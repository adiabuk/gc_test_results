-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-12 03:59:59','2019-01-14 15:59:59','RCNETH','4h','0.000086100000000','0.000084480000000','0.072144500000000','0.070787077351916','837.9152148664343','837.915214866434326','test'),('2019-01-14 19:59:59','2019-01-22 19:59:59','RCNETH','4h','0.000085540000000','0.000104760000000','0.072144500000000','0.088354662380173','843.4007481879822','843.400748187982231','test'),('2019-01-29 03:59:59','2019-01-31 03:59:59','RCNETH','4h','0.000104870000000','0.000103180000000','0.075857684933022','0.074635223909499','723.349718060668','723.349718060668010','test'),('2019-02-08 07:59:59','2019-02-08 11:59:59','RCNETH','4h','0.000101090000000','0.000097830000000','0.075857684933022','0.073411389029553','750.3975164014442','750.397516401444250','test'),('2019-02-22 07:59:59','2019-02-24 11:59:59','RCNETH','4h','0.000118400000000','0.000102000000000','0.075857684933022','0.065350370465948','640.689906528902','640.689906528902043','test'),('2019-02-24 23:59:59','2019-03-03 19:59:59','RCNETH','4h','0.000111500000000','0.000147810000000','0.075857684933022','0.100560757039910','680.3379814620807','680.337981462080734','test'),('2019-03-04 19:59:59','2019-03-06 03:59:59','RCNETH','4h','0.000161530000000','0.000152410000000','0.078489435111228','0.074057913733067','485.91243181593353','485.912431815933530','test'),('2019-03-08 11:59:59','2019-03-11 07:59:59','RCNETH','4h','0.000172190000000','0.000163420000000','0.078489435111228','0.074491802577832','455.8303914932807','455.830391493280672','test'),('2019-03-12 19:59:59','2019-03-13 03:59:59','RCNETH','4h','0.000179150000000','0.000169370000000','0.078489435111228','0.074204608567059','438.1213235346246','438.121323534624594','test'),('2019-03-13 11:59:59','2019-03-13 15:59:59','RCNETH','4h','0.000170680000000','0.000168850000000','0.078489435111228','0.077647885625327','459.86310704961323','459.863107049613234','test'),('2019-03-14 23:59:59','2019-03-16 19:59:59','RCNETH','4h','0.000179620000000','0.000172420000000','0.078489435111228','0.075343215687996','436.9749198932636','436.974919893263575','test'),('2019-03-17 11:59:59','2019-03-17 15:59:59','RCNETH','4h','0.000175350000000','0.000172920000000','0.078489435111228','0.077401728653741','447.61582612619327','447.615826126193269','test'),('2019-03-17 23:59:59','2019-03-20 19:59:59','RCNETH','4h','0.000174540000000','0.000176620000000','0.078489435111228','0.079424796776356','449.69310823437604','449.693108234376041','test'),('2019-03-27 23:59:59','2019-04-02 07:59:59','RCNETH','4h','0.000179210000000','0.000208630000000','0.078489435111228','0.091374648999807','437.9746393126946','437.974639312694592','test'),('2019-04-14 03:59:59','2019-04-14 23:59:59','RCNETH','4h','0.000191200000000','0.000184500000000','0.078489435111228','0.075739020805552','410.5095978620711','410.509597862071075','test'),('2019-04-15 07:59:59','2019-04-15 23:59:59','RCNETH','4h','0.000185420000000','0.000185460000000','0.078489435111228','0.078506367359122','423.306197342401','423.306197342400992','test'),('2019-04-16 03:59:59','2019-04-17 23:59:59','RCNETH','4h','0.000187160000000','0.000187050000000','0.078489435111228','0.078443304325471','419.37077960690317','419.370779606903170','test'),('2019-04-20 11:59:59','2019-04-20 23:59:59','RCNETH','4h','0.000193870000000','0.000185540000000','0.078489435111228','0.075116984528484','404.85601233418265','404.856012334182651','test'),('2019-04-21 03:59:59','2019-04-21 11:59:59','RCNETH','4h','0.000187820000000','0.000182640000000','0.078489435111228','0.076324728083882','417.8971095262911','417.897109526291104','test'),('2019-05-02 15:59:59','2019-05-04 11:59:59','RCNETH','4h','0.000206320000000','0.000166980000000','0.078489435111228','0.063523487179492','380.4257227182435','380.425722718243492','test'),('2019-06-02 15:59:59','2019-06-03 07:59:59','RCNETH','4h','0.000129610000000','0.000127150000000','0.078489435111228','0.076999704300537','605.5816303620708','605.581630362070769','test'),('2019-06-03 11:59:59','2019-06-04 03:59:59','RCNETH','4h','0.000128230000000','0.000127000000000','0.078489435111228','0.077736553529798','612.0988466913202','612.098846691320205','test'),('2019-06-08 07:59:59','2019-06-12 15:59:59','RCNETH','4h','0.000128340000000','0.000128200000000','0.078489435111228','0.078403814720737','611.5742177904627','611.574217790462740','test'),('2019-06-12 19:59:59','2019-06-12 23:59:59','RCNETH','4h','0.000129360000000','0.000123680000000','0.078489435111228','0.075043083909684','606.7519721028757','606.751972102875698','test'),('2019-06-21 11:59:59','2019-06-21 23:59:59','RCNETH','4h','0.000131100000000','0.000120310000000','0.078489435111228','0.072029473213058','598.6989711001373','598.698971100137328','test'),('2019-07-22 19:59:59','2019-07-23 19:59:59','RCNETH','4h','0.000086890000000','0.000083890000000','0.078489435111228','0.075779476481539','903.3195432296926','903.319543229692613','test'),('2019-07-24 03:59:59','2019-07-24 07:59:59','RCNETH','4h','0.000083110000000','0.000085720000000','0.078489435111228','0.080954330137582','944.4042246568163','944.404224656816268','test'),('2019-07-24 11:59:59','2019-07-24 23:59:59','RCNETH','4h','0.000086570000000','0.000084160000000','0.078489435111228','0.076304387882187','906.6586012617303','906.658601261730269','test'),('2019-07-25 11:59:59','2019-07-29 03:59:59','RCNETH','4h','0.000084900000000','0.000091320000000','0.078489435111228','0.084424678614339','924.4927574938515','924.492757493851514','test'),('2019-08-21 19:59:59','2019-08-27 15:59:59','RCNETH','4h','0.000080670000000','0.000087040000000','0.078489435111228','0.084687249684905','972.969320828412','972.969320828412037','test'),('2019-08-31 07:59:59','2019-09-01 07:59:59','RCNETH','4h','0.000088230000000','0.000087110000000','0.078489435111228','0.077493082767075','889.6003072790206','889.600307279020626','test'),('2019-09-01 15:59:59','2019-09-01 19:59:59','RCNETH','4h','0.000087110000000','0.000086670000000','0.078489435111228','0.078092978315809','901.0381714065893','901.038171406589299','test'),('2019-09-19 03:59:59','2019-09-28 03:59:59','RCNETH','4h','0.000097280000000','0.000228680000000','0.078489435111228','0.184508265020925','806.8404102716694','806.840410271669384','test'),('2019-10-01 23:59:59','2019-10-06 07:59:59','RCNETH','4h','0.000242160000000','0.000217940000000','0.097200140980780','0.087478521330324','401.38809456879557','401.388094568795566','test'),('2019-10-08 15:59:59','2019-10-09 15:59:59','RCNETH','4h','0.000227850000000','0.000210870000000','0.097200140980780','0.089956522837907','426.5970637734474','426.597063773447417','test'),('2019-10-21 19:59:59','2019-10-24 15:59:59','RCNETH','4h','0.000227460000000','0.000245000000000','0.097200140980780','0.104695482899372','427.32850163008885','427.328501630088851','test'),('2019-11-02 03:59:59','2019-11-04 15:59:59','RCNETH','4h','0.000231270000000','0.000226800000000','0.097200140980780','0.095321451007225','420.2885846879405','420.288584687940499','test'),('2019-11-06 19:59:59','2019-11-09 23:59:59','RCNETH','4h','0.000256040000000','0.000245310000000','0.097200140980780','0.093126724668002','379.62873371652864','379.628733716528643','test'),('2019-11-10 23:59:59','2019-11-14 11:59:59','RCNETH','4h','0.000256440000000','0.000251420000000','0.097200140980780','0.095297377341240','379.03658158157856','379.036581581578560','test'),('2019-11-14 15:59:59','2019-11-15 19:59:59','RCNETH','4h','0.000258120000000','0.000255130000000','0.097200140980780','0.096074197925098','376.56958383999694','376.569583839996938','test'),('2019-11-16 19:59:59','2019-11-17 11:59:59','RCNETH','4h','0.000269080000000','0.000255350000000','0.097200140980780','0.092240434069578','361.2313846468708','361.231384646870822','test'),('2019-11-20 11:59:59','2019-11-20 23:59:59','RCNETH','4h','0.000262860000000','0.000261420000000','0.097200140980780','0.096667659039776','369.7791256972533','369.779125697253278','test'),('2019-11-21 03:59:59','2019-11-21 11:59:59','RCNETH','4h','0.000261580000000','0.000254040000000','0.097200140980780','0.094398363081112','371.5885808577873','371.588580857787292','test'),('2019-11-21 15:59:59','2019-11-21 19:59:59','RCNETH','4h','0.000254750000000','0.000257850000000','0.097200140980780','0.098382949369555','381.5510931532091','381.551093153209081','test'),('2019-11-21 23:59:59','2019-11-29 07:59:59','RCNETH','4h','0.000269610000000','0.000312980000000','0.097200140980780','0.112835948682039','360.521275103965','360.521275103965024','test'),('2019-11-29 11:59:59','2019-11-30 07:59:59','RCNETH','4h','0.000317300000000','0.000311600000000','0.097200140980780','0.095454030663760','306.3351433368421','306.335143336842123','test'),('2019-12-01 07:59:59','2019-12-03 15:59:59','RCNETH','4h','0.000372200000000','0.000331020000000','0.097200140980780','0.086445971701929','261.1502981751209','261.150298175120895','test'),('2019-12-07 03:59:59','2019-12-08 03:59:59','RCNETH','4h','0.000337340000000','0.000324160000000','0.097200140980780','0.093402495109770','288.137016009901','288.137016009901004','test'),('2019-12-09 11:59:59','2019-12-09 19:59:59','RCNETH','4h','0.000347170000000','0.000334530000000','0.097200140980780','0.093661212553793','279.9785147932713','279.978514793271302','test'),('2019-12-18 11:59:59','2019-12-18 19:59:59','RCNETH','4h','0.000319230000000','0.000312030000000','0.097200140980780','0.095007862638952','304.4831030316073','304.483103031607300','test'),('2019-12-18 23:59:59','2019-12-25 23:59:59','RCNETH','4h','0.000319070000000','0.000358800000000','0.097200140980780','0.109303320850923','304.63578832475633','304.635788324756334','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:48:37
