-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 07:59:59','2019-01-13 11:59:59','BATBTC','4h','0.000035250000000','0.000035210000000','0.001467500000000','0.001465834751773','41.63120567375886','41.631205673758863','test'),('2019-01-19 03:59:59','2019-01-19 07:59:59','BATBTC','4h','0.000034770000000','0.000034510000000','0.001467500000000','0.001456526459592','42.20592464768479','42.205924647684789','test'),('2019-01-19 15:59:59','2019-01-19 19:59:59','BATBTC','4h','0.000034650000000','0.000034660000000','0.001467500000000','0.001467923520924','42.35209235209235','42.352092352092349','test'),('2019-01-19 23:59:59','2019-01-20 15:59:59','BATBTC','4h','0.000034900000000','0.000034440000000','0.001467500000000','0.001448157593123','42.0487106017192','42.048710601719200','test'),('2019-01-25 15:59:59','2019-01-27 15:59:59','BATBTC','4h','0.000035070000000','0.000034690000000','0.001467500000000','0.001451598944967','41.84488166524095','41.844881665240948','test'),('2019-02-08 11:59:59','2019-02-08 23:59:59','BATBTC','4h','0.000033000000000','0.000032360000000','0.001467500000000','0.001439039393939','44.46969696969697','44.469696969696969','test'),('2019-02-10 07:59:59','2019-02-11 23:59:59','BATBTC','4h','0.000033290000000','0.000033060000000','0.001467500000000','0.001457361069390','44.082306999098826','44.082306999098826','test'),('2019-02-14 03:59:59','2019-02-19 03:59:59','BATBTC','4h','0.000034840000000','0.000035430000000','0.001467500000000','0.001492351463835','42.121125143513204','42.121125143513204','test'),('2019-02-26 07:59:59','2019-03-04 03:59:59','BATBTC','4h','0.000047510000000','0.000043330000000','0.001467500000000','0.001338387181646','30.888234055988217','30.888234055988217','test'),('2019-03-05 03:59:59','2019-03-06 11:59:59','BATBTC','4h','0.000045890000000','0.000044970000000','0.001467500000000','0.001438079646982','31.97864458487688','31.978644584876879','test'),('2019-03-07 15:59:59','2019-03-11 15:59:59','BATBTC','4h','0.000046130000000','0.000049540000000','0.001467500000000','0.001575979839584','31.81226967266421','31.812269672664211','test'),('2019-03-15 11:59:59','2019-03-16 07:59:59','BATBTC','4h','0.000049960000000','0.000049440000000','0.001467500000000','0.001452225780624','29.37349879903923','29.373498799039229','test'),('2019-03-16 11:59:59','2019-03-16 15:59:59','BATBTC','4h','0.000049530000000','0.000049460000000','0.001467500000000','0.001465426004442','29.628507974964666','29.628507974964666','test'),('2019-03-22 19:59:59','2019-04-02 07:59:59','BATBTC','4h','0.000049650000000','0.000066050000000','0.001467500000000','0.001952233131923','29.556898288016114','29.556898288016114','test'),('2019-04-14 03:59:59','2019-04-15 19:59:59','BATBTC','4h','0.000063380000000','0.000058220000000','0.001556531195686','0.001429808239395','24.558712459545593','24.558712459545593','test'),('2019-04-16 11:59:59','2019-04-22 23:59:59','BATBTC','4h','0.000061730000000','0.000074340000000','0.001556531195686','0.001874494234364','25.21514977621902','25.215149776219022','test'),('2019-04-24 19:59:59','2019-04-26 03:59:59','BATBTC','4h','0.000080400000000','0.000072750000000','0.001604341216283','0.001451689346823','19.954492739835196','19.954492739835196','test'),('2019-04-28 19:59:59','2019-04-29 11:59:59','BATBTC','4h','0.000078000000000','0.000073500000000','0.001604341216283','0.001511783069190','20.568477131833333','20.568477131833333','test'),('2019-06-08 03:59:59','2019-06-08 15:59:59','BATBTC','4h','0.000043110000000','0.000042400000000','0.001604341216283','0.001577918524018','37.215059528717234','37.215059528717234','test'),('2019-06-08 19:59:59','2019-06-08 23:59:59','BATBTC','4h','0.000042470000000','0.000042510000000','0.001604341216283','0.001605852251099','37.77587040930069','37.775870409300687','test'),('2019-06-09 07:59:59','2019-06-09 15:59:59','BATBTC','4h','0.000043050000000','0.000042260000000','0.001604341216283','0.001574900343789','37.2669272075029','37.266927207502903','test'),('2019-07-02 23:59:59','2019-07-03 03:59:59','BATBTC','4h','0.000029710000000','0.000027490000000','0.001604341216283','0.001484461125400','54.000040938505556','54.000040938505556','test'),('2019-07-23 03:59:59','2019-07-23 07:59:59','BATBTC','4h','0.000024650000000','0.000023540000000','0.001604341216283','0.001532097047923','65.08483636036512','65.084836360365117','test'),('2019-07-23 11:59:59','2019-07-23 15:59:59','BATBTC','4h','0.000023670000000','0.000023250000000','0.001604341216283','0.001575873818275','67.77951906561049','67.779519065610486','test'),('2019-07-26 11:59:59','2019-07-30 03:59:59','BATBTC','4h','0.000024400000000','0.000025950000000','0.001604341216283','0.001706256334530','65.75168919192623','65.751689191926232','test'),('2019-08-22 15:59:59','2019-08-26 03:59:59','BATBTC','4h','0.000019400000000','0.000018430000000','0.001604341216283','0.001524124155469','82.6980008393299','82.698000839329893','test'),('2019-09-01 19:59:59','2019-09-02 03:59:59','BATBTC','4h','0.000018960000000','0.000018260000000','0.001604341216283','0.001545109209353','84.61715275754219','84.617152757542186','test'),('2019-09-16 19:59:59','2019-09-22 19:59:59','BATBTC','4h','0.000017410000000','0.000019300000000','0.001604341216283','0.001778505771066','92.1505580863297','92.150558086329696','test'),('2019-09-23 15:59:59','2019-09-23 23:59:59','BATBTC','4h','0.000020320000000','0.000019210000000','0.001604341216283','0.001516702498268','78.95380001392716','78.953800013927165','test'),('2019-09-27 19:59:59','2019-09-30 07:59:59','BATBTC','4h','0.000020400000000','0.000019730000000','0.001604341216283','0.001551649617513','78.6441772687745','78.644177268774499','test'),('2019-09-30 11:59:59','2019-10-01 19:59:59','BATBTC','4h','0.000020050000000','0.000019730000000','0.001604341216283','0.001578735770437','80.01701826847881','80.017018268478807','test'),('2019-10-02 11:59:59','2019-10-09 15:59:59','BATBTC','4h','0.000020350000000','0.000023430000000','0.001604341216283','0.001847160427396','78.83740620555282','78.837406205552824','test'),('2019-10-13 11:59:59','2019-10-19 11:59:59','BATBTC','4h','0.000024270000000','0.000027160000000','0.001604341216283','0.001795381435280','66.10388200589205','66.103882005892046','test'),('2019-10-22 11:59:59','2019-10-25 19:59:59','BATBTC','4h','0.000028520000000','0.000028720000000','0.001604341216283','0.001615591855948','56.253198326893404','56.253198326893404','test'),('2019-11-05 23:59:59','2019-11-08 15:59:59','BATBTC','4h','0.000026810000000','0.000026530000000','0.001604341216283','0.001587585694442','59.84114943241328','59.841149432413282','test'),('2019-11-09 11:59:59','2019-11-10 23:59:59','BATBTC','4h','0.000027520000000','0.000027040000000','0.001604341216283','0.001576358520650','58.297282568422965','58.297282568422965','test'),('2019-11-13 11:59:59','2019-11-19 11:59:59','BATBTC','4h','0.000028020000000','0.000030060000000','0.001604341216283','0.001721145501837','57.25700272244825','57.257002722448249','test'),('2019-11-23 15:59:59','2019-11-23 19:59:59','BATBTC','4h','0.000030640000000','0.000029930000000','0.001604341216283','0.001567164902198','52.361005753361624','52.361005753361624','test'),('2019-11-23 23:59:59','2019-11-24 07:59:59','BATBTC','4h','0.000030250000000','0.000029760000000','0.001604341216283','0.001578353540383','53.03607326555372','53.036073265553718','test'),('2019-11-24 11:59:59','2019-11-24 15:59:59','BATBTC','4h','0.000030440000000','0.000029650000000','0.001604341216283','0.001562704239908','52.705033386432326','52.705033386432326','test'),('2019-11-24 19:59:59','2019-11-24 23:59:59','BATBTC','4h','0.000029720000000','0.000029350000000','0.001604341216283','0.001584367923886','53.981871341958275','53.981871341958275','test'),('2019-11-25 03:59:59','2019-11-25 07:59:59','BATBTC','4h','0.000029880000000','0.000030300000000','0.001604341216283','0.001626892197235','53.692811789926374','53.692811789926374','test'),('2019-12-15 15:59:59','2019-12-16 11:59:59','BATBTC','4h','0.000025910000000','0.000025500000000','0.001604341216283','0.001578954110969','61.91976905762254','61.919769057622538','test'),('2019-12-16 15:59:59','2019-12-16 19:59:59','BATBTC','4h','0.000025700000000','0.000025130000000','0.001604341216283','0.001568758551175','62.42572826003891','62.425728260038909','test'),('2019-12-28 15:59:59','2019-12-31 19:59:59','BATBTC','4h','0.000024610000000','0.000025320000000','0.001604341216283','0.001650626558159','65.19062236013815','65.190622360138150','test'),('2020-01-01 11:59:59','2020-01-01 15:59:59','BATBTC','4h','0.000026500000000','0.000026110000000','0.001604341216283','0.001580730156874','60.541177972943395','60.541177972943395','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:53:14
