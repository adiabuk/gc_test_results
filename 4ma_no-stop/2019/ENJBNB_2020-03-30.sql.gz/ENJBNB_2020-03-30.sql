-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-02-18 15:59:59','2019-02-19 15:59:59','ENJBNB','4h','0.003735000000000','0.003462000000000','0.711908500000000','0.659873420883534','190.60468540829987','190.604685408299872','test'),('2019-02-21 15:59:59','2019-02-24 23:59:59','ENJBNB','4h','0.003593000000000','0.003604000000000','0.711908500000000','0.714088013915948','198.13762872251604','198.137628722516041','test'),('2019-02-25 03:59:59','2019-03-01 07:59:59','ENJBNB','4h','0.004221000000000','0.007505000000000','0.711908500000000','1.265783769841270','168.65873015873018','168.658730158730179','test'),('2019-03-06 03:59:59','2019-03-06 23:59:59','ENJBNB','4h','0.007681000000000','0.006811000000000','0.837913426160188','0.743005903603312','109.08910638721363','109.089106387213633','test'),('2019-03-08 03:59:59','2019-03-11 19:59:59','ENJBNB','4h','0.008963000000000','0.011843000000000','0.837913426160188','1.107152594668650','93.48582239877139','93.485822398771390','test'),('2019-03-18 11:59:59','2019-03-23 07:59:59','ENJBNB','4h','0.013211000000000','0.012204000000000','0.881496337648084','0.814304844800334','66.72442189448826','66.724421894488259','test'),('2019-04-14 03:59:59','2019-04-14 19:59:59','ENJBNB','4h','0.009268000000000','0.008142000000000','0.881496337648084','0.774400429556614','95.11181890894302','95.111818908943022','test'),('2019-04-14 23:59:59','2019-04-15 03:59:59','ENJBNB','4h','0.008300000000000','0.008066000000000','0.881496337648084','0.856644513189090','106.20437802988964','106.204378029889639','test'),('2019-04-18 11:59:59','2019-04-18 15:59:59','ENJBNB','4h','0.008585000000000','0.008085000000000','0.881496337648084','0.830157005228277','102.67866483961373','102.678664839613731','test'),('2019-04-18 19:59:59','2019-04-18 23:59:59','ENJBNB','4h','0.008280000000000','0.008085000000000','0.881496337648084','0.860736460131010','106.4609103439715','106.460910343971506','test'),('2019-04-19 07:59:59','2019-04-19 15:59:59','ENJBNB','4h','0.008866000000000','0.007818000000000','0.881496337648084','0.777299612873079','99.42435570134039','99.424355701340389','test'),('2019-05-10 23:59:59','2019-05-12 11:59:59','ENJBNB','4h','0.007074000000000','0.006755000000000','0.881496337648084','0.841745513261635','124.61073475375798','124.610734753757981','test'),('2019-07-02 03:59:59','2019-07-02 07:59:59','ENJBNB','4h','0.003864000000000','0.003785000000000','0.881496337648084','0.863474026396997','228.13052216565322','228.130522165653218','test'),('2019-07-02 11:59:59','2019-07-02 19:59:59','ENJBNB','4h','0.003824000000000','0.003846000000000','0.881496337648084','0.886567707791457','230.51682469876673','230.516824698766726','test'),('2019-07-07 07:59:59','2019-07-08 07:59:59','ENJBNB','4h','0.003871000000000','0.003638000000000','0.881496337648084','0.828438046076913','227.7179895758419','227.717989575841898','test'),('2019-07-29 11:59:59','2019-07-29 15:59:59','ENJBNB','4h','0.003134000000000','0.003079000000000','0.881496337648084','0.866026555079276','281.2687739783293','281.268773978329307','test'),('2019-07-29 23:59:59','2019-07-31 15:59:59','ENJBNB','4h','0.003069000000000','0.003118000000000','0.881496337648084','0.895570407555141','287.22591647053895','287.225916470538948','test'),('2019-07-31 19:59:59','2019-07-31 23:59:59','ENJBNB','4h','0.003125000000000','0.003136000000000','0.881496337648084','0.884599204756605','282.0788280473869','282.078828047386878','test'),('2019-08-22 03:59:59','2019-08-25 23:59:59','ENJBNB','4h','0.002372000000000','0.002591000000000','0.881496337648084','0.962882382312894','371.6257747251619','371.625774725161875','test'),('2019-08-27 11:59:59','2019-09-03 23:59:59','ENJBNB','4h','0.002731000000000','0.003369000000000','0.881496337648084','1.087426276651920','322.7741990655745','322.774199065574521','test'),('2019-09-04 03:59:59','2019-09-06 11:59:59','ENJBNB','4h','0.003620000000000','0.003590000000000','0.881496337648084','0.874191119380282','243.50727559339336','243.507275593393359','test'),('2019-09-08 19:59:59','2019-09-09 11:59:59','ENJBNB','4h','0.003678000000000','0.003552000000000','0.881496337648084','0.851298257565523','239.66730224254596','239.667302242545958','test'),('2019-09-24 11:59:59','2019-09-24 19:59:59','ENJBNB','4h','0.003433000000000','0.003444000000000','0.881496337648084','0.884320823437227','256.77143537666296','256.771435376662964','test'),('2019-09-24 23:59:59','2019-09-25 15:59:59','ENJBNB','4h','0.003467000000000','0.003465000000000','0.881496337648084','0.880987830963545','254.2533422694214','254.253342269421410','test'),('2019-09-25 23:59:59','2019-09-26 15:59:59','ENJBNB','4h','0.003502000000000','0.003426000000000','0.881496337648084','0.862366205820199','251.71226089322786','251.712260893227864','test'),('2019-09-26 19:59:59','2019-09-26 23:59:59','ENJBNB','4h','0.003440000000000','0.003426000000000','0.881496337648084','0.877908852553005','256.24893536281513','256.248935362815132','test'),('2019-09-27 15:59:59','2019-10-07 03:59:59','ENJBNB','4h','0.003503000000000','0.003952000000000','0.881496337648084','0.994482879356331','251.64040469542792','251.640404695427918','test'),('2019-10-08 23:59:59','2019-10-09 07:59:59','ENJBNB','4h','0.004156000000000','0.003900000000000','0.881496337648084','0.827198199429145','212.10210241772955','212.102102417729554','test'),('2019-10-24 11:59:59','2019-10-25 03:59:59','ENJBNB','4h','0.003535000000000','0.003330000000000','0.881496337648084','0.830377030938648','249.36247175334768','249.362471753347677','test'),('2019-10-25 07:59:59','2019-10-25 11:59:59','ENJBNB','4h','0.003334000000000','0.003277000000000','0.881496337648084','0.866425764388953','264.3960220900072','264.396022090007193','test'),('2019-11-01 23:59:59','2019-11-02 15:59:59','ENJBNB','4h','0.003324000000000','0.003242000000000','0.881496337648084','0.859750639787933','265.19143731891813','265.191437318918133','test'),('2019-11-02 19:59:59','2019-11-03 07:59:59','ENJBNB','4h','0.003271000000000','0.003213000000000','0.881496337648084','0.865866014326901','269.488333123841','269.488333123841016','test'),('2019-11-03 23:59:59','2019-11-04 03:59:59','ENJBNB','4h','0.003284000000000','0.003217000000000','0.881496337648084','0.863512094462206','268.4215400877235','268.421540087723486','test'),('2019-11-04 19:59:59','2019-11-04 23:59:59','ENJBNB','4h','0.003313000000000','0.003224000000000','0.881496337648084','0.857815934976584','266.0719401292134','266.071940129213374','test'),('2019-11-06 19:59:59','2019-11-06 23:59:59','ENJBNB','4h','0.003280000000000','0.003253000000000','0.881496337648084','0.874240117795493','268.7488834292939','268.748883429293926','test'),('2019-11-07 07:59:59','2019-11-07 11:59:59','ENJBNB','4h','0.003265000000000','0.003212000000000','0.881496337648084','0.867187208736798','269.98356436388485','269.983564363884852','test'),('2019-11-16 11:59:59','2019-11-24 11:59:59','ENJBNB','4h','0.003228000000000','0.003570000000000','0.881496337648084','0.974889072305966','273.07817151427633','273.078171514276335','test'),('2019-11-27 23:59:59','2019-12-08 03:59:59','ENJBNB','4h','0.003646000000000','0.005453000000000','0.881496337648084','1.318376173668404','241.7708002326067','241.770800232606689','test'),('2019-12-08 11:59:59','2019-12-09 03:59:59','ENJBNB','4h','0.005952000000000','0.005700000000000','0.924518353439988','0.885375439282247','155.3290244354818','155.329024435481813','test'),('2019-12-12 07:59:59','2019-12-14 07:59:59','ENJBNB','4h','0.005708000000000','0.005446000000000','0.924518353439988','0.882082507504235','161.96887761737702','161.968877617377018','test'),('2019-12-16 07:59:59','2019-12-18 15:59:59','ENJBNB','4h','0.005900000000000','0.005898000000000','0.924518353439988','0.924204957387974','156.69802600677764','156.698026006777638','test'),('2019-12-18 19:59:59','2019-12-18 23:59:59','ENJBNB','4h','0.005992000000000','0.005677000000000','0.924518353439988','0.875916337196063','154.29211506007812','154.292115060078117','test'),('2019-12-20 19:59:59','2019-12-20 23:59:59','ENJBNB','4h','0.006003000000000','0.005727000000000','0.924518353439988','0.882011762477230','154.0093875462249','154.009387546224900','test'),('2019-12-22 11:59:59','2019-12-23 03:59:59','ENJBNB','4h','0.006141000000000','0.005695000000000','0.924518353439988','0.857373721354947','150.54850243282658','150.548502432826581','test'),('2019-12-25 03:59:59','2019-12-25 15:59:59','ENJBNB','4h','0.005980000000000','0.005809000000000','0.924518353439988','0.898081457380082','154.6017313444796','154.601731344479589','test'),('2019-12-29 07:59:59','2019-12-29 15:59:59','ENJBNB','4h','0.005937000000000','0.005843000000000','0.924518353439988','0.909880535480857','155.72146765032645','155.721467650326446','test'),('2019-12-29 23:59:59','2019-12-30 03:59:59','ENJBNB','4h','0.005804000000000','0.005738000000000','0.924518353439988','0.914005222611759','159.28986103376775','159.289861033767750','test'),('2019-12-30 15:59:59','2019-12-31 23:59:59','ENJBNB','4h','0.006024000000000','0.005865000000000','0.924518353439988','0.900116225585247','153.47250223107372','153.472502231073719','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  6:01:24
