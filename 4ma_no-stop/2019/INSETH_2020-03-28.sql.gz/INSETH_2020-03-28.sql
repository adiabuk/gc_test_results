-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 03:59:59','2019-01-17 15:59:59','INSETH','4h','0.002263000000000','0.002407000000000','0.072144500000000','0.076735223817941','31.880026513477688','31.880026513477688','test'),('2019-01-18 15:59:59','2019-01-22 11:59:59','INSETH','4h','0.002548000000000','0.002582000000000','0.073292180954485','0.074270177089670','28.764592211336442','28.764592211336442','test'),('2019-01-22 15:59:59','2019-01-23 23:59:59','INSETH','4h','0.002664000000000','0.002628000000000','0.073536679988282','0.072542941069521','27.60385885446002','27.603858854460022','test'),('2019-02-05 03:59:59','2019-02-05 11:59:59','INSETH','4h','0.002576000000000','0.002522000000000','0.073536679988282','0.071995150205919','28.546847821538044','28.546847821538044','test'),('2019-02-27 03:59:59','2019-02-28 11:59:59','INSETH','4h','0.002052000000000','0.001990000000000','0.073536679988282','0.071314811489611','35.83658868824659','35.836588688246593','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','INSETH','4h','0.001996000000000','0.001995000000000','0.073536679988282','0.073499837964240','36.842024042225454','36.842024042225454','test'),('2019-03-01 07:59:59','2019-03-05 11:59:59','INSETH','4h','0.002031000000000','0.002118000000000','0.073536679988282','0.076686700253659','36.207129487091095','36.207129487091095','test'),('2019-03-12 01:59:59','2019-03-15 15:59:59','INSETH','4h','0.002080000000000','0.002128000000000','0.073536679988282','0.075233680295704','35.35417307128943','35.354173071289431','test'),('2019-03-20 03:59:59','2019-03-21 03:59:59','INSETH','4h','0.002115000000000','0.002154000000000','0.073549940325522','0.074906180359893','34.7753854967007','34.775385496700700','test'),('2019-03-25 15:59:59','2019-03-26 07:59:59','INSETH','4h','0.002111000000000','0.002109000000000','0.073889000334115','0.073818996544125','35.001894994843546','35.001894994843546','test'),('2019-03-26 15:59:59','2019-03-27 07:59:59','INSETH','4h','0.002143000000000','0.002130000000000','0.073889000334115','0.073440770280758','34.47923487359542','34.479234873595423','test'),('2019-03-27 11:59:59','2019-03-30 03:59:59','INSETH','4h','0.002173000000000','0.002137000000000','0.073889000334115','0.072664884359873','34.00322150672572','34.003221506725723','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','INSETH','4h','0.002258000000000','0.002309000000000','0.073889000334115','0.075557883866905','32.72320652529451','32.723206525294508','test'),('2019-04-07 11:59:59','2019-04-07 23:59:59','INSETH','4h','0.002315000000000','0.002132000000000','0.073889000334115','0.068048098795824','31.917494744758102','31.917494744758102','test'),('2019-05-24 19:59:59','2019-05-24 23:59:59','INSETH','4h','0.001376000000000','0.001374000000000','0.073889000334115','0.073781603531304','53.69840140560682','53.698401405606823','test'),('2019-05-25 07:59:59','2019-05-25 11:59:59','INSETH','4h','0.001348000000000','0.001292000000000','0.073889000334115','0.070819427619938','54.81379846744436','54.813798467444357','test'),('2019-05-27 19:59:59','2019-05-28 19:59:59','INSETH','4h','0.001432000000000','0.001378000000000','0.073889000334115','0.071102683282410','51.59846392047137','51.598463920471367','test'),('2019-05-29 03:59:59','2019-05-29 07:59:59','INSETH','4h','0.001380000000000','0.001389000000000','0.073889000334115','0.074370885118903','53.542753865300725','53.542753865300725','test'),('2019-05-29 11:59:59','2019-05-30 03:59:59','INSETH','4h','0.001399000000000','0.001358000000000','0.073889000334115','0.071723561439405','52.815582797794846','52.815582797794846','test'),('2019-06-02 23:59:59','2019-06-03 03:59:59','INSETH','4h','0.001384000000000','0.001359000000000','0.073889000334115','0.072554300183571','53.38800602175939','53.388006021759388','test'),('2019-06-03 15:59:59','2019-06-03 23:59:59','INSETH','4h','0.001421000000000','0.001378000000000','0.073889000334115','0.071653091105145','51.997889045823364','51.997889045823364','test'),('2019-06-04 11:59:59','2019-06-04 15:59:59','INSETH','4h','0.001379000000000','0.001384000000000','0.073889000334115','0.074156908239605','53.58158109798042','53.581581097980418','test'),('2019-06-05 03:59:59','2019-06-08 19:59:59','INSETH','4h','0.001430000000000','0.001428000000000','0.073889000334115','0.073785659074906','51.67062960427622','51.670629604276222','test'),('2019-06-08 23:59:59','2019-06-12 19:59:59','INSETH','4h','0.001458000000000','0.001508000000000','0.073889000334115','0.076422916669304','50.678326703782574','50.678326703782574','test'),('2019-06-12 23:59:59','2019-06-14 11:59:59','INSETH','4h','0.001510000000000','0.001470000000000','0.073889000334115','0.071931675821953','48.933112804049664','48.933112804049664','test'),('2019-06-20 15:59:59','2019-06-20 23:59:59','INSETH','4h','0.001487000000000','0.001493000000000','0.073889000334115','0.074187140214414','49.68998004984196','49.689980049841957','test'),('2019-06-21 03:59:59','2019-06-21 07:59:59','INSETH','4h','0.001517000000000','0.001498000000000','0.073889000334115','0.072963561305540','48.70731729341793','48.707317293417930','test'),('2019-06-21 11:59:59','2019-06-21 19:59:59','INSETH','4h','0.001510000000000','0.001438000000000','0.073889000334115','0.070365816212223','48.933112804049664','48.933112804049664','test'),('2019-06-21 23:59:59','2019-06-22 03:59:59','INSETH','4h','0.001605000000000','0.001432000000000','0.073889000334115','0.065924640796544','46.036760332781924','46.036760332781924','test'),('2019-07-04 19:59:59','2019-07-05 11:59:59','INSETH','4h','0.001251000000000','0.001197000000000','0.073889000334115','0.070699547082283','59.063949108005595','59.063949108005595','test'),('2019-07-05 15:59:59','2019-07-05 23:59:59','INSETH','4h','0.001211000000000','0.001183000000000','0.073889000334115','0.072180584141419','61.01486402486787','61.014864024867869','test'),('2019-07-06 03:59:59','2019-07-06 07:59:59','INSETH','4h','0.001193000000000','0.001175000000000','0.073889000334115','0.072774162106107','61.93545711158004','61.935457111580043','test'),('2019-07-07 07:59:59','2019-07-07 11:59:59','INSETH','4h','0.001223000000000','0.001192000000000','0.073889000334115','0.072016098445025','60.416189970658216','60.416189970658216','test'),('2019-07-15 03:59:59','2019-07-20 19:59:59','INSETH','4h','0.001180000000000','0.001270000000000','0.073889000334115','0.079524602054514','62.61779689331779','62.617796893317788','test'),('2019-07-31 07:59:59','2019-07-31 15:59:59','INSETH','4h','0.001306000000000','0.001237000000000','0.073889000334115','0.069985217008653','56.57656993423812','56.576569934238123','test'),('2019-07-31 19:59:59','2019-08-01 19:59:59','INSETH','4h','0.001252000000000','0.001223000000000','0.073889000334115','0.072177513904651','59.0167734298043','59.016773429804303','test'),('2019-08-03 15:59:59','2019-08-03 23:59:59','INSETH','4h','0.001257000000000','0.001221000000000','0.073889000334115','0.071772847579916','58.78202094997215','58.782020949972150','test'),('2019-08-04 03:59:59','2019-08-04 07:59:59','INSETH','4h','0.001225000000000','0.001224000000000','0.073889000334115','0.073828682782822','60.3175512931551','60.317551293155098','test'),('2019-08-21 15:59:59','2019-08-23 19:59:59','INSETH','4h','0.001185000000000','0.001130000000000','0.073889000334115','0.070459553061224','62.35358677984387','62.353586779843873','test'),('2019-08-28 15:59:59','2019-08-31 19:59:59','INSETH','4h','0.001148000000000','0.001410000000000','0.073889000334115','0.090752169399915','64.36324070915941','64.363240709159413','test'),('2019-09-02 11:59:59','2019-09-06 03:59:59','INSETH','4h','0.001470000000000','0.001515000000000','0.073889000334115','0.076150908507608','50.26462607762925','50.264626077629252','test'),('2019-09-07 03:59:59','2019-09-07 19:59:59','INSETH','4h','0.001659000000000','0.001525000000000','0.073889000334115','0.067920871313759','44.53827627131705','44.538276271317052','test'),('2019-09-08 23:59:59','2019-09-09 07:59:59','INSETH','4h','0.001635000000000','0.001524000000000','0.073889000334115','0.068872682880239','45.19204913401529','45.192049134015292','test'),('2019-09-12 03:59:59','2019-09-12 15:59:59','INSETH','4h','0.001639000000000','0.001486000000000','0.073889000334115','0.066991491456068','45.08175737285845','45.081757372858448','test'),('2019-10-05 19:59:59','2019-10-06 07:59:59','INSETH','4h','0.001079000000000','0.001055000000000','0.073889000334115','0.072245500790075','68.47914766831788','68.479147668317879','test'),('2019-10-06 11:59:59','2019-10-06 15:59:59','INSETH','4h','0.001072000000000','0.001063000000000','0.073889000334115','0.073268663577579','68.92630628182368','68.926306281823685','test'),('2019-10-06 19:59:59','2019-10-09 15:59:59','INSETH','4h','0.001073000000000','0.001087000000000','0.073889000334115','0.074853069303992','68.86206927690121','68.862069276901209','test'),('2019-10-09 19:59:59','2019-10-09 23:59:59','INSETH','4h','0.001113000000000','0.001100000000000','0.073889000334115','0.073025966188254','66.38724198932165','66.387241989321652','test'),('2019-10-12 19:59:59','2019-10-12 23:59:59','INSETH','4h','0.001105000000000','0.001101000000000','0.073889000334115','0.073621528839693','66.86787360553393','66.867873605533930','test'),('2019-10-13 15:59:59','2019-10-13 19:59:59','INSETH','4h','0.001094000000000','0.001076000000000','0.073889000334115','0.072673276379806','67.54021968383455','67.540219683834550','test'),('2019-10-19 19:59:59','2019-10-23 15:59:59','INSETH','4h','0.001202000000000','0.001120000000000','0.073889000334115','0.068848319778876','61.47171408828203','61.471714088282027','test'),('2019-10-24 19:59:59','2019-10-25 19:59:59','INSETH','4h','0.001169000000000','0.001141000000000','0.073889000334115','0.072119203918927','63.207014828156545','63.207014828156545','test'),('2019-10-25 23:59:59','2019-10-26 03:59:59','INSETH','4h','0.001168000000000','0.001076000000000','0.073889000334115','0.068068976335195','63.26113042304366','63.261130423043660','test'),('2019-10-28 11:59:59','2019-10-29 07:59:59','INSETH','4h','0.001183000000000','0.001183000000000','0.073889000334115','0.073889000334115','62.45900281835587','62.459002818355870','test'),('2019-10-29 11:59:59','2019-10-29 15:59:59','INSETH','4h','0.001194000000000','0.001103000000000','0.073889000334115','0.068257594110996','61.88358486944305','61.883584869443048','test'),('2019-11-19 07:59:59','2019-11-19 11:59:59','INSETH','4h','0.001022000000000','0.001022000000000','0.073889000334115','0.073889000334115','72.29843476919277','72.298434769192767','test'),('2019-11-19 19:59:59','2019-11-20 07:59:59','INSETH','4h','0.001037000000000','0.001044000000000','0.073889000334115','0.074387768899533','71.25265220261812','71.252652202618123','test'),('2019-11-20 11:59:59','2019-11-20 23:59:59','INSETH','4h','0.001059000000000','0.001030000000000','0.073889000334115','0.071865599947251','69.77242713325306','69.772427133253061','test'),('2019-11-21 03:59:59','2019-11-21 07:59:59','INSETH','4h','0.001037000000000','0.001022000000000','0.073889000334115','0.072820210551076','71.25265220261812','71.252652202618123','test'),('2019-11-21 23:59:59','2019-11-22 15:59:59','INSETH','4h','0.001047000000000','0.001032000000000','0.073889000334115','0.072830418667437','70.57211111185768','70.572111111857680','test'),('2019-11-22 19:59:59','2019-11-22 23:59:59','INSETH','4h','0.001037000000000','0.001051000000000','0.073889000334115','0.074886537464952','71.25265220261812','71.252652202618123','test'),('2019-11-23 15:59:59','2019-11-25 03:59:59','INSETH','4h','0.001062000000000','0.001029000000000','0.073889000334115','0.071593014448027','69.57532988146421','69.575329881464214','test'),('2019-11-26 03:59:59','2019-11-27 15:59:59','INSETH','4h','0.001081000000000','0.001090000000000','0.073889000334115','0.074504172399801','68.35245174293709','68.352451742937092','test'),('2019-11-27 19:59:59','2019-11-28 07:59:59','INSETH','4h','0.001091000000000','0.001077000000000','0.073889000334115','0.072940837176757','67.7259398112878','67.725939811287802','test'),('2019-11-28 11:59:59','2019-11-28 15:59:59','INSETH','4h','0.001094000000000','0.001082000000000','0.073889000334115','0.073078517697909','67.54021968383455','67.540219683834550','test'),('2019-11-29 19:59:59','2019-11-30 15:59:59','INSETH','4h','0.001101000000000','0.001074000000000','0.073889000334115','0.072077008500308','67.110808659505','67.110808659504997','test'),('2019-11-30 19:59:59','2019-12-01 15:59:59','INSETH','4h','0.001097000000000','0.001085000000000','0.073889000334115','0.073080734149968','67.35551534559252','67.355515345592522','test'),('2019-12-02 15:59:59','2019-12-05 15:59:59','INSETH','4h','0.001117000000000','0.001108000000000','0.073889000334115','0.073293654762936','66.14950790878693','66.149507908786930','test'),('2019-12-06 03:59:59','2019-12-10 03:59:59','INSETH','4h','0.001153000000000','0.001215000000000','0.073889000334115','0.077862216310451','64.08412865057676','64.084128650576758','test'),('2019-12-13 23:59:59','2019-12-22 03:59:59','INSETH','4h','0.001246000000000','0.001631000000000','0.073889000334115','0.096719871223870','59.30096335001204','59.300963350012040','test'),('2019-12-27 15:59:59','2019-12-29 15:59:59','INSETH','4h','0.001615000000000','0.001578000000000','0.073889000334115','0.072196187323364','45.75170299326006','45.751702993260061','test'),('2019-12-30 19:59:59','2020-01-01 15:59:59','INSETH','4h','0.001676000000000','0.001666000000000','0.073889000334115','0.073448135176990','44.08651571247911','44.086515712479112','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 21:26:31
