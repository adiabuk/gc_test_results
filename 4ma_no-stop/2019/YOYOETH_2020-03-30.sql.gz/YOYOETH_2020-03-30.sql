-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 07:59:59','2019-01-10 19:59:59','YOYOETH','4h','0.000102900000000','0.000100800000000','0.072144500000000','0.070672163265306','701.1127308066084','701.112730806608397','test'),('2019-01-11 07:59:59','2019-01-14 19:59:59','YOYOETH','4h','0.000100120000000','0.000104080000000','0.072144500000000','0.074997998002397','720.5803036356373','720.580303635637279','test'),('2019-01-14 23:59:59','2019-01-15 03:59:59','YOYOETH','4h','0.000106190000000','0.000104800000000','0.072489790316926','0.071540917461285','682.6423421878308','682.642342187830764','test'),('2019-01-15 15:59:59','2019-01-20 15:59:59','YOYOETH','4h','0.000116360000000','0.000121400000000','0.072489790316926','0.075629602479158','622.9786036174459','622.978603617445856','test'),('2019-01-20 23:59:59','2019-01-25 03:59:59','YOYOETH','4h','0.000128100000000','0.000137850000000','0.073037525143574','0.078596587361762','570.1602275064287','570.160227506428669','test'),('2019-01-26 15:59:59','2019-01-27 07:59:59','YOYOETH','4h','0.000143070000000','0.000136570000000','0.074427290698120','0.071045887262475','520.215913176211','520.215913176210961','test'),('2019-02-20 19:59:59','2019-02-21 23:59:59','YOYOETH','4h','0.000155000000000','0.000120720000000','0.074427290698120','0.057966855052110','480.17606902012903','480.176069020129034','test'),('2019-03-01 19:59:59','2019-03-02 07:59:59','YOYOETH','4h','0.000125000000000','0.000121590000000','0.074427290698120','0.072396914207875','595.41832558496','595.418325584960030','test'),('2019-03-02 11:59:59','2019-03-06 11:59:59','YOYOETH','4h','0.000122510000000','0.000127950000000','0.074427290698120','0.077732200186307','607.5201265049384','607.520126504938389','test'),('2019-03-10 11:59:59','2019-03-14 23:59:59','YOYOETH','4h','0.000133370000000','0.000143160000000','0.074427290698120','0.079890612104243','558.0512161514583','558.051216151458334','test'),('2019-03-15 03:59:59','2019-03-18 11:59:59','YOYOETH','4h','0.000143780000000','0.000147540000000','0.074427290698120','0.076373643549872','517.6470350404785','517.647035040478499','test'),('2019-03-26 15:59:59','2019-03-29 19:59:59','YOYOETH','4h','0.000161040000000','0.000152410000000','0.074427290698120','0.070438793935050','462.166484712618','462.166484712618001','test'),('2019-03-31 11:59:59','2019-04-02 19:59:59','YOYOETH','4h','0.000157210000000','0.000153990000000','0.074427290698120','0.072902859198547','473.42593154455824','473.425931544558239','test'),('2019-04-05 19:59:59','2019-04-06 03:59:59','YOYOETH','4h','0.000157000000000','0.000155710000000','0.074427290698120','0.073815754360537','474.0591764211465','474.059176421146503','test'),('2019-04-06 11:59:59','2019-04-06 15:59:59','YOYOETH','4h','0.000155150000000','0.000153320000000','0.074427290698120','0.073549418045993','479.71183176358363','479.711831763583632','test'),('2019-04-07 15:59:59','2019-04-07 23:59:59','YOYOETH','4h','0.000159240000000','0.000154900000000','0.074427290698120','0.072398815179219','467.3906725579','467.390672557900018','test'),('2019-04-15 19:59:59','2019-04-16 07:59:59','YOYOETH','4h','0.000199640000000','0.000150600000000','0.074427290698120','0.056144810554683','372.8075070032057','372.807507003205728','test'),('2019-04-16 19:59:59','2019-04-17 03:59:59','YOYOETH','4h','0.000151050000000','0.000146650000000','0.074427290698120','0.072259266341472','492.7328083291625','492.732808329162481','test'),('2019-05-22 19:59:59','2019-05-24 11:59:59','YOYOETH','4h','0.000114360000000','0.000095190000000','0.074427290698120','0.061951152514463','650.8157633623645','650.815763362364464','test'),('2019-05-27 07:59:59','2019-05-27 15:59:59','YOYOETH','4h','0.000103020000000','0.000091140000000','0.074427290698120','0.065844527996764','722.45477284139','722.454772841389968','test'),('2019-05-27 19:59:59','2019-05-27 23:59:59','YOYOETH','4h','0.000092710000000','0.000093820000000','0.074427290698120','0.075318395138579','802.796793205911','802.796793205910944','test'),('2019-05-28 07:59:59','2019-05-28 11:59:59','YOYOETH','4h','0.000096000000000','0.000094650000000','0.074427290698120','0.073380656922678','775.2842781054167','775.284278105416661','test'),('2019-05-29 15:59:59','2019-05-30 03:59:59','YOYOETH','4h','0.000098040000000','0.000091540000000','0.074427290698120','0.069492800800754','759.1522919024887','759.152291902488741','test'),('2019-06-02 23:59:59','2019-06-03 07:59:59','YOYOETH','4h','0.000096650000000','0.000094090000000','0.074427290698120','0.072455910830689','770.0702607151577','770.070260715157701','test'),('2019-06-03 11:59:59','2019-06-04 03:59:59','YOYOETH','4h','0.000098880000000','0.000093820000000','0.074427290698120','0.070618612594029','752.7031826266181','752.703182626618059','test'),('2019-06-04 07:59:59','2019-06-04 11:59:59','YOYOETH','4h','0.000094720000000','0.000095320000000','0.074427290698120','0.074898747353725','785.7610926744088','785.761092674408815','test'),('2019-06-06 07:59:59','2019-06-06 15:59:59','YOYOETH','4h','0.000095900000000','0.000095270000000','0.074427290698120','0.073938352292074','776.0927080095934','776.092708009593366','test'),('2019-06-06 19:59:59','2019-06-06 23:59:59','YOYOETH','4h','0.000095360000000','0.000094000000000','0.074427290698120','0.073365827659640','780.4875282940436','780.487528294043614','test'),('2019-06-07 03:59:59','2019-06-07 07:59:59','YOYOETH','4h','0.000095070000000','0.000097040000000','0.074427290698120','0.075969541278485','782.8683149060693','782.868314906069259','test'),('2019-06-07 11:59:59','2019-06-12 23:59:59','YOYOETH','4h','0.000098950000000','0.000100490000000','0.074427290698120','0.075585633575079','752.170699324103','752.170699324102998','test'),('2019-06-13 23:59:59','2019-06-14 11:59:59','YOYOETH','4h','0.000107110000000','0.000102640000000','0.074427290698120','0.071321231605406','694.867805976286','694.867805976286036','test'),('2019-06-16 15:59:59','2019-06-22 19:59:59','YOYOETH','4h','0.000106490000000','0.000127070000000','0.074427290698120','0.088810928998123','698.9134256561179','698.913425656117852','test'),('2019-07-04 19:59:59','2019-07-06 15:59:59','YOYOETH','4h','0.000113140000000','0.000107170000000','0.074427290698120','0.070500024254176','657.8335751999292','657.833575199929214','test'),('2019-08-13 11:59:59','2019-08-13 15:59:59','YOYOETH','4h','0.000071810000000','0.000070400000000','0.074427290698120','0.072965899807097','1036.447440441721','1036.447440441721028','test'),('2019-08-21 23:59:59','2019-08-23 15:59:59','YOYOETH','4h','0.000073460000000','0.000068660000000','0.074427290698120','0.069564086296391','1013.1675836934386','1013.167583693438587','test'),('2019-08-24 07:59:59','2019-08-27 19:59:59','YOYOETH','4h','0.000071460000000','0.000080120000000','0.074427290698120','0.083446886800075','1041.523799301987','1041.523799301987083','test'),('2019-08-27 23:59:59','2019-08-28 07:59:59','YOYOETH','4h','0.000081060000000','0.000080600000000','0.074427290698120','0.074004930055125','918.1753108576363','918.175310857636305','test'),('2019-09-11 07:59:59','2019-09-11 19:59:59','YOYOETH','4h','0.000079340000000','0.000072500000000','0.074427290698120','0.068010821472318','938.0802961699018','938.080296169901771','test'),('2019-09-11 23:59:59','2019-09-12 11:59:59','YOYOETH','4h','0.000077890000000','0.000074000000000','0.074427290698120','0.070710226109396','955.5435960729234','955.543596072923378','test'),('2019-09-12 15:59:59','2019-09-13 03:59:59','YOYOETH','4h','0.000075090000000','0.000072220000000','0.074427290698120','0.071582619978935','991.1744666149954','991.174466614995367','test'),('2019-09-13 11:59:59','2019-09-18 11:59:59','YOYOETH','4h','0.000078680000000','0.000088800000000','0.074427290698120','0.084000297585067','945.9492971291306','945.949297129130628','test'),('2019-09-23 03:59:59','2019-09-24 07:59:59','YOYOETH','4h','0.000085920000000','0.000085510000000','0.074427290698120','0.074072132537200','866.2394168775605','866.239416877560529','test'),('2019-09-24 11:59:59','2019-09-24 15:59:59','YOYOETH','4h','0.000085550000000','0.000081590000000','0.074427290698120','0.070982146675156','869.9858643848041','869.985864384804131','test'),('2019-10-01 11:59:59','2019-10-04 15:59:59','YOYOETH','4h','0.000088440000000','0.000086980000000','0.074427290698120','0.073198617649508','841.5568826110357','841.556882611035689','test'),('2019-10-07 15:59:59','2019-10-08 11:59:59','YOYOETH','4h','0.000090350000000','0.000086510000000','0.074427290698120','0.071264027872655','823.7663607982291','823.766360798229130','test'),('2019-10-08 15:59:59','2019-10-08 19:59:59','YOYOETH','4h','0.000087290000000','0.000088290000000','0.074427290698120','0.075279934651587','852.6439534668347','852.643953466834660','test'),('2019-10-08 23:59:59','2019-10-09 15:59:59','YOYOETH','4h','0.000088370000000','0.000078170000000','0.074427290698120','0.065836610997760','842.2235000353062','842.223500035306188','test'),('2019-10-23 03:59:59','2019-10-23 07:59:59','YOYOETH','4h','0.000077870000000','0.000077250000000','0.049618193798747','0.049223134338682','637.1926775233936','637.192677523393627','test'),('2019-11-01 07:59:59','2019-11-04 11:59:59','YOYOETH','4h','0.000076250000000','0.000074940000000','0.054163826573174','0.053233274274015','710.3452665334231','710.345266533423114','test'),('2019-11-18 11:59:59','2019-11-21 03:59:59','YOYOETH','4h','0.000073250000000','0.000076170000000','0.054163826573174','0.056322985257047','739.4379054358225','739.437905435822472','test'),('2019-11-23 19:59:59','2019-11-24 07:59:59','YOYOETH','4h','0.000078910000000','0.000074730000000','0.054470978169352','0.051585555678566','690.2924619104298','690.292461910429779','test'),('2019-11-24 11:59:59','2019-11-24 15:59:59','YOYOETH','4h','0.000075360000000','0.000073950000000','0.054470978169352','0.053451815759336','722.8102198693207','722.810219869320690','test'),('2019-11-24 19:59:59','2019-11-25 07:59:59','YOYOETH','4h','0.000076630000000','0.000080200000000','0.054470978169352','0.057008644775963','710.8309822439253','710.830982243925291','test'),('2019-11-25 15:59:59','2019-11-27 19:59:59','YOYOETH','4h','0.000079990000000','0.000076860000000','0.054470978169352','0.052339534718045','680.9723486604826','680.972348660482567','test'),('2019-11-28 19:59:59','2019-12-02 11:59:59','YOYOETH','4h','0.000085280000000','0.000085930000000','0.054470978169352','0.054886153307838','638.7309822860226','638.730982286022595','test'),('2019-12-02 15:59:59','2019-12-02 19:59:59','YOYOETH','4h','0.000086510000000','0.000085200000000','0.054470978169352','0.053646137325498','629.6494991255578','629.649499125557782','test'),('2019-12-06 07:59:59','2019-12-06 15:59:59','YOYOETH','4h','0.000087490000000','0.000085820000000','0.054470978169352','0.053431241816137','622.5966186918733','622.596618691873346','test'),('2019-12-06 19:59:59','2019-12-06 23:59:59','YOYOETH','4h','0.000089090000000','0.000086420000000','0.054470978169352','0.052838499645251','611.415177565967','611.415177565967042','test'),('2019-12-07 11:59:59','2019-12-09 03:59:59','YOYOETH','4h','0.000087470000000','0.000086930000000','0.054470978169352','0.054134699122691','622.7389752984109','622.738975298410878','test'),('2019-12-29 03:59:59','2019-12-29 07:59:59','YOYOETH','4h','0.000078350000000','0.000077050000000','0.054470978169352','0.053567184019765','695.2262689132356','695.226268913235572','test'),('2019-12-29 11:59:59','2019-12-29 15:59:59','YOYOETH','4h','0.000078950000000','0.000076630000000','0.054470978169352','0.052870311046453','689.9427253876124','689.942725387612427','test'),('2019-12-29 19:59:59','2019-12-29 23:59:59','YOYOETH','4h','0.000077740000000','0.000075880000000','0.054470978169352','0.053167710618606','700.6814788957037','700.681478895703663','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  5:18:55
