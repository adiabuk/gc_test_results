-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 15:59:59','2019-01-14 19:59:59','SNGLSETH','4h','0.000074450000000','0.000076390000000','0.072144500000000','0.074024423841504','969.032907991941','969.032907991940988','test'),('2019-01-15 11:59:59','2019-01-21 15:59:59','SNGLSETH','4h','0.000079600000000','0.000098510000000','0.072614480960376','0.089864981399581','912.2422231203014','912.242223120301446','test'),('2019-01-21 19:59:59','2019-01-22 03:59:59','SNGLSETH','4h','0.000099620000000','0.000098520000000','0.076927106070177','0.076077680084660','772.2054413790128','772.205441379012768','test'),('2019-01-22 11:59:59','2019-01-30 15:59:59','SNGLSETH','4h','0.000101520000000','0.000124520000000','0.076927106070177','0.094355429943444','757.7532118811761','757.753211881176071','test'),('2019-02-22 15:59:59','2019-02-23 11:59:59','SNGLSETH','4h','0.000111780000000','0.000092000000000','0.081071830542115','0.066725786454416','725.2802875479938','725.280287547993794','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','SNGLSETH','4h','0.000092140000000','0.000088830000000','0.081071830542115','0.078159438973910','879.8766067084329','879.876606708432860','test'),('2019-02-26 11:59:59','2019-02-27 11:59:59','SNGLSETH','4h','0.000095720000000','0.000092230000000','0.081071830542115','0.078115910268484','846.9685597797221','846.968559779722113','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','SNGLSETH','4h','0.000092240000000','0.000092730000000','0.081071830542115','0.081502502668802','878.9227075250976','878.922707525097621','test'),('2019-02-28 23:59:59','2019-03-06 07:59:59','SNGLSETH','4h','0.000095390000000','0.000104110000000','0.081071830542115','0.088482946616413','849.8986323735717','849.898632373571672','test'),('2019-03-07 15:59:59','2019-03-11 15:59:59','SNGLSETH','4h','0.000112700000000','0.000124370000000','0.081071830542115','0.089466757449182','719.359632139441','719.359632139441032','test'),('2019-03-13 03:59:59','2019-03-14 11:59:59','SNGLSETH','4h','0.000131310000000','0.000127170000000','0.081071830542115','0.078515761861555','617.4078938551139','617.407893855113912','test'),('2019-03-22 23:59:59','2019-03-23 03:59:59','SNGLSETH','4h','0.000121150000000','0.000119180000000','0.081071830542115','0.079753534989759','669.1855595717293','669.185559571729300','test'),('2019-03-23 07:59:59','2019-03-23 15:59:59','SNGLSETH','4h','0.000119210000000','0.000120810000000','0.081071830542115','0.082159951747277','680.0757532263652','680.075753226365237','test'),('2019-03-24 03:59:59','2019-03-25 07:59:59','SNGLSETH','4h','0.000121070000000','0.000120150000000','0.081071830542115','0.080455773020857','669.6277404981829','669.627740498182902','test'),('2019-03-25 15:59:59','2019-03-25 23:59:59','SNGLSETH','4h','0.000120620000000','0.000120430000000','0.081071830542115','0.080944126614052','672.1259371755514','672.125937175551371','test'),('2019-03-26 03:59:59','2019-03-26 07:59:59','SNGLSETH','4h','0.000122560000000','0.000120780000000','0.081071830542115','0.079894383917074','661.4868680002857','661.486868000285654','test'),('2019-03-26 11:59:59','2019-03-26 15:59:59','SNGLSETH','4h','0.000122520000000','0.000130910000000','0.081071830542115','0.086623517272839','661.7028284534362','661.702828453436155','test'),('2019-03-26 23:59:59','2019-03-29 03:59:59','SNGLSETH','4h','0.000139020000000','0.000131690000000','0.081071830542115','0.076797218846865','583.1666705662135','583.166670566213497','test'),('2019-03-29 07:59:59','2019-03-29 11:59:59','SNGLSETH','4h','0.000134090000000','0.000126570000000','0.081071830542115','0.076525181532668','604.607581043441','604.607581043440973','test'),('2019-03-29 15:59:59','2019-03-29 19:59:59','SNGLSETH','4h','0.000132950000000','0.000130430000000','0.081071830542115','0.079535155002693','609.791880722941','609.791880722940959','test'),('2019-03-31 11:59:59','2019-04-01 23:59:59','SNGLSETH','4h','0.000135900000000','0.000131880000000','0.081071830542115','0.078673679263386','596.5550444600074','596.555044460007366','test'),('2019-04-19 15:59:59','2019-04-21 11:59:59','SNGLSETH','4h','0.000113800000000','0.000109640000000','0.081071830542115','0.078108220567992','712.4062437795694','712.406243779569422','test'),('2019-04-21 15:59:59','2019-04-22 11:59:59','SNGLSETH','4h','0.000111350000000','0.000110350000000','0.081071830542115','0.080343749441602','728.0811005129323','728.081100512932267','test'),('2019-04-22 15:59:59','2019-04-23 03:59:59','SNGLSETH','4h','0.000112680000000','0.000109590000000','0.081071830542115','0.078848614741839','719.4873140052805','719.487314005280496','test'),('2019-04-23 07:59:59','2019-04-23 11:59:59','SNGLSETH','4h','0.000110830000000','0.000110500000000','0.081071830542115','0.080830436478424','731.4971627006678','731.497162700667786','test'),('2019-05-23 03:59:59','2019-05-24 15:59:59','SNGLSETH','4h','0.000078570000000','0.000068210000000','0.081071830542115','0.070381946815294','1031.8420585734377','1031.842058573437725','test'),('2019-05-31 19:59:59','2019-06-01 03:59:59','SNGLSETH','4h','0.000069810000000','0.000067600000000','0.081071830542115','0.078505310767039','1161.3211651928807','1161.321165192880699','test'),('2019-06-02 15:59:59','2019-06-03 07:59:59','SNGLSETH','4h','0.000068530000000','0.000068680000000','0.081071830542115','0.081249282381912','1183.012265316139','1183.012265316139064','test'),('2019-06-03 11:59:59','2019-06-03 15:59:59','SNGLSETH','4h','0.000070150000000','0.000069170000000','0.081071830542115','0.079939251868825','1155.6925237650037','1155.692523765003671','test'),('2019-06-03 19:59:59','2019-06-04 07:59:59','SNGLSETH','4h','0.000070430000000','0.000068530000000','0.081071830542115','0.078884744385221','1151.097977312438','1151.097977312437934','test'),('2019-06-05 19:59:59','2019-06-05 23:59:59','SNGLSETH','4h','0.000069610000000','0.000068800000000','0.081071830542115','0.080128457711500','1164.6578155741272','1164.657815574127198','test'),('2019-06-06 03:59:59','2019-06-06 19:59:59','SNGLSETH','4h','0.000070030000000','0.000068500000000','0.081071830542115','0.079300591062900','1157.6728622321148','1157.672862232114767','test'),('2019-06-07 03:59:59','2019-06-07 07:59:59','SNGLSETH','4h','0.000068940000000','0.000071170000000','0.081071830542115','0.083694258481032','1175.9766542227298','1175.976654222729849','test'),('2019-06-07 11:59:59','2019-06-12 15:59:59','SNGLSETH','4h','0.000071390000000','0.000073350000000','0.081071830542115','0.083297643511194','1135.6188617749685','1135.618861774968536','test'),('2019-07-15 23:59:59','2019-07-16 19:59:59','SNGLSETH','4h','0.000044390000000','0.000044780000000','0.081071830542115','0.081784108395492','1826.353470198581','1826.353470198580908','test'),('2019-07-21 23:59:59','2019-07-22 03:59:59','SNGLSETH','4h','0.000044980000000','0.000043940000000','0.081071830542115','0.079197337350390','1802.3972997357716','1802.397299735771639','test'),('2019-07-22 07:59:59','2019-07-24 07:59:59','SNGLSETH','4h','0.000044770000000','0.000044220000000','0.081071830542115','0.080075862107937','1810.851698506031','1810.851698506030971','test'),('2019-07-26 07:59:59','2019-08-01 19:59:59','SNGLSETH','4h','0.000045440000000','0.000046160000000','0.081071830542115','0.082356419406339','1784.1512003106295','1784.151200310629520','test'),('2019-08-22 11:59:59','2019-08-23 15:59:59','SNGLSETH','4h','0.000040660000000','0.000039480000000','0.081071830542115','0.078719032705428','1993.8964717686918','1993.896471768691754','test'),('2019-08-23 23:59:59','2019-08-27 23:59:59','SNGLSETH','4h','0.000039530000000','0.000043000000000','0.081071830542115','0.088188431907689','2050.893765295092','2050.893765295092180','test'),('2019-08-31 15:59:59','2019-08-31 19:59:59','SNGLSETH','4h','0.000042800000000','0.000042700000000','0.081071830542115','0.080882410377297','1894.2016481802573','1894.201648180257280','test'),('2019-09-01 11:59:59','2019-09-01 19:59:59','SNGLSETH','4h','0.000042910000000','0.000041390000000','0.081071830542115','0.078200024845913','1889.345852764274','1889.345852764274014','test'),('2019-09-02 07:59:59','2019-09-02 15:59:59','SNGLSETH','4h','0.000042520000000','0.000040840000000','0.081071830542115','0.077868616165098','1906.675224414746','1906.675224414746026','test'),('2019-09-10 23:59:59','2019-09-11 07:59:59','SNGLSETH','4h','0.000040060000000','0.000039320000000','0.081071830542115','0.079574248050823','2023.7601233678233','2023.760123367823326','test'),('2019-09-11 11:59:59','2019-09-11 19:59:59','SNGLSETH','4h','0.000039880000000','0.000039040000000','0.081071830542115','0.079364199206724','2032.8944468935558','2032.894446893555823','test'),('2019-09-11 23:59:59','2019-09-12 03:59:59','SNGLSETH','4h','0.000039770000000','0.000038300000000','0.081071830542115','0.078075210202741','2038.5172376694745','2038.517237669474525','test'),('2019-09-19 15:59:59','2019-09-19 19:59:59','SNGLSETH','4h','0.000040500000000','0.000041720000000','0.081071830542115','0.083513994326347','2001.773593632469','2001.773593632469101','test'),('2019-09-20 03:59:59','2019-09-24 07:59:59','SNGLSETH','4h','0.000040180000000','0.000046420000000','0.081071830542115','0.093662378640243','2017.716041366725','2017.716041366724994','test'),('2019-09-26 11:59:59','2019-09-29 19:59:59','SNGLSETH','4h','0.000052010000000','0.000051490000000','0.081071830542115','0.080261268114084','1558.7739000598924','1558.773900059892412','test'),('2019-10-01 15:59:59','2019-10-05 23:59:59','SNGLSETH','4h','0.000055740000000','0.000058600000000','0.081071830542115','0.085231597950627','1454.4641288502871','1454.464128850287125','test'),('2019-10-09 19:59:59','2019-10-10 11:59:59','SNGLSETH','4h','0.000061030000000','0.000059480000000','0.081071830542115','0.079012821246027','1328.3930942506145','1328.393094250614467','test'),('2019-10-10 19:59:59','2019-10-10 23:59:59','SNGLSETH','4h','0.000059670000000','0.000059310000000','0.081071830542115','0.080582709392540','1358.66985993154','1358.669859931540032','test'),('2019-10-12 11:59:59','2019-10-12 15:59:59','SNGLSETH','4h','0.000059970000000','0.000058950000000','0.081071830542115','0.079692919967612','1351.873112258046','1351.873112258045921','test'),('2019-10-12 19:59:59','2019-10-13 15:59:59','SNGLSETH','4h','0.000059480000000','0.000058610000000','0.081071830542115','0.079886011904394','1363.0099284148455','1363.009928414845490','test'),('2019-10-13 19:59:59','2019-10-14 07:59:59','SNGLSETH','4h','0.000062930000000','0.000061070000000','0.081071830542115','0.078675618801954','1288.2858818070079','1288.285881807007854','test'),('2019-10-14 11:59:59','2019-10-15 19:59:59','SNGLSETH','4h','0.000063630000000','0.000059320000000','0.081071830542115','0.075580402133557','1274.113319850935','1274.113319850935113','test'),('2019-10-23 11:59:59','2019-10-23 15:59:59','SNGLSETH','4h','0.000058950000000','0.000056300000000','0.081071830542115','0.077427380144547','1375.2643009688718','1375.264300968871794','test'),('2019-11-12 15:59:59','2019-11-14 11:59:59','SNGLSETH','4h','0.000054000000000','0.000051770000000','0.081071830542115','0.077723864206765','1501.3301952243519','1501.330195224351883','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:14:48
