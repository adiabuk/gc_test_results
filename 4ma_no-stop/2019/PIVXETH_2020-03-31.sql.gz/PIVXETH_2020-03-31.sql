-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 07:59:59','2019-01-10 11:59:59','PIVXETH','4h','0.005969000000000','0.005922000000000','0.072144500000000','0.071576433070866','12.086530407103366','12.086530407103366','test'),('2019-01-11 11:59:59','2019-01-12 11:59:59','PIVXETH','4h','0.006025000000000','0.005894000000000','0.072144500000000','0.070575880995851','11.974190871369295','11.974190871369295','test'),('2019-01-12 15:59:59','2019-01-14 15:59:59','PIVXETH','4h','0.005983000000000','0.005918000000000','0.072144500000000','0.071360713855925','12.058248370382753','12.058248370382753','test'),('2019-01-15 19:59:59','2019-01-20 11:59:59','PIVXETH','4h','0.006240000000000','0.006300000000000','0.072144500000000','0.072838197115385','11.56161858974359','11.561618589743590','test'),('2019-01-23 15:59:59','2019-01-26 07:59:59','PIVXETH','4h','0.006413000000000','0.006580000000000','0.072144500000000','0.074023204428505','11.249727116794011','11.249727116794011','test'),('2019-01-30 03:59:59','2019-01-30 15:59:59','PIVXETH','4h','0.006700000000000','0.006409000000000','0.072144500000000','0.069011059776119','10.767835820895522','10.767835820895522','test'),('2019-03-02 03:59:59','2019-03-06 03:59:59','PIVXETH','4h','0.005564000000000','0.005727000000000','0.072144500000000','0.074258007099209','12.966301222142343','12.966301222142343','test'),('2019-03-10 15:59:59','2019-03-15 15:59:59','PIVXETH','4h','0.005783000000000','0.006250000000000','0.072144500000000','0.077970452187446','12.475272349991354','12.475272349991354','test'),('2019-03-23 19:59:59','2019-03-25 19:59:59','PIVXETH','4h','0.006125000000000','0.006123000000000','0.073258987132327','0.073235065830406','11.960650960379837','11.960650960379837','test'),('2019-03-26 19:59:59','2019-03-30 03:59:59','PIVXETH','4h','0.006338000000000','0.006253000000000','0.073258987132327','0.072276498349391','11.558691563951877','11.558691563951877','test'),('2019-03-31 03:59:59','2019-04-02 07:59:59','PIVXETH','4h','0.006723000000000','0.006609000000000','0.073258987132327','0.072016755311252','10.896770360304476','10.896770360304476','test'),('2019-04-02 11:59:59','2019-04-02 23:59:59','PIVXETH','4h','0.007346000000000','0.006333000000000','0.073258987132327','0.063156706440107','9.972636418775796','9.972636418775796','test'),('2019-05-25 15:59:59','2019-05-26 19:59:59','PIVXETH','4h','0.002868000000000','0.002739000000000','0.073258987132327','0.069963865326166','25.543579892722104','25.543579892722104','test'),('2019-06-08 19:59:59','2019-06-12 19:59:59','PIVXETH','4h','0.002799000000000','0.002881000000000','0.073258987132327','0.075405195401298','26.173271572821363','26.173271572821363','test'),('2019-06-19 19:59:59','2019-06-20 07:59:59','PIVXETH','4h','0.002897000000000','0.002789000000000','0.073258987132327','0.070527896138095','25.287879576226096','25.287879576226096','test'),('2019-07-06 11:59:59','2019-07-07 23:59:59','PIVXETH','4h','0.002355000000000','0.002233000000000','0.073258987132327','0.069463829412521','31.10785016234692','31.107850162346921','test'),('2019-07-17 19:59:59','2019-07-17 23:59:59','PIVXETH','4h','0.002104000000000','0.002085000000000','0.073258987132327','0.072597427837881','34.81891023399572','34.818910233995723','test'),('2019-07-18 07:59:59','2019-07-18 15:59:59','PIVXETH','4h','0.002165000000000','0.002069000000000','0.073258987132327','0.070010551675189','33.83786934518568','33.837869345185680','test'),('2019-07-18 19:59:59','2019-07-18 23:59:59','PIVXETH','4h','0.002141000000000','0.002084000000000','0.073258987132327','0.071308607745805','34.21718221967632','34.217182219676317','test'),('2019-07-19 03:59:59','2019-07-21 19:59:59','PIVXETH','4h','0.002132000000000','0.002141000000000','0.073258987132327','0.073568241768439','34.361626234674944','34.361626234674944','test'),('2019-07-22 07:59:59','2019-07-24 23:59:59','PIVXETH','4h','0.002241000000000','0.002192000000000','0.073258987132327','0.071657161889362','32.69031108091343','32.690311080913432','test'),('2019-07-26 03:59:59','2019-07-27 23:59:59','PIVXETH','4h','0.002263000000000','0.002257000000000','0.073258987132327','0.073064752080275','32.372508675354396','32.372508675354396','test'),('2019-07-28 15:59:59','2019-07-30 11:59:59','PIVXETH','4h','0.002286000000000','0.002249000000000','0.073258987132327','0.072073255494577','32.04680102026553','32.046801020265526','test'),('2019-08-21 23:59:59','2019-08-26 03:59:59','PIVXETH','4h','0.001770000000000','0.001795000000000','0.073258987132327','0.074293718588998','41.38925826685141','41.389258266851407','test'),('2019-08-29 11:59:59','2019-08-30 15:59:59','PIVXETH','4h','0.001831000000000','0.001866000000000','0.073258987132327','0.074659350075872','40.010369815580006','40.010369815580006','test'),('2019-08-31 03:59:59','2019-08-31 23:59:59','PIVXETH','4h','0.001968000000000','0.001834000000000','0.073258987132327','0.068270824390593','37.225095087564526','37.225095087564526','test'),('2019-09-01 03:59:59','2019-09-01 07:59:59','PIVXETH','4h','0.001837000000000','0.001840000000000','0.073258987132327','0.073378626196778','39.879688150422965','39.879688150422965','test'),('2019-09-02 11:59:59','2019-09-03 15:59:59','PIVXETH','4h','0.001894000000000','0.001854000000000','0.073258987132327','0.071711806833862','38.67950746162988','38.679507461629882','test'),('2019-09-03 19:59:59','2019-09-03 23:59:59','PIVXETH','4h','0.001863000000000','0.001936000000000','0.073258987132327','0.076129575463331','39.32312782196833','39.323127821968328','test'),('2019-09-04 03:59:59','2019-09-07 19:59:59','PIVXETH','4h','0.001944000000000','0.001939000000000','0.073258987132327','0.073070563811513','37.68466416271965','37.684664162719649','test'),('2019-10-02 15:59:59','2019-10-05 15:59:59','PIVXETH','4h','0.001332000000000','0.001307000000000','0.073258987132327','0.071884006142606','54.99923958883408','54.999239588834079','test'),('2019-10-06 19:59:59','2019-10-10 11:59:59','PIVXETH','4h','0.001353000000000','0.001369000000000','0.073258987132327','0.074125316618001','54.14559285463931','54.145592854639311','test'),('2019-10-12 15:59:59','2019-10-13 23:59:59','PIVXETH','4h','0.001436000000000','0.001421000000000','0.073258987132327','0.072493747016042','51.016007752316845','51.016007752316845','test'),('2019-10-22 03:59:59','2019-10-23 03:59:59','PIVXETH','4h','0.001440000000000','0.001284000000000','0.073258987132327','0.065322596859658','50.87429661967152','50.874296619671519','test'),('2019-11-02 19:59:59','2019-11-05 07:59:59','PIVXETH','4h','0.001373000000000','0.001325000000000','0.073258987132327','0.070697857210731','53.35687336658921','53.356873366589213','test'),('2019-11-14 23:59:59','2019-11-17 11:59:59','PIVXETH','4h','0.001321000000000','0.001299000000000','0.073258987132327','0.072038928300449','55.45721963083043','55.457219630830430','test'),('2019-11-21 03:59:59','2019-11-21 11:59:59','PIVXETH','4h','0.001319000000000','0.001314000000000','0.073258987132327','0.072981280585199','55.54130942557012','55.541309425570120','test'),('2019-11-21 19:59:59','2019-11-22 07:59:59','PIVXETH','4h','0.001288000000000','0.001274000000000','0.073258987132327','0.072462693793932','56.87809559963276','56.878095599632758','test'),('2019-11-22 23:59:59','2019-11-23 07:59:59','PIVXETH','4h','0.001322000000000','0.001286000000000','0.073258987132327','0.071264037407090','55.41527014548184','55.415270145481841','test'),('2019-11-23 11:59:59','2019-11-23 15:59:59','PIVXETH','4h','0.001304000000000','0.001297000000000','0.073258987132327','0.072865725698334','56.18020485607898','56.180204856078980','test'),('2019-11-23 23:59:59','2019-11-24 15:59:59','PIVXETH','4h','0.001314000000000','0.001322000000000','0.073258987132327','0.073705008362965','55.75265382977701','55.752653829777010','test'),('2019-11-24 23:59:59','2019-11-25 03:59:59','PIVXETH','4h','0.001327000000000','0.001284000000000','0.073258987132327','0.070885108875590','55.20647108690806','55.206471086908060','test'),('2019-11-26 07:59:59','2019-11-28 23:59:59','PIVXETH','4h','0.001543000000000','0.001516000000000','0.073258987132327','0.071977073553213','47.47828070792416','47.478280707924164','test'),('2019-11-30 03:59:59','2019-11-30 11:59:59','PIVXETH','4h','0.001595000000000','0.001485000000000','0.073258987132327','0.068206643192167','45.93039945600438','45.930399456004380','test'),('2019-11-30 15:59:59','2019-11-30 19:59:59','PIVXETH','4h','0.001539000000000','0.001515000000000','0.073258987132327','0.072116546787183','47.60168104764587','47.601681047645869','test'),('2019-12-07 03:59:59','2019-12-07 07:59:59','PIVXETH','4h','0.001500000000000','0.001480000000000','0.073258987132327','0.072282200637229','48.839324754884665','48.839324754884665','test'),('2019-12-07 11:59:59','2019-12-09 03:59:59','PIVXETH','4h','0.001493000000000','0.001480000000000','0.073258987132327','0.072621099099695','49.06831020249631','49.068310202496313','test'),('2019-12-09 07:59:59','2019-12-09 11:59:59','PIVXETH','4h','0.001501000000000','0.001481000000000','0.073258987132327','0.072282851394388','48.80678689695336','48.806786896953362','test'),('2019-12-09 15:59:59','2019-12-10 03:59:59','PIVXETH','4h','0.001575000000000','0.001471000000000','0.073258987132327','0.068421568299462','46.51364262369968','46.513642623699681','test'),('2019-12-13 19:59:59','2019-12-14 19:59:59','PIVXETH','4h','0.001542000000000','0.001558000000000','0.073258987132327','0.074019132264699','47.50907077323411','47.509070773234107','test'),('2019-12-15 03:59:59','2019-12-16 07:59:59','PIVXETH','4h','0.001547000000000','0.001515000000000','0.073258987132327','0.071743610540062','47.35551850829153','47.355518508291532','test'),('2019-12-16 19:59:59','2019-12-22 15:59:59','PIVXETH','4h','0.001611000000000','0.001700000000000','0.073258987132327','0.077306193746093','45.47423161534885','45.474231615348849','test'),('2019-12-24 11:59:59','2019-12-28 23:59:59','PIVXETH','4h','0.001755000000000','0.001782000000000','0.073258987132327','0.074386048472824','41.74301261101253','41.743012611012531','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  2:35:06
