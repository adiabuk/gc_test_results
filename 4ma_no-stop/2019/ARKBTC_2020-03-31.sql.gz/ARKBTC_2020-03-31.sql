-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 19:59:59','2019-01-07 07:59:59','ARKBTC','4h','0.000106600000000','0.000111900000000','0.001467500000000','0.001540462007505','13.76641651031895','13.766416510318949','test'),('2019-01-09 19:59:59','2019-01-10 19:59:59','ARKBTC','4h','0.000116200000000','0.000113100000000','0.001485740501876','0.001446103707076','12.786062838866178','12.786062838866178','test'),('2019-01-10 23:59:59','2019-01-11 07:59:59','ARKBTC','4h','0.000113300000000','0.000113900000000','0.001485740501876','0.001493608501003','13.113331878870255','13.113331878870255','test'),('2019-01-18 07:59:59','2019-01-20 15:59:59','ARKBTC','4h','0.000110600000000','0.000110200000000','0.001485740501876','0.001480367118506','13.433458425641952','13.433458425641952','test'),('2019-01-22 03:59:59','2019-01-22 23:59:59','ARKBTC','4h','0.000114000000000','0.000112200000000','0.001485740501876','0.001462281441320','13.032811419964911','13.032811419964911','test'),('2019-01-25 03:59:59','2019-01-25 19:59:59','ARKBTC','4h','0.000115200000000','0.000114000000000','0.001485740501876','0.001470264038315','12.897052967673611','12.897052967673611','test'),('2019-01-27 07:59:59','2019-01-28 07:59:59','ARKBTC','4h','0.000115700000000','0.000113300000000','0.001485740501876','0.001454921338484','12.841318080172861','12.841318080172861','test'),('2019-01-28 11:59:59','2019-01-28 15:59:59','ARKBTC','4h','0.000116100000000','0.000111600000000','0.001485740501876','0.001428153660718','12.797075812885442','12.797075812885442','test'),('2019-01-30 15:59:59','2019-01-31 11:59:59','ARKBTC','4h','0.000116100000000','0.000110800000000','0.001485740501876','0.001417916000068','12.797075812885442','12.797075812885442','test'),('2019-02-03 23:59:59','2019-02-04 07:59:59','ARKBTC','4h','0.000114500000000','0.000112100000000','0.001485740501876','0.001454598342885','12.975899579703055','12.975899579703055','test'),('2019-02-09 19:59:59','2019-02-10 07:59:59','ARKBTC','4h','0.000114100000000','0.000111300000000','0.001485740501876','0.001449280612259','13.02138914878177','13.021389148781770','test'),('2019-02-10 11:59:59','2019-02-13 03:59:59','ARKBTC','4h','0.000141500000000','0.000134300000000','0.001485740501876','0.001410140985173','10.499932875448764','10.499932875448764','test'),('2019-02-13 07:59:59','2019-02-14 15:59:59','ARKBTC','4h','0.000148800000000','0.000137500000000','0.001485740501876','0.001372912090107','9.984815200779568','9.984815200779568','test'),('2019-02-17 15:59:59','2019-02-17 23:59:59','ARKBTC','4h','0.000223900000000','0.000169800000000','0.001485740501876','0.001126747374804','6.635732478231353','6.635732478231353','test'),('2019-02-18 07:59:59','2019-02-21 03:59:59','ARKBTC','4h','0.000181900000000','0.000162500000000','0.001485740501876','0.001327283296068','8.16789720657504','8.167897206575040','test'),('2019-03-10 19:59:59','2019-03-11 07:59:59','ARKBTC','4h','0.000155400000000','0.000145900000000','0.001485740501876','0.001394913379818','9.56074969032175','9.560749690321749','test'),('2019-03-11 15:59:59','2019-03-16 11:59:59','ARKBTC','4h','0.000160200000000','0.000164800000000','0.001485740501876','0.001528402214165','9.274285280124843','9.274285280124843','test'),('2019-03-27 07:59:59','2019-03-30 03:59:59','ARKBTC','4h','0.000164600000000','0.000160700000000','0.001485740501876','0.001450537658879','9.026369999246658','9.026369999246658','test'),('2019-03-30 19:59:59','2019-04-02 03:59:59','ARKBTC','4h','0.000166700000000','0.000164800000000','0.001485740501876','0.001468806446966','8.912660479160166','8.912660479160166','test'),('2019-05-18 15:59:59','2019-05-18 19:59:59','ARKBTC','4h','0.000077400000000','0.000076400000000','0.001485740501876','0.001466544888157','19.195613719328165','19.195613719328165','test'),('2019-05-18 23:59:59','2019-05-19 03:59:59','ARKBTC','4h','0.000077700000000','0.000073500000000','0.001485740501876','0.001405430204477','19.1214993806435','19.121499380643499','test'),('2019-05-22 07:59:59','2019-05-23 11:59:59','ARKBTC','4h','0.000079500000000','0.000077000000000','0.001485740501876','0.001439019102446','18.688559772025158','18.688559772025158','test'),('2019-05-23 15:59:59','2019-05-24 19:59:59','ARKBTC','4h','0.000077900000000','0.000078600000000','0.001485740501876','0.001499091186745','19.072406956046212','19.072406956046212','test'),('2019-05-24 23:59:59','2019-05-26 11:59:59','ARKBTC','4h','0.000082800000000','0.000078100000000','0.001485740501876','0.001401404990296','17.943725868067634','17.943725868067634','test'),('2019-06-07 19:59:59','2019-06-11 03:59:59','ARKBTC','4h','0.000074900000000','0.000075500000000','0.001485740501876','0.001497642294948','19.836321787396525','19.836321787396525','test'),('2019-06-11 19:59:59','2019-06-12 15:59:59','ARKBTC','4h','0.000078700000000','0.000075200000000','0.001485740501876','0.001419665638387','18.87853242536213','18.878532425362131','test'),('2019-07-23 15:59:59','2019-07-27 23:59:59','ARKBTC','4h','0.000034200000000','0.000039100000000','0.001485740501876','0.001698609755069','43.442704733216374','43.442704733216374','test'),('2019-07-28 15:59:59','2019-07-30 11:59:59','ARKBTC','4h','0.000040700000000','0.000038400000000','0.001485740501876','0.001401779736414','36.50468063577395','36.504680635773951','test'),('2019-08-23 19:59:59','2019-08-25 23:59:59','ARKBTC','4h','0.000022600000000','0.000023000000000','0.001485740501876','0.001512036793945','65.74073017150442','65.740730171504424','test'),('2019-09-09 19:59:59','2019-09-11 15:59:59','ARKBTC','4h','0.000022800000000','0.000021400000000','0.001485740501876','0.001394510821936','65.16405709982456','65.164057099824561','test'),('2019-09-12 19:59:59','2019-09-13 03:59:59','ARKBTC','4h','0.000023000000000','0.000021900000000','0.001485740501876','0.001414683347438','64.59741312504347','64.597413125043474','test'),('2019-09-13 11:59:59','2019-09-14 19:59:59','ARKBTC','4h','0.000022500000000','0.000021400000000','0.001485740501876','0.001413104299562','66.03291119448888','66.032911194488875','test'),('2019-09-18 23:59:59','2019-09-19 03:59:59','ARKBTC','4h','0.000022400000000','0.000021790000000','0.001485740501876','0.001445280604280','66.32770097660715','66.327700976607147','test'),('2019-09-19 11:59:59','2019-09-19 23:59:59','ARKBTC','4h','0.000021800000000','0.000021850000000','0.000990493667917','0.000992765442385','45.43548935400611','45.435489354006108','test'),('2019-09-20 03:59:59','2019-09-22 03:59:59','ARKBTC','4h','0.000022070000000','0.000021670000000','0.001111894898164','0.001091742747767','50.38037599292029','50.380375992920293','test'),('2019-09-22 19:59:59','2019-09-22 23:59:59','ARKBTC','4h','0.000022690000000','0.000022310000000','0.001111894898164','0.001093273476335','49.003741655531066','49.003741655531066','test'),('2019-09-23 07:59:59','2019-09-23 15:59:59','ARKBTC','4h','0.000022330000000','0.000022160000000','0.001111894898164','0.001103429957157','49.793770629825346','49.793770629825346','test'),('2019-10-03 07:59:59','2019-10-03 15:59:59','ARKBTC','4h','0.000021430000000','0.000021080000000','0.001111894898164','0.001093735158810','51.88496958301447','51.884969583014467','test'),('2019-10-03 19:59:59','2019-10-09 15:59:59','ARKBTC','4h','0.000021400000000','0.000021510000000','0.001111894898164','0.001117610245771','51.95770552168224','51.957705521682243','test'),('2019-10-12 03:59:59','2019-10-15 19:59:59','ARKBTC','4h','0.000023130000000','0.000024530000000','0.001111894898164','0.001179195064936','48.071547694076955','48.071547694076955','test'),('2019-10-17 15:59:59','2019-10-19 07:59:59','ARKBTC','4h','0.000025410000000','0.000024510000000','0.001113799213612','0.001074349418561','43.833105612426245','43.833105612426245','test'),('2019-11-03 07:59:59','2019-11-04 23:59:59','ARKBTC','4h','0.000025080000000','0.000022410000000','0.001113799213612','0.000995224895416','44.409857002073366','44.409857002073366','test'),('2019-11-05 23:59:59','2019-11-10 19:59:59','ARKBTC','4h','0.000023430000000','0.000023870000000','0.001113799213612','0.001134715630769','47.53731172052923','47.537311720529232','test'),('2019-11-10 23:59:59','2019-11-14 19:59:59','ARKBTC','4h','0.000023980000000','0.000024400000000','0.001113799213612','0.001133306956302','46.447006405838195','46.447006405838195','test'),('2019-11-17 15:59:59','2019-11-18 15:59:59','ARKBTC','4h','0.000024790000000','0.000024130000000','0.001113799213612','0.001084145825916','44.929375296974584','44.929375296974584','test'),('2019-11-27 15:59:59','2019-11-30 07:59:59','ARKBTC','4h','0.000025320000000','0.000023710000000','0.001113799213612','0.001042977067723','43.98891049020537','43.988910490205370','test'),('2019-11-30 23:59:59','2019-12-04 19:59:59','ARKBTC','4h','0.000024720000000','0.000024670000000','0.001113799213612','0.001111546383487','45.05660249239482','45.056602492394823','test'),('2019-12-04 23:59:59','2019-12-05 03:59:59','ARKBTC','4h','0.000025020000000','0.000024790000000','0.001113799213612','0.001103560451856','44.51635546011191','44.516355460111910','test'),('2019-12-08 19:59:59','2019-12-09 23:59:59','ARKBTC','4h','0.000025140000000','0.000025090000000','0.001113799213612','0.001111584020268','44.30386688989658','44.303866889896582','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  9:48:24
