-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-02-26 11:59:59','2019-02-27 23:59:59','VIABNB','4h','0.035800000000000','0.033920000000000','0.711908500000000','0.674523360893855','19.885712290502795','19.885712290502795','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','VIABNB','4h','0.053330000000000','0.034760000000000','0.711908500000000','0.464015365835365','13.349118694918433','13.349118694918433','test'),('2019-03-12 11:59:59','2019-03-12 19:59:59','VIABNB','4h','0.044590000000000','0.034000000000000','0.711908500000000','0.542832226956717','15.965653734021084','15.965653734021084','test'),('2019-03-13 07:59:59','2019-03-13 15:59:59','VIABNB','4h','0.031240000000000','0.030760000000000','0.711908500000000','0.700970085147247','22.788364276568505','22.788364276568505','test'),('2019-03-13 19:59:59','2019-03-13 23:59:59','VIABNB','4h','0.031600000000000','0.030870000000000','0.711908500000000','0.695462512500000','22.52875','22.528749999999999','test'),('2019-03-14 19:59:59','2019-03-16 15:59:59','VIABNB','4h','0.034000000000000','0.031330000000000','0.711908500000000','0.656002744264706','20.938485294117648','20.938485294117648','test'),('2019-03-20 15:59:59','2019-03-24 11:59:59','VIABNB','4h','0.033760000000000','0.029660000000000','0.711908500000000','0.625450417950237','21.08733708530806','21.087337085308061','test'),('2019-03-28 23:59:59','2019-03-29 03:59:59','VIABNB','4h','0.031910000000000','0.031760000000000','0.711908500000000','0.708562016922595','22.30988718270135','22.309887182701349','test'),('2019-03-29 07:59:59','2019-03-29 15:59:59','VIABNB','4h','0.032050000000000','0.032070000000000','0.711908500000000','0.712352748673947','22.212433697347894','22.212433697347894','test'),('2019-03-30 03:59:59','2019-03-30 07:59:59','VIABNB','4h','0.032340000000000','0.031980000000000','0.711908500000000','0.703983730055659','22.013249845392703','22.013249845392703','test'),('2019-03-30 11:59:59','2019-03-31 07:59:59','VIABNB','4h','0.036040000000000','0.033190000000000','0.711908500000000','0.655611629162042','19.753288013318535','19.753288013318535','test'),('2019-03-31 15:59:59','2019-03-31 23:59:59','VIABNB','4h','0.032850000000000','0.032710000000000','0.711908500000000','0.708874491171994','21.67149162861492','21.671491628614920','test'),('2019-04-08 03:59:59','2019-04-09 23:59:59','VIABNB','4h','0.033940000000000','0.032880000000000','0.711908500000000','0.689674469063053','20.97550088391279','20.975500883912790','test'),('2019-04-10 11:59:59','2019-04-10 19:59:59','VIABNB','4h','0.034090000000000','0.032950000000000','0.474605666666667','0.458734429940354','13.922137479221668','13.922137479221668','test'),('2019-05-01 23:59:59','2019-05-02 15:59:59','VIABNB','4h','0.023860000000000','0.021270000000000','0.528817015467776','0.471413994928734','22.163328393452467','22.163328393452467','test'),('2019-05-02 19:59:59','2019-05-11 19:59:59','VIABNB','4h','0.023520000000000','0.031590000000000','0.528817015467776','0.710260608785163','22.483716644038097','22.483716644038097','test'),('2019-07-02 23:59:59','2019-07-03 03:59:59','VIABNB','4h','0.014250000000000','0.013560000000000','0.559827158662362','0.532719738348184','39.28611639735874','39.286116397358740','test'),('2019-07-03 15:59:59','2019-07-03 19:59:59','VIABNB','4h','0.013620000000000','0.014000000000000','0.559827158662362','0.575446418595673','41.10331561397665','41.103315613976648','test'),('2019-07-03 23:59:59','2019-07-04 07:59:59','VIABNB','4h','0.014040000000000','0.013570000000000','0.559827158662362','0.541086505915118','39.873729249455984','39.873729249455984','test'),('2019-07-04 19:59:59','2019-07-05 11:59:59','VIABNB','4h','0.014790000000000','0.013670000000000','0.559827158662362','0.517433215612880','37.85173486560933','37.851734865609330','test'),('2019-07-05 15:59:59','2019-07-06 03:59:59','VIABNB','4h','0.014070000000000','0.013700000000000','0.559827158662362','0.545105335726678','39.788710636983794','39.788710636983794','test'),('2019-07-06 15:59:59','2019-07-08 07:59:59','VIABNB','4h','0.014150000000000','0.013620000000000','0.559827158662362','0.538858367560521','39.56375679592664','39.563756795926643','test'),('2019-07-08 11:59:59','2019-07-08 15:59:59','VIABNB','4h','0.014290000000000','0.013570000000000','0.559827158662362','0.531620331913804','39.17614826188677','39.176148261886773','test'),('2019-07-09 03:59:59','2019-07-09 07:59:59','VIABNB','4h','0.014270000000000','0.013770000000000','0.559827158662362','0.540211631028782','39.23105526715921','39.231055267159213','test'),('2019-07-09 15:59:59','2019-07-10 19:59:59','VIABNB','4h','0.014360000000000','0.014540000000000','0.559827158662362','0.566844490734731','38.98517817983022','38.985178179830221','test'),('2019-07-28 19:59:59','2019-07-28 23:59:59','VIABNB','4h','0.011970000000000','0.011600000000000','0.559827158662362','0.542522559773049','46.76918618733183','46.769186187331833','test'),('2019-07-29 03:59:59','2019-07-31 03:59:59','VIABNB','4h','0.011730000000000','0.011750000000000','0.559827158662362','0.560781680672017','47.7261004827248','47.726100482724803','test'),('2019-08-23 15:59:59','2019-08-29 15:59:59','VIABNB','4h','0.009960000000000','0.010960000000000','0.559827158662362','0.616034704712800','56.20754605043795','56.207546050437948','test'),('2019-08-31 23:59:59','2019-09-02 15:59:59','VIABNB','4h','0.011500000000000','0.010760000000000','0.559827158662362','0.523803498018001','48.68062249237931','48.680622492379307','test'),('2019-09-11 15:59:59','2019-09-13 03:59:59','VIABNB','4h','0.010940000000000','0.010420000000000','0.559827158662362','0.533217458250623','51.1725007918064','51.172500791806399','test'),('2019-09-13 07:59:59','2019-09-13 11:59:59','VIABNB','4h','0.010510000000000','0.010480000000000','0.559827158662362','0.558229174384544','53.266142593945006','53.266142593945006','test'),('2019-09-13 19:59:59','2019-09-16 11:59:59','VIABNB','4h','0.011400000000000','0.011210000000000','0.559827158662362','0.550496706017989','49.10764549669842','49.107645496698417','test'),('2019-09-20 19:59:59','2019-09-23 03:59:59','VIABNB','4h','0.011550000000000','0.011310000000000','0.559827158662362','0.548194386534313','48.46988386687117','48.469883866871172','test'),('2019-09-23 07:59:59','2019-09-23 23:59:59','VIABNB','4h','0.011670000000000','0.011470000000000','0.559827158662362','0.550232862884087','47.97147889137635','47.971478891376350','test'),('2019-09-24 03:59:59','2019-09-24 07:59:59','VIABNB','4h','0.011500000000000','0.011310000000000','0.559827158662362','0.550577840388810','48.68062249237931','48.680622492379307','test'),('2019-09-24 11:59:59','2019-09-24 15:59:59','VIABNB','4h','0.011530000000000','0.011310000000000','0.559827158662362','0.549145287464988','48.553959988062616','48.553959988062616','test'),('2019-09-28 03:59:59','2019-09-28 07:59:59','VIABNB','4h','0.011390000000000','0.011450000000000','0.559827158662362','0.562776204274280','49.15076019862704','49.150760198627040','test'),('2019-09-28 11:59:59','2019-09-29 03:59:59','VIABNB','4h','0.011610000000000','0.011470000000000','0.559827158662362','0.553076443570826','48.21939351097002','48.219393510970022','test'),('2019-09-29 15:59:59','2019-09-29 19:59:59','VIABNB','4h','0.011400000000000','0.011340000000000','0.559827158662362','0.556880699932560','49.10764549669842','49.107645496698417','test'),('2019-10-01 23:59:59','2019-10-09 15:59:59','VIABNB','4h','0.012160000000000','0.012250000000000','0.559827158662362','0.563970616251146','46.03841765315477','46.038417653154767','test'),('2019-10-21 07:59:59','2019-10-22 07:59:59','VIABNB','4h','0.011830000000000','0.012010000000000','0.559827158662362','0.568345238844883','47.322667680673035','47.322667680673035','test'),('2019-10-22 19:59:59','2019-10-23 07:59:59','VIABNB','4h','0.012040000000000','0.011930000000000','0.559827158662362','0.554712458707806','46.49727231414967','46.497272314149669','test'),('2019-11-06 19:59:59','2019-11-07 07:59:59','VIABNB','4h','0.010610000000000','0.010580000000000','0.559827158662362','0.558244235499320','52.76410543471838','52.764105434718381','test'),('2019-11-07 15:59:59','2019-11-08 07:59:59','VIABNB','4h','0.010500000000000','0.010460000000000','0.559827158662362','0.557694483772220','53.31687225355828','53.316872253558280','test'),('2019-11-08 11:59:59','2019-11-08 15:59:59','VIABNB','4h','0.010680000000000','0.010160000000000','0.559827158662362','0.532569656555206','52.41827328299269','52.418273282992693','test'),('2019-11-18 23:59:59','2019-11-21 11:59:59','VIABNB','4h','0.010660000000000','0.010060000000000','0.559827158662362','0.528317187255475','52.51661901147861','52.516619011478610','test'),('2019-11-23 03:59:59','2019-11-23 23:59:59','VIABNB','4h','0.010440000000000','0.010160000000000','0.559827158662362','0.544812637165670','53.62329105961322','53.623291059613223','test'),('2019-11-25 11:59:59','2019-12-02 11:59:59','VIABNB','4h','0.010690000000000','0.012390000000000','0.559827158662362','0.648854863968818','52.36923841556239','52.369238415562393','test'),('2019-12-06 19:59:59','2019-12-15 11:59:59','VIABNB','4h','0.013040000000000','0.014400000000000','0.559827158662362','0.618214040240645','42.93153057226703','42.931530572267029','test'),('2019-12-16 19:59:59','2019-12-18 15:59:59','VIABNB','4h','0.015880000000000','0.015060000000000','0.559827158662362','0.530919207144532','35.25359941198754','35.253599411987537','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 23:11:24
