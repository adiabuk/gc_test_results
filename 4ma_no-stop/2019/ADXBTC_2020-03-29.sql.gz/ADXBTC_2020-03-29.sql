-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 03:59:59','2019-01-06 07:59:59','ADXBTC','4h','0.000028000000000','0.000027660000000','0.001467500000000','0.001449680357143','52.41071428571429','52.410714285714292','test'),('2019-01-06 15:59:59','2019-01-06 19:59:59','ADXBTC','4h','0.000028240000000','0.000027330000000','0.001467500000000','0.001420211579320','51.96529745042493','51.965297450424927','test'),('2019-01-17 03:59:59','2019-01-18 15:59:59','ADXBTC','4h','0.000027360000000','0.000026390000000','0.001467500000000','0.001415472404971','53.636695906432756','53.636695906432756','test'),('2019-01-18 19:59:59','2019-01-21 15:59:59','ADXBTC','4h','0.000026850000000','0.000027990000000','0.001467500000000','0.001529807262570','54.655493482309126','54.655493482309126','test'),('2019-01-21 23:59:59','2019-01-22 07:59:59','ADXBTC','4h','0.000028920000000','0.000028420000000','0.001467500000000','0.001442128284924','50.743430152143844','50.743430152143844','test'),('2019-01-22 15:59:59','2019-01-23 23:59:59','ADXBTC','4h','0.000029900000000','0.000029880000000','0.001467500000000','0.001466518394649','49.08026755852843','49.080267558528433','test'),('2019-01-24 07:59:59','2019-01-25 11:59:59','ADXBTC','4h','0.000029830000000','0.000029200000000','0.001467500000000','0.001436506872276','49.19544083137781','49.195440831377809','test'),('2019-02-07 11:59:59','2019-02-09 19:59:59','ADXBTC','4h','0.000028470000000','0.000030000000000','0.001467500000000','0.001546364594310','51.545486476993325','51.545486476993325','test'),('2019-02-11 19:59:59','2019-02-12 15:59:59','ADXBTC','4h','0.000031420000000','0.000030190000000','0.001467500000000','0.001410051718651','46.70591979630809','46.705919796308088','test'),('2019-02-12 23:59:59','2019-02-13 07:59:59','ADXBTC','4h','0.000031080000000','0.000030170000000','0.001467500000000','0.001424532657658','47.216859716859716','47.216859716859716','test'),('2019-02-16 19:59:59','2019-02-18 19:59:59','ADXBTC','4h','0.000031100000000','0.000030950000000','0.001467500000000','0.001460422025723','47.18649517684888','47.186495176848879','test'),('2019-02-20 23:59:59','2019-02-21 07:59:59','ADXBTC','4h','0.000031520000000','0.000030380000000','0.001467500000000','0.001414424175127','46.55774111675127','46.557741116751266','test'),('2019-02-26 11:59:59','2019-02-27 15:59:59','ADXBTC','4h','0.000032150000000','0.000030710000000','0.001467500000000','0.001401770606532','45.64541213063764','45.645412130637638','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','ADXBTC','4h','0.000031230000000','0.000030860000000','0.001467500000000','0.001450113672751','46.990073647134174','46.990073647134174','test'),('2019-02-28 03:59:59','2019-03-03 15:59:59','ADXBTC','4h','0.000031140000000','0.000032060000000','0.001467500000000','0.001510855812460','47.12588310854208','47.125883108542077','test'),('2019-03-06 07:59:59','2019-03-06 23:59:59','ADXBTC','4h','0.000032850000000','0.000032140000000','0.001467500000000','0.001435782343988','44.67275494672755','44.672754946727551','test'),('2019-03-07 07:59:59','2019-03-11 15:59:59','ADXBTC','4h','0.000032320000000','0.000035100000000','0.001467500000000','0.001593726794554','45.40532178217822','45.405321782178220','test'),('2019-03-11 19:59:59','2019-03-16 11:59:59','ADXBTC','4h','0.000037020000000','0.000035930000000','0.001467500000000','0.001424291599136','39.64073473797947','39.640734737979471','test'),('2019-03-17 19:59:59','2019-03-18 11:59:59','ADXBTC','4h','0.000037050000000','0.000035770000000','0.001467500000000','0.001416800944669','39.60863697705803','39.608636977058033','test'),('2019-03-26 15:59:59','2019-03-29 03:59:59','ADXBTC','4h','0.000048050000000','0.000040200000000','0.001467500000000','0.001227752341311','30.541103017689906','30.541103017689906','test'),('2019-04-01 03:59:59','2019-04-02 03:59:59','ADXBTC','4h','0.000040730000000','0.000039140000000','0.001467500000000','0.001410212374171','36.02995335133809','36.029953351338087','test'),('2019-04-21 03:59:59','2019-04-21 11:59:59','ADXBTC','4h','0.000034530000000','0.000032020000000','0.001467500000000','0.001360826817260','42.4992759918911','42.499275991891103','test'),('2019-04-22 03:59:59','2019-04-22 07:59:59','ADXBTC','4h','0.000033720000000','0.000032890000000','0.001467500000000','0.001431378262159','43.520166073546854','43.520166073546854','test'),('2019-04-22 19:59:59','2019-04-23 03:59:59','ADXBTC','4h','0.000033710000000','0.000032600000000','0.001467500000000','0.001419178285375','43.5330762385049','43.533076238504897','test'),('2019-05-23 11:59:59','2019-05-26 23:59:59','ADXBTC','4h','0.000019550000000','0.000019350000000','0.001467500000000','0.001452487212276','75.06393861892583','75.063938618925832','test'),('2019-05-29 03:59:59','2019-05-30 19:59:59','ADXBTC','4h','0.000021000000000','0.000020390000000','0.001467500000000','0.001424872619048','69.8809523809524','69.880952380952394','test'),('2019-05-31 23:59:59','2019-06-01 15:59:59','ADXBTC','4h','0.000020440000000','0.000019970000000','0.001467500000000','0.001433756115460','71.79549902152642','71.795499021526425','test'),('2019-06-08 07:59:59','2019-06-09 15:59:59','ADXBTC','4h','0.000021520000000','0.000019760000000','0.001467500000000','0.001347481412639','68.19237918215613','68.192379182156131','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','ADXBTC','4h','0.000020650000000','0.000019870000000','0.001467500000000','0.001412069007264','71.06537530266344','71.065375302663440','test'),('2019-06-10 15:59:59','2019-06-13 19:59:59','ADXBTC','4h','0.000020460000000','0.000020380000000','0.001467500000000','0.001461761974585','71.72531769305962','71.725317693059623','test'),('2019-06-13 23:59:59','2019-06-14 03:59:59','ADXBTC','4h','0.000020850000000','0.000020900000000','0.001467500000000','0.001471019184652','70.38369304556356','70.383693045563561','test'),('2019-07-23 07:59:59','2019-07-30 19:59:59','ADXBTC','4h','0.000011330000000','0.000011080000000','0.001467500000000','0.001435119152692','129.5233892321271','129.523389232127101','test'),('2019-08-22 23:59:59','2019-08-27 07:59:59','ADXBTC','4h','0.000008420000000','0.000009030000000','0.001467500000000','0.001573815320665','174.2874109263658','174.287410926365794','test'),('2019-09-10 15:59:59','2019-09-11 03:59:59','ADXBTC','4h','0.000008310000000','0.000007740000000','0.001467500000000','0.001366841155235','176.5944645006017','176.594464500601703','test'),('2019-09-11 11:59:59','2019-09-11 15:59:59','ADXBTC','4h','0.000007700000000','0.000007720000000','0.001467500000000','0.001471311688312','190.58441558441558','190.584415584415581','test'),('2019-09-17 15:59:59','2019-09-18 03:59:59','ADXBTC','4h','0.000008140000000','0.000007890000000','0.001467500000000','0.001422429361179','180.28255528255528','180.282555282555279','test'),('2019-09-18 07:59:59','2019-09-19 07:59:59','ADXBTC','4h','0.000007940000000','0.000007950000000','0.001467500000000','0.001469348236776','184.823677581864','184.823677581863990','test'),('2019-09-19 15:59:59','2019-09-19 23:59:59','ADXBTC','4h','0.000007940000000','0.000007880000000','0.001467500000000','0.001456410579345','184.823677581864','184.823677581863990','test'),('2019-09-20 03:59:59','2019-09-22 11:59:59','ADXBTC','4h','0.000007990000000','0.000008000000000','0.001467500000000','0.001469336670839','183.66708385481854','183.667083854818543','test'),('2019-09-29 03:59:59','2019-09-30 15:59:59','ADXBTC','4h','0.000007970000000','0.000007770000000','0.001467500000000','0.001430674404015','184.1279799247177','184.127979924717692','test'),('2019-10-01 23:59:59','2019-10-07 07:59:59','ADXBTC','4h','0.000008090000000','0.000010150000000','0.001467500000000','0.001841177379481','181.39678615574783','181.396786155747833','test'),('2019-10-12 19:59:59','2019-10-13 07:59:59','ADXBTC','4h','0.000010080000000','0.000009620000000','0.001467500000000','0.001400530753968','145.58531746031747','145.585317460317469','test'),('2019-10-22 15:59:59','2019-10-23 03:59:59','ADXBTC','4h','0.000009770000000','0.000009300000000','0.001467500000000','0.001396903787103','150.20470829068577','150.204708290685772','test'),('2019-10-23 11:59:59','2019-10-23 15:59:59','ADXBTC','4h','0.000009380000000','0.000009140000000','0.001467500000000','0.001429952025586','156.4498933901919','156.449893390191903','test'),('2019-11-01 07:59:59','2019-11-03 03:59:59','ADXBTC','4h','0.000009640000000','0.000008850000000','0.001467500000000','0.001347238070539','152.23029045643156','152.230290456431561','test'),('2019-11-04 03:59:59','2019-11-04 11:59:59','ADXBTC','4h','0.000009090000000','0.000008980000000','0.001467500000000','0.001449741474147','161.44114411441146','161.441144114411458','test'),('2019-11-08 03:59:59','2019-11-10 19:59:59','ADXBTC','4h','0.000009560000000','0.000009210000000','0.001467500000000','0.001413773535565','153.50418410041843','153.504184100418428','test'),('2019-11-12 03:59:59','2019-11-12 15:59:59','ADXBTC','4h','0.000009360000000','0.000009380000000','0.001467500000000','0.001470635683761','156.78418803418805','156.784188034188048','test'),('2019-11-12 23:59:59','2019-11-13 11:59:59','ADXBTC','4h','0.000009340000000','0.000009240000000','0.001467500000000','0.001451788008565','157.1199143468951','157.119914346895087','test'),('2019-11-13 15:59:59','2019-11-19 07:59:59','ADXBTC','4h','0.000009380000000','0.000009550000000','0.001467500000000','0.001494096481876','156.4498933901919','156.449893390191903','test'),('2019-11-26 15:59:59','2019-11-30 15:59:59','ADXBTC','4h','0.000010110000000','0.000009730000000','0.001467500000000','0.001412341740851','145.15331355093969','145.153313550939686','test'),('2019-12-01 15:59:59','2019-12-03 15:59:59','ADXBTC','4h','0.000011150000000','0.000010480000000','0.001467500000000','0.001379318385650','131.61434977578475','131.614349775784746','test'),('2019-12-08 11:59:59','2019-12-08 15:59:59','ADXBTC','4h','0.000010430000000','0.000010380000000','0.001467500000000','0.001460465004794','140.69990412272293','140.699904122722927','test'),('2019-12-08 23:59:59','2019-12-09 07:59:59','ADXBTC','4h','0.000010480000000','0.000010390000000','0.001467500000000','0.001454897423664','140.02862595419847','140.028625954198475','test'),('2019-12-09 11:59:59','2019-12-10 03:59:59','ADXBTC','4h','0.000010630000000','0.000010510000000','0.001467500000000','0.001450933678269','138.05268109125117','138.052681091251173','test'),('2019-12-10 07:59:59','2019-12-10 15:59:59','ADXBTC','4h','0.000010810000000','0.000010360000000','0.001467500000000','0.001406410730805','135.75393154486588','135.753931544865878','test'),('2019-12-11 23:59:59','2019-12-12 03:59:59','ADXBTC','4h','0.000010570000000','0.000010510000000','0.001467500000000','0.001459169820246','138.83632923368023','138.836329233680232','test'),('2019-12-13 11:59:59','2019-12-14 19:59:59','ADXBTC','4h','0.000010580000000','0.000010640000000','0.001467500000000','0.001475822306238','138.70510396975425','138.705103969754248','test'),('2019-12-15 07:59:59','2019-12-17 23:59:59','ADXBTC','4h','0.000010600000000','0.000010230000000','0.001467500000000','0.001416275943396','138.4433962264151','138.443396226415103','test'),('2019-12-19 19:59:59','2019-12-22 03:59:59','ADXBTC','4h','0.000011190000000','0.000010920000000','0.001467500000000','0.001432091152815','131.14387846291334','131.143878462913335','test'),('2019-12-28 19:59:59','2019-12-31 19:59:59','ADXBTC','4h','0.000010940000000','0.000010710000000','0.001467500000000','0.001436647623400','134.14076782449726','134.140767824497260','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  1:28:54
