-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-18 03:59:59','2019-01-21 15:59:59','IOTAETH','4h','0.002534760000000','0.002582220000000','0.072144500000000','0.073495309532263','28.462063469519798','28.462063469519798','test'),('2019-01-21 19:59:59','2019-01-22 11:59:59','IOTAETH','4h','0.002593630000000','0.002546060000000','0.072482202383066','0.071152799820880','27.946238431490134','27.946238431490134','test'),('2019-01-22 15:59:59','2019-01-23 15:59:59','IOTAETH','4h','0.002556780000000','0.002549370000000','0.072482202383066','0.072272136159277','28.349018055157664','28.349018055157664','test'),('2019-03-01 11:59:59','2019-03-02 11:59:59','IOTAETH','4h','0.002167430000000','0.002162490000000','0.072482202383066','0.072317001163293','33.44154246414694','33.441542464146941','test'),('2019-03-02 15:59:59','2019-03-04 07:59:59','IOTAETH','4h','0.002170810000000','0.002156790000000','0.072482202383066','0.072014081968377','33.38947323029929','33.389473230299288','test'),('2019-03-04 11:59:59','2019-03-04 15:59:59','IOTAETH','4h','0.002157320000000','0.002138320000000','0.072482202383066','0.071843835406781','33.598261909714836','33.598261909714836','test'),('2019-03-12 19:59:59','2019-03-16 07:59:59','IOTAETH','4h','0.002127600000000','0.002164770000000','0.072482202383066','0.073748494666662','34.067589012533375','34.067589012533375','test'),('2019-03-20 15:59:59','2019-03-20 19:59:59','IOTAETH','4h','0.002185590000000','0.002149970000000','0.072482202383066','0.071300912182761','33.16367771771742','33.163677717717420','test'),('2019-03-21 03:59:59','2019-03-21 07:59:59','IOTAETH','4h','0.002148880000000','0.002131910000000','0.072482202383066','0.071909800492574','33.730223364294886','33.730223364294886','test'),('2019-03-21 15:59:59','2019-03-24 23:59:59','IOTAETH','4h','0.002158000000000','0.002262870000000','0.072482202383066','0.076004541847344','33.58767487630491','33.587674876304909','test'),('2019-04-01 23:59:59','2019-04-02 07:59:59','IOTAETH','4h','0.002271000000000','0.002246750000000','0.072538147948154','0.071763577235806','31.941060303018272','31.941060303018272','test'),('2019-04-02 11:59:59','2019-04-02 15:59:59','IOTAETH','4h','0.002251250000000','0.002192070000000','0.072538147948154','0.070631292825190','32.22127615687018','32.221276156870182','test'),('2019-04-29 15:59:59','2019-05-01 15:59:59','IOTAETH','4h','0.002029350000000','0.001798220000000','0.072538147948154','0.064276516324601','35.744523097619435','35.744523097619435','test'),('2019-05-14 15:59:59','2019-05-15 15:59:59','IOTAETH','4h','0.001765440000000','0.001751450000000','0.072538147948154','0.071963328815363','41.08785795504463','41.087857955044633','test'),('2019-05-15 19:59:59','2019-05-16 03:59:59','IOTAETH','4h','0.001775400000000','0.001672500000000','0.072538147948154','0.068333926125542','40.85735493305959','40.857354933059590','test'),('2019-05-28 19:59:59','2019-06-01 19:59:59','IOTAETH','4h','0.001771200000000','0.001810420000000','0.072538147948154','0.074144373198000','40.954238904784326','40.954238904784326','test'),('2019-07-15 23:59:59','2019-07-16 19:59:59','IOTAETH','4h','0.001357330000000','0.001309170000000','0.072538147948154','0.069964391230787','53.44179230412207','53.441792304122067','test'),('2019-07-16 23:59:59','2019-07-17 15:59:59','IOTAETH','4h','0.001352850000000','0.001323230000000','0.072538147948154','0.070949960091241','53.618766269840705','53.618766269840705','test'),('2019-07-17 19:59:59','2019-07-18 11:59:59','IOTAETH','4h','0.001353840000000','0.001359140000000','0.072538147948154','0.072822119602209','53.579557368783604','53.579557368783604','test'),('2019-07-18 19:59:59','2019-07-18 23:59:59','IOTAETH','4h','0.001334280000000','0.001351610000000','0.072538147948154','0.073480293602695','54.36501180273556','54.365011802735559','test'),('2019-07-19 03:59:59','2019-07-20 03:59:59','IOTAETH','4h','0.001379050000000','0.001403340000000','0.072538147948154','0.073815804025643','52.60008552855516','52.600085528555162','test'),('2019-07-20 07:59:59','2019-07-22 11:59:59','IOTAETH','4h','0.001437990000000','0.001393920000000','0.072538147948154','0.070315075339808','50.444125444651206','50.444125444651206','test'),('2019-07-24 03:59:59','2019-07-25 07:59:59','IOTAETH','4h','0.001407130000000','0.001379500000000','0.072538147948154','0.071113809736470','51.55042387565754','51.550423875657543','test'),('2019-08-16 11:59:59','2019-08-18 19:59:59','IOTAETH','4h','0.001298880000000','0.001276770000000','0.072538147948154','0.071303377645175','55.84668941561498','55.846689415614982','test'),('2019-08-21 19:59:59','2019-08-22 03:59:59','IOTAETH','4h','0.001290210000000','0.001290300000000','0.072538147948154','0.072543207925456','56.22197002670418','56.221970026704177','test'),('2019-08-22 11:59:59','2019-08-27 23:59:59','IOTAETH','4h','0.001298000000000','0.001389840000000','0.072538147948154','0.077670585165071','55.884551577930665','55.884551577930665','test'),('2019-08-28 19:59:59','2019-08-29 07:59:59','IOTAETH','4h','0.001420000000000','0.001396880000000','0.072538147948154','0.071357104299871','51.08320278039014','51.083202780390138','test'),('2019-08-29 11:59:59','2019-09-01 03:59:59','IOTAETH','4h','0.001421950000000','0.001439190000000','0.072538147948154','0.073417614645736','51.0131495116945','51.013149511694500','test'),('2019-09-01 11:59:59','2019-09-01 15:59:59','IOTAETH','4h','0.001473100000000','0.001451440000000','0.072538147948154','0.071471569790149','49.24183554962596','49.241835549625961','test'),('2019-09-19 11:59:59','2019-09-19 19:59:59','IOTAETH','4h','0.001353880000000','0.001356330000000','0.072538147948154','0.072669413985375','53.57797437598162','53.577974375981618','test'),('2019-09-20 07:59:59','2019-09-20 15:59:59','IOTAETH','4h','0.001336300000000','0.001365320000000','0.072538147948154','0.074113435722947','54.28283166067051','54.282831660670510','test'),('2019-09-20 19:59:59','2019-09-22 07:59:59','IOTAETH','4h','0.001383390000000','0.001355330000000','0.072538147948154','0.071066819955740','52.435067441686','52.435067441686002','test'),('2019-09-23 19:59:59','2019-09-28 03:59:59','IOTAETH','4h','0.001407380000000','0.001496020000000','0.072538147948154','0.077106765829696','51.54126671414543','51.541266714145429','test'),('2019-09-30 03:59:59','2019-09-30 11:59:59','IOTAETH','4h','0.001550190000000','0.001511120000000','0.072538147948154','0.070709942734384','46.79306920322928','46.793069203229280','test'),('2019-10-02 03:59:59','2019-10-04 15:59:59','IOTAETH','4h','0.001535030000000','0.001530380000000','0.072538147948154','0.072318411273327','47.25519888741849','47.255198887418487','test'),('2019-10-05 07:59:59','2019-10-08 03:59:59','IOTAETH','4h','0.001568320000000','0.001542400000000','0.072538147948154','0.071339292615814','46.2521347353563','46.252134735356300','test'),('2019-10-14 11:59:59','2019-10-14 19:59:59','IOTAETH','4h','0.001541450000000','0.001514000000000','0.072538147948154','0.071246395272961','47.05838525294625','47.058385252946252','test'),('2019-10-14 23:59:59','2019-10-20 23:59:59','IOTAETH','4h','0.001523480000000','0.001541400000000','0.072538147948154','0.073391381079689','47.613456000836244','47.613456000836244','test'),('2019-10-22 19:59:59','2019-10-23 15:59:59','IOTAETH','4h','0.001568320000000','0.001566740000000','0.072538147948154','0.072465069575272','46.2521347353563','46.252134735356300','test'),('2019-10-23 19:59:59','2019-10-24 03:59:59','IOTAETH','4h','0.001583240000000','0.001572950000000','0.072538147948154','0.072066698551735','45.81626787357191','45.816267873571910','test'),('2019-10-24 07:59:59','2019-10-24 15:59:59','IOTAETH','4h','0.001575210000000','0.001570770000000','0.072538147948154','0.072333686716388','46.04982697427898','46.049826974278979','test'),('2019-10-24 19:59:59','2019-10-25 07:59:59','IOTAETH','4h','0.001575210000000','0.001557380000000','0.072538147948154','0.071717079533203','46.04982697427898','46.049826974278979','test'),('2019-11-24 19:59:59','2019-11-25 03:59:59','IOTAETH','4h','0.001429820000000','0.001426900000000','0.072538147948154','0.072390009446798','50.732363478028','50.732363478027999','test'),('2019-11-25 07:59:59','2019-11-25 15:59:59','IOTAETH','4h','0.001449350000000','0.001412010000000','0.072538147948154','0.070669327825765','50.048744573880704','50.048744573880704','test'),('2019-11-25 19:59:59','2019-11-26 19:59:59','IOTAETH','4h','0.001422100000000','0.001421740000000','0.072538147948154','0.072519785151402','51.00776875617326','51.007768756173263','test'),('2019-11-26 23:59:59','2019-11-27 07:59:59','IOTAETH','4h','0.001435780000000','0.001419490000000','0.072538147948154','0.071715148303309','50.52177070871164','50.521770708711642','test'),('2019-11-27 11:59:59','2019-11-27 15:59:59','IOTAETH','4h','0.001424300000000','0.001400070000000','0.072538147948154','0.071304138733253','50.92898121754826','50.928981217548262','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:33:02
