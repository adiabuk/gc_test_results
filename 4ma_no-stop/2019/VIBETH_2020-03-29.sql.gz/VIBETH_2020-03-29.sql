-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 07:59:59','2019-01-10 07:59:59','VIBETH','4h','0.000178050000000','0.000174870000000','0.072144500000000','0.070855988289806','405.1923616961528','405.192361696152773','test'),('2019-01-10 11:59:59','2019-01-10 15:59:59','VIBETH','4h','0.000175250000000','0.000175830000000','0.072144500000000','0.072383266390870','411.66619115549213','411.666191155492129','test'),('2019-01-10 23:59:59','2019-01-11 03:59:59','VIBETH','4h','0.000176500000000','0.000173250000000','0.072144500000000','0.070816060198300','408.75070821529744','408.750708215297436','test'),('2019-01-11 19:59:59','2019-01-12 11:59:59','VIBETH','4h','0.000181400000000','0.000175880000000','0.072144500000000','0.069949143660419','397.7094818081588','397.709481808158785','test'),('2019-01-12 15:59:59','2019-01-14 19:59:59','VIBETH','4h','0.000177700000000','0.000179010000000','0.072144500000000','0.072676347467642','405.9904333145751','405.990433314575114','test'),('2019-01-15 03:59:59','2019-01-20 11:59:59','VIBETH','4h','0.000181530000000','0.000193780000000','0.072144500000000','0.077012952184212','397.4246680989368','397.424668098936820','test'),('2019-01-22 07:59:59','2019-01-27 15:59:59','VIBETH','4h','0.000205980000000','0.000206770000000','0.072351189547812','0.072628679788334','351.25346901549784','351.253469015497842','test'),('2019-01-30 11:59:59','2019-01-30 23:59:59','VIBETH','4h','0.000215360000000','0.000207910000000','0.072420562107943','0.069915300277964','336.2767557018144','336.276755701814409','test'),('2019-02-01 15:59:59','2019-02-02 15:59:59','VIBETH','4h','0.000213160000000','0.000209540000000','0.072420562107943','0.071190676412546','339.7474296675877','339.747429667587710','test'),('2019-02-05 19:59:59','2019-02-05 23:59:59','VIBETH','4h','0.000211160000000','0.000211460000000','0.072420562107943','0.072523451711241','342.96534432630705','342.965344326307047','test'),('2019-02-06 07:59:59','2019-02-06 11:59:59','VIBETH','4h','0.000212940000000','0.000210000000000','0.072420562107943','0.071420672690279','340.09844138228135','340.098441382281351','test'),('2019-02-07 19:59:59','2019-02-07 23:59:59','VIBETH','4h','0.000210130000000','0.000209400000000','0.072420562107943','0.072168970187043','344.64646698683197','344.646466986831967','test'),('2019-02-08 07:59:59','2019-02-08 11:59:59','VIBETH','4h','0.000211460000000','0.000206570000000','0.072420562107943','0.070745840890182','342.47877663833816','342.478776638338161','test'),('2019-02-27 15:59:59','2019-03-06 07:59:59','VIBETH','4h','0.000171590000000','0.000183230000000','0.072420562107943','0.077333292120977','422.05584304413424','422.055843044134235','test'),('2019-03-08 03:59:59','2019-03-16 07:59:59','VIBETH','4h','0.000185220000000','0.000203120000000','0.072420562107943','0.079419417856416','390.99752784765684','390.997527847656841','test'),('2019-03-16 15:59:59','2019-03-18 07:59:59','VIBETH','4h','0.000212220000000','0.000207650000000','0.073758843428719','0.072170501545441','347.55839896672677','347.558398966726770','test'),('2019-03-19 19:59:59','2019-03-19 23:59:59','VIBETH','4h','0.000210230000000','0.000208180000000','0.073758843428719','0.073039604361845','350.848325304281','350.848325304280991','test'),('2019-03-20 15:59:59','2019-03-21 15:59:59','VIBETH','4h','0.000210030000000','0.000202520000000','0.073758843428719','0.071121463463239','351.1824188388278','351.182418838827800','test'),('2019-03-26 23:59:59','2019-03-29 23:59:59','VIBETH','4h','0.000217210000000','0.000256460000000','0.073758843428719','0.087087118391093','339.57388439169006','339.573884391690058','test'),('2019-04-17 15:59:59','2019-04-21 15:59:59','VIBETH','4h','0.000227840000000','0.000237930000000','0.075854671940404','0.079213931244647','332.9295643451732','332.929564345173219','test'),('2019-04-22 19:59:59','2019-04-23 23:59:59','VIBETH','4h','0.000254690000000','0.000243850000000','0.076694486766465','0.073430250885400','301.12877131597236','301.128771315972358','test'),('2019-04-28 07:59:59','2019-04-29 07:59:59','VIBETH','4h','0.000241900000000','0.000239130000000','0.076694486766465','0.075816257215646','317.0503793570277','317.050379357027680','test'),('2019-04-30 23:59:59','2019-05-03 07:59:59','VIBETH','4h','0.000246460000000','0.000248040000000','0.076694486766465','0.077186157987316','311.1843169945021','311.184316994502126','test'),('2019-05-05 11:59:59','2019-05-06 19:59:59','VIBETH','4h','0.000251770000000','0.000249740000000','0.076694486766465','0.076076105672070','304.6212287661953','304.621228766195316','test'),('2019-05-24 03:59:59','2019-05-24 15:59:59','VIBETH','4h','0.000200220000000','0.000187500000000','0.076694486766465','0.071822077058796','383.05107764691337','383.051077646913370','test'),('2019-05-24 19:59:59','2019-05-24 23:59:59','VIBETH','4h','0.000187980000000','0.000187450000000','0.076694486766465','0.076478250581838','407.99280118345035','407.992801183450354','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','VIBETH','4h','0.000198470000000','0.000187670000000','0.076694486766465','0.072521057749093','386.42861271963017','386.428612719630166','test'),('2019-05-27 03:59:59','2019-05-27 07:59:59','VIBETH','4h','0.000189030000000','0.000186270000000','0.076694486766465','0.075574681531976','405.7265342351214','405.726534235121392','test'),('2019-06-01 19:59:59','2019-06-03 07:59:59','VIBETH','4h','0.000194840000000','0.000190150000000','0.076694486766465','0.074848371272035','393.62803719187536','393.628037191875364','test'),('2019-06-03 11:59:59','2019-06-03 15:59:59','VIBETH','4h','0.000192730000000','0.000190320000000','0.076694486766465','0.075735457486606','397.93746052231097','397.937460522310971','test'),('2019-06-03 19:59:59','2019-06-03 23:59:59','VIBETH','4h','0.000192100000000','0.000186480000000','0.076694486766465','0.074450743842844','399.2425130997657','399.242513099765688','test'),('2019-06-08 19:59:59','2019-06-14 15:59:59','VIBETH','4h','0.000193450000000','0.000191380000000','0.076694486766465','0.075873822059271','396.4563802867149','396.456380286714875','test'),('2019-07-05 03:59:59','2019-07-06 07:59:59','VIBETH','4h','0.000152330000000','0.000148390000000','0.076694486766465','0.074710791644953','503.47591916539744','503.475919165397443','test'),('2019-07-14 03:59:59','2019-07-14 07:59:59','VIBETH','4h','0.000138500000000','0.000139000000000','0.076694486766465','0.076971362169954','553.7508069780865','553.750806978086530','test'),('2019-07-14 11:59:59','2019-07-15 23:59:59','VIBETH','4h','0.000140250000000','0.000146000000000','0.076694486766465','0.079838824013575','546.8412603669518','546.841260366951815','test'),('2019-07-16 07:59:59','2019-07-16 15:59:59','VIBETH','4h','0.000144530000000','0.000141160000000','0.076694486766465','0.074906204607723','530.64752484927','530.647524849269985','test'),('2019-08-22 11:59:59','2019-08-27 19:59:59','VIBETH','4h','0.000105820000000','0.000102500000000','0.076694486766465','0.074288271532439','724.7636247067189','724.763624706718929','test'),('2019-08-30 15:59:59','2019-08-30 23:59:59','VIBETH','4h','0.000102400000000','0.000098960000000','0.076694486766465','0.074118031351654','748.9695973287597','748.969597328759733','test'),('2019-09-10 03:59:59','2019-09-10 19:59:59','VIBETH','4h','0.000100000000000','0.000096200000000','0.076694486766465','0.073780096269339','766.9448676646499','766.944867664649905','test'),('2019-09-10 23:59:59','2019-09-11 07:59:59','VIBETH','4h','0.000096530000000','0.000093470000000','0.076694486766465','0.074263272330483','794.514521562882','794.514521562882010','test'),('2019-09-11 15:59:59','2019-09-11 19:59:59','VIBETH','4h','0.000096490000000','0.000094110000000','0.076694486766465','0.074802758312696','794.8438881383044','794.843888138304351','test'),('2019-09-14 19:59:59','2019-09-15 03:59:59','VIBETH','4h','0.000097600000000','0.000106150000000','0.076694486766465','0.083413112400208','785.8041676891905','785.804167689190535','test'),('2019-09-15 11:59:59','2019-09-16 07:59:59','VIBETH','4h','0.000104600000000','0.000097740000000','0.076694486766465','0.071664618896313','733.216890692782','733.216890692782044','test'),('2019-09-16 11:59:59','2019-09-16 15:59:59','VIBETH','4h','0.000097870000000','0.000097240000000','0.076694486766465','0.076200795884041','783.6363213085215','783.636321308521474','test'),('2019-09-18 15:59:59','2019-09-19 03:59:59','VIBETH','4h','0.000110990000000','0.000096260000000','0.076694486766465','0.066516004109739','691.0035747947112','691.003574794711199','test'),('2019-09-19 07:59:59','2019-09-19 11:59:59','VIBETH','4h','0.000097200000000','0.000097500000000','0.076694486766465','0.076931198145374','789.0379296961419','789.037929696141873','test'),('2019-09-20 15:59:59','2019-09-21 03:59:59','VIBETH','4h','0.000100470000000','0.000100250000000','0.076694486766465','0.076526548206809','763.3570893447297','763.357089344729729','test'),('2019-09-21 07:59:59','2019-09-22 03:59:59','VIBETH','4h','0.000103310000000','0.000099630000000','0.076694486766465','0.073962556543828','742.3723431077824','742.372343107782399','test'),('2019-09-22 11:59:59','2019-09-22 15:59:59','VIBETH','4h','0.000100020000000','0.000099640000000','0.076694486766465','0.076403105992907','766.7915093627774','766.791509362777447','test'),('2019-09-24 11:59:59','2019-09-24 15:59:59','VIBETH','4h','0.000102940000000','0.000097160000000','0.076694486766465','0.072388151682822','745.0406719104818','745.040671910481819','test'),('2019-09-28 23:59:59','2019-10-04 23:59:59','VIBETH','4h','0.000111740000000','0.000120510000000','0.076694486766465','0.082713912656405','686.3655518745749','686.365551874574862','test'),('2019-10-05 19:59:59','2019-10-09 15:59:59','VIBETH','4h','0.000138740000000','0.000133810000000','0.076694486766465','0.073969217775845','552.7928987059607','552.792898705960738','test'),('2019-10-12 23:59:59','2019-10-13 23:59:59','VIBETH','4h','0.000139950000000','0.000135530000000','0.076694486766465','0.074272267177270','548.0134817182208','548.013481718220760','test'),('2019-10-14 07:59:59','2019-10-14 11:59:59','VIBETH','4h','0.000135500000000','0.000135330000000','0.076694486766465','0.076598264901149','566.0109724462362','566.010972446236224','test'),('2019-10-14 15:59:59','2019-10-14 19:59:59','VIBETH','4h','0.000137550000000','0.000133540000000','0.076694486766465','0.074458609689522','557.575330908506','557.575330908505975','test'),('2019-10-15 03:59:59','2019-10-16 11:59:59','VIBETH','4h','0.000136630000000','0.000133220000000','0.076694486766465','0.074780352243493','561.3297721325112','561.329772132511152','test'),('2019-10-20 23:59:59','2019-10-23 15:59:59','VIBETH','4h','0.000143250000000','0.000133610000000','0.076694486766465','0.071533335964170','535.3890873749738','535.389087374973769','test'),('2019-11-04 07:59:59','2019-11-04 11:59:59','VIBETH','4h','0.000131280000000','0.000129930000000','0.076694486766465','0.075905809457395','584.2054141260282','584.205414126028245','test'),('2019-11-08 11:59:59','2019-11-08 15:59:59','VIBETH','4h','0.000133770000000','0.000128500000000','0.076694486766465','0.073673032439940','573.3309917505046','573.330991750504609','test'),('2019-11-08 19:59:59','2019-11-08 23:59:59','VIBETH','4h','0.000128550000000','0.000130180000000','0.076694486766465','0.077666964506094','596.6121102019836','596.612110201983569','test'),('2019-11-09 03:59:59','2019-11-09 07:59:59','VIBETH','4h','0.000131010000000','0.000129760000000','0.076694486766465','0.075962725004324','585.4094097127318','585.409409712731758','test'),('2019-11-09 11:59:59','2019-11-09 15:59:59','VIBETH','4h','0.000130270000000','0.000130030000000','0.076694486766465','0.076553190406413','588.7348335492821','588.734833549282143','test'),('2019-11-09 19:59:59','2019-11-10 19:59:59','VIBETH','4h','0.000132490000000','0.000134430000000','0.076694486766465','0.077817494573295','578.8700035207562','578.870003520756200','test'),('2019-11-10 23:59:59','2019-11-14 11:59:59','VIBETH','4h','0.000136290000000','0.000135920000000','0.076694486766465','0.076486276625563','562.7301105471054','562.730110547105369','test'),('2019-11-14 15:59:59','2019-11-14 19:59:59','VIBETH','4h','0.000140590000000','0.000139110000000','0.076694486766465','0.075887118956419','545.5187905716266','545.518790571626596','test'),('2019-11-14 23:59:59','2019-11-25 15:59:59','VIBETH','4h','0.000151910000000','0.000189940000000','0.076694486766465','0.095894614024240','504.86792684132047','504.867926841320468','test'),('2019-12-17 15:59:59','2019-12-22 19:59:59','VIBETH','4h','0.000152570000000','0.000151810000000','0.076694486766465','0.076312446981825','502.68392715779635','502.683927157796347','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 18:35:47
