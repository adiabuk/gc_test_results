-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 11:59:59','2019-01-12 19:59:59','QLCETH','4h','0.000204350000000','0.000200520000000','0.072144500000000','0.070792342255933','353.04379740641053','353.043797406410533','test'),('2019-01-13 03:59:59','2019-01-14 23:59:59','QLCETH','4h','0.000203620000000','0.000258200000000','0.072144500000000','0.091482712405461','354.3094980846675','354.309498084667496','test'),('2019-01-15 07:59:59','2019-01-16 03:59:59','QLCETH','4h','0.000266420000000','0.000212790000000','0.076641013665349','0.061213277148298','287.66989589876323','287.669895898763230','test'),('2019-01-20 03:59:59','2019-01-20 15:59:59','QLCETH','4h','0.000219340000000','0.000211110000000','0.076641013665349','0.073765315924555','349.4164934136455','349.416493413645526','test'),('2019-01-20 19:59:59','2019-01-23 23:59:59','QLCETH','4h','0.000223070000000','0.000213370000000','0.076641013665349','0.073308347540124','343.5738273427579','343.573827342757909','test'),('2019-01-25 03:59:59','2019-01-25 11:59:59','QLCETH','4h','0.000219970000000','0.000215000000000','0.076641013665349','0.074909387362140','348.41575517274634','348.415755172746344','test'),('2019-01-25 19:59:59','2019-01-26 15:59:59','QLCETH','4h','0.000220410000000','0.000217350000000','0.076641013665349','0.075576989792494','347.72021988725106','347.720219887251062','test'),('2019-01-26 19:59:59','2019-01-27 03:59:59','QLCETH','4h','0.000218950000000','0.000217350000000','0.076641013665349','0.076080951450850','350.03888406188173','350.038884061881731','test'),('2019-02-27 11:59:59','2019-03-06 11:59:59','QLCETH','4h','0.000185370000000','0.000227070000000','0.076641013665349','0.093881830787025','413.4488518387496','413.448851838749590','test'),('2019-03-06 15:59:59','2019-03-06 19:59:59','QLCETH','4h','0.000232290000000','0.000229840000000','0.076641013665349','0.075832668564483','329.9367758635714','329.936775863571427','test'),('2019-03-07 15:59:59','2019-03-08 23:59:59','QLCETH','4h','0.000243380000000','0.000230410000000','0.076641013665349','0.072556725937353','314.9026775632715','314.902677563271482','test'),('2019-03-10 03:59:59','2019-03-16 07:59:59','QLCETH','4h','0.000235980000000','0.000252110000000','0.076641013665349','0.081879676053781','324.77758142787104','324.777581427871041','test'),('2019-03-20 15:59:59','2019-03-24 07:59:59','QLCETH','4h','0.000273000000000','0.000264990000000','0.076641013665349','0.074392315791871','280.7363137924872','280.736313792487181','test'),('2019-03-26 03:59:59','2019-03-31 11:59:59','QLCETH','4h','0.000306230000000','0.000319330000000','0.076641013665349','0.079919586238304','250.27271549276364','250.272715492763638','test'),('2019-03-31 15:59:59','2019-03-31 19:59:59','QLCETH','4h','0.000346790000000','0.000321700000000','0.076641013665349','0.071096093013474','221.0012216769486','221.001221676948603','test'),('2019-05-22 07:59:59','2019-05-25 11:59:59','QLCETH','4h','0.000173940000000','0.000174680000000','0.076641013665349','0.076967070639664','440.61753285816377','440.617532858163770','test'),('2019-06-04 23:59:59','2019-06-07 11:59:59','QLCETH','4h','0.000162500000000','0.000160930000000','0.076641013665349','0.075900543564090','471.6370071713785','471.637007171378514','test'),('2019-06-10 15:59:59','2019-06-12 15:59:59','QLCETH','4h','0.000171310000000','0.000161330000000','0.076641013665349','0.072176141116285','447.3820189443056','447.382018944305628','test'),('2019-07-15 23:59:59','2019-07-16 15:59:59','QLCETH','4h','0.000105860000000','0.000102760000000','0.076641013665349','0.074396661290868','723.9846369294256','723.984636929425619','test'),('2019-07-24 11:59:59','2019-07-24 15:59:59','QLCETH','4h','0.000102400000000','0.000100310000000','0.076641013665349','0.075076758601281','748.447399075674','748.447399075673957','test'),('2019-07-26 19:59:59','2019-07-29 03:59:59','QLCETH','4h','0.000102410000000','0.000102680000000','0.076641013665349','0.076843074730574','748.3743156464116','748.374315646411560','test'),('2019-08-21 19:59:59','2019-08-28 07:59:59','QLCETH','4h','0.000074380000000','0.000087840000000','0.076641013665349','0.090510172631948','1030.3981401633368','1030.398140163336848','test'),('2019-08-30 11:59:59','2019-09-01 03:59:59','QLCETH','4h','0.000091560000000','0.000084440000000','0.076641013665349','0.070681162012910','837.0578163537463','837.057816353746261','test'),('2019-09-10 23:59:59','2019-09-11 11:59:59','QLCETH','4h','0.000086710000000','0.000083810000000','0.076641013665349','0.074077769061157','883.8774497214739','883.877449721473909','test'),('2019-09-15 19:59:59','2019-09-17 11:59:59','QLCETH','4h','0.000102710000000','0.000086450000000','0.076641013665349','0.064507989790375','746.1884301952001','746.188430195200112','test'),('2019-09-19 03:59:59','2019-09-20 03:59:59','QLCETH','4h','0.000093450000000','0.000085890000000','0.076641013665349','0.070440841773321','820.1285571465919','820.128557146591902','test'),('2019-09-28 07:59:59','2019-09-29 07:59:59','QLCETH','4h','0.000087090000000','0.000083640000000','0.076641013665349','0.073604941818461','880.0208251848549','880.020825184854857','test'),('2019-09-29 19:59:59','2019-09-29 23:59:59','QLCETH','4h','0.000084660000000','0.000083070000000','0.076641013665349','0.075201618298849','905.280104717092','905.280104717091945','test'),('2019-10-02 03:59:59','2019-10-06 07:59:59','QLCETH','4h','0.000087090000000','0.000092390000000','0.076641013665349','0.081305124038829','880.0208251848549','880.020825184854857','test'),('2019-10-06 15:59:59','2019-10-08 11:59:59','QLCETH','4h','0.000102980000000','0.000100020000000','0.076641013665349','0.074438086879085','744.232022386376','744.232022386376002','test'),('2019-10-09 07:59:59','2019-10-09 15:59:59','QLCETH','4h','0.000104050000000','0.000092950000000','0.076641013665349','0.068464990102779','736.5786993306008','736.578699330600784','test'),('2019-10-10 23:59:59','2019-10-11 03:59:59','QLCETH','4h','0.000105500000000','0.000096870000000','0.076641013665349','0.070371706102013','726.455105832692','726.455105832691970','test'),('2019-10-11 07:59:59','2019-10-11 19:59:59','QLCETH','4h','0.000100870000000','0.000099810000000','0.076641013665349','0.075835625794969','759.7998777173491','759.799877717349091','test'),('2019-10-12 19:59:59','2019-10-13 11:59:59','QLCETH','4h','0.000100870000000','0.000099140000000','0.076641013665349','0.075326559876898','759.7998777173491','759.799877717349091','test'),('2019-10-19 19:59:59','2019-10-23 15:59:59','QLCETH','4h','0.000114700000000','0.000102990000000','0.076641013665349','0.068816547492540','668.1866928103663','668.186692810366253','test'),('2019-10-28 11:59:59','2019-10-28 23:59:59','QLCETH','4h','0.000110410000000','0.000101570000000','0.076641013665349','0.070504734697849','694.1492044683363','694.149204468336279','test'),('2019-10-29 11:59:59','2019-10-29 15:59:59','QLCETH','4h','0.000099090000000','0.000100720000000','0.076641013665349','0.077901734749964','773.4485181688264','773.448518168826354','test'),('2019-10-31 03:59:59','2019-10-31 11:59:59','QLCETH','4h','0.000102390000000','0.000098750000000','0.076641013665349','0.073916399057068','748.5204967804376','748.520496780437611','test'),('2019-10-31 15:59:59','2019-10-31 19:59:59','QLCETH','4h','0.000100290000000','0.000097690000000','0.076641013665349','0.074654109332615','764.1939741285173','764.193974128517311','test'),('2019-11-18 11:59:59','2019-11-18 19:59:59','QLCETH','4h','0.000094170000000','0.000091540000000','0.076641013665349','0.074500566963216','813.8580616475417','813.858061647541717','test'),('2019-11-25 19:59:59','2019-11-27 11:59:59','QLCETH','4h','0.000093810000000','0.000093240000000','0.076641013665349','0.076175334337034','816.9812777459654','816.981277745965372','test'),('2019-11-28 19:59:59','2019-12-01 03:59:59','QLCETH','4h','0.000094930000000','0.000092680000000','0.076641013665349','0.074824493274039','807.3423961376699','807.342396137669880','test'),('2019-12-01 07:59:59','2019-12-01 11:59:59','QLCETH','4h','0.000094940000000','0.000094060000000','0.076641013665349','0.075930627189412','807.2573590198969','807.257359019896853','test'),('2019-12-01 19:59:59','2019-12-01 23:59:59','QLCETH','4h','0.000095490000000','0.000093240000000','0.076641013665349','0.074835146236854','802.6077459979999','802.607745997999928','test'),('2019-12-04 07:59:59','2019-12-04 15:59:59','QLCETH','4h','0.000094350000000','0.000095060000000','0.076641013665349','0.077217750493143','812.3053912596608','812.305391259660837','test'),('2019-12-06 11:59:59','2019-12-10 03:59:59','QLCETH','4h','0.000095540000000','0.000098340000000','0.076641013665349','0.078887139249010','802.1877084503769','802.187708450376931','test'),('2019-12-15 03:59:59','2019-12-15 15:59:59','QLCETH','4h','0.000104140000000','0.000096630000000','0.076641013665349','0.071114088251226','735.942132373238','735.942132373237996','test'),('2019-12-15 23:59:59','2019-12-16 03:59:59','QLCETH','4h','0.000097480000000','0.000097210000000','0.051094009110233','0.050952488978311','524.1486367483861','524.148636748386139','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 20:04:26
