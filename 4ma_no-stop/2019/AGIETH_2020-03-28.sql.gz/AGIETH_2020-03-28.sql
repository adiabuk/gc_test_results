-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 11:59:59','2019-01-10 03:59:59','AGIETH','4h','0.000368360000000','0.000353480000000','0.072144500000000','0.069230203768053','195.8532413942882','195.853241394288204','test'),('2019-01-10 15:59:59','2019-01-15 15:59:59','AGIETH','4h','0.000366330000000','0.000359390000000','0.072144500000000','0.070777746444463','196.9385526710889','196.938552671088900','test'),('2019-01-15 19:59:59','2019-01-17 03:59:59','AGIETH','4h','0.000375760000000','0.000374530000000','0.072144500000000','0.071908344648180','191.99622099212263','191.996220992122630','test'),('2019-01-17 19:59:59','2019-01-18 11:59:59','AGIETH','4h','0.000408580000000','0.000385210000000','0.072144500000000','0.068017971621225','176.57374320818442','176.573743208184425','test'),('2019-01-18 23:59:59','2019-01-20 11:59:59','AGIETH','4h','0.000391890000000','0.000381770000000','0.072144500000000','0.070281471241930','184.09375079741764','184.093750797417641','test'),('2019-01-21 11:59:59','2019-01-23 23:59:59','AGIETH','4h','0.000391970000000','0.000398160000000','0.072144500000000','0.073283807740388','184.0561777687068','184.056177768706789','test'),('2019-01-24 07:59:59','2019-01-29 15:59:59','AGIETH','4h','0.000400460000000','0.000429550000000','0.072144500000000','0.077385181978225','180.1540728162613','180.154072816261305','test'),('2019-02-27 11:59:59','2019-02-28 11:59:59','AGIETH','4h','0.000343970000000','0.000340520000000','0.072144500000000','0.071420894671047','209.74067505887143','209.740675058871432','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','AGIETH','4h','0.000336420000000','0.000333620000000','0.072144500000000','0.071544046400333','214.4477141668153','214.447714166815302','test'),('2019-03-01 07:59:59','2019-03-01 15:59:59','AGIETH','4h','0.000342380000000','0.000337990000000','0.072144500000000','0.071219462453998','210.7147029616216','210.714702961621612','test'),('2019-03-01 19:59:59','2019-03-04 19:59:59','AGIETH','4h','0.000347120000000','0.000343450000000','0.072144500000000','0.071381736935354','207.83734731504953','207.837347315049527','test'),('2019-03-13 19:59:59','2019-03-16 07:59:59','AGIETH','4h','0.000393170000000','0.000386410000000','0.072144500000000','0.070904077739909','183.49441717323296','183.494417173232961','test'),('2019-03-16 23:59:59','2019-03-18 11:59:59','AGIETH','4h','0.000405000000000','0.000395760000000','0.072144500000000','0.070498536592593','178.1345679012346','178.134567901234590','test'),('2019-05-23 11:59:59','2019-05-24 15:59:59','AGIETH','4h','0.000207890000000','0.000195450000000','0.072144500000000','0.067827420871615','347.0320842753379','347.032084275337922','test'),('2019-05-24 19:59:59','2019-05-24 23:59:59','AGIETH','4h','0.000199630000000','0.000196280000000','0.072144500000000','0.070933839903822','361.391073485949','361.391073485948993','test'),('2019-06-01 23:59:59','2019-06-02 07:59:59','AGIETH','4h','0.000190830000000','0.000184310000000','0.072144500000000','0.069679572368076','378.05638526437144','378.056385264371443','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','AGIETH','4h','0.000188670000000','0.000190520000000','0.072144500000000','0.072851911485663','382.3845868447554','382.384586844755404','test'),('2019-06-02 23:59:59','2019-06-04 19:59:59','AGIETH','4h','0.000194150000000','0.000193030000000','0.072144500000000','0.071728317460726','371.59155292299766','371.591552922997664','test'),('2019-06-04 23:59:59','2019-06-06 19:59:59','AGIETH','4h','0.000193690000000','0.000192660000000','0.072144500000000','0.071760851721824','372.4740564820073','372.474056482007313','test'),('2019-06-07 07:59:59','2019-06-09 19:59:59','AGIETH','4h','0.000199380000000','0.000199920000000','0.072144500000000','0.072339895877219','361.8442170729261','361.844217072926085','test'),('2019-07-16 11:59:59','2019-07-25 07:59:59','AGIETH','4h','0.000111500000000','0.000147060000000','0.072144500000000','0.095153095695067','647.0358744394618','647.035874439461850','test'),('2019-08-04 07:59:59','2019-08-04 15:59:59','AGIETH','4h','0.000139360000000','0.000135950000000','0.073417971904927','0.071621507466094','526.8224160801342','526.822416080134190','test'),('2019-08-04 19:59:59','2019-08-04 23:59:59','AGIETH','4h','0.000139360000000','0.000136100000000','0.073417971904927','0.071700530828506','526.8224160801307','526.822416080130665','test'),('2019-08-05 07:59:59','2019-08-05 11:59:59','AGIETH','4h','0.000135860000000','0.000135400000000','0.073417971904927','0.073169390519116','540.3943169801782','540.394316980178246','test'),('2019-08-05 15:59:59','2019-08-05 23:59:59','AGIETH','4h','0.000144130000000','0.000135130000000','0.073417971904927','0.068833487431574','509.3871637058698','509.387163705869796','test'),('2019-08-06 03:59:59','2019-08-06 07:59:59','AGIETH','4h','0.000138910000000','0.000136050000000','0.073417971904927','0.071906378789614','528.5290612981571','528.529061298157103','test'),('2019-08-06 11:59:59','2019-08-06 15:59:59','AGIETH','4h','0.000142810000000','0.000137700000000','0.073417971904927','0.070790944130722','514.0954548345845','514.095454834584530','test'),('2019-08-07 19:59:59','2019-08-19 03:59:59','AGIETH','4h','0.000141060000000','0.000176120000000','0.073417971904927','0.091665767842732','520.4733581803985','520.473358180398463','test'),('2019-08-21 19:59:59','2019-08-23 11:59:59','AGIETH','4h','0.000183380000000','0.000177080000000','0.074858522823395','0.072286766395282','408.2153060497041','408.215306049704111','test'),('2019-08-24 19:59:59','2019-08-25 11:59:59','AGIETH','4h','0.000180230000000','0.000177460000000','0.074858522823395','0.073708003441379','415.34995740661935','415.349957406619353','test'),('2019-08-25 15:59:59','2019-08-28 15:59:59','AGIETH','4h','0.000185410000000','0.000183120000000','0.074858522823395','0.073933944767920','403.74587575316866','403.745875753168662','test'),('2019-09-01 11:59:59','2019-09-01 15:59:59','AGIETH','4h','0.000186770000000','0.000186560000000','0.074858522823395','0.074774353578908','400.8059261305081','400.805926130508112','test'),('2019-09-01 19:59:59','2019-09-01 23:59:59','AGIETH','4h','0.000186770000000','0.000182230000000','0.074858522823395','0.073038863918762','400.8059261305081','400.805926130508112','test'),('2019-09-02 03:59:59','2019-09-02 07:59:59','AGIETH','4h','0.000182960000000','0.000182040000000','0.074858522823395','0.074482102616806','409.15239846630413','409.152398466304135','test'),('2019-10-05 19:59:59','2019-10-06 07:59:59','AGIETH','4h','0.000124090000000','0.000122410000000','0.074858522823395','0.073845046166587','603.2599147666613','603.259914766661268','test'),('2019-10-06 11:59:59','2019-10-08 11:59:59','AGIETH','4h','0.000122600000000','0.000124750000000','0.074858522823395','0.076171294634735','610.5915401581974','610.591540158197404','test'),('2019-10-08 15:59:59','2019-10-09 15:59:59','AGIETH','4h','0.000132230000000','0.000120000000000','0.074858522823395','0.067934831269813','566.1235939151101','566.123593915110064','test'),('2019-10-12 15:59:59','2019-10-13 15:59:59','AGIETH','4h','0.000128650000000','0.000122240000000','0.074858522823395','0.071128688922906','581.87736357089','581.877363570889997','test'),('2019-10-18 19:59:59','2019-10-19 15:59:59','AGIETH','4h','0.000125480000000','0.000125410000000','0.074858522823395','0.074816762410599','596.5773256566385','596.577325656638550','test'),('2019-10-19 19:59:59','2019-10-20 03:59:59','AGIETH','4h','0.000125640000000','0.000124340000000','0.074858522823395','0.074083959947954','595.8175964931153','595.817596493115275','test'),('2019-10-20 07:59:59','2019-10-20 15:59:59','AGIETH','4h','0.000125550000000','0.000125720000000','0.074858522823395','0.074959884423395','596.2447058812825','596.244705881282471','test'),('2019-10-20 23:59:59','2019-10-23 03:59:59','AGIETH','4h','0.000125350000000','0.000125310000000','0.074858522823395','0.074834634982047','597.19603369282','597.196033692820038','test'),('2019-11-03 07:59:59','2019-11-03 11:59:59','AGIETH','4h','0.000121110000000','0.000120630000000','0.074858522823395','0.074561833111932','618.103565546982','618.103565546982054','test'),('2019-11-03 23:59:59','2019-11-04 07:59:59','AGIETH','4h','0.000120850000000','0.000119760000000','0.074858522823395','0.074183340449564','619.4333704873397','619.433370487339744','test'),('2019-11-15 07:59:59','2019-11-17 11:59:59','AGIETH','4h','0.000128170000000','0.000119760000000','0.074858522823395','0.069946607578449','584.0565095060857','584.056509506085717','test'),('2019-11-18 03:59:59','2019-11-21 11:59:59','AGIETH','4h','0.000125010000000','0.000120630000000','0.074858522823395','0.072235690010288','598.8202769650028','598.820276965002790','test'),('2019-11-23 19:59:59','2019-11-27 11:59:59','AGIETH','4h','0.000131100000000','0.000130400000000','0.074858522823395','0.074458820565757','571.003225197521','571.003225197521033','test'),('2019-11-27 15:59:59','2019-11-27 19:59:59','AGIETH','4h','0.000131330000000','0.000127460000000','0.074858522823395','0.072652610363740','570.0032195491891','570.003219549189112','test'),('2019-11-30 07:59:59','2019-11-30 11:59:59','AGIETH','4h','0.000131350000000','0.000132240000000','0.074858522823395','0.075365748444353','569.9164280425962','569.916428042596181','test'),('2019-11-30 19:59:59','2019-12-01 07:59:59','AGIETH','4h','0.000130960000000','0.000129420000000','0.074858522823395','0.073978237811574','571.6136440393632','571.613644039363180','test'),('2019-12-01 11:59:59','2019-12-01 15:59:59','AGIETH','4h','0.000130300000000','0.000128520000000','0.074858522823395','0.073835896801709','574.5090009470069','574.509000947006939','test'),('2019-12-01 23:59:59','2019-12-02 07:59:59','AGIETH','4h','0.000135270000000','0.000131100000000','0.074858522823395','0.072550841591980','553.4007749197531','553.400774919753076','test'),('2019-12-02 11:59:59','2019-12-02 19:59:59','AGIETH','4h','0.000133160000000','0.000129930000000','0.074858522823395','0.073042714557252','562.1697418398543','562.169741839854282','test'),('2019-12-02 23:59:59','2019-12-03 07:59:59','AGIETH','4h','0.000131460000000','0.000132260000000','0.074858522823395','0.075314074460841','569.4395468081166','569.439546808116575','test'),('2019-12-03 15:59:59','2019-12-05 11:59:59','AGIETH','4h','0.000132250000000','0.000135960000000','0.074858522823395','0.076958523728308','566.0379797610209','566.037979761020893','test'),('2019-12-05 15:59:59','2019-12-05 19:59:59','AGIETH','4h','0.000138170000000','0.000135950000000','0.074858522823395','0.073655758687418','541.7856468364696','541.785646836469596','test'),('2019-12-05 23:59:59','2019-12-06 03:59:59','AGIETH','4h','0.000136730000000','0.000135970000000','0.074858522823395','0.074442429227653','547.491573344511','547.491573344511039','test'),('2019-12-19 03:59:59','2019-12-22 23:59:59','AGIETH','4h','0.000133200000000','0.000134640000000','0.074858522823395','0.075667804151215','562.0009220975601','562.000922097560078','test'),('2019-12-25 03:59:59','2019-12-26 15:59:59','AGIETH','4h','0.000139330000000','0.000136160000000','0.074858522823395','0.073155361139980','537.2749789951554','537.274978995155379','test'),('2019-12-29 15:59:59','2019-12-29 19:59:59','AGIETH','4h','0.000136940000000','0.000134160000000','0.074858522823395','0.073338830305146','546.6519849817073','546.651984981707301','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:20:00
