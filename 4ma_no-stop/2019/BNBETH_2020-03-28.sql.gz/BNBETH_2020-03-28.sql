-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 07:59:59','2019-01-14 19:59:59','BNBETH','4h','0.045554000000000','0.046534000000000','0.072144500000000','0.073696539557448','1.5837138341309216','1.583713834130922','test'),('2019-01-15 23:59:59','2019-01-29 03:59:59','BNBETH','4h','0.048726000000000','0.059500000000000','0.072532509889362','0.088570462143764','1.4885791956935106','1.488579195693511','test'),('2019-02-01 11:59:59','2019-02-08 19:59:59','BNBETH','4h','0.061535000000000','0.070926000000000','0.076541997952963','0.088223250943558','1.2438774348413504','1.243877434841350','test'),('2019-02-10 03:59:59','2019-02-12 19:59:59','BNBETH','4h','0.077199000000000','0.074411000000000','0.079462311200611','0.076592572944580','1.0293178823639069','1.029317882363907','test'),('2019-02-15 23:59:59','2019-02-16 15:59:59','BNBETH','4h','0.076314000000000','0.074028000000000','0.079462311200611','0.077082002955668','1.0412547003251171','1.041254700325117','test'),('2019-02-22 23:59:59','2019-02-23 07:59:59','BNBETH','4h','0.072977000000000','0.072146000000000','0.079462311200611','0.078557461993221','1.0888678789291282','1.088867878929128','test'),('2019-02-28 07:59:59','2019-03-10 11:59:59','BNBETH','4h','0.073316000000000','0.105077000000000','0.079462311200611','0.113885935867022','1.083833149661888','1.083833149661888','test'),('2019-03-11 03:59:59','2019-03-15 15:59:59','BNBETH','4h','0.107641000000000','0.110700000000000','0.086529493440123','0.088988535259071','0.8038711405516764','0.803871140551676','test'),('2019-03-16 23:59:59','2019-03-19 15:59:59','BNBETH','4h','0.113143000000000','0.111646000000000','0.087144253894860','0.085991244445927','0.770213392740691','0.770213392740691','test'),('2019-03-23 19:59:59','2019-03-23 23:59:59','BNBETH','4h','0.110343000000000','0.110262000000000','0.087144253894860','0.087080283506476','0.7897578812870776','0.789757881287078','test'),('2019-03-24 11:59:59','2019-03-27 19:59:59','BNBETH','4h','0.124743000000000','0.119909000000000','0.087144253894860','0.083767268225702','0.698590332883288','0.698590332883288','test'),('2019-03-29 03:59:59','2019-03-29 11:59:59','BNBETH','4h','0.121099000000000','0.118494000000000','0.087144253894860','0.085269665488712','0.7196116722256997','0.719611672225700','test'),('2019-03-31 07:59:59','2019-04-02 15:59:59','BNBETH','4h','0.122900000000000','0.121304000000000','0.087144253894860','0.086012584007015','0.7090663457677787','0.709066345767779','test'),('2019-04-02 19:59:59','2019-04-02 23:59:59','BNBETH','4h','0.124288000000000','0.120740000000000','0.087144253894860','0.084656581610979','0.701147768850251','0.701147768850251','test'),('2019-04-14 07:59:59','2019-04-18 03:59:59','BNBETH','4h','0.117523000000000','0.113702000000000','0.087144253894860','0.084310951527389','0.7415080783749564','0.741508078374956','test'),('2019-04-18 07:59:59','2019-04-23 07:59:59','BNBETH','4h','0.120381000000000','0.136401000000000','0.087144253894860','0.098741191512887','0.7239037214748174','0.723903721474817','test'),('2019-04-25 03:59:59','2019-04-27 19:59:59','BNBETH','4h','0.141428000000000','0.140285000000000','0.087144253894860','0.086439967033688','0.6161739817777243','0.616173981777724','test'),('2019-04-28 07:59:59','2019-04-29 15:59:59','BNBETH','4h','0.144332000000000','0.140396000000000','0.087144253894860','0.084767790024546','0.6037763898155641','0.603776389815564','test'),('2019-05-02 19:59:59','2019-05-03 11:59:59','BNBETH','4h','0.146615000000000','0.140481000000000','0.087144253894860','0.083498359181556','0.5943747494789755','0.594374749478976','test'),('2019-05-03 19:59:59','2019-05-04 03:59:59','BNBETH','4h','0.140000000000000','0.139561000000000','0.087144253894860','0.086870994413004','0.6224589563918571','0.622458956391857','test'),('2019-05-04 07:59:59','2019-05-04 11:59:59','BNBETH','4h','0.139968000000000','0.140613000000000','0.087144253894860','0.087545831710948','0.6226012652524863','0.622601265252486','test'),('2019-05-05 15:59:59','2019-05-05 23:59:59','BNBETH','4h','0.141162000000000','0.140779000000000','0.087144253894860','0.086907814561033','0.6173350752671398','0.617335075267140','test'),('2019-05-21 15:59:59','2019-05-26 19:59:59','BNBETH','4h','0.124170000000000','0.126951000000000','0.087144253894860','0.089095998841962','0.7018140766276878','0.701814076627688','test'),('2019-06-06 07:59:59','2019-06-14 07:59:59','BNBETH','4h','0.129423000000000','0.131103000000000','0.087144253894860','0.088275446546424','0.6733289592642728','0.673328959264273','test'),('2019-06-19 07:59:59','2019-06-21 03:59:59','BNBETH','4h','0.131690000000000','0.130000000000000','0.087144253894860','0.086025916974195','0.6617378228784265','0.661737822878427','test'),('2019-06-21 07:59:59','2019-06-21 19:59:59','BNBETH','4h','0.130827000000000','0.128840000000000','0.087144253894860','0.085820707283770','0.6661029748817905','0.666102974881790','test'),('2019-07-12 19:59:59','2019-07-24 07:59:59','BNBETH','4h','0.117524000000000','0.136001000000000','0.087144253894860','0.100844982079872','0.7415017689566386','0.741501768956639','test'),('2019-08-08 11:59:59','2019-08-13 23:59:59','BNBETH','4h','0.139392000000000','0.140643000000000','0.088689942638296','0.089485907386922','0.6362627886700548','0.636262788670055','test'),('2019-08-15 11:59:59','2019-08-18 11:59:59','BNBETH','4h','0.148398000000000','0.145666000000000','0.088888933825453','0.087252492854475','0.5989901065071818','0.598990106507182','test'),('2019-10-09 19:59:59','2019-10-10 15:59:59','BNBETH','4h','0.091546000000000','0.090530000000000','0.088888933825453','0.087902422598675','0.9709756169079261','0.970975616907926','test'),('2019-10-10 19:59:59','2019-10-10 23:59:59','BNBETH','4h','0.090774000000000','0.091715000000000','0.088888933825453','0.089810392467022','0.9792334129315995','0.979233412931599','test'),('2019-10-11 11:59:59','2019-10-21 07:59:59','BNBETH','4h','0.091645000000000','0.103823000000000','0.088888933825453','0.100700701364614','0.9699267153194718','0.969926715319472','test'),('2019-10-22 07:59:59','2019-10-23 15:59:59','BNBETH','4h','0.107100000000000','0.104092000000000','0.091416502321196','0.088848987484761','0.8535621131764358','0.853562113176436','test'),('2019-10-28 03:59:59','2019-10-30 03:59:59','BNBETH','4h','0.111132000000000','0.106996000000000','0.091416502321196','0.088014254061465','0.8225938732425944','0.822593873242594','test'),('2019-10-30 07:59:59','2019-10-30 11:59:59','BNBETH','4h','0.108014000000000','0.107578000000000','0.091416502321196','0.091047498349377','0.8463393849056233','0.846339384905623','test'),('2019-10-30 23:59:59','2019-11-05 15:59:59','BNBETH','4h','0.109453000000000','0.108555000000000','0.091416502321196','0.090666481590065','0.835212395468338','0.835212395468338','test'),('2019-11-12 19:59:59','2019-11-15 23:59:59','BNBETH','4h','0.111114000000000','0.112719000000000','0.091416502321196','0.092736979364823','0.8227271299853843','0.822727129985384','test'),('2019-12-05 19:59:59','2019-12-08 03:59:59','BNBETH','4h','0.105403000000000','0.104823000000000','0.091416502321196','0.090913465677587','0.8673045579461306','0.867304557946131','test'),('2019-12-08 07:59:59','2019-12-08 15:59:59','BNBETH','4h','0.105239000000000','0.104066000000000','0.091416502321196','0.090397568682310','0.8686561286328832','0.868656128632883','test'),('2019-12-19 19:59:59','2019-12-22 11:59:59','BNBETH','4h','0.104447000000000','0.103542000000000','0.091416502321196','0.090624407434788','0.875242968406905','0.875242968406905','test'),('2019-12-24 07:59:59','2019-12-26 19:59:59','BNBETH','4h','0.104971000000000','0.103488000000000','0.091416502321196','0.090124996353430','0.8708738825122748','0.870873882512275','test'),('2019-12-27 07:59:59','2019-12-29 19:59:59','BNBETH','4h','0.105530000000000','0.104526000000000','0.091416502321196','0.090546776477071','0.8662608009210272','0.866260800921027','test'),('2019-12-30 03:59:59','2019-12-30 23:59:59','BNBETH','4h','0.106623000000000','0.105284000000000','0.091416502321196','0.090268469564586','0.8573806994850642','0.857380699485064','test'),('2019-12-31 19:59:59','2020-01-01 11:59:59','BNBETH','4h','0.106397000000000','0.104850000000000','0.091416502321196','0.090087317014365','0.8592018790115886','0.859201879011589','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 13:32:00
