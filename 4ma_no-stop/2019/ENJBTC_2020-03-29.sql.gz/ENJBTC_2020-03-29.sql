-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-22 23:59:59','2019-01-24 03:59:59','ENJBTC','4h','0.000009640000000','0.000009520000000','0.001467500000000','0.001449232365145','152.23029045643156','152.230290456431561','test'),('2019-01-24 07:59:59','2019-01-25 11:59:59','ENJBTC','4h','0.000009530000000','0.000009540000000','0.001467500000000','0.001469039874082','153.98740818467996','153.987408184679964','test'),('2019-01-25 15:59:59','2019-01-25 19:59:59','ENJBTC','4h','0.000009620000000','0.000009570000000','0.001467500000000','0.001459872661123','152.54677754677755','152.546777546777548','test'),('2019-02-12 15:59:59','2019-02-16 19:59:59','ENJBTC','4h','0.000008440000000','0.000008490000000','0.001467500000000','0.001476193720379','173.87440758293837','173.874407582938375','test'),('2019-02-17 15:59:59','2019-02-24 03:59:59','ENJBTC','4h','0.000008660000000','0.000009500000000','0.001467500000000','0.001609844110855','169.45727482678984','169.457274826789842','test'),('2019-02-25 03:59:59','2019-03-02 03:59:59','ENJBTC','4h','0.000011100000000','0.000019990000000','0.001499170682896','0.002699857833432','135.06042188252252','135.060421882522519','test'),('2019-03-02 19:59:59','2019-03-04 15:59:59','ENJBTC','4h','0.000022200000000','0.000020480000000','0.001799342470530','0.001659933954795','81.05146263648648','81.051462636486477','test'),('2019-03-05 03:59:59','2019-03-11 19:59:59','ENJBTC','4h','0.000021620000000','0.000044410000000','0.001799342470530','0.003696059163563','83.22583119935246','83.225831199352456','test'),('2019-03-18 11:59:59','2019-03-23 11:59:59','ENJBTC','4h','0.000050800000000','0.000046200000000','0.002238669514854','0.002035955346186','44.0682975365059','44.068297536505902','test'),('2019-04-14 11:59:59','2019-04-15 03:59:59','ENJBTC','4h','0.000033810000000','0.000030660000000','0.002238669514854','0.002030097820924','66.21323616841171','66.213236168411711','test'),('2019-04-15 07:59:59','2019-04-15 15:59:59','ENJBTC','4h','0.000031700000000','0.000030060000000','0.002238669514854','0.002122851912193','70.62048942757099','70.620489427570988','test'),('2019-04-17 15:59:59','2019-04-21 23:59:59','ENJBTC','4h','0.000034280000000','0.000035290000000','0.002238669514854','0.002304627980723','65.30541175186698','65.305411751866984','test'),('2019-05-22 07:59:59','2019-05-22 23:59:59','ENJBTC','4h','0.000022940000000','0.000020230000000','0.002238669514854','0.001974205940955','97.58803464925894','97.588034649258944','test'),('2019-05-23 03:59:59','2019-05-23 07:59:59','ENJBTC','4h','0.000020610000000','0.000020920000000','0.002238669514854','0.002272341885043','108.62054899825328','108.620548998253284','test'),('2019-05-23 15:59:59','2019-05-24 15:59:59','ENJBTC','4h','0.000021350000000','0.000020200000000','0.002238669514854','0.002118085442625','104.855714981452','104.855714981451996','test'),('2019-05-26 03:59:59','2019-05-26 11:59:59','ENJBTC','4h','0.000021160000000','0.000020660000000','0.002238669514854','0.002185770896828','105.79723605170133','105.797236051701333','test'),('2019-06-07 11:59:59','2019-06-07 19:59:59','ENJBTC','4h','0.000019580000000','0.000019000000000','0.002238669514854','0.002172355504710','114.33450024790604','114.334500247906035','test'),('2019-06-07 23:59:59','2019-06-09 19:59:59','ENJBTC','4h','0.000019070000000','0.000018990000000','0.002238669514854','0.002229278137760','117.39221367876247','117.392213678762474','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','ENJBTC','4h','0.000019390000000','0.000018980000000','0.002238669514854','0.002191333026917','115.4548486257865','115.454848625786497','test'),('2019-06-11 07:59:59','2019-06-11 11:59:59','ENJBTC','4h','0.000019850000000','0.000019310000000','0.002238669514854','0.002177768681704','112.77932064755667','112.779320647556673','test'),('2019-06-11 15:59:59','2019-06-12 15:59:59','ENJBTC','4h','0.000019600000000','0.000019290000000','0.002238669514854','0.002203261986813','114.21783239051022','114.217832390510225','test'),('2019-06-12 19:59:59','2019-06-12 23:59:59','ENJBTC','4h','0.000019370000000','0.000019260000000','0.002238669514854','0.002225956368409','115.57405858822924','115.574058588229235','test'),('2019-07-26 15:59:59','2019-07-27 11:59:59','ENJBTC','4h','0.000009080000000','0.000008850000000','0.002238669514854','0.002181963128465','246.54950604118946','246.549506041189460','test'),('2019-07-27 15:59:59','2019-07-27 19:59:59','ENJBTC','4h','0.000008900000000','0.000008880000000','0.002238669514854','0.002233638796843','251.53590054539328','251.535900545393275','test'),('2019-07-30 11:59:59','2019-07-31 07:59:59','ENJBTC','4h','0.000008970000000','0.000008870000000','0.002238669514854','0.002213712218144','249.57296709632107','249.572967096321065','test'),('2019-07-31 11:59:59','2019-07-31 15:59:59','ENJBTC','4h','0.000008940000000','0.000008560000000','0.002238669514854','0.002143513539950','250.41046027449664','250.410460274496643','test'),('2019-08-22 03:59:59','2019-08-25 19:59:59','ENJBTC','4h','0.000006360000000','0.000006800000000','0.002238669514854','0.002393546022171','351.99206208396225','351.992062083962253','test'),('2019-08-28 03:59:59','2019-08-28 15:59:59','ENJBTC','4h','0.000007100000000','0.000006710000000','0.002238669514854','0.002115700344320','315.3055654723944','315.305565472394392','test'),('2019-08-31 11:59:59','2019-08-31 23:59:59','ENJBTC','4h','0.000007010000000','0.000007010000000','0.002238669514854','0.002238669514854','319.35371110613414','319.353711106134142','test'),('2019-09-01 03:59:59','2019-09-03 11:59:59','ENJBTC','4h','0.000007360000000','0.000007220000000','0.002238669514854','0.002196086127343','304.16705364864134','304.167053648641343','test'),('2019-09-04 11:59:59','2019-09-06 15:59:59','ENJBTC','4h','0.000007900000000','0.000007520000000','0.002238669514854','0.002130986677431','283.3758879562025','283.375887956202519','test'),('2019-09-08 15:59:59','2019-09-09 11:59:59','ENJBTC','4h','0.000007930000000','0.000007630000000','0.002238669514854','0.002153978360446','282.30384802698615','282.303848026986145','test'),('2019-09-29 23:59:59','2019-09-30 19:59:59','ENJBTC','4h','0.000006880000000','0.000006860000000','0.002238669514854','0.002232161754636','325.3880108799419','325.388010879941874','test'),('2019-09-30 23:59:59','2019-10-01 19:59:59','ENJBTC','4h','0.000006900000000','0.000006850000000','0.002238669514854','0.002222447271993','324.4448572252174','324.444857225217390','test'),('2019-10-01 23:59:59','2019-10-02 07:59:59','ENJBTC','4h','0.000006970000000','0.000006980000000','0.002238669514854','0.002241881379294','321.18644402496415','321.186444024964146','test'),('2019-10-02 23:59:59','2019-10-07 03:59:59','ENJBTC','4h','0.000006940000000','0.000007620000000','0.002238669514854','0.002458020418327','322.5748580481268','322.574858048126828','test'),('2019-10-08 19:59:59','2019-10-09 15:59:59','ENJBTC','4h','0.000008050000000','0.000007490000000','0.002238669514854','0.002082935983386','278.09559190732926','278.095591907329265','test'),('2019-10-14 03:59:59','2019-10-14 15:59:59','ENJBTC','4h','0.000007730000000','0.000007580000000','0.002238669514854','0.002195228321163','289.60795793712805','289.607957937128049','test'),('2019-10-14 19:59:59','2019-10-14 23:59:59','ENJBTC','4h','0.000007610000000','0.000007570000000','0.002238669514854','0.002226902526602','294.1747062883049','294.174706288304890','test'),('2019-10-15 03:59:59','2019-10-15 07:59:59','ENJBTC','4h','0.000007620000000','0.000007580000000','0.002238669514854','0.002226917968844','293.78865024330713','293.788650243307131','test'),('2019-10-23 19:59:59','2019-10-25 15:59:59','ENJBTC','4h','0.000007680000000','0.000007180000000','0.002238669514854','0.002092922801647','291.49342641328127','291.493426413281270','test'),('2019-11-02 19:59:59','2019-11-03 07:59:59','ENJBTC','4h','0.000007080000000','0.000007060000000','0.002238669514854','0.002232345589671','316.1962591601695','316.196259160169518','test'),('2019-11-03 11:59:59','2019-11-03 15:59:59','ENJBTC','4h','0.000007090000000','0.000007100000000','0.002238669514854','0.002241827017696','315.7502841825106','315.750284182510597','test'),('2019-11-03 23:59:59','2019-11-04 23:59:59','ENJBTC','4h','0.000007200000000','0.000007140000000','0.002238669514854','0.002220013935564','310.9263215075','310.926321507500006','test'),('2019-11-05 07:59:59','2019-11-05 11:59:59','ENJBTC','4h','0.000007130000000','0.000007130000000','0.002238669514854','0.002238669514854','313.9788940889201','313.978894088920072','test'),('2019-11-05 19:59:59','2019-11-07 03:59:59','ENJBTC','4h','0.000007210000000','0.000007180000000','0.002238669514854','0.002229354662504','310.4950783431346','310.495078343134594','test'),('2019-11-10 15:59:59','2019-11-10 19:59:59','ENJBTC','4h','0.000007170000000','0.000007030000000','0.002238669514854','0.002194957697270','312.22726845941423','312.227268459414233','test'),('2019-11-14 07:59:59','2019-11-14 11:59:59','ENJBTC','4h','0.000007230000000','0.000007100000000','0.002238669514854','0.002198416812651','309.6361707958506','309.636170795850603','test'),('2019-11-14 15:59:59','2019-11-18 15:59:59','ENJBTC','4h','0.000007270000000','0.000007600000000','0.002238669514854','0.002340287250741','307.9325329922971','307.932532992297126','test'),('2019-11-18 23:59:59','2019-11-19 07:59:59','ENJBTC','4h','0.000007840000000','0.000007600000000','0.002238669514854','0.002170138815420','285.54458097627554','285.544580976275540','test'),('2019-11-19 19:59:59','2019-11-22 07:59:59','ENJBTC','4h','0.000007950000000','0.000007960000000','0.002238669514854','0.002241485451351','281.5936496671698','281.593649667169814','test'),('2019-11-23 19:59:59','2019-11-24 11:59:59','ENJBTC','4h','0.000008610000000','0.000007930000000','0.002238669514854','0.002061864024715','260.00807373449476','260.008073734494758','test'),('2019-11-28 23:59:59','2019-11-29 15:59:59','ENJBTC','4h','0.000008050000000','0.000007810000000','0.002238669514854','0.002171926572796','278.09559190732926','278.095591907329265','test'),('2019-11-29 19:59:59','2019-11-29 23:59:59','ENJBTC','4h','0.000007860000000','0.000007920000000','0.002238669514854','0.002255758595120','284.81800443435117','284.818004434351167','test'),('2019-11-30 07:59:59','2019-11-30 15:59:59','ENJBTC','4h','0.000007950000000','0.000007800000000','0.002238669514854','0.002196430467404','281.5936496671698','281.593649667169814','test'),('2019-11-30 23:59:59','2019-12-01 03:59:59','ENJBTC','4h','0.000007990000000','0.000007910000000','0.002238669514854','0.002216254801314','280.1839192558198','280.183919255819774','test'),('2019-12-01 07:59:59','2019-12-03 11:59:59','ENJBTC','4h','0.000007990000000','0.000008050000000','0.002238669514854','0.002255480550009','280.1839192558198','280.183919255819774','test'),('2019-12-03 15:59:59','2019-12-04 15:59:59','ENJBTC','4h','0.000008170000000','0.000008400000000','0.002238669514854','0.002301692034856','274.01095653047736','274.010956530477358','test'),('2019-12-04 19:59:59','2019-12-08 03:59:59','ENJBTC','4h','0.000011600000000','0.000011450000000','0.002238669514854','0.002209721202162','192.98875128051725','192.988751280517249','test'),('2019-12-08 15:59:59','2019-12-08 23:59:59','ENJBTC','4h','0.000012840000000','0.000012060000000','0.002238669514854','0.002102675572363','174.35120832196262','174.351208321962616','test'),('2019-12-12 11:59:59','2019-12-14 07:59:59','ENJBTC','4h','0.000012120000000','0.000011170000000','0.002238669514854','0.002063196244300','184.70870584603963','184.708705846039635','test'),('2019-12-16 07:59:59','2019-12-17 23:59:59','ENJBTC','4h','0.000011890000000','0.000011480000000','0.001492446343236','0.001440982676228','125.52113904423886','125.521139044238865','test'),('2019-12-18 03:59:59','2019-12-18 07:59:59','ENJBTC','4h','0.000011790000000','0.000011400000000','0.001655332751389','0.001600576197272','140.4014208133586','140.401420813358612','test'),('2019-12-18 11:59:59','2019-12-18 15:59:59','ENJBTC','4h','0.000011590000000','0.000011330000000','0.001655332751389','0.001618198453256','142.82422358835203','142.824223588352027','test'),('2019-12-29 23:59:59','2020-01-01 03:59:59','ENJBTC','4h','0.000011090000000','0.000011130000000','0.001655332751389','0.001661303293324','149.26354836690712','149.263548366907116','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 16:34:04
