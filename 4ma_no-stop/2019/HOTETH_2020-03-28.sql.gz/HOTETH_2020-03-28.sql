-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 19:59:59','2019-01-17 15:59:59','HOTETH','4h','0.000003720000000','0.000004790000000','0.072144500000000','0.092895740591398','19393.682795698925','19393.682795698925474','test'),('2019-01-19 03:59:59','2019-01-23 03:59:59','HOTETH','4h','0.000004920000000','0.000005840000000','0.077332310147849','0.091792823427528','15717.94921704258','15717.949217042580131','test'),('2019-01-23 19:59:59','2019-01-30 03:59:59','HOTETH','4h','0.000006530000000','0.000011490000000','0.080947438467769','0.142432782235018','12396.238662751799','12396.238662751798984','test'),('2019-02-01 23:59:59','2019-02-02 15:59:59','HOTETH','4h','0.000012060000000','0.000010390000000','0.096318774409582','0.082981100009582','7986.631377245564','7986.631377245564181','test'),('2019-02-04 19:59:59','2019-02-06 15:59:59','HOTETH','4h','0.000011230000000','0.000011220000000','0.096318774409582','0.096233005242699','8576.916688297597','8576.916688297596920','test'),('2019-02-16 15:59:59','2019-02-17 11:59:59','HOTETH','4h','0.000010950000000','0.000010210000000','0.096318774409582','0.089809560431218','8796.2351058979','8796.235105897900212','test'),('2019-03-16 07:59:59','2019-03-18 11:59:59','HOTETH','4h','0.000008510000000','0.000008340000000','0.096318774409582','0.094394662582364','11318.304865990835','11318.304865990834514','test'),('2019-03-20 03:59:59','2019-03-23 23:59:59','HOTETH','4h','0.000008560000000','0.000008530000000','0.096318774409582','0.095981208611418','11252.193272147431','11252.193272147431344','test'),('2019-04-15 19:59:59','2019-04-19 03:59:59','HOTETH','4h','0.000007910000000','0.000008110000000','0.096318774409582','0.098754141651291','12176.836208543868','12176.836208543867542','test'),('2019-04-20 23:59:59','2019-04-21 19:59:59','HOTETH','4h','0.000008460000000','0.000008140000000','0.096318774409582','0.092675511074941','11385.197920754374','11385.197920754373627','test'),('2019-04-27 03:59:59','2019-04-27 07:59:59','HOTETH','4h','0.000008120000000','0.000008100000000','0.096318774409582','0.096081536048967','11861.9180307367','11861.918030736700530','test'),('2019-04-27 19:59:59','2019-04-27 23:59:59','HOTETH','4h','0.000008060000000','0.000008140000000','0.096318774409582','0.097274792021588','11950.220150072208','11950.220150072207616','test'),('2019-04-28 03:59:59','2019-04-29 03:59:59','HOTETH','4h','0.000008200000000','0.000008040000000','0.096318774409582','0.094439383689395','11746.192001168538','11746.192001168537900','test'),('2019-05-21 03:59:59','2019-05-25 15:59:59','HOTETH','4h','0.000007480000000','0.000007710000000','0.096318774409582','0.099280447954262','12876.841498607218','12876.841498607218455','test'),('2019-05-27 03:59:59','2019-05-30 15:59:59','HOTETH','4h','0.000007890000000','0.000008280000000','0.096318774409582','0.101079778467850','12207.702713508492','12207.702713508491797','test'),('2019-06-02 03:59:59','2019-06-02 07:59:59','HOTETH','4h','0.000008590000000','0.000008430000000','0.096318774409582','0.094524711091126','11212.895740347147','11212.895740347146784','test'),('2019-07-01 19:59:59','2019-07-03 03:59:59','HOTETH','4h','0.000006340000000','0.000005850000000','0.096318774409582','0.088874578911050','15192.235711290536','15192.235711290535619','test'),('2019-07-15 23:59:59','2019-07-16 03:59:59','HOTETH','4h','0.000005720000000','0.000005760000000','0.096318774409582','0.096992332272586','16838.94657510175','16838.946575101748749','test'),('2019-07-16 11:59:59','2019-07-17 15:59:59','HOTETH','4h','0.000005740000000','0.000005610000000','0.096318774409582','0.094137338752222','16780.274287383625','16780.274287383625051','test'),('2019-07-17 19:59:59','2019-07-17 23:59:59','HOTETH','4h','0.000005720000000','0.000005660000000','0.096318774409582','0.095308437615076','16838.94657510175','16838.946575101748749','test'),('2019-07-18 03:59:59','2019-07-18 07:59:59','HOTETH','4h','0.000005680000000','0.000005670000000','0.096318774409582','0.096149199102523','16957.530705912326','16957.530705912326084','test'),('2019-07-19 23:59:59','2019-07-20 03:59:59','HOTETH','4h','0.000005740000000','0.000005590000000','0.096318774409582','0.093801733266474','16780.274287383625','16780.274287383625051','test'),('2019-07-20 23:59:59','2019-07-22 15:59:59','HOTETH','4h','0.000005710000000','0.000005760000000','0.096318774409582','0.097162196252048','16868.436849313835','16868.436849313835410','test'),('2019-07-23 11:59:59','2019-07-23 19:59:59','HOTETH','4h','0.000005880000000','0.000005770000000','0.096318774409582','0.094516892575389','16380.743947207824','16380.743947207824021','test'),('2019-07-24 03:59:59','2019-07-24 11:59:59','HOTETH','4h','0.000005850000000','0.000005750000000','0.096318774409582','0.094672299633350','16464.74776232171','16464.747762321709160','test'),('2019-08-25 03:59:59','2019-08-26 07:59:59','HOTETH','4h','0.000004530000000','0.000004340000000','0.096318774409582','0.092278914114257','21262.422606971744','21262.422606971744244','test'),('2019-08-26 11:59:59','2019-08-26 15:59:59','HOTETH','4h','0.000004400000000','0.000004410000000','0.096318774409582','0.096537680715058','21890.630547632274','21890.630547632274101','test'),('2019-08-26 19:59:59','2019-09-01 03:59:59','HOTETH','4h','0.000004520000000','0.000004610000000','0.096318774409582','0.098236626112428','21309.46336495177','21309.463364951770927','test'),('2019-09-05 11:59:59','2019-09-06 11:59:59','HOTETH','4h','0.000004670000000','0.000004600000000','0.096318774409582','0.094875024043700','20625.00522689122','20625.005226891218626','test'),('2019-09-06 19:59:59','2019-09-07 07:59:59','HOTETH','4h','0.000004620000000','0.000004580000000','0.096318774409582','0.095484845626815','20848.219569173594','20848.219569173594209','test'),('2019-09-10 11:59:59','2019-09-11 11:59:59','HOTETH','4h','0.000004740000000','0.000004620000000','0.096318774409582','0.093880324424529','20320.416542105908','20320.416542105907865','test'),('2019-09-11 15:59:59','2019-09-11 23:59:59','HOTETH','4h','0.000004680000000','0.000004590000000','0.096318774409582','0.094466490286321','20580.934702902137','20580.934702902137360','test'),('2019-10-02 07:59:59','2019-10-04 19:59:59','HOTETH','4h','0.000004160000000','0.000004050000000','0.096318774409582','0.093771883740098','23153.551540764904','23153.551540764903621','test'),('2019-10-04 23:59:59','2019-10-05 15:59:59','HOTETH','4h','0.000004080000000','0.000004040000000','0.096318774409582','0.095374472699684','23607.54274744657','23607.542747446568683','test'),('2019-10-09 19:59:59','2019-10-14 19:59:59','HOTETH','4h','0.000004300000000','0.000004310000000','0.096318774409582','0.096542771559372','22399.714978972555','22399.714978972555400','test'),('2019-10-16 03:59:59','2019-10-16 15:59:59','HOTETH','4h','0.000004430000000','0.000004380000000','0.096318774409582','0.095231655059587','21742.386999905644','21742.386999905644188','test'),('2019-10-17 03:59:59','2019-10-22 15:59:59','HOTETH','4h','0.000004380000000','0.000005260000000','0.096318774409582','0.115670491642557','21990.58776474475','21990.587764744748711','test'),('2019-10-23 23:59:59','2019-10-25 19:59:59','HOTETH','4h','0.000005350000000','0.000005250000000','0.096318774409582','0.094518423486038','18003.50923543589','18003.509235435889423','test'),('2019-11-07 15:59:59','2019-11-08 11:59:59','HOTETH','4h','0.000005210000000','0.000005140000000','0.096318774409582','0.095024664196785','18487.288754238387','18487.288754238386900','test'),('2019-11-08 15:59:59','2019-11-10 07:59:59','HOTETH','4h','0.000005150000000','0.000005090000000','0.096318774409582','0.095196613931024','18702.67464263728','18702.674642637281067','test'),('2019-11-11 23:59:59','2019-11-12 03:59:59','HOTETH','4h','0.000005190000000','0.000005140000000','0.096318774409582','0.095390847873844','18558.530714755685','18558.530714755685040','test'),('2019-11-12 11:59:59','2019-11-12 15:59:59','HOTETH','4h','0.000005240000000','0.000005230000000','0.096318774409582','0.096134959954602','18381.44549801183','18381.445498011831660','test'),('2019-11-12 19:59:59','2019-11-14 15:59:59','HOTETH','4h','0.000005530000000','0.000005380000000','0.096318774409582','0.093706149425597','17417.499893233635','17417.499893233634793','test'),('2019-11-14 19:59:59','2019-11-16 23:59:59','HOTETH','4h','0.000005410000000','0.000005380000000','0.096318774409582','0.095784659209529','17803.840001771165','17803.840001771164680','test'),('2019-11-17 03:59:59','2019-11-17 11:59:59','HOTETH','4h','0.000005420000000','0.000005380000000','0.096318774409582','0.095607934746043','17770.991588483765','17770.991588483764644','test'),('2019-11-23 07:59:59','2019-11-25 03:59:59','HOTETH','4h','0.000005290000000','0.000005420000000','0.096318774409582','0.098685776427209','18207.7078278983','18207.707827898299001','test'),('2019-11-25 11:59:59','2019-11-25 15:59:59','HOTETH','4h','0.000005390000000','0.000005380000000','0.096318774409582','0.096140075384703','17869.90248786308','17869.902487863080751','test'),('2019-11-25 19:59:59','2019-11-27 11:59:59','HOTETH','4h','0.000005430000000','0.000005500000000','0.096318774409582','0.097560452901050','17738.264163827258','17738.264163827258017','test'),('2019-11-27 19:59:59','2019-11-28 15:59:59','HOTETH','4h','0.000005410000000','0.000005430000000','0.096318774409582','0.096674851209617','17803.840001771165','17803.840001771164680','test'),('2019-12-18 11:59:59','2019-12-22 11:59:59','HOTETH','4h','0.000005060000000','0.000005020000000','0.096318774409582','0.095557361173143','19035.330910984587','19035.330910984586808','test'),('2019-12-24 23:59:59','2019-12-26 15:59:59','HOTETH','4h','0.000005040000000','0.000005110000000','0.096318774409582','0.097656535165271','19110.867938409127','19110.867938409126509','test'),('2019-12-27 07:59:59','2019-12-27 23:59:59','HOTETH','4h','0.000005100000000','0.000005020000000','0.096318774409582','0.094807891673745','18886.034197957255','18886.034197957254946','test'),('2020-01-04 15:59:59','2020-01-06 03:59:59','HOTETH','4h','0.000005000000000','0.000004920000000','0.096318774409582','0.094777674019029','19263.7548819164','19263.754881916400336','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:15:02
