-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-17 07:59:59','2019-01-20 11:59:59','MDAETH','4h','0.006290300000000','0.005878800000000','0.072144500000000','0.067424937856700','11.469166812393684','11.469166812393684','test'),('2019-01-21 23:59:59','2019-01-25 15:59:59','MDAETH','4h','0.005962800000000','0.006005500000000','0.072144500000000','0.072661131473469','12.0990977393171','12.099097739317100','test'),('2019-01-25 19:59:59','2019-01-29 23:59:59','MDAETH','4h','0.006237400000000','0.006508700000000','0.072144500000000','0.075282474612819','11.566437938884793','11.566437938884793','test'),('2019-01-30 11:59:59','2019-01-30 15:59:59','MDAETH','4h','0.006631000000000','0.006384800000000','0.072144500000000','0.069465872960338','10.879882370683156','10.879882370683156','test'),('2019-01-31 23:59:59','2019-02-05 03:59:59','MDAETH','4h','0.006664600000000','0.006794800000000','0.072144500000000','0.073553919004892','10.825030759535457','10.825030759535457','test'),('2019-02-25 07:59:59','2019-03-01 03:59:59','MDAETH','4h','0.006912100000000','0.006708800000000','0.072144500000000','0.070022572242878','10.43742133360339','10.437421333603391','test'),('2019-03-09 11:59:59','2019-03-09 15:59:59','MDAETH','4h','0.006285800000000','0.006317100000000','0.072144500000000','0.072503741918292','11.477377581214801','11.477377581214801','test'),('2019-03-09 19:59:59','2019-03-12 19:59:59','MDAETH','4h','0.006945000000000','0.007400400000000','0.072144500000000','0.076875184708423','10.387976961843053','10.387976961843053','test'),('2019-03-12 23:59:59','2019-03-14 23:59:59','MDAETH','4h','0.008161400000000','0.008398100000000','0.072302958694453','0.074399916363845','8.85913675281848','8.859136752818481','test'),('2019-03-23 11:59:59','2019-03-26 11:59:59','MDAETH','4h','0.008728700000000','0.008287400000000','0.072827198111801','0.069145247474623','8.343418620390294','8.343418620390294','test'),('2019-03-26 15:59:59','2019-03-27 03:59:59','MDAETH','4h','0.008635700000000','0.008342100000000','0.072827198111801','0.070351189755139','8.433270969556723','8.433270969556723','test'),('2019-03-30 03:59:59','2019-03-31 23:59:59','MDAETH','4h','0.008653900000000','0.008703600000000','0.072827198111801','0.073245450200011','8.415534974034943','8.415534974034943','test'),('2019-04-01 07:59:59','2019-04-02 07:59:59','MDAETH','4h','0.008627000000000','0.008505600000000','0.072827198111801','0.071802366553812','8.441775601228816','8.441775601228816','test'),('2019-06-02 15:59:59','2019-06-03 07:59:59','MDAETH','4h','0.004034700000000','0.003810900000000','0.072827198111801','0.068787560236018','18.05021392217538','18.050213922175381','test'),('2019-06-03 11:59:59','2019-06-03 15:59:59','MDAETH','4h','0.003823600000000','0.003849800000000','0.072827198111801','0.073326223268860','19.046761719793125','19.046761719793125','test'),('2019-06-03 19:59:59','2019-06-03 23:59:59','MDAETH','4h','0.003861200000000','0.003842300000000','0.072827198111801','0.072470719803422','18.861286157619652','18.861286157619652','test'),('2019-06-04 03:59:59','2019-06-04 07:59:59','MDAETH','4h','0.003901800000000','0.003835100000000','0.072827198111801','0.071582240883328','18.665025914142447','18.665025914142447','test'),('2019-06-04 15:59:59','2019-06-05 07:59:59','MDAETH','4h','0.003863600000000','0.003820000000000','0.072827198111801','0.072005356865897','18.84956986018247','18.849569860182470','test'),('2019-06-05 11:59:59','2019-06-06 15:59:59','MDAETH','4h','0.003876600000000','0.003898400000000','0.072827198111801','0.073236740731323','18.78635869364933','18.786358693649330','test'),('2019-06-06 19:59:59','2019-06-07 07:59:59','MDAETH','4h','0.003950200000000','0.003929700000000','0.072827198111801','0.072449253308679','18.436331859602298','18.436331859602298','test'),('2019-06-07 15:59:59','2019-06-11 23:59:59','MDAETH','4h','0.003972000000000','0.004296100000000','0.072827198111801','0.078769618783512','18.335145546777692','18.335145546777692','test'),('2019-07-08 11:59:59','2019-07-08 19:59:59','MDAETH','4h','0.003124000000000','0.002949200000000','0.072827198111801','0.068752231969054','23.312163288028486','23.312163288028486','test'),('2019-07-15 23:59:59','2019-07-18 11:59:59','MDAETH','4h','0.003130000000000','0.002966800000000','0.072827198111801','0.069029946120796','23.26747543508019','23.267475435080190','test'),('2019-07-19 15:59:59','2019-07-19 19:59:59','MDAETH','4h','0.003004200000000','0.002921600000000','0.072827198111801','0.070824825911536','24.241794192064777','24.241794192064777','test'),('2019-07-21 03:59:59','2019-07-24 19:59:59','MDAETH','4h','0.002979300000000','0.003176700000000','0.072827198111801','0.077652522485738','24.444399057429933','24.444399057429933','test'),('2019-07-26 19:59:59','2019-07-26 23:59:59','MDAETH','4h','0.003285100000000','0.003010500000000','0.072827198111801','0.066739606074572','22.168944054001702','22.168944054001702','test'),('2019-07-27 11:59:59','2019-07-28 07:59:59','MDAETH','4h','0.003126000000000','0.003106300000000','0.072827198111801','0.072368242320757','23.297248276327895','23.297248276327895','test'),('2019-07-28 15:59:59','2019-07-29 07:59:59','MDAETH','4h','0.003140600000000','0.003076200000000','0.072827198111801','0.071333830106197','23.188944186397823','23.188944186397823','test'),('2019-07-29 11:59:59','2019-07-29 15:59:59','MDAETH','4h','0.003087600000000','0.003038600000000','0.072827198111801','0.071671435478209','23.586992522283','23.586992522283001','test'),('2019-07-30 23:59:59','2019-07-31 11:59:59','MDAETH','4h','0.003236000000000','0.003105900000000','0.072827198111801','0.069899256679679','22.50531462045766','22.505314620457661','test'),('2019-07-31 15:59:59','2019-07-31 23:59:59','MDAETH','4h','0.003116500000000','0.003079600000000','0.072827198111801','0.071964909130468','23.368265076785175','23.368265076785175','test'),('2019-08-01 19:59:59','2019-08-03 03:59:59','MDAETH','4h','0.003181000000000','0.003130600000000','0.072827198111801','0.071673318581831','22.894435118453632','22.894435118453632','test'),('2019-08-03 11:59:59','2019-08-03 15:59:59','MDAETH','4h','0.003185600000000','0.003350000000000','0.072827198111801','0.076585608260464','22.861375600138434','22.861375600138434','test'),('2019-08-03 19:59:59','2019-08-05 07:59:59','MDAETH','4h','0.003378700000000','0.003214900000000','0.072827198111801','0.069296522097147','21.554798624264063','21.554798624264063','test'),('2019-08-15 19:59:59','2019-08-17 15:59:59','MDAETH','4h','0.003205500000000','0.003093400000000','0.072827198111801','0.070280347727046','22.71945035464077','22.719450354640770','test'),('2019-08-21 07:59:59','2019-08-25 15:59:59','MDAETH','4h','0.003528800000000','0.003405800000000','0.072827198111801','0.070288730256510','20.63795004301774','20.637950043017739','test'),('2019-08-25 19:59:59','2019-08-26 11:59:59','MDAETH','4h','0.003591900000000','0.003328800000000','0.072827198111801','0.067492741188386','20.27539689629472','20.275396896294719','test'),('2019-08-26 19:59:59','2019-08-28 07:59:59','MDAETH','4h','0.004002300000000','0.003418200000000','0.072827198111801','0.062198717883656','18.196336634385474','18.196336634385474','test'),('2019-08-31 19:59:59','2019-08-31 23:59:59','MDAETH','4h','0.003523000000000','0.003476400000000','0.072827198111801','0.071863886322982','20.671926798694578','20.671926798694578','test'),('2019-09-01 19:59:59','2019-09-01 23:59:59','MDAETH','4h','0.003539500000000','0.003450000000000','0.072827198111801','0.070985685403507','20.5755609865238','20.575560986523801','test'),('2019-09-10 07:59:59','2019-09-12 23:59:59','MDAETH','4h','0.003716000000000','0.003490100000000','0.072827198111801','0.068399947290096','19.598277209849567','19.598277209849567','test'),('2019-09-25 19:59:59','2019-09-28 23:59:59','MDAETH','4h','0.003474900000000','0.003899400000000','0.072827198111801','0.081723898908503','20.958070192466256','20.958070192466256','test'),('2019-09-29 07:59:59','2019-10-07 23:59:59','MDAETH','4h','0.004378200000000','0.005117600000000','0.072827198111801','0.085126414749658','16.634050091773105','16.634050091773105','test'),('2019-10-12 19:59:59','2019-10-15 19:59:59','MDAETH','4h','0.006333700000000','0.004939600000000','0.072827198111801','0.056797326648413','11.49836558596097','11.498365585960970','test'),('2019-11-10 11:59:59','2019-11-10 19:59:59','MDAETH','4h','0.004111100000000','0.004106300000000','0.072827198111801','0.072742167207436','17.71477174279414','17.714771742794142','test'),('2019-11-11 03:59:59','2019-11-11 11:59:59','MDAETH','4h','0.004098900000000','0.004000200000000','0.072827198111801','0.071073546045726','17.767498136524676','17.767498136524676','test'),('2019-11-11 15:59:59','2019-11-11 19:59:59','MDAETH','4h','0.004002900000000','0.004011500000000','0.072827198111801','0.072983663150588','18.1936091613083','18.193609161308299','test'),('2019-11-11 23:59:59','2019-11-12 03:59:59','MDAETH','4h','0.004019100000000','0.004008700000000','0.072827198111801','0.072638747249577','18.12027521380433','18.120275213804330','test'),('2019-11-23 11:59:59','2019-11-25 11:59:59','MDAETH','4h','0.003868300000000','0.003820100000000','0.072827198111801','0.071919752735540','18.826667557273478','18.826667557273478','test'),('2019-11-25 19:59:59','2019-11-26 23:59:59','MDAETH','4h','0.003929600000000','0.003940800000000','0.072827198111801','0.073034767487527','18.53297997551939','18.532979975519389','test'),('2019-11-27 03:59:59','2019-11-27 19:59:59','MDAETH','4h','0.003962300000000','0.003971400000000','0.072827198111801','0.072994456396842','18.380031323171135','18.380031323171135','test'),('2019-11-30 03:59:59','2019-11-30 11:59:59','MDAETH','4h','0.003984900000000','0.003900700000000','0.072827198111801','0.071288376540114','18.275790637607216','18.275790637607216','test'),('2019-12-13 11:59:59','2019-12-13 15:59:59','MDAETH','4h','0.003821800000000','0.003708800000000','0.072827198111801','0.070673900349848','19.055732406667275','19.055732406667275','test'),('2019-12-14 03:59:59','2019-12-14 15:59:59','MDAETH','4h','0.003689800000000','0.003635400000000','0.072827198111801','0.071753481493751','19.737437831806872','19.737437831806872','test'),('2019-12-17 03:59:59','2019-12-21 15:59:59','MDAETH','4h','0.003729500000000','0.003868900000000','0.072827198111801','0.075549308694127','19.527335597747953','19.527335597747953','test'),('2019-12-21 19:59:59','2019-12-21 23:59:59','MDAETH','4h','0.003890900000000','0.003842200000000','0.072827198111801','0.071915664906618','18.71731427479529','18.717314274795289','test'),('2019-12-25 03:59:59','2019-12-28 19:59:59','MDAETH','4h','0.003880000000000','0.003907200000000','0.072827198111801','0.073337739294440','18.769896420567267','18.769896420567267','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 19:12:14
