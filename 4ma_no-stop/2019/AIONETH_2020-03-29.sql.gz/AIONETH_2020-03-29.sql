-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-17 07:59:59','2019-01-20 15:59:59','AIONETH','4h','0.001098000000000','0.001107000000000','0.072144500000000','0.072735848360656','65.70537340619308','65.705373406193075','test'),('2019-01-22 19:59:59','2019-01-27 11:59:59','AIONETH','4h','0.001147000000000','0.001138000000000','0.072292337090164','0.071725091201924','63.02732091557454','63.027320915574542','test'),('2019-03-01 07:59:59','2019-03-03 15:59:59','AIONETH','4h','0.000873000000000','0.000888000000000','0.072292337090164','0.073534473466284','82.80909174131043','82.809091741310425','test'),('2019-03-03 19:59:59','2019-03-05 15:59:59','AIONETH','4h','0.000901000000000','0.000861000000000','0.072461059712134','0.069244142521806','80.42292975819534','80.422929758195338','test'),('2019-03-08 03:59:59','2019-03-15 03:59:59','AIONETH','4h','0.000904000000000','0.001053000000000','0.072461059712134','0.084404309598315','80.15603950457302','80.156039504573016','test'),('2019-03-15 07:59:59','2019-03-15 15:59:59','AIONETH','4h','0.001070000000000','0.001026000000000','0.074642642886097','0.071573225795454','69.75947933280116','69.759479332801163','test'),('2019-03-20 11:59:59','2019-03-20 15:59:59','AIONETH','4h','0.001052000000000','0.001037000000000','0.074642642886097','0.073578346647227','70.95308259134696','70.953082591346956','test'),('2019-03-21 07:59:59','2019-03-21 11:59:59','AIONETH','4h','0.001029000000000','0.001036000000000','0.074642642886097','0.075150415966955','72.53901155111467','72.539011551114669','test'),('2019-03-21 19:59:59','2019-03-21 23:59:59','AIONETH','4h','0.001018000000000','0.001024000000000','0.074642642886097','0.075082579877567','73.32283191168663','73.322831911686634','test'),('2019-03-22 03:59:59','2019-03-22 07:59:59','AIONETH','4h','0.001029000000000','0.001012000000000','0.074642642886097','0.073409479689728','72.53901155111467','72.539011551114669','test'),('2019-03-23 15:59:59','2019-03-25 19:59:59','AIONETH','4h','0.001028000000000','0.001016000000000','0.074642642886097','0.073771327988594','72.60957479192315','72.609574791923151','test'),('2019-03-27 19:59:59','2019-04-02 07:59:59','AIONETH','4h','0.001097000000000','0.001219000000000','0.074642642886097','0.082943830153284','68.04251858349771','68.042518583497710','test'),('2019-04-02 23:59:59','2019-04-07 11:59:59','AIONETH','4h','0.001249000000000','0.001325000000000','0.075395319365130','0.079983024946995','60.36454712980765','60.364547129807647','test'),('2019-04-27 23:59:59','2019-04-29 03:59:59','AIONETH','4h','0.001151000000000','0.001118000000000','0.076542245760596','0.074347724379102','66.50064792406258','66.500647924062577','test'),('2019-05-03 11:59:59','2019-05-03 15:59:59','AIONETH','4h','0.001144000000000','0.001134000000000','0.076542245760596','0.075873170185766','66.90755748303846','66.907557483038460','test'),('2019-05-03 19:59:59','2019-05-06 03:59:59','AIONETH','4h','0.001210000000000','0.001150000000000','0.076542245760596','0.072746762499740','63.2580543476','63.258054347600002','test'),('2019-06-01 15:59:59','2019-06-03 15:59:59','AIONETH','4h','0.000846000000000','0.000842000000000','0.076542245760596','0.076180343889388','90.47546780212294','90.475467802122935','test'),('2019-07-20 23:59:59','2019-07-23 07:59:59','AIONETH','4h','0.000411000000000','0.000395000000000','0.076542245760596','0.073562498966996','186.23417459999027','186.234174599990268','test'),('2019-07-23 11:59:59','2019-07-23 15:59:59','AIONETH','4h','0.000398000000000','0.000397000000000','0.076542245760596','0.076349928560192','192.3172004035075','192.317200403507513','test'),('2019-07-23 19:59:59','2019-07-27 23:59:59','AIONETH','4h','0.000408000000000','0.000458000000000','0.076542245760596','0.085922422937140','187.60354353087254','187.603543530872543','test'),('2019-07-28 15:59:59','2019-07-31 19:59:59','AIONETH','4h','0.000495000000000','0.000508000000000','0.076542245760596','0.078552446154309','154.63079951635555','154.630799516355552','test'),('2019-08-17 11:59:59','2019-08-18 19:59:59','AIONETH','4h','0.000420000000000','0.000430000000000','0.076841578632562','0.078671140028575','182.95613960133872','182.956139601338720','test'),('2019-08-23 03:59:59','2019-08-23 15:59:59','AIONETH','4h','0.000423000000000','0.000482000000000','0.077298968981566','0.088080621865520','182.73987938904378','182.739879389043779','test'),('2019-08-23 19:59:59','2019-08-26 03:59:59','AIONETH','4h','0.000527000000000','0.000487000000000','0.079994382202554','0.073922702338983','151.79199658928655','151.791996589286555','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','AIONETH','4h','0.000400000000000','0.000374000000000','0.079994382202554','0.074794747359388','199.985955506385','199.985955506385011','test'),('2019-09-26 19:59:59','2019-09-29 11:59:59','AIONETH','4h','0.000378000000000','0.000378000000000','0.079994382202554','0.079994382202554','211.62534974220634','211.625349742206339','test'),('2019-10-02 23:59:59','2019-10-03 07:59:59','AIONETH','4h','0.000393000000000','0.000386000000000','0.079994382202554','0.078569545878335','203.5480463169313','203.548046316931305','test'),('2019-10-03 11:59:59','2019-10-08 03:59:59','AIONETH','4h','0.000407000000000','0.000409000000000','0.079994382202554','0.080387474989790','196.5463936180688','196.546393618068805','test'),('2019-10-08 15:59:59','2019-10-09 15:59:59','AIONETH','4h','0.000437000000000','0.000384000000000','0.079994382202554','0.070292546374784','183.0535061843341','183.053506184334111','test'),('2019-10-21 03:59:59','2019-10-24 07:59:59','AIONETH','4h','0.000386000000000','0.000395000000000','0.079994382202554','0.081859536191733','207.23933213096893','207.239332130968933','test'),('2019-10-24 19:59:59','2019-10-25 15:59:59','AIONETH','4h','0.000402000000000','0.000392000000000','0.079994382202554','0.078004472197515','198.99100050386568','198.991000503865678','test'),('2019-10-27 19:59:59','2019-11-06 07:59:59','AIONETH','4h','0.000403000000000','0.000445000000000','0.079994382202554','0.088331265707535','198.497226309067','198.497226309067003','test'),('2019-11-06 15:59:59','2019-11-08 19:59:59','AIONETH','4h','0.000477000000000','0.000459000000000','0.079994382202554','0.076975726270382','167.70310734288051','167.703107342880514','test'),('2019-11-15 07:59:59','2019-11-15 11:59:59','AIONETH','4h','0.000457000000000','0.000452000000000','0.079994382202554','0.079119170143445','175.0424118217812','175.042411821781201','test'),('2019-11-18 07:59:59','2019-11-19 11:59:59','AIONETH','4h','0.000457000000000','0.000453000000000','0.079994382202554','0.079294212555267','175.0424118217812','175.042411821781201','test'),('2019-11-29 23:59:59','2019-11-30 15:59:59','AIONETH','4h','0.000436000000000','0.000422000000000','0.079994382202554','0.077425755251096','183.47335367558256','183.473353675582558','test'),('2019-12-05 19:59:59','2019-12-06 07:59:59','AIONETH','4h','0.000443000000000','0.000422000000000','0.079994382202554','0.076202323452546','180.57422619086682','180.574226190866824','test'),('2019-12-06 11:59:59','2019-12-07 15:59:59','AIONETH','4h','0.000431000000000','0.000429000000000','0.079994382202554','0.079623178572844','185.6018148551137','185.601814855113702','test'),('2019-12-07 19:59:59','2019-12-08 23:59:59','AIONETH','4h','0.000430000000000','0.000432000000000','0.079994382202554','0.080366449096519','186.03344698268373','186.033446982683728','test'),('2019-12-09 07:59:59','2019-12-09 15:59:59','AIONETH','4h','0.000434000000000','0.000425000000000','0.079994382202554','0.078335512525543','184.31885300127652','184.318853001276523','test'),('2019-12-20 07:59:59','2019-12-22 19:59:59','AIONETH','4h','0.000414000000000','0.000424000000000','0.079994382202554','0.081926613656722','193.2231454167971','193.223145416797109','test'),('2019-12-25 07:59:59','2019-12-25 19:59:59','AIONETH','4h','0.000431000000000','0.000424000000000','0.079994382202554','0.078695169498568','185.6018148551137','185.601814855113702','test'),('2019-12-25 23:59:59','2019-12-26 19:59:59','AIONETH','4h','0.000426000000000','0.000427000000000','0.079994382202554','0.080182162442466','187.7802399120986','187.780239912098608','test'),('2019-12-26 23:59:59','2019-12-28 11:59:59','AIONETH','4h','0.000432000000000','0.000430000000000','0.079994382202554','0.079624037840505','185.17218102443059','185.172181024430586','test'),('2019-12-29 03:59:59','2019-12-29 15:59:59','AIONETH','4h','0.000435000000000','0.000426000000000','0.079994382202554','0.078339326019053','183.89513150012414','183.895131500124137','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 10:16:38
