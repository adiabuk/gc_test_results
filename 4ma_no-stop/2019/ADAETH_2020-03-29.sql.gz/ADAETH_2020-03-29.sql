-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 19:59:59','2019-01-14 15:59:59','ADAETH','4h','0.000318900000000','0.000334790000000','0.072144500000000','0.075739282392600','226.22922546252744','226.229225462527438','test'),('2019-01-15 23:59:59','2019-01-20 15:59:59','ADAETH','4h','0.000352520000000','0.000363170000000','0.073043195598150','0.075249907368036','207.20298308790993','207.202983087909928','test'),('2019-01-21 03:59:59','2019-01-25 11:59:59','ADAETH','4h','0.000367100000000','0.000365110000000','0.073594873540621','0.073195925574547','200.47636486140425','200.476364861404249','test'),('2019-01-26 07:59:59','2019-01-26 19:59:59','ADAETH','4h','0.000370580000000','0.000366590000000','0.073594873540621','0.072802484460187','198.59375449463272','198.593754494632719','test'),('2019-03-02 07:59:59','2019-03-03 03:59:59','ADAETH','4h','0.000319190000000','0.000317160000000','0.073594873540621','0.073126821304375','230.5676040622231','230.567604062223097','test'),('2019-03-03 15:59:59','2019-03-04 07:59:59','ADAETH','4h','0.000319330000000','0.000318480000000','0.073594873540621','0.073398976999396','230.46651908878277','230.466519088782775','test'),('2019-03-04 11:59:59','2019-03-05 03:59:59','ADAETH','4h','0.000320580000000','0.000318400000000','0.073594873540621','0.073094415544743','229.56788801740908','229.567888017409075','test'),('2019-03-09 15:59:59','2019-03-18 11:59:59','ADAETH','4h','0.000335920000000','0.000359840000000','0.073594873540621','0.078835375371687','219.0845247101125','219.084524710112504','test'),('2019-03-18 19:59:59','2019-03-19 11:59:59','ADAETH','4h','0.000361830000000','0.000360420000000','0.074316063043424','0.074026463925354','205.38944543963672','205.389445439636717','test'),('2019-03-19 15:59:59','2019-04-01 11:59:59','ADAETH','4h','0.000369270000000','0.000490290000000','0.074316063043424','0.098671493892167','201.25128779327864','201.251287793278635','test'),('2019-04-01 19:59:59','2019-04-06 11:59:59','ADAETH','4h','0.000507870000000','0.000541550000000','0.080332520976092','0.085659867160105','158.17536175811134','158.175361758111336','test'),('2019-04-06 15:59:59','2019-04-06 19:59:59','ADAETH','4h','0.000549540000000','0.000541140000000','0.081664357522095','0.080416076044522','148.60493780633848','148.604937806338484','test'),('2019-05-29 19:59:59','2019-05-30 03:59:59','ADAETH','4h','0.000343520000000','0.000332720000000','0.081664357522095','0.079096894022914','237.72810177601013','237.728101776010135','test'),('2019-05-30 07:59:59','2019-05-30 19:59:59','ADAETH','4h','0.000335800000000','0.000331130000000','0.081664357522095','0.080528644152148','243.19344110212927','243.193441102129270','test'),('2019-06-01 23:59:59','2019-06-04 07:59:59','ADAETH','4h','0.000342000000000','0.000344290000000','0.081664357522095','0.082211174418953','238.78467111723683','238.784671117236826','test'),('2019-06-04 11:59:59','2019-06-04 15:59:59','ADAETH','4h','0.000345030000000','0.000345270000000','0.081664357522095','0.081721162570367','236.6877011335101','236.687701133510103','test'),('2019-06-08 23:59:59','2019-06-09 19:59:59','ADAETH','4h','0.000343960000000','0.000341420000000','0.081664357522095','0.081061300573304','237.42399558697232','237.423995586972325','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','ADAETH','4h','0.000345530000000','0.000342800000000','0.081664357522095','0.081019135121622','236.3452016383382','236.345201638338210','test'),('2019-06-10 15:59:59','2019-06-11 07:59:59','ADAETH','4h','0.000343010000000','0.000340010000000','0.081664357522095','0.080950112827870','238.08156474182968','238.081564741829681','test'),('2019-06-11 11:59:59','2019-06-13 19:59:59','ADAETH','4h','0.000345430000000','0.000348810000000','0.081664357522095','0.082463435565185','236.41362221606406','236.413622216064056','test'),('2019-07-17 11:59:59','2019-07-18 07:59:59','ADAETH','4h','0.000260840000000','0.000260380000000','0.081664357522095','0.081520339716313','313.08218648249886','313.082186482498855','test'),('2019-07-18 11:59:59','2019-07-18 15:59:59','ADAETH','4h','0.000263410000000','0.000260690000000','0.081664357522095','0.080821082580141','310.02755218896397','310.027552188963966','test'),('2019-07-19 03:59:59','2019-07-19 07:59:59','ADAETH','4h','0.000261060000000','0.000258940000000','0.081664357522095','0.081001182627638','312.818346441795','312.818346441794972','test'),('2019-07-19 11:59:59','2019-07-23 07:59:59','ADAETH','4h','0.000262740000000','0.000267970000000','0.081664357522095','0.083289936382720','310.81813778676633','310.818137786766329','test'),('2019-07-24 23:59:59','2019-07-25 03:59:59','ADAETH','4h','0.000272230000000','0.000268730000000','0.081664357522095','0.080614417209391','299.9829464867759','299.982946486775916','test'),('2019-07-26 11:59:59','2019-07-31 11:59:59','ADAETH','4h','0.000283050000000','0.000282960000000','0.081664357522095','0.081638391112708','288.5156598554849','288.515659855484898','test'),('2019-08-14 03:59:59','2019-08-14 15:59:59','ADAETH','4h','0.000254700000000','0.000253500000000','0.081664357522095','0.081279602009623','320.6295937263251','320.629593726325083','test'),('2019-08-14 19:59:59','2019-08-16 03:59:59','ADAETH','4h','0.000254300000000','0.000245360000000','0.081664357522095','0.078793420218723','321.13392655169093','321.133926551690934','test'),('2019-08-17 03:59:59','2019-08-19 07:59:59','ADAETH','4h','0.000253540000000','0.000252290000000','0.081664357522095','0.081261736843296','322.0965430389485','322.096543038948482','test'),('2019-08-22 03:59:59','2019-08-23 15:59:59','ADAETH','4h','0.000257100000000','0.000254460000000','0.081664357522095','0.080825797024785','317.63655201126016','317.636552011260164','test'),('2019-08-23 19:59:59','2019-08-26 11:59:59','ADAETH','4h','0.000255420000000','0.000258530000000','0.081664357522095','0.082658704683217','319.725775280303','319.725775280303026','test'),('2019-08-26 19:59:59','2019-08-27 03:59:59','ADAETH','4h','0.000266100000000','0.000263000000000','0.081664357522095','0.080712987705039','306.8934893727734','306.893489372773388','test'),('2019-08-28 19:59:59','2019-08-29 03:59:59','ADAETH','4h','0.000267440000000','0.000260630000000','0.081664357522095','0.079584884463744','305.35580886215604','305.355808862156039','test'),('2019-08-30 03:59:59','2019-08-31 23:59:59','ADAETH','4h','0.000265490000000','0.000260950000000','0.081664357522095','0.080267859789034','307.59861961691587','307.598619616915869','test'),('2019-09-10 15:59:59','2019-09-10 19:59:59','ADAETH','4h','0.000261780000000','0.000258150000000','0.081664357522095','0.080531950089116','311.95797051759115','311.957970517591150','test'),('2019-09-10 23:59:59','2019-09-11 03:59:59','ADAETH','4h','0.000258460000000','0.000253610000000','0.081664357522095','0.080131926453527','315.9651687769674','315.965168776967403','test'),('2019-10-06 15:59:59','2019-10-08 07:59:59','ADAETH','4h','0.000227500000000','0.000226540000000','0.081664357522095','0.081319751881562','358.96420888832967','358.964208888329665','test'),('2019-10-08 15:59:59','2019-10-09 15:59:59','ADAETH','4h','0.000227900000000','0.000222220000000','0.081664357522095','0.079629019432031','358.33417078584904','358.334170785849039','test'),('2019-10-13 23:59:59','2019-10-14 19:59:59','ADAETH','4h','0.000228200000000','0.000223940000000','0.081664357522095','0.080139860751525','357.86309168315074','357.863091683150742','test'),('2019-10-15 03:59:59','2019-10-15 07:59:59','ADAETH','4h','0.000223770000000','0.000223900000000','0.081664357522095','0.081711800729307','364.9477477860973','364.947747786097295','test'),('2019-10-20 15:59:59','2019-10-20 19:59:59','ADAETH','4h','0.000225560000000','0.000223460000000','0.081664357522095','0.080904049174886','362.0515939089156','362.051593908915606','test'),('2019-10-20 23:59:59','2019-10-21 03:59:59','ADAETH','4h','0.000225150000000','0.000222700000000','0.081664357522095','0.080775715834646','362.71089283630914','362.710892836309142','test'),('2019-10-21 11:59:59','2019-10-21 15:59:59','ADAETH','4h','0.000222430000000','0.000223720000000','0.081664357522095','0.082137976283968','367.14632703365106','367.146327033651062','test'),('2019-10-21 19:59:59','2019-10-23 23:59:59','ADAETH','4h','0.000224220000000','0.000224240000000','0.081664357522095','0.081671641828359','364.2153131839042','364.215313183904186','test'),('2019-10-24 03:59:59','2019-10-24 07:59:59','ADAETH','4h','0.000225920000000','0.000228340000000','0.081664357522095','0.082539126224306','361.4746703350522','361.474670335052224','test'),('2019-10-24 11:59:59','2019-10-25 19:59:59','ADAETH','4h','0.000231510000000','0.000228630000000','0.081664357522095','0.080648447411674','352.7465661185046','352.746566118504575','test'),('2019-10-27 23:59:59','2019-10-29 19:59:59','ADAETH','4h','0.000229840000000','0.000226390000000','0.081664357522095','0.080438539416233','355.30959590191003','355.309595901910029','test'),('2019-11-01 15:59:59','2019-11-01 23:59:59','ADAETH','4h','0.000230740000000','0.000230710000000','0.081664357522095','0.081653739810707','353.92371293271646','353.923712932716455','test'),('2019-11-02 11:59:59','2019-11-03 07:59:59','ADAETH','4h','0.000230940000000','0.000229870000000','0.081664357522095','0.081285987111821','353.61720586340607','353.617205863406070','test'),('2019-11-03 15:59:59','2019-11-03 23:59:59','ADAETH','4h','0.000229960000000','0.000229520000000','0.081664357522095','0.081508102880811','355.124184736889','355.124184736888992','test'),('2019-11-04 23:59:59','2019-11-06 03:59:59','ADAETH','4h','0.000232600000000','0.000230970000000','0.081664357522095','0.081092075051067','351.09354050771714','351.093540507717137','test'),('2019-11-06 07:59:59','2019-11-07 07:59:59','ADAETH','4h','0.000232270000000','0.000230870000000','0.081664357522095','0.081172128217704','351.59236027939465','351.592360279394654','test'),('2019-11-11 23:59:59','2019-11-13 11:59:59','ADAETH','4h','0.000233490000000','0.000232430000000','0.081664357522095','0.081293616938030','349.75526798618785','349.755267986187846','test'),('2019-11-15 11:59:59','2019-11-19 07:59:59','ADAETH','4h','0.000236520000000','0.000237650000000','0.081664357522095','0.082054517863715','345.27463860178847','345.274638601788467','test'),('2019-11-22 15:59:59','2019-11-25 15:59:59','ADAETH','4h','0.000245800000000','0.000246510000000','0.081664357522095','0.081900247244799','332.2390460622254','332.239046062225384','test'),('2019-11-25 19:59:59','2019-11-26 07:59:59','ADAETH','4h','0.000248040000000','0.000246250000000','0.081664357522095','0.081075020318561','329.2386611921263','329.238661192126301','test'),('2019-11-26 15:59:59','2019-11-28 03:59:59','ADAETH','4h','0.000249250000000','0.000253170000000','0.081664357522095','0.082948707698571','327.6403511418054','327.640351141805411','test'),('2019-11-28 07:59:59','2019-12-01 15:59:59','ADAETH','4h','0.000254130000000','0.000259700000000','0.081664357522095','0.083454270052682','321.3487487588833','321.348748758883289','test'),('2019-12-07 11:59:59','2019-12-08 15:59:59','ADAETH','4h','0.000259510000000','0.000257990000000','0.081664357522095','0.081186033667779','314.6867462606258','314.686746260625796','test'),('2019-12-08 23:59:59','2019-12-09 03:59:59','ADAETH','4h','0.000257510000000','0.000255510000000','0.081664357522095','0.081030095881599','317.13082024812627','317.130820248126270','test'),('2019-12-14 07:59:59','2019-12-14 11:59:59','ADAETH','4h','0.000257710000000','0.000254320000000','0.081664357522095','0.080590118369560','316.88470576265956','316.884705762659564','test'),('2019-12-14 23:59:59','2019-12-15 03:59:59','ADAETH','4h','0.000255440000000','0.000254760000000','0.081664357522095','0.081446961017573','319.7007419436854','319.700741943685387','test'),('2019-12-16 19:59:59','2019-12-16 23:59:59','ADAETH','4h','0.000256510000000','0.000256820000000','0.081664357522095','0.081763051338445','318.36714951500915','318.367149515009146','test'),('2019-12-17 07:59:59','2019-12-17 11:59:59','ADAETH','4h','0.000256000000000','0.000256290000000','0.081664357522095','0.081756867927101','319.0013965706836','319.001396570683596','test'),('2019-12-17 15:59:59','2019-12-18 15:59:59','ADAETH','4h','0.000257320000000','0.000257510000000','0.081664357522095','0.081724656868936','317.3649833751554','317.364983375155418','test'),('2019-12-18 19:59:59','2019-12-18 23:59:59','ADAETH','4h','0.000259510000000','0.000258720000000','0.081664357522095','0.081415754992549','314.6867462606258','314.686746260625796','test'),('2019-12-19 03:59:59','2019-12-19 23:59:59','ADAETH','4h','0.000263620000000','0.000257990000000','0.081664357522095','0.079920292834858','309.78058387867003','309.780583878670029','test'),('2019-12-20 03:59:59','2019-12-20 07:59:59','ADAETH','4h','0.000261800000000','0.000257510000000','0.081664357522095','0.080326160066901','311.93413873985867','311.934138739858668','test'),('2019-12-20 11:59:59','2019-12-21 15:59:59','ADAETH','4h','0.000259970000000','0.000258960000000','0.081664357522095','0.081347086294271','314.12992853827365','314.129928538273646','test'),('2019-12-24 15:59:59','2019-12-27 11:59:59','ADAETH','4h','0.000265400000000','0.000260010000000','0.081664357522095','0.080005838731424','307.7029296235682','307.702929623568195','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  6:00:06
