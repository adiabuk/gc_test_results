-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-12 19:59:59','2019-01-14 15:59:59','ARNETH','4h','0.002028740000000','0.001926760000000','0.072144500000000','0.068517965249367','35.56123505229847','35.561235052298471','test'),('2019-01-15 15:59:59','2019-01-19 19:59:59','ARNETH','4h','0.002118450000000','0.002344950000000','0.072144500000000','0.079858030765418','34.055323467629634','34.055323467629634','test'),('2019-01-20 19:59:59','2019-01-22 19:59:59','ARNETH','4h','0.002550030000000','0.002439910000000','0.073166249003696','0.070006651924333','28.692309111538396','28.692309111538396','test'),('2019-01-23 07:59:59','2019-01-24 07:59:59','ARNETH','4h','0.002498730000000','0.002466630000000','0.073166249003696','0.072226316880970','29.281374539744593','29.281374539744593','test'),('2019-01-24 11:59:59','2019-01-24 15:59:59','ARNETH','4h','0.002504700000000','0.002442200000000','0.073166249003696','0.071340525139468','29.211581827642433','29.211581827642433','test'),('2019-01-26 23:59:59','2019-01-28 03:59:59','ARNETH','4h','0.002482480000000','0.002433370000000','0.073166249003696','0.071718827679628','29.473046712842','29.473046712841999','test'),('2019-01-30 07:59:59','2019-02-01 07:59:59','ARNETH','4h','0.002486740000000','0.002429620000000','0.073166249003696','0.071485632556825','29.422556842973535','29.422556842973535','test'),('2019-02-02 19:59:59','2019-02-02 23:59:59','ARNETH','4h','0.002541030000000','0.002451130000000','0.073166249003696','0.070577674376308','28.79393356382884','28.793933563828841','test'),('2019-02-26 23:59:59','2019-02-27 15:59:59','ARNETH','4h','0.002214240000000','0.002115230000000','0.073166249003696','0.069894611641054','33.043504319177686','33.043504319177686','test'),('2019-02-27 19:59:59','2019-02-28 11:59:59','ARNETH','4h','0.002145170000000','0.002094750000000','0.073166249003696','0.071446552068364','34.10743624220738','34.107436242207378','test'),('2019-03-01 15:59:59','2019-03-06 11:59:59','ARNETH','4h','0.002179980000000','0.002214270000000','0.073166249003696','0.074317117671453','33.56280745864457','33.562807458644571','test'),('2019-03-06 19:59:59','2019-03-09 11:59:59','ARNETH','4h','0.002281100000000','0.002301250000000','0.073166249003696','0.073812559957808','32.07498531572312','32.074985315723119','test'),('2019-03-09 15:59:59','2019-03-16 11:59:59','ARNETH','4h','0.002370000000000','0.002998730000000','0.073166249003696','0.092576297837491','30.87183502265654','30.871835022656541','test'),('2019-03-16 23:59:59','2019-03-17 23:59:59','ARNETH','4h','0.003273050000000','0.003104240000000','0.074309756176958','0.070477174963646','22.703520012513632','22.703520012513632','test'),('2019-03-26 03:59:59','2019-03-29 11:59:59','ARNETH','4h','0.003136360000000','0.003228750000000','0.074309756176958','0.076498751819419','23.692993207717862','23.692993207717862','test'),('2019-03-29 15:59:59','2019-03-29 19:59:59','ARNETH','4h','0.003321020000000','0.003251500000000','0.074309756176958','0.072754205698665','22.375582253933427','22.375582253933427','test'),('2019-03-31 03:59:59','2019-04-02 07:59:59','ARNETH','4h','0.003362980000000','0.003348890000000','0.074309756176958','0.073998417880408','22.096401458515363','22.096401458515363','test'),('2019-04-17 11:59:59','2019-04-18 11:59:59','ARNETH','4h','0.002963350000000','0.002812470000000','0.074309756176958','0.070526248993541','25.076267122330467','25.076267122330467','test'),('2019-04-18 19:59:59','2019-04-18 23:59:59','ARNETH','4h','0.002793650000000','0.002777350000000','0.074309756176958','0.073876183959363','26.599522551843645','26.599522551843645','test'),('2019-04-19 11:59:59','2019-04-21 07:59:59','ARNETH','4h','0.002879660000000','0.002773950000000','0.074309756176958','0.071581904859279','25.805045101490453','25.805045101490453','test'),('2019-05-23 19:59:59','2019-05-24 15:59:59','ARNETH','4h','0.001917200000000','0.001774720000000','0.074309756176958','0.068787299437915','38.759522312204254','38.759522312204254','test'),('2019-05-24 19:59:59','2019-05-24 23:59:59','ARNETH','4h','0.001810810000000','0.001776260000000','0.074309756176958','0.072891936485265','41.03674939776012','41.036749397760119','test'),('2019-05-25 07:59:59','2019-05-25 11:59:59','ARNETH','4h','0.001847530000000','0.001762100000000','0.074309756176958','0.070873664492278','40.22113642374305','40.221136423743047','test'),('2019-05-25 15:59:59','2019-05-30 03:59:59','ARNETH','4h','0.001867800000000','0.001936780000000','0.074309756176958','0.077054100850417','39.78464299012635','39.784642990126351','test'),('2019-05-30 11:59:59','2019-05-30 15:59:59','ARNETH','4h','0.002174230000000','0.002000680000000','0.074309756176958','0.068378250225651','34.17750476120649','34.177504761206492','test'),('2019-05-30 19:59:59','2019-06-02 07:59:59','ARNETH','4h','0.002120340000000','0.002134160000000','0.074309756176958','0.074794093986161','35.04615117243366','35.046151172433660','test'),('2019-06-02 11:59:59','2019-06-04 03:59:59','ARNETH','4h','0.002191110000000','0.002130490000000','0.074309756176958','0.072253877001815','33.914206122448434','33.914206122448434','test'),('2019-07-21 23:59:59','2019-07-22 15:59:59','ARNETH','4h','0.001193630000000','0.001199990000000','0.074309756176958','0.074705699684817','62.25526853125172','62.255268531251723','test'),('2019-07-22 23:59:59','2019-07-27 07:59:59','ARNETH','4h','0.001194680000000','0.001293500000000','0.074309756176958','0.080456414784624','62.200552597313084','62.200552597313084','test'),('2019-08-22 07:59:59','2019-08-26 03:59:59','ARNETH','4h','0.001052430000000','0.001102070000000','0.074309756176958','0.077814726860637','70.6077897598491','70.607789759849098','test'),('2019-08-30 11:59:59','2019-08-31 23:59:59','ARNETH','4h','0.001150000000000','0.001211490000000','0.074309756176958','0.078283066531150','64.6171792843113','64.617179284311305','test'),('2019-09-01 07:59:59','2019-09-02 07:59:59','ARNETH','4h','0.001184150000000','0.001097020000000','0.074309756176958','0.068842029068316','62.75366818136047','62.753668181360467','test'),('2019-09-22 15:59:59','2019-09-24 07:59:59','ARNETH','4h','0.001093220000000','0.001008090000000','0.074309756176958','0.068523190304266','67.97328641715116','67.973286417151158','test'),('2019-09-24 11:59:59','2019-09-24 15:59:59','ARNETH','4h','0.001043510000000','0.000963680000000','0.074309756176958','0.068624954080565','71.2113503243457','71.211350324345702','test'),('2019-09-27 07:59:59','2019-09-29 15:59:59','ARNETH','4h','0.001096640000000','0.001024750000000','0.074309756176958','0.069438396048236','67.76130377968886','67.761303779688859','test'),('2019-09-29 19:59:59','2019-09-30 03:59:59','ARNETH','4h','0.001039740000000','0.001007460000000','0.074309756176958','0.072002718908610','71.46955602069556','71.469556020695563','test'),('2019-10-01 07:59:59','2019-10-06 03:59:59','ARNETH','4h','0.001124420000000','0.001127550000000','0.074309756176958','0.074516609076083','66.08718821877767','66.087188218777669','test'),('2019-10-07 19:59:59','2019-10-09 15:59:59','ARNETH','4h','0.001176930000000','0.001094380000000','0.074309756176958','0.069097661683311','63.138637112621815','63.138637112621815','test'),('2019-10-22 11:59:59','2019-10-23 15:59:59','ARNETH','4h','0.001125890000000','0.001054300000000','0.074309756176958','0.069584751563089','66.0009025543863','66.000902554386300','test'),('2019-10-24 15:59:59','2019-10-25 03:59:59','ARNETH','4h','0.001091440000000','0.001072650000000','0.074309756176958','0.073030455144776','68.08414221300117','68.084142213001172','test'),('2019-10-25 07:59:59','2019-10-25 11:59:59','ARNETH','4h','0.001076650000000','0.001062880000000','0.074309756176958','0.073359358793819','69.01941780240375','69.019417802403751','test'),('2019-11-03 15:59:59','2019-11-04 11:59:59','ARNETH','4h','0.001055090000000','0.001017600000000','0.074309756176958','0.071669343739086','70.42977961781268','70.429779617812684','test'),('2019-11-04 19:59:59','2019-11-04 23:59:59','ARNETH','4h','0.001016510000000','0.001011160000000','0.074309756176958','0.073918656044597','73.10282847877345','73.102828478773446','test'),('2019-11-16 11:59:59','2019-11-16 15:59:59','ARNETH','4h','0.000995020000000','0.000982700000000','0.074309756176958','0.073389677991494','74.68167089803018','74.681670898030177','test'),('2019-11-16 23:59:59','2019-11-18 15:59:59','ARNETH','4h','0.000983670000000','0.000984480000000','0.074309756176958','0.074370946314406','75.54337956525866','75.543379565258661','test'),('2019-11-26 07:59:59','2019-11-30 15:59:59','ARNETH','4h','0.001009640000000','0.001045380000000','0.074309756176958','0.076940229103709','73.60024976918307','73.600249769183065','test'),('2019-12-05 23:59:59','2019-12-06 11:59:59','ARNETH','4h','0.001066280000000','0.001066040000000','0.074309756176958','0.074293030418731','69.69065927988709','69.690659279887086','test'),('2019-12-06 19:59:59','2019-12-10 03:59:59','ARNETH','4h','0.001067450000000','0.001037050000000','0.074309756176958','0.072193482264569','69.61427343384514','69.614273433845142','test'),('2019-12-19 07:59:59','2019-12-22 15:59:59','ARNETH','4h','0.001046790000000','0.001052700000000','0.074309756176958','0.074729296542271','70.98821748102102','70.988217481021024','test'),('2019-12-25 23:59:59','2019-12-26 03:59:59','ARNETH','4h','0.001041010000000','0.001032410000000','0.074309756176958','0.073695867834750','71.38236537301083','71.382365373010828','test'),('2019-12-26 07:59:59','2019-12-26 11:59:59','ARNETH','4h','0.001037060000000','0.001050610000000','0.074309756176958','0.075280671260172','71.65424968368079','71.654249683680789','test'),('2019-12-26 15:59:59','2019-12-26 19:59:59','ARNETH','4h','0.001062260000000','0.001029420000000','0.074309756176958','0.072012453828332','69.95439551235856','69.954395512358559','test'),('2019-12-26 23:59:59','2019-12-27 03:59:59','ARNETH','4h','0.001033150000000','0.001039960000000','0.074309756176958','0.074799568343212','71.92542823109711','71.925428231097115','test'),('2019-12-27 07:59:59','2019-12-29 07:59:59','ARNETH','4h','0.001070860000000','0.001047740000000','0.074309756176958','0.072705399339639','69.39259676984665','69.392596769846648','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 13:11:08
