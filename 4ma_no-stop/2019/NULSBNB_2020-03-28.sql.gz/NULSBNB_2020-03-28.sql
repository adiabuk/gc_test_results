-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-25 07:59:59','2019-01-27 03:59:59','NULSBNB','4h','0.067550000000000','0.066820000000000','0.711908500000000','0.704215040266469','10.538985936343451','10.538985936343451','test'),('2019-01-30 07:59:59','2019-01-31 11:59:59','NULSBNB','4h','0.066800000000000','0.063510000000000','0.711908500000000','0.676845940643713','10.657312874251499','10.657312874251499','test'),('2019-03-14 19:59:59','2019-03-16 23:59:59','NULSBNB','4h','0.037160000000000','0.035450000000000','0.711908500000000','0.679148447927880','19.1579251883746','19.157925188374598','test'),('2019-03-17 23:59:59','2019-03-19 11:59:59','NULSBNB','4h','0.036890000000000','0.036140000000000','0.711908500000000','0.697434892653836','19.29814312821903','19.298143128219031','test'),('2019-03-20 03:59:59','2019-03-21 15:59:59','NULSBNB','4h','0.037550000000000','0.037780000000000','0.711908500000000','0.716269058055926','18.958948069241014','18.958948069241014','test'),('2019-03-21 23:59:59','2019-03-24 11:59:59','NULSBNB','4h','0.038670000000000','0.037730000000000','0.711908500000000','0.694603250711146','18.409839668994053','18.409839668994053','test'),('2019-03-27 11:59:59','2019-04-03 23:59:59','NULSBNB','4h','0.043860000000000','0.048060000000000','0.711908500000000','0.780080312585499','16.231383948928407','16.231383948928407','test'),('2019-04-06 11:59:59','2019-04-08 11:59:59','NULSBNB','4h','0.050060000000000','0.047690000000000','0.711908500000000','0.678204481921694','14.221104674390732','14.221104674390732','test'),('2019-04-08 15:59:59','2019-04-09 19:59:59','NULSBNB','4h','0.050000000000000','0.049120000000000','0.711908500000000','0.699378910400000','14.23817','14.238170000000000','test'),('2019-04-09 23:59:59','2019-04-11 03:59:59','NULSBNB','4h','0.050090000000000','0.045790000000000','0.711908500000000','0.650794374426033','14.21258734278299','14.212587342782991','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','NULSBNB','4h','0.032420000000000','0.031810000000000','0.711908500000000','0.698513552899445','21.958929673041336','21.958929673041336','test'),('2019-05-10 15:59:59','2019-05-10 19:59:59','NULSBNB','4h','0.032400000000000','0.031910000000000','0.711908500000000','0.701141982561729','21.972484567901237','21.972484567901237','test'),('2019-05-11 03:59:59','2019-05-11 07:59:59','NULSBNB','4h','0.031650000000000','0.031550000000000','0.711908500000000','0.709659184044234','22.49315955766193','22.493159557661929','test'),('2019-05-11 11:59:59','2019-05-11 15:59:59','NULSBNB','4h','0.032520000000000','0.030710000000000','0.711908500000000','0.672285056426814','21.89140528905289','21.891405289052891','test'),('2019-05-12 07:59:59','2019-05-12 11:59:59','NULSBNB','4h','0.032740000000000','0.031270000000000','0.711908500000000','0.679944373701894','21.74430360415394','21.744303604153941','test'),('2019-06-03 03:59:59','2019-06-04 03:59:59','NULSBNB','4h','0.024960000000000','0.024230000000000','0.711908500000000','0.691087458133013','28.521975160256414','28.521975160256414','test'),('2019-06-04 07:59:59','2019-06-04 15:59:59','NULSBNB','4h','0.024570000000000','0.024500000000000','0.711908500000000','0.709880270655271','28.974704924704927','28.974704924704927','test'),('2019-06-04 23:59:59','2019-06-06 03:59:59','NULSBNB','4h','0.024660000000000','0.025160000000000','0.711908500000000','0.726342978913220','28.86895782643958','28.868957826439580','test'),('2019-06-06 11:59:59','2019-06-06 15:59:59','NULSBNB','4h','0.024350000000000','0.024350000000000','0.711908500000000','0.711908500000000','29.236488706365506','29.236488706365506','test'),('2019-06-07 19:59:59','2019-06-08 15:59:59','NULSBNB','4h','0.025280000000000','0.024900000000000','0.711908500000000','0.701207343750000','28.160937500000003','28.160937500000003','test'),('2019-06-08 23:59:59','2019-06-12 07:59:59','NULSBNB','4h','0.024810000000000','0.027030000000000','0.711908500000000','0.775610107013301','28.694417573559054','28.694417573559054','test'),('2019-06-14 19:59:59','2019-06-17 11:59:59','NULSBNB','4h','0.032350000000000','0.028950000000000','0.711908500000000','0.637086586553323','22.006445131375582','22.006445131375582','test'),('2019-06-19 23:59:59','2019-06-20 11:59:59','NULSBNB','4h','0.029680000000000','0.027510000000000','0.711908500000000','0.659858586084906','23.986135444743937','23.986135444743937','test'),('2019-07-01 23:59:59','2019-07-02 07:59:59','NULSBNB','4h','0.027430000000000','0.026170000000000','0.711908500000000','0.679206906489245','25.953645643456074','25.953645643456074','test'),('2019-07-02 11:59:59','2019-07-05 07:59:59','NULSBNB','4h','0.027150000000000','0.027500000000000','0.711908500000000','0.721085957642726','26.221307550644568','26.221307550644568','test'),('2019-07-05 15:59:59','2019-07-08 11:59:59','NULSBNB','4h','0.027990000000000','0.026790000000000','0.711908500000000','0.681387235262594','25.434387281171848','25.434387281171848','test'),('2019-08-05 15:59:59','2019-08-05 23:59:59','NULSBNB','4h','0.019200000000000','0.018980000000000','0.711908500000000','0.703751215104167','37.07856770833334','37.078567708333338','test'),('2019-08-17 23:59:59','2019-08-19 07:59:59','NULSBNB','4h','0.016870000000000','0.015590000000000','0.711908500000000','0.657892917308832','42.19967397747481','42.199673977474809','test'),('2019-08-22 11:59:59','2019-08-23 19:59:59','NULSBNB','4h','0.015850000000000','0.016080000000000','0.711908500000000','0.722239033438486','44.91536277602524','44.915362776025241','test'),('2019-08-24 07:59:59','2019-09-02 23:59:59','NULSBNB','4h','0.016650000000000','0.019350000000000','0.711908500000000','0.827353121621622','42.75726726726727','42.757267267267267','test'),('2019-09-04 23:59:59','2019-09-05 19:59:59','NULSBNB','4h','0.020040000000000','0.018920000000000','0.711908500000000','0.672121198602795','35.524376247504996','35.524376247504996','test'),('2019-09-09 15:59:59','2019-09-11 03:59:59','NULSBNB','4h','0.019700000000000','0.019200000000000','0.711908500000000','0.693839756345178','36.137487309644676','36.137487309644676','test'),('2019-09-11 19:59:59','2019-09-12 23:59:59','NULSBNB','4h','0.020030000000000','0.019510000000000','0.711908500000000','0.693426601847229','35.54211183225163','35.542111832251628','test'),('2019-09-13 19:59:59','2019-09-14 23:59:59','NULSBNB','4h','0.020340000000000','0.019390000000000','0.711908500000000','0.678658102999017','35.00041789577188','35.000417895771882','test'),('2019-09-15 11:59:59','2019-09-15 19:59:59','NULSBNB','4h','0.020250000000000','0.019970000000000','0.711908500000000','0.702064826913580','35.15597530864198','35.155975308641978','test'),('2019-09-15 23:59:59','2019-09-18 07:59:59','NULSBNB','4h','0.020580000000000','0.020050000000000','0.711908500000000','0.693574607628766','34.59224975704568','34.592249757045678','test'),('2019-09-23 07:59:59','2019-09-24 19:59:59','NULSBNB','4h','0.020740000000000','0.018950000000000','0.711908500000000','0.650466059546770','34.32538572806172','34.325385728061718','test'),('2019-09-25 07:59:59','2019-09-26 15:59:59','NULSBNB','4h','0.021760000000000','0.020510000000000','0.711908500000000','0.671013020909927','32.71638327205882','32.716383272058820','test'),('2019-09-26 19:59:59','2019-10-06 15:59:59','NULSBNB','4h','0.021080000000000','0.023830000000000','0.711908500000000','0.804780813804554','33.7717504743833','33.771750474383303','test'),('2019-10-28 03:59:59','2019-11-03 11:59:59','NULSBNB','4h','0.020730000000000','0.020680000000000','0.711908500000000','0.710191402797878','34.34194404245056','34.341944042450557','test'),('2019-11-09 19:59:59','2019-11-10 03:59:59','NULSBNB','4h','0.020280000000000','0.020670000000000','0.711908500000000','0.725599048076923','35.10396942800789','35.103969428007893','test'),('2019-11-10 15:59:59','2019-11-10 19:59:59','NULSBNB','4h','0.019850000000000','0.020070000000000','0.711908500000000','0.719798669773300','35.86440806045341','35.864408060453407','test'),('2019-11-28 19:59:59','2019-11-30 15:59:59','NULSBNB','4h','0.019440000000000','0.019400000000000','0.711908500000000','0.710443667695473','36.62080761316873','36.620807613168729','test'),('2019-11-30 19:59:59','2019-12-03 07:59:59','NULSBNB','4h','0.019600000000000','0.019910000000000','0.711908500000000','0.723168277295918','36.321862244897964','36.321862244897964','test'),('2019-12-03 11:59:59','2019-12-03 23:59:59','NULSBNB','4h','0.020070000000000','0.019680000000000','0.711908500000000','0.698074702541106','35.47127553562531','35.471275535625310','test'),('2019-12-10 07:59:59','2019-12-10 11:59:59','NULSBNB','4h','0.019090000000000','0.019210000000000','0.711908500000000','0.716383566526978','37.29222105814563','37.292221058145628','test'),('2019-12-10 15:59:59','2019-12-10 19:59:59','NULSBNB','4h','0.019430000000000','0.018490000000000','0.711908500000000','0.677467224137931','36.639655172413796','36.639655172413796','test'),('2019-12-15 23:59:59','2019-12-16 19:59:59','NULSBNB','4h','0.019500000000000','0.019410000000000','0.711908500000000','0.708622768461539','36.50812820512821','36.508128205128209','test'),('2019-12-16 23:59:59','2019-12-18 03:59:59','NULSBNB','4h','0.019440000000000','0.019390000000000','0.711908500000000','0.710077459619342','36.62080761316873','36.620807613168729','test'),('2019-12-18 07:59:59','2019-12-18 11:59:59','NULSBNB','4h','0.019590000000000','0.019280000000000','0.711908500000000','0.700642974987238','36.34040326697295','36.340403266972949','test'),('2019-12-27 19:59:59','2019-12-28 23:59:59','NULSBNB','4h','0.021020000000000','0.018390000000000','0.711908500000000','0.622835267126546','33.86814938154139','33.868149381541393','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 21:49:20
