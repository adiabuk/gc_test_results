-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-04 19:59:59','NEBLBNB','4h','0.219420000000000','0.221220000000000','0.711908500000000','0.717748602543068','3.244501412815605','3.244501412815605','test'),('2019-01-04 23:59:59','2019-01-06 23:59:59','NEBLBNB','4h','0.224100000000000','0.220450000000000','0.713368525635767','0.701749627293194','3.1832598198829407','3.183259819882941','test'),('2019-01-07 03:59:59','2019-01-07 11:59:59','NEBLBNB','4h','0.225880000000000','0.216430000000000','0.713368525635767','0.683523773699969','3.1581748080209273','3.158174808020927','test'),('2019-02-26 23:59:59','2019-02-27 07:59:59','NEBLBNB','4h','0.118270000000000','0.115060000000000','0.713368525635767','0.694006785826087','6.031694644760015','6.031694644760015','test'),('2019-02-27 11:59:59','2019-02-27 15:59:59','NEBLBNB','4h','0.115080000000000','0.111580000000000','0.713368525635767','0.691672402593317','6.198892297842953','6.198892297842953','test'),('2019-02-27 19:59:59','2019-02-28 11:59:59','NEBLBNB','4h','0.119480000000000','0.112450000000000','0.713368525635767','0.671395134815383','5.970610358518305','5.970610358518305','test'),('2019-03-15 19:59:59','2019-03-18 07:59:59','NEBLBNB','4h','0.098150000000000','0.095120000000000','0.713368525635767','0.691346043387409','7.2681459565539175','7.268145956553917','test'),('2019-03-19 19:59:59','2019-03-21 15:59:59','NEBLBNB','4h','0.098580000000000','0.097250000000000','0.713368525635767','0.703744056787161','7.23644274331271','7.236442743312710','test'),('2019-03-21 23:59:59','2019-03-22 07:59:59','NEBLBNB','4h','0.100360000000000','0.098080000000000','0.713368525635767','0.697162066504145','7.108096110360372','7.108096110360372','test'),('2019-03-30 03:59:59','2019-03-30 23:59:59','NEBLBNB','4h','0.095330000000000','0.090370000000000','0.713368525635767','0.676252110161589','7.483148281084308','7.483148281084308','test'),('2019-04-07 11:59:59','2019-04-07 19:59:59','NEBLBNB','4h','0.091510000000000','0.093590000000000','0.713368525635767','0.729583218383253','7.795525359368015','7.795525359368015','test'),('2019-04-08 03:59:59','2019-04-10 23:59:59','NEBLBNB','4h','0.092700000000000','0.092640000000000','0.713368525635767','0.712906798434708','7.695453350979148','7.695453350979148','test'),('2019-05-08 23:59:59','2019-05-09 07:59:59','NEBLBNB','4h','0.062530000000000','0.059910000000000','0.713368525635767','0.683478464270571','11.408420368395442','11.408420368395442','test'),('2019-05-09 15:59:59','2019-05-09 19:59:59','NEBLBNB','4h','0.061320000000000','0.059920000000000','0.713368525635767','0.697081572995681','11.633537600061432','11.633537600061432','test'),('2019-05-09 23:59:59','2019-05-10 03:59:59','NEBLBNB','4h','0.060950000000000','0.060850000000000','0.713368525635767','0.712198109679023','11.704159567444906','11.704159567444906','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','NEBLBNB','4h','0.063040000000000','0.061000000000000','0.713368525635767','0.690283630453391','11.316125089399858','11.316125089399858','test'),('2019-05-10 15:59:59','2019-05-10 19:59:59','NEBLBNB','4h','0.062280000000000','0.060570000000000','0.713368525635767','0.693781817561953','11.454215247844685','11.454215247844685','test'),('2019-06-01 15:59:59','2019-06-01 23:59:59','NEBLBNB','4h','0.042850000000000','0.041400000000000','0.713368525635767','0.689228867242025','16.64804027154649','16.648040271546488','test'),('2019-06-02 07:59:59','2019-06-02 11:59:59','NEBLBNB','4h','0.041740000000000','0.042010000000000','0.713368525635767','0.717983032150421','17.09076486908881','17.090764869088812','test'),('2019-06-02 19:59:59','2019-06-02 23:59:59','NEBLBNB','4h','0.041780000000000','0.042300000000000','0.713368525635767','0.722247214801171','17.07440224116245','17.074402241162449','test'),('2019-06-03 03:59:59','2019-06-03 07:59:59','NEBLBNB','4h','0.042630000000000','0.042000000000000','0.713368525635767','0.702826133631298','16.733955562649943','16.733955562649943','test'),('2019-06-09 11:59:59','2019-06-11 19:59:59','NEBLBNB','4h','0.043390000000000','0.043590000000000','0.713368525635767','0.716656695839205','16.440851017187534','16.440851017187534','test'),('2019-07-01 03:59:59','2019-07-02 07:59:59','NEBLBNB','4h','0.034270000000000','0.032000000000000','0.713368525635767','0.666115927059952','20.81612272062349','20.816122720623490','test'),('2019-07-02 11:59:59','2019-07-02 19:59:59','NEBLBNB','4h','0.032960000000000','0.032110000000000','0.713368525635767','0.694971582468582','21.64346254962885','21.643462549628850','test'),('2019-07-04 03:59:59','2019-07-04 11:59:59','NEBLBNB','4h','0.035060000000000','0.031810000000000','0.713368525635767','0.647240524828116','20.34707717158491','20.347077171584910','test'),('2019-07-04 19:59:59','2019-07-04 23:59:59','NEBLBNB','4h','0.033440000000000','0.032510000000000','0.713368525635767','0.693529030156064','21.332790838390164','21.332790838390164','test'),('2019-07-05 03:59:59','2019-07-05 07:59:59','NEBLBNB','4h','0.033250000000000','0.032660000000000','0.713368525635767','0.700710257060576','21.45469250032382','21.454692500323819','test'),('2019-07-08 03:59:59','2019-07-08 07:59:59','NEBLBNB','4h','0.033280000000000','0.032000000000000','0.713368525635767','0.685931274649776','21.4353523328055','21.435352332805500','test'),('2019-07-09 23:59:59','2019-07-10 19:59:59','NEBLBNB','4h','0.036550000000000','0.033720000000000','0.713368525635767','0.658133698616637','19.517606720540822','19.517606720540822','test'),('2019-07-11 15:59:59','2019-07-12 03:59:59','NEBLBNB','4h','0.034630000000000','0.032450000000000','0.713368525635767','0.668461122058349','20.599726411659457','20.599726411659457','test'),('2019-07-28 15:59:59','2019-07-31 07:59:59','NEBLBNB','4h','0.031540000000000','0.030230000000000','0.713368525635767','0.683739078312278','22.617898720220897','22.617898720220897','test'),('2019-08-23 23:59:59','2019-08-26 03:59:59','NEBLBNB','4h','0.020700000000000','0.021610000000000','0.713368525635767','0.744729170965649','34.46224761525445','34.462247615254448','test'),('2019-08-27 19:59:59','2019-09-02 07:59:59','NEBLBNB','4h','0.022480000000000','0.024680000000000','0.713368525635767','0.783182171383040','31.73347533966935','31.733475339669351','test'),('2019-09-15 23:59:59','2019-09-16 07:59:59','NEBLBNB','4h','0.023210000000000','0.022480000000000','0.713368525635767','0.690931687044035','30.735395331140328','30.735395331140328','test'),('2019-09-16 11:59:59','2019-09-16 15:59:59','NEBLBNB','4h','0.022590000000000','0.022500000000000','0.713368525635767','0.710526419955943','31.578951998041923','31.578951998041923','test'),('2019-09-22 11:59:59','2019-09-24 15:59:59','NEBLBNB','4h','0.023080000000000','0.022630000000000','0.713368525635767','0.699459693896768','30.908514975553164','30.908514975553164','test'),('2019-09-25 15:59:59','2019-09-25 19:59:59','NEBLBNB','4h','0.023300000000000','0.022580000000000','0.713368525635767','0.691324519693374','30.61667491999','30.616674919990000','test'),('2019-09-27 07:59:59','2019-10-06 23:59:59','NEBLBNB','4h','0.023490000000000','0.026850000000000','0.713368525635767','0.815408468000015','30.369030465549894','30.369030465549894','test'),('2019-10-07 11:59:59','2019-10-09 15:59:59','NEBLBNB','4h','0.028360000000000','0.026740000000000','0.713368525635767','0.672618983621312','25.15403828052775','25.154038280527750','test'),('2019-10-11 11:59:59','2019-10-12 19:59:59','NEBLBNB','4h','0.028290000000000','0.027440000000000','0.713368525635767','0.691934688704328','25.216278742869108','25.216278742869108','test'),('2019-10-23 23:59:59','2019-10-24 23:59:59','NEBLBNB','4h','0.025420000000000','0.024640000000000','0.713368525635767','0.691479168830264','28.063277955773682','28.063277955773682','test'),('2019-10-25 07:59:59','2019-10-25 15:59:59','NEBLBNB','4h','0.025000000000000','0.024930000000000','0.713368525635767','0.711371093763987','28.53474102543068','28.534741025430680','test'),('2019-10-25 19:59:59','2019-10-26 03:59:59','NEBLBNB','4h','0.025400000000000','0.025400000000000','0.713368525635767','0.713368525635767','28.0853750250302','28.085375025030199','test'),('2019-10-26 07:59:59','2019-10-28 03:59:59','NEBLBNB','4h','0.025890000000000','0.024960000000000','0.713368525635767','0.687743468515595','27.553824860400425','27.553824860400425','test'),('2019-11-04 07:59:59','2019-11-04 11:59:59','NEBLBNB','4h','0.024500000000000','0.023850000000000','0.713368525635767','0.694442421894410','29.1170826790109','29.117082679010899','test'),('2019-11-06 19:59:59','2019-11-06 23:59:59','NEBLBNB','4h','0.024980000000000','0.023760000000000','0.713368525635767','0.678528269379737','28.55758709510677','28.557587095106769','test'),('2019-11-18 03:59:59','2019-11-22 07:59:59','NEBLBNB','4h','0.024250000000000','0.024170000000000','0.713368525635767','0.711015144932639','29.417258789103794','29.417258789103794','test'),('2019-11-23 03:59:59','2019-11-23 19:59:59','NEBLBNB','4h','0.025250000000000','0.024300000000000','0.713368525635767','0.686528917740560','28.252218837060077','28.252218837060077','test'),('2019-11-25 15:59:59','2019-11-28 11:59:59','NEBLBNB','4h','0.025750000000000','0.027270000000000','0.713368525635767','0.755478046372325','27.703632063524935','27.703632063524935','test'),('2019-11-29 15:59:59','2019-12-02 03:59:59','NEBLBNB','4h','0.028700000000000','0.028510000000000','0.713368525635767','0.708645876859781','24.85604618939955','24.856046189399549','test'),('2019-12-02 19:59:59','2019-12-09 23:59:59','NEBLBNB','4h','0.031950000000000','0.032780000000000','0.713368525635767','0.731900477944928','22.32765338453105','22.327653384531050','test'),('2019-12-16 19:59:59','2019-12-19 23:59:59','NEBLBNB','4h','0.033040000000000','0.032500000000000','0.713368525635767','0.701709354817265','21.591057071300455','21.591057071300455','test'),('2019-12-20 03:59:59','2019-12-20 07:59:59','NEBLBNB','4h','0.033000000000000','0.032500000000000','0.713368525635767','0.702559911610983','21.6172280495687','21.617228049568698','test'),('2019-12-20 11:59:59','2019-12-20 23:59:59','NEBLBNB','4h','0.033000000000000','0.032260000000000','0.713368525635767','0.697371776879086','21.6172280495687','21.617228049568698','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 13:32:02
