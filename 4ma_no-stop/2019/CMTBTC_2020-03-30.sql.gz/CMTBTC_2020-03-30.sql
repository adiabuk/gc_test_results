-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-05 11:59:59','2019-01-06 19:59:59','CMTBTC','4h','0.000006840000000','0.000006680000000','0.001467500000000','0.001433172514620','214.54678362573102','214.546783625731024','test'),('2019-01-06 23:59:59','2019-01-07 03:59:59','CMTBTC','4h','0.000006730000000','0.000006820000000','0.001467500000000','0.001487124814264','218.05349182763746','218.053491827637458','test'),('2019-01-16 19:59:59','2019-01-20 23:59:59','CMTBTC','4h','0.000006930000000','0.000007120000000','0.001467500000000','0.001507734487734','211.76046176046177','211.760461760461766','test'),('2019-01-21 03:59:59','2019-01-23 23:59:59','CMTBTC','4h','0.000007540000000','0.000007730000000','0.001473882954154','0.001511023240797','195.475192858687','195.475192858686995','test'),('2019-02-10 07:59:59','2019-02-14 15:59:59','CMTBTC','4h','0.000007100000000','0.000006890000000','0.001483168025815','0.001439299675756','208.89690504440142','208.896905044401421','test'),('2019-02-16 03:59:59','2019-02-18 15:59:59','CMTBTC','4h','0.000007190000000','0.000006860000000','0.001483168025815','0.001415094945353','206.2820620048679','206.282062004867896','test'),('2019-02-23 19:59:59','2019-02-24 15:59:59','CMTBTC','4h','0.000007250000000','0.000006830000000','0.001483168025815','0.001397246567768','204.57490011241381','204.574900112413815','test'),('2019-02-24 19:59:59','2019-02-24 23:59:59','CMTBTC','4h','0.000006860000000','0.000006850000000','0.001483168025815','0.001481005973299','216.2052515765306','216.205251576530600','test'),('2019-02-26 03:59:59','2019-03-03 07:59:59','CMTBTC','4h','0.000007220000000','0.000007560000000','0.001483168025815','0.001553012503485','205.4249343234072','205.424934323407200','test'),('2019-03-08 11:59:59','2019-03-14 03:59:59','CMTBTC','4h','0.000007600000000','0.000008500000000','0.001483168025815','0.001658806344662','195.15368760723686','195.153687607236861','test'),('2019-03-20 07:59:59','2019-03-21 15:59:59','CMTBTC','4h','0.000008660000000','0.000008190000000','0.001494532489673','0.001413420449240','172.57880943112008','172.578809431120078','test'),('2019-03-23 15:59:59','2019-03-23 19:59:59','CMTBTC','4h','0.000008550000000','0.000008380000000','0.001494532489673','0.001464816639001','174.79912159918132','174.799121599181319','test'),('2019-03-23 23:59:59','2019-03-24 07:59:59','CMTBTC','4h','0.000008470000000','0.000008350000000','0.001494532489673','0.001473358475652','176.45011684451003','176.450116844510035','test'),('2019-03-29 15:59:59','2019-03-29 19:59:59','CMTBTC','4h','0.000008340000000','0.000008290000000','0.001494532489673','0.001485572462756','179.20053833009595','179.200538330095952','test'),('2019-03-29 23:59:59','2019-03-30 07:59:59','CMTBTC','4h','0.000008380000000','0.000008360000000','0.001494532489673','0.001490965586356','178.34516583210026','178.345165832100264','test'),('2019-03-30 11:59:59','2019-04-02 07:59:59','CMTBTC','4h','0.000008400000000','0.000008740000000','0.001494532489673','0.001555025471398','177.920534484881','177.920534484880989','test'),('2019-04-03 15:59:59','2019-04-03 23:59:59','CMTBTC','4h','0.000009370000000','0.000008940000000','0.001494532489673','0.001425946687052','159.501866560619','159.501866560618993','test'),('2019-04-04 03:59:59','2019-04-06 19:59:59','CMTBTC','4h','0.000009090000000','0.000009490000000','0.001494532489673','0.001560298495819','164.41501536556657','164.415015365566575','test'),('2019-05-17 19:59:59','2019-05-19 03:59:59','CMTBTC','4h','0.000005390000000','0.000004930000000','0.001494532489673','0.001366984262354','277.2787550413729','277.278755041372904','test'),('2019-05-21 19:59:59','2019-05-22 15:59:59','CMTBTC','4h','0.000005130000000','0.000005070000000','0.001494532489673','0.001477052577513','291.33186933196885','291.331869331968846','test'),('2019-05-22 19:59:59','2019-05-23 11:59:59','CMTBTC','4h','0.000005200000000','0.000004970000000','0.001494532489673','0.001428428168014','287.4100941678846','287.410094167884608','test'),('2019-05-23 15:59:59','2019-05-23 23:59:59','CMTBTC','4h','0.000005080000000','0.000004950000000','0.001494532489673','0.001456286579504','294.1993089907481','294.199308990748079','test'),('2019-05-24 03:59:59','2019-05-24 19:59:59','CMTBTC','4h','0.000005110000000','0.000005280000000','0.001494532489673','0.001544252748625','292.4721114819961','292.472111481996080','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','CMTBTC','4h','0.000005240000000','0.000004900000000','0.001494532489673','0.001397559007519','285.216123983397','285.216123983396983','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','CMTBTC','4h','0.000005140000000','0.000005140000000','0.001494532489673','0.001494532489673','290.76507581186775','290.765075811867746','test'),('2019-05-28 23:59:59','2019-05-29 07:59:59','CMTBTC','4h','0.000005120000000','0.000005060000000','0.001494532489673','0.001477018437060','291.9008768892578','291.900876889257802','test'),('2019-05-29 15:59:59','2019-05-29 19:59:59','CMTBTC','4h','0.000005030000000','0.000005050000000','0.001494532489673','0.001500474964781','297.1237554021869','297.123755402186873','test'),('2019-06-10 15:59:59','2019-06-11 07:59:59','CMTBTC','4h','0.000004880000000','0.000004610000000','0.001494532489673','0.001411843192089','306.25665771987707','306.256657719877069','test'),('2019-06-11 15:59:59','2019-06-12 03:59:59','CMTBTC','4h','0.000004670000000','0.000004600000000','0.001494532489673','0.001472130503746','320.0283703796574','320.028370379657417','test'),('2019-06-13 15:59:59','2019-06-17 07:59:59','CMTBTC','4h','0.000004690000000','0.000005510000000','0.001494532489673','0.001755836677633','318.6636438535181','318.663643853518124','test'),('2019-07-03 19:59:59','2019-07-06 15:59:59','CMTBTC','4h','0.000006050000000','0.000005150000000','0.001494532489673','0.001272205342449','247.0301635823141','247.030163582314088','test'),('2019-07-11 11:59:59','2019-07-12 03:59:59','CMTBTC','4h','0.000005050000000','0.000004870000000','0.001494532489673','0.001441262024695','295.9470276580198','295.947027658019806','test'),('2019-07-12 11:59:59','2019-07-12 15:59:59','CMTBTC','4h','0.000004860000000','0.000005000000000','0.001494532489673','0.001537584865919','307.5169731837449','307.516973183744881','test'),('2019-07-12 19:59:59','2019-07-14 11:59:59','CMTBTC','4h','0.000005440000000','0.000004980000000','0.001494532489673','0.001368156580620','274.7302370722427','274.730237072242687','test'),('2019-08-20 03:59:59','2019-08-20 19:59:59','CMTBTC','4h','0.000003280000000','0.000002990000000','0.001494532489673','0.001362393946379','455.6501492905488','455.650149290548825','test'),('2019-08-20 23:59:59','2019-08-21 07:59:59','CMTBTC','4h','0.000003000000000','0.000003000000000','0.001494532489673','0.001494532489673','498.1774965576667','498.177496557666700','test'),('2019-08-21 11:59:59','2019-08-23 07:59:59','CMTBTC','4h','0.000003010000000','0.000003020000000','0.001494532489673','0.001499497713891','496.52242181827245','496.522421818272448','test'),('2019-08-24 19:59:59','2019-08-24 23:59:59','CMTBTC','4h','0.000003070000000','0.000003060000000','0.001494532489673','0.001489664305668','486.8184005449512','486.818400544951203','test'),('2019-08-25 07:59:59','2019-08-25 15:59:59','CMTBTC','4h','0.000003130000000','0.000003060000000','0.001494532489673','0.001461108440383','477.4864184258786','477.486418425878583','test'),('2019-09-20 19:59:59','2019-09-23 03:59:59','CMTBTC','4h','0.000002180000000','0.000002180000000','0.001494532489673','0.001494532489673','685.5653622353212','685.565362235321231','test'),('2019-09-23 19:59:59','2019-09-23 23:59:59','CMTBTC','4h','0.000002300000000','0.000002210000000','0.001494532489673','0.001436050783555','649.7967346404348','649.796734640434806','test'),('2019-10-03 03:59:59','2019-10-06 07:59:59','CMTBTC','4h','0.000002270000000','0.000002190000000','0.001494532489673','0.001441861741138','658.384356684141','658.384356684141039','test'),('2019-10-07 19:59:59','2019-10-08 15:59:59','CMTBTC','4h','0.000002250000000','0.000002220000000','0.001494532489673','0.001474605389811','664.2366620768889','664.236662076888933','test'),('2019-10-08 19:59:59','2019-10-09 15:59:59','CMTBTC','4h','0.000002280000000','0.000002110000000','0.001494532489673','0.001383098049654','655.4967059969298','655.496705996929791','test'),('2019-10-29 19:59:59','2019-11-01 07:59:59','CMTBTC','4h','0.000002170000000','0.000002140000000','0.001494532489673','0.001473870750184','688.7246496188941','688.724649618894091','test'),('2019-11-01 11:59:59','2019-11-02 19:59:59','CMTBTC','4h','0.000002240000000','0.000002180000000','0.001494532489673','0.001454500369414','667.2020043183036','667.202004318303580','test'),('2019-11-05 03:59:59','2019-11-06 23:59:59','CMTBTC','4h','0.000002310000000','0.000002210000000','0.001494532489673','0.001429834113497','646.9837617632036','646.983761763203574','test'),('2019-11-12 15:59:59','2019-11-12 19:59:59','CMTBTC','4h','0.000002170000000','0.000002170000000','0.001494532489673','0.001494532489673','688.7246496188941','688.724649618894091','test'),('2019-11-13 01:59:59','2019-11-13 07:59:59','CMTBTC','4h','0.000002160000000','0.000002150000000','0.001494532489673','0.001487613357776','691.9131896634259','691.913189663425896','test'),('2019-11-13 15:59:59','2019-11-13 19:59:59','CMTBTC','4h','0.000002160000000','0.000002160000000','0.001494532489673','0.001494532489673','691.9131896634259','691.913189663425896','test'),('2019-11-14 03:59:59','2019-11-17 03:59:59','CMTBTC','4h','0.000002190000000','0.000002280000000','0.001494532489673','0.001555951633084','682.4349267913242','682.434926791324187','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  8:36:17
