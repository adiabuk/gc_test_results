-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 11:59:59','2019-01-11 23:59:59','ENGETH','4h','0.002296600000000','0.002308000000000','0.072144500000000','0.072502615170252','31.413611425585646','31.413611425585646','test'),('2019-01-12 15:59:59','2019-01-13 11:59:59','ENGETH','4h','0.002357100000000','0.002319900000000','0.072234028792563','0.071094023756254','30.645296674966268','30.645296674966268','test'),('2019-01-14 03:59:59','2019-01-14 15:59:59','ENGETH','4h','0.002341700000000','0.002293600000000','0.072234028792563','0.070750296126157','30.84683298140795','30.846832981407950','test'),('2019-01-16 07:59:59','2019-01-18 15:59:59','ENGETH','4h','0.002359300000000','0.002322100000000','0.072234028792563','0.071095086788120','30.616720549554103','30.616720549554103','test'),('2019-01-22 19:59:59','2019-01-27 11:59:59','ENGETH','4h','0.002443900000000','0.002499100000000','0.072234028792563','0.073865567885549','29.55686762656532','29.556867626565321','test'),('2019-02-02 03:59:59','2019-02-03 07:59:59','ENGETH','4h','0.002528600000000','0.002482200000000','0.072234028792563','0.070908528936526','28.566807242174715','28.566807242174715','test'),('2019-02-10 15:59:59','2019-02-11 19:59:59','ENGETH','4h','0.002662100000000','0.002498000000000','0.072234028792563','0.067781301951025','27.134228162940158','27.134228162940158','test'),('2019-02-12 03:59:59','2019-02-12 07:59:59','ENGETH','4h','0.002451800000000','0.002427200000000','0.072234028792563','0.071509272650832','29.46163177769924','29.461631777699239','test'),('2019-02-13 19:59:59','2019-02-14 07:59:59','ENGETH','4h','0.002532100000000','0.002501200000000','0.072234028792563','0.071352534582346','28.527320718993327','28.527320718993327','test'),('2019-02-14 11:59:59','2019-02-14 15:59:59','ENGETH','4h','0.002517400000000','0.002600000000000','0.072234028792563','0.074604145094408','28.69390195938786','28.693901959387858','test'),('2019-02-14 23:59:59','2019-02-15 15:59:59','ENGETH','4h','0.002602200000000','0.002469100000000','0.072234028792563','0.068539328449665','27.75883052515679','27.758830525156789','test'),('2019-02-23 11:59:59','2019-02-23 19:59:59','ENGETH','4h','0.002499500000000','0.002300500000000','0.072234028792563','0.066483049904897','28.89939139530426','28.899391395304260','test'),('2019-02-28 07:59:59','2019-03-04 15:59:59','ENGETH','4h','0.002441400000000','0.002504400000000','0.072234028792563','0.074098018230562','29.58713393649668','29.587133936496681','test'),('2019-03-07 15:59:59','2019-03-16 03:59:59','ENGETH','4h','0.002520400000000','0.003100600000000','0.072234028792563','0.088862414566823','28.65974797356094','28.659747973560940','test'),('2019-03-20 23:59:59','2019-03-21 15:59:59','ENGETH','4h','0.003192600000000','0.003085600000000','0.072709327447524','0.070272474087603','22.774330466555245','22.774330466555245','test'),('2019-03-21 19:59:59','2019-03-22 07:59:59','ENGETH','4h','0.003137100000000','0.003086900000000','0.072709327447524','0.071545829874012','23.177242500246724','23.177242500246724','test'),('2019-03-22 11:59:59','2019-03-22 19:59:59','ENGETH','4h','0.003096100000000','0.003124200000000','0.072709327447524','0.073369232522061','23.4841663536462','23.484166353646199','test'),('2019-03-23 03:59:59','2019-03-24 11:59:59','ENGETH','4h','0.003161000000000','0.003134000000000','0.072709327447524','0.072088273400993','23.00200172335463','23.002001723354631','test'),('2019-03-26 03:59:59','2019-04-03 03:59:59','ENGETH','4h','0.003176900000000','0.003750600000000','0.072709327447524','0.085839530210168','22.886879488660014','22.886879488660014','test'),('2019-05-24 11:59:59','2019-05-24 15:59:59','ENGETH','4h','0.002030000000000','0.001930900000000','0.075101503161829','0.071435217958215','36.99581436543277','36.995814365432771','test'),('2019-05-24 19:59:59','2019-05-24 23:59:59','ENGETH','4h','0.001999000000000','0.002004300000000','0.075101503161829','0.075300621704479','37.56953634908904','37.569536349089041','test'),('2019-05-25 07:59:59','2019-05-25 11:59:59','ENGETH','4h','0.001990500000000','0.001893500000000','0.075101503161829','0.071441696175294','37.7299689333479','37.729968933347898','test'),('2019-06-05 07:59:59','2019-06-09 19:59:59','ENGETH','4h','0.001867400000000','0.002154900000000','0.075101503161829','0.086663933363728','40.217148528343685','40.217148528343685','test'),('2019-06-11 23:59:59','2019-06-12 15:59:59','ENGETH','4h','0.002327400000000','0.002194900000000','0.076210367300429','0.071871674481272','32.74485146533838','32.744851465338378','test'),('2019-06-13 15:59:59','2019-06-14 23:59:59','ENGETH','4h','0.002201700000000','0.002178700000000','0.076210367300429','0.075414237742401','34.61432860990553','34.614328609905527','test'),('2019-06-19 19:59:59','2019-06-21 07:59:59','ENGETH','4h','0.002378800000000','0.002190000000000','0.076210367300429','0.070161722039658','32.03731599984404','32.037315999844040','test'),('2019-07-05 15:59:59','2019-07-09 07:59:59','ENGETH','4h','0.001965900000000','0.002010800000000','0.076210367300429','0.077950967275906','38.766146447138205','38.766146447138205','test'),('2019-07-09 23:59:59','2019-07-12 03:59:59','ENGETH','4h','0.002121100000000','0.002110000000000','0.076210367300429','0.075811548255106','35.92964372279902','35.929643722799021','test'),('2019-07-14 15:59:59','2019-07-15 03:59:59','ENGETH','4h','0.002166200000000','0.002137700000000','0.076210367300429','0.075207691892774','35.18159325105207','35.181593251052071','test'),('2019-07-15 11:59:59','2019-07-15 23:59:59','ENGETH','4h','0.002178500000000','0.002171700000000','0.076210367300429','0.075972483206951','34.98295492330916','34.982954923309158','test'),('2019-07-16 11:59:59','2019-07-16 19:59:59','ENGETH','4h','0.002154400000000','0.002123400000000','0.076210367300429','0.075113764354684','35.37428857242342','35.374288572423417','test'),('2019-07-23 23:59:59','2019-07-24 19:59:59','ENGETH','4h','0.002124400000000','0.002135700000000','0.076210367300429','0.076615741594580','35.87383134081576','35.873831340815762','test'),('2019-07-24 23:59:59','2019-07-27 03:59:59','ENGETH','4h','0.002137700000000','0.002057200000000','0.076210367300429','0.073340490999880','35.650637273906064','35.650637273906064','test'),('2019-07-30 23:59:59','2019-08-02 03:59:59','ENGETH','4h','0.002322700000000','0.002119600000000','0.076210367300429','0.069546430675502','32.81111090559651','32.811110905596507','test'),('2019-08-18 23:59:59','2019-08-20 19:59:59','ENGETH','4h','0.002108800000000','0.002004900000000','0.076210367300429','0.072455503319722','36.139210593906014','36.139210593906014','test'),('2019-08-20 23:59:59','2019-08-26 03:59:59','ENGETH','4h','0.002020000000000','0.002134000000000','0.076210367300429','0.080511348425305','37.72790460417277','37.727904604172771','test'),('2019-09-21 11:59:59','2019-09-23 11:59:59','ENGETH','4h','0.001928100000000','0.001745200000000','0.076210367300429','0.068981034703962','39.52614869582957','39.526148695829569','test'),('2019-09-27 07:59:59','2019-09-27 15:59:59','ENGETH','4h','0.001811700000000','0.001726800000000','0.076210367300429','0.072638992247271','42.065666114935695','42.065666114935695','test'),('2019-10-03 07:59:59','2019-10-06 11:59:59','ENGETH','4h','0.001813200000000','0.001910900000000','0.076210367300429','0.080316782966242','42.030866589691705','42.030866589691705','test'),('2019-10-21 07:59:59','2019-10-22 23:59:59','ENGETH','4h','0.001765600000000','0.001720400000000','0.076210367300429','0.074259354272575','43.164005041022314','43.164005041022314','test'),('2019-10-23 07:59:59','2019-10-23 11:59:59','ENGETH','4h','0.001756600000000','0.001740000000000','0.076210367300429','0.075490173689369','43.38515729274109','43.385157292741091','test'),('2019-10-23 15:59:59','2019-10-23 23:59:59','ENGETH','4h','0.001804700000000','0.001689500000000','0.076210367300429','0.071345606224899','42.22882878064443','42.228828780644427','test'),('2019-11-03 23:59:59','2019-11-04 07:59:59','ENGETH','4h','0.001687900000000','0.001640300000000','0.076210367300429','0.074061179858341','45.15099668252207','45.150996682522070','test'),('2019-11-04 11:59:59','2019-11-04 23:59:59','ENGETH','4h','0.001673100000000','0.001606400000000','0.076210367300429','0.073172155897083','45.55039585226765','45.550395852267648','test'),('2019-11-14 15:59:59','2019-11-15 15:59:59','ENGETH','4h','0.001605700000000','0.001595600000000','0.076210367300429','0.075730997113137','47.46239478135953','47.462394781359528','test'),('2019-11-15 19:59:59','2019-11-16 11:59:59','ENGETH','4h','0.001627900000000','0.001592600000000','0.076210367300429','0.074557792839034','46.81514054943731','46.815140549437309','test'),('2019-11-16 19:59:59','2019-11-20 11:59:59','ENGETH','4h','0.001658200000000','0.002054300000000','0.076210367300429','0.094415002741087','45.95969563407852','45.959695634078521','test'),('2019-11-22 03:59:59','2019-11-30 11:59:59','ENGETH','4h','0.002361900000000','0.003465100000000','0.076210367300429','0.111806826594147','32.26655120895423','32.266551208954233','test'),('2019-12-01 03:59:59','2019-12-02 03:59:59','ENGETH','4h','0.003799900000000','0.003474200000000','0.079082947525469','0.072304528090998','20.811849660640874','20.811849660640874','test'),('2019-12-06 03:59:59','2019-12-08 19:59:59','ENGETH','4h','0.003580200000000','0.003369300000000','0.079082947525469','0.074424382743300','22.088974785059214','22.088974785059214','test'),('2019-12-13 23:59:59','2019-12-14 15:59:59','ENGETH','4h','0.003506900000000','0.003257300000000','0.079082947525469','0.073454300086889','22.550670827645217','22.550670827645217','test'),('2019-12-16 03:59:59','2019-12-16 07:59:59','ENGETH','4h','0.003389100000000','0.003315200000000','0.079082947525469','0.077358528115557','23.334498104354843','23.334498104354843','test'),('2019-12-16 15:59:59','2019-12-16 19:59:59','ENGETH','4h','0.003410900000000','0.003327700000000','0.079082947525469','0.077153925497817','23.185360909281716','23.185360909281716','test'),('2019-12-24 11:59:59','2019-12-24 23:59:59','ENGETH','4h','0.003317500000000','0.003226100000000','0.079082947525469','0.076904143786561','23.83811530534107','23.838115305341070','test'),('2019-12-25 07:59:59','2019-12-25 11:59:59','ENGETH','4h','0.003237700000000','0.003189400000000','0.079082947525469','0.077903188324345','24.42565633797727','24.425656337977269','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 18:39:30
