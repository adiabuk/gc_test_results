-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 23:59:59','2019-01-06 07:59:59','ADXBNB','4h','0.018180000000000','0.017480000000000','0.711908500000000','0.684497281628163','39.158883388338836','39.158883388338836','test'),('2019-01-19 23:59:59','2019-01-20 11:59:59','ADXBNB','4h','0.017010000000000','0.015880000000000','0.711908500000000','0.664615342739565','41.85235155790711','41.852351557907113','test'),('2019-01-20 15:59:59','2019-01-20 19:59:59','ADXBNB','4h','0.015900000000000','0.015850000000000','0.711908500000000','0.709669794025157','44.77411949685535','44.774119496855349','test'),('2019-01-20 23:59:59','2019-01-21 03:59:59','ADXBNB','4h','0.016150000000000','0.015760000000000','0.711908500000000','0.694716901547988','44.081021671826626','44.081021671826626','test'),('2019-01-23 03:59:59','2019-01-23 23:59:59','ADXBNB','4h','0.016320000000000','0.016390000000000','0.711908500000000','0.714962029105392','43.6218443627451','43.621844362745101','test'),('2019-01-24 03:59:59','2019-01-24 07:59:59','ADXBNB','4h','0.016410000000000','0.016300000000000','0.711908500000000','0.707136413772090','43.38260207190737','43.382602071907371','test'),('2019-01-24 11:59:59','2019-01-25 07:59:59','ADXBNB','4h','0.016410000000000','0.016140000000000','0.711908500000000','0.700195197440585','43.38260207190737','43.382602071907371','test'),('2019-02-17 15:59:59','2019-02-18 03:59:59','ADXBNB','4h','0.013790000000000','0.012620000000000','0.711908500000000','0.651507271211022','51.62498187092096','51.624981870920962','test'),('2019-02-18 15:59:59','2019-02-18 19:59:59','ADXBNB','4h','0.012850000000000','0.012450000000000','0.711908500000000','0.689747924124514','55.40143968871595','55.401439688715953','test'),('2019-02-18 23:59:59','2019-02-19 03:59:59','ADXBNB','4h','0.012630000000000','0.012180000000000','0.711908500000000','0.686543589073634','56.36646872525733','56.366468725257327','test'),('2019-02-26 11:59:59','2019-02-27 15:59:59','ADXBNB','4h','0.012780000000000','0.011880000000000','0.711908500000000','0.661774098591549','55.704890453834125','55.704890453834125','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','ADXBNB','4h','0.012070000000000','0.011890000000000','0.711908500000000','0.701291803231152','58.981648715824356','58.981648715824356','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','ADXBNB','4h','0.012870000000000','0.012030000000000','0.711908500000000','0.665443609557110','55.315345765345775','55.315345765345775','test'),('2019-03-22 15:59:59','2019-03-22 19:59:59','ADXBNB','4h','0.009740000000000','0.009450000000000','0.711908500000000','0.690712045687885','73.09122176591376','73.091221765913758','test'),('2019-03-23 03:59:59','2019-03-23 07:59:59','ADXBNB','4h','0.009420000000000','0.009260000000000','0.711908500000000','0.699816635881104','75.57415074309979','75.574150743099793','test'),('2019-03-26 23:59:59','2019-03-28 23:59:59','ADXBNB','4h','0.011320000000000','0.009800000000000','0.711908500000000','0.616316545936396','62.88944346289753','62.889443462897532','test'),('2019-03-29 19:59:59','2019-03-30 03:59:59','ADXBNB','4h','0.010070000000000','0.009740000000000','0.711908500000000','0.688578827209533','70.6959781529295','70.695978152929499','test'),('2019-04-07 19:59:59','2019-04-09 07:59:59','ADXBNB','4h','0.009530000000000','0.009310000000000','0.711908500000000','0.695474096012592','74.70183630640085','74.701836306400850','test'),('2019-04-10 15:59:59','2019-04-11 11:59:59','ADXBNB','4h','0.009680000000000','0.009470000000000','0.711908500000000','0.696464204028926','73.54426652892563','73.544266528925633','test'),('2019-04-11 15:59:59','2019-04-11 23:59:59','ADXBNB','4h','0.009600000000000','0.009370000000000','0.711908500000000','0.694852358854167','74.15713541666668','74.157135416666677','test'),('2019-04-12 03:59:59','2019-04-12 07:59:59','ADXBNB','4h','0.009450000000000','0.009540000000000','0.711908500000000','0.718688580952381','75.33423280423281','75.334232804232812','test'),('2019-05-11 03:59:59','2019-05-11 07:59:59','ADXBNB','4h','0.006380000000000','0.006290000000000','0.711908500000000','0.701865903605016','111.58440438871473','111.584404388714731','test'),('2019-05-11 11:59:59','2019-05-11 15:59:59','ADXBNB','4h','0.006510000000000','0.006070000000000','0.711908500000000','0.663791796466974','109.35614439324117','109.356144393241166','test'),('2019-05-28 23:59:59','2019-05-30 03:59:59','ADXBNB','4h','0.005270000000000','0.005060000000000','0.711908500000000','0.683540229601518','135.0870018975332','135.087001897533213','test'),('2019-05-30 07:59:59','2019-06-01 07:59:59','ADXBNB','4h','0.005150000000000','0.005270000000000','0.711908500000000','0.728496659223301','138.23466019417478','138.234660194174779','test'),('2019-06-01 11:59:59','2019-06-01 15:59:59','ADXBNB','4h','0.005300000000000','0.005140000000000','0.711908500000000','0.690416922641509','134.32235849056605','134.322358490566046','test'),('2019-06-03 03:59:59','2019-06-03 23:59:59','ADXBNB','4h','0.005520000000000','0.005140000000000','0.711908500000000','0.662900306159420','128.9689311594203','128.968931159420293','test'),('2019-06-11 03:59:59','2019-06-11 11:59:59','ADXBNB','4h','0.005140000000000','0.005090000000000','0.711908500000000','0.704983320038911','138.5035992217899','138.503599221789898','test'),('2019-06-11 15:59:59','2019-06-12 03:59:59','ADXBNB','4h','0.005160000000000','0.004960000000000','0.711908500000000','0.684315147286822','137.96676356589148','137.966763565891483','test'),('2019-07-06 11:59:59','2019-07-07 15:59:59','ADXBNB','4h','0.004070000000000','0.004040000000000','0.711908500000000','0.706661017199017','174.91609336609338','174.916093366093378','test'),('2019-07-07 19:59:59','2019-07-08 11:59:59','ADXBNB','4h','0.004120000000000','0.003990000000000','0.711908500000000','0.689445367718447','172.79332524271845','172.793325242718453','test'),('2019-07-09 19:59:59','2019-07-09 23:59:59','ADXBNB','4h','0.004130000000000','0.004040000000000','0.474605666666667','0.464263170298628','114.91662631154158','114.916626311541577','test'),('2019-07-10 03:59:59','2019-07-10 23:59:59','ADXBNB','4h','0.004240000000000','0.004010000000000','0.529387306045950','0.500670541802891','124.85549670895044','124.855496708950440','test'),('2019-07-23 23:59:59','2019-07-24 15:59:59','ADXBNB','4h','0.003723000000000','0.003580000000000','0.529387306045950','0.509053600764035','142.19374323017726','142.193743230177262','test'),('2019-07-24 19:59:59','2019-07-31 15:59:59','ADXBNB','4h','0.003609000000000','0.003719000000000','0.529387306045950','0.545522690824297','146.68531616679135','146.685316166791353','test'),('2019-08-23 07:59:59','2019-08-27 19:59:59','ADXBNB','4h','0.003286000000000','0.003540000000000','0.529387306045950','0.570307688193141','161.1038667212264','161.103866721226410','test'),('2019-08-31 11:59:59','2019-09-02 15:59:59','ADXBNB','4h','0.003607000000000','0.003421000000000','0.531388630396091','0.503986832432777','147.32149442641833','147.321494426418326','test'),('2019-09-04 19:59:59','2019-09-05 23:59:59','ADXBNB','4h','0.003801000000000','0.003576000000000','0.531388630396091','0.499933107681247','139.8023231770826','139.802323177082599','test'),('2019-09-06 03:59:59','2019-09-06 11:59:59','ADXBNB','4h','0.003745000000000','0.003586000000000','0.531388630396091','0.508827671188353','141.8928252058988','141.892825205898788','test'),('2019-09-10 03:59:59','2019-09-11 07:59:59','ADXBNB','4h','0.003769000000000','0.003617000000000','0.531388630396091','0.509958258461836','140.9892890411491','140.989289041149107','test'),('2019-09-11 11:59:59','2019-09-13 11:59:59','ADXBNB','4h','0.003749000000000','0.003701000000000','0.531388630396091','0.524585041636685','141.74143248762095','141.741432487620955','test'),('2019-09-14 11:59:59','2019-09-17 19:59:59','ADXBNB','4h','0.003736000000000','0.003735000000000','0.531388630396091','0.531246395751981','142.23464411030272','142.234644110302725','test'),('2019-09-19 23:59:59','2019-09-20 03:59:59','ADXBNB','4h','0.003838000000000','0.003738000000000','0.531388630396091','0.517543173637464','138.45456758626653','138.454567586266535','test'),('2019-09-20 07:59:59','2019-09-22 15:59:59','ADXBNB','4h','0.003980000000000','0.003893000000000','0.531388630396091','0.519772848776880','133.51473125529924','133.514731255299239','test'),('2019-09-25 23:59:59','2019-09-26 15:59:59','ADXBNB','4h','0.003910000000000','0.003860000000000','0.531388630396091','0.524593379368008','135.90502056166008','135.905020561660081','test'),('2019-09-27 11:59:59','2019-10-01 03:59:59','ADXBNB','4h','0.004058000000000','0.003980000000000','0.531388630396091','0.521174654750232','130.94840571613872','130.948405716138723','test'),('2019-10-01 23:59:59','2019-10-07 07:59:59','ADXBNB','4h','0.004232000000000','0.005288000000000','0.531388630396091','0.663984659152772','125.56442117109901','125.564421171099013','test'),('2019-11-01 07:59:59','2019-11-03 03:59:59','ADXBNB','4h','0.004441000000000','0.004044000000000','0.531388630396091','0.483885526080115','119.65517459943504','119.655174599435043','test'),('2019-11-03 23:59:59','2019-11-04 03:59:59','ADXBNB','4h','0.004181000000000','0.004000000000000','0.531388630396091','0.508384243383010','127.09606084575245','127.096060845752447','test'),('2019-11-08 11:59:59','2019-11-10 03:59:59','ADXBNB','4h','0.004336000000000','0.004123000000000','0.531388630396091','0.505284899244254','122.55272841238262','122.552728412382621','test'),('2019-11-17 03:59:59','2019-11-20 07:59:59','ADXBNB','4h','0.004175000000000','0.004149000000000','0.531388630396091','0.528079383835540','127.27871386732718','127.278713867327184','test'),('2019-11-20 11:59:59','2019-11-21 23:59:59','ADXBNB','4h','0.004217000000000','0.004209000000000','0.531388630396091','0.530380541934348','126.01105771783043','126.011057717830425','test'),('2019-11-22 19:59:59','2019-11-23 19:59:59','ADXBNB','4h','0.004298000000000','0.004342000000000','0.531388630396091','0.536828625681672','123.63625649048186','123.636256490481856','test'),('2019-11-24 19:59:59','2019-11-24 23:59:59','ADXBNB','4h','0.004341000000000','0.004329000000000','0.531388630396091','0.529919691542197','122.41157115781868','122.411571157818685','test'),('2019-11-25 19:59:59','2019-11-30 19:59:59','ADXBNB','4h','0.004505000000000','0.004746000000000','0.531388630396091','0.559815857904517','117.95530086483706','117.955300864837056','test'),('2019-12-01 15:59:59','2019-12-03 19:59:59','ADXBNB','4h','0.005299000000000','0.005000000000000','0.531388630396091','0.501404633323354','100.28092666467087','100.280926664670872','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:07:58
