-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 15:59:59','2019-01-03 23:59:59','BLZBTC','4h','0.000011660000000','0.000011430000000','0.001467500000000','0.001438552744425','125.85763293310464','125.857632933104640','test'),('2019-01-04 03:59:59','2019-01-07 03:59:59','BLZBTC','4h','0.000011510000000','0.000011490000000','0.001467500000000','0.001464950043440','127.49782797567333','127.497827975673331','test'),('2019-01-16 11:59:59','2019-01-18 15:59:59','BLZBTC','4h','0.000011790000000','0.000011230000000','0.001467500000000','0.001397796861747','124.4698897370653','124.469889737065301','test'),('2019-01-18 19:59:59','2019-01-20 15:59:59','BLZBTC','4h','0.000011870000000','0.000011570000000','0.001467500000000','0.001430410699242','123.63100252737996','123.631002527379962','test'),('2019-01-22 07:59:59','2019-01-23 23:59:59','BLZBTC','4h','0.000011900000000','0.000011900000000','0.001467500000000','0.001467500000000','123.31932773109244','123.319327731092443','test'),('2019-02-08 11:59:59','2019-02-08 19:59:59','BLZBTC','4h','0.000011180000000','0.000011440000000','0.001467500000000','0.001501627906977','131.26118067978533','131.261180679785326','test'),('2019-02-09 03:59:59','2019-02-09 15:59:59','BLZBTC','4h','0.000011450000000','0.000011060000000','0.001467500000000','0.001417515283843','128.16593886462883','128.165938864628828','test'),('2019-02-09 23:59:59','2019-02-10 03:59:59','BLZBTC','4h','0.000010990000000','0.000010960000000','0.001467500000000','0.001463494085532','133.5304822565969','133.530482256596912','test'),('2019-02-16 07:59:59','2019-02-18 03:59:59','BLZBTC','4h','0.000011090000000','0.000011220000000','0.001467500000000','0.001484702434626','132.32642019837692','132.326420198376923','test'),('2019-02-18 11:59:59','2019-02-18 15:59:59','BLZBTC','4h','0.000011400000000','0.000011120000000','0.001467500000000','0.001431456140351','128.7280701754386','128.728070175438603','test'),('2019-02-22 11:59:59','2019-02-23 19:59:59','BLZBTC','4h','0.000011200000000','0.000011210000000','0.001467500000000','0.001468810267857','131.02678571428572','131.026785714285722','test'),('2019-02-23 23:59:59','2019-02-24 15:59:59','BLZBTC','4h','0.000011250000000','0.000010880000000','0.001467500000000','0.001419235555556','130.44444444444443','130.444444444444429','test'),('2019-02-26 11:59:59','2019-02-26 15:59:59','BLZBTC','4h','0.000011360000000','0.000012000000000','0.001467500000000','0.001550176056338','129.18133802816902','129.181338028169023','test'),('2019-02-27 11:59:59','2019-02-27 23:59:59','BLZBTC','4h','0.000011580000000','0.000011440000000','0.001467500000000','0.001449758203800','126.72711571675303','126.727115716753033','test'),('2019-03-01 15:59:59','2019-03-07 15:59:59','BLZBTC','4h','0.000011730000000','0.000012900000000','0.001467500000000','0.001613874680307','125.10656436487639','125.106564364876391','test'),('2019-03-09 07:59:59','2019-03-11 07:59:59','BLZBTC','4h','0.000013730000000','0.000013020000000','0.001467500000000','0.001391613255645','106.88273852876912','106.882738528769124','test'),('2019-03-12 11:59:59','2019-03-17 07:59:59','BLZBTC','4h','0.000014230000000','0.000014230000000','0.001467500000000','0.001467500000000','103.12719606465215','103.127196064652153','test'),('2019-03-27 11:59:59','2019-04-02 07:59:59','BLZBTC','4h','0.000014850000000','0.000014950000000','0.001467500000000','0.001477382154882','98.82154882154883','98.821548821548831','test'),('2019-04-05 07:59:59','2019-04-08 11:59:59','BLZBTC','4h','0.000016090000000','0.000015840000000','0.001467500000000','0.001444698570541','91.20571783716595','91.205717837165949','test'),('2019-05-19 07:59:59','2019-05-19 23:59:59','BLZBTC','4h','0.000008550000000','0.000007610000000','0.001467500000000','0.001306160818713','171.6374269005848','171.637426900584813','test'),('2019-05-20 03:59:59','2019-05-20 07:59:59','BLZBTC','4h','0.000007690000000','0.000007690000000','0.001467500000000','0.001467500000000','190.8322496749025','190.832249674902499','test'),('2019-05-20 19:59:59','2019-05-24 19:59:59','BLZBTC','4h','0.000007800000000','0.000007970000000','0.001467500000000','0.001499483974359','188.14102564102566','188.141025641025664','test'),('2019-05-24 23:59:59','2019-05-25 03:59:59','BLZBTC','4h','0.000008140000000','0.000008400000000','0.001467500000000','0.001514373464373','180.28255528255528','180.282555282555279','test'),('2019-06-06 23:59:59','2019-06-09 15:59:59','BLZBTC','4h','0.000007750000000','0.000007890000000','0.001467500000000','0.001494009677419','189.3548387096774','189.354838709677409','test'),('2019-06-10 11:59:59','2019-06-11 15:59:59','BLZBTC','4h','0.000008360000000','0.000007920000000','0.001467500000000','0.001390263157895','175.53827751196175','175.538277511961752','test'),('2019-06-12 11:59:59','2019-06-12 15:59:59','BLZBTC','4h','0.000008090000000','0.000007940000000','0.001467500000000','0.001440290482077','181.39678615574783','181.396786155747833','test'),('2019-06-13 15:59:59','2019-06-14 11:59:59','BLZBTC','4h','0.000008150000000','0.000007350000000','0.001467500000000','0.001323450920245','180.06134969325154','180.061349693251543','test'),('2019-07-25 19:59:59','2019-08-01 07:59:59','BLZBTC','4h','0.000003750000000','0.000004090000000','0.001467500000000','0.001600553333333','391.3333333333333','391.333333333333314','test'),('2019-08-19 15:59:59','2019-08-19 19:59:59','BLZBTC','4h','0.000003060000000','0.000003030000000','0.001467500000000','0.001453112745098','479.57516339869284','479.575163398692837','test'),('2019-08-21 03:59:59','2019-08-26 03:59:59','BLZBTC','4h','0.000003100000000','0.000003370000000','0.001467500000000','0.001595314516129','473.3870967741936','473.387096774193594','test'),('2019-08-26 11:59:59','2019-08-28 03:59:59','BLZBTC','4h','0.000003590000000','0.000003400000000','0.001467500000000','0.001389832869081','408.77437325905294','408.774373259052936','test'),('2019-08-31 07:59:59','2019-08-31 11:59:59','BLZBTC','4h','0.000003450000000','0.000003340000000','0.001467500000000','0.001420710144928','425.36231884057975','425.362318840579746','test'),('2019-09-11 11:59:59','2019-09-12 15:59:59','BLZBTC','4h','0.000003210000000','0.000003060000000','0.001467500000000','0.001398925233645','457.1651090342679','457.165109034267914','test'),('2019-09-13 19:59:59','2019-09-23 23:59:59','BLZBTC','4h','0.000003210000000','0.000003500000000','0.001467500000000','0.001600077881620','457.1651090342679','457.165109034267914','test'),('2019-10-07 11:59:59','2019-10-07 19:59:59','BLZBTC','4h','0.000003290000000','0.000003210000000','0.001467500000000','0.001431816109422','446.048632218845','446.048632218845000','test'),('2019-10-07 23:59:59','2019-10-08 07:59:59','BLZBTC','4h','0.000003230000000','0.000003260000000','0.001467500000000','0.001481130030960','454.33436532507744','454.334365325077442','test'),('2019-10-08 11:59:59','2019-10-09 15:59:59','BLZBTC','4h','0.000003410000000','0.000003160000000','0.001467500000000','0.001359912023460','430.3519061583578','430.351906158357792','test'),('2019-10-09 19:59:59','2019-10-09 23:59:59','BLZBTC','4h','0.000003170000000','0.000003210000000','0.001467500000000','0.001486017350158','462.93375394321765','462.933753943217653','test'),('2019-10-14 11:59:59','2019-10-16 07:59:59','BLZBTC','4h','0.000003380000000','0.000003250000000','0.001467500000000','0.001411057692308','434.1715976331361','434.171597633136116','test'),('2019-10-21 19:59:59','2019-10-22 07:59:59','BLZBTC','4h','0.000003330000000','0.000003290000000','0.001467500000000','0.001449872372372','440.6906906906907','440.690690690690701','test'),('2019-10-22 19:59:59','2019-10-23 03:59:59','BLZBTC','4h','0.000003270000000','0.000003240000000','0.001467500000000','0.001454036697248','448.77675840978594','448.776758409785941','test'),('2019-10-25 11:59:59','2019-10-25 15:59:59','BLZBTC','4h','0.000003270000000','0.000003070000000','0.001467500000000','0.001377744648318','448.77675840978594','448.776758409785941','test'),('2019-11-09 19:59:59','2019-11-13 15:59:59','BLZBTC','4h','0.000002930000000','0.000003480000000','0.001467500000000','0.001742969283276','500.85324232081916','500.853242320819163','test'),('2019-12-09 07:59:59','2019-12-10 03:59:59','BLZBTC','4h','0.000002960000000','0.000002780000000','0.001467500000000','0.001378260135135','495.77702702702703','495.777027027027032','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31 10:53:34
