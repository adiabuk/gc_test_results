-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 07:59:59','2019-01-08 11:59:59','SYSBTC','4h','0.000012620000000','0.000012360000000','0.001467500000000','0.001437266244057','116.28367670364501','116.283676703645014','test'),('2019-01-08 15:59:59','2019-01-08 19:59:59','SYSBTC','4h','0.000012430000000','0.000012340000000','0.001467500000000','0.001456874497184','118.0611423974256','118.061142397425598','test'),('2019-01-09 07:59:59','2019-01-09 11:59:59','SYSBTC','4h','0.000012400000000','0.000012450000000','0.001467500000000','0.001473417338710','118.3467741935484','118.346774193548399','test'),('2019-01-18 15:59:59','2019-01-18 19:59:59','SYSBTC','4h','0.000011870000000','0.000011740000000','0.001467500000000','0.001451427969671','123.63100252737996','123.631002527379962','test'),('2019-01-19 03:59:59','2019-01-20 03:59:59','SYSBTC','4h','0.000011740000000','0.000011720000000','0.001467500000000','0.001465000000000','125.00000000000001','125.000000000000014','test'),('2019-01-20 07:59:59','2019-01-20 15:59:59','SYSBTC','4h','0.000011860000000','0.000011910000000','0.001467500000000','0.001473686762226','123.73524451939292','123.735244519392921','test'),('2019-01-20 23:59:59','2019-01-22 11:59:59','SYSBTC','4h','0.000012250000000','0.000011900000000','0.001467500000000','0.001425571428571','119.79591836734694','119.795918367346943','test'),('2019-01-22 15:59:59','2019-01-23 15:59:59','SYSBTC','4h','0.000012070000000','0.000012060000000','0.001467500000000','0.001466284175642','121.5824357912179','121.582435791217904','test'),('2019-01-24 15:59:59','2019-01-27 15:59:59','SYSBTC','4h','0.000012640000000','0.000011970000000','0.001467500000000','0.001389713212025','116.09968354430382','116.099683544303815','test'),('2019-01-27 19:59:59','2019-01-28 03:59:59','SYSBTC','4h','0.000012600000000','0.000012000000000','0.001467500000000','0.001397619047619','116.46825396825398','116.468253968253975','test'),('2019-02-03 23:59:59','2019-02-04 07:59:59','SYSBTC','4h','0.000012210000000','0.000012190000000','0.001467500000000','0.001465096232596','120.18837018837019','120.188370188370186','test'),('2019-02-04 11:59:59','2019-02-05 07:59:59','SYSBTC','4h','0.000012200000000','0.000012110000000','0.001467500000000','0.001456674180328','120.28688524590164','120.286885245901644','test'),('2019-02-05 11:59:59','2019-02-05 15:59:59','SYSBTC','4h','0.000012180000000','0.000012140000000','0.001467500000000','0.001462680623974','120.48440065681446','120.484400656814458','test'),('2019-02-17 15:59:59','2019-02-18 15:59:59','SYSBTC','4h','0.000012350000000','0.000011640000000','0.001467500000000','0.001383133603239','118.82591093117409','118.825910931174093','test'),('2019-02-19 11:59:59','2019-02-23 19:59:59','SYSBTC','4h','0.000013290000000','0.000013110000000','0.001467500000000','0.001447624153499','110.42136945071483','110.421369450714835','test'),('2019-02-27 23:59:59','2019-02-28 11:59:59','SYSBTC','4h','0.000013310000000','0.000012920000000','0.001467500000000','0.001424500375657','110.25544703230655','110.255447032306549','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','SYSBTC','4h','0.000013060000000','0.000012780000000','0.001467500000000','0.001436037519142','112.36600306278714','112.366003062787144','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','SYSBTC','4h','0.000012830000000','0.000013140000000','0.001467500000000','0.001502957911146','114.38035853468433','114.380358534684333','test'),('2019-03-01 07:59:59','2019-03-02 07:59:59','SYSBTC','4h','0.000013250000000','0.000013050000000','0.001467500000000','0.001445349056604','110.75471698113208','110.754716981132077','test'),('2019-03-02 23:59:59','2019-03-03 03:59:59','SYSBTC','4h','0.000012980000000','0.000013010000000','0.001467500000000','0.001470891756549','113.05855161787366','113.058551617873661','test'),('2019-03-03 19:59:59','2019-03-04 11:59:59','SYSBTC','4h','0.000013490000000','0.000013020000000','0.001467500000000','0.001416371386212','108.78428465530023','108.784284655300226','test'),('2019-03-04 15:59:59','2019-03-08 23:59:59','SYSBTC','4h','0.000013270000000','0.000013820000000','0.001467500000000','0.001528323285607','110.58779201205728','110.587792012057278','test'),('2019-03-09 07:59:59','2019-03-10 19:59:59','SYSBTC','4h','0.000013950000000','0.000013910000000','0.001467500000000','0.001463292114695','105.19713261648745','105.197132616487451','test'),('2019-03-13 07:59:59','2019-03-16 03:59:59','SYSBTC','4h','0.000013900000000','0.000013950000000','0.001467500000000','0.001472778776978','105.57553956834532','105.575539568345320','test'),('2019-03-17 15:59:59','2019-03-18 11:59:59','SYSBTC','4h','0.000014210000000','0.000013980000000','0.001467500000000','0.001443747361013','103.27234342012667','103.272343420126674','test'),('2019-03-19 03:59:59','2019-03-20 07:59:59','SYSBTC','4h','0.000014690000000','0.000014210000000','0.001467500000000','0.001419549012934','99.89788972089858','99.897889720898576','test'),('2019-03-20 11:59:59','2019-03-21 15:59:59','SYSBTC','4h','0.000014480000000','0.000014410000000','0.001467500000000','0.001460405732044','101.34668508287292','101.346685082872924','test'),('2019-03-21 23:59:59','2019-03-23 23:59:59','SYSBTC','4h','0.000014510000000','0.000014510000000','0.001467500000000','0.001467500000000','101.13714679531358','101.137146795313583','test'),('2019-03-26 03:59:59','2019-03-26 15:59:59','SYSBTC','4h','0.000015060000000','0.000014520000000','0.001467500000000','0.001414880478088','97.44355909694555','97.443559096945549','test'),('2019-03-26 19:59:59','2019-03-26 23:59:59','SYSBTC','4h','0.000014550000000','0.000014720000000','0.001467500000000','0.001484646048110','100.85910652920963','100.859106529209626','test'),('2019-03-27 07:59:59','2019-03-31 03:59:59','SYSBTC','4h','0.000014730000000','0.000014840000000','0.001467500000000','0.001478458927359','99.6266123557366','99.626612355736597','test'),('2019-05-06 19:59:59','2019-05-07 07:59:59','SYSBTC','4h','0.000010910000000','0.000010340000000','0.001467500000000','0.001390829514207','134.5096241979835','134.509624197983499','test'),('2019-05-07 11:59:59','2019-05-07 15:59:59','SYSBTC','4h','0.000010360000000','0.000010120000000','0.001467500000000','0.001433503861004','141.65057915057915','141.650579150579148','test'),('2019-05-08 11:59:59','2019-05-08 19:59:59','SYSBTC','4h','0.000010620000000','0.000010370000000','0.001467500000000','0.001432954331450','138.18267419962336','138.182674199623364','test'),('2019-05-08 23:59:59','2019-05-09 03:59:59','SYSBTC','4h','0.000010450000000','0.000010270000000','0.001467500000000','0.001442222488038','140.4306220095694','140.430622009569390','test'),('2019-05-19 03:59:59','2019-05-20 23:59:59','SYSBTC','4h','0.000009800000000','0.000008600000000','0.001467500000000','0.001287806122449','149.7448979591837','149.744897959183703','test'),('2019-05-22 03:59:59','2019-05-24 11:59:59','SYSBTC','4h','0.000009350000000','0.000008850000000','0.001467500000000','0.001389024064171','156.95187165775403','156.951871657754026','test'),('2019-06-02 03:59:59','2019-06-03 07:59:59','SYSBTC','4h','0.000008730000000','0.000008440000000','0.001467500000000','0.001418751431844','168.09851088201606','168.098510882016058','test'),('2019-06-03 11:59:59','2019-06-03 23:59:59','SYSBTC','4h','0.000008830000000','0.000008510000000','0.001467500000000','0.001414317667044','166.19479048697622','166.194790486976217','test'),('2019-06-13 07:59:59','2019-06-13 15:59:59','SYSBTC','4h','0.000008640000000','0.000008290000000','0.001467500000000','0.001408052662037','169.84953703703704','169.849537037037038','test'),('2019-07-22 15:59:59','2019-07-22 19:59:59','SYSBTC','4h','0.000003390000000','0.000003130000000','0.001467500000000','0.001354948377581','432.89085545722713','432.890855457227133','test'),('2019-07-23 03:59:59','2019-07-24 03:59:59','SYSBTC','4h','0.000003150000000','0.000003150000000','0.001467500000000','0.001467500000000','465.8730158730159','465.873015873015902','test'),('2019-07-24 07:59:59','2019-07-31 15:59:59','SYSBTC','4h','0.000003160000000','0.000003650000000','0.001467500000000','0.001695055379747','464.39873417721526','464.398734177215260','test'),('2019-08-17 07:59:59','2019-08-18 07:59:59','SYSBTC','4h','0.000002840000000','0.000002460000000','0.001467500000000','0.001271144366197','516.7253521126761','516.725352112676092','test'),('2019-08-18 11:59:59','2019-08-19 03:59:59','SYSBTC','4h','0.000002550000000','0.000002490000000','0.001467500000000','0.001432970588235','575.4901960784314','575.490196078431381','test'),('2019-08-22 03:59:59','2019-08-23 15:59:59','SYSBTC','4h','0.000002480000000','0.000002470000000','0.001467500000000','0.001461582661290','591.733870967742','591.733870967741950','test'),('2019-08-24 11:59:59','2019-08-26 03:59:59','SYSBTC','4h','0.000002810000000','0.000002640000000','0.001467500000000','0.001378718861210','522.2419928825623','522.241992882562272','test'),('2019-08-26 07:59:59','2019-08-26 15:59:59','SYSBTC','4h','0.000002680000000','0.000002670000000','0.001467500000000','0.001462024253731','547.5746268656716','547.574626865671576','test'),('2019-08-27 15:59:59','2019-08-28 19:59:59','SYSBTC','4h','0.000002780000000','0.000002520000000','0.001467500000000','0.001330251798561','527.8776978417267','527.877697841726672','test'),('2019-08-29 19:59:59','2019-08-31 07:59:59','SYSBTC','4h','0.000002720000000','0.000002640000000','0.001467500000000','0.001424338235294','539.5220588235295','539.522058823529505','test'),('2019-09-01 15:59:59','2019-09-01 23:59:59','SYSBTC','4h','0.000002710000000','0.000002690000000','0.000978333333333','0.000971113161131','361.00861008610093','361.008610086100930','test'),('2019-09-02 03:59:59','2019-09-02 11:59:59','SYSBTC','4h','0.000002720000000','0.000002650000000','0.001091383925842','0.001063296839515','401.24409038299615','401.244090382996148','test'),('2019-09-11 03:59:59','2019-09-11 15:59:59','SYSBTC','4h','0.000002560000000','0.000002520000000','0.001091383925842','0.001074331052001','426.32184603203126','426.321846032031260','test'),('2019-09-18 11:59:59','2019-09-23 03:59:59','SYSBTC','4h','0.000002560000000','0.000002610000000','0.001091383925842','0.001112700018144','426.32184603203126','426.321846032031260','test'),('2019-09-23 07:59:59','2019-09-23 11:59:59','SYSBTC','4h','0.000002630000000','0.000002560000000','0.001091383925842','0.001062335684470','414.9748767460077','414.974876746007681','test'),('2019-09-27 11:59:59','2019-10-01 07:59:59','SYSBTC','4h','0.000002710000000','0.000002800000000','0.001091383925842','0.001127629148471','402.7246958826569','402.724695882656874','test'),('2019-10-01 11:59:59','2019-10-01 19:59:59','SYSBTC','4h','0.000002940000000','0.000002820000000','0.001091383925842','0.001046837643155','371.21902239523814','371.219022395238142','test'),('2019-10-02 11:59:59','2019-10-09 15:59:59','SYSBTC','4h','0.000002920000000','0.000002990000000','0.001091383925842','0.001117547239133','373.7616184390411','373.761618439041115','test'),('2019-10-13 15:59:59','2019-10-14 19:59:59','SYSBTC','4h','0.000003210000000','0.000003100000000','0.001091383925842','0.001053984476670','339.9949924741433','339.994992474143316','test'),('2019-10-14 23:59:59','2019-10-15 03:59:59','SYSBTC','4h','0.000003110000000','0.000003080000000','0.001091383925842','0.001080856106622','350.92730734469455','350.927307344694555','test'),('2019-10-15 07:59:59','2019-10-15 19:59:59','SYSBTC','4h','0.000003120000000','0.000003080000000','0.001091383925842','0.001077391824229','349.8025403339744','349.802540333974378','test'),('2019-11-02 11:59:59','2019-11-02 15:59:59','SYSBTC','4h','0.000002820000000','0.000002780000000','0.001091383925842','0.001075903302780','387.01557653971633','387.015576539716335','test'),('2019-11-02 19:59:59','2019-11-07 03:59:59','SYSBTC','4h','0.000002840000000','0.000002810000000','0.001091383925842','0.001079855222400','384.2901147330986','384.290114733098619','test'),('2019-11-10 11:59:59','2019-11-10 19:59:59','SYSBTC','4h','0.000002880000000','0.000002780000000','0.001091383925842','0.001053488650639','378.9527520284723','378.952752028472275','test'),('2019-11-10 23:59:59','2019-11-11 03:59:59','SYSBTC','4h','0.000002800000000','0.000002810000000','0.001091383925842','0.001095281725577','389.77997351500005','389.779973515000052','test'),('2019-11-12 07:59:59','2019-11-12 11:59:59','SYSBTC','4h','0.000002830000000','0.000002830000000','0.001091383925842','0.001091383925842','385.6480303328622','385.648030332862220','test'),('2019-11-12 19:59:59','2019-11-14 15:59:59','SYSBTC','4h','0.000002820000000','0.000002840000000','0.001091383925842','0.001099124237373','387.01557653971633','387.015576539716335','test'),('2019-11-14 19:59:59','2019-11-17 23:59:59','SYSBTC','4h','0.000002870000000','0.000003000000000','0.001091383925842','0.001140819434678','380.273144892683','380.273144892682978','test'),('2019-11-27 11:59:59','2019-11-27 15:59:59','SYSBTC','4h','0.000002950000000','0.000002900000000','0.001091383925842','0.001072885893201','369.96065282779665','369.960652827796650','test'),('2019-11-27 23:59:59','2019-11-28 03:59:59','SYSBTC','4h','0.000002870000000','0.000002890000000','0.001091383925842','0.001098989388740','380.273144892683','380.273144892682978','test'),('2019-11-28 07:59:59','2019-11-29 15:59:59','SYSBTC','4h','0.000002910000000','0.000002880000000','0.001091383925842','0.001080132545163','375.04602262611684','375.046022626116837','test'),('2019-11-29 19:59:59','2019-11-29 23:59:59','SYSBTC','4h','0.000002910000000','0.000002880000000','0.001091383925842','0.001080132545163','375.04602262611684','375.046022626116837','test'),('2019-11-30 19:59:59','2019-12-04 07:59:59','SYSBTC','4h','0.000003040000000','0.000003010000000','0.001091383925842','0.001080613689732','359.00787034276317','359.007870342763169','test'),('2019-12-07 19:59:59','2019-12-08 11:59:59','SYSBTC','4h','0.000003180000000','0.000002990000000','0.001091383925842','0.001026175452285','343.2024924031447','343.202492403144674','test'),('2019-12-08 15:59:59','2019-12-09 03:59:59','SYSBTC','4h','0.000003010000000','0.000003000000000','0.001091383925842','0.001087758065623','362.58602187441863','362.586021874418634','test'),('2019-12-09 07:59:59','2019-12-10 03:59:59','SYSBTC','4h','0.000003020000000','0.000002900000000','0.001091383925842','0.001048017677133','361.3854059079471','361.385405907947074','test'),('2019-12-11 23:59:59','2019-12-12 11:59:59','SYSBTC','4h','0.000003020000000','0.000002970000000','0.001091383925842','0.001073314655547','361.3854059079471','361.385405907947074','test'),('2019-12-15 07:59:59','2019-12-16 19:59:59','SYSBTC','4h','0.000003100000000','0.000003020000000','0.001091383925842','0.001063219179369','352.05933091677423','352.059330916774229','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  6:17:42
