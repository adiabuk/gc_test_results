-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 07:59:59','2019-01-14 15:59:59','KMDETH','4h','0.005405000000000','0.005260000000000','0.072144500000000','0.070209078630897','13.3477335800185','13.347733580018501','test'),('2019-01-16 15:59:59','2019-01-19 11:59:59','KMDETH','4h','0.005500000000000','0.005480000000000','0.072144500000000','0.071882156363636','13.11718181818182','13.117181818181820','test'),('2019-01-19 19:59:59','2019-01-20 23:59:59','KMDETH','4h','0.005624000000000','0.005539000000000','0.072144500000000','0.071054122599573','12.827969416785207','12.827969416785207','test'),('2019-01-21 23:59:59','2019-01-22 03:59:59','KMDETH','4h','0.005557000000000','0.005472000000000','0.072144500000000','0.071040976066223','12.982634515026092','12.982634515026092','test'),('2019-01-22 23:59:59','2019-01-23 07:59:59','KMDETH','4h','0.005599000000000','0.005585000000000','0.072144500000000','0.071964106536882','12.885247365601','12.885247365601000','test'),('2019-01-23 11:59:59','2019-01-29 07:59:59','KMDETH','4h','0.005616000000000','0.005774000000000','0.072144500000000','0.074174206374644','12.846242877492877','12.846242877492877','test'),('2019-02-01 19:59:59','2019-02-05 11:59:59','KMDETH','4h','0.006098000000000','0.005958000000000','0.072144500000000','0.070488181534929','11.830846179075106','11.830846179075106','test'),('2019-02-05 15:59:59','2019-02-05 19:59:59','KMDETH','4h','0.006052000000000','0.005910000000000','0.072144500000000','0.070451750660939','11.920769993390614','11.920769993390614','test'),('2019-02-12 15:59:59','2019-02-15 15:59:59','KMDETH','4h','0.006504000000000','0.006155000000000','0.072144500000000','0.068273277598401','11.092327798277982','11.092327798277982','test'),('2019-02-17 07:59:59','2019-02-19 03:59:59','KMDETH','4h','0.006575000000000','0.006293000000000','0.072144500000000','0.069050241596958','10.97254752851711','10.972547528517110','test'),('2019-02-20 07:59:59','2019-02-21 15:59:59','KMDETH','4h','0.006663000000000','0.006341000000000','0.072144500000000','0.068658003076692','10.827630196608135','10.827630196608135','test'),('2019-02-24 15:59:59','2019-02-27 15:59:59','KMDETH','4h','0.007299000000000','0.007457000000000','0.072144500000000','0.073706197629812','9.884162214001918','9.884162214001918','test'),('2019-02-28 03:59:59','2019-03-02 11:59:59','KMDETH','4h','0.007306000000000','0.007282000000000','0.072144500000000','0.071907507391185','9.874692033944703','9.874692033944703','test'),('2019-03-13 03:59:59','2019-03-13 15:59:59','KMDETH','4h','0.010143000000000','0.007964000000000','0.072144500000000','0.056645844227546','7.112737848762694','7.112737848762694','test'),('2019-03-13 19:59:59','2019-03-15 03:59:59','KMDETH','4h','0.008314000000000','0.007492000000000','0.072144500000000','0.065011618234304','8.677471734423863','8.677471734423863','test'),('2019-03-15 11:59:59','2019-03-16 07:59:59','KMDETH','4h','0.008138000000000','0.007493000000000','0.072144500000000','0.066426485438683','8.865138854755468','8.865138854755468','test'),('2019-03-16 11:59:59','2019-03-16 15:59:59','KMDETH','4h','0.007609000000000','0.007697000000000','0.072144500000000','0.072978869299514','9.481469312656065','9.481469312656065','test'),('2019-03-16 19:59:59','2019-03-17 07:59:59','KMDETH','4h','0.007912000000000','0.007712000000000','0.072144500000000','0.070320827098079','9.118364509605662','9.118364509605662','test'),('2019-03-17 19:59:59','2019-03-18 07:59:59','KMDETH','4h','0.007827000000000','0.007698000000000','0.072144500000000','0.070955456880031','9.217388526894084','9.217388526894084','test'),('2019-03-19 03:59:59','2019-03-19 07:59:59','KMDETH','4h','0.007796000000000','0.007711000000000','0.072144500000000','0.071357906554643','9.254040533606979','9.254040533606979','test'),('2019-03-19 19:59:59','2019-03-20 03:59:59','KMDETH','4h','0.007887000000000','0.007735000000000','0.072144500000000','0.070754115316343','9.147267655635856','9.147267655635856','test'),('2019-03-20 15:59:59','2019-03-21 15:59:59','KMDETH','4h','0.007831000000000','0.007712000000000','0.072144500000000','0.071048191035628','9.212680372877028','9.212680372877028','test'),('2019-03-21 19:59:59','2019-03-22 03:59:59','KMDETH','4h','0.007805000000000','0.007651000000000','0.072144500000000','0.070721021076233','9.243369634849454','9.243369634849454','test'),('2019-03-28 19:59:59','2019-03-29 23:59:59','KMDETH','4h','0.008124000000000','0.007697000000000','0.072144500000000','0.068352562346135','8.880416051206304','8.880416051206304','test'),('2019-03-31 11:59:59','2019-04-02 07:59:59','KMDETH','4h','0.007822000000000','0.007894000000000','0.072144500000000','0.072808576195346','9.223280490923036','9.223280490923036','test'),('2019-04-02 15:59:59','2019-04-02 19:59:59','KMDETH','4h','0.007878000000000','0.007689000000000','0.072144500000000','0.070413691355674','9.157717694846408','9.157717694846408','test'),('2019-05-04 23:59:59','2019-05-06 15:59:59','KMDETH','4h','0.006357000000000','0.006167000000000','0.072144500000000','0.069988222667925','11.34882806355199','11.348828063551990','test'),('2019-05-07 19:59:59','2019-05-10 19:59:59','KMDETH','4h','0.006528000000000','0.006568000000000','0.072144500000000','0.072586561887255','11.051547181372548','11.051547181372548','test'),('2019-05-10 23:59:59','2019-05-11 03:59:59','KMDETH','4h','0.006659000000000','0.006705000000000','0.072144500000000','0.072642870175702','10.834134254392552','10.834134254392552','test'),('2019-05-28 23:59:59','2019-06-01 03:59:59','KMDETH','4h','0.005218000000000','0.005291000000000','0.072144500000000','0.073153804043695','13.826082790341125','13.826082790341125','test'),('2019-06-01 19:59:59','2019-06-11 03:59:59','KMDETH','4h','0.005800000000000','0.006742000000000','0.072144500000000','0.083861761896552','12.438706896551725','12.438706896551725','test'),('2019-06-14 07:59:59','2019-06-14 11:59:59','KMDETH','4h','0.006778000000000','0.006571000000000','0.072144500000000','0.069941208247271','10.643921510770138','10.643921510770138','test'),('2019-07-02 07:59:59','2019-07-02 15:59:59','KMDETH','4h','0.004703000000000','0.004697000000000','0.072144500000000','0.072052459387625','15.34010206251329','15.340102062513290','test'),('2019-07-02 23:59:59','2019-07-03 07:59:59','KMDETH','4h','0.004664000000000','0.004539000000000','0.072144500000000','0.070210953151801','15.468374785591768','15.468374785591768','test'),('2019-07-03 11:59:59','2019-07-03 15:59:59','KMDETH','4h','0.004664000000000','0.004557000000000','0.072144500000000','0.070489383897942','15.468374785591768','15.468374785591768','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','KMDETH','4h','0.004624000000000','0.004415000000000','0.072144500000000','0.068883643490484','15.602184256055365','15.602184256055365','test'),('2019-07-04 15:59:59','2019-07-08 07:59:59','KMDETH','4h','0.004983000000000','0.005312000000000','0.072144500000000','0.076907803331327','14.47812562713225','14.478125627132250','test'),('2019-07-12 07:59:59','2019-07-13 23:59:59','KMDETH','4h','0.005451000000000','0.005364000000000','0.072144500000000','0.070993046780407','13.235094478077416','13.235094478077416','test'),('2019-07-14 19:59:59','2019-07-18 15:59:59','KMDETH','4h','0.005926000000000','0.005684000000000','0.072144500000000','0.069198335808302','12.174232197097536','12.174232197097536','test'),('2019-07-24 07:59:59','2019-07-24 11:59:59','KMDETH','4h','0.005605000000000','0.005477000000000','0.072144500000000','0.070496953880464','12.871454058876004','12.871454058876004','test'),('2019-08-16 03:59:59','2019-08-16 19:59:59','KMDETH','4h','0.004369000000000','0.004239000000000','0.072144500000000','0.069997833714809','16.512817578393225','16.512817578393225','test'),('2019-08-23 23:59:59','2019-08-27 11:59:59','KMDETH','4h','0.004500000000000','0.004290000000000','0.072144500000000','0.068777756666667','16.032111111111114','16.032111111111114','test'),('2019-09-06 19:59:59','2019-09-08 15:59:59','KMDETH','4h','0.004254000000000','0.004064000000000','0.072144500000000','0.068922249177245','16.95921485660555','16.959214856605549','test'),('2019-09-29 03:59:59','2019-09-29 07:59:59','KMDETH','4h','0.003403000000000','0.003389000000000','0.072144500000000','0.071847696297385','21.200264472524243','21.200264472524243','test'),('2019-09-29 11:59:59','2019-09-29 15:59:59','KMDETH','4h','0.003417000000000','0.003339000000000','0.072144500000000','0.070497654521510','21.11340357038338','21.113403570383380','test'),('2019-10-04 07:59:59','2019-10-06 11:59:59','KMDETH','4h','0.003399000000000','0.003390000000000','0.072144500000000','0.071953473080318','21.22521329802883','21.225213298028830','test'),('2019-10-06 15:59:59','2019-10-08 03:59:59','KMDETH','4h','0.003446000000000','0.003439000000000','0.072144500000000','0.071997949941962','20.935722576900755','20.935722576900755','test'),('2019-10-08 19:59:59','2019-10-09 07:59:59','KMDETH','4h','0.003536000000000','0.003472000000000','0.072144500000000','0.070838717194570','20.40285633484163','20.402856334841630','test'),('2019-11-03 07:59:59','2019-11-12 07:59:59','KMDETH','4h','0.003165000000000','0.004216000000000','0.072144500000000','0.096101488783570','22.79447077409163','22.794470774091629','test'),('2019-11-12 15:59:59','2019-11-19 15:59:59','KMDETH','4h','0.004584000000000','0.005097000000000','0.072144500000000','0.080218262761780','15.738328970331587','15.738328970331587','test'),('2019-11-29 03:59:59','2019-12-01 11:59:59','KMDETH','4h','0.004865000000000','0.004666000000000','0.072144500000000','0.069193471120247','14.829290853031859','14.829290853031859','test'),('2019-12-20 11:59:59','2019-12-22 03:59:59','KMDETH','4h','0.004353000000000','0.004200000000000','0.072144500000000','0.069608752584425','16.57351252010108','16.573512520101080','test'),('2019-12-23 11:59:59','2019-12-23 19:59:59','KMDETH','4h','0.004484000000000','0.004311000000000','0.072144500000000','0.069361048059768','16.089317573595004','16.089317573595004','test'),('2019-12-24 03:59:59','2019-12-25 19:59:59','KMDETH','4h','0.004310000000000','0.004301000000000','0.072144500000000','0.071993850232019','16.738863109048726','16.738863109048726','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 22:17:50
