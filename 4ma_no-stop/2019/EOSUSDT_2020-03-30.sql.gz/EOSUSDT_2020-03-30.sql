-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-03 19:59:59','EOSUSDT','4h','2.568600000000000','2.595500000000000','15.000000000000000','15.157089465078252','5.83975706610605','5.839757066106050','test'),('2019-01-03 23:59:59','2019-01-04 03:59:59','EOSUSDT','4h','2.637900000000000','2.674600000000000','15.039272366269563','15.248507475956089','5.701229146771888','5.701229146771888','test'),('2019-01-04 07:59:59','2019-01-04 15:59:59','EOSUSDT','4h','2.702300000000000','2.616900000000000','15.091581143691194','14.614646299421041','5.584717146020498','5.584717146020498','test'),('2019-01-05 03:59:59','2019-01-06 03:59:59','EOSUSDT','4h','2.713900000000000','2.635700000000000','15.091581143691194','14.656722952366291','5.56084643637982','5.560846436379820','test'),('2019-01-06 11:59:59','2019-01-10 07:59:59','EOSUSDT','4h','2.692300000000000','2.659100000000000','15.091581143691194','14.905479857069887','5.605460440400845','5.605460440400845','test'),('2019-01-25 07:59:59','2019-01-25 11:59:59','EOSUSDT','4h','2.439000000000000','2.423800000000000','15.091581143691194','14.997529469486969','6.1876101450148395','6.187610145014840','test'),('2019-01-25 15:59:59','2019-01-25 19:59:59','EOSUSDT','4h','2.432600000000000','2.419200000000000','15.091581143691194','15.008449026892107','6.203889313364793','6.203889313364793','test'),('2019-01-25 23:59:59','2019-01-26 15:59:59','EOSUSDT','4h','2.428500000000000','2.420200000000000','15.091581143691194','15.040001928746726','6.214363246321265','6.214363246321265','test'),('2019-02-03 23:59:59','2019-02-05 15:59:59','EOSUSDT','4h','2.370700000000000','2.377700000000000','15.091581143691194','15.136142272474185','6.365875540427382','6.365875540427382','test'),('2019-02-05 19:59:59','2019-02-06 03:59:59','EOSUSDT','4h','2.382200000000000','2.325700000000000','15.091581143691194','14.733645481438421','6.335144464650824','6.335144464650824','test'),('2019-02-08 11:59:59','2019-02-14 11:59:59','EOSUSDT','4h','2.428500000000000','2.730200000000000','15.091581143691194','16.966454535106319','6.214363246321265','6.214363246321265','test'),('2019-02-16 11:59:59','2019-02-24 15:59:59','EOSUSDT','4h','2.812500000000000','3.570400000000000','15.150291526136495','19.232924751970753','5.3867703204040875','5.386770320404088','test'),('2019-03-06 07:59:59','2019-03-08 23:59:59','EOSUSDT','4h','3.739300000000000','3.589700000000000','16.170949832595060','15.523990750693041','4.324592793462696','4.324592793462696','test'),('2019-03-09 07:59:59','2019-03-10 15:59:59','EOSUSDT','4h','3.753600000000000','3.685900000000000','16.170949832595060','15.879290278122904','4.308117495895956','4.308117495895956','test'),('2019-03-15 19:59:59','2019-03-18 15:59:59','EOSUSDT','4h','3.699100000000000','3.705600000000000','16.170949832595060','16.199365169815430','4.371590341595269','4.371590341595269','test'),('2019-03-27 03:59:59','2019-03-30 23:59:59','EOSUSDT','4h','4.036000000000000','4.150200000000000','16.170949832595060','16.628512387323099','4.0066773618917395','4.006677361891740','test'),('2019-04-01 23:59:59','2019-04-02 03:59:59','EOSUSDT','4h','4.204300000000000','4.182900000000000','16.170949832595060','16.088639263316576','3.846288284041353','3.846288284041353','test'),('2019-04-02 07:59:59','2019-04-11 11:59:59','EOSUSDT','4h','4.533900000000000','5.246600000000000','16.170949832595060','18.712919427356855','3.56667545217033','3.566675452170330','test'),('2019-04-15 15:59:59','2019-04-15 19:59:59','EOSUSDT','4h','5.484400000000000','5.269100000000000','16.672704402859445','16.018187362173929','3.040023412380469','3.040023412380469','test'),('2019-04-15 23:59:59','2019-04-16 03:59:59','EOSUSDT','4h','5.323400000000000','5.341200000000000','16.672704402859445','16.728453386285619','3.1319653610210474','3.131965361021047','test'),('2019-04-16 11:59:59','2019-04-16 15:59:59','EOSUSDT','4h','5.383300000000000','5.366300000000000','16.672704402859445','16.620053431364521','3.097115970289496','3.097115970289496','test'),('2019-04-16 19:59:59','2019-04-19 03:59:59','EOSUSDT','4h','5.452900000000000','5.401800000000000','16.672704402859445','16.516461817265338','3.057584845285893','3.057584845285893','test'),('2019-04-19 07:59:59','2019-04-20 15:59:59','EOSUSDT','4h','5.441400000000000','5.422400000000000','16.672704402859445','16.614487513151953','3.064046826709936','3.064046826709936','test'),('2019-05-03 23:59:59','2019-05-04 15:59:59','EOSUSDT','4h','5.084100000000000','4.847800000000000','16.672704402859445','15.897786511709450','3.2793816807024734','3.279381680702473','test'),('2019-05-04 19:59:59','2019-05-04 23:59:59','EOSUSDT','4h','4.859800000000000','4.947200000000000','16.672704402859445','16.972550973666866','3.430738796423607','3.430738796423607','test'),('2019-05-05 15:59:59','2019-05-05 19:59:59','EOSUSDT','4h','4.888500000000000','4.909200000000000','16.672704402859445','16.743303764859895','3.41059719808928','3.410597198089280','test'),('2019-05-07 03:59:59','2019-05-07 15:59:59','EOSUSDT','4h','4.999100000000000','4.852100000000000','16.672704402859445','16.182438645579065','3.335141205988967','3.335141205988967','test'),('2019-05-07 19:59:59','2019-05-07 23:59:59','EOSUSDT','4h','4.885000000000000','4.849200000000000','16.672704402859445','16.550517541524261','3.413040819418515','3.413040819418515','test'),('2019-05-08 11:59:59','2019-05-08 15:59:59','EOSUSDT','4h','4.908600000000000','4.910000000000000','16.672704402859445','16.677459686680496','3.3966313007495916','3.396631300749592','test'),('2019-05-08 23:59:59','2019-05-09 07:59:59','EOSUSDT','4h','4.900000000000000','4.888100000000000','16.672704402859445','16.632213549309640','3.4025927352774374','3.402592735277437','test'),('2019-05-11 11:59:59','2019-05-17 11:59:59','EOSUSDT','4h','5.276000000000000','5.801400000000000','16.672704402859445','18.333022616138894','3.1601031847724497','3.160103184772450','test'),('2019-05-19 07:59:59','2019-05-22 23:59:59','EOSUSDT','4h','6.312500000000000','5.928500000000000','16.672704402859445','15.658475731065698','2.6412204994628823','2.641220499462882','test'),('2019-05-24 15:59:59','2019-05-30 23:59:59','EOSUSDT','4h','6.392300000000000','7.300000000000000','16.672704402859445','19.040211213627952','2.6082481114558838','2.608248111455884','test'),('2019-05-31 23:59:59','2019-06-01 23:59:59','EOSUSDT','4h','8.564500000000001','7.702700000000000','16.946468828237421','15.241235967454536','1.9786874689984728','1.978687468998473','test'),('2019-06-15 19:59:59','2019-06-18 15:59:59','EOSUSDT','4h','6.884700000000000','6.857200000000000','16.946468828237421','16.878778457883371','2.461468012874551','2.461468012874551','test'),('2019-06-21 07:59:59','2019-06-21 15:59:59','EOSUSDT','4h','6.997600000000000','6.909200000000000','16.946468828237421','16.732385736260717','2.4217544341256176','2.421754434125618','test'),('2019-06-21 19:59:59','2019-06-24 15:59:59','EOSUSDT','4h','6.974600000000000','7.161200000000000','16.946468828237421','17.399858425253612','2.4297406056601702','2.429740605660170','test'),('2019-06-26 11:59:59','2019-06-26 23:59:59','EOSUSDT','4h','7.380200000000000','6.809600000000000','16.946468828237421','15.636252965064028','2.296207261082006','2.296207261082006','test'),('2019-07-25 11:59:59','2019-07-27 11:59:59','EOSUSDT','4h','4.590400000000000','4.358800000000000','16.946468828237421','16.091466610430739','3.691719420581523','3.691719420581523','test'),('2019-08-05 19:59:59','2019-08-06 11:59:59','EOSUSDT','4h','4.505900000000000','4.335800000000000','16.946468828237421','16.306731073808077','3.7609509372683423','3.760950937268342','test'),('2019-09-08 03:59:59','2019-09-11 15:59:59','EOSUSDT','4h','3.644500000000000','3.672200000000000','16.946468828237421','17.075270361106725','4.649874832826841','4.649874832826841','test'),('2019-09-14 15:59:59','2019-09-19 03:59:59','EOSUSDT','4h','3.936100000000000','3.887800000000000','16.946468828237421','16.738518205945336','4.305395906668383','4.305395906668383','test'),('2019-10-07 23:59:59','2019-10-10 11:59:59','EOSUSDT','4h','3.175900000000000','3.110000000000000','16.946468828237421','16.594829199854647','5.33595794207545','5.335957942075450','test'),('2019-10-10 15:59:59','2019-10-10 23:59:59','EOSUSDT','4h','3.113800000000000','3.105300000000000','16.946468828237421','16.900208636497421','5.442375498823759','5.442375498823759','test'),('2019-10-14 03:59:59','2019-10-14 19:59:59','EOSUSDT','4h','3.123800000000000','3.158800000000000','16.946468828237421','17.136342190484783','5.424953207067489','5.424953207067489','test'),('2019-10-14 23:59:59','2019-10-15 07:59:59','EOSUSDT','4h','3.163400000000000','3.113000000000000','16.946468828237421','16.676473876937184','5.357042684528488','5.357042684528488','test'),('2019-10-26 03:59:59','2019-10-30 15:59:59','EOSUSDT','4h','3.291700000000000','3.246300000000000','16.946468828237421','16.712738632653991','5.148242193467637','5.148242193467637','test'),('2019-11-01 23:59:59','2019-11-03 15:59:59','EOSUSDT','4h','3.341900000000000','3.273900000000000','16.946468828237421','16.601647056095782','5.070908413847638','5.070908413847638','test'),('2019-11-04 11:59:59','2019-11-07 15:59:59','EOSUSDT','4h','3.369100000000000','3.447100000000000','16.946468828237421','17.338806416496158','5.029969080240249','5.029969080240249','test'),('2019-11-10 07:59:59','2019-11-11 11:59:59','EOSUSDT','4h','3.544500000000000','3.460800000000000','16.946468828237421','16.546294067079717','4.781060467833946','4.781060467833946','test'),('2019-11-11 15:59:59','2019-11-11 19:59:59','EOSUSDT','4h','3.462600000000000','3.474200000000000','16.946468828237421','17.003240918114265','4.894145679038128','4.894145679038128','test'),('2019-12-08 11:59:59','2019-12-09 15:59:59','EOSUSDT','4h','2.736900000000000','2.679000000000000','16.946468828237421','16.587960828253880','6.191848013532618','6.191848013532618','test'),('2019-12-23 11:59:59','2019-12-24 07:59:59','EOSUSDT','4h','2.547200000000000','2.487200000000000','16.946468828237421','16.547290071290874','6.6529792824424545','6.652979282442455','test'),('2019-12-24 11:59:59','2019-12-25 15:59:59','EOSUSDT','4h','2.515000000000000','2.474800000000000','16.946468828237421','16.675594853328814','6.738158579816072','6.738158579816072','test'),('2019-12-26 19:59:59','2019-12-26 23:59:59','EOSUSDT','4h','2.574200000000000','2.516900000000000','16.946468828237421','16.569251570892227','6.583198208467649','6.583198208467649','test'),('2019-12-27 03:59:59','2019-12-31 03:59:59','EOSUSDT','4h','2.553100000000000','2.622300000000000','16.946468828237421','17.405791080759467','6.6376048052318435','6.637604805231843','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  4:26:27
