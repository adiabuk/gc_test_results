-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 15:59:59','2019-01-13 23:59:59','REPETH','4h','0.061860000000000','0.070200000000000','0.072144500000000','0.081871062075655','1.1662544455221469','1.166254445522147','test'),('2019-01-14 19:59:59','2019-01-22 07:59:59','REPETH','4h','0.080320000000000','0.130700000000000','0.074576140518914','0.121353356148183','0.9284878052653605','0.928487805265360','test'),('2019-02-02 03:59:59','2019-02-04 19:59:59','REPETH','4h','0.123550000000000','0.126370000000000','0.086270444426231','0.088239547245187','0.6982634109771834','0.698263410977183','test'),('2019-03-04 03:59:59','2019-03-04 07:59:59','REPETH','4h','0.097790000000000','0.094510000000000','0.086762720130970','0.083852589012966','0.8872350969523468','0.887235096952347','test'),('2019-03-04 11:59:59','2019-03-05 15:59:59','REPETH','4h','0.096910000000000','0.093140000000000','0.086762720130970','0.083387470364240','0.8952917153128677','0.895291715312868','test'),('2019-03-09 23:59:59','2019-03-16 11:59:59','REPETH','4h','0.095590000000000','0.102410000000000','0.086762720130970','0.092952925709935','0.9076547769742651','0.907654776974265','test'),('2019-03-18 03:59:59','2019-03-21 15:59:59','REPETH','4h','0.106830000000000','0.106020000000000','0.086762720130970','0.086104873053313','0.8121568859961622','0.812156885996162','test'),('2019-03-26 19:59:59','2019-03-26 23:59:59','REPETH','4h','0.105960000000000','0.105140000000000','0.086762720130970','0.086091283451965','0.8188252182990752','0.818825218299075','test'),('2019-03-30 03:59:59','2019-03-31 07:59:59','REPETH','4h','0.114280000000000','0.109230000000000','0.086762720130970','0.082928700734213','0.7592117617340741','0.759211761734074','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','REPETH','4h','0.108720000000000','0.111730000000000','0.086762720130970','0.089164815307517','0.7980382646336461','0.798038264633646','test'),('2019-04-02 15:59:59','2019-04-02 23:59:59','REPETH','4h','0.109830000000000','0.107410000000000','0.086762720130970','0.084850985789561','0.7899728683508149','0.789972868350815','test'),('2019-04-03 03:59:59','2019-04-05 11:59:59','REPETH','4h','0.131220000000000','0.117620000000000','0.086762720130970','0.077770394313403','0.6612004277623076','0.661200427762308','test'),('2019-04-06 11:59:59','2019-04-08 03:59:59','REPETH','4h','0.121560000000000','0.118990000000000','0.086762720130970','0.084928398061732','0.7137439958125206','0.713743995812521','test'),('2019-04-15 03:59:59','2019-04-15 23:59:59','REPETH','4h','0.120380000000000','0.116470000000000','0.086762720130970','0.083944625466473','0.720740323400648','0.720740323400648','test'),('2019-04-16 03:59:59','2019-04-16 07:59:59','REPETH','4h','0.116570000000000','0.116500000000000','0.086762720130970','0.086710619329656','0.7442971616279489','0.744297161627949','test'),('2019-04-17 23:59:59','2019-04-21 11:59:59','REPETH','4h','0.121260000000000','0.121770000000000','0.086762720130970','0.087127630136469','0.7155098147036945','0.715509814703694','test'),('2019-04-22 03:59:59','2019-04-24 03:59:59','REPETH','4h','0.129980000000000','0.126010000000000','0.086762720130970','0.084112712445788','0.6675082330433143','0.667508233043314','test'),('2019-04-24 23:59:59','2019-04-29 03:59:59','REPETH','4h','0.130910000000000','0.136730000000000','0.086762720130970','0.090620019276660','0.6627661762353525','0.662766176235352','test'),('2019-06-08 23:59:59','2019-06-11 07:59:59','REPETH','4h','0.078770000000000','0.076340000000000','0.086762720130970','0.084086150244995','1.1014690888786338','1.101469088878634','test'),('2019-07-11 07:59:59','2019-07-12 07:59:59','REPETH','4h','0.053360000000000','0.052290000000000','0.086762720130970','0.085022912961927','1.6259880084514617','1.625988008451462','test'),('2019-07-12 11:59:59','2019-07-15 19:59:59','REPETH','4h','0.052690000000000','0.056130000000000','0.086762720130970','0.092427243897350','1.6466638855754412','1.646663885575441','test'),('2019-07-15 23:59:59','2019-07-16 07:59:59','REPETH','4h','0.056270000000000','0.056120000000000','0.086762720130970','0.086531435111961','1.5419001267277412','1.541900126727741','test'),('2019-07-16 11:59:59','2019-07-16 15:59:59','REPETH','4h','0.056380000000000','0.056030000000000','0.086762720130970','0.086224107998195','1.5388918079278113','1.538891807927811','test'),('2019-07-19 19:59:59','2019-07-23 19:59:59','REPETH','4h','0.056440000000000','0.055210000000000','0.086762720130970','0.084871895436408','1.5372558492375976','1.537255849237598','test'),('2019-07-31 03:59:59','2019-07-31 11:59:59','REPETH','4h','0.056000000000000','0.053860000000000','0.086762720130970','0.083447144754537','1.5493342880530356','1.549334288053036','test'),('2019-08-10 19:59:59','2019-08-11 19:59:59','REPETH','4h','0.052570000000000','0.051110000000000','0.086762720130970','0.084353103022520','1.6504226770205441','1.650422677020544','test'),('2019-08-11 23:59:59','2019-08-13 07:59:59','REPETH','4h','0.051210000000000','0.051910000000000','0.086762720130970','0.087948697559044','1.694253468677407','1.694253468677407','test'),('2019-08-14 19:59:59','2019-08-14 23:59:59','REPETH','4h','0.054140000000000','0.052320000000000','0.086762720130970','0.083846056838795','1.6025622484479127','1.602562248447913','test'),('2019-08-15 11:59:59','2019-08-15 19:59:59','REPETH','4h','0.052000000000000','0.052600000000000','0.086762720130970','0.087763828440173','1.6685138486725002','1.668513848672500','test'),('2019-08-15 23:59:59','2019-08-17 03:59:59','REPETH','4h','0.053050000000000','0.051640000000000','0.086762720130970','0.084456679878667','1.6354895406403394','1.635489540640339','test'),('2019-08-21 19:59:59','2019-08-22 07:59:59','REPETH','4h','0.052990000000000','0.052280000000000','0.086762720130970','0.085600207745747','1.637341387638611','1.637341387638611','test'),('2019-08-22 23:59:59','2019-08-23 03:59:59','REPETH','4h','0.051990000000000','0.051770000000000','0.086762720130970','0.086395576479714','1.668834778437584','1.668834778437584','test'),('2019-08-23 11:59:59','2019-08-23 15:59:59','REPETH','4h','0.052030000000000','0.050680000000000','0.086762720130970','0.084511525201568','1.6675517995573708','1.667551799557371','test'),('2019-08-25 19:59:59','2019-08-25 23:59:59','REPETH','4h','0.051870000000000','0.051490000000000','0.086762720130970','0.086127095807666','1.672695587641604','1.672695587641604','test'),('2019-09-05 15:59:59','2019-09-09 11:59:59','REPETH','4h','0.051460000000000','0.058750000000000','0.086762720130970','0.099053824479100','1.686022544325107','1.686022544325107','test'),('2019-09-12 15:59:59','2019-09-13 23:59:59','REPETH','4h','0.059440000000000','0.057750000000000','0.086762720130970','0.084295879669642','1.459668912028432','1.459668912028432','test'),('2019-10-17 03:59:59','2019-10-20 19:59:59','REPETH','4h','0.046520000000000','0.046280000000000','0.086762720130970','0.086315105065806','1.865062771516982','1.865062771516982','test'),('2019-10-21 15:59:59','2019-10-22 03:59:59','REPETH','4h','0.047650000000000','0.046520000000000','0.086762720130970','0.084705178184527','1.8208335809227703','1.820833580922770','test'),('2019-10-28 19:59:59','2019-10-29 23:59:59','REPETH','4h','0.049690000000000','0.048600000000000','0.086762720130970','0.084859492822804','1.746080099234655','1.746080099234655','test'),('2019-10-30 11:59:59','2019-11-07 03:59:59','REPETH','4h','0.048790000000000','0.059850000000000','0.086762720130970','0.106430596430386','1.7782889963306006','1.778288996330601','test'),('2019-11-08 19:59:59','2019-11-11 15:59:59','REPETH','4h','0.064890000000000','0.063590000000000','0.086762720130970','0.085024524165948','1.3370738192474958','1.337073819247496','test'),('2019-11-18 03:59:59','2019-11-18 11:59:59','REPETH','4h','0.064030000000000','0.061160000000000','0.086762720130970','0.082873777342029','1.355032330641418','1.355032330641418','test'),('2019-11-18 23:59:59','2019-11-19 03:59:59','REPETH','4h','0.061710000000000','0.060530000000000','0.086762720130970','0.085103669575881','1.4059750466856262','1.405975046685626','test'),('2019-11-20 03:59:59','2019-11-25 23:59:59','REPETH','4h','0.069780000000000','0.071320000000000','0.086762720130970','0.088677517909727','1.2433751810113214','1.243375181011321','test'),('2019-11-26 23:59:59','2019-11-27 03:59:59','REPETH','4h','0.073300000000000','0.072170000000000','0.086762720130970','0.085425177515036','1.1836660318004093','1.183666031800409','test'),('2019-12-01 11:59:59','2019-12-01 15:59:59','REPETH','4h','0.072280000000000','0.070660000000000','0.086762720130970','0.084818121256978','1.200369675303957','1.200369675303957','test'),('2019-12-06 11:59:59','2019-12-06 15:59:59','REPETH','4h','0.070420000000000','0.070030000000000','0.086762720130970','0.086282210888552','1.2320749805590743','1.232074980559074','test'),('2019-12-06 19:59:59','2019-12-06 23:59:59','REPETH','4h','0.070120000000000','0.070500000000000','0.086762720130970','0.087232911711828','1.237346265416001','1.237346265416001','test'),('2019-12-07 07:59:59','2019-12-07 23:59:59','REPETH','4h','0.070440000000000','0.070210000000000','0.086762720130970','0.086479423344625','1.2317251580205848','1.231725158020585','test'),('2019-12-08 03:59:59','2019-12-08 07:59:59','REPETH','4h','0.070440000000000','0.070380000000000','0.086762720130970','0.086688816621489','1.2317251580205848','1.231725158020585','test'),('2019-12-08 11:59:59','2019-12-08 15:59:59','REPETH','4h','0.070800000000000','0.069680000000000','0.086762720130970','0.085390202524378','1.2254621487425141','1.225462148742514','test'),('2019-12-11 19:59:59','2019-12-12 03:59:59','REPETH','4h','0.071600000000000','0.070200000000000','0.086762720130970','0.085066242363046','1.2117698342314247','1.211769834231425','test'),('2019-12-12 07:59:59','2019-12-12 11:59:59','REPETH','4h','0.070420000000000','0.069440000000000','0.086762720130970','0.085555286650022','1.2320749805590743','1.232074980559074','test'),('2019-12-12 15:59:59','2019-12-12 19:59:59','REPETH','4h','0.069870000000000','0.069770000000000','0.086762720130970','0.086638542772832','1.2417735813792758','1.241773581379276','test'),('2019-12-12 23:59:59','2019-12-13 03:59:59','REPETH','4h','0.069900000000000','0.070400000000000','0.086762720130970','0.087383340446642','1.241240631344349','1.241240631344349','test'),('2019-12-13 07:59:59','2019-12-13 11:59:59','REPETH','4h','0.070450000000000','0.070270000000000','0.086762720130970','0.086541041073148','1.2315503212344925','1.231550321234492','test'),('2019-12-13 15:59:59','2019-12-13 19:59:59','REPETH','4h','0.070580000000000','0.071080000000000','0.086762720130970','0.087377361106678','1.2292819514164068','1.229281951416407','test'),('2019-12-16 03:59:59','2019-12-17 03:59:59','REPETH','4h','0.071200000000000','0.070440000000000','0.086762720130970','0.085836601208224','1.218577529929354','1.218577529929354','test'),('2019-12-17 07:59:59','2019-12-17 11:59:59','REPETH','4h','0.071670000000000','0.070170000000000','0.086762720130970','0.084946840680761','1.21058630013911','1.210586300139110','test'),('2019-12-18 03:59:59','2019-12-22 19:59:59','REPETH','4h','0.071330000000000','0.073670000000000','0.086762720130970','0.089608994701368','1.2163566540161221','1.216356654016122','test'),('2019-12-23 23:59:59','2019-12-25 15:59:59','REPETH','4h','0.076870000000000','0.075310000000000','0.086762720130970','0.085001957240319','1.1286941606734748','1.128694160673475','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:52:31
