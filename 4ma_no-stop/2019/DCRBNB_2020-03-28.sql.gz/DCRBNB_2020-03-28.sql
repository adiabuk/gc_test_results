-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-04-10 03:59:59','2019-04-10 11:59:59','DCRBNB','4h','1.384000000000000','1.352000000000000','0.711908500000000','0.695448187861272','0.5143847543352602','0.514384754335260','test'),('2019-05-02 03:59:59','2019-05-02 11:59:59','DCRBNB','4h','1.137000000000000','1.083000000000000','0.711908500000000','0.678097542216359','0.6261288478452067','0.626128847845207','test'),('2019-05-03 11:59:59','2019-05-13 03:59:59','DCRBNB','4h','1.114000000000000','1.284000000000000','0.711908500000000','0.820548037701975','0.639056104129264','0.639056104129264','test'),('2019-06-11 15:59:59','2019-06-12 03:59:59','DCRBNB','4h','0.877000000000000','0.847000000000000','0.726500566944902','0.701648780162294','0.8283928927535935','0.828392892753594','test'),('2019-06-17 03:59:59','2019-06-17 07:59:59','DCRBNB','4h','0.867000000000000','0.820000000000000','0.726500566944902','0.687117029867151','0.8379475973989642','0.837947597398964','test'),('2019-06-17 11:59:59','2019-06-17 15:59:59','DCRBNB','4h','0.851000000000000','0.828000000000000','0.726500566944902','0.706865416486932','0.8537021938247966','0.853702193824797','test'),('2019-06-17 23:59:59','2019-06-18 03:59:59','DCRBNB','4h','0.855000000000000','0.841000000000000','0.726500566944902','0.714604651228845','0.8497082654326339','0.849708265432634','test'),('2019-06-24 03:59:59','2019-06-30 19:59:59','DCRBNB','4h','0.910000000000000','0.940000000000000','0.726500566944902','0.750451135085943','0.7983522713680241','0.798352271368024','test'),('2019-07-03 23:59:59','2019-07-04 11:59:59','DCRBNB','4h','0.987000000000000','0.913000000000000','0.726500566944902','0.672031426160786','0.7360694700556251','0.736069470055625','test'),('2019-07-04 15:59:59','2019-07-04 23:59:59','DCRBNB','4h','0.946000000000000','0.921000000000000','0.726500566944902','0.707301291919931','0.7679710009988393','0.767971000998839','test'),('2019-07-06 15:59:59','2019-07-06 23:59:59','DCRBNB','4h','0.945000000000000','0.928000000000000','0.726500566944902','0.713431244576581','0.768783668724764','0.768783668724764','test'),('2019-07-07 03:59:59','2019-07-07 11:59:59','DCRBNB','4h','0.932000000000000','0.921000000000000','0.726500566944902','0.717925989438042','0.779507046078221','0.779507046078221','test'),('2019-07-07 15:59:59','2019-07-07 19:59:59','DCRBNB','4h','0.943000000000000','0.962000000000000','0.726500566944902','0.741138436268288','0.7704141749150605','0.770414174915060','test'),('2019-07-08 19:59:59','2019-07-12 03:59:59','DCRBNB','4h','0.960000000000000','0.979000000000000','0.726500566944902','0.740879223999020','0.7567714239009395','0.756771423900940','test'),('2019-07-15 11:59:59','2019-07-17 15:59:59','DCRBNB','4h','1.027000000000000','1.057000000000000','0.726500566944902','0.747722589348356','0.7074007467817935','0.707400746781794','test'),('2019-08-01 19:59:59','2019-08-07 19:59:59','DCRBNB','4h','0.970000000000000','1.036000000000000','0.726500566944902','0.775932564283421','0.7489696566442289','0.748969656644229','test'),('2019-08-20 23:59:59','2019-08-21 07:59:59','DCRBNB','4h','0.946000000000000','0.928000000000000','0.726500566944902','0.712677088926923','0.7679710009988393','0.767971000998839','test'),('2019-08-21 11:59:59','2019-08-21 15:59:59','DCRBNB','4h','0.931000000000000','0.914000000000000','0.726500566944902','0.713234713413148','0.7803443253973168','0.780344325397317','test'),('2019-08-23 07:59:59','2019-08-23 19:59:59','DCRBNB','4h','0.942000000000000','0.923000000000000','0.726500566944902','0.711847158482107','0.7712320243576454','0.771232024357645','test'),('2019-08-23 23:59:59','2019-08-24 07:59:59','DCRBNB','4h','0.938000000000000','0.938000000000000','0.726500566944902','0.726500566944902','0.7745208602824115','0.774520860282412','test'),('2019-08-24 11:59:59','2019-08-24 19:59:59','DCRBNB','4h','0.944000000000000','0.935000000000000','0.726500566944902','0.719574184421063','0.7695980582043453','0.769598058204345','test'),('2019-08-24 23:59:59','2019-08-26 03:59:59','DCRBNB','4h','0.938000000000000','0.940000000000000','0.726500566944902','0.728049608665467','0.7745208602824115','0.774520860282412','test'),('2019-08-26 19:59:59','2019-08-27 19:59:59','DCRBNB','4h','0.966000000000000','0.950000000000000','0.726500566944902','0.714467431260514','0.7520709802742257','0.752070980274226','test'),('2019-08-28 03:59:59','2019-09-05 19:59:59','DCRBNB','4h','0.955000000000000','1.092000000000000','0.726500566944902','0.830721067124432','0.760733577952777','0.760733577952777','test'),('2019-09-09 11:59:59','2019-09-09 23:59:59','DCRBNB','4h','1.116000000000000','1.086000000000000','0.726500566944902','0.706970981811974','0.6509861710975823','0.650986171097582','test'),('2019-09-12 15:59:59','2019-09-14 23:59:59','DCRBNB','4h','1.112000000000000','1.089000000000000','0.726500566944902','0.711474026441545','0.653327847972034','0.653327847972034','test'),('2019-09-15 03:59:59','2019-09-15 07:59:59','DCRBNB','4h','1.111000000000000','1.120000000000000','0.726500566944902','0.732385810061467','0.6539159018405958','0.653915901840596','test'),('2019-09-15 19:59:59','2019-09-15 23:59:59','DCRBNB','4h','1.118000000000000','1.107000000000000','0.726500566944902','0.719352529166374','0.649821616229787','0.649821616229787','test'),('2019-09-22 19:59:59','2019-09-23 03:59:59','DCRBNB','4h','1.099000000000000','1.093000000000000','0.726500566944902','0.722534230819634','0.6610560208779818','0.661056020877982','test'),('2019-09-23 15:59:59','2019-09-23 19:59:59','DCRBNB','4h','1.087000000000000','1.064000000000000','0.726500566944902','0.711128429833832','0.6683537874378123','0.668353787437812','test'),('2019-09-24 19:59:59','2019-09-24 23:59:59','DCRBNB','4h','1.099000000000000','1.111000000000000','0.726500566944902','0.734433239195438','0.6610560208779818','0.661056020877982','test'),('2019-09-25 11:59:59','2019-09-25 19:59:59','DCRBNB','4h','1.111000000000000','1.065000000000000','0.726500566944902','0.696420435460235','0.6539159018405958','0.653915901840596','test'),('2019-09-26 07:59:59','2019-09-26 11:59:59','DCRBNB','4h','1.093000000000000','1.080000000000000','0.726500566944902','0.717859663586911','0.6646848736915846','0.664684873691585','test'),('2019-09-26 15:59:59','2019-09-30 07:59:59','DCRBNB','4h','1.087000000000000','1.102000000000000','0.726500566944902','0.736525873756469','0.6683537874378123','0.668353787437812','test'),('2019-10-06 23:59:59','2019-10-07 11:59:59','DCRBNB','4h','1.117000000000000','1.087000000000000','0.726500566944902','0.706988465773598','0.6504033723768147','0.650403372376815','test'),('2019-10-07 15:59:59','2019-10-07 19:59:59','DCRBNB','4h','1.111000000000000','1.087000000000000','0.726500566944902','0.710806585300728','0.6539159018405958','0.653915901840596','test'),('2019-11-01 03:59:59','2019-11-05 11:59:59','DCRBNB','4h','0.852000000000000','0.939000000000000','0.726500566944902','0.800685483992093','0.8527001959447206','0.852700195944721','test'),('2019-11-07 03:59:59','2019-11-10 19:59:59','DCRBNB','4h','1.100000000000000','1.001000000000000','0.726500566944902','0.661115515919861','0.6604550608590017','0.660455060859002','test'),('2019-11-10 23:59:59','2019-11-13 11:59:59','DCRBNB','4h','1.014000000000000','1.025000000000000','0.726500566944902','0.734381736803279','0.7164699871251499','0.716469987125150','test'),('2019-11-15 03:59:59','2019-11-17 15:59:59','DCRBNB','4h','1.177000000000000','1.117000000000000','0.726500566944902','0.689465703719163','0.6172477204289736','0.617247720428974','test'),('2019-11-17 19:59:59','2019-11-19 07:59:59','DCRBNB','4h','1.151000000000000','1.099000000000000','0.726500566944902','0.693678647326192','0.6311907618982641','0.631190761898264','test'),('2019-11-23 15:59:59','2019-11-24 07:59:59','DCRBNB','4h','1.157000000000000','1.124000000000000','0.726500566944902','0.705779288890294','0.6279175168063111','0.627917516806311','test'),('2019-11-24 11:59:59','2019-11-24 15:59:59','DCRBNB','4h','1.148000000000000','1.109000000000000','0.726500566944902','0.701819798555659','0.6328402151087996','0.632840215108800','test'),('2019-11-24 19:59:59','2019-11-25 07:59:59','DCRBNB','4h','1.124000000000000','1.099000000000000','0.726500566944902','0.710341746505736','0.6463528175666386','0.646352817566639','test'),('2019-11-25 19:59:59','2019-11-26 03:59:59','DCRBNB','4h','1.150000000000000','1.062000000000000','0.726500566944902','0.670907480083031','0.6317396234303496','0.631739623430350','test'),('2019-11-27 15:59:59','2019-12-03 03:59:59','DCRBNB','4h','1.160000000000000','1.185000000000000','0.726500566944902','0.742157906749749','0.626293592193881','0.626293592193881','test'),('2019-12-04 15:59:59','2019-12-09 15:59:59','DCRBNB','4h','1.251000000000000','1.281000000000000','0.726500566944902','0.743922642890823','0.5807358648640304','0.580735864864030','test'),('2019-12-10 23:59:59','2019-12-13 03:59:59','DCRBNB','4h','1.337000000000000','1.313000000000000','0.726500566944902','0.713459419894283','0.5433811271091263','0.543381127109126','test'),('2019-12-14 11:59:59','2019-12-16 19:59:59','DCRBNB','4h','1.360000000000000','1.378000000000000','0.726500566944902','0.736116015625055','0.5341915933418396','0.534191593341840','test'),('2019-12-17 03:59:59','2019-12-17 07:59:59','DCRBNB','4h','1.370000000000000','1.363000000000000','0.726500566944902','0.722788520252483','0.5302923846313152','0.530292384631315','test'),('2020-01-03 19:59:59','2020-01-05 19:59:59','DCRBNB','4h','1.270000000000000','1.245000000000000','0.726500566944902','0.712199374682207','0.5720476905077968','0.572047690507797','test'),('2020-01-05 23:59:59','2020-01-06 07:59:59','DCRBNB','4h','1.263000000000000','1.249000000000000','0.726500566944902','0.718447512362773','0.5752181844377688','0.575218184437769','test'),('2020-02-04 11:59:59','2020-02-05 03:59:59','DCRBNB','4h','1.082000000000000','1.044000000000000','0.726500566944902','0.700985759603029','0.6714422984703344','0.671442298470334','test'),('2020-02-06 03:59:59','2020-02-06 11:59:59','DCRBNB','4h','1.063000000000000','1.049000000000000','0.726500566944902','0.716932356279588','0.6834436189509896','0.683443618950990','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 13:43:40
