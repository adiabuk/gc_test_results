-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 15:59:59','2019-01-14 15:59:59','VIAETH','4h','0.002361000000000','0.002240000000000','0.072144500000000','0.068447132570945','30.556755612028805','30.556755612028805','test'),('2019-01-15 15:59:59','2019-01-23 23:59:59','VIAETH','4h','0.002346000000000','0.002591000000000','0.072144500000000','0.079678772165388','30.752131287297527','30.752131287297527','test'),('2019-01-25 11:59:59','2019-01-27 11:59:59','VIAETH','4h','0.002659000000000','0.002669000000000','0.073103726184083','0.073378655579285','27.49293952015166','27.492939520151658','test'),('2019-01-30 11:59:59','2019-01-31 11:59:59','VIAETH','4h','0.002741000000000','0.002674000000000','0.073172458532884','0.071383857758822','26.6955339412199','26.695533941219900','test'),('2019-01-31 15:59:59','2019-01-31 19:59:59','VIAETH','4h','0.002676000000000','0.002653000000000','0.073172458532884','0.072543547267467','27.343968061615843','27.343968061615843','test'),('2019-02-04 07:59:59','2019-02-05 07:59:59','VIAETH','4h','0.002803000000000','0.002670000000000','0.073172458532884','0.069700486722369','26.10505120687977','26.105051206879772','test'),('2019-02-05 11:59:59','2019-02-05 19:59:59','VIAETH','4h','0.002747000000000','0.002631000000000','0.073172458532884','0.070082540371321','26.637225530718602','26.637225530718602','test'),('2019-02-06 11:59:59','2019-02-06 19:59:59','VIAETH','4h','0.002741000000000','0.002656000000000','0.073172458532884','0.070903338147880','26.695533941219992','26.695533941219992','test'),('2019-02-26 19:59:59','2019-02-28 07:59:59','VIAETH','4h','0.002524000000000','0.002434000000000','0.073172458532884','0.070563297967131','28.99067295280665','28.990672952806651','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','VIAETH','4h','0.002456000000000','0.002422000000000','0.073172458532884','0.072159484758406','29.793346308177526','29.793346308177526','test'),('2019-02-28 23:59:59','2019-03-05 19:59:59','VIAETH','4h','0.002452000000000','0.002596000000000','0.073172458532884','0.077469699164505','29.841948830703096','29.841948830703096','test'),('2019-03-07 19:59:59','2019-03-14 07:59:59','VIAETH','4h','0.002664000000000','0.003334000000000','0.073172458532884','0.091575441722461','27.46713908892042','27.467139088920419','test'),('2019-03-14 19:59:59','2019-03-16 07:59:59','VIAETH','4h','0.003853000000000','0.003527000000000','0.075129850303985','0.068773159102558','19.49905276511426','19.499052765114261','test'),('2019-03-21 07:59:59','2019-03-26 07:59:59','VIAETH','4h','0.003581000000000','0.003716000000000','0.075129850303985','0.077962168033959','20.980131333142978','20.980131333142978','test'),('2019-03-26 15:59:59','2019-03-26 19:59:59','VIAETH','4h','0.003932000000000','0.003747000000000','0.075129850303985','0.071595002311554','19.107286445570956','19.107286445570956','test'),('2019-03-27 11:59:59','2019-03-28 19:59:59','VIAETH','4h','0.003900000000000','0.003812000000000','0.075129850303985','0.073434612656100','19.264064180508974','19.264064180508974','test'),('2019-03-28 23:59:59','2019-03-29 15:59:59','VIAETH','4h','0.003850000000000','0.003733000000000','0.075129850303985','0.072846683424617','19.514246832203895','19.514246832203895','test'),('2019-03-30 11:59:59','2019-04-02 19:59:59','VIAETH','4h','0.004182000000000','0.003929000000000','0.075129850303985','0.070584691976173','17.965052679097322','17.965052679097322','test'),('2019-05-01 23:59:59','2019-05-06 19:59:59','VIAETH','4h','0.003308000000000','0.003404000000000','0.075129850303985','0.077310160349083','22.71156296976572','22.711562969765719','test'),('2019-05-07 15:59:59','2019-05-08 11:59:59','VIAETH','4h','0.003730000000000','0.003506000000000','0.075129850303985','0.070618030875542','20.142051019835122','20.142051019835122','test'),('2019-05-08 15:59:59','2019-05-10 07:59:59','VIAETH','4h','0.003678000000000','0.003660000000000','0.075129850303985','0.074762167512938','20.426821724846384','20.426821724846384','test'),('2019-05-10 11:59:59','2019-05-11 07:59:59','VIAETH','4h','0.003677000000000','0.003608000000000','0.075129850303985','0.073720016289578','20.432377020392984','20.432377020392984','test'),('2019-06-09 19:59:59','2019-06-11 11:59:59','VIAETH','4h','0.002340000000000','0.002330000000000','0.075129850303985','0.074808782567643','32.10677363418162','32.106773634181621','test'),('2019-06-11 15:59:59','2019-06-12 07:59:59','VIAETH','4h','0.002341000000000','0.002327000000000','0.075129850303985','0.074680547482859','32.09305865185177','32.093058651851770','test'),('2019-07-05 07:59:59','2019-07-05 23:59:59','VIAETH','4h','0.001635000000000','0.001564000000000','0.075129850303985','0.071867330810662','45.95097877919572','45.950978779195722','test'),('2019-07-06 03:59:59','2019-07-06 07:59:59','VIAETH','4h','0.001568000000000','0.001536000000000','0.075129850303985','0.073596588052883','47.91444534692921','47.914445346929213','test'),('2019-07-06 19:59:59','2019-07-07 19:59:59','VIAETH','4h','0.001599000000000','0.001513000000000','0.075129850303985','0.071089095378317','46.985522391485304','46.985522391485304','test'),('2019-07-19 19:59:59','2019-07-20 19:59:59','VIAETH','4h','0.001563000000000','0.001514000000000','0.075129850303985','0.072774531900341','48.06772252334294','48.067722523342937','test'),('2019-07-20 23:59:59','2019-07-24 23:59:59','VIAETH','4h','0.001522000000000','0.001554000000000','0.075129850303985','0.076709452938497','49.36258232850526','49.362582328505262','test'),('2019-07-25 03:59:59','2019-07-25 07:59:59','VIAETH','4h','0.001555000000000','0.001535000000000','0.075129850303985','0.074163549978532','48.315016272659165','48.315016272659165','test'),('2019-07-27 11:59:59','2019-07-27 23:59:59','VIAETH','4h','0.001600000000000','0.001534000000000','0.075129850303985','0.072030743978946','46.95615643999062','46.956156439990622','test'),('2019-07-28 03:59:59','2019-07-28 07:59:59','VIAETH','4h','0.001543000000000','0.001525000000000','0.075129850303985','0.074253416535047','48.69076494101426','48.690764941014258','test'),('2019-07-28 19:59:59','2019-07-28 23:59:59','VIAETH','4h','0.001592000000000','0.001548000000000','0.075129850303985','0.073053397154880','47.192117025116204','47.192117025116204','test'),('2019-07-29 07:59:59','2019-07-29 11:59:59','VIAETH','4h','0.001554000000000','0.001580000000000','0.075129850303985','0.076386849086420','48.34610701672136','48.346107016721362','test'),('2019-07-29 15:59:59','2019-07-30 15:59:59','VIAETH','4h','0.001585000000000','0.001547000000000','0.075129850303985','0.073328629918148','47.40053646939117','47.400536469391170','test'),('2019-07-30 19:59:59','2019-07-31 03:59:59','VIAETH','4h','0.001556000000000','0.001528000000000','0.075129850303985','0.073777899270237','48.28396549099293','48.283965490992927','test'),('2019-08-14 07:59:59','2019-08-14 11:59:59','VIAETH','4h','0.001502000000000','0.001427000000000','0.075129850303985','0.071378359776156','50.01987370438415','50.019873704384153','test'),('2019-08-14 19:59:59','2019-08-14 23:59:59','VIAETH','4h','0.001431000000000','0.001398000000000','0.075129850303985','0.073397296104103','52.50164242067436','52.501642420674358','test'),('2019-08-17 15:59:59','2019-08-17 19:59:59','VIAETH','4h','0.001416000000000','0.001420000000000','0.075129850303985','0.075342081519533','53.05780388699506','53.057803886995060','test'),('2019-08-23 03:59:59','2019-08-23 07:59:59','VIAETH','4h','0.001393000000000','0.001383000000000','0.075129850303985','0.074590511823698','53.93384802870424','53.933848028704240','test'),('2019-08-23 11:59:59','2019-08-23 15:59:59','VIAETH','4h','0.001419000000000','0.001374000000000','0.075129850303985','0.072747296911681','52.945630940088094','52.945630940088094','test'),('2019-08-24 03:59:59','2019-08-28 23:59:59','VIAETH','4h','0.001462000000000','0.001521000000000','0.075129850303985','0.078161766287525','51.38840650067374','51.388406500673739','test'),('2019-09-15 03:59:59','2019-09-15 07:59:59','VIAETH','4h','0.001325000000000','0.001322000000000','0.075129850303985','0.074959744982542','56.701773814328305','56.701773814328305','test'),('2019-10-03 11:59:59','2019-10-05 15:59:59','VIAETH','4h','0.001098000000000','0.001096000000000','0.075129850303985','0.074993001760626','68.42427167940346','68.424271679403461','test'),('2019-10-05 19:59:59','2019-10-06 11:59:59','VIAETH','4h','0.001108000000000','0.001109000000000','0.075129850303985','0.075197657028086','67.80672410106949','67.806724101069491','test'),('2019-10-06 15:59:59','2019-10-09 15:59:59','VIAETH','4h','0.001128000000000','0.001117000000000','0.075129850303985','0.074397201054567','66.60447721984485','66.604477219844853','test'),('2019-10-09 19:59:59','2019-10-09 23:59:59','VIAETH','4h','0.001177000000000','0.001131000000000','0.075129850303985','0.072193594472223','63.8316485165548','63.831648516554800','test'),('2019-10-13 23:59:59','2019-10-16 07:59:59','VIAETH','4h','0.001154000000000','0.001168000000000','0.075129850303985','0.076041304293808','65.10385641593155','65.103856415931546','test'),('2019-10-17 19:59:59','2019-10-17 23:59:59','VIAETH','4h','0.001180000000000','0.001156000000000','0.075129850303985','0.073601785552040','63.66936466439407','63.669364664394067','test'),('2019-10-18 03:59:59','2019-10-19 03:59:59','VIAETH','4h','0.001189000000000','0.001150000000000','0.075129850303985','0.072665540664073','63.18742666441128','63.187426664411277','test'),('2019-10-19 07:59:59','2019-10-23 15:59:59','VIAETH','4h','0.001203000000000','0.001200000000000','0.075129850303985','0.074942494068813','62.45207839067747','62.452078390677471','test'),('2019-11-03 19:59:59','2019-11-04 07:59:59','VIAETH','4h','0.001149000000000','0.001134000000000','0.075129850303985','0.074149042858763','65.38716301478242','65.387163014782416','test'),('2019-11-05 11:59:59','2019-11-06 11:59:59','VIAETH','4h','0.001171000000000','0.001155000000000','0.075129850303985','0.074103310931770','64.15871076343724','64.158710763437242','test'),('2019-11-06 19:59:59','2019-11-06 23:59:59','VIAETH','4h','0.001155000000000','0.001133000000000','0.075129850303985','0.073698805536290','65.04748944067966','65.047489440679655','test'),('2019-11-07 19:59:59','2019-11-08 03:59:59','VIAETH','4h','0.001171000000000','0.001144000000000','0.075129850303985','0.073397565113372','64.15871076343724','64.158710763437242','test'),('2019-11-18 23:59:59','2019-11-19 11:59:59','VIAETH','4h','0.001145000000000','0.001118000000000','0.075129850303985','0.073358229379786','65.61558978513975','65.615589785139747','test'),('2019-11-19 15:59:59','2019-11-20 11:59:59','VIAETH','4h','0.001128000000000','0.001100000000000','0.075129850303985','0.073264924941829','66.60447721984485','66.604477219844853','test'),('2019-11-20 15:59:59','2019-11-20 19:59:59','VIAETH','4h','0.001102000000000','0.001088000000000','0.075129850303985','0.074175387595949','68.1759077168648','68.175907716864799','test'),('2019-11-25 19:59:59','2019-11-28 15:59:59','VIAETH','4h','0.001142000000000','0.001176000000000','0.075129850303985','0.077366640943508','65.78795998597636','65.787959985976357','test'),('2019-11-29 03:59:59','2019-12-02 07:59:59','VIAETH','4h','0.001297000000000','0.001264000000000','0.075129850303985','0.073218296672503','57.92586762065151','57.925867620651509','test'),('2019-12-06 15:59:59','2019-12-10 23:59:59','VIAETH','4h','0.001294000000000','0.001371000000000','0.075129850303985','0.079600482818210','58.06016252239954','58.060162522399537','test'),('2019-12-11 07:59:59','2019-12-14 19:59:59','VIAETH','4h','0.001457000000000','0.001523000000000','0.075129850303985','0.078533124236767','51.56475655729925','51.564756557299248','test'),('2019-12-15 03:59:59','2019-12-15 11:59:59','VIAETH','4h','0.001513000000000','0.001453000000000','0.075129850303985','0.072150477522598','49.65621302312294','49.656213023122937','test'),('2019-12-16 19:59:59','2019-12-18 15:59:59','VIAETH','4h','0.001614000000000','0.001548000000000','0.075129850303985','0.072057625942112','46.548853967772615','46.548853967772615','test'),('2019-12-20 11:59:59','2019-12-20 19:59:59','VIAETH','4h','0.001579000000000','0.001536000000000','0.075129850303985','0.073083882246308','47.58065250410703','47.580652504107029','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 23:43:07
