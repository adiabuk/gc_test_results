-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 07:59:59','2019-01-14 15:59:59','SNMETH','4h','0.000157600000000','0.000149650000000','0.072144500000000','0.068505231123096','457.7696700507614','457.769670050761420','test'),('2019-01-15 07:59:59','2019-01-21 03:59:59','SNMETH','4h','0.000161090000000','0.000184000000000','0.072144500000000','0.082404792352101','447.8521323483767','447.852132348376699','test'),('2019-01-25 23:59:59','2019-01-27 15:59:59','SNMETH','4h','0.000182980000000','0.000183610000000','0.073799755868799','0.074053848371790','403.32143331948436','403.321433319484356','test'),('2019-01-27 23:59:59','2019-01-28 07:59:59','SNMETH','4h','0.000184420000000','0.000183040000000','0.073863278994547','0.073310566029508','400.5166413325399','400.516641332539905','test'),('2019-02-28 23:59:59','2019-03-05 23:59:59','SNMETH','4h','0.000144480000000','0.000152290000000','0.073863278994547','0.077856026841636','511.23531972969965','511.235319729699654','test'),('2019-03-08 19:59:59','2019-03-11 15:59:59','SNMETH','4h','0.000157320000000','0.000157390000000','0.074723287715059','0.074756536063267','474.9764029688501','474.976402968850095','test'),('2019-03-11 23:59:59','2019-03-19 11:59:59','SNMETH','4h','0.000160580000000','0.000177600000000','0.074731599802111','0.082652460610630','465.3854764112062','465.385476411206184','test'),('2019-03-26 11:59:59','2019-03-26 15:59:59','SNMETH','4h','0.000179320000000','0.000180800000000','0.076711815004241','0.077344948431668','427.79285636984855','427.792856369848550','test'),('2019-03-26 19:59:59','2019-03-30 07:59:59','SNMETH','4h','0.000181870000000','0.000192230000000','0.076870098361098','0.081248908604794','422.6650814378293','422.665081437829315','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','SNMETH','4h','0.000201630000000','0.000203590000000','0.077964800922022','0.078722679262582','386.6726227348212','386.672622734821175','test'),('2019-04-04 23:59:59','2019-04-05 07:59:59','SNMETH','4h','0.000203100000000','0.000200090000000','0.078154270507162','0.076996001899449','384.8068464163565','384.806846416356507','test'),('2019-04-05 11:59:59','2019-04-06 19:59:59','SNMETH','4h','0.000203870000000','0.000197950000000','0.078154270507162','0.075884818006047','383.35346302625203','383.353463026252030','test'),('2019-04-07 11:59:59','2019-04-07 23:59:59','SNMETH','4h','0.000205570000000','0.000198200000000','0.078154270507162','0.075352319961665','380.18324904977385','380.183249049773849','test'),('2019-06-02 23:59:59','2019-06-04 19:59:59','SNMETH','4h','0.000129160000000','0.000108650000000','0.078154270507162','0.065743740249328','605.0965508451688','605.096550845168849','test'),('2019-06-07 19:59:59','2019-06-09 15:59:59','SNMETH','4h','0.000112250000000','0.000112590000000','0.078154270507162','0.078390996137206','696.2518530704856','696.251853070485595','test'),('2019-06-09 19:59:59','2019-06-09 23:59:59','SNMETH','4h','0.000114420000000','0.000110920000000','0.078154270507162','0.075763605004845','683.0472863761755','683.047286376175521','test'),('2019-06-10 07:59:59','2019-06-11 03:59:59','SNMETH','4h','0.000114350000000','0.000113800000000','0.078154270507162','0.077778364527460','683.4654176402449','683.465417640244937','test'),('2019-06-11 11:59:59','2019-06-12 15:59:59','SNMETH','4h','0.000114510000000','0.000113110000000','0.078154270507162','0.077198755890884','682.5104401987775','682.510440198777474','test'),('2019-07-23 03:59:59','2019-07-23 07:59:59','SNMETH','4h','0.000065360000000','0.000063090000000','0.078154270507162','0.075439916253012','1195.7507727533966','1195.750772753396632','test'),('2019-07-23 11:59:59','2019-07-23 19:59:59','SNMETH','4h','0.000063350000000','0.000063530000000','0.078154270507162','0.078376334732755','1233.6901421809316','1233.690142180931616','test'),('2019-07-23 23:59:59','2019-07-24 15:59:59','SNMETH','4h','0.000063930000000','0.000062180000000','0.078154270507162','0.076014899736201','1222.4975834062568','1222.497583406256808','test'),('2019-07-24 19:59:59','2019-07-24 23:59:59','SNMETH','4h','0.000063360000000','0.000062480000000','0.078154270507162','0.077068794527896','1233.4954309842487','1233.495430984248742','test'),('2019-07-25 15:59:59','2019-07-27 11:59:59','SNMETH','4h','0.000063480000000','0.000062950000000','0.078154270507162','0.077501753755921','1231.1636815873032','1231.163681587303245','test'),('2019-08-22 19:59:59','2019-08-25 15:59:59','SNMETH','4h','0.000053710000000','0.000053590000000','0.078154270507162','0.077979656609175','1455.1158165548688','1455.115816554868843','test'),('2019-08-25 19:59:59','2019-08-26 03:59:59','SNMETH','4h','0.000053750000000','0.000052470000000','0.078154270507162','0.076293108344387','1454.0329396681304','1454.032939668130439','test'),('2019-08-26 15:59:59','2019-08-29 03:59:59','SNMETH','4h','0.000056600000000','0.000057660000000','0.078154270507162','0.079617937057296','1380.8175001265372','1380.817500126537198','test'),('2019-08-29 23:59:59','2019-08-31 23:59:59','SNMETH','4h','0.000059920000000','0.000058300000000','0.078154270507162','0.076041287893317','1304.31025545998','1304.310255459979999','test'),('2019-09-11 19:59:59','2019-09-12 03:59:59','SNMETH','4h','0.000058610000000','0.000053350000000','0.078154270507162','0.071140254761254','1333.4630695642722','1333.463069564272246','test'),('2019-09-21 19:59:59','2019-09-24 15:59:59','SNMETH','4h','0.000054870000000','0.000069780000000','0.078154270507162','0.099391379551481','1424.3533899610352','1424.353389961035191','test'),('2019-09-26 15:59:59','2019-09-27 19:59:59','SNMETH','4h','0.000074760000000','0.000069750000000','0.078154270507162','0.072916805348777','1045.4022272226057','1045.402227222605688','test'),('2019-09-27 23:59:59','2019-09-28 23:59:59','SNMETH','4h','0.000095870000000','0.000077490000000','0.078154270507162','0.063170693872953','815.2109158982164','815.210915898216399','test'),('2019-10-03 15:59:59','2019-10-04 11:59:59','SNMETH','4h','0.000077110000000','0.000074880000000','0.078154270507162','0.075894070491198','1013.5426080555311','1013.542608055531105','test'),('2019-10-04 23:59:59','2019-10-05 03:59:59','SNMETH','4h','0.000074160000000','0.000072290000000','0.078154270507162','0.076183551981698','1053.8601740447953','1053.860174044795258','test'),('2019-10-16 07:59:59','2019-10-16 11:59:59','SNMETH','4h','0.000068710000000','0.000065680000000','0.078154270507162','0.074707793434877','1137.4511789719402','1137.451178971940180','test'),('2019-10-21 07:59:59','2019-10-23 15:59:59','SNMETH','4h','0.000069300000000','0.000068600000000','0.078154270507162','0.077364833431332','1127.7672511855988','1127.767251185598752','test'),('2019-10-31 15:59:59','2019-11-01 03:59:59','SNMETH','4h','0.000068940000000','0.000068930000000','0.078154270507162','0.078142933943410','1133.6563752126779','1133.656375212677858','test'),('2019-11-01 07:59:59','2019-11-05 07:59:59','SNMETH','4h','0.000071270000000','0.000072240000000','0.078154270507162','0.079217966906656','1096.5942262826154','1096.594226282615409','test'),('2019-11-11 19:59:59','2019-11-18 15:59:59','SNMETH','4h','0.000080370000000','0.000079090000000','0.078154270507162','0.076909558969907','972.4308884803036','972.430888480303565','test'),('2019-11-22 07:59:59','2019-11-27 07:59:59','SNMETH','4h','0.000084150000000','0.000097730000000','0.078154270507162','0.090766688730421','928.7495009763755','928.749500976375543','test'),('2019-11-27 19:59:59','2019-11-30 11:59:59','SNMETH','4h','0.000121050000000','0.000107490000000','0.078154270507162','0.069399442683311','645.636270195473','645.636270195473003','test'),('2019-12-04 11:59:59','2019-12-04 23:59:59','SNMETH','4h','0.000110090000000','0.000106860000000','0.078154270507162','0.075861253032931','709.9125307217913','709.912530721791313','test'),('2019-12-05 07:59:59','2019-12-05 15:59:59','SNMETH','4h','0.000107140000000','0.000106040000000','0.078154270507162','0.077351865265815','729.4593103151204','729.459310315120433','test'),('2019-12-05 23:59:59','2019-12-09 07:59:59','SNMETH','4h','0.000106040000000','0.000112000000000','0.078154270507162','0.082546947348191','737.0263156088458','737.026315608845835','test'),('2020-01-01 03:59:59','2020-01-01 15:59:59','SNMETH','4h','0.000101420000000','0.000101870000000','0.078154270507162','0.078501040589278','770.6001824803984','770.600182480398416','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  8:51:10
