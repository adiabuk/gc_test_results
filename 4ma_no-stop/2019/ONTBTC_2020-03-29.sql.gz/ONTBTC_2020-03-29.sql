-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 11:59:59','2019-01-10 11:59:59','ONTBTC','4h','0.000168600000000','0.000161500000000','0.001467500000000','0.001405701364176','8.704033214709371','8.704033214709371','test'),('2019-01-11 15:59:59','2019-01-13 07:59:59','ONTBTC','4h','0.000169800000000','0.000166800000000','0.001467500000000','0.001441572438163','8.642520612485276','8.642520612485276','test'),('2019-01-16 19:59:59','2019-01-18 15:59:59','ONTBTC','4h','0.000171500000000','0.000167000000000','0.001467500000000','0.001428994169096','8.556851311953354','8.556851311953354','test'),('2019-01-22 23:59:59','2019-01-23 19:59:59','ONTBTC','4h','0.000168400000000','0.000166100000000','0.001467500000000','0.001447456947743','8.71437054631829','8.714370546318291','test'),('2019-01-23 23:59:59','2019-01-24 03:59:59','ONTBTC','4h','0.000166900000000','0.000166300000000','0.001467500000000','0.001462224385860','8.79269023367286','8.792690233672859','test'),('2019-01-24 07:59:59','2019-01-24 11:59:59','ONTBTC','4h','0.000166600000000','0.000167200000000','0.001467500000000','0.001472785114046','8.808523409363746','8.808523409363746','test'),('2019-01-25 15:59:59','2019-01-27 11:59:59','ONTBTC','4h','0.000172700000000','0.000169400000000','0.001467500000000','0.001439458598726','8.497394325419803','8.497394325419803','test'),('2019-02-10 19:59:59','2019-02-11 11:59:59','ONTBTC','4h','0.000159100000000','0.000158800000000','0.001467500000000','0.001464732872407','9.223758642363295','9.223758642363295','test'),('2019-02-11 19:59:59','2019-02-12 03:59:59','ONTBTC','4h','0.000159300000000','0.000157400000000','0.001467500000000','0.001449996861268','9.212178279974891','9.212178279974891','test'),('2019-02-12 07:59:59','2019-02-12 11:59:59','ONTBTC','4h','0.000159000000000','0.000158100000000','0.001467500000000','0.001459193396226','9.229559748427674','9.229559748427674','test'),('2019-02-12 19:59:59','2019-02-14 07:59:59','ONTBTC','4h','0.000160600000000','0.000158200000000','0.001467500000000','0.001445569738481','9.13760896637609','9.137608966376090','test'),('2019-02-15 11:59:59','2019-02-18 11:59:59','ONTBTC','4h','0.000171900000000','0.000173000000000','0.001467500000000','0.001476890634090','8.5369400814427','8.536940081442699','test'),('2019-02-19 07:59:59','2019-02-20 03:59:59','ONTBTC','4h','0.000181100000000','0.000171700000000','0.001467500000000','0.001391329376035','8.103257868580894','8.103257868580894','test'),('2019-02-20 15:59:59','2019-02-26 19:59:59','ONTBTC','4h','0.000178400000000','0.000237300000000','0.001467500000000','0.001952005325112','8.225896860986547','8.225896860986547','test'),('2019-03-01 19:59:59','2019-03-02 07:59:59','ONTBTC','4h','0.000242100000000','0.000234300000000','0.001515727805357','0.001466893947935','6.260750951496282','6.260750951496282','test'),('2019-03-06 07:59:59','2019-03-10 07:59:59','ONTBTC','4h','0.000235600000000','0.000243600000000','0.001515727805357','0.001567195642551','6.433479649223259','6.433479649223259','test'),('2019-03-13 03:59:59','2019-03-13 11:59:59','ONTBTC','4h','0.000252300000000','0.000247400000000','0.001516386300300','0.001486936070924','6.010250892985532','6.010250892985532','test'),('2019-03-13 15:59:59','2019-03-24 03:59:59','ONTBTC','4h','0.000265200000000','0.000307700000000','0.001516386300300','0.001759396925348','5.717897059954751','5.717897059954751','test'),('2019-03-27 23:59:59','2019-03-28 11:59:59','ONTBTC','4h','0.000310000000000','0.000303600000000','0.001569776399218','0.001537368112266','5.063794836187903','5.063794836187903','test'),('2019-03-28 15:59:59','2019-03-29 03:59:59','ONTBTC','4h','0.000306100000000','0.000306400000000','0.001569776399218','0.001571314892912','5.128312313681803','5.128312313681803','test'),('2019-03-30 03:59:59','2019-04-02 03:59:59','ONTBTC','4h','0.000314000000000','0.000306200000000','0.001569776399218','0.001530781953632','4.9992878955987265','4.999287895598727','test'),('2019-04-04 19:59:59','2019-04-06 19:59:59','ONTBTC','4h','0.000315000000000','0.000310200000000','0.001569776399218','0.001545855996944','4.983417140374603','4.983417140374603','test'),('2019-05-16 03:59:59','2019-05-16 11:59:59','ONTBTC','4h','0.000198800000000','0.000179800000000','0.001569776399218','0.001419747467703','7.896259553410462','7.896259553410462','test'),('2019-05-16 15:59:59','2019-05-17 03:59:59','ONTBTC','4h','0.000193000000000','0.000180900000000','0.001569776399218','0.001471360365899','8.133556472632124','8.133556472632124','test'),('2019-05-17 07:59:59','2019-05-17 11:59:59','ONTBTC','4h','0.000183300000000','0.000180700000000','0.001569776399218','0.001547510067314','8.56397380915439','8.563973809154390','test'),('2019-05-17 15:59:59','2019-05-18 07:59:59','ONTBTC','4h','0.000185600000000','0.000181200000000','0.001569776399218','0.001532561872512','8.457846978545257','8.457846978545257','test'),('2019-05-30 03:59:59','2019-05-30 23:59:59','ONTBTC','4h','0.000180200000000','0.000174600000000','0.001569776399218','0.001520993114892','8.711300772574917','8.711300772574917','test'),('2019-05-31 07:59:59','2019-05-31 15:59:59','ONTBTC','4h','0.000174400000000','0.000172100000000','0.001569776399218','0.001549074072852','9.001011463405963','9.001011463405963','test'),('2019-05-31 23:59:59','2019-06-01 15:59:59','ONTBTC','4h','0.000178400000000','0.000172200000000','0.001569776399218','0.001515221389828','8.799195062881166','8.799195062881166','test'),('2019-06-10 03:59:59','2019-06-12 23:59:59','ONTBTC','4h','0.000184500000000','0.000175000000000','0.001569776399218','0.001488947804136','8.508273166493224','8.508273166493224','test'),('2019-06-13 15:59:59','2019-06-13 23:59:59','ONTBTC','4h','0.000180300000000','0.000173800000000','0.001569776399218','0.001513184349329','8.706469213632834','8.706469213632834','test'),('2019-07-22 23:59:59','2019-07-23 07:59:59','ONTBTC','4h','0.000095900000000','0.000092700000000','0.001569776399218','0.001517395956283','16.368888417288844','16.368888417288844','test'),('2019-07-24 07:59:59','2019-07-27 23:59:59','ONTBTC','4h','0.000096000000000','0.000103100000000','0.001569776399218','0.001685874445410','16.351837491854166','16.351837491854166','test'),('2019-08-24 15:59:59','2019-08-26 03:59:59','ONTBTC','4h','0.000081600000000','0.000078300000000','0.001569776399218','0.001506292794838','19.237455872769605','19.237455872769605','test'),('2019-09-09 19:59:59','2019-09-11 19:59:59','ONTBTC','4h','0.000074000000000','0.000072000000000','0.001569776399218','0.001527350010050','21.21319458402703','21.213194584027029','test'),('2019-09-14 15:59:59','2019-09-22 07:59:59','ONTBTC','4h','0.000073100000000','0.000079400000000','0.001569776399218','0.001705064926100','21.47436934634747','21.474369346347469','test'),('2019-10-04 23:59:59','2019-10-09 15:59:59','ONTBTC','4h','0.000075200000000','0.000076400000000','0.001569776399218','0.001594826022610','20.87468615981383','20.874686159813830','test'),('2019-10-09 19:59:59','2019-10-10 03:59:59','ONTBTC','4h','0.000076800000000','0.000075200000000','0.001569776399218','0.001537072724234','20.43979686481771','20.439796864817708','test'),('2019-10-11 23:59:59','2019-10-12 15:59:59','ONTBTC','4h','0.000078000000000','0.000075900000000','0.001569776399218','0.001527513188470','20.12533845151282','20.125338451512821','test'),('2019-10-12 19:59:59','2019-10-12 23:59:59','ONTBTC','4h','0.000076200000000','0.000076000000000','0.001569776399218','0.001565656251189','20.60074014721785','20.600740147217849','test'),('2019-10-14 11:59:59','2019-10-14 15:59:59','ONTBTC','4h','0.000076600000000','0.000076600000000','0.001569776399218','0.001569776399218','20.49316448065274','20.493164480652741','test'),('2019-10-15 03:59:59','2019-10-15 07:59:59','ONTBTC','4h','0.000077000000000','0.000076500000000','0.001569776399218','0.001559583045976','20.386706483350647','20.386706483350647','test'),('2019-10-15 11:59:59','2019-10-16 15:59:59','ONTBTC','4h','0.000078100000000','0.000075000000000','0.001569776399218','0.001507467732924','20.09956977231754','20.099569772317540','test'),('2019-10-27 15:59:59','2019-10-31 19:59:59','ONTBTC','4h','0.000096000000000','0.000092900000000','0.001569776399218','0.001519085702993','16.351837491854166','16.351837491854166','test'),('2019-11-02 03:59:59','2019-11-05 03:59:59','ONTBTC','4h','0.000097600000000','0.000094900000000','0.001569776399218','0.001526350207846','16.083774582151637','16.083774582151637','test'),('2019-11-11 19:59:59','2019-11-15 07:59:59','ONTBTC','4h','0.000097600000000','0.000100900000000','0.001569776399218','0.001622852855339','16.083774582151637','16.083774582151637','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 15:13:10
