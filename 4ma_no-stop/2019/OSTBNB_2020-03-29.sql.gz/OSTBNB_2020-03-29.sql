-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 19:59:59','2019-01-07 23:59:59','OSTBNB','4h','0.004161000000000','0.004117000000000','0.711908500000000','0.704380508171113','171.090723383802','171.090723383801986','test'),('2019-02-17 15:59:59','2019-02-18 03:59:59','OSTBNB','4h','0.002700000000000','0.002355000000000','0.711908500000000','0.620942413888889','263.6698148148148','263.669814814814799','test'),('2019-02-18 07:59:59','2019-02-18 15:59:59','OSTBNB','4h','0.002358000000000','0.002390000000000','0.711908500000000','0.721569684054283','301.9120016963529','301.912001696352888','test'),('2019-02-18 23:59:59','2019-02-19 03:59:59','OSTBNB','4h','0.002364000000000','0.002311000000000','0.711908500000000','0.695947776438240','301.14572758037224','301.145727580372238','test'),('2019-02-26 03:59:59','2019-02-27 23:59:59','OSTBNB','4h','0.002415000000000','0.002312000000000','0.711908500000000','0.681545528778468','294.78612836438924','294.786128364389242','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','OSTBNB','4h','0.001868000000000','0.001828000000000','0.711908500000000','0.696664206638116','381.10733404710925','381.107334047109248','test'),('2019-03-21 19:59:59','2019-03-22 15:59:59','OSTBNB','4h','0.001830000000000','0.001858000000000','0.711908500000000','0.722801089071038','389.0210382513661','389.021038251366122','test'),('2019-03-22 23:59:59','2019-03-23 07:59:59','OSTBNB','4h','0.001849000000000','0.001784000000000','0.711908500000000','0.686881970795024','385.02352623039485','385.023526230394850','test'),('2019-03-28 15:59:59','2019-03-30 07:59:59','OSTBNB','4h','0.001793000000000','0.001764000000000','0.711908500000000','0.700394084774122','397.04880089235917','397.048800892359168','test'),('2019-05-08 23:59:59','2019-05-09 11:59:59','OSTBNB','4h','0.001050000000000','0.001015000000000','0.711908500000000','0.688178216666667','678.0080952380953','678.008095238095279','test'),('2019-05-09 15:59:59','2019-05-09 19:59:59','OSTBNB','4h','0.001027000000000','0.001011000000000','0.711908500000000','0.700817423076923','693.1923076923078','693.192307692307850','test'),('2019-05-09 23:59:59','2019-05-10 03:59:59','OSTBNB','4h','0.001026000000000','0.001032000000000','0.711908500000000','0.716071707602339','693.867933723197','693.867933723196984','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','OSTBNB','4h','0.001033000000000','0.001028000000000','0.711908500000000','0.708462669893514','689.1660212971926','689.166021297192628','test'),('2019-05-10 15:59:59','2019-05-11 15:59:59','OSTBNB','4h','0.001068000000000','0.001010000000000','0.711908500000000','0.673246802434457','666.5809925093633','666.580992509363341','test'),('2019-05-28 07:59:59','2019-05-29 03:59:59','OSTBNB','4h','0.000829000000000','0.000988000000000','0.711908500000000','0.848450661037394','858.7557297949337','858.755729794933700','test'),('2019-05-29 23:59:59','2019-05-30 03:59:59','OSTBNB','4h','0.000892000000000','0.000857000000000','0.711908500000000','0.683974870515695','798.1036995515695','798.103699551569548','test'),('2019-05-30 07:59:59','2019-05-30 23:59:59','OSTBNB','4h','0.000877000000000','0.000844000000000','0.711908500000000','0.685120608893957','811.7542759407071','811.754275940707089','test'),('2019-06-03 15:59:59','2019-06-04 03:59:59','OSTBNB','4h','0.000868000000000','0.000861000000000','0.711908500000000','0.706167302419355','820.1710829493088','820.171082949308811','test'),('2019-06-04 07:59:59','2019-06-04 19:59:59','OSTBNB','4h','0.000875000000000','0.000819000000000','0.711908500000000','0.666346356000000','813.6097142857143','813.609714285714290','test'),('2019-06-05 11:59:59','2019-06-05 23:59:59','OSTBNB','4h','0.000910000000000','0.000848000000000','0.711908500000000','0.663404843956044','782.317032967033','782.317032967033015','test'),('2019-06-06 03:59:59','2019-06-06 07:59:59','OSTBNB','4h','0.000864000000000','0.000834000000000','0.711908500000000','0.687189454861111','823.9681712962964','823.968171296296418','test'),('2019-06-07 11:59:59','2019-06-09 19:59:59','OSTBNB','4h','0.000871000000000','0.000886000000000','0.711908500000000','0.724168692307692','817.3461538461539','817.346153846153925','test'),('2019-06-10 03:59:59','2019-06-10 11:59:59','OSTBNB','4h','0.000881000000000','0.000862000000000','0.711908500000000','0.696555195232690','808.0686719636777','808.068671963677730','test'),('2019-06-11 19:59:59','2019-06-12 03:59:59','OSTBNB','4h','0.000893000000000','0.000857000000000','0.711908500000000','0.683208941209407','797.2099664053752','797.209966405375212','test'),('2019-06-16 11:59:59','2019-06-17 07:59:59','OSTBNB','4h','0.000871000000000','0.000840000000000','0.711908500000000','0.686570769230769','817.3461538461539','817.346153846153925','test'),('2019-07-24 23:59:59','2019-07-25 11:59:59','OSTBNB','4h','0.000520800000000','0.000509000000000','0.711908500000000','0.695778468701997','1366.9518049155147','1366.951804915514685','test'),('2019-07-25 19:59:59','2019-07-26 03:59:59','OSTBNB','4h','0.000520900000000','0.000508400000000','0.711908500000000','0.694824882703014','1366.6893837588789','1366.689383758878876','test'),('2019-07-26 11:59:59','2019-07-27 11:59:59','OSTBNB','4h','0.000526100000000','0.000505600000000','0.711908500000000','0.684168290439080','1353.1809541912185','1353.180954191218461','test'),('2019-07-27 15:59:59','2019-07-27 19:59:59','OSTBNB','4h','0.000517500000000','0.000513300000000','0.711908500000000','0.706130691884058','1375.6685990338167','1375.668599033816690','test'),('2019-07-29 11:59:59','2019-07-31 07:59:59','OSTBNB','4h','0.000529200000000','0.000523200000000','0.711908500000000','0.703836975056690','1345.2541572184432','1345.254157218443197','test'),('2019-08-21 19:59:59','2019-08-28 03:59:59','OSTBNB','4h','0.000400900000000','0.000450300000000','0.711908500000000','0.799631822274881','1775.7757545522577','1775.775754552257695','test'),('2019-08-29 23:59:59','2019-09-02 19:59:59','OSTBNB','4h','0.000479000000000','0.000476600000000','0.711908500000000','0.708341526304802','1486.239039665971','1486.239039665970949','test'),('2019-09-04 23:59:59','2019-09-05 19:59:59','OSTBNB','4h','0.000495500000000','0.000470700000000','0.711908500000000','0.676277156306761','1436.7477295660951','1436.747729566095131','test'),('2019-09-05 23:59:59','2019-09-06 07:59:59','OSTBNB','4h','0.000477300000000','0.000477600000000','0.711908500000000','0.712355959773727','1491.5325790907186','1491.532579090718627','test'),('2019-09-07 03:59:59','2019-09-12 23:59:59','OSTBNB','4h','0.000504400000000','0.000529000000000','0.711908500000000','0.746628859040444','1411.396708961142','1411.396708961141940','test'),('2019-09-15 11:59:59','2019-09-16 23:59:59','OSTBNB','4h','0.000560200000000','0.000538000000000','0.711908500000000','0.683696488754016','1270.8113173866477','1270.811317386647715','test'),('2019-09-17 03:59:59','2019-09-17 19:59:59','OSTBNB','4h','0.000543600000000','0.000542400000000','0.711908500000000','0.710336958057395','1309.6182855040472','1309.618285504047208','test'),('2019-09-19 07:59:59','2019-09-24 23:59:59','OSTBNB','4h','0.000575800000000','0.000612400000000','0.711908500000000','0.757160064953109','1236.3815560958667','1236.381556095866699','test'),('2019-09-26 07:59:59','2019-09-29 15:59:59','OSTBNB','4h','0.000672400000000','0.000656900000000','0.711908500000000','0.695497759741226','1058.7574360499705','1058.757436049970465','test'),('2019-10-03 03:59:59','2019-10-09 15:59:59','OSTBNB','4h','0.000679900000000','0.000702200000000','0.711908500000000','0.735258344903662','1047.0782468010002','1047.078246801000205','test'),('2019-11-03 15:59:59','2019-11-04 03:59:59','OSTBNB','4h','0.000650300000000','0.000591600000000','0.711908500000000','0.647647345225281','1094.7385821928342','1094.738582192834201','test'),('2019-11-05 03:59:59','2019-11-05 07:59:59','OSTBNB','4h','0.000602500000000','0.000598200000000','0.711908500000000','0.706827659253112','1181.5908713692947','1181.590871369294746','test'),('2019-11-17 03:59:59','2019-11-19 15:59:59','OSTBNB','4h','0.000655900000000','0.000590600000000','0.711908500000000','0.641032413630127','1085.3918280225646','1085.391828022564596','test'),('2019-11-21 07:59:59','2019-11-21 11:59:59','OSTBNB','4h','0.000612700000000','0.000580600000000','0.711908500000000','0.674610861922638','1161.9201893259344','1161.920189325934416','test'),('2019-11-24 19:59:59','2019-11-30 11:59:59','OSTBNB','4h','0.000613800000000','0.000676900000000','0.711908500000000','0.785094271179537','1159.8378950798308','1159.837895079830787','test'),('2019-11-30 15:59:59','2019-11-30 19:59:59','OSTBNB','4h','0.000691500000000','0.000671600000000','0.711908500000000','0.691421183803326','1029.5133767172815','1029.513376717281517','test'),('2019-12-07 15:59:59','2019-12-08 11:59:59','OSTBNB','4h','0.000715000000000','0.000667300000000','0.711908500000000','0.664414744125874','995.6762237762238','995.676223776223765','test'),('2019-12-08 15:59:59','2019-12-10 03:59:59','OSTBNB','4h','0.000685600000000','0.000661500000000','0.711908500000000','0.686883711712369','1038.3729579929989','1038.372957992998863','test'),('2019-12-12 07:59:59','2019-12-22 11:59:59','OSTBNB','4h','0.000705700000000','0.000917600000000','0.711908500000000','0.925672721553068','1008.7976477256626','1008.797647725662614','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 12:58:40
