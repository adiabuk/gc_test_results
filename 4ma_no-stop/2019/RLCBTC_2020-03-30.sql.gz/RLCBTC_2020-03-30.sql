-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 15:59:59','2019-01-02 23:59:59','RLCBTC','4h','0.000051800000000','0.000050800000000','0.001467500000000','0.001439169884170','28.330115830115833','28.330115830115833','test'),('2019-01-03 15:59:59','2019-01-03 19:59:59','RLCBTC','4h','0.000050100000000','0.000050400000000','0.001467500000000','0.001476287425150','29.291417165668665','29.291417165668665','test'),('2019-01-05 07:59:59','2019-01-08 11:59:59','RLCBTC','4h','0.000050700000000','0.000051600000000','0.001467500000000','0.001493550295858','28.94477317554241','28.944773175542409','test'),('2019-01-08 15:59:59','2019-01-08 23:59:59','RLCBTC','4h','0.000052200000000','0.000051800000000','0.001469126901295','0.001457869223890','28.144193511388888','28.144193511388888','test'),('2019-01-09 11:59:59','2019-01-10 07:59:59','RLCBTC','4h','0.000053100000000','0.000051100000000','0.001469126901295','0.001413792554730','27.667173282391712','27.667173282391712','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','RLCBTC','4h','0.000053500000000','0.000051500000000','0.001469126901295','0.001414206269471','27.460315912056075','27.460315912056075','test'),('2019-01-15 15:59:59','2019-01-18 03:59:59','RLCBTC','4h','0.000058200000000','0.000056800000000','0.001469126901295','0.001433787078927','25.242730262800688','25.242730262800688','test'),('2019-01-22 19:59:59','2019-01-23 11:59:59','RLCBTC','4h','0.000056000000000','0.000055600000000','0.001469126901295','0.001458633137714','26.23440895169643','26.234408951696430','test'),('2019-01-23 15:59:59','2019-01-29 03:59:59','RLCBTC','4h','0.000055900000000','0.000065400000000','0.001469126901295','0.001718799630495','26.281339915831847','26.281339915831847','test'),('2019-01-29 23:59:59','2019-02-01 03:59:59','RLCBTC','4h','0.000070800000000','0.000069000000000','0.001489708523159','0.001451834577655','21.041080835575563','21.041080835575563','test'),('2019-02-03 07:59:59','2019-02-04 19:59:59','RLCBTC','4h','0.000072600000000','0.000072000000000','0.001489708523159','0.001477396882472','20.51940114544077','20.519401145440771','test'),('2019-02-17 11:59:59','2019-02-17 15:59:59','RLCBTC','4h','0.000070500000000','0.000069200000000','0.001489708523159','0.001462238720604','21.130617349773047','21.130617349773047','test'),('2019-02-17 19:59:59','2019-02-18 07:59:59','RLCBTC','4h','0.000070100000000','0.000067700000000','0.001489708523159','0.001438705663593','21.251191485863053','21.251191485863053','test'),('2019-02-18 11:59:59','2019-02-18 15:59:59','RLCBTC','4h','0.000068200000000','0.000067800000000','0.001489708523159','0.001480971229768','21.84323347740469','21.843233477404691','test'),('2019-02-20 11:59:59','2019-02-21 11:59:59','RLCBTC','4h','0.000069200000000','0.000067600000000','0.001489708523159','0.001455264395456','21.527579814436415','21.527579814436415','test'),('2019-02-21 15:59:59','2019-02-21 19:59:59','RLCBTC','4h','0.000069400000000','0.000068700000000','0.001489708523159','0.001474682644683','21.465540679524494','21.465540679524494','test'),('2019-02-21 23:59:59','2019-02-24 15:59:59','RLCBTC','4h','0.000068900000000','0.000071200000000','0.001489708523159','0.001539437544977','21.621313833947752','21.621313833947752','test'),('2019-02-25 11:59:59','2019-02-28 15:59:59','RLCBTC','4h','0.000086100000000','0.000079300000000','0.001489708523159','0.001372054423769','17.302073439709638','17.302073439709638','test'),('2019-02-28 19:59:59','2019-03-06 11:59:59','RLCBTC','4h','0.000085700000000','0.000086500000000','0.001489708523159','0.001503614787086','17.38282990850642','17.382829908506420','test'),('2019-03-12 19:59:59','2019-03-13 23:59:59','RLCBTC','4h','0.000134600000000','0.000107100000000','0.001489708523159','0.001185347569319','11.06767104872957','11.067671048729570','test'),('2019-03-14 07:59:59','2019-03-16 19:59:59','RLCBTC','4h','0.000103100000000','0.000103900000000','0.001489708523159','0.001501267852146','14.449161233355966','14.449161233355966','test'),('2019-03-23 15:59:59','2019-03-23 19:59:59','RLCBTC','4h','0.000099900000000','0.000098300000000','0.001489708523159','0.001465849327593','14.91199722881882','14.911997228818819','test'),('2019-03-26 11:59:59','2019-03-30 03:59:59','RLCBTC','4h','0.000111200000000','0.000103100000000','0.001489708523159','0.001381195582173','13.396659380926259','13.396659380926259','test'),('2019-03-31 11:59:59','2019-04-02 07:59:59','RLCBTC','4h','0.000106800000000','0.000111300000000','0.001489708523159','0.001552477140708','13.948581677518728','13.948581677518728','test'),('2019-04-02 19:59:59','2019-04-02 23:59:59','RLCBTC','4h','0.000111600000000','0.000108900000000','0.001489708523159','0.001453667187921','13.348642680636202','13.348642680636202','test'),('2019-04-05 23:59:59','2019-04-06 03:59:59','RLCBTC','4h','0.000108900000000','0.000107200000000','0.001489708523159','0.001466453201861','13.67960076362718','13.679600763627180','test'),('2019-04-06 07:59:59','2019-04-06 11:59:59','RLCBTC','4h','0.000107900000000','0.000109800000000','0.001489708523159','0.001515940647292','13.8063811228823','13.806381122882300','test'),('2019-04-06 19:59:59','2019-04-07 15:59:59','RLCBTC','4h','0.000110000000000','0.000106100000000','0.001489708523159','0.001436891584611','13.54280475599091','13.542804755990909','test'),('2019-04-20 07:59:59','2019-04-21 11:59:59','RLCBTC','4h','0.000098500000000','0.000101500000000','0.001489708523159','0.001535080356352','15.1239443975533','15.123944397553300','test'),('2019-04-21 15:59:59','2019-04-23 07:59:59','RLCBTC','4h','0.000104400000000','0.000098600000000','0.001489708523159','0.001406946938539','14.269238727576628','14.269238727576628','test'),('2019-05-02 23:59:59','2019-05-03 03:59:59','RLCBTC','4h','0.000095000000000','0.000090000000000','0.001489708523159','0.001411302811414','15.681142349042105','15.681142349042105','test'),('2019-05-03 15:59:59','2019-05-03 19:59:59','RLCBTC','4h','0.000091000000000','0.000092800000000','0.001489708523159','0.001519175285156','16.370423331417584','16.370423331417584','test'),('2019-05-03 23:59:59','2019-05-10 03:59:59','RLCBTC','4h','0.000096500000000','0.000098700000000','0.001489708523159','0.001523670790008','15.437394022373057','15.437394022373057','test'),('2019-06-10 07:59:59','2019-06-12 15:59:59','RLCBTC','4h','0.000057200000000','0.000056500000000','0.001489708523159','0.001471477824449','26.043855299982518','26.043855299982518','test'),('2019-07-01 23:59:59','2019-07-02 15:59:59','RLCBTC','4h','0.000036900000000','0.000033900000000','0.001489708523159','0.001368594009081','40.371504692655826','40.371504692655826','test'),('2019-07-25 11:59:59','2019-07-30 15:59:59','RLCBTC','4h','0.000028100000000','0.000028800000000','0.001489708523159','0.001526818699892','53.01453819071175','53.014538190711747','test'),('2019-08-24 23:59:59','2019-08-25 15:59:59','RLCBTC','4h','0.000024200000000','0.000023000000000','0.001489708523159','0.001415838679035','61.558203436322316','61.558203436322316','test'),('2019-09-12 19:59:59','2019-09-22 03:59:59','RLCBTC','4h','0.000019700000000','0.000023080000000','0.001489708523159','0.001745303183478','75.6197219877665','75.619721987766496','test'),('2019-09-26 07:59:59','2019-10-01 19:59:59','RLCBTC','4h','0.000023130000000','0.000024930000000','0.001489708523159','0.001605639147529','64.40590242797234','64.405902427972336','test'),('2019-10-02 19:59:59','2019-10-11 11:59:59','RLCBTC','4h','0.000027270000000','0.000031890000000','0.001489708523159','0.001742090385168','54.62810866002933','54.628108660029334','test'),('2019-10-12 23:59:59','2019-10-18 23:59:59','RLCBTC','4h','0.000035390000000','0.000040600000000','0.001489708523159','0.001709018537447','42.09405264648206','42.094052646482062','test'),('2019-10-23 07:59:59','2019-10-23 15:59:59','RLCBTC','4h','0.000042870000000','0.000043070000000','0.001489708523159','0.001496658411301','34.749440708164215','34.749440708164215','test'),('2019-10-23 19:59:59','2019-11-04 23:59:59','RLCBTC','4h','0.000043680000000','0.000067860000000','0.001489708523159','0.002314368598479','34.10504860711996','34.105048607119961','test'),('2019-11-06 07:59:59','2019-11-08 11:59:59','RLCBTC','4h','0.000074800000000','0.000068770000000','0.001679004731561','0.001543651810019','22.44658732033422','22.446587320334221','test'),('2019-11-09 19:59:59','2019-11-10 03:59:59','RLCBTC','4h','0.000072070000000','0.000069330000000','0.001679004731561','0.001615171333969','23.29686043514638','23.296860435146382','test'),('2019-11-10 19:59:59','2019-11-15 15:59:59','RLCBTC','4h','0.000076950000000','0.000082310000000','0.001679004731561','0.001795956848015','21.819424711643922','21.819424711643922','test'),('2019-11-16 03:59:59','2019-11-19 11:59:59','RLCBTC','4h','0.000083290000000','0.000089210000000','0.001679004731561','0.001798343283738','20.158539219125945','20.158539219125945','test'),('2019-11-23 11:59:59','2019-11-25 23:59:59','RLCBTC','4h','0.000097990000000','0.000093040000000','0.001688280818935','0.001602996707763','17.22911336805031','17.229113368050310','test'),('2019-12-13 03:59:59','2019-12-13 11:59:59','RLCBTC','4h','0.000084670000000','0.000075830000000','0.001688280818935','0.001512015288766','19.93953961184599','19.939539611845991','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 12:35:55
