-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-02 19:59:59','ARDRBTC','4h','0.000014180000000','0.000014000000000','0.001467500000000','0.001448871650212','103.49083215796898','103.490832157968981','test'),('2019-01-03 03:59:59','2019-01-08 07:59:59','ARDRBTC','4h','0.000014030000000','0.000015170000000','0.001467500000000','0.001586740912331','104.59729151817534','104.597291518175339','test'),('2019-01-08 11:59:59','2019-01-08 19:59:59','ARDRBTC','4h','0.000015500000000','0.000015170000000','0.001492653140636','0.001460874073771','96.30020262166128','96.300202621661285','test'),('2019-01-09 07:59:59','2019-01-09 11:59:59','ARDRBTC','4h','0.000015370000000','0.000015280000000','0.001492653140636','0.001483912816455','97.11471311880287','97.114713118802868','test'),('2019-01-09 23:59:59','2019-01-10 03:59:59','ARDRBTC','4h','0.000015410000000','0.000015160000000','0.001492653140636','0.001468437482936','96.86263080051914','96.862630800519142','test'),('2019-01-17 19:59:59','2019-01-20 15:59:59','ARDRBTC','4h','0.000015420000000','0.000015070000000','0.001492653140636','0.001458773205537','96.79981456783398','96.799814567833977','test'),('2019-01-22 07:59:59','2019-01-24 03:59:59','ARDRBTC','4h','0.000016270000000','0.000015370000000','0.001492653140636','0.001410084743182','91.74266383749233','91.742663837492330','test'),('2019-02-02 19:59:59','2019-02-02 23:59:59','ARDRBTC','4h','0.000015410000000','0.000015240000000','0.001492653140636','0.001476186493400','96.86263080051914','96.862630800519142','test'),('2019-02-03 07:59:59','2019-02-03 11:59:59','ARDRBTC','4h','0.000015110000000','0.000015000000000','0.001492653140636','0.001481786704801','98.78578032005295','98.785780320052950','test'),('2019-02-03 15:59:59','2019-02-03 19:59:59','ARDRBTC','4h','0.000015080000000','0.000015030000000','0.001492653140636','0.001487704025448','98.98230375570293','98.982303755702929','test'),('2019-02-04 07:59:59','2019-02-04 15:59:59','ARDRBTC','4h','0.000015200000000','0.000015150000000','0.001492653140636','0.001487743097410','98.20086451552632','98.200864515526320','test'),('2019-02-16 23:59:59','2019-02-19 03:59:59','ARDRBTC','4h','0.000015130000000','0.000014760000000','0.001492653140636','0.001456150717501','98.65519766265697','98.655197662656974','test'),('2019-02-27 23:59:59','2019-02-28 03:59:59','ARDRBTC','4h','0.000014800000000','0.000014660000000','0.001492653140636','0.001478533448765','100.85494193486487','100.854941934864868','test'),('2019-02-28 11:59:59','2019-02-28 15:59:59','ARDRBTC','4h','0.000014640000000','0.000014710000000','0.001492653140636','0.001499790143358','101.9571817374317','101.957181737431696','test'),('2019-02-28 23:59:59','2019-03-01 07:59:59','ARDRBTC','4h','0.000014770000000','0.000014810000000','0.001492653140636','0.001496695532351','101.05979286635072','101.059792866350719','test'),('2019-03-01 15:59:59','2019-03-01 23:59:59','ARDRBTC','4h','0.000014850000000','0.000014720000000','0.001492653140636','0.001479586143445','100.51536300579124','100.515363005791244','test'),('2019-03-02 03:59:59','2019-03-02 07:59:59','ARDRBTC','4h','0.000014800000000','0.000014530000000','0.001492653140636','0.001465422306314','100.85494193486487','100.854941934864868','test'),('2019-03-03 07:59:59','2019-03-06 23:59:59','ARDRBTC','4h','0.000014810000000','0.000014990000000','0.001492653140636','0.001510794772325','100.78684271681297','100.786842716812970','test'),('2019-03-07 03:59:59','2019-03-09 15:59:59','ARDRBTC','4h','0.000015050000000','0.000015070000000','0.001492653140636','0.001494636732849','99.17961067348838','99.179610673488384','test'),('2019-03-12 01:59:59','2019-03-14 15:59:59','ARDRBTC','4h','0.000015710000000','0.000016380000000','0.001492653140636','0.001556311804177','95.01293065792488','95.012930657924883','test'),('2019-03-14 19:59:59','2019-03-18 11:59:59','ARDRBTC','4h','0.000016550000000','0.000016790000000','0.001492653140636','0.001514298865938','90.19052209280967','90.190522092809672','test'),('2019-03-20 19:59:59','2019-03-24 03:59:59','ARDRBTC','4h','0.000017210000000','0.000017350000000','0.001492653140636','0.001504795583384','86.73173391260896','86.731733912608959','test'),('2019-03-24 15:59:59','2019-03-30 03:59:59','ARDRBTC','4h','0.000017890000000','0.000018750000000','0.001492653140636','0.001564407288257','83.43505537372835','83.435055373728346','test'),('2019-03-31 11:59:59','2019-04-02 07:59:59','ARDRBTC','4h','0.000019950000000','0.000018180000000','0.001492653140636','0.001360222260489','74.81970629754386','74.819706297543860','test'),('2019-06-02 23:59:59','2019-06-04 07:59:59','ARDRBTC','4h','0.000010590000000','0.000010250000000','0.001492653140636','0.001444730376914','140.9493050647781','140.949305064778088','test'),('2019-06-04 11:59:59','2019-06-09 23:59:59','ARDRBTC','4h','0.000010420000000','0.000012510000000','0.001492653140636','0.001792043261934','143.24886186525913','143.248861865259130','test'),('2019-06-11 23:59:59','2019-06-13 19:59:59','ARDRBTC','4h','0.000012950000000','0.000012400000000','0.001495214767055','0.001431711437180','115.46059977258683','115.460599772586832','test'),('2019-06-19 07:59:59','2019-06-20 23:59:59','ARDRBTC','4h','0.000014500000000','0.000012580000000','0.001495214767055','0.001297227708245','103.11825979689655','103.118259796896552','test'),('2019-07-23 11:59:59','2019-07-24 07:59:59','ARDRBTC','4h','0.000007190000000','0.000006650000000','0.001495214767055','0.001382917691365','207.9575475737135','207.957547573713498','test'),('2019-07-24 23:59:59','2019-07-25 03:59:59','ARDRBTC','4h','0.000006940000000','0.000006780000000','0.001495214767055','0.001460742956864','215.44881369668587','215.448813696685875','test'),('2019-07-26 03:59:59','2019-07-29 19:59:59','ARDRBTC','4h','0.000007030000000','0.000007180000000','0.001495214767055','0.001527118353834','212.6905785284495','212.690578528449493','test'),('2019-07-29 23:59:59','2019-07-30 07:59:59','ARDRBTC','4h','0.000007240000000','0.000007050000000','0.001495214767055','0.001455975705489','206.52137666505524','206.521376665055243','test'),('2019-08-22 03:59:59','2019-08-27 15:59:59','ARDRBTC','4h','0.000005420000000','0.000006120000000','0.001495214767055','0.001688323685309','275.8698832204797','275.869883220479721','test'),('2019-09-09 11:59:59','2019-09-11 07:59:59','ARDRBTC','4h','0.000006280000000','0.000005640000000','0.001495214767055','0.001342836192069','238.09152341640126','238.091523416401259','test'),('2019-09-16 11:59:59','2019-09-17 11:59:59','ARDRBTC','4h','0.000005870000000','0.000005860000000','0.001495214767055','0.001492667552801','254.72142539267463','254.721425392674632','test'),('2019-09-17 19:59:59','2019-09-19 07:59:59','ARDRBTC','4h','0.000005850000000','0.000005800000000','0.001495214767055','0.001482435153661','255.59226787264956','255.592267872649558','test'),('2019-09-19 15:59:59','2019-09-20 03:59:59','ARDRBTC','4h','0.000005900000000','0.000005780000000','0.001495214767055','0.001464803619250','253.42623170423727','253.426231704237267','test'),('2019-09-20 07:59:59','2019-09-23 23:59:59','ARDRBTC','4h','0.000006070000000','0.000006310000000','0.001495214767055','0.001554333637581','246.3286271919275','246.328627191927495','test'),('2019-09-24 19:59:59','2019-09-24 23:59:59','ARDRBTC','4h','0.000006430000000','0.000006090000000','0.001495214767055','0.001416152088859','232.53728881104198','232.537288811041975','test'),('2019-09-26 23:59:59','2019-09-29 19:59:59','ARDRBTC','4h','0.000006300000000','0.000006360000000','0.001495214767055','0.001509454907694','237.33567731031746','237.335677310317465','test'),('2019-10-02 15:59:59','2019-10-07 07:59:59','ARDRBTC','4h','0.000006630000000','0.000006900000000','0.001495214767055','0.001556105866166','225.52258929939669','225.522589299396685','test'),('2019-10-07 11:59:59','2019-10-07 15:59:59','ARDRBTC','4h','0.000006970000000','0.000006930000000','0.001495214767055','0.001486633907560','214.52148738235292','214.521487382352916','test'),('2019-10-08 11:59:59','2019-10-09 15:59:59','ARDRBTC','4h','0.000007130000000','0.000006710000000','0.001495214767055','0.001407137599851','209.70754096143057','209.707540961430567','test'),('2019-11-03 15:59:59','2019-11-04 23:59:59','ARDRBTC','4h','0.000006240000000','0.000006070000000','0.001495214767055','0.001454479749363','239.61775113060895','239.617751130608951','test'),('2019-11-09 23:59:59','2019-11-10 19:59:59','ARDRBTC','4h','0.000006090000000','0.000006060000000','0.001495214767055','0.001487849177070','245.51966618308703','245.519666183087026','test'),('2019-11-10 23:59:59','2019-11-11 03:59:59','ARDRBTC','4h','0.000006080000000','0.000006090000000','0.001495214767055','0.001497674001869','245.92348142351972','245.923481423519718','test'),('2019-11-11 07:59:59','2019-11-14 11:59:59','ARDRBTC','4h','0.000006140000000','0.000006130000000','0.001495214767055','0.001492779563851','243.52032036726385','243.520320367263849','test'),('2019-11-15 19:59:59','2019-11-16 15:59:59','ARDRBTC','4h','0.000006290000000','0.000006320000000','0.001495214767055','0.001502346157041','237.7129995317965','237.712999531796498','test'),('2019-11-16 19:59:59','2019-11-18 11:59:59','ARDRBTC','4h','0.000006340000000','0.000006300000000','0.001495214767055','0.001485781235402','235.8382913335962','235.838291333596203','test'),('2019-11-18 15:59:59','2019-11-19 07:59:59','ARDRBTC','4h','0.000006330000000','0.000006200000000','0.001495214767055','0.001464507354777','236.21086367377566','236.210863673775663','test'),('2019-11-24 23:59:59','2019-11-25 03:59:59','ARDRBTC','4h','0.000006250000000','0.000006220000000','0.001495214767055','0.001488037736173','239.2343627288','239.234362728799994','test'),('2019-11-25 07:59:59','2019-11-25 11:59:59','ARDRBTC','4h','0.000006270000000','0.000006170000000','0.001495214767055','0.001471367641584','238.4712547137161','238.471254713716093','test'),('2019-11-26 15:59:59','2019-11-30 19:59:59','ARDRBTC','4h','0.000006420000000','0.000006730000000','0.001495214767055','0.001567413610947','232.89949642601243','232.899496426012433','test'),('2019-12-01 07:59:59','2019-12-02 23:59:59','ARDRBTC','4h','0.000006890000000','0.000006870000000','0.001495214767055','0.001490874520997','217.0123029107402','217.012302910740203','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:47:14
