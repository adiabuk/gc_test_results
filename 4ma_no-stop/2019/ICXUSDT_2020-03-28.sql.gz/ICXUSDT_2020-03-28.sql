-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-08 07:59:59','ICXUSDT','4h','0.242900000000000','0.265800000000000','15.000000000000000','16.414162206669410','61.753808151502675','61.753808151502675','test'),('2019-01-08 11:59:59','2019-01-10 07:59:59','ICXUSDT','4h','0.278200000000000','0.259700000000000','15.353540551667352','14.332546661639148','55.188858920443394','55.188858920443394','test'),('2019-02-08 07:59:59','2019-02-13 19:59:59','ICXUSDT','4h','0.209000000000000','0.218400000000000','15.353540551667352','16.044082566909807','73.4619165151548','73.461916515154797','test'),('2019-02-15 19:59:59','2019-02-16 11:59:59','ICXUSDT','4h','0.225700000000000','0.220800000000000','15.353540551667352','15.020211580895662','68.02632056565065','68.026320565650650','test'),('2019-02-16 15:59:59','2019-02-24 15:59:59','ICXUSDT','4h','0.224200000000000','0.240200000000000','15.353540551667352','16.449243713249320','68.48144759887312','68.481447598873117','test'),('2019-02-24 19:59:59','2019-02-24 23:59:59','ICXUSDT','4h','0.243100000000000','0.232400000000000','15.461521130673484','14.780985235575967','63.60148552313239','63.601485523132389','test'),('2019-02-26 07:59:59','2019-03-02 19:59:59','ICXUSDT','4h','0.286500000000000','0.279100000000000','15.461521130673484','15.062165960108096','53.96691494126871','53.966914941268712','test'),('2019-03-03 03:59:59','2019-03-03 23:59:59','ICXUSDT','4h','0.294700000000000','0.280100000000000','15.461521130673484','14.695527888366620','52.4652905689633','52.465290568963297','test'),('2019-03-06 07:59:59','2019-03-11 11:59:59','ICXUSDT','4h','0.285400000000000','0.323400000000000','15.461521130673484','17.520167952557134','54.17491636535909','54.174916365359088','test'),('2019-03-13 03:59:59','2019-03-13 15:59:59','ICXUSDT','4h','0.341900000000000','0.331900000000000','15.514711759151954','15.060932532502292','45.377922664966235','45.377922664966235','test'),('2019-03-15 15:59:59','2019-03-17 03:59:59','ICXUSDT','4h','0.345900000000000','0.327100000000000','15.514711759151954','14.671472149229848','44.8531707405376','44.853170740537600','test'),('2019-03-19 15:59:59','2019-03-20 03:59:59','ICXUSDT','4h','0.337400000000000','0.335900000000000','15.514711759151954','15.445737047715298','45.983140957771056','45.983140957771056','test'),('2019-03-20 11:59:59','2019-03-20 15:59:59','ICXUSDT','4h','0.335400000000000','0.333800000000000','15.514711759151954','15.440700015518551','46.257339770876435','46.257339770876435','test'),('2019-03-20 19:59:59','2019-03-21 07:59:59','ICXUSDT','4h','0.334900000000000','0.337500000000000','15.514711759151954','15.635160402250778','46.32640119185415','46.326401191854153','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','ICXUSDT','4h','0.341300000000000','0.318600000000000','15.514711759151954','14.482822052346361','45.45769633504821','45.457696335048212','test'),('2019-03-25 07:59:59','2019-03-25 15:59:59','ICXUSDT','4h','0.338100000000000','0.319900000000000','15.514711759151954','14.679551291785597','45.88793776738229','45.887937767382290','test'),('2019-03-29 23:59:59','2019-04-08 11:59:59','ICXUSDT','4h','0.333700000000000','0.407900000000000','15.514711759151954','18.964491838651728','46.49299298517217','46.492992985172172','test'),('2019-04-22 19:59:59','2019-04-23 23:59:59','ICXUSDT','4h','0.405000000000000','0.376600000000000','15.580505073348160','14.487946199068929','38.47038289715595','38.470382897155950','test'),('2019-04-25 11:59:59','2019-04-25 19:59:59','ICXUSDT','4h','0.390100000000000','0.378700000000000','15.580505073348160','15.125191672076257','39.939772041394924','39.939772041394924','test'),('2019-05-13 11:59:59','2019-05-13 23:59:59','ICXUSDT','4h','0.339900000000000','0.329500000000000','15.580505073348160','15.103784706290732','45.83849683244531','45.838496832445308','test'),('2019-05-14 03:59:59','2019-05-17 03:59:59','ICXUSDT','4h','0.342200000000000','0.358100000000000','15.580505073348160','16.304438535260012','45.53040640955044','45.530406409550437','test'),('2019-05-17 07:59:59','2019-05-17 11:59:59','ICXUSDT','4h','0.360600000000000','0.346400000000000','15.580505073348160','14.966963276227961','43.20716881128165','43.207168811281647','test'),('2019-05-18 11:59:59','2019-05-20 15:59:59','ICXUSDT','4h','0.376800000000000','0.370200000000000','15.580505073348160','15.307598137350022','41.34953575729342','41.349535757293417','test'),('2019-05-21 07:59:59','2019-05-22 23:59:59','ICXUSDT','4h','0.385300000000000','0.374500000000000','15.580505073348160','15.143781858211488','40.43733473487714','40.437334734877140','test'),('2019-05-24 23:59:59','2019-05-25 07:59:59','ICXUSDT','4h','0.386000000000000','0.379000000000000','15.580505073348160','15.297957053883296','40.36400278069471','40.364002780694712','test'),('2019-05-27 15:59:59','2019-05-28 15:59:59','ICXUSDT','4h','0.385900000000000','0.390900000000000','15.580505073348160','15.782377385778171','40.37446248600197','40.374462486001967','test'),('2019-05-28 19:59:59','2019-05-29 07:59:59','ICXUSDT','4h','0.400400000000000','0.389200000000000','15.580505073348160','15.144686749618142','38.91235033303737','38.912350333037367','test'),('2019-05-29 11:59:59','2019-05-30 23:59:59','ICXUSDT','4h','0.396700000000000','0.386800000000000','15.580505073348160','15.191679763980510','39.27528377451011','39.275283774510108','test'),('2019-06-02 11:59:59','2019-06-03 07:59:59','ICXUSDT','4h','0.415100000000000','0.403700000000000','15.580505073348160','15.152613582535899','37.53434129932103','37.534341299321028','test'),('2019-06-03 11:59:59','2019-06-03 15:59:59','ICXUSDT','4h','0.405600000000000','0.401900000000000','15.580505073348160','15.438375219375308','38.41347404671637','38.413474046716367','test'),('2019-06-03 19:59:59','2019-06-03 23:59:59','ICXUSDT','4h','0.410500000000000','0.386200000000000','15.580505073348160','14.658199900918538','37.9549453674742','37.954945367474203','test'),('2019-06-12 19:59:59','2019-06-14 03:59:59','ICXUSDT','4h','0.393300000000000','0.382500000000000','15.580505073348160','15.152665117100614','39.61481076366174','39.614810763661737','test'),('2019-07-07 23:59:59','2019-07-09 03:59:59','ICXUSDT','4h','0.354300000000000','0.325300000000000','15.580505073348160','14.305216766469535','43.9754588578836','43.975458857883602','test'),('2019-07-09 07:59:59','2019-07-09 15:59:59','ICXUSDT','4h','0.328100000000000','0.338100000000000','15.580505073348160','16.055375694297510','47.487062094934956','47.487062094934956','test'),('2019-07-26 19:59:59','2019-07-27 11:59:59','ICXUSDT','4h','0.282500000000000','0.263100000000000','15.580505073348160','14.510551804594341','55.152230348135085','55.152230348135085','test'),('2019-08-22 23:59:59','2019-08-25 23:59:59','ICXUSDT','4h','0.225500000000000','0.223100000000000','15.580505073348160','15.414681516026493','69.09314888402731','69.093148884027315','test'),('2019-08-26 23:59:59','2019-08-27 07:59:59','ICXUSDT','4h','0.240200000000000','0.231900000000000','15.580505073348160','15.042127920522224','64.86471720794405','64.864717207944054','test'),('2019-09-18 03:59:59','2019-09-19 03:59:59','ICXUSDT','4h','0.213800000000000','0.204800000000000','15.580505073348160','14.924637226481307','72.87420520742826','72.874205207428261','test'),('2019-09-19 07:59:59','2019-09-20 11:59:59','ICXUSDT','4h','0.209300000000000','0.207600000000000','15.580505073348160','15.453955342699846','74.4410180284193','74.441018028419293','test'),('2019-10-08 11:59:59','2019-10-09 15:59:59','ICXUSDT','4h','0.172500000000000','0.175300000000000','15.580505073348160','15.833406025263379','90.32176854114876','90.321768541148757','test'),('2019-10-09 19:59:59','2019-10-10 11:59:59','ICXUSDT','4h','0.175500000000000','0.171600000000000','15.580505073348160','15.234271627273758','88.77780668574451','88.777806685744508','test'),('2019-10-28 03:59:59','2019-10-31 11:59:59','ICXUSDT','4h','0.172200000000000','0.161700000000000','15.580505073348160','14.630474276192786','90.47912353860721','90.479123538607212','test'),('2019-11-03 07:59:59','2019-11-03 11:59:59','ICXUSDT','4h','0.164500000000000','0.162800000000000','15.580505073348160','15.419490735204135','94.71431655530796','94.714316555307960','test'),('2019-11-03 15:59:59','2019-11-08 07:59:59','ICXUSDT','4h','0.165300000000000','0.173900000000000','15.580505073348160','16.391106063250120','94.25592905836757','94.255929058367570','test'),('2019-12-08 15:59:59','2019-12-09 11:59:59','ICXUSDT','4h','0.136200000000000','0.136000000000000','15.580505073348160','15.557626211272762','114.3943103770056','114.394310377005596','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:38:26
