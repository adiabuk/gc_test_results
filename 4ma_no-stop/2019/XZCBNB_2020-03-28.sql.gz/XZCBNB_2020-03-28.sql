-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-02-26 11:59:59','2019-02-27 19:59:59','XZCBNB','4h','0.562000000000000','0.540000000000000','0.711908500000000','0.684040195729537','1.266741103202847','1.266741103202847','test'),('2019-03-13 07:59:59','2019-03-14 03:59:59','XZCBNB','4h','0.486000000000000','0.437000000000000','0.711908500000000','0.640131717078189','1.464832304526749','1.464832304526749','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','XZCBNB','4h','0.446000000000000','0.425000000000000','0.711908500000000','0.678388144618834','1.5962073991031391','1.596207399103139','test'),('2019-03-15 23:59:59','2019-03-16 11:59:59','XZCBNB','4h','0.455000000000000','0.429000000000000','0.711908500000000','0.671228014285714','1.564634065934066','1.564634065934066','test'),('2019-03-20 19:59:59','2019-03-24 07:59:59','XZCBNB','4h','0.445000000000000','0.449000000000000','0.711908500000000','0.718307677528090','1.599794382022472','1.599794382022472','test'),('2019-03-28 23:59:59','2019-03-29 03:59:59','XZCBNB','4h','0.433000000000000','0.427000000000000','0.711908500000000','0.702043717090069','1.6441304849884528','1.644130484988453','test'),('2019-03-29 07:59:59','2019-03-29 19:59:59','XZCBNB','4h','0.434000000000000','0.430000000000000','0.711908500000000','0.705347131336406','1.6403421658986177','1.640342165898618','test'),('2019-03-29 23:59:59','2019-03-30 07:59:59','XZCBNB','4h','0.433000000000000','0.437000000000000','0.711908500000000','0.718485021939954','1.6441304849884528','1.644130484988453','test'),('2019-03-30 15:59:59','2019-03-30 19:59:59','XZCBNB','4h','0.439000000000000','0.432000000000000','0.711908500000000','0.700556883826879','1.6216594533029614','1.621659453302961','test'),('2019-03-31 23:59:59','2019-04-01 11:59:59','XZCBNB','4h','0.473000000000000','0.433000000000000','0.711908500000000','0.651704821353066','1.5050919661733617','1.505091966173362','test'),('2019-04-01 23:59:59','2019-04-02 07:59:59','XZCBNB','4h','0.435000000000000','0.426000000000000','0.711908500000000','0.697179358620690','1.6365712643678163','1.636571264367816','test'),('2019-04-03 15:59:59','2019-04-04 19:59:59','XZCBNB','4h','0.459000000000000','0.437000000000000','0.711908500000000','0.677786523965142','1.5509989106753814','1.550998910675381','test'),('2019-04-04 23:59:59','2019-04-06 23:59:59','XZCBNB','4h','0.438000000000000','0.448000000000000','0.711908500000000','0.728162118721461','1.625361872146119','1.625361872146119','test'),('2019-04-07 07:59:59','2019-04-09 23:59:59','XZCBNB','4h','0.451000000000000','0.455000000000000','0.711908500000000','0.718222544345898','1.5785110864745011','1.578511086474501','test'),('2019-05-07 23:59:59','2019-05-11 11:59:59','XZCBNB','4h','0.325000000000000','0.321000000000000','0.711908500000000','0.703146549230769','2.1904876923076926','2.190487692307693','test'),('2019-06-07 15:59:59','2019-06-15 07:59:59','XZCBNB','4h','0.285000000000000','0.326000000000000','0.711908500000000','0.814323407017544','2.4979245614035093','2.497924561403509','test'),('2019-06-15 15:59:59','2019-06-17 11:59:59','XZCBNB','4h','0.372000000000000','0.347000000000000','0.711908500000000','0.664065186827957','1.9137325268817207','1.913732526881721','test'),('2019-06-18 23:59:59','2019-06-20 23:59:59','XZCBNB','4h','0.365000000000000','0.356000000000000','0.711908500000000','0.694354591780822','1.9504342465753426','1.950434246575343','test'),('2019-06-29 23:59:59','2019-07-01 15:59:59','XZCBNB','4h','0.362000000000000','0.351000000000000','0.711908500000000','0.690275921270718','1.9665980662983427','1.966598066298343','test'),('2019-07-03 19:59:59','2019-07-04 11:59:59','XZCBNB','4h','0.353000000000000','0.336000000000000','0.711908500000000','0.677623954674221','2.0167379603399436','2.016737960339944','test'),('2019-07-04 15:59:59','2019-07-04 19:59:59','XZCBNB','4h','0.341000000000000','0.344000000000000','0.711908500000000','0.718171624633431','2.087708211143695','2.087708211143695','test'),('2019-07-06 15:59:59','2019-07-06 23:59:59','XZCBNB','4h','0.359000000000000','0.348000000000000','0.711908500000000','0.690095147632312','1.9830320334261842','1.983032033426184','test'),('2019-07-07 07:59:59','2019-07-07 11:59:59','XZCBNB','4h','0.350000000000000','0.346000000000000','0.711908500000000','0.703772402857143','2.034024285714286','2.034024285714286','test'),('2019-07-07 15:59:59','2019-07-07 19:59:59','XZCBNB','4h','0.347000000000000','0.355000000000000','0.711908500000000','0.728321376080692','2.0516095100864558','2.051609510086456','test'),('2019-07-07 23:59:59','2019-07-08 07:59:59','XZCBNB','4h','0.356000000000000','0.347000000000000','0.711908500000000','0.693910813202247','1.9997429775280902','1.999742977528090','test'),('2019-07-08 11:59:59','2019-07-08 15:59:59','XZCBNB','4h','0.352000000000000','0.349000000000000','0.711908500000000','0.705841098011364','2.0224673295454547','2.022467329545455','test'),('2019-07-08 19:59:59','2019-07-08 23:59:59','XZCBNB','4h','0.350000000000000','0.349000000000000','0.711908500000000','0.709874475714286','2.034024285714286','2.034024285714286','test'),('2019-07-09 07:59:59','2019-07-09 11:59:59','XZCBNB','4h','0.353000000000000','0.348000000000000','0.711908500000000','0.701824810198300','2.0167379603399436','2.016737960339944','test'),('2019-07-09 15:59:59','2019-07-09 23:59:59','XZCBNB','4h','0.360000000000000','0.349000000000000','0.711908500000000','0.690155740277778','1.9775236111111114','1.977523611111111','test'),('2019-07-10 03:59:59','2019-07-11 03:59:59','XZCBNB','4h','0.357000000000000','0.347000000000000','0.711908500000000','0.691967085434174','1.9941414565826332','1.994141456582633','test'),('2019-07-11 07:59:59','2019-07-11 11:59:59','XZCBNB','4h','0.354000000000000','0.344100000000000','0.711908500000000','0.691999194491525','2.0110409604519774','2.011040960451977','test'),('2019-07-11 15:59:59','2019-07-11 23:59:59','XZCBNB','4h','0.361000000000000','0.354800000000000','0.711908500000000','0.699681816620499','1.9720457063711914','1.972045706371191','test'),('2019-07-26 07:59:59','2019-07-27 11:59:59','XZCBNB','4h','0.333400000000000','0.330000000000000','0.711908500000000','0.704648485302940','2.135298440311938','2.135298440311938','test'),('2019-07-27 19:59:59','2019-07-27 23:59:59','XZCBNB','4h','0.327600000000000','0.326600000000000','0.711908500000000','0.709735397130647','2.1731028693528693','2.173102869352869','test'),('2019-07-29 03:59:59','2019-07-31 03:59:59','XZCBNB','4h','0.332700000000000','0.328600000000000','0.711908500000000','0.703135356477307','2.1397911030958823','2.139791103095882','test'),('2019-08-23 23:59:59','2019-08-26 07:59:59','XZCBNB','4h','0.262600000000000','0.252500000000000','0.711908500000000','0.684527403846154','2.710999619192689','2.710999619192689','test'),('2019-08-29 03:59:59','2019-08-30 11:59:59','XZCBNB','4h','0.266300000000000','0.260800000000000','0.711908500000000','0.697205170108900','2.6733327074727753','2.673332707472775','test'),('2019-08-31 19:59:59','2019-09-02 03:59:59','XZCBNB','4h','0.265100000000000','0.257300000000000','0.711908500000000','0.690962116371181','2.685433798566579','2.685433798566579','test'),('2019-09-10 19:59:59','2019-09-14 07:59:59','XZCBNB','4h','0.261000000000000','0.255700000000000','0.711908500000000','0.697452120498084','2.7276187739463604','2.727618773946360','test'),('2019-09-14 15:59:59','2019-09-15 03:59:59','XZCBNB','4h','0.260900000000000','0.257000000000000','0.711908500000000','0.701266709467229','2.7286642391720966','2.728664239172097','test'),('2019-09-15 07:59:59','2019-09-16 15:59:59','XZCBNB','4h','0.263600000000000','0.251900000000000','0.711908500000000','0.680310133345979','2.7007150986342947','2.700715098634295','test'),('2019-09-21 07:59:59','2019-09-23 11:59:59','XZCBNB','4h','0.261600000000000','0.258200000000000','0.711908500000000','0.702655866590214','2.721362767584098','2.721362767584098','test'),('2019-09-23 15:59:59','2019-09-24 23:59:59','XZCBNB','4h','0.265900000000000','0.285000000000000','0.711908500000000','0.763045966528770','2.677354268522001','2.677354268522001','test'),('2019-09-25 07:59:59','2019-10-08 03:59:59','XZCBNB','4h','0.285000000000000','0.355400000000000','0.711908500000000','0.887762389122807','2.4979245614035093','2.497924561403509','test'),('2019-11-20 15:59:59','2019-11-23 19:59:59','XZCBNB','4h','0.234100000000000','0.235400000000000','0.711908500000000','0.715861857753097','3.0410444254592055','3.041044425459206','test'),('2019-11-25 23:59:59','2019-11-26 07:59:59','XZCBNB','4h','0.240500000000000','0.236400000000000','0.711908500000000','0.699772014137214','2.9601185031185033','2.960118503118503','test'),('2019-11-26 11:59:59','2019-11-26 15:59:59','XZCBNB','4h','0.237600000000000','0.235200000000000','0.711908500000000','0.704717505050505','2.9962478956228957','2.996247895622896','test'),('2019-11-27 07:59:59','2019-11-27 15:59:59','XZCBNB','4h','0.239900000000000','0.237800000000000','0.711908500000000','0.705676704043351','2.967521884118383','2.967521884118383','test'),('2019-11-29 19:59:59','2019-11-29 23:59:59','XZCBNB','4h','0.236400000000000','0.236400000000000','0.711908500000000','0.711908500000000','3.0114572758037226','3.011457275803723','test'),('2019-11-30 03:59:59','2019-11-30 07:59:59','XZCBNB','4h','0.238500000000000','0.235200000000000','0.711908500000000','0.702058193710692','2.9849412997903566','2.984941299790357','test'),('2019-11-30 15:59:59','2019-11-30 19:59:59','XZCBNB','4h','0.237500000000000','0.240900000000000','0.711908500000000','0.722100032210526','2.997509473684211','2.997509473684211','test'),('2019-12-01 03:59:59','2019-12-01 07:59:59','XZCBNB','4h','0.238700000000000','0.237500000000000','0.711908500000000','0.708329571638039','2.9824403016338503','2.982440301633850','test'),('2019-12-01 11:59:59','2019-12-02 07:59:59','XZCBNB','4h','0.243400000000000','0.236800000000000','0.711908500000000','0.692604489728841','2.9248500410846345','2.924850041084635','test'),('2019-12-02 11:59:59','2019-12-02 15:59:59','XZCBNB','4h','0.238700000000000','0.238700000000000','0.711908500000000','0.711908500000000','2.9824403016338503','2.982440301633850','test'),('2019-12-02 23:59:59','2019-12-03 07:59:59','XZCBNB','4h','0.239900000000000','0.237500000000000','0.711908500000000','0.704786447478116','2.967521884118383','2.967521884118383','test'),('2019-12-16 19:59:59','2019-12-18 11:59:59','XZCBNB','4h','0.232400000000000','0.228600000000000','0.711908500000000','0.700267999569707','3.0632895869191055','3.063289586919105','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:19:23
