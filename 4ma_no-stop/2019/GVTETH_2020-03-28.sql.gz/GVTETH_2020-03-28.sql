-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 19:59:59','2019-01-14 03:59:59','GVTETH','4h','0.028627000000000','0.028064000000000','0.072144500000000','0.070725652286303','2.520155796974884','2.520155796974884','test'),('2019-01-14 07:59:59','2019-01-14 11:59:59','GVTETH','4h','0.028183000000000','0.028383000000000','0.072144500000000','0.072656471756023','2.5598587801156727','2.559858780115673','test'),('2019-01-16 19:59:59','2019-01-20 15:59:59','GVTETH','4h','0.028694000000000','0.029614000000000','0.072144500000000','0.074457629574127','2.514271276224995','2.514271276224995','test'),('2019-01-23 11:59:59','2019-01-26 11:59:59','GVTETH','4h','0.031775000000000','0.032615000000000','0.072496063404113','0.074412560438242','2.28154408824904','2.281544088249040','test'),('2019-01-29 15:59:59','2019-01-31 11:59:59','GVTETH','4h','0.033147000000000','0.032275000000000','0.072975187662645','0.071055425281681','2.2015623634912806','2.201562363491281','test'),('2019-01-31 15:59:59','2019-01-31 23:59:59','GVTETH','4h','0.032605000000000','0.032575000000000','0.072975187662645','0.072908042880253','2.2381594130545928','2.238159413054593','test'),('2019-02-07 23:59:59','2019-02-08 19:59:59','GVTETH','4h','0.032466000000000','0.032032000000000','0.072975187662645','0.071999667689578','2.2477418734258916','2.247741873425892','test'),('2019-02-10 15:59:59','2019-02-10 23:59:59','GVTETH','4h','0.032669000000000','0.031091000000000','0.072975187662645','0.069450291090003','2.233774760863357','2.233774760863357','test'),('2019-02-26 11:59:59','2019-03-01 03:59:59','GVTETH','4h','0.031275000000000','0.030029000000000','0.072975187662645','0.070067846852808','2.3333393337376505','2.333339333737650','test'),('2019-03-12 19:59:59','2019-03-16 03:59:59','GVTETH','4h','0.030686000000000','0.029309000000000','0.072975187662645','0.069700507567114','2.378126431031904','2.378126431031904','test'),('2019-03-27 03:59:59','2019-03-30 03:59:59','GVTETH','4h','0.030316000000000','0.029966000000000','0.072975187662645','0.072132684836351','2.4071509322682743','2.407150932268274','test'),('2019-03-31 23:59:59','2019-04-02 07:59:59','GVTETH','4h','0.030785000000000','0.030452000000000','0.072975187662645','0.072185818245992','2.37047872868751','2.370478728687510','test'),('2019-05-23 23:59:59','2019-05-24 15:59:59','GVTETH','4h','0.015360000000000','0.013402000000000','0.072975187662645','0.063672751631170','4.750988780120117','4.750988780120117','test'),('2019-05-24 19:59:59','2019-05-24 23:59:59','GVTETH','4h','0.013554000000000','0.013340000000000','0.072975187662645','0.071823004531480','5.384033323199425','5.384033323199425','test'),('2019-05-31 15:59:59','2019-06-01 03:59:59','GVTETH','4h','0.014737000000000','0.013212000000000','0.072975187662645','0.065423639777354','4.951834678879352','4.951834678879352','test'),('2019-06-01 11:59:59','2019-06-01 15:59:59','GVTETH','4h','0.013370000000000','0.013467000000000','0.072975187662645','0.073504626196921','5.458129219345176','5.458129219345176','test'),('2019-06-01 19:59:59','2019-06-01 23:59:59','GVTETH','4h','0.013715000000000','0.013582000000000','0.072975187662645','0.072267517231793','5.320830307156034','5.320830307156034','test'),('2019-06-02 03:59:59','2019-06-02 07:59:59','GVTETH','4h','0.013585000000000','0.013326000000000','0.072975187662645','0.071583905100656','5.371747343588149','5.371747343588149','test'),('2019-06-02 11:59:59','2019-06-03 07:59:59','GVTETH','4h','0.013600000000000','0.013452000000000','0.072975187662645','0.072181045914552','5.36582262225331','5.365822622253310','test'),('2019-06-03 11:59:59','2019-06-03 15:59:59','GVTETH','4h','0.013562000000000','0.013622000000000','0.072975187662645','0.073298039104892','5.380857370789339','5.380857370789339','test'),('2019-06-07 07:59:59','2019-06-11 19:59:59','GVTETH','4h','0.013785000000000','0.014655000000000','0.072975187662645','0.077580803423726','5.293811219633297','5.293811219633297','test'),('2019-07-21 19:59:59','2019-07-23 07:59:59','GVTETH','4h','0.009650000000000','0.009342000000000','0.072975187662645','0.070646031413931','7.562195612709327','7.562195612709327','test'),('2019-07-23 11:59:59','2019-07-23 19:59:59','GVTETH','4h','0.009498000000000','0.009456000000000','0.072975187662645','0.072652492581383','7.6832162205353765','7.683216220535376','test'),('2019-07-29 15:59:59','2019-07-30 11:59:59','GVTETH','4h','0.009710000000000','0.009366000000000','0.072975187662645','0.070389866905081','7.51546731850103','7.515467318501030','test'),('2019-07-30 19:59:59','2019-07-30 23:59:59','GVTETH','4h','0.009392000000000','0.009455000000000','0.072975187662645','0.073464693286873','7.769930543296956','7.769930543296956','test'),('2019-07-31 07:59:59','2019-07-31 15:59:59','GVTETH','4h','0.009493000000000','0.009139000000000','0.072975187662645','0.070253896560509','7.687263000383968','7.687263000383968','test'),('2019-08-22 23:59:59','2019-08-26 03:59:59','GVTETH','4h','0.007085000000000','0.006967000000000','0.072975187662645','0.071759792864594','10.299955915687368','10.299955915687368','test'),('2019-08-28 07:59:59','2019-08-28 19:59:59','GVTETH','4h','0.007469000000000','0.007297000000000','0.072975187662645','0.071294677249206','9.770409380458563','9.770409380458563','test'),('2019-08-29 15:59:59','2019-08-31 03:59:59','GVTETH','4h','0.007377000000000','0.007197000000000','0.072975187662645','0.071194581212967','9.892258053767792','9.892258053767792','test'),('2019-08-31 11:59:59','2019-08-31 19:59:59','GVTETH','4h','0.007324000000000','0.007199000000000','0.072975187662645','0.071729707261521','9.963843208990307','9.963843208990307','test'),('2019-09-01 07:59:59','2019-09-01 19:59:59','GVTETH','4h','0.007391000000000','0.007227000000000','0.072975187662645','0.071355930352853','9.873520181659451','9.873520181659451','test'),('2019-09-24 03:59:59','2019-09-24 19:59:59','GVTETH','4h','0.006071000000000','0.005474000000000','0.072975187662645','0.065799073837147','12.020291164988471','12.020291164988471','test'),('2019-09-24 23:59:59','2019-09-25 03:59:59','GVTETH','4h','0.005673000000000','0.005642000000000','0.072975187662645','0.072576416145363','12.863597331684295','12.863597331684295','test'),('2019-09-26 07:59:59','2019-09-26 15:59:59','GVTETH','4h','0.006030000000000','0.005901000000000','0.072975187662645','0.071414026931554','12.102021171251245','12.102021171251245','test'),('2019-09-26 19:59:59','2019-09-29 07:59:59','GVTETH','4h','0.006041000000000','0.005956000000000','0.072975187662645','0.071948388961879','12.079984714889092','12.079984714889092','test'),('2019-10-01 19:59:59','2019-10-02 03:59:59','GVTETH','4h','0.006085000000000','0.005901000000000','0.072975187662645','0.070768542711137','11.992635606022187','11.992635606022187','test'),('2019-10-02 07:59:59','2019-10-06 07:59:59','GVTETH','4h','0.006006000000000','0.006268000000000','0.072975187662645','0.076158587457452','12.15038089621129','12.150380896211290','test'),('2019-10-06 23:59:59','2019-10-09 15:59:59','GVTETH','4h','0.006514000000000','0.006517000000000','0.072975187662645','0.073008796131019','11.202822791317931','11.202822791317931','test'),('2019-10-09 19:59:59','2019-10-09 23:59:59','GVTETH','4h','0.006588000000000','0.006634000000000','0.072975187662645','0.073484729045839','11.076986591172588','11.076986591172588','test'),('2019-10-21 15:59:59','2019-10-23 23:59:59','GVTETH','4h','0.006966000000000','0.006731000000000','0.072975187662645','0.070513348859785','10.475909799403532','10.475909799403532','test'),('2019-11-10 23:59:59','2019-11-11 03:59:59','GVTETH','4h','0.006195000000000','0.006081000000000','0.072975187662645','0.071632302853357','11.779691309547216','11.779691309547216','test'),('2019-11-11 23:59:59','2019-11-12 03:59:59','GVTETH','4h','0.006182000000000','0.006126000000000','0.072975187662645','0.072314137758228','11.80446257888143','11.804462578881431','test'),('2019-11-12 07:59:59','2019-11-12 11:59:59','GVTETH','4h','0.006154000000000','0.006082000000000','0.072975187662645','0.072121399311701','11.858171540891291','11.858171540891291','test'),('2019-11-13 23:59:59','2019-11-15 11:59:59','GVTETH','4h','0.006218000000000','0.006275000000000','0.072975187662645','0.073644146443084','11.736118955073175','11.736118955073175','test'),('2019-11-15 19:59:59','2019-11-16 11:59:59','GVTETH','4h','0.006306000000000','0.006174000000000','0.072975187662645','0.071447638539355','11.572341843108944','11.572341843108944','test'),('2019-11-18 11:59:59','2019-11-18 15:59:59','GVTETH','4h','0.006309000000000','0.006444000000000','0.072975187662645','0.074536710936453','11.566839065247265','11.566839065247265','test'),('2019-11-18 19:59:59','2019-11-20 23:59:59','GVTETH','4h','0.006531000000000','0.006365000000000','0.072975187662645','0.071120359741653','11.173662174650897','11.173662174650897','test'),('2019-11-22 19:59:59','2019-11-28 03:59:59','GVTETH','4h','0.006564000000000','0.006993000000000','0.072975187662645','0.077744589781364','11.117487456222579','11.117487456222579','test'),('2019-11-29 07:59:59','2019-11-30 11:59:59','GVTETH','4h','0.007349000000000','0.007098000000000','0.072975187662645','0.070482770721112','9.92994797423391','9.929947974233910','test'),('2019-12-02 15:59:59','2019-12-04 15:59:59','GVTETH','4h','0.007939000000000','0.007112000000000','0.072975187662645','0.065373414114716','9.191987361461772','9.191987361461772','test'),('2019-12-06 11:59:59','2019-12-10 03:59:59','GVTETH','4h','0.007353000000000','0.007370000000000','0.072975187662645','0.073143904946783','9.924546125750714','9.924546125750714','test'),('2019-12-17 03:59:59','2019-12-17 19:59:59','GVTETH','4h','0.007617000000000','0.007559000000000','0.072975187662645','0.072419514709457','9.580568158414732','9.580568158414732','test'),('2019-12-17 23:59:59','2019-12-18 23:59:59','GVTETH','4h','0.007617000000000','0.007320000000000','0.072975187662645','0.070129758919596','9.580568158414732','9.580568158414732','test'),('2019-12-19 03:59:59','2019-12-19 07:59:59','GVTETH','4h','0.007485000000000','0.007477000000000','0.072975187662645','0.072897191470086','9.749524069825652','9.749524069825652','test'),('2019-12-19 11:59:59','2019-12-19 15:59:59','GVTETH','4h','0.007641000000000','0.007476000000000','0.072975187662645','0.071399359110841','9.550476071541029','9.550476071541029','test'),('2019-12-20 03:59:59','2019-12-22 07:59:59','GVTETH','4h','0.007693000000000','0.007526000000000','0.072975187662645','0.071391038911877','9.485920663284155','9.485920663284155','test'),('2019-12-25 15:59:59','2019-12-28 07:59:59','GVTETH','4h','0.007930000000000','0.007765000000000','0.072975187662645','0.071456788423763','9.202419629589535','9.202419629589535','test'),('2019-12-29 07:59:59','2019-12-29 11:59:59','GVTETH','4h','0.007930000000000','0.007779000000000','0.048650125108430','0.047723748199051','6.134946419726356','6.134946419726356','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 13:27:38
