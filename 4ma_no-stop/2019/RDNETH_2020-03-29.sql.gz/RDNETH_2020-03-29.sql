-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-12 07:59:59','2019-01-14 03:59:59','RDNETH','4h','0.001818900000000','0.001743700000000','0.072144500000000','0.069161781653747','39.66380779592061','39.663807795920611','test'),('2019-01-14 07:59:59','2019-01-14 15:59:59','RDNETH','4h','0.001759700000000','0.001708700000000','0.072144500000000','0.070053592743081','40.99818150821163','40.998181508211630','test'),('2019-01-16 03:59:59','2019-01-16 11:59:59','RDNETH','4h','0.001781800000000','0.001784100000000','0.072144500000000','0.072237626248737','40.48967336401392','40.489673364013917','test'),('2019-01-16 15:59:59','2019-01-18 11:59:59','RDNETH','4h','0.001808200000000','0.001804300000000','0.072144500000000','0.071988895780334','39.89851786306824','39.898517863068243','test'),('2019-01-18 15:59:59','2019-01-20 11:59:59','RDNETH','4h','0.001875600000000','0.001837000000000','0.072144500000000','0.070659760343357','38.46475794412454','38.464757944124543','test'),('2019-01-21 15:59:59','2019-01-22 07:59:59','RDNETH','4h','0.001906300000000','0.001838800000000','0.072144500000000','0.069589942086765','37.84530241829722','37.845302418297223','test'),('2019-01-22 23:59:59','2019-01-25 15:59:59','RDNETH','4h','0.001897500000000','0.001978700000000','0.072144500000000','0.075231790329381','38.02081686429512','38.020816864295121','test'),('2019-01-30 03:59:59','2019-01-30 15:59:59','RDNETH','4h','0.001982800000000','0.001971000000000','0.072144500000000','0.071715155083720','36.38516239661086','36.385162396610859','test'),('2019-01-30 19:59:59','2019-01-30 23:59:59','RDNETH','4h','0.001983200000000','0.001949200000000','0.072144500000000','0.070907653993546','36.377823719241626','36.377823719241626','test'),('2019-02-08 07:59:59','2019-02-08 15:59:59','RDNETH','4h','0.002060300000000','0.001894500000000','0.072144500000000','0.066338763893608','35.01650245109935','35.016502451099349','test'),('2019-02-17 07:59:59','2019-02-17 23:59:59','RDNETH','4h','0.001995900000000','0.001846400000000','0.072144500000000','0.066740620672378','36.146350017535944','36.146350017535944','test'),('2019-02-18 07:59:59','2019-02-18 11:59:59','RDNETH','4h','0.001807400000000','0.001782300000000','0.072144500000000','0.071142603933828','39.916177935155474','39.916177935155474','test'),('2019-02-24 23:59:59','2019-02-25 07:59:59','RDNETH','4h','0.001895400000000','0.001826600000000','0.072144500000000','0.069525769600084','38.06294185923816','38.062941859238158','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','RDNETH','4h','0.001839000000000','0.001833400000000','0.072144500000000','0.071924810386079','39.23028820010876','39.230288200108760','test'),('2019-02-25 23:59:59','2019-03-04 11:59:59','RDNETH','4h','0.001876200000000','0.002126900000000','0.072144500000000','0.081784530993498','38.45245709412643','38.452457094126430','test'),('2019-03-08 11:59:59','2019-03-10 11:59:59','RDNETH','4h','0.002223300000000','0.002190000000000','0.072144500000000','0.071063938739711','32.44928709575856','32.449287095758557','test'),('2019-03-11 19:59:59','2019-03-14 15:59:59','RDNETH','4h','0.002263500000000','0.002309400000000','0.072144500000000','0.073607469980119','31.872984316324278','31.872984316324278','test'),('2019-03-14 23:59:59','2019-03-16 03:59:59','RDNETH','4h','0.002332700000000','0.002289300000000','0.072144500000000','0.070802247974450','30.927466026492905','30.927466026492905','test'),('2019-03-16 11:59:59','2019-03-16 15:59:59','RDNETH','4h','0.002379400000000','0.002313200000000','0.072144500000000','0.070137285618223','30.32045893922838','30.320458939228381','test'),('2019-03-16 23:59:59','2019-03-21 15:59:59','RDNETH','4h','0.002382900000000','0.002451700000000','0.072144500000000','0.074227483591422','30.27592429392757','30.275924293927570','test'),('2019-03-21 19:59:59','2019-03-22 03:59:59','RDNETH','4h','0.002457300000000','0.002417500000000','0.072144500000000','0.070976001607455','29.35925609408701','29.359256094087009','test'),('2019-03-25 03:59:59','2019-03-29 11:59:59','RDNETH','4h','0.002468300000000','0.002536300000000','0.072144500000000','0.074132032309687','29.228416318923955','29.228416318923955','test'),('2019-03-30 19:59:59','2019-04-02 07:59:59','RDNETH','4h','0.002629700000000','0.002551600000000','0.072144500000000','0.070001865688101','27.43449823173746','27.434498231737461','test'),('2019-05-02 15:59:59','2019-05-03 07:59:59','RDNETH','4h','0.002099900000000','0.001837500000000','0.072144500000000','0.063129443663984','34.35615981713415','34.356159817134149','test'),('2019-05-30 23:59:59','2019-06-02 15:59:59','RDNETH','4h','0.001425200000000','0.001485100000000','0.072144500000000','0.075176674817569','50.62061465057536','50.620614650575362','test'),('2019-06-02 23:59:59','2019-06-03 03:59:59','RDNETH','4h','0.001509000000000','0.001474900000000','0.072144500000000','0.070514196852220','47.80947647448642','47.809476474486416','test'),('2019-06-08 11:59:59','2019-06-09 15:59:59','RDNETH','4h','0.001440600000000','0.001362000000000','0.072144500000000','0.068208252811329','50.0794807719006','50.079480771900599','test'),('2019-06-09 19:59:59','2019-06-09 23:59:59','RDNETH','4h','0.001374700000000','0.001342400000000','0.072144500000000','0.070449390266967','52.48017749327126','52.480177493271263','test'),('2019-06-11 03:59:59','2019-06-12 19:59:59','RDNETH','4h','0.001468300000000','0.001407900000000','0.072144500000000','0.069176763297691','49.134713614383976','49.134713614383976','test'),('2019-06-13 15:59:59','2019-06-13 19:59:59','RDNETH','4h','0.001442100000000','0.001365600000000','0.072144500000000','0.068317404618265','50.02739061091464','50.027390610914637','test'),('2019-06-18 19:59:59','2019-06-19 15:59:59','RDNETH','4h','0.001398400000000','0.001363700000000','0.072144500000000','0.070354301094108','51.590746567505725','51.590746567505725','test'),('2019-06-19 19:59:59','2019-06-19 23:59:59','RDNETH','4h','0.001375100000000','0.001339100000000','0.072144500000000','0.070255763180860','52.464911642789616','52.464911642789616','test'),('2019-07-15 23:59:59','2019-07-16 23:59:59','RDNETH','4h','0.001076500000000','0.001037100000000','0.072144500000000','0.069504004598235','67.01764979098932','67.017649790989324','test'),('2019-07-18 15:59:59','2019-07-23 23:59:59','RDNETH','4h','0.001063100000000','0.001193200000000','0.072144500000000','0.080973396105729','67.86238359514627','67.862383595146269','test'),('2019-07-24 23:59:59','2019-07-27 03:59:59','RDNETH','4h','0.001236400000000','0.001195300000000','0.072144500000000','0.069746296384665','58.350452927855066','58.350452927855066','test'),('2019-08-15 19:59:59','2019-08-17 07:59:59','RDNETH','4h','0.001018300000000','0.000981400000000','0.072144500000000','0.069530209466758','70.84798193066877','70.847981930668766','test'),('2019-08-17 11:59:59','2019-08-17 15:59:59','RDNETH','4h','0.000989100000000','0.000990000000000','0.072144500000000','0.072210145586897','72.93954099686584','72.939540996865844','test'),('2019-08-17 19:59:59','2019-08-17 23:59:59','RDNETH','4h','0.001003400000000','0.000985500000000','0.072144500000000','0.070857489286426','71.90003986446084','71.900039864460837','test'),('2019-08-23 23:59:59','2019-08-26 03:59:59','RDNETH','4h','0.001036500000000','0.001017400000000','0.072144500000000','0.070815064447660','69.60395561987457','69.603955619874569','test'),('2019-08-26 07:59:59','2019-08-26 15:59:59','RDNETH','4h','0.001036800000000','0.001028700000000','0.072144500000000','0.071580871093750','69.58381558641975','69.583815586419746','test'),('2019-08-26 19:59:59','2019-08-26 23:59:59','RDNETH','4h','0.001031800000000','0.001000100000000','0.072144500000000','0.069928003925179','69.92101182399689','69.921011823996892','test'),('2019-08-30 11:59:59','2019-08-31 23:59:59','RDNETH','4h','0.001040500000000','0.001015400000000','0.072144500000000','0.070404156943777','69.33637674195099','69.336376741950986','test'),('2019-09-01 07:59:59','2019-09-01 11:59:59','RDNETH','4h','0.001006300000000','0.001002500000000','0.072144500000000','0.071872067226473','71.69283513862666','71.692835138626663','test'),('2019-09-02 15:59:59','2019-09-03 03:59:59','RDNETH','4h','0.001031900000000','0.000992900000000','0.072144500000000','0.069417844800853','69.91423587556933','69.914235875569332','test'),('2019-09-26 19:59:59','2019-09-30 03:59:59','RDNETH','4h','0.000897800000000','0.000861700000000','0.072144500000000','0.069243612887057','80.35698373802629','80.356983738026287','test'),('2019-10-01 15:59:59','2019-10-06 23:59:59','RDNETH','4h','0.000900000000000','0.001112800000000','0.072144500000000','0.089202666222222','80.16055555555556','80.160555555555561','test'),('2019-10-07 11:59:59','2019-10-10 07:59:59','RDNETH','4h','0.001198300000000','0.001166700000000','0.072144500000000','0.070241999624468','60.205708086455815','60.205708086455815','test'),('2019-11-03 23:59:59','2019-11-04 19:59:59','RDNETH','4h','0.000894100000000','0.000877000000000','0.072144500000000','0.070764709204787','80.68952018789845','80.689520187898452','test'),('2019-11-04 23:59:59','2019-11-05 03:59:59','RDNETH','4h','0.000884400000000','0.000876200000000','0.072144500000000','0.071475588986884','81.57451379466305','81.574513794663048','test'),('2019-11-08 07:59:59','2019-11-08 11:59:59','RDNETH','4h','0.000875200000000','0.000858400000000','0.072144500000000','0.070759642138940','82.4320155393053','82.432015539305297','test'),('2019-11-14 19:59:59','2019-11-17 11:59:59','RDNETH','4h','0.000937600000000','0.000880900000000','0.072144500000000','0.067781666008959','76.94592576791808','76.945925767918084','test'),('2019-11-17 15:59:59','2019-11-18 11:59:59','RDNETH','4h','0.000899600000000','0.000872500000000','0.072144500000000','0.069971183025789','80.19619831036016','80.196198310360160','test'),('2019-11-27 07:59:59','2019-12-02 11:59:59','RDNETH','4h','0.000870600000000','0.000882600000000','0.072144500000000','0.073138910751206','82.8675626005054','82.867562600505394','test'),('2019-12-08 11:59:59','2019-12-10 03:59:59','RDNETH','4h','0.000909600000000','0.000869700000000','0.072144500000000','0.068979850098945','79.31453386103782','79.314533861037816','test'),('2019-12-16 11:59:59','2019-12-17 15:59:59','RDNETH','4h','0.000976200000000','0.000877400000000','0.072144500000000','0.064842843986888','73.90340094242983','73.903400942429826','test'),('2019-12-17 19:59:59','2019-12-18 15:59:59','RDNETH','4h','0.000878200000000','0.000877000000000','0.072144500000000','0.072045919494420','82.15042131632886','82.150421316328860','test'),('2019-12-19 11:59:59','2019-12-21 23:59:59','RDNETH','4h','0.000910300000000','0.000901400000000','0.072144500000000','0.071439143469186','79.25354278809185','79.253542788091849','test'),('2019-12-22 11:59:59','2019-12-22 19:59:59','RDNETH','4h','0.000916400000000','0.000890000000000','0.072144500000000','0.070066133784374','78.72599301615016','78.725993016150156','test'),('2019-12-24 11:59:59','2019-12-25 19:59:59','RDNETH','4h','0.000907900000000','0.000902100000000','0.072144500000000','0.071683614329772','79.46304659103426','79.463046591034256','test'),('2019-12-25 23:59:59','2019-12-26 03:59:59','RDNETH','4h','0.000905800000000','0.000899000000000','0.072144500000000','0.071602898542725','79.64727312872598','79.647273128725985','test'),('2019-12-27 23:59:59','2019-12-28 07:59:59','RDNETH','4h','0.000918900000000','0.000920700000000','0.072144500000000','0.072285821253673','78.51180759603875','78.511807596038750','test'),('2019-12-28 15:59:59','2019-12-28 19:59:59','RDNETH','4h','0.000900500000000','0.000898900000000','0.072144500000000','0.072016314325375','80.11604664075513','80.116046640755130','test'),('2020-01-01 11:59:59','2020-01-01 15:59:59','RDNETH','4h','0.000927000000000','0.000902300000000','0.072144500000000','0.070222203182309','77.82578209277239','77.825782092772386','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 20:29:43
