-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 15:59:59','2019-01-04 11:59:59','QLCBTC','4h','0.000006810000000','0.000006790000000','0.001467500000000','0.001463190161527','215.49192364170338','215.491923641703380','test'),('2019-01-04 15:59:59','2019-01-08 19:59:59','QLCBTC','4h','0.000006820000000','0.000007200000000','0.001467500000000','0.001549266862170','215.1759530791789','215.175953079178896','test'),('2019-01-09 11:59:59','2019-01-10 07:59:59','QLCBTC','4h','0.000007510000000','0.000007220000000','0.001486864255924','0.001429448725402','197.98458800589214','197.984588005892135','test'),('2019-01-14 23:59:59','2019-01-15 23:59:59','QLCBTC','4h','0.000008960000000','0.000007280000000','0.001486864255924','0.001208077207938','165.94467142008926','165.944671420089264','test'),('2019-01-21 19:59:59','2019-01-21 23:59:59','QLCBTC','4h','0.000007400000000','0.000007290000000','0.001486864255924','0.001464762219687','200.92760215189188','200.927602151891875','test'),('2019-01-22 07:59:59','2019-01-22 11:59:59','QLCBTC','4h','0.000007220000000','0.000007140000000','0.001486864255924','0.001470389305720','205.93687755180054','205.936877551800535','test'),('2019-01-22 15:59:59','2019-01-22 19:59:59','QLCBTC','4h','0.000007210000000','0.000007230000000','0.001486864255924','0.001490988706010','206.222504289043','206.222504289043002','test'),('2019-01-23 03:59:59','2019-01-23 15:59:59','QLCBTC','4h','0.000007210000000','0.000007230000000','0.001486864255924','0.001490988706010','206.222504289043','206.222504289043002','test'),('2019-02-15 19:59:59','2019-02-15 23:59:59','QLCBTC','4h','0.000006380000000','0.000006310000000','0.001486864255924','0.001470550698257','233.0508238125392','233.050823812539193','test'),('2019-02-17 15:59:59','2019-02-18 19:59:59','QLCBTC','4h','0.000006510000000','0.000006440000000','0.001486864255924','0.001470876468226','228.39696711582178','228.396967115821781','test'),('2019-02-20 07:59:59','2019-02-21 11:59:59','QLCBTC','4h','0.000006500000000','0.000006400000000','0.001486864255924','0.001463989421217','228.74834706523077','228.748347065230774','test'),('2019-02-22 11:59:59','2019-02-24 15:59:59','QLCBTC','4h','0.000006580000000','0.000006410000000','0.001486864255924','0.001448449829859','225.96721214650455','225.967212146504551','test'),('2019-02-26 15:59:59','2019-02-27 23:59:59','QLCBTC','4h','0.000006780000000','0.000006600000000','0.001486864255924','0.001447389983643','219.3015126731563','219.301512673156310','test'),('2019-02-28 03:59:59','2019-02-28 11:59:59','QLCBTC','4h','0.000006650000000','0.000006700000000','0.001486864255924','0.001498043686420','223.58860991338346','223.588609913383465','test'),('2019-02-28 15:59:59','2019-03-08 15:59:59','QLCBTC','4h','0.000006950000000','0.000008030000000','0.001486864255924','0.001717916543175','213.93730301064747','213.937303010647469','test'),('2019-03-10 03:59:59','2019-03-11 07:59:59','QLCBTC','4h','0.000008240000000','0.000008110000000','0.001486864255924','0.001463406446061','180.4446912529126','180.444691252912605','test'),('2019-03-11 15:59:59','2019-03-12 01:59:59','QLCBTC','4h','0.000008370000000','0.000008150000000','0.001486864255924','0.001447782997106','177.6420855345281','177.642085534528093','test'),('2019-03-12 11:59:59','2019-03-14 03:59:59','QLCBTC','4h','0.000008430000000','0.000008380000000','0.001486864255924','0.001478045369471','176.37772905385526','176.377729053855262','test'),('2019-03-14 11:59:59','2019-03-17 15:59:59','QLCBTC','4h','0.000008780000000','0.000008740000000','0.001486864255924','0.001480090386877','169.34672618724372','169.346726187243718','test'),('2019-03-20 15:59:59','2019-03-24 07:59:59','QLCBTC','4h','0.000009480000000','0.000009020000000','0.001486864255924','0.001414716834223','156.84222108902952','156.842221089029522','test'),('2019-03-26 03:59:59','2019-03-31 11:59:59','QLCBTC','4h','0.000010500000000','0.000011030000000','0.001486864255924','0.001561915499318','141.60611961180953','141.606119611809532','test'),('2019-03-31 15:59:59','2019-03-31 19:59:59','QLCBTC','4h','0.000011760000000','0.000010960000000','0.001486864255924','0.001385717027630','126.43403536768707','126.434035367687073','test'),('2019-05-20 23:59:59','2019-05-25 11:59:59','QLCBTC','4h','0.000004930000000','0.000005510000000','0.001486864255924','0.001661789462503','301.5951837574036','301.595183757403618','test'),('2019-06-04 23:59:59','2019-06-07 11:59:59','QLCBTC','4h','0.000005060000000','0.000005040000000','0.001486864255924','0.001480987322106','293.8466908940711','293.846690894071116','test'),('2019-06-07 15:59:59','2019-06-07 19:59:59','QLCBTC','4h','0.000005050000000','0.000005020000000','0.001486864255924','0.001478031398958','294.42856552950497','294.428565529504965','test'),('2019-06-11 03:59:59','2019-06-12 15:59:59','QLCBTC','4h','0.000005220000000','0.000005030000000','0.001486864255924','0.001432744675728','284.83989577088124','284.839895770881242','test'),('2019-07-26 19:59:59','2019-07-29 03:59:59','QLCBTC','4h','0.000002280000000','0.000002270000000','0.001486864255924','0.001480342921468','652.1334455807016','652.133445580701618','test'),('2019-08-22 03:59:59','2019-08-28 07:59:59','QLCBTC','4h','0.000001400000000','0.000001590000000','0.001486864255924','0.001688652976371','1062.0458970885713','1062.045897088571337','test'),('2019-08-31 03:59:59','2019-08-31 15:59:59','QLCBTC','4h','0.000001590000000','0.000001550000000','0.001486864255924','0.001449458865838','935.1347521534591','935.134752153459090','test'),('2019-08-31 19:59:59','2019-09-01 03:59:59','QLCBTC','4h','0.000001560000000','0.000001520000000','0.001486864255924','0.001448739531413','953.1181127717948','953.118112771794813','test'),('2019-09-10 23:59:59','2019-09-11 19:59:59','QLCBTC','4h','0.000001510000000','0.000001390000000','0.001486864255924','0.001368702858102','984.6783151814569','984.678315181456924','test'),('2019-09-15 07:59:59','2019-09-20 19:59:59','QLCBTC','4h','0.000001430000000','0.000001750000000','0.001486864255924','0.001819589124383','1039.765213932867','1039.765213932867027','test'),('2019-09-27 19:59:59','2019-09-29 07:59:59','QLCBTC','4h','0.000001820000000','0.000001750000000','0.001488528636274','0.001431277534879','817.8728770737639','817.872877073763902','test'),('2019-09-29 15:59:59','2019-09-30 03:59:59','QLCBTC','4h','0.000001760000000','0.000001730000000','0.001488528636274','0.001463155989065','845.7549069738636','845.754906973863626','test'),('2019-10-01 15:59:59','2019-10-06 07:59:59','QLCBTC','4h','0.000001810000000','0.000002010000000','0.001488528636274','0.001653006938625','822.3915117535912','822.391511753591203','test'),('2019-10-06 15:59:59','2019-10-09 15:59:59','QLCBTC','4h','0.000002230000000','0.000002070000000','0.001508992274711','0.001400723770696','676.678150094619','676.678150094619014','test'),('2019-10-10 03:59:59','2019-10-10 07:59:59','QLCBTC','4h','0.000002280000000','0.000002110000000','0.001508992274711','0.001396479692825','661.8387169785087','661.838716978508728','test'),('2019-10-10 15:59:59','2019-10-11 07:59:59','QLCBTC','4h','0.000002300000000','0.000002240000000','0.001508992274711','0.001469627258849','656.0835977004348','656.083597700434780','test'),('2019-10-19 19:59:59','2019-10-20 19:59:59','QLCBTC','4h','0.000002440000000','0.000002120000000','0.001508992274711','0.001311091648519','618.4394568487705','618.439456848770533','test'),('2019-10-20 23:59:59','2019-10-21 11:59:59','QLCBTC','4h','0.000002170000000','0.000002150000000','0.001508992274711','0.001495084511810','695.3881450281107','695.388145028110671','test'),('2019-10-21 19:59:59','2019-10-23 15:59:59','QLCBTC','4h','0.000002240000000','0.000002200000000','0.001508992274711','0.001482045984091','673.6572654959821','673.657265495982074','test'),('2019-11-16 15:59:59','2019-11-18 23:59:59','QLCBTC','4h','0.000001970000000','0.000001970000000','0.001508992274711','0.001508992274711','765.9859262492386','765.985926249238560','test'),('2019-11-26 11:59:59','2019-11-27 11:59:59','QLCBTC','4h','0.000001970000000','0.000001930000000','0.001508992274711','0.001478352837661','765.9859262492386','765.985926249238560','test'),('2019-11-29 11:59:59','2019-11-29 15:59:59','QLCBTC','4h','0.000001930000000','0.000001880000000','0.001508992274711','0.001469899210599','781.8612822336787','781.861282233678708','test'),('2019-12-01 15:59:59','2019-12-01 19:59:59','QLCBTC','4h','0.000001930000000','0.000001950000000','0.001508992274711','0.001524629500356','781.8612822336787','781.861282233678708','test'),('2019-12-02 07:59:59','2019-12-02 11:59:59','QLCBTC','4h','0.000001920000000','0.000001900000000','0.001508992274711','0.001493273605183','785.9334764119793','785.933476411979314','test'),('2019-12-06 23:59:59','2019-12-10 03:59:59','QLCBTC','4h','0.000001960000000','0.000001960000000','0.001508992274711','0.001508992274711','769.8940177096939','769.894017709693912','test'),('2019-12-15 03:59:59','2019-12-15 15:59:59','QLCBTC','4h','0.000002080000000','0.000001940000000','0.001508992274711','0.001407425486990','725.4770551495193','725.477055149519288','test'),('2020-01-01 07:59:59','2020-01-01 15:59:59','QLCBTC','4h','0.000001650000000','0.000001640000000','0.001508992274711','0.001499846866985','914.5407725521212','914.540772552121211','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  4:33:24
