-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-12 23:59:59','2019-01-22 03:59:59','POWRETH','4h','0.000575050000000','0.000890090000000','0.072144500000000','0.111668720989479','125.45778627945396','125.457786279453956','test'),('2019-02-17 15:59:59','2019-02-18 03:59:59','POWRETH','4h','0.000736430000000','0.000683070000000','0.082025555247370','0.076082174847332','111.38269115512641','111.382691155126409','test'),('2019-02-18 07:59:59','2019-02-18 11:59:59','POWRETH','4h','0.000688810000000','0.000704410000000','0.082025555247370','0.083883249911877','119.08299131454247','119.082991314542468','test'),('2019-02-27 23:59:59','2019-02-28 11:59:59','POWRETH','4h','0.000687230000000','0.000660700000000','0.082025555247370','0.078859020054330','119.3567732016501','119.356773201650100','test'),('2019-02-28 15:59:59','2019-03-04 07:59:59','POWRETH','4h','0.000663100000000','0.000702000000000','0.082025555247370','0.086837490248309','123.70012855884481','123.700128558844810','test'),('2019-03-04 19:59:59','2019-03-05 03:59:59','POWRETH','4h','0.000725450000000','0.000713120000000','0.082025555247370','0.080631420439733','113.06851643444759','113.068516434447588','test'),('2019-03-08 03:59:59','2019-03-08 07:59:59','POWRETH','4h','0.000711420000000','0.000704740000000','0.082025555247370','0.081255362240352','115.2983543439459','115.298354343945903','test'),('2019-03-08 15:59:59','2019-03-15 15:59:59','POWRETH','4h','0.000711860000000','0.000796970000000','0.082025555247370','0.091832532752924','115.22708853899643','115.227088538996426','test'),('2019-03-20 19:59:59','2019-03-21 03:59:59','POWRETH','4h','0.000786430000000','0.000772560000000','0.083326146188186','0.081856551122344','105.95494346373677','105.954943463736768','test'),('2019-03-21 07:59:59','2019-03-21 15:59:59','POWRETH','4h','0.000773640000000','0.000759980000000','0.083326146188186','0.081854873817406','107.70661572331575','107.706615723315750','test'),('2019-03-23 07:59:59','2019-03-23 15:59:59','POWRETH','4h','0.000775080000000','0.000769900000000','0.083326146188186','0.082769262463597','107.50651053850699','107.506510538506987','test'),('2019-03-23 23:59:59','2019-03-24 03:59:59','POWRETH','4h','0.000772770000000','0.000771030000000','0.083326146188186','0.083138525687432','107.82787399638444','107.827873996384440','test'),('2019-03-24 07:59:59','2019-03-26 11:59:59','POWRETH','4h','0.000780040000000','0.000795450000000','0.083326146188186','0.084972287299873','106.82291445077945','106.822914450779450','test'),('2019-03-26 23:59:59','2019-03-27 11:59:59','POWRETH','4h','0.000820000000000','0.000817010000000','0.083326146188186','0.083022310606353','101.61725144900731','101.617251449007313','test'),('2019-03-27 15:59:59','2019-03-30 07:59:59','POWRETH','4h','0.000825920000000','0.000836890000000','0.083326146188186','0.084432897233910','100.88888292835384','100.888882928353837','test'),('2019-03-31 23:59:59','2019-04-02 07:59:59','POWRETH','4h','0.000869760000000','0.000843810000000','0.083326146188186','0.080840042557778','95.80360810819766','95.803608108197665','test'),('2019-04-21 19:59:59','2019-04-23 03:59:59','POWRETH','4h','0.000758560000000','0.000720500000000','0.083326146188186','0.079145338969347','109.84779870832367','109.847798708323666','test'),('2019-04-23 23:59:59','2019-04-24 07:59:59','POWRETH','4h','0.000741660000000','0.000725710000000','0.083326146188186','0.081534149812891','112.35086992447482','112.350869924474821','test'),('2019-05-26 03:59:59','2019-05-26 11:59:59','POWRETH','4h','0.000514970000000','0.000496500000000','0.083326146188186','0.080337556716769','161.80776780819465','161.807767808194654','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','POWRETH','4h','0.000500150000000','0.000479870000000','0.083326146188186','0.079947451307257','166.60231168286714','166.602311682867139','test'),('2019-06-08 03:59:59','2019-06-10 19:59:59','POWRETH','4h','0.000493690000000','0.000494000000000','0.083326146188186','0.083378468709036','168.78232532193482','168.782325321934820','test'),('2019-07-04 23:59:59','2019-07-05 07:59:59','POWRETH','4h','0.000376130000000','0.000366160000000','0.083326146188186','0.081117437291006','221.53549620659345','221.535496206593450','test'),('2019-07-06 19:59:59','2019-07-07 15:59:59','POWRETH','4h','0.000374230000000','0.000366920000000','0.083326146188186','0.081698499744460','222.66025221972046','222.660252219720462','test'),('2019-07-19 15:59:59','2019-07-24 19:59:59','POWRETH','4h','0.000349280000000','0.000360370000000','0.083326146188186','0.085971837213229','238.56546664047755','238.565466640477553','test'),('2019-07-26 07:59:59','2019-07-27 03:59:59','POWRETH','4h','0.000374680000000','0.000361770000000','0.083326146188186','0.080455054730704','222.39283171822888','222.392831718228877','test'),('2019-07-27 07:59:59','2019-07-28 23:59:59','POWRETH','4h','0.000362150000000','0.000360650000000','0.083326146188186','0.082981015111885','230.08738420043076','230.087384200430762','test'),('2019-08-22 19:59:59','2019-08-26 03:59:59','POWRETH','4h','0.000305000000000','0.000307500000000','0.083326146188186','0.084009147386450','273.2004793055279','273.200479305527892','test'),('2019-08-31 07:59:59','2019-08-31 23:59:59','POWRETH','4h','0.000316890000000','0.000311710000000','0.083326146188186','0.081964066484646','262.9497497181546','262.949749718154578','test'),('2019-09-01 07:59:59','2019-09-02 19:59:59','POWRETH','4h','0.000317500000000','0.000311250000000','0.083326146188186','0.081685867719915','262.44455492342047','262.444554923420469','test'),('2019-09-13 19:59:59','2019-09-13 23:59:59','POWRETH','4h','0.000311250000000','0.000300820000000','0.083326146188186','0.080533883682988','267.71452590581845','267.714525905818448','test'),('2019-09-14 03:59:59','2019-09-14 07:59:59','POWRETH','4h','0.000305360000000','0.000304680000000','0.083326146188186','0.083140588880719','272.87839333306914','272.878393333069141','test'),('2019-09-25 11:59:59','2019-09-26 19:59:59','POWRETH','4h','0.000298570000000','0.000281250000000','0.083326146188186','0.078492409201954','279.08412160694644','279.084121606946439','test'),('2019-09-26 23:59:59','2019-09-27 03:59:59','POWRETH','4h','0.000281380000000','0.000279410000000','0.083326146188186','0.082742762479355','296.1338623505082','296.133862350508196','test'),('2019-09-27 11:59:59','2019-09-27 15:59:59','POWRETH','4h','0.000284500000000','0.000277440000000','0.083326146188186','0.081258369063094','292.8862783416028','292.886278341602804','test'),('2019-10-05 19:59:59','2019-10-06 07:59:59','POWRETH','4h','0.000269920000000','0.000269870000000','0.083326146188186','0.083310710846939','308.70682494141226','308.706824941412265','test'),('2019-10-06 15:59:59','2019-10-07 03:59:59','POWRETH','4h','0.000271250000000','0.000270640000000','0.083326146188186','0.083138758357127','307.1931656707318','307.193165670731787','test'),('2019-10-07 07:59:59','2019-10-07 11:59:59','POWRETH','4h','0.000270730000000','0.000270950000000','0.083326146188186','0.083393858492553','307.7832016702471','307.783201670247081','test'),('2019-10-08 15:59:59','2019-10-09 15:59:59','POWRETH','4h','0.000274320000000','0.000260670000000','0.083326146188186','0.079179886726722','303.75527190210704','303.755271902107040','test'),('2019-10-22 19:59:59','2019-10-23 15:59:59','POWRETH','4h','0.000272050000000','0.000262160000000','0.083326146188186','0.080296939844495','306.28982241568093','306.289822415680931','test'),('2019-10-31 23:59:59','2019-11-04 15:59:59','POWRETH','4h','0.000265900000000','0.000263660000000','0.083326146188186','0.082624188431655','313.3739984512448','313.373998451244802','test'),('2019-11-04 19:59:59','2019-11-04 23:59:59','POWRETH','4h','0.000271360000000','0.000270000000000','0.083326146188186','0.082908532837597','307.0686401392467','307.068640139246725','test'),('2019-11-15 19:59:59','2019-11-16 19:59:59','POWRETH','4h','0.000259080000000','0.000253800000000','0.083326146188186','0.081627975538681','321.6232290728192','321.623229072819186','test'),('2019-11-17 03:59:59','2019-11-17 23:59:59','POWRETH','4h','0.000259090000000','0.000253270000000','0.083326146188186','0.081454371241969','321.6108155011231','321.610815501123113','test'),('2019-11-23 19:59:59','2019-11-25 11:59:59','POWRETH','4h','0.000257890000000','0.000252720000000','0.083326146188186','0.081655681355145','323.10731780288495','323.107317802884950','test'),('2019-11-25 15:59:59','2019-11-25 19:59:59','POWRETH','4h','0.000255000000000','0.000263160000000','0.083326146188186','0.085992582866208','326.7692007379843','326.769200737984306','test'),('2019-11-26 07:59:59','2019-11-30 03:59:59','POWRETH','4h','0.000259090000000','0.000267930000000','0.083326146188186','0.086169185797216','321.6108155011231','321.610815501123113','test'),('2019-12-02 07:59:59','2019-12-04 03:59:59','POWRETH','4h','0.000290450000000','0.000270920000000','0.083326146188186','0.077723255380628','286.8863700746635','286.886370074663489','test'),('2019-12-08 07:59:59','2019-12-08 11:59:59','POWRETH','4h','0.000269410000000','0.000272250000000','0.083326146188186','0.084204533238312','309.291214833102','309.291214833102003','test'),('2019-12-09 07:59:59','2019-12-09 23:59:59','POWRETH','4h','0.000287970000000','0.000268630000000','0.083326146188186','0.077729981076266','289.3570378448658','289.357037844865772','test'),('2019-12-12 07:59:59','2019-12-12 11:59:59','POWRETH','4h','0.000272550000000','0.000270000000000','0.083326146188186','0.082546539977289','305.7279258418125','305.727925841812521','test'),('2019-12-12 15:59:59','2019-12-17 15:59:59','POWRETH','4h','0.000281570000000','0.000286360000000','0.083326146188186','0.084743670215040','295.934034833917','295.934034833916996','test'),('2019-12-17 19:59:59','2019-12-18 15:59:59','POWRETH','4h','0.000293180000000','0.000287590000000','0.083326146188186','0.081737384481412','284.21497437815','284.214974378149975','test'),('2019-12-19 23:59:59','2019-12-21 15:59:59','POWRETH','4h','0.000294540000000','0.000290220000000','0.083326146188186','0.082104006745214','282.90264883610377','282.902648836103765','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:47:44
