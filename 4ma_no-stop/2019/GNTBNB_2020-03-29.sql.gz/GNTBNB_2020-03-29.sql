-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-02-18 11:59:59','2019-02-19 15:59:59','GNTBNB','4h','0.007430000000000','0.006460000000000','0.711908500000000','0.618967551816958','95.81541049798116','95.815410497981162','test'),('2019-02-27 03:59:59','2019-02-27 19:59:59','GNTBNB','4h','0.007000000000000','0.006650000000000','0.711908500000000','0.676313075000000','101.70121428571429','101.701214285714286','test'),('2019-03-20 15:59:59','2019-03-22 23:59:59','GNTBNB','4h','0.005590000000000','0.005130000000000','0.711908500000000','0.653325689624329','127.35393559928444','127.353935599284441','test'),('2019-03-28 19:59:59','2019-03-29 03:59:59','GNTBNB','4h','0.005330000000000','0.005200000000000','0.711908500000000','0.694544878048781','133.56632270168856','133.566322701688563','test'),('2019-03-29 07:59:59','2019-03-31 03:59:59','GNTBNB','4h','0.005250000000000','0.005120000000000','0.711908500000000','0.694280289523810','135.60161904761904','135.601619047619039','test'),('2019-04-03 19:59:59','2019-04-03 23:59:59','GNTBNB','4h','0.005430000000000','0.005220000000000','0.711908500000000','0.684376127071823','131.10653775322285','131.106537753222852','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','GNTBNB','4h','0.005240000000000','0.004870000000000','0.711908500000000','0.661640151717557','135.8604007633588','135.860400763358797','test'),('2019-04-05 19:59:59','2019-04-06 15:59:59','GNTBNB','4h','0.005200000000000','0.005210000000000','0.711908500000000','0.713277554807692','136.9054807692308','136.905480769230792','test'),('2019-04-06 19:59:59','2019-04-06 23:59:59','GNTBNB','4h','0.005250000000000','0.005170000000000','0.711908500000000','0.701060370476191','135.60161904761904','135.601619047619039','test'),('2019-04-07 03:59:59','2019-04-07 07:59:59','GNTBNB','4h','0.005210000000000','0.005250000000000','0.711908500000000','0.717374208253359','136.64270633397314','136.642706333973138','test'),('2019-04-07 15:59:59','2019-04-08 15:59:59','GNTBNB','4h','0.005240000000000','0.005370000000000','0.711908500000000','0.729570352099237','135.8604007633588','135.860400763358797','test'),('2019-04-08 19:59:59','2019-04-09 11:59:59','GNTBNB','4h','0.005440000000000','0.005160000000000','0.711908500000000','0.675266150735294','130.86553308823528','130.865533088235281','test'),('2019-04-10 15:59:59','2019-04-10 23:59:59','GNTBNB','4h','0.005420000000000','0.005200000000000','0.711908500000000','0.683011845018450','131.34843173431736','131.348431734317359','test'),('2019-05-08 11:59:59','2019-05-09 11:59:59','GNTBNB','4h','0.003500000000000','0.003390000000000','0.711908500000000','0.689534232857143','203.40242857142857','203.402428571428572','test'),('2019-05-09 15:59:59','2019-05-11 15:59:59','GNTBNB','4h','0.003470000000000','0.003470000000000','0.711908500000000','0.711908500000000','205.16095100864555','205.160951008645554','test'),('2019-05-11 23:59:59','2019-05-12 11:59:59','GNTBNB','4h','0.003570000000000','0.003440000000000','0.711908500000000','0.685984661064426','199.41414565826332','199.414145658263323','test'),('2019-05-16 15:59:59','2019-05-17 03:59:59','GNTBNB','4h','0.003820000000000','0.003470000000000','0.711908500000000','0.646681281413613','186.36348167539268','186.363481675392677','test'),('2019-05-29 15:59:59','2019-05-30 03:59:59','GNTBNB','4h','0.003180000000000','0.003040000000000','0.711908500000000','0.680566616352201','223.87059748427674','223.870597484276743','test'),('2019-05-30 07:59:59','2019-05-30 19:59:59','GNTBNB','4h','0.003060000000000','0.003050000000000','0.711908500000000','0.709582001633987','232.64983660130721','232.649836601307214','test'),('2019-06-08 23:59:59','2019-06-09 15:59:59','GNTBNB','4h','0.003040000000000','0.002950000000000','0.711908500000000','0.690832261513158','234.18042763157897','234.180427631578965','test'),('2019-06-10 03:59:59','2019-06-10 07:59:59','GNTBNB','4h','0.002960000000000','0.002950000000000','0.711908500000000','0.709503403716216','240.5096283783784','240.509628378378409','test'),('2019-06-10 23:59:59','2019-06-12 03:59:59','GNTBNB','4h','0.003000000000000','0.002980000000000','0.711908500000000','0.707162443333333','237.30283333333335','237.302833333333353','test'),('2019-06-14 11:59:59','2019-06-15 07:59:59','GNTBNB','4h','0.003130000000000','0.002990000000000','0.711908500000000','0.680065947284345','227.4468051118211','227.446805111821106','test'),('2019-06-15 23:59:59','2019-06-16 07:59:59','GNTBNB','4h','0.003040000000000','0.003050000000000','0.711908500000000','0.714250304276316','234.18042763157897','234.180427631578965','test'),('2019-06-16 11:59:59','2019-06-17 07:59:59','GNTBNB','4h','0.003060000000000','0.002930000000000','0.711908500000000','0.681664021241830','232.64983660130721','232.649836601307214','test'),('2019-06-29 15:59:59','2019-07-01 15:59:59','GNTBNB','4h','0.002920000000000','0.002840000000000','0.711908500000000','0.692404157534247','243.80428082191784','243.804280821917843','test'),('2019-07-02 19:59:59','2019-07-03 07:59:59','GNTBNB','4h','0.002920000000000','0.002760000000000','0.711908500000000','0.672899815068493','243.80428082191784','243.804280821917843','test'),('2019-07-03 15:59:59','2019-07-04 11:59:59','GNTBNB','4h','0.002910000000000','0.002760000000000','0.711908500000000','0.675212185567010','244.64209621993132','244.642096219931318','test'),('2019-07-06 11:59:59','2019-07-07 11:59:59','GNTBNB','4h','0.002940000000000','0.002800000000000','0.711908500000000','0.678008095238095','242.14574829931976','242.145748299319763','test'),('2019-07-07 19:59:59','2019-07-08 03:59:59','GNTBNB','4h','0.002850000000000','0.002820000000000','0.474605666666667','0.469609817543860','166.52830409356727','166.528304093567272','test'),('2019-07-28 15:59:59','2019-08-01 11:59:59','GNTBNB','4h','0.002270000000000','0.002301000000000','0.531639955791271','0.538900237125865','234.20262369659537','234.202623696595367','test'),('2019-08-22 23:59:59','2019-09-02 03:59:59','GNTBNB','4h','0.001929000000000','0.002693000000000','0.533455026124920','0.744735295673618','276.54485543023327','276.544855430233270','test'),('2019-09-04 15:59:59','2019-09-05 19:59:59','GNTBNB','4h','0.002774000000000','0.002512000000000','0.586275093512094','0.530902319719675','211.3464648565589','211.346464856558896','test'),('2019-09-09 07:59:59','2019-09-17 15:59:59','GNTBNB','4h','0.002718000000000','0.002862000000000','0.586275093512094','0.617336025618695','215.70091740695142','215.700917406951419','test'),('2019-09-21 11:59:59','2019-09-24 15:59:59','GNTBNB','4h','0.002982000000000','0.002941000000000','0.586275093512094','0.578214302487950','196.6046591254507','196.604659125450695','test'),('2019-09-27 07:59:59','2019-09-29 11:59:59','GNTBNB','4h','0.003032000000000','0.003026000000000','0.586275093512094','0.585114918524933','193.3624978601893','193.362497860189308','test'),('2019-09-29 23:59:59','2019-09-30 15:59:59','GNTBNB','4h','0.003021000000000','0.002965000000000','0.586275093512094','0.575407365860099','194.0665652141986','194.066565214198590','test'),('2019-10-04 19:59:59','2019-10-04 23:59:59','GNTBNB','4h','0.003083000000000','0.002960000000000','0.586275093512094','0.562884942197794','190.163831823579','190.163831823578988','test'),('2019-10-05 03:59:59','2019-10-09 07:59:59','GNTBNB','4h','0.002995000000000','0.003098000000000','0.586275093512094','0.606437475692977','195.75128330954723','195.751283309547233','test'),('2019-11-09 15:59:59','2019-11-10 19:59:59','GNTBNB','4h','0.002485000000000','0.002334000000000','0.586275093512094','0.550650329278562','235.92559095054085','235.925590950540851','test'),('2019-11-18 11:59:59','2019-11-18 15:59:59','GNTBNB','4h','0.002285000000000','0.002229000000000','0.586275093512094','0.571906863649216','256.5755332656866','256.575533265686602','test'),('2019-11-18 19:59:59','2019-11-19 07:59:59','GNTBNB','4h','0.002251000000000','0.002230000000000','0.586275093512094','0.580805623514869','260.45095224882004','260.450952248820045','test'),('2019-11-19 11:59:59','2019-11-23 19:59:59','GNTBNB','4h','0.002313000000000','0.002350000000000','0.586275093512094','0.595653467251803','253.4695605326822','253.469560532682209','test'),('2019-11-26 23:59:59','2019-11-27 19:59:59','GNTBNB','4h','0.002396000000000','0.002356000000000','0.586275093512094','0.576487529346617','244.68910413693402','244.689104136934020','test'),('2019-11-28 03:59:59','2019-11-30 15:59:59','GNTBNB','4h','0.002351000000000','0.002370000000000','0.586275093512094','0.591013173808449','249.3726471765606','249.372647176560605','test'),('2019-11-30 19:59:59','2019-12-01 03:59:59','GNTBNB','4h','0.002420000000000','0.002364000000000','0.586275093512094','0.572708397133302','242.26243533557601','242.262435335576015','test'),('2019-12-01 07:59:59','2019-12-03 07:59:59','GNTBNB','4h','0.002470000000000','0.002427000000000','0.586275093512094','0.576068685001559','237.35833745428906','237.358337454289057','test'),('2019-12-04 03:59:59','2019-12-04 03:59:59','GNTBNB','4h','0.002506000000000','0.002506000000000','0.586275093512094','0.586275093512094','233.94856085877652','233.948560858776517','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  8:41:47
