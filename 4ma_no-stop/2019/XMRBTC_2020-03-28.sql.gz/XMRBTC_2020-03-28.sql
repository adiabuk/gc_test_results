-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 15:59:59','2019-01-05 19:59:59','XMRBTC','4h','0.013051000000000','0.012877000000000','0.001467500000000','0.001447934832580','0.112443490920236','0.112443490920236','test'),('2019-01-06 11:59:59','2019-01-07 11:59:59','XMRBTC','4h','0.013127000000000','0.013023000000000','0.001467500000000','0.001455873581169','0.11179248876361698','0.111792488763617','test'),('2019-01-07 19:59:59','2019-01-08 23:59:59','XMRBTC','4h','0.013219000000000','0.013172000000000','0.001467500000000','0.001462282320902','0.1110144488993116','0.111014448899312','test'),('2019-01-09 03:59:59','2019-01-09 19:59:59','XMRBTC','4h','0.013279000000000','0.012917000000000','0.001467500000000','0.001427494351984','0.11051283982227579','0.110512839822276','test'),('2019-01-22 15:59:59','2019-01-23 07:59:59','XMRBTC','4h','0.012763000000000','0.012544000000000','0.001467500000000','0.001442319203949','0.11498080388623365','0.114980803886234','test'),('2019-01-23 11:59:59','2019-01-23 23:59:59','XMRBTC','4h','0.012718000000000','0.012541000000000','0.001467500000000','0.001447076387797','0.1153876395659695','0.115387639565969','test'),('2019-01-24 03:59:59','2019-01-25 15:59:59','XMRBTC','4h','0.012584000000000','0.012913000000000','0.001467500000000','0.001505866775270','0.1166163382072473','0.116616338207247','test'),('2019-01-25 19:59:59','2019-01-27 03:59:59','XMRBTC','4h','0.013111000000000','0.012752000000000','0.001467500000000','0.001427317519640','0.11192891465181909','0.111928914651819','test'),('2019-01-27 07:59:59','2019-01-27 15:59:59','XMRBTC','4h','0.012778000000000','0.012846000000000','0.001467500000000','0.001475309516356','0.11484582876819535','0.114845828768195','test'),('2019-01-27 19:59:59','2019-01-28 07:59:59','XMRBTC','4h','0.012859000000000','0.012744000000000','0.001467500000000','0.001454375923478','0.11412240454156622','0.114122404541566','test'),('2019-02-07 11:59:59','2019-02-11 07:59:59','XMRBTC','4h','0.012708000000000','0.013032000000000','0.001467500000000','0.001504915014164','0.11547843877872206','0.115478438778722','test'),('2019-02-11 15:59:59','2019-02-14 07:59:59','XMRBTC','4h','0.013189000000000','0.013213000000000','0.001467500000000','0.001470170407157','0.11126696489498826','0.111266964894988','test'),('2019-02-19 15:59:59','2019-02-20 03:59:59','XMRBTC','4h','0.013203000000000','0.012865000000000','0.001467500000000','0.001429931644323','0.11114898129213059','0.111148981292131','test'),('2019-03-06 23:59:59','2019-03-08 03:59:59','XMRBTC','4h','0.012841000000000','0.012791000000000','0.001467500000000','0.001461785881162','0.11428237676193444','0.114282376761934','test'),('2019-03-08 11:59:59','2019-03-08 15:59:59','XMRBTC','4h','0.012802000000000','0.012671000000000','0.001467500000000','0.001452483401031','0.11463052648023747','0.114630526480237','test'),('2019-03-12 23:59:59','2019-03-17 15:59:59','XMRBTC','4h','0.012936000000000','0.013115000000000','0.001467500000000','0.001487806315708','0.1134431045145331','0.113443104514533','test'),('2019-03-20 03:59:59','2019-03-21 15:59:59','XMRBTC','4h','0.013175000000000','0.013126000000000','0.001467500000000','0.001462042125237','0.11138519924098673','0.111385199240987','test'),('2019-03-21 19:59:59','2019-03-21 23:59:59','XMRBTC','4h','0.013142000000000','0.013106000000000','0.001467500000000','0.001463480063917','0.11166489118855578','0.111664891188556','test'),('2019-03-25 03:59:59','2019-03-25 11:59:59','XMRBTC','4h','0.013225000000000','0.013100000000000','0.001467500000000','0.001453629489603','0.1109640831758034','0.110964083175803','test'),('2019-03-28 11:59:59','2019-03-28 19:59:59','XMRBTC','4h','0.013221000000000','0.013046000000000','0.001467500000000','0.001448075410332','0.11099765524544286','0.110997655245443','test'),('2019-03-28 23:59:59','2019-03-29 03:59:59','XMRBTC','4h','0.013094000000000','0.012986000000000','0.001467500000000','0.001455395982893','0.11207423247288835','0.112074232472888','test'),('2019-03-31 19:59:59','2019-04-02 07:59:59','XMRBTC','4h','0.013531000000000','0.013630000000000','0.001467500000000','0.001478237011307','0.10845465967038653','0.108454659670387','test'),('2019-04-02 11:59:59','2019-04-03 23:59:59','XMRBTC','4h','0.013710000000000','0.013329000000000','0.001467500000000','0.001426718271335','0.10703865791393144','0.107038657913931','test'),('2019-04-06 15:59:59','2019-04-06 19:59:59','XMRBTC','4h','0.013673000000000','0.013378000000000','0.001467500000000','0.001435838148175','0.1073283112703869','0.107328311270387','test'),('2019-04-08 07:59:59','2019-04-08 11:59:59','XMRBTC','4h','0.013684000000000','0.013436000000000','0.001467500000000','0.001440903975446','0.10724203449283835','0.107242034492838','test'),('2019-05-17 07:59:59','2019-05-17 11:59:59','XMRBTC','4h','0.011299000000000','0.010974000000000','0.001467500000000','0.001425289406142','0.12987875033188778','0.129878750331888','test'),('2019-05-17 15:59:59','2019-05-17 19:59:59','XMRBTC','4h','0.011175000000000','0.011120000000000','0.001467500000000','0.001460277404922','0.1313199105145414','0.131319910514541','test'),('2019-05-17 23:59:59','2019-05-18 11:59:59','XMRBTC','4h','0.011221000000000','0.011070000000000','0.001467500000000','0.001447751982889','0.1307815702700294','0.130781570270029','test'),('2019-05-20 15:59:59','2019-05-20 19:59:59','XMRBTC','4h','0.011135000000000','0.011076000000000','0.001467500000000','0.001459724292771','0.1317916479568927','0.131791647956893','test'),('2019-05-21 03:59:59','2019-05-22 23:59:59','XMRBTC','4h','0.011626000000000','0.010894000000000','0.001467500000000','0.001375102786857','0.12622570101496647','0.126225701014966','test'),('2019-05-30 19:59:59','2019-05-30 23:59:59','XMRBTC','4h','0.011000000000000','0.011101000000000','0.001467500000000','0.001480974318182','0.13340909090909092','0.133409090909091','test'),('2019-05-31 19:59:59','2019-05-31 23:59:59','XMRBTC','4h','0.010961000000000','0.010894000000000','0.001467500000000','0.001458529787428','0.13388376972903931','0.133883769729039','test'),('2019-06-03 15:59:59','2019-06-03 23:59:59','XMRBTC','4h','0.011019000000000','0.010951000000000','0.001467500000000','0.001458443824303','0.1331790543606498','0.133179054360650','test'),('2019-06-04 07:59:59','2019-06-04 11:59:59','XMRBTC','4h','0.010930000000000','0.010874000000000','0.001467500000000','0.001459981244282','0.13426349496797804','0.134263494967978','test'),('2019-06-06 11:59:59','2019-06-06 23:59:59','XMRBTC','4h','0.011003000000000','0.011125000000000','0.001467500000000','0.001483771471417','0.13337271653185495','0.133372716531855','test'),('2019-06-07 11:59:59','2019-06-08 07:59:59','XMRBTC','4h','0.011056000000000','0.010993000000000','0.001467500000000','0.001459137798480','0.13273335745296672','0.132733357452967','test'),('2019-06-08 11:59:59','2019-06-09 03:59:59','XMRBTC','4h','0.011021000000000','0.011016000000000','0.001467500000000','0.001466834225569','0.13315488612648582','0.133154886126486','test'),('2019-06-11 15:59:59','2019-06-11 23:59:59','XMRBTC','4h','0.011100000000000','0.010942000000000','0.001467500000000','0.001446611261261','0.13220720720720722','0.132207207207207','test'),('2019-06-12 03:59:59','2019-06-12 15:59:59','XMRBTC','4h','0.011007000000000','0.010964000000000','0.001467500000000','0.001461767057327','0.1333242482056873','0.133324248205687','test'),('2019-06-12 19:59:59','2019-06-12 23:59:59','XMRBTC','4h','0.011041000000000','0.011077000000000','0.001467500000000','0.001472284892673','0.13291368535458745','0.132913685354587','test'),('2019-06-13 03:59:59','2019-06-13 23:59:59','XMRBTC','4h','0.011154000000000','0.010890000000000','0.001467500000000','0.001432766272189','0.13156715079792003','0.131567150797920','test'),('2019-06-20 07:59:59','2019-06-21 23:59:59','XMRBTC','4h','0.011311000000000','0.010769000000000','0.001467500000000','0.001397180399611','0.1297409601273097','0.129740960127310','test'),('2019-07-07 23:59:59','2019-07-08 11:59:59','XMRBTC','4h','0.009368000000000','0.008480000000000','0.001467500000000','0.001328394534586','0.15665029888983775','0.156650298889838','test'),('2019-07-08 15:59:59','2019-07-08 23:59:59','XMRBTC','4h','0.008685000000000','0.008264000000000','0.001467500000000','0.001396363845711','0.16896948762233738','0.168969487622337','test'),('2019-07-23 07:59:59','2019-07-25 07:59:59','XMRBTC','4h','0.008170000000000','0.008136000000000','0.001467500000000','0.001461392900857','0.17962056303549573','0.179620563035496','test'),('2019-07-25 11:59:59','2019-07-26 03:59:59','XMRBTC','4h','0.008218000000000','0.008141000000000','0.001467500000000','0.001453750000000','0.17857142857142858','0.178571428571429','test'),('2019-07-27 11:59:59','2019-07-29 19:59:59','XMRBTC','4h','0.008291000000000','0.008216000000000','0.001467500000000','0.001454225063322','0.17699915571101196','0.176999155711012','test'),('2019-08-18 03:59:59','2019-08-20 15:59:59','XMRBTC','4h','0.008111000000000','0.008057000000000','0.001467500000000','0.001457729934657','0.18092713598816423','0.180927135988164','test'),('2019-08-22 23:59:59','2019-08-23 03:59:59','XMRBTC','4h','0.008107000000000','0.008086000000000','0.001467500000000','0.001463698655483','0.18101640557542867','0.181016405575429','test'),('2019-09-08 03:59:59','2019-09-09 19:59:59','XMRBTC','4h','0.007463000000000','0.007281000000000','0.001467500000000','0.001431712113091','0.19663674125686723','0.196636741256867','test'),('2019-09-15 19:59:59','2019-09-16 11:59:59','XMRBTC','4h','0.007308000000000','0.007142000000000','0.001467500000000','0.001434165982485','0.2008073344280241','0.200807334428024','test'),('2019-09-16 23:59:59','2019-09-17 07:59:59','XMRBTC','4h','0.007336000000000','0.007279000000000','0.001467500000000','0.001456097669029','0.20004089422028354','0.200040894220284','test'),('2019-09-18 03:59:59','2019-09-19 23:59:59','XMRBTC','4h','0.007310000000000','0.007385000000000','0.001467500000000','0.001482556429549','0.20075239398084818','0.200752393980848','test'),('2019-09-20 03:59:59','2019-09-20 15:59:59','XMRBTC','4h','0.007405000000000','0.007286000000000','0.001467500000000','0.001443916948008','0.19817690749493586','0.198176907494936','test'),('2019-10-07 07:59:59','2019-10-07 11:59:59','XMRBTC','4h','0.007000000000000','0.006985000000000','0.001467500000000','0.001464355357143','0.20964285714285716','0.209642857142857','test'),('2019-10-17 11:59:59','2019-10-19 03:59:59','XMRBTC','4h','0.007427000000000','0.006924000000000','0.001467500000000','0.001368112292985','0.19758987478120374','0.197589874781204','test'),('2019-10-21 15:59:59','2019-10-22 07:59:59','XMRBTC','4h','0.007052000000000','0.006902000000000','0.001467500000000','0.001436285450936','0.20809699376063528','0.208096993760635','test'),('2019-10-22 11:59:59','2019-10-24 07:59:59','XMRBTC','4h','0.006977000000000','0.006998000000000','0.001467500000000','0.001471917013043','0.21033395442167122','0.210333954421671','test'),('2019-10-24 11:59:59','2019-10-25 15:59:59','XMRBTC','4h','0.007082000000000','0.006915000000000','0.001467500000000','0.001432895015532','0.20721547585427846','0.207215475854278','test'),('2019-11-03 07:59:59','2019-11-05 19:59:59','XMRBTC','4h','0.006675000000000','0.006697000000000','0.001467500000000','0.001472336704120','0.2198501872659176','0.219850187265918','test'),('2019-11-06 07:59:59','2019-11-16 03:59:59','XMRBTC','4h','0.006796000000000','0.007250000000000','0.001467500000000','0.001565534873455','0.21593584461447912','0.215935844614479','test'),('2019-11-27 07:59:59','2019-11-29 15:59:59','XMRBTC','4h','0.007288000000000','0.007169000000000','0.001467500000000','0.001443538350714','0.20135839736553238','0.201358397365532','test'),('2019-12-02 07:59:59','2019-12-04 03:59:59','XMRBTC','4h','0.007313000000000','0.007304000000000','0.001467500000000','0.001465693969643','0.2006700396554082','0.200670039655408','test'),('2019-12-04 07:59:59','2019-12-04 15:59:59','XMRBTC','4h','0.007422000000000','0.007313000000000','0.001467500000000','0.001445948194557','0.1977229857181353','0.197722985718135','test'),('2019-12-10 23:59:59','2019-12-13 03:59:59','XMRBTC','4h','0.007289000000000','0.007293000000000','0.001467500000000','0.001468305323090','0.20133077239676225','0.201330772396762','test'),('2019-12-13 07:59:59','2019-12-13 15:59:59','XMRBTC','4h','0.007319000000000','0.007310000000000','0.001467500000000','0.001465695450198','0.20050553354283374','0.200505533542834','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:18:45
