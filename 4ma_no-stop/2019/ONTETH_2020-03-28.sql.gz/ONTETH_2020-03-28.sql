-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 19:59:59','2019-01-14 15:59:59','ONTETH','4h','0.004742000000000','0.004712000000000','0.072144500000000','0.071688081822016','15.213939266132435','15.213939266132435','test'),('2019-01-16 07:59:59','2019-01-19 23:59:59','ONTETH','4h','0.004882000000000','0.004987000000000','0.072144500000000','0.073696153523146','14.777652601392871','14.777652601392871','test'),('2019-01-20 03:59:59','2019-01-20 15:59:59','ONTETH','4h','0.005028000000000','0.004960000000000','0.072418308836290','0.071438904500397','14.403004939596359','14.403004939596359','test'),('2019-01-22 11:59:59','2019-01-27 15:59:59','ONTETH','4h','0.005078000000000','0.005225000000000','0.072418308836290','0.074514703361484','14.261187246217014','14.261187246217014','test'),('2019-01-27 23:59:59','2019-01-29 11:59:59','ONTETH','4h','0.005351000000000','0.005184000000000','0.072697556383616','0.070428729637949','13.58578889620926','13.585788896209261','test'),('2019-02-15 19:59:59','2019-02-17 11:59:59','ONTETH','4h','0.005395000000000','0.005018000000000','0.072697556383616','0.067617486178496','13.47498728148582','13.474987281485820','test'),('2019-02-17 15:59:59','2019-02-17 23:59:59','ONTETH','4h','0.005055000000000','0.004829000000000','0.072697556383616','0.069447378788621','14.381316792011079','14.381316792011079','test'),('2019-02-21 15:59:59','2019-02-27 03:59:59','ONTETH','4h','0.005004000000000','0.006455000000000','0.072697556383616','0.093777523272630','14.52788896555076','14.527888965550760','test'),('2019-03-01 15:59:59','2019-03-02 19:59:59','ONTETH','4h','0.006782000000000','0.006648000000000','0.075317779469424','0.073829636967374','11.105541060074279','11.105541060074279','test'),('2019-03-03 19:59:59','2019-03-04 03:59:59','ONTETH','4h','0.006711000000000','0.006483000000000','0.075317779469424','0.072758927775335','11.223033746002683','11.223033746002683','test'),('2019-03-07 03:59:59','2019-03-10 11:59:59','ONTETH','4h','0.006647000000000','0.007068000000000','0.075317779469424','0.080088169894673','11.331093646671281','11.331093646671281','test'),('2019-03-12 19:59:59','2019-03-24 03:59:59','ONTETH','4h','0.007311000000000','0.008976000000000','0.075498628526701','0.092692612454612','10.326717073820442','10.326717073820442','test'),('2019-03-30 07:59:59','2019-04-02 07:59:59','ONTETH','4h','0.009093000000000','0.009100000000000','0.079797124508679','0.079858554165730','8.775665292937315','8.775665292937315','test'),('2019-04-02 11:59:59','2019-04-02 15:59:59','ONTETH','4h','0.009135000000000','0.009065000000000','0.079812481922942','0.079200892023149','8.73699856846653','8.736998568466531','test'),('2019-04-04 03:59:59','2019-04-06 19:59:59','ONTETH','4h','0.009367000000000','0.009408000000000','0.079812481922942','0.080161826618025','8.520602319092772','8.520602319092772','test'),('2019-05-14 19:59:59','2019-05-15 15:59:59','ONTETH','4h','0.006965000000000','0.006364000000000','0.079812481922942','0.072925575729735','11.459078524471215','11.459078524471215','test'),('2019-05-15 19:59:59','2019-05-15 23:59:59','ONTETH','4h','0.006443000000000','0.006403000000000','0.079812481922942','0.079316983044016','12.387471973140153','12.387471973140153','test'),('2019-05-30 11:59:59','2019-05-31 19:59:59','ONTETH','4h','0.005545000000000','0.005574000000000','0.079812481922942','0.080229896165641','14.393594575823627','14.393594575823627','test'),('2019-05-31 23:59:59','2019-06-01 07:59:59','ONTETH','4h','0.005687000000000','0.005597000000000','0.079812481922942','0.078549404136224','14.034197630199051','14.034197630199051','test'),('2019-06-02 07:59:59','2019-06-02 15:59:59','ONTETH','4h','0.005638000000000','0.005608000000000','0.079812481922942','0.079387796847084','14.15616919527173','14.156169195271730','test'),('2019-06-09 19:59:59','2019-06-12 19:59:59','ONTETH','4h','0.005572000000000','0.005582000000000','0.079812481922942','0.079955720404498','14.323848155589019','14.323848155589019','test'),('2019-07-20 15:59:59','2019-07-23 07:59:59','ONTETH','4h','0.004491000000000','0.004399000000000','0.079812481922942','0.078177490086623','17.771650394776664','17.771650394776664','test'),('2019-07-24 11:59:59','2019-07-27 23:59:59','ONTETH','4h','0.004541000000000','0.004718000000000','0.079812481922942','0.082923428696860','17.57597047411187','17.575970474111870','test'),('2019-08-24 19:59:59','2019-08-27 03:59:59','ONTETH','4h','0.004403000000000','0.004124000000000','0.079812481922942','0.074755093220580','18.126841227104702','18.126841227104702','test'),('2019-08-29 23:59:59','2019-08-31 15:59:59','ONTETH','4h','0.004232000000000','0.004195000000000','0.079812481922942','0.079114688484580','18.85928211789745','18.859282117897450','test'),('2019-08-31 19:59:59','2019-08-31 23:59:59','ONTETH','4h','0.004231000000000','0.004142000000000','0.079812481922942','0.078133609105371','18.86373952326684','18.863739523266840','test'),('2019-09-09 15:59:59','2019-09-11 03:59:59','ONTETH','4h','0.004190000000000','0.004150000000000','0.079812481922942','0.079050548921291','19.04832504127494','19.048325041274939','test'),('2019-09-11 07:59:59','2019-09-11 11:59:59','ONTETH','4h','0.004168000000000','0.004127000000000','0.079812481922942','0.079027378333969','19.148868023738487','19.148868023738487','test'),('2019-10-07 11:59:59','2019-10-07 19:59:59','ONTETH','4h','0.003542000000000','0.003525000000000','0.079812481922942','0.079429418062781','22.53316824476059','22.533168244760589','test'),('2019-10-07 23:59:59','2019-10-08 03:59:59','ONTETH','4h','0.003550000000000','0.003491000000000','0.079812481922942','0.078486020955772','22.48238927406817','22.482389274068169','test'),('2019-10-08 07:59:59','2019-10-08 11:59:59','ONTETH','4h','0.003521000000000','0.003451000000000','0.079812481922942','0.078225752660060','22.66756089830787','22.667560898307869','test'),('2019-10-09 11:59:59','2019-10-09 15:59:59','ONTETH','4h','0.003571000000000','0.003420000000000','0.079812481922942','0.076437605202034','22.35017695965892','22.350176959658921','test'),('2019-10-13 19:59:59','2019-10-14 03:59:59','ONTETH','4h','0.003542000000000','0.003497000000000','0.079812481922942','0.078798489351928','22.53316824476059','22.533168244760589','test'),('2019-10-15 23:59:59','2019-10-16 15:59:59','ONTETH','4h','0.003522000000000','0.003447000000000','0.079812481922942','0.078112897554907','22.66112490713856','22.661124907138561','test'),('2019-10-26 15:59:59','2019-10-30 03:59:59','ONTETH','4h','0.003509000000000','0.004367000000000','0.079812481922942','0.099327759634508','22.745078917908806','22.745078917908806','test'),('2019-10-30 07:59:59','2019-11-01 03:59:59','ONTETH','4h','0.004898000000000','0.004623000000000','0.079812481922942','0.075331380957485','16.294912601662315','16.294912601662315','test'),('2019-11-01 23:59:59','2019-11-05 03:59:59','ONTETH','4h','0.004755000000000','0.004819000000000','0.079812481922942','0.080886719324218','16.784959394940486','16.784959394940486','test'),('2019-11-12 23:59:59','2019-11-14 11:59:59','ONTETH','4h','0.004916000000000','0.004715000000000','0.079812481922942','0.076549196962301','16.235248560403175','16.235248560403175','test'),('2019-11-14 15:59:59','2019-11-15 03:59:59','ONTETH','4h','0.004741000000000','0.004744000000000','0.079812481922942','0.079862985497245','16.834524767547354','16.834524767547354','test'),('2019-11-29 11:59:59','2019-11-30 11:59:59','ONTETH','4h','0.004303000000000','0.004222000000000','0.079812481922942','0.078310085679447','18.54810177154125','18.548101771541251','test'),('2019-12-08 15:59:59','2019-12-09 03:59:59','ONTETH','4h','0.004292000000000','0.004247000000000','0.079812481922942','0.078975678174915','18.595638845047066','18.595638845047066','test'),('2019-12-09 07:59:59','2019-12-09 15:59:59','ONTETH','4h','0.004281000000000','0.004171000000000','0.079812481922942','0.077761705699741','18.643420210918478','18.643420210918478','test'),('2019-12-15 19:59:59','2019-12-16 07:59:59','ONTETH','4h','0.004223000000000','0.004154000000000','0.079812481922942','0.078508418164315','18.899474762714185','18.899474762714185','test'),('2019-12-16 11:59:59','2019-12-17 07:59:59','ONTETH','4h','0.004160000000000','0.004169000000000','0.079812481922942','0.079985153157871','19.185692769937983','19.185692769937983','test'),('2019-12-17 23:59:59','2019-12-18 23:59:59','ONTETH','4h','0.004272000000000','0.004188000000000','0.079812481922942','0.078243135368277','18.682697079340358','18.682697079340358','test'),('2019-12-19 03:59:59','2019-12-20 03:59:59','ONTETH','4h','0.004214000000000','0.004239000000000','0.079812481922942','0.080285977900178','18.93983908944993','18.939839089449929','test'),('2019-12-20 11:59:59','2019-12-21 15:59:59','ONTETH','4h','0.004303000000000','0.004225000000000','0.079812481922942','0.078365729984762','18.54810177154125','18.548101771541251','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 23:58:59
