-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-04 11:59:59','2019-01-05 11:59:59','ASTBTC','4h','0.000007490000000','0.000007420000000','0.001467500000000','0.001453785046729','195.9279038718291','195.927903871829102','test'),('2019-01-05 19:59:59','2019-01-05 23:59:59','ASTBTC','4h','0.000007370000000','0.000007370000000','0.001467500000000','0.001467500000000','199.11804613297153','199.118046132971529','test'),('2019-01-06 03:59:59','2019-01-06 11:59:59','ASTBTC','4h','0.000007420000000','0.000007390000000','0.001467500000000','0.001461566711590','197.77628032345015','197.776280323450152','test'),('2019-01-06 15:59:59','2019-01-06 19:59:59','ASTBTC','4h','0.000007430000000','0.000007430000000','0.001467500000000','0.001467500000000','197.5100942126514','197.510094212651410','test'),('2019-01-06 23:59:59','2019-01-07 03:59:59','ASTBTC','4h','0.000007450000000','0.000007250000000','0.001467500000000','0.001428104026846','196.9798657718121','196.979865771812086','test'),('2019-01-07 19:59:59','2019-01-08 03:59:59','ASTBTC','4h','0.000007540000000','0.000007350000000','0.001467500000000','0.001430520557029','194.6286472148541','194.628647214854112','test'),('2019-01-08 07:59:59','2019-01-08 11:59:59','ASTBTC','4h','0.000007440000000','0.000007490000000','0.001467500000000','0.001477362231183','197.24462365591398','197.244623655913983','test'),('2019-01-08 15:59:59','2019-01-08 19:59:59','ASTBTC','4h','0.000007550000000','0.000007370000000','0.001467500000000','0.001432513245033','194.37086092715234','194.370860927152336','test'),('2019-01-08 23:59:59','2019-01-09 03:59:59','ASTBTC','4h','0.000007430000000','0.000007480000000','0.001467500000000','0.001477375504711','197.5100942126514','197.510094212651410','test'),('2019-01-17 03:59:59','2019-01-18 15:59:59','ASTBTC','4h','0.000007680000000','0.000007810000000','0.001467500000000','0.001492340494792','191.08072916666669','191.080729166666686','test'),('2019-01-18 23:59:59','2019-01-20 19:59:59','ASTBTC','4h','0.000008700000000','0.000007700000000','0.001467500000000','0.001298821839080','168.67816091954023','168.678160919540232','test'),('2019-01-21 07:59:59','2019-01-24 11:59:59','ASTBTC','4h','0.000008400000000','0.000008270000000','0.001467500000000','0.001444788690476','174.70238095238096','174.702380952380963','test'),('2019-01-24 19:59:59','2019-01-27 03:59:59','ASTBTC','4h','0.000008470000000','0.000008420000000','0.001467500000000','0.001458837072019','173.25855962219597','173.258559622195975','test'),('2019-02-08 23:59:59','2019-02-09 03:59:59','ASTBTC','4h','0.000007400000000','0.000007580000000','0.001467500000000','0.001503195945946','198.3108108108108','198.310810810810807','test'),('2019-02-17 07:59:59','2019-02-18 19:59:59','ASTBTC','4h','0.000008170000000','0.000007420000000','0.001467500000000','0.001332784577723','179.62056303549573','179.620563035495735','test'),('2019-02-18 23:59:59','2019-02-19 03:59:59','ASTBTC','4h','0.000007450000000','0.000007420000000','0.001467500000000','0.001461590604027','196.9798657718121','196.979865771812086','test'),('2019-02-19 19:59:59','2019-02-20 07:59:59','ASTBTC','4h','0.000007820000000','0.000007550000000','0.001467500000000','0.001416831841432','187.6598465473146','187.659846547314601','test'),('2019-02-20 11:59:59','2019-02-21 07:59:59','ASTBTC','4h','0.000007780000000','0.000007690000000','0.001467500000000','0.001450523778920','188.62467866323908','188.624678663239081','test'),('2019-02-21 19:59:59','2019-02-24 19:59:59','ASTBTC','4h','0.000007970000000','0.000007970000000','0.001467500000000','0.001467500000000','184.1279799247177','184.127979924717692','test'),('2019-02-26 15:59:59','2019-02-28 03:59:59','ASTBTC','4h','0.000008410000000','0.000008130000000','0.001467500000000','0.001418641498216','174.49464922711059','174.494649227110585','test'),('2019-02-28 15:59:59','2019-03-04 07:59:59','ASTBTC','4h','0.000008560000000','0.000009370000000','0.001467500000000','0.001606363901869','171.4369158878505','171.436915887850489','test'),('2019-03-08 15:59:59','2019-03-11 07:59:59','ASTBTC','4h','0.000009580000000','0.000009390000000','0.001467500000000','0.001438395093946','153.18371607515658','153.183716075156582','test'),('2019-03-12 19:59:59','2019-03-16 15:59:59','ASTBTC','4h','0.000010160000000','0.000009980000000','0.001467500000000','0.001441500984252','144.43897637795277','144.438976377952770','test'),('2019-03-21 03:59:59','2019-03-21 07:59:59','ASTBTC','4h','0.000010040000000','0.000010020000000','0.001467500000000','0.001464576693227','146.16533864541833','146.165338645418331','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','ASTBTC','4h','0.000010110000000','0.000009750000000','0.001467500000000','0.001415244807122','145.15331355093969','145.153313550939686','test'),('2019-03-23 15:59:59','2019-03-24 07:59:59','ASTBTC','4h','0.000010140000000','0.000009940000000','0.001467500000000','0.001438555226824','144.72386587771206','144.723865877712058','test'),('2019-03-24 11:59:59','2019-03-24 15:59:59','ASTBTC','4h','0.000009950000000','0.000010070000000','0.001467500000000','0.001485198492462','147.48743718592965','147.487437185929650','test'),('2019-03-24 23:59:59','2019-03-25 03:59:59','ASTBTC','4h','0.000010000000000','0.000009920000000','0.001467500000000','0.001455760000000','146.75','146.750000000000000','test'),('2019-03-25 19:59:59','2019-03-25 23:59:59','ASTBTC','4h','0.000010280000000','0.000010080000000','0.001467500000000','0.001438949416342','142.75291828793775','142.752918287937746','test'),('2019-03-26 03:59:59','2019-03-26 11:59:59','ASTBTC','4h','0.000010260000000','0.000009950000000','0.001467500000000','0.001423160331384','143.03118908382066','143.031189083820664','test'),('2019-03-26 15:59:59','2019-03-30 03:59:59','ASTBTC','4h','0.000010200000000','0.000010890000000','0.001467500000000','0.001566772058824','143.87254901960785','143.872549019607845','test'),('2019-03-31 11:59:59','2019-04-02 03:59:59','ASTBTC','4h','0.000011950000000','0.000011070000000','0.001467500000000','0.001359433054393','122.80334728033472','122.803347280334719','test'),('2019-04-20 03:59:59','2019-04-21 11:59:59','ASTBTC','4h','0.000009150000000','0.000008650000000','0.001467500000000','0.001387308743169','160.38251366120218','160.382513661202182','test'),('2019-04-21 15:59:59','2019-04-23 23:59:59','ASTBTC','4h','0.000009130000000','0.000008760000000','0.001467500000000','0.001408028477547','160.7338444687842','160.733844468784213','test'),('2019-05-21 19:59:59','2019-05-25 03:59:59','ASTBTC','4h','0.000005430000000','0.000006850000000','0.001467500000000','0.001851266114180','270.25782688766117','270.257826887661167','test'),('2019-05-28 19:59:59','2019-05-29 07:59:59','ASTBTC','4h','0.000007010000000','0.000006350000000','0.001467500000000','0.001329333095578','209.34379457917262','209.343794579172624','test'),('2019-05-29 15:59:59','2019-05-29 19:59:59','ASTBTC','4h','0.000006370000000','0.000006320000000','0.001467500000000','0.001455981161695','230.37676609105182','230.376766091051820','test'),('2019-06-08 15:59:59','2019-06-09 15:59:59','ASTBTC','4h','0.000006500000000','0.000005980000000','0.001467500000000','0.001350100000000','225.7692307692308','225.769230769230802','test'),('2019-06-11 15:59:59','2019-06-12 15:59:59','ASTBTC','4h','0.000006110000000','0.000006180000000','0.001467500000000','0.001484312602291','240.18003273322424','240.180032733224238','test'),('2019-06-13 07:59:59','2019-06-14 11:59:59','ASTBTC','4h','0.000006190000000','0.000005960000000','0.001467500000000','0.001412972536349','237.07592891760905','237.075928917609048','test'),('2019-06-20 03:59:59','2019-06-21 03:59:59','ASTBTC','4h','0.000006640000000','0.000006120000000','0.001467500000000','0.001352575301205','221.00903614457832','221.009036144578317','test'),('2019-06-21 07:59:59','2019-06-21 23:59:59','ASTBTC','4h','0.000007070000000','0.000005830000000','0.001467500000000','0.001210116690240','207.56718528995756','207.567185289957564','test'),('2019-06-22 07:59:59','2019-06-22 23:59:59','ASTBTC','4h','0.000006240000000','0.000006080000000','0.001467500000000','0.001429871794872','235.17628205128204','235.176282051282044','test'),('2019-06-23 03:59:59','2019-06-23 07:59:59','ASTBTC','4h','0.000006220000000','0.000006140000000','0.001467500000000','0.001448625401929','235.93247588424438','235.932475884244383','test'),('2019-06-23 11:59:59','2019-06-23 19:59:59','ASTBTC','4h','0.000006400000000','0.000005960000000','0.001467500000000','0.001366609375000','229.29687500000003','229.296875000000028','test'),('2019-07-02 19:59:59','2019-07-04 07:59:59','ASTBTC','4h','0.000006270000000','0.000005290000000','0.001467500000000','0.001238129984051','234.05103668261563','234.051036682615631','test'),('2019-07-24 03:59:59','2019-07-25 03:59:59','ASTBTC','4h','0.000004570000000','0.000004320000000','0.001467500000000','0.001387221006565','321.1159737417943','321.115973741794278','test'),('2019-07-25 11:59:59','2019-07-25 15:59:59','ASTBTC','4h','0.000004310000000','0.000004410000000','0.000978333333333','0.001001032482598','226.99149265274556','226.991492652745563','test'),('2019-07-27 19:59:59','2019-07-28 15:59:59','ASTBTC','4h','0.000004500000000','0.000004350000000','0.001102161290083','0.001065422580414','244.92473112961093','244.924731129610933','test'),('2019-07-28 19:59:59','2019-07-28 23:59:59','ASTBTC','4h','0.000004380000000','0.000004420000000','0.001102161290083','0.001112226689992','251.63499773584473','251.634997735844735','test'),('2019-07-29 03:59:59','2019-07-29 11:59:59','ASTBTC','4h','0.000004530000000','0.000004440000000','0.001102161290083','0.001080264045909','243.3027130426049','243.302713042604893','test'),('2019-08-22 03:59:59','2019-08-23 15:59:59','ASTBTC','4h','0.000002830000000','0.000002800000000','0.001102161290083','0.001090477601496','389.4562862484099','389.456286248409924','test'),('2019-08-23 23:59:59','2019-08-26 03:59:59','ASTBTC','4h','0.000002850000000','0.000002860000000','0.001102161290083','0.001106028522680','386.72325967824565','386.723259678245654','test'),('2019-09-10 23:59:59','2019-09-11 19:59:59','ASTBTC','4h','0.000002780000000','0.000002440000000','0.001102161290083','0.000967364585540','396.46089571330936','396.460895713309355','test'),('2019-09-15 15:59:59','2019-09-16 11:59:59','ASTBTC','4h','0.000002650000000','0.000002430000000','0.001102161290083','0.001010661107510','415.9099207860378','415.909920786037787','test'),('2019-09-16 15:59:59','2019-09-21 23:59:59','ASTBTC','4h','0.000002510000000','0.000002760000000','0.001102161290083','0.001211938311008','439.1080836984064','439.108083698406404','test'),('2019-09-22 15:59:59','2019-09-23 23:59:59','ASTBTC','4h','0.000003050000000','0.000002930000000','0.001102161290083','0.001058797567194','361.3643574042623','361.364357404262307','test'),('2019-09-24 07:59:59','2019-09-24 11:59:59','ASTBTC','4h','0.000002920000000','0.000002870000000','0.001102161290083','0.001083288665253','377.45249660376714','377.452496603767145','test'),('2019-09-28 07:59:59','2019-09-29 15:59:59','ASTBTC','4h','0.000002920000000','0.000002840000000','0.001102161290083','0.001071965090355','377.45249660376714','377.452496603767145','test'),('2019-09-29 19:59:59','2019-09-29 23:59:59','ASTBTC','4h','0.000002860000000','0.000002850000000','0.001102161290083','0.001098307579279','385.3710804486014','385.371080448601390','test'),('2019-09-30 11:59:59','2019-10-01 19:59:59','ASTBTC','4h','0.000003000000000','0.000002910000000','0.001102161290083','0.001069096451381','367.38709669433337','367.387096694333366','test'),('2019-10-02 07:59:59','2019-10-09 15:59:59','ASTBTC','4h','0.000003030000000','0.000003210000000','0.001102161290083','0.001167636218207','363.7496006874588','363.749600687458781','test'),('2019-10-15 23:59:59','2019-10-16 15:59:59','ASTBTC','4h','0.000003440000000','0.000003160000000','0.001102161290083','0.001012450487402','320.3957238613372','320.395723861337217','test'),('2019-10-22 15:59:59','2019-10-22 23:59:59','ASTBTC','4h','0.000003300000000','0.000003250000000','0.001102161290083','0.001085461876597','333.98826972212123','333.988269722121231','test'),('2019-11-12 23:59:59','2019-11-14 15:59:59','ASTBTC','4h','0.000002760000000','0.000002740000000','0.001102161290083','0.001094174614068','399.3338007547102','399.333800754710182','test'),('2019-11-14 23:59:59','2019-11-15 11:59:59','ASTBTC','4h','0.000002760000000','0.000002760000000','0.001102161290083','0.001102161290083','399.3338007547102','399.333800754710182','test'),('2019-11-16 23:59:59','2019-11-18 19:59:59','ASTBTC','4h','0.000002890000000','0.000002740000000','0.001102161290083','0.001044955686791','381.3706886100347','381.370688610034676','test'),('2019-11-18 23:59:59','2019-11-21 07:59:59','ASTBTC','4h','0.000002820000000','0.000002830000000','0.001102161290083','0.001106069663452','390.83733690886527','390.837336908865268','test'),('2019-11-25 15:59:59','2019-11-27 19:59:59','ASTBTC','4h','0.000002910000000','0.000002990000000','0.001102161290083','0.001132461256821','378.7495842209622','378.749584220962220','test'),('2019-11-28 03:59:59','2019-11-28 15:59:59','ASTBTC','4h','0.000003000000000','0.000002990000000','0.001102161290083','0.001098487419116','367.38709669433337','367.387096694333366','test'),('2019-11-28 19:59:59','2019-12-02 23:59:59','ASTBTC','4h','0.000003080000000','0.000003020000000','0.001102161290083','0.001080690615601','357.8445747022727','357.844574702272723','test'),('2019-12-05 19:59:59','2019-12-05 23:59:59','ASTBTC','4h','0.000003100000000','0.000003050000000','0.001102161290083','0.001084384495082','355.53590002677424','355.535900026774243','test'),('2019-12-06 15:59:59','2019-12-06 19:59:59','ASTBTC','4h','0.000003110000000','0.000003140000000','0.001102161290083','0.001112793071016','354.3926977758843','354.392697775884301','test'),('2019-12-06 23:59:59','2019-12-10 07:59:59','ASTBTC','4h','0.000003170000000','0.000003160000000','0.001102161290083','0.001098684440587','347.68494955299684','347.684949552996841','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 17:12:47
