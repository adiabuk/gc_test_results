-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-04 03:59:59','2018-09-05 19:59:59','XEMBNB','4h','0.010190000000000','0.010280000000000','0.711908500000000','0.718196210009813','69.86344455348382','69.863444553483816','test'),('2018-09-09 03:59:59','2018-09-09 23:59:59','XEMBNB','4h','0.010450000000000','0.010390000000000','0.713480427502453','0.709383889162726','68.27563899545008','68.275638995450080','test'),('2018-09-10 11:59:59','2018-09-10 15:59:59','XEMBNB','4h','0.010370000000000','0.010070000000000','0.713480427502453','0.692839720824465','68.80235559329344','68.802355593293441','test'),('2018-09-22 19:59:59','2018-09-24 15:59:59','XEMBNB','4h','0.009540000000000','0.009580000000000','0.713480427502453','0.716471959693239','74.78830476964916','74.788304769649159','test'),('2018-09-27 03:59:59','2018-09-27 07:59:59','XEMBNB','4h','0.009600000000000','0.009450000000000','0.713480427502453','0.702332295822727','74.32087786483886','74.320877864838863','test'),('2018-09-27 15:59:59','2018-09-28 15:59:59','XEMBNB','4h','0.009640000000000','0.009680000000000','0.713480427502453','0.716440927201633','74.01249247950757','74.012492479507571','test'),('2018-09-29 19:59:59','2018-09-30 19:59:59','XEMBNB','4h','0.009660000000000','0.009710000000000','0.713480427502453','0.717173390377725','73.85925750542991','73.859257505429909','test'),('2018-10-01 03:59:59','2018-10-03 03:59:59','XEMBNB','4h','0.009690000000000','0.009890000000000','0.713480427502453','0.728206545717158','73.63059107352456','73.630591073524556','test'),('2018-10-03 07:59:59','2018-10-03 11:59:59','XEMBNB','4h','0.009930000000000','0.010030000000000','0.713480427502453','0.720665527477302','71.8509997484847','71.850999748484696','test'),('2018-10-04 11:59:59','2018-10-05 03:59:59','XEMBNB','4h','0.010460000000000','0.009980000000000','0.713480427502453','0.680739451861805','68.21036591801654','68.210365918016535','test'),('2018-10-07 15:59:59','2018-10-10 07:59:59','XEMBNB','4h','0.010460000000000','0.010140000000000','0.713480427502453','0.691653110408688','68.21036591801654','68.210365918016535','test'),('2018-10-10 11:59:59','2018-10-10 15:59:59','XEMBNB','4h','0.010170000000000','0.010150000000000','0.713480427502453','0.712077319483766','70.15540093436115','70.155400934361154','test'),('2018-10-21 15:59:59','2018-10-24 15:59:59','XEMBNB','4h','0.010120000000000','0.010060000000000','0.713480427502453','0.709250306390778','70.50201852791037','70.502018527910366','test'),('2018-10-24 23:59:59','2018-10-25 03:59:59','XEMBNB','4h','0.010120000000000','0.009910000000000','0.713480427502453','0.698675003611592','70.50201852791037','70.502018527910366','test'),('2018-11-03 23:59:59','2018-11-04 03:59:59','XEMBNB','4h','0.009810000000000','0.009710000000000','0.713480427502453','0.706207436396414','72.72991106039277','72.729911060392766','test'),('2018-11-04 07:59:59','2018-11-04 11:59:59','XEMBNB','4h','0.009780000000000','0.009650000000000','0.713480427502453','0.703996536339332','72.95300894708107','72.953008947081074','test'),('2018-11-04 15:59:59','2018-11-04 19:59:59','XEMBNB','4h','0.009770000000000','0.009700000000000','0.713480427502453','0.708368489946141','73.0276793758908','73.027679375890798','test'),('2018-11-04 23:59:59','2018-11-05 15:59:59','XEMBNB','4h','0.009810000000000','0.009700000000000','0.713480427502453','0.705480137285810','72.72991106039277','72.729911060392766','test'),('2018-11-06 15:59:59','2018-11-07 15:59:59','XEMBNB','4h','0.009830000000000','0.009910000000000','0.713480427502453','0.719286982354965','72.58193565640417','72.581935656404170','test'),('2018-11-08 03:59:59','2018-11-08 07:59:59','XEMBNB','4h','0.009870000000000','0.009660000000000','0.713480427502453','0.698299992874741','72.28778394148459','72.287783941484591','test'),('2018-11-11 07:59:59','2018-11-11 15:59:59','XEMBNB','4h','0.009880000000000','0.009850000000000','0.713480427502453','0.711313988957405','72.21461816826448','72.214618168264479','test'),('2018-11-11 23:59:59','2018-11-12 03:59:59','XEMBNB','4h','0.009840000000000','0.009870000000000','0.713480427502453','0.715655672708253','72.50817352667205','72.508173526672053','test'),('2018-11-12 07:59:59','2018-11-15 11:59:59','XEMBNB','4h','0.009930000000000','0.011130000000000','0.713480427502453','0.799701627200635','71.8509997484847','71.850999748484696','test'),('2018-11-15 19:59:59','2018-11-18 19:59:59','XEMBNB','4h','0.011410000000000','0.011690000000000','0.713480427502453','0.730989149649752','62.5311505260695','62.531150526069503','test'),('2018-11-19 07:59:59','2018-11-25 07:59:59','XEMBNB','4h','0.012070000000000','0.013760000000000','0.713480427502453','0.813379509729391','59.111882974519716','59.111882974519716','test'),('2018-11-27 07:59:59','2018-11-30 03:59:59','XEMBNB','4h','0.014990000000000','0.014850000000000','0.734745105356846','0.727882909576329','49.01568414655411','49.015684146554108','test'),('2018-12-01 11:59:59','2018-12-02 03:59:59','XEMBNB','4h','0.015220000000000','0.014850000000000','0.734745105356846','0.716883364950668','48.27497407075204','48.274974070752037','test'),('2018-12-02 07:59:59','2018-12-02 15:59:59','XEMBNB','4h','0.015100000000000','0.014740000000000','0.734745105356846','0.717228003507279','48.65861624879775','48.658616248797749','test'),('2018-12-07 19:59:59','2018-12-11 11:59:59','XEMBNB','4h','0.015700000000000','0.015060000000000','0.734745105356846','0.704793712527013','46.7990512966144','46.799051296614401','test'),('2019-02-26 15:59:59','2019-02-27 15:59:59','XEMBNB','4h','0.004510000000000','0.004380000000000','0.734745105356846','0.713566199880928','162.9146575070612','162.914657507061207','test'),('2019-03-15 19:59:59','2019-03-16 11:59:59','XEMBNB','4h','0.003340000000000','0.003160000000000','0.734745105356846','0.695148063750788','219.9835644780976','219.983564478097605','test'),('2019-03-20 07:59:59','2019-03-21 19:59:59','XEMBNB','4h','0.003280000000000','0.003300000000000','0.734745105356846','0.739225258438290','224.00765407220916','224.007654072209164','test'),('2019-03-21 23:59:59','2019-03-22 15:59:59','XEMBNB','4h','0.003390000000000','0.003300000000000','0.734745105356846','0.715238598134983','216.738969131813','216.738969131813008','test'),('2019-03-22 23:59:59','2019-03-23 07:59:59','XEMBNB','4h','0.003290000000000','0.003260000000000','0.734745105356846','0.728045301964534','223.3267797437222','223.326779743722199','test'),('2019-03-23 11:59:59','2019-03-24 11:59:59','XEMBNB','4h','0.003320000000000','0.003010000000000','0.734745105356846','0.666139387687984','221.3087666737488','221.308766673748806','test'),('2019-03-29 19:59:59','2019-03-30 23:59:59','XEMBNB','4h','0.003360000000000','0.003160000000000','0.734745105356846','0.691010277657034','218.6741384990613','218.674138499061314','test'),('2019-04-02 03:59:59','2019-04-02 07:59:59','XEMBNB','4h','0.003270000000000','0.003230000000000','0.734745105356846','0.725757397646059','224.69269276967768','224.692692769677677','test'),('2019-04-02 11:59:59','2019-04-05 03:59:59','XEMBNB','4h','0.003240000000000','0.003510000000000','0.734745105356846','0.795973864136583','226.77318066569322','226.773180665693218','test'),('2019-04-05 07:59:59','2019-04-11 03:59:59','XEMBNB','4h','0.003730000000000','0.003850000000000','0.734745105356846','0.758383017593527','196.98260197234478','196.982601972344781','test'),('2019-05-10 11:59:59','2019-05-13 07:59:59','XEMBNB','4h','0.002610000000000','0.002430000000000','0.734745105356846','0.684073029125339','281.5115346194812','281.511534619481210','test'),('2019-05-14 19:59:59','2019-05-15 15:59:59','XEMBNB','4h','0.002700000000000','0.002620000000000','0.734745105356846','0.712974880012939','272.1278167988318','272.127816798831816','test'),('2019-05-15 19:59:59','2019-05-18 19:59:59','XEMBNB','4h','0.002770000000000','0.003190000000000','0.734745105356846','0.846150500392902','265.2509405620383','265.250940562038295','test'),('2019-05-30 11:59:59','2019-05-31 07:59:59','XEMBNB','4h','0.002900000000000','0.003210000000000','0.734745105356846','0.813286823515681','253.3603811575331','253.360381157533112','test'),('2019-05-31 23:59:59','2019-06-01 23:59:59','XEMBNB','4h','0.002980000000000','0.002800000000000','0.734745105356846','0.690364528523211','246.55876018686106','246.558760186861065','test'),('2019-06-03 03:59:59','2019-06-03 19:59:59','XEMBNB','4h','0.002980000000000','0.002850000000000','0.734745105356846','0.702692466532554','246.55876018686106','246.558760186861065','test'),('2019-06-17 03:59:59','2019-06-17 15:59:59','XEMBNB','4h','0.002780000000000','0.002660000000000','0.734745105356846','0.703029489298277','264.2968004880741','264.296800488074098','test'),('2019-06-26 03:59:59','2019-06-27 15:59:59','XEMBNB','4h','0.002680000000000','0.002520000000000','0.734745105356846','0.690879725932557','274.1586214018082','274.158621401808205','test'),('2019-06-27 19:59:59','2019-07-01 19:59:59','XEMBNB','4h','0.002630000000000','0.002760000000000','0.734745105356846','0.771063304480949','279.37076249309735','279.370762493097345','test'),('2019-07-09 19:59:59','2019-07-10 15:59:59','XEMBNB','4h','0.002760000000000','0.002720000000000','0.734745105356846','0.724096625569066','266.21199469450943','266.211994694509428','test'),('2019-07-29 03:59:59','2019-08-01 07:59:59','XEMBNB','4h','0.002311000000000','0.002320000000000','0.734745105356846','0.737606509921195','317.9338404832739','317.933840483273912','test'),('2019-08-06 11:59:59','2019-08-06 19:59:59','XEMBNB','4h','0.002387000000000','0.002300000000000','0.734745105356846','0.707965539304879','307.8111040455995','307.811104045599507','test'),('2019-08-06 23:59:59','2019-08-07 03:59:59','XEMBNB','4h','0.002318000000000','0.002308000000000','0.734745105356846','0.731575368060225','316.9737296621423','316.973729662142318','test'),('2019-08-07 07:59:59','2019-08-07 11:59:59','XEMBNB','4h','0.002322000000000','0.002339000000000','0.734745105356846','0.740124376154032','316.4276939521301','316.427693952130085','test'),('2019-08-22 03:59:59','2019-08-22 11:59:59','XEMBNB','4h','0.002054000000000','0.002020000000000','0.734745105356846','0.722582820263305','357.7142674570818','357.714267457081803','test'),('2019-08-22 19:59:59','2019-08-26 07:59:59','XEMBNB','4h','0.002027000000000','0.002053000000000','0.734745105356846','0.744169561567639','362.4790850305111','362.479085030511101','test'),('2019-08-26 19:59:59','2019-08-27 11:59:59','XEMBNB','4h','0.002123000000000','0.002089000000000','0.734745105356846','0.722978108850896','346.08813252795386','346.088132527953860','test'),('2019-08-29 11:59:59','2019-09-02 23:59:59','XEMBNB','4h','0.002164000000000','0.002188000000000','0.734745105356846','0.742893849593706','339.53100986915246','339.531009869152456','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  1:02:51
