-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-12-01 03:59:59','2018-12-03 07:59:59','CVCBTC','4h','0.000016300000000','0.000016000000000','0.001467500000000','0.001440490797546','90.03067484662577','90.030674846625772','test'),('2018-12-03 11:59:59','2018-12-03 15:59:59','CVCBTC','4h','0.000016200000000','0.000015680000000','0.001467500000000','0.001420395061728','90.58641975308642','90.586419753086417','test'),('2018-12-06 11:59:59','2018-12-06 15:59:59','CVCBTC','4h','0.000016170000000','0.000015610000000','0.001467500000000','0.001416677489177','90.75448361162647','90.754483611626469','test'),('2018-12-08 07:59:59','2018-12-08 15:59:59','CVCBTC','4h','0.000017060000000','0.000016350000000','0.001467500000000','0.001406425849941','86.01992966002345','86.019929660023450','test'),('2018-12-08 23:59:59','2018-12-09 03:59:59','CVCBTC','4h','0.000016190000000','0.000015920000000','0.001467500000000','0.001443026559605','90.64237183446573','90.642371834465735','test'),('2018-12-09 07:59:59','2018-12-09 19:59:59','CVCBTC','4h','0.000016050000000','0.000016080000000','0.001467500000000','0.001470242990654','91.43302180685359','91.433021806853588','test'),('2018-12-10 07:59:59','2018-12-10 23:59:59','CVCBTC','4h','0.000016300000000','0.000016110000000','0.001467500000000','0.001450394171779','90.03067484662577','90.030674846625772','test'),('2018-12-11 03:59:59','2018-12-11 07:59:59','CVCBTC','4h','0.000016130000000','0.000015780000000','0.001467500000000','0.001435657160570','90.97954122752635','90.979541227526354','test'),('2018-12-24 11:59:59','2018-12-25 07:59:59','CVCBTC','4h','0.000015400000000','0.000014970000000','0.001467500000000','0.001426524350649','95.29220779220779','95.292207792207790','test'),('2019-01-07 07:59:59','2019-01-07 11:59:59','CVCBTC','4h','0.000014420000000','0.000014040000000','0.001467500000000','0.001428828016644','101.76837725381415','101.768377253814151','test'),('2019-01-16 23:59:59','2019-01-20 15:59:59','CVCBTC','4h','0.000014260000000','0.000014410000000','0.001467500000000','0.001482936535764','102.91023842917251','102.910238429172509','test'),('2019-01-22 15:59:59','2019-01-23 23:59:59','CVCBTC','4h','0.000014840000000','0.000014560000000','0.001467500000000','0.001439811320755','98.88814016172508','98.888140161725076','test'),('2019-01-25 03:59:59','2019-01-25 11:59:59','CVCBTC','4h','0.000014830000000','0.000014670000000','0.001467500000000','0.001451667228591','98.95482130815914','98.954821308159140','test'),('2019-01-25 19:59:59','2019-01-27 11:59:59','CVCBTC','4h','0.000014760000000','0.000014650000000','0.001467500000000','0.001456563346883','99.42411924119241','99.424119241192415','test'),('2019-02-10 03:59:59','2019-02-12 23:59:59','CVCBTC','4h','0.000014140000000','0.000014490000000','0.001467500000000','0.001503824257426','103.78359264497878','103.783592644978782','test'),('2019-02-16 11:59:59','2019-02-19 03:59:59','CVCBTC','4h','0.000014660000000','0.000014620000000','0.001467500000000','0.001463495907231','100.10231923601637','100.102319236016370','test'),('2019-02-23 03:59:59','2019-02-23 23:59:59','CVCBTC','4h','0.000015110000000','0.000014880000000','0.001467500000000','0.001445162144275','97.1211118464593','97.121111846459300','test'),('2019-02-24 03:59:59','2019-02-24 15:59:59','CVCBTC','4h','0.000014930000000','0.000014600000000','0.001467500000000','0.001435063630275','98.29202947086404','98.292029470864037','test'),('2019-02-26 23:59:59','2019-02-28 11:59:59','CVCBTC','4h','0.000015320000000','0.000015170000000','0.001467500000000','0.001453131527415','95.789817232376','95.789817232375995','test'),('2019-03-01 03:59:59','2019-03-04 03:59:59','CVCBTC','4h','0.000015520000000','0.000015560000000','0.001467500000000','0.001471282216495','94.55541237113403','94.555412371134025','test'),('2019-03-09 03:59:59','2019-03-16 15:59:59','CVCBTC','4h','0.000015870000000','0.000018910000000','0.001467500000000','0.001748609010712','92.47006931316952','92.470069313169517','test'),('2019-03-19 15:59:59','2019-03-24 19:59:59','CVCBTC','4h','0.000019090000000','0.000020000000000','0.001467500000000','0.001537454164484','76.87270822420116','76.872708224201162','test'),('2019-03-26 15:59:59','2019-03-26 19:59:59','CVCBTC','4h','0.000020450000000','0.000019350000000','0.001467500000000','0.001388563569682','71.76039119804402','71.760391198044019','test'),('2019-03-29 19:59:59','2019-03-30 07:59:59','CVCBTC','4h','0.000020100000000','0.000019830000000','0.001467500000000','0.001447787313433','73.00995024875623','73.009950248756226','test'),('2019-03-30 11:59:59','2019-03-31 07:59:59','CVCBTC','4h','0.000020630000000','0.000020220000000','0.001467500000000','0.001438334949103','71.13427047988367','71.134270479883668','test'),('2019-03-31 11:59:59','2019-04-02 07:59:59','CVCBTC','4h','0.000020420000000','0.000019530000000','0.001467500000000','0.001403539422135','71.86581782566111','71.865817825661111','test'),('2019-05-23 19:59:59','2019-05-24 15:59:59','CVCBTC','4h','0.000010850000000','0.000010250000000','0.001467500000000','0.001386347926267','135.25345622119818','135.253456221198178','test'),('2019-05-24 23:59:59','2019-05-25 03:59:59','CVCBTC','4h','0.000010230000000','0.000010420000000','0.001467500000000','0.001494755620723','143.45063538611925','143.450635386119245','test'),('2019-05-25 19:59:59','2019-05-26 19:59:59','CVCBTC','4h','0.000010420000000','0.000010000000000','0.001467500000000','0.001408349328215','140.83493282149712','140.834932821497119','test'),('2019-06-05 15:59:59','2019-06-06 15:59:59','CVCBTC','4h','0.000010290000000','0.000010000000000','0.001467500000000','0.001426141885326','142.6141885325559','142.614188532555886','test'),('2019-06-07 07:59:59','2019-06-13 15:59:59','CVCBTC','4h','0.000010260000000','0.000010980000000','0.001467500000000','0.001570482456140','143.03118908382066','143.031189083820664','test'),('2019-07-24 19:59:59','2019-07-27 03:59:59','CVCBTC','4h','0.000005270000000','0.000005110000000','0.001467500000000','0.001422945920304','278.46299810246677','278.462998102466770','test'),('2019-07-27 07:59:59','2019-07-27 11:59:59','CVCBTC','4h','0.000005150000000','0.000005100000000','0.001467500000000','0.001453252427184','284.95145631067965','284.951456310679646','test'),('2019-07-28 15:59:59','2019-07-31 07:59:59','CVCBTC','4h','0.000005200000000','0.000005300000000','0.001467500000000','0.001495721153846','282.21153846153845','282.211538461538453','test'),('2019-07-31 11:59:59','2019-07-31 15:59:59','CVCBTC','4h','0.000005360000000','0.000005200000000','0.001467500000000','0.001423694029851','273.7873134328358','273.787313432835788','test'),('2019-08-22 19:59:59','2019-08-26 07:59:59','CVCBTC','4h','0.000003870000000','0.000004540000000','0.001467500000000','0.001721563307494','379.19896640826875','379.198966408268745','test'),('2019-09-09 19:59:59','2019-09-12 19:59:59','CVCBTC','4h','0.000004350000000','0.000004170000000','0.001467500000000','0.001406775862069','337.35632183908046','337.356321839080465','test'),('2019-09-12 23:59:59','2019-09-13 03:59:59','CVCBTC','4h','0.000004190000000','0.000004190000000','0.001467500000000','0.001467500000000','350.2386634844869','350.238663484486892','test'),('2019-09-15 11:59:59','2019-09-16 11:59:59','CVCBTC','4h','0.000004370000000','0.000004200000000','0.001467500000000','0.001410411899314','335.8123569794051','335.812356979405081','test'),('2019-09-18 03:59:59','2019-09-19 23:59:59','CVCBTC','4h','0.000004530000000','0.000004280000000','0.001467500000000','0.001386512141280','323.95143487858724','323.951434878587236','test'),('2019-09-20 15:59:59','2019-09-23 23:59:59','CVCBTC','4h','0.000004390000000','0.000004310000000','0.001467500000000','0.001440757403189','334.2824601366743','334.282460136674274','test'),('2019-09-27 19:59:59','2019-09-29 07:59:59','CVCBTC','4h','0.000004500000000','0.000004390000000','0.001467500000000','0.001431627777778','326.11111111111114','326.111111111111143','test'),('2019-10-02 19:59:59','2019-10-09 15:59:59','CVCBTC','4h','0.000004550000000','0.000004820000000','0.001467500000000','0.001554582417582','322.5274725274726','322.527472527472582','test'),('2019-10-15 11:59:59','2019-10-15 19:59:59','CVCBTC','4h','0.000004940000000','0.000004830000000','0.001467500000000','0.001434822874494','297.06477732793525','297.064777327935246','test'),('2019-10-22 23:59:59','2019-10-23 19:59:59','CVCBTC','4h','0.000004980000000','0.000004870000000','0.001467500000000','0.001435085341365','294.6787148594378','294.678714859437775','test'),('2019-10-23 23:59:59','2019-10-25 15:59:59','CVCBTC','4h','0.000004910000000','0.000004630000000','0.001467500000000','0.001383813645621','298.8798370672098','298.879837067209792','test'),('2019-11-03 15:59:59','2019-11-04 07:59:59','CVCBTC','4h','0.000004840000000','0.000004620000000','0.001467500000000','0.001400795454545','303.202479338843','303.202479338842977','test'),('2019-11-04 11:59:59','2019-11-04 15:59:59','CVCBTC','4h','0.000004670000000','0.000004640000000','0.001467500000000','0.001458072805139','314.2398286937902','314.239828693790173','test'),('2019-11-05 03:59:59','2019-11-06 07:59:59','CVCBTC','4h','0.000004790000000','0.000004680000000','0.001467500000000','0.001433799582463','306.36743215031316','306.367432150313164','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 13:43:47
