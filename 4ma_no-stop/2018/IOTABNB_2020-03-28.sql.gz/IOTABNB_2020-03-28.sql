-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-31 03:59:59','2018-05-31 11:59:59','IOTABNB','4h','0.126420000000000','0.124500000000000','0.711908500000000','0.701096410773612','5.631296472077203','5.631296472077203','test'),('2018-05-31 15:59:59','2018-06-01 03:59:59','IOTABNB','4h','0.126000000000000','0.123280000000000','0.711908500000000','0.696540316507937','5.6500674603174605','5.650067460317461','test'),('2018-06-01 07:59:59','2018-06-02 19:59:59','IOTABNB','4h','0.131010000000000','0.128790000000000','0.711908500000000','0.699845017288757','5.434001221280819','5.434001221280819','test'),('2018-06-02 23:59:59','2018-06-03 07:59:59','IOTABNB','4h','0.129280000000000','0.130780000000000','0.711908500000000','0.720168576964728','5.506717976485149','5.506717976485149','test'),('2018-06-03 11:59:59','2018-06-03 19:59:59','IOTABNB','4h','0.132680000000000','0.126110000000000','0.711908500000000','0.676656473733796','5.365605215556227','5.365605215556227','test'),('2018-07-01 23:59:59','2018-07-06 15:59:59','IOTABNB','4h','0.074230000000000','0.079310000000000','0.711908500000000','0.760628629058332','9.590576586285868','9.590576586285868','test'),('2018-07-12 11:59:59','2018-07-12 23:59:59','IOTABNB','4h','0.079030000000000','0.079320000000000','0.711908500000000','0.714520842971024','9.008079210426422','9.008079210426422','test'),('2018-07-13 03:59:59','2018-07-16 07:59:59','IOTABNB','4h','0.079470000000000','0.077180000000000','0.711908500000000','0.691394212029697','8.958204353844218','8.958204353844218','test'),('2018-07-16 11:59:59','2018-07-17 15:59:59','IOTABNB','4h','0.081590000000000','0.082270000000000','0.711908500000000','0.717841797953181','8.725438166441966','8.725438166441966','test'),('2018-07-17 19:59:59','2018-07-18 03:59:59','IOTABNB','4h','0.082300000000000','0.084600000000000','0.711908500000000','0.731803877278250','8.650164034021872','8.650164034021872','test'),('2018-07-18 19:59:59','2018-07-19 15:59:59','IOTABNB','4h','0.083650000000000','0.079850000000000','0.711908500000000','0.679568364913329','8.51056186491333','8.510561864913329','test'),('2018-07-21 15:59:59','2018-07-21 19:59:59','IOTABNB','4h','0.083560000000000','0.081950000000000','0.711908500000000','0.698191737374342','8.519728338918144','8.519728338918144','test'),('2018-07-21 23:59:59','2018-07-22 07:59:59','IOTABNB','4h','0.082010000000000','0.081000000000000','0.711908500000000','0.703140940129253','8.680752347274723','8.680752347274723','test'),('2018-08-19 19:59:59','2018-08-22 19:59:59','IOTABNB','4h','0.053910000000000','0.051340000000000','0.711908500000000','0.677970365238360','13.20549990725283','13.205499907252831','test'),('2018-08-25 11:59:59','2018-08-27 19:59:59','IOTABNB','4h','0.052900000000000','0.055350000000000','0.711908500000000','0.744879687618148','13.457627599243857','13.457627599243857','test'),('2018-08-27 23:59:59','2018-09-01 03:59:59','IOTABNB','4h','0.059970000000000','0.064530000000000','0.711908500000000','0.766040612056028','11.871077205269302','11.871077205269302','test'),('2018-09-14 03:59:59','2018-09-14 11:59:59','IOTABNB','4h','0.061790000000000','0.059090000000000','0.711908500000000','0.680800667826509','11.521419323515133','11.521419323515133','test'),('2018-09-14 15:59:59','2018-09-14 19:59:59','IOTABNB','4h','0.059170000000000','0.059010000000000','0.711908500000000','0.709983447439581','12.031578502619572','12.031578502619572','test'),('2018-09-22 19:59:59','2018-09-24 07:59:59','IOTABNB','4h','0.059740000000000','0.055540000000000','0.711908500000000','0.661858019584868','11.916781051221962','11.916781051221962','test'),('2018-10-09 15:59:59','2018-10-10 07:59:59','IOTABNB','4h','0.057170000000000','0.055570000000000','0.711908500000000','0.691984525887703','12.452483820185414','12.452483820185414','test'),('2018-10-10 11:59:59','2018-10-10 15:59:59','IOTABNB','4h','0.055980000000000','0.056180000000000','0.711908500000000','0.714451938728117','12.717193640585924','12.717193640585924','test'),('2018-10-10 19:59:59','2018-10-11 03:59:59','IOTABNB','4h','0.056890000000000','0.054310000000000','0.711908500000000','0.679622967744771','12.513772191949377','12.513772191949377','test'),('2018-11-03 03:59:59','2018-11-03 15:59:59','IOTABNB','4h','0.050370000000000','0.050030000000000','0.711908500000000','0.707103082291046','14.133581496922773','14.133581496922773','test'),('2018-11-04 07:59:59','2018-11-04 11:59:59','IOTABNB','4h','0.049910000000000','0.050220000000000','0.711908500000000','0.716330291925466','14.263844920857544','14.263844920857544','test'),('2018-11-04 15:59:59','2018-11-07 23:59:59','IOTABNB','4h','0.050870000000000','0.051110000000000','0.711908500000000','0.715267219087871','13.994662866129351','13.994662866129351','test'),('2018-11-11 19:59:59','2018-11-14 15:59:59','IOTABNB','4h','0.051010000000000','0.051010000000000','0.711908500000000','0.711908500000000','13.956253675749855','13.956253675749855','test'),('2018-11-17 03:59:59','2018-11-18 11:59:59','IOTABNB','4h','0.052730000000000','0.051900000000000','0.711908500000000','0.700702657879765','13.501014602692965','13.501014602692965','test'),('2018-11-19 23:59:59','2018-11-20 03:59:59','IOTABNB','4h','0.052990000000000','0.051840000000000','0.711908500000000','0.696458513681827','13.434770711454991','13.434770711454991','test'),('2018-11-20 15:59:59','2018-11-20 19:59:59','IOTABNB','4h','0.052600000000000','0.051950000000000','0.711908500000000','0.703111151615970','13.534382129277567','13.534382129277567','test'),('2018-11-21 03:59:59','2018-11-22 07:59:59','IOTABNB','4h','0.053160000000000','0.052450000000000','0.711908500000000','0.702400316497366','13.391807750188113','13.391807750188113','test'),('2018-11-22 11:59:59','2018-11-25 07:59:59','IOTABNB','4h','0.053300000000000','0.055750000000000','0.711908500000000','0.744632249061914','13.356632270168857','13.356632270168857','test'),('2018-11-25 11:59:59','2018-11-26 03:59:59','IOTABNB','4h','0.057590000000000','0.054790000000000','0.711908500000000','0.677295827661052','12.361668692481334','12.361668692481334','test'),('2018-11-28 19:59:59','2018-11-30 11:59:59','IOTABNB','4h','0.056450000000000','0.055810000000000','0.711908500000000','0.703837261027458','12.61131089459699','12.611310894596990','test'),('2018-11-30 15:59:59','2018-12-02 11:59:59','IOTABNB','4h','0.056070000000000','0.055650000000000','0.711908500000000','0.706575852059925','12.696780809702158','12.696780809702158','test'),('2018-12-18 03:59:59','2018-12-24 23:59:59','IOTABNB','4h','0.050190000000000','0.057770000000000','0.711908500000000','0.819425264893405','14.18426977485555','14.184269774855551','test'),('2018-12-27 11:59:59','2018-12-31 03:59:59','IOTABNB','4h','0.060060000000000','0.057690000000000','0.711908500000000','0.683816206543457','11.85328837828838','11.853288378288379','test'),('2019-01-02 07:59:59','2019-01-04 23:59:59','IOTABNB','4h','0.061240000000000','0.062070000000000','0.711908500000000','0.721557161903984','11.624893860222077','11.624893860222077','test'),('2019-03-21 23:59:59','2019-03-24 11:59:59','IOTABNB','4h','0.022430000000000','0.018160000000000','0.711908500000000','0.576382450289791','31.739121711992873','31.739121711992873','test'),('2019-04-07 11:59:59','2019-04-08 03:59:59','IOTABNB','4h','0.018770000000000','0.019070000000000','0.711908500000000','0.723286899041023','37.927996803409705','37.927996803409705','test'),('2019-04-08 15:59:59','2019-04-11 03:59:59','IOTABNB','4h','0.019350000000000','0.018870000000000','0.711908500000000','0.694248754263566','36.791136950904395','36.791136950904395','test'),('2019-04-30 11:59:59','2019-05-02 11:59:59','IOTABNB','4h','0.013950000000000','0.012810000000000','0.711908500000000','0.653731031182796','51.032867383512546','51.032867383512546','test'),('2019-05-08 11:59:59','2019-05-13 07:59:59','IOTABNB','4h','0.013640000000000','0.013400000000000','0.711908500000000','0.699382250733138','52.192705278592385','52.192705278592385','test'),('2019-05-14 03:59:59','2019-05-15 15:59:59','IOTABNB','4h','0.014660000000000','0.015510000000000','0.711908500000000','0.753185595839018','48.56128922237381','48.561289222373809','test'),('2019-05-15 19:59:59','2019-05-15 23:59:59','IOTABNB','4h','0.016240000000000','0.016400000000000','0.711908500000000','0.718922376847291','43.836730295566504','43.836730295566504','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 21:26:57
