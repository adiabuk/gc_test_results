-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-16 19:59:59','2018-04-19 23:59:59','VIBETH','4h','0.000335790000000','0.000330740000000','0.072144500000000','0.071059507221776','214.85005509395754','214.850055093957536','test'),('2018-04-30 15:59:59','2018-05-01 07:59:59','VIBETH','4h','0.000324870000000','0.000319000000000','0.072144500000000','0.070840937913627','222.07190568535106','222.071905685351055','test'),('2018-05-01 15:59:59','2018-05-03 03:59:59','VIBETH','4h','0.000322120000000','0.000310170000000','0.072144500000000','0.069468085076990','223.9677759841053','223.967775984105288','test'),('2018-05-15 15:59:59','2018-05-16 07:59:59','VIBETH','4h','0.000318540000000','0.000262000000000','0.072144500000000','0.059339043762165','226.48489985559112','226.484899855591124','test'),('2018-05-17 19:59:59','2018-05-18 15:59:59','VIBETH','4h','0.000293590000000','0.000278650000000','0.072144500000000','0.068473261776627','245.7321434653769','245.732143465376907','test'),('2018-05-18 19:59:59','2018-05-19 11:59:59','VIBETH','4h','0.000280320000000','0.000269660000000','0.072144500000000','0.069400991259989','257.3647973744292','257.364797374429202','test'),('2018-05-21 03:59:59','2018-05-22 03:59:59','VIBETH','4h','0.000283190000000','0.000274700000000','0.072144500000000','0.069981617112186','254.7565238885554','254.756523888555392','test'),('2018-07-03 15:59:59','2018-07-07 19:59:59','VIBETH','4h','0.000161100000000','0.000178870000000','0.072144500000000','0.080102338392303','447.82433271260084','447.824332712600835','test'),('2018-07-09 23:59:59','2018-07-10 15:59:59','VIBETH','4h','0.000185070000000','0.000176840000000','0.072144500000000','0.068936258604852','389.82276976279246','389.822769762792461','test'),('2018-08-13 19:59:59','2018-08-14 03:59:59','VIBETH','4h','0.000130700000000','0.000119180000000','0.072144500000000','0.065785627467483','551.9854628921194','551.985462892119358','test'),('2018-08-20 19:59:59','2018-08-29 23:59:59','VIBETH','4h','0.000128080000000','0.000139790000000','0.072144500000000','0.078740472009681','563.2768582136165','563.276858213616492','test'),('2018-09-01 07:59:59','2018-09-02 11:59:59','VIBETH','4h','0.000141600000000','0.000138940000000','0.072144500000000','0.070789243149718','509.49505649717514','509.495056497175142','test'),('2018-09-02 15:59:59','2018-09-02 19:59:59','VIBETH','4h','0.000140430000000','0.000139880000000','0.072144500000000','0.071861943032116','513.7399416079185','513.739941607918468','test'),('2018-09-04 03:59:59','2018-09-06 11:59:59','VIBETH','4h','0.000141710000000','0.000143440000000','0.072144500000000','0.073025242255310','509.0995695434338','509.099569543433802','test'),('2018-09-06 19:59:59','2018-09-12 23:59:59','VIBETH','4h','0.000149940000000','0.000158130000000','0.072144500000000','0.076085165966387','481.155795651594','481.155795651594019','test'),('2018-09-17 11:59:59','2018-09-19 07:59:59','VIBETH','4h','0.000174590000000','0.000158800000000','0.072144500000000','0.065619718196919','413.2224067816026','413.222406781602615','test'),('2018-09-25 07:59:59','2018-09-28 03:59:59','VIBETH','4h','0.000163620000000','0.000174000000000','0.072144500000000','0.076721323799047','440.9271482703826','440.927148270382588','test'),('2018-10-02 15:59:59','2018-10-06 03:59:59','VIBETH','4h','0.000186050000000','0.000185840000000','0.072144500000000','0.072063068422467','387.7694168234346','387.769416823434597','test'),('2018-10-06 11:59:59','2018-10-09 15:59:59','VIBETH','4h','0.000190900000000','0.000192450000000','0.072144500000000','0.072730272524882','377.9177579884756','377.917757988475614','test'),('2018-10-10 07:59:59','2018-10-12 03:59:59','VIBETH','4h','0.000199780000000','0.000198090000000','0.072144500000000','0.071534207653419','361.1197317048754','361.119731704875392','test'),('2018-10-12 07:59:59','2018-10-12 11:59:59','VIBETH','4h','0.000205250000000','0.000202110000000','0.072144500000000','0.071040803386115','351.49573690621196','351.495736906211960','test'),('2018-10-13 23:59:59','2018-10-14 23:59:59','VIBETH','4h','0.000212060000000','0.000205860000000','0.072144500000000','0.070035210647930','340.20796001131754','340.207960011317539','test'),('2018-10-15 03:59:59','2018-10-15 07:59:59','VIBETH','4h','0.000215690000000','0.000197900000000','0.072144500000000','0.066194058834438','334.48235894107285','334.482358941072846','test'),('2018-10-16 15:59:59','2018-10-22 19:59:59','VIBETH','4h','0.000211770000000','0.000225440000000','0.072144500000000','0.076801511451103','340.6738442650045','340.673844265004504','test'),('2018-10-23 03:59:59','2018-10-25 19:59:59','VIBETH','4h','0.000231070000000','0.000236760000000','0.072144500000000','0.073921027480850','312.21924092266414','312.219240922664142','test'),('2018-10-27 07:59:59','2018-10-27 15:59:59','VIBETH','4h','0.000241200000000','0.000234280000000','0.072144500000000','0.070074682669983','299.1065505804312','299.106550580431190','test'),('2018-10-29 07:59:59','2018-10-29 11:59:59','VIBETH','4h','0.000244460000000','0.000233670000000','0.072144500000000','0.068960178822711','295.1178106847746','295.117810684774611','test'),('2018-10-30 23:59:59','2018-11-02 07:59:59','VIBETH','4h','0.000297960000000','0.000258920000000','0.072144500000000','0.062691817492281','242.12813800510136','242.128138005101363','test'),('2018-11-02 11:59:59','2018-11-02 15:59:59','VIBETH','4h','0.000264700000000','0.000256140000000','0.072144500000000','0.069811455345674','272.5519455987911','272.551945598791121','test'),('2018-11-03 23:59:59','2018-11-04 07:59:59','VIBETH','4h','0.000263000000000','0.000255940000000','0.072144500000000','0.070207845361217','274.3136882129278','274.313688212927786','test'),('2018-11-11 19:59:59','2018-11-13 15:59:59','VIBETH','4h','0.000255690000000','0.000249110000000','0.072144500000000','0.070287912687238','282.15612655950565','282.156126559505651','test'),('2018-11-13 19:59:59','2018-11-14 11:59:59','VIBETH','4h','0.000256470000000','0.000241250000000','0.072144500000000','0.067863144324872','281.29800756423754','281.298007564237537','test'),('2018-11-29 03:59:59','2018-11-30 11:59:59','VIBETH','4h','0.000234440000000','0.000212910000000','0.072144500000000','0.065519047496161','307.73118921685716','307.731189216857160','test'),('2018-11-30 15:59:59','2018-11-30 23:59:59','VIBETH','4h','0.000213190000000','0.000219750000000','0.072144500000000','0.074364434893757','338.4047094141376','338.404709414137585','test'),('2018-12-01 19:59:59','2018-12-02 03:59:59','VIBETH','4h','0.000231110000000','0.000221740000000','0.072144500000000','0.069219512050539','312.16520271732077','312.165202717320767','test'),('2018-12-04 07:59:59','2018-12-06 15:59:59','VIBETH','4h','0.000223170000000','0.000218730000000','0.072144500000000','0.070709174553031','323.2714970650177','323.271497065017684','test'),('2018-12-08 19:59:59','2018-12-14 03:59:59','VIBETH','4h','0.000238990000000','0.000226400000000','0.072144500000000','0.068343925687267','301.87246328298255','301.872463282982551','test'),('2018-12-17 11:59:59','2018-12-17 15:59:59','VIBETH','4h','0.000237710000000','0.000239450000000','0.072144500000000','0.072672586449876','303.49795969879267','303.497959698792670','test'),('2018-12-17 23:59:59','2018-12-18 03:59:59','VIBETH','4h','0.000232390000000','0.000232630000000','0.072144500000000','0.072219006992556','310.4458023150738','310.445802315073820','test'),('2019-01-09 07:59:59','2019-01-10 07:59:59','VIBETH','4h','0.000178050000000','0.000174870000000','0.072144500000000','0.070855988289806','405.1923616961528','405.192361696152773','test'),('2019-01-10 11:59:59','2019-01-10 15:59:59','VIBETH','4h','0.000175250000000','0.000175830000000','0.072144500000000','0.072383266390870','411.66619115549213','411.666191155492129','test'),('2019-01-10 23:59:59','2019-01-11 03:59:59','VIBETH','4h','0.000176500000000','0.000173250000000','0.072144500000000','0.070816060198300','408.75070821529744','408.750708215297436','test'),('2019-01-11 19:59:59','2019-01-12 11:59:59','VIBETH','4h','0.000181400000000','0.000175880000000','0.072144500000000','0.069949143660419','397.7094818081588','397.709481808158785','test'),('2019-01-12 15:59:59','2019-01-14 19:59:59','VIBETH','4h','0.000177700000000','0.000179010000000','0.072144500000000','0.072676347467642','405.9904333145751','405.990433314575114','test'),('2019-01-15 03:59:59','2019-01-20 11:59:59','VIBETH','4h','0.000181530000000','0.000193780000000','0.072144500000000','0.077012952184212','397.4246680989368','397.424668098936820','test'),('2019-01-22 07:59:59','2019-01-27 15:59:59','VIBETH','4h','0.000205980000000','0.000206770000000','0.072144500000000','0.072421197519177','350.2500242742014','350.250024274201394','test'),('2019-01-30 11:59:59','2019-01-30 23:59:59','VIBETH','4h','0.000215360000000','0.000207910000000','0.072144500000000','0.069648788052563','334.9948922734027','334.994892273402684','test'),('2019-02-01 15:59:59','2019-02-02 15:59:59','VIBETH','4h','0.000213160000000','0.000209540000000','0.072144500000000','0.070919302542691','338.452336273222','338.452336273221988','test'),('2019-02-05 19:59:59','2019-02-05 23:59:59','VIBETH','4h','0.000211160000000','0.000211460000000','0.072144500000000','0.072246997395340','341.65798446675507','341.657984466755067','test'),('2019-02-06 07:59:59','2019-02-06 11:59:59','VIBETH','4h','0.000212940000000','0.000210000000000','0.072144500000000','0.071148422090730','338.8020099558561','338.802009955856079','test'),('2019-02-07 19:59:59','2019-02-07 23:59:59','VIBETH','4h','0.000210130000000','0.000209400000000','0.072144500000000','0.071893867129872','343.33269880550137','343.332698805501366','test'),('2019-02-08 07:59:59','2019-02-08 11:59:59','VIBETH','4h','0.000211460000000','0.000206570000000','0.072144500000000','0.070476162702166','341.1732715407169','341.173271540716883','test'),('2019-02-27 15:59:59','2019-03-06 07:59:59','VIBETH','4h','0.000171590000000','0.000183230000000','0.072144500000000','0.077038503030480','420.44699574567284','420.446995745672837','test'),('2019-03-08 03:59:59','2019-03-16 07:59:59','VIBETH','4h','0.000185220000000','0.000203120000000','0.072144500000000','0.079116676600799','389.507072670338','389.507072670338005','test'),('2019-03-16 15:59:59','2019-03-18 07:59:59','VIBETH','4h','0.000212220000000','0.000207650000000','0.072144500000000','0.070590921802846','339.9514654603713','339.951465460371310','test'),('2019-03-19 19:59:59','2019-03-19 23:59:59','VIBETH','4h','0.000210230000000','0.000208180000000','0.072144500000000','0.071441002758883','343.1693859106693','343.169385910669291','test'),('2019-03-20 15:59:59','2019-03-21 15:59:59','VIBETH','4h','0.000210030000000','0.000202520000000','0.072144500000000','0.069564843784221','343.4961672142075','343.496167214207503','test'),('2019-03-26 23:59:59','2019-03-29 23:59:59','VIBETH','4h','0.000217210000000','0.000256460000000','0.072144500000000','0.085181061967681','332.1417061829566','332.141706182956625','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  3:29:54
