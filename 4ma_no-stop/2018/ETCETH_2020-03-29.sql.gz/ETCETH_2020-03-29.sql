-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-29 23:59:59','2018-03-31 11:59:59','ETCETH','4h','0.038353000000000','0.036284000000000','0.072144500000000','0.068252575756786','1.881065366464162','1.881065366464162','test'),('2018-04-03 07:59:59','2018-04-03 23:59:59','ETCETH','4h','0.037502000000000','0.036286000000000','0.072144500000000','0.069805219108314','1.9237507332942243','1.923750733294224','test'),('2018-04-30 03:59:59','2018-05-01 07:59:59','ETCETH','4h','0.032419000000000','0.031964000000000','0.072144500000000','0.071131953422376','2.225377093679632','2.225377093679632','test'),('2018-05-01 15:59:59','2018-05-01 19:59:59','ETCETH','4h','0.031919000000000','0.031833000000000','0.072144500000000','0.071950119630941','2.260236849525361','2.260236849525361','test'),('2018-05-01 23:59:59','2018-05-02 03:59:59','ETCETH','4h','0.032016000000000','0.031500000000000','0.072144500000000','0.070981751311844','2.2533889305347325','2.253388930534733','test'),('2018-05-08 07:59:59','2018-05-08 11:59:59','ETCETH','4h','0.030655000000000','0.030781000000000','0.072144500000000','0.072441032604795','2.35343337139129','2.353433371391290','test'),('2018-05-26 15:59:59','2018-05-26 23:59:59','ETCETH','4h','0.026085000000000','0.025935000000000','0.072144500000000','0.071729638010351','2.7657465976614914','2.765746597661491','test'),('2018-05-27 07:59:59','2018-05-30 07:59:59','ETCETH','4h','0.025950000000000','0.026802000000000','0.072144500000000','0.074513174913295','2.780134874759152','2.780134874759152','test'),('2018-05-30 15:59:59','2018-05-31 03:59:59','ETCETH','4h','0.027213000000000','0.026805000000000','0.072144500000000','0.071062849465329','2.6511042516444348','2.651104251644435','test'),('2018-06-12 15:59:59','2018-06-14 19:59:59','ETCETH','4h','0.029465000000000','0.027286000000000','0.072144500000000','0.066809259358561','2.4484812489394194','2.448481248939419','test'),('2018-06-15 23:59:59','2018-06-19 23:59:59','ETCETH','4h','0.028366000000000','0.028923000000000','0.072144500000000','0.073561142688430','2.5433441443982234','2.543344144398223','test'),('2018-06-20 07:59:59','2018-06-23 11:59:59','ETCETH','4h','0.029005000000000','0.031191000000000','0.072144500000000','0.077581765195656','2.4873125323220133','2.487312532322013','test'),('2018-06-24 19:59:59','2018-07-02 03:59:59','ETCETH','4h','0.032759000000000','0.035200000000000','0.072144500000000','0.077520266186392','2.2022802893861226','2.202280289386123','test'),('2018-07-04 11:59:59','2018-07-10 07:59:59','ETCETH','4h','0.035971000000000','0.037530000000000','0.072144500000000','0.075271276444914','2.0056295349031164','2.005629534903116','test'),('2018-07-10 11:59:59','2018-07-10 23:59:59','ETCETH','4h','0.038316000000000','0.037238000000000','0.072791756024496','0.070743799218086','1.8997744029777637','1.899774402977764','test'),('2018-07-13 11:59:59','2018-07-13 23:59:59','ETCETH','4h','0.038048000000000','0.037682000000000','0.072791756024496','0.072091540961813','1.913155908970143','1.913155908970143','test'),('2018-07-14 07:59:59','2018-07-14 11:59:59','ETCETH','4h','0.037557000000000','0.037605000000000','0.072791756024496','0.072884788063508','1.938167479417845','1.938167479417845','test'),('2018-07-14 23:59:59','2018-07-15 11:59:59','ETCETH','4h','0.037963000000000','0.037294000000000','0.072791756024496','0.071508988993956','1.917439507533546','1.917439507533546','test'),('2018-07-28 11:59:59','2018-08-01 23:59:59','ETCETH','4h','0.036188000000000','0.036897000000000','0.072791756024496','0.074217901570571','2.0114887814882283','2.011488781488228','test'),('2018-08-04 03:59:59','2018-08-08 19:59:59','ETCETH','4h','0.040122000000000','0.042520000000000','0.072791756024496','0.077142352478978','1.8142604063729626','1.814260406372963','test'),('2018-08-13 19:59:59','2018-08-14 03:59:59','ETCETH','4h','0.043232000000000','0.040708000000000','0.073251464809480','0.068974848016847','1.6943806626915248','1.694380662691525','test'),('2018-08-15 23:59:59','2018-08-18 07:59:59','ETCETH','4h','0.047100000000000','0.044530000000000','0.073251464809480','0.069254516517328','1.5552327985027599','1.555232798502760','test'),('2018-08-20 23:59:59','2018-08-21 07:59:59','ETCETH','4h','0.045681000000000','0.044700000000000','0.073251464809480','0.071678388760836','1.603543372725641','1.603543372725641','test'),('2018-08-21 15:59:59','2018-08-22 23:59:59','ETCETH','4h','0.045237000000000','0.045150000000000','0.073251464809480','0.073110587265911','1.6192821099869577','1.619282109986958','test'),('2018-08-23 15:59:59','2018-08-23 19:59:59','ETCETH','4h','0.045325000000000','0.044848000000000','0.073251464809480','0.072480566878666','1.6161382197348042','1.616138219734804','test'),('2018-08-24 15:59:59','2018-08-24 19:59:59','ETCETH','4h','0.045484000000000','0.044709000000000','0.073251464809480','0.072003336121868','1.6104886291768534','1.610488629176853','test'),('2018-08-26 11:59:59','2018-08-27 07:59:59','ETCETH','4h','0.045800000000000','0.045176000000000','0.073251464809480','0.072253453585875','1.5993769609056767','1.599376960905677','test'),('2018-08-27 11:59:59','2018-08-27 15:59:59','ETCETH','4h','0.045363000000000','0.044998000000000','0.073251464809480','0.072662068502898','1.614784401593369','1.614784401593369','test'),('2018-08-27 19:59:59','2018-08-27 23:59:59','ETCETH','4h','0.045139000000000','0.044206000000000','0.073251464809480','0.071737394567179','1.6227976873541727','1.622797687354173','test'),('2018-08-30 07:59:59','2018-08-30 11:59:59','ETCETH','4h','0.045300000000000','0.045362000000000','0.073251464809480','0.073351720677431','1.6170301282445916','1.617030128244592','test'),('2018-08-30 19:59:59','2018-08-30 23:59:59','ETCETH','4h','0.045484000000000','0.045130000000000','0.073251464809480','0.072681351834751','1.6104886291768534','1.610488629176853','test'),('2018-08-31 03:59:59','2018-08-31 15:59:59','ETCETH','4h','0.045229000000000','0.045360000000000','0.073251464809480','0.073463628286233','1.6195685248287603','1.619568524828760','test'),('2018-08-31 23:59:59','2018-09-01 03:59:59','ETCETH','4h','0.045267000000000','0.045150000000000','0.073251464809480','0.073062134361633','1.6182089559608543','1.618208955960854','test'),('2018-09-01 11:59:59','2018-09-01 15:59:59','ETCETH','4h','0.045343000000000','0.044855000000000','0.073251464809480','0.072463102442036','1.6154966545989458','1.615496654598946','test'),('2018-09-03 03:59:59','2018-09-13 07:59:59','ETCETH','4h','0.047827000000000','0.057584000000000','0.073251464809480','0.088195210855565','1.5315922974361762','1.531592297436176','test'),('2018-09-27 07:59:59','2018-09-27 19:59:59','ETCETH','4h','0.051200000000000','0.050194000000000','0.073251464809480','0.071812187981387','1.4306926720601563','1.430692672060156','test'),('2018-09-28 19:59:59','2018-09-29 11:59:59','ETCETH','4h','0.050900000000000','0.048867000000000','0.073251464809480','0.070325723592237','1.4391250453728879','1.439125045372888','test'),('2018-10-22 15:59:59','2018-10-23 23:59:59','ETCETH','4h','0.049424000000000','0.048125000000000','0.073251464809480','0.071326212851170','1.4821031241801552','1.482103124180155','test'),('2018-10-24 03:59:59','2018-10-24 11:59:59','ETCETH','4h','0.048356000000000','0.048116000000000','0.073251464809480','0.072887903895544','1.5148371413987922','1.514837141398792','test'),('2018-12-02 19:59:59','2018-12-03 23:59:59','ETCETH','4h','0.044297000000000','0.041551000000000','0.073251464809480','0.068710558599876','1.6536439219242838','1.653643921924284','test'),('2018-12-04 03:59:59','2018-12-04 07:59:59','ETCETH','4h','0.042280000000000','0.042131000000000','0.073251464809480','0.072993317499721','1.7325322802620624','1.732532280262062','test'),('2018-12-09 11:59:59','2018-12-09 15:59:59','ETCETH','4h','0.042656000000000','0.041470000000000','0.073251464809480','0.071214793830859','1.7172605216025882','1.717260521602588','test'),('2018-12-09 19:59:59','2018-12-10 07:59:59','ETCETH','4h','0.041895000000000','0.041871000000000','0.073251464809480','0.073209501922371','1.7484536295376536','1.748453629537654','test'),('2018-12-10 11:59:59','2018-12-11 23:59:59','ETCETH','4h','0.042149000000000','0.042135000000000','0.073251464809480','0.073227133971089','1.737917027912406','1.737917027912406','test'),('2018-12-12 15:59:59','2018-12-15 11:59:59','ETCETH','4h','0.043147000000000','0.042982000000000','0.073251464809480','0.072971341239045','1.6977186086977079','1.697718608697708','test'),('2018-12-15 15:59:59','2018-12-15 19:59:59','ETCETH','4h','0.043374000000000','0.042636000000000','0.073251464809480','0.072005105676603','1.6888335133831327','1.688833513383133','test'),('2018-12-20 03:59:59','2018-12-20 11:59:59','ETCETH','4h','0.043913000000000','0.042923000000000','0.073251464809480','0.071600041537069','1.6681043155666886','1.668104315566689','test'),('2018-12-20 15:59:59','2018-12-20 19:59:59','ETCETH','4h','0.043107000000000','0.041789000000000','0.073251464809480','0.071011795367884','1.6992939617574871','1.699293961757487','test'),('2018-12-28 11:59:59','2018-12-28 19:59:59','ETCETH','4h','0.042690000000000','0.039051000000000','0.073251464809480','0.067007330809909','1.7158928275821035','1.715892827582103','test'),('2019-01-12 11:59:59','2019-01-13 15:59:59','ETCETH','4h','0.036606000000000','0.035600000000000','0.073251464809480','0.071238380244154','2.0010780967458888','2.001078096745889','test'),('2019-01-13 19:59:59','2019-01-14 15:59:59','ETCETH','4h','0.036415000000000','0.034218000000000','0.073251464809480','0.068832036876309','2.0115739340788137','2.011573934078814','test'),('2019-01-17 11:59:59','2019-01-19 23:59:59','ETCETH','4h','0.035560000000000','0.035382000000000','0.073251464809480','0.072884795497442','2.059939955272216','2.059939955272216','test'),('2019-01-20 03:59:59','2019-01-20 07:59:59','ETCETH','4h','0.035680000000000','0.035733000000000','0.073251464809480','0.073360274440503','2.0530119060952914','2.053011906095291','test'),('2019-01-20 23:59:59','2019-01-27 11:59:59','ETCETH','4h','0.035929000000000','0.036621000000000','0.073251464809480','0.074662303231038','2.0387838461821923','2.038783846182192','test'),('2019-01-27 23:59:59','2019-01-30 03:59:59','ETCETH','4h','0.037470000000000','0.036960000000000','0.073251464809480','0.072254447274043','1.954936343994662','1.954936343994662','test'),('2019-03-02 11:59:59','2019-03-05 15:59:59','ETCETH','4h','0.032306000000000','0.031803000000000','0.073251464809480','0.072110949524419','2.267426014037021','2.267426014037021','test'),('2019-03-11 19:59:59','2019-03-11 23:59:59','ETCETH','4h','0.032065000000000','0.031649000000000','0.073251464809480','0.072301126142374','2.2844679497732727','2.284467949773273','test'),('2019-03-12 01:59:59','2019-03-12 11:59:59','ETCETH','4h','0.031727000000000','0.031717000000000','0.073251464809480','0.073228376756777','2.30880527025814','2.308805270258140','test'),('2019-03-12 15:59:59','2019-03-16 07:59:59','ETCETH','4h','0.031822000000000','0.031909000000000','0.073251464809480','0.073451731211291','2.301912664492489','2.301912664492489','test'),('2019-03-19 15:59:59','2019-03-25 11:59:59','ETCETH','4h','0.032903000000000','0.034853000000000','0.073251464809480','0.077592721119801','2.226285287344011','2.226285287344011','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  5:06:37
