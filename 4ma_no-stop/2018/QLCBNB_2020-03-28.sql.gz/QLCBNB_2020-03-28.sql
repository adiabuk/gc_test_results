-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-17 03:59:59','2018-09-17 07:59:59','QLCBNB','4h','0.005725000000000','0.005507000000000','0.711908500000000','0.684800019126638','124.35082969432315','124.350829694323153','test'),('2018-09-18 15:59:59','2018-09-19 11:59:59','QLCBNB','4h','0.005874000000000','0.005371000000000','0.711908500000000','0.650946638321416','121.19654409261152','121.196544092611518','test'),('2018-09-20 11:59:59','2018-09-21 23:59:59','QLCBNB','4h','0.005819000000000','0.005620000000000','0.711908500000000','0.687562428252277','122.34206908403506','122.342069084035060','test'),('2018-09-22 07:59:59','2018-09-22 11:59:59','QLCBNB','4h','0.005687000000000','0.005660000000000','0.711908500000000','0.708528593282926','125.18173026200105','125.181730262001054','test'),('2018-09-23 07:59:59','2018-09-25 03:59:59','QLCBNB','4h','0.006109000000000','0.005681000000000','0.711908500000000','0.662031787281061','116.53437551154036','116.534375511540361','test'),('2018-10-09 07:59:59','2018-10-10 11:59:59','QLCBNB','4h','0.006025000000000','0.005644000000000','0.711908500000000','0.666889887800830','118.15908713692947','118.159087136929472','test'),('2018-10-10 19:59:59','2018-10-11 03:59:59','QLCBNB','4h','0.005860000000000','0.005320000000000','0.711908500000000','0.646306010238908','121.48609215017066','121.486092150170663','test'),('2018-10-23 07:59:59','2018-10-23 11:59:59','QLCBNB','4h','0.005237000000000','0.005178000000000','0.711908500000000','0.703888144548406','135.93822799312585','135.938227993125849','test'),('2018-10-23 15:59:59','2018-10-23 19:59:59','QLCBNB','4h','0.005221000000000','0.005198000000000','0.711908500000000','0.708772339207049','136.35481708484966','136.354817084849657','test'),('2018-10-23 23:59:59','2018-10-24 11:59:59','QLCBNB','4h','0.005308000000000','0.005196000000000','0.711908500000000','0.696887069706104','134.1199133383572','134.119913338357208','test'),('2018-10-24 15:59:59','2018-10-24 23:59:59','QLCBNB','4h','0.005210000000000','0.005209000000000','0.711908500000000','0.711771857293666','136.64270633397314','136.642706333973138','test'),('2018-10-25 23:59:59','2018-10-31 15:59:59','QLCBNB','4h','0.005350000000000','0.005666000000000','0.711908500000000','0.753957674953271','133.06700934579442','133.067009345794418','test'),('2018-10-31 19:59:59','2018-10-31 23:59:59','QLCBNB','4h','0.005792000000000','0.005676000000000','0.711908500000000','0.697650664019337','122.91237914364642','122.912379143646419','test'),('2018-11-08 07:59:59','2018-11-08 11:59:59','QLCBNB','4h','0.005641000000000','0.005520000000000','0.711908500000000','0.696637993263606','126.20253501152278','126.202535011522784','test'),('2018-11-08 15:59:59','2018-11-09 11:59:59','QLCBNB','4h','0.005565000000000','0.005598000000000','0.711908500000000','0.716130059838275','127.92605570530101','127.926055705301010','test'),('2018-11-11 03:59:59','2018-11-11 07:59:59','QLCBNB','4h','0.005651000000000','0.005629000000000','0.711908500000000','0.709136957441161','125.97920721996108','125.979207219961083','test'),('2018-11-11 19:59:59','2018-11-12 07:59:59','QLCBNB','4h','0.005626000000000','0.005573000000000','0.711908500000000','0.705201932189833','126.53901528617136','126.539015286171363','test'),('2018-11-12 11:59:59','2018-11-12 19:59:59','QLCBNB','4h','0.005577000000000','0.005429000000000','0.711908500000000','0.693016181907836','127.6507979200287','127.650797920028694','test'),('2018-11-29 07:59:59','2018-12-03 19:59:59','QLCBNB','4h','0.005030000000000','0.005601000000000','0.711908500000000','0.792723560337972','141.53250497017893','141.532504970178934','test'),('2018-12-18 15:59:59','2018-12-18 19:59:59','QLCBNB','4h','0.004129000000000','0.004066000000000','0.711908500000000','0.701046248728506','172.41668684911602','172.416686849116019','test'),('2018-12-19 11:59:59','2018-12-19 15:59:59','QLCBNB','4h','0.004195000000000','0.003946000000000','0.711908500000000','0.669652190941597','169.704052443385','169.704052443384995','test'),('2018-12-21 03:59:59','2018-12-22 15:59:59','QLCBNB','4h','0.004174000000000','0.004066000000000','0.711908500000000','0.693488251317681','170.55785816962148','170.557858169621483','test'),('2018-12-22 19:59:59','2018-12-22 23:59:59','QLCBNB','4h','0.004099000000000','0.004131000000000','0.711908500000000','0.717466214564528','173.67858014149792','173.678580141497918','test'),('2018-12-23 03:59:59','2018-12-23 11:59:59','QLCBNB','4h','0.004260000000000','0.004026000000000','0.711908500000000','0.672803666901409','167.11467136150236','167.114671361502360','test'),('2018-12-24 15:59:59','2018-12-25 03:59:59','QLCBNB','4h','0.004264000000000','0.004232000000000','0.711908500000000','0.706565847091932','166.95790337711068','166.957903377110682','test'),('2018-12-25 07:59:59','2018-12-28 15:59:59','QLCBNB','4h','0.004445000000000','0.004376000000000','0.711908500000000','0.700857501912261','160.15939257592802','160.159392575928024','test'),('2018-12-28 23:59:59','2018-12-29 19:59:59','QLCBNB','4h','0.005261000000000','0.004440000000000','0.711908500000000','0.600812343660901','135.31809541912185','135.318095419121846','test'),('2019-01-03 15:59:59','2019-01-03 19:59:59','QLCBNB','4h','0.004736000000000','0.004357000000000','0.711908500000000','0.654937781777872','150.3185177364865','150.318517736486513','test'),('2019-01-03 23:59:59','2019-01-04 03:59:59','QLCBNB','4h','0.004390000000000','0.004321000000000','0.711908500000000','0.700719049772210','162.16594533029615','162.165945330296154','test'),('2019-01-04 11:59:59','2019-01-04 15:59:59','QLCBNB','4h','0.004332000000000','0.004294000000000','0.711908500000000','0.705663688596491','164.33714219759926','164.337142197599263','test'),('2019-01-06 19:59:59','2019-01-08 11:59:59','QLCBNB','4h','0.004800000000000','0.004400000000000','0.711908500000000','0.652582791666667','148.31427083333335','148.314270833333353','test'),('2019-01-14 23:59:59','2019-01-15 23:59:59','QLCBNB','4h','0.005425000000000','0.004468000000000','0.711908500000000','0.586323903778802','131.2273732718894','131.227373271889405','test'),('2019-02-26 15:59:59','2019-02-27 23:59:59','QLCBNB','4h','0.002749000000000','0.002531000000000','0.474605666666667','0.436968694919365','172.6466593912938','172.646659391293809','test'),('2019-03-02 15:59:59','2019-03-03 03:59:59','QLCBNB','4h','0.002770000000000','0.002565000000000','0.521171076993531','0.482600654327945','188.14840324676223','188.148403246762228','test'),('2019-03-03 11:59:59','2019-03-04 23:59:59','QLCBNB','4h','0.002694000000000','0.002543000000000','0.521171076993531','0.491959186634948','193.4562275402862','193.456227540286193','test'),('2019-03-16 07:59:59','2019-03-16 11:59:59','QLCBNB','4h','0.002395000000000','0.002238000000000','0.521171076993531','0.487006626434874','217.60796534176663','217.607965341766629','test'),('2019-03-20 19:59:59','2019-03-24 11:59:59','QLCBNB','4h','0.002542000000000','0.002117000000000','0.521171076993531','0.434035865458421','205.02402714143628','205.024027141436278','test'),('2019-03-26 19:59:59','2019-03-27 07:59:59','QLCBNB','4h','0.002526000000000','0.002420000000000','0.521171076993531','0.499300873445901','206.3226749776449','206.322674977644908','test'),('2019-03-27 11:59:59','2019-03-28 11:59:59','QLCBNB','4h','0.002440000000000','0.002371000000000','0.521171076993531','0.506433042439206','213.59470368587338','213.594703685873384','test'),('2019-03-28 15:59:59','2019-03-28 19:59:59','QLCBNB','4h','0.002398000000000','0.002914000000000','0.521171076993531','0.633316312910404','217.33572852107216','217.335728521072156','test'),('2019-03-28 23:59:59','2019-03-31 07:59:59','QLCBNB','4h','0.003310000000000','0.002687000000000','0.521171076993531','0.423077548000489','157.4534975811272','157.453497581127209','test'),('2019-05-06 19:59:59','2019-05-10 03:59:59','QLCBNB','4h','0.001528000000000','0.001548000000000','0.521171076993531','0.527992687948944','341.08054777063546','341.080547770635462','test'),('2019-05-10 07:59:59','2019-05-11 15:59:59','QLCBNB','4h','0.001568000000000','0.001560000000000','0.521171076993531','0.518512040886421','332.37951338873154','332.379513388731539','test'),('2019-05-11 19:59:59','2019-05-11 23:59:59','QLCBNB','4h','0.001575000000000','0.001569000000000','0.521171076993531','0.519185663366889','330.90227110700386','330.902271107003855','test'),('2019-05-23 11:59:59','2019-05-24 15:59:59','QLCBNB','4h','0.001460000000000','0.001406000000000','0.521171076993531','0.501894886474592','356.96649109145966','356.966491091459659','test'),('2019-06-04 07:59:59','2019-06-05 15:59:59','QLCBNB','4h','0.001351000000000','0.001296000000000','0.521171076993531','0.499953897693276','385.7668963682687','385.766896368268704','test'),('2019-06-05 19:59:59','2019-06-05 23:59:59','QLCBNB','4h','0.001315000000000','0.001298000000000','0.521171076993531','0.514433504135060','396.3278152042061','396.327815204206104','test'),('2019-07-08 03:59:59','2019-07-08 07:59:59','QLCBNB','4h','0.001032000000000','0.000959000000000','0.521171076993531','0.484305293446508','505.0107335208634','505.010733520863425','test'),('2019-07-27 07:59:59','2019-07-30 15:59:59','QLCBNB','4h','0.000827000000000','0.000773000000000','0.521171076993531','0.487140559269649','630.1947726644873','630.194772664487346','test'),('2019-08-22 15:59:59','2019-08-28 11:59:59','QLCBNB','4h','0.000589000000000','0.000613000000000','0.521171076993531','0.542407249910076','884.8405381893566','884.840538189356607','test'),('2019-08-29 23:59:59','2019-09-02 03:59:59','QLCBNB','4h','0.000696000000000','0.000668000000000','0.521171076993531','0.500204424470803','748.8090186688664','748.809018668866429','test'),('2019-09-02 07:59:59','2019-09-02 15:59:59','QLCBNB','4h','0.000679000000000','0.000658000000000','0.521171076993531','0.505052383890638','767.5568144234625','767.556814423462470','test'),('2019-09-04 15:59:59','2019-09-05 15:59:59','QLCBNB','4h','0.000715000000000','0.000650000000000','0.521171076993531','0.473791888175937','728.9105971937497','728.910597193749709','test'),('2019-09-09 19:59:59','2019-09-12 07:59:59','QLCBNB','4h','0.000743000000000','0.000667000000000','0.521171076993531','0.467861518646952','701.4415571918319','701.441557191831862','test'),('2019-09-13 19:59:59','2019-09-16 23:59:59','QLCBNB','4h','0.000694000000000','0.000887000000000','0.521171076993531','0.666107702151674','750.9669697313128','750.966969731312815','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:39:25
