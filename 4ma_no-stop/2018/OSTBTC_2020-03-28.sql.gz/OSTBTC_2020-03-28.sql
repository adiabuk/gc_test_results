-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-02 23:59:59','2018-07-05 19:59:59','OSTBTC','4h','0.000012130000000','0.000011130000000','0.001467500000000','0.001346518961253','120.98103874690848','120.981038746908482','test'),('2018-07-07 19:59:59','2018-07-09 19:59:59','OSTBTC','4h','0.000011910000000','0.000011480000000','0.001467500000000','0.001414517212427','123.215785054576','123.215785054576003','test'),('2018-08-07 07:59:59','2018-08-07 11:59:59','OSTBTC','4h','0.000015980000000','0.000011450000000','0.001467500000000','0.001051494055069','91.83354192740927','91.833541927409271','test'),('2018-08-07 19:59:59','2018-08-08 03:59:59','OSTBTC','4h','0.000010660000000','0.000008010000000','0.001467500000000','0.001102689962477','137.6641651031895','137.664165103189504','test'),('2018-08-27 15:59:59','2018-08-30 11:59:59','OSTBTC','4h','0.000004570000000','0.000004930000000','0.001467500000000','0.001583101750547','321.1159737417943','321.115973741794278','test'),('2018-08-31 03:59:59','2018-09-02 19:59:59','OSTBTC','4h','0.000005380000000','0.000005230000000','0.001467500000000','0.001426584572491','272.7695167286245','272.769516728624524','test'),('2018-09-04 15:59:59','2018-09-05 11:59:59','OSTBTC','4h','0.000005470000000','0.000004810000000','0.001467500000000','0.001290434186472','268.2815356489945','268.281535648994520','test'),('2018-09-18 15:59:59','2018-09-19 19:59:59','OSTBTC','4h','0.000004880000000','0.000004940000000','0.001467500000000','0.001485543032787','300.71721311475414','300.717213114754145','test'),('2018-09-20 03:59:59','2018-09-21 15:59:59','OSTBTC','4h','0.000004900000000','0.000004770000000','0.001467500000000','0.001428566326531','299.4897959183674','299.489795918367406','test'),('2018-09-21 19:59:59','2018-09-24 15:59:59','OSTBTC','4h','0.000005000000000','0.000005130000000','0.001467500000000','0.001505655000000','293.5','293.500000000000000','test'),('2018-09-25 03:59:59','2018-09-28 07:59:59','OSTBTC','4h','0.000007850000000','0.000007340000000','0.001467500000000','0.001372159235669','186.94267515923568','186.942675159235677','test'),('2018-10-10 19:59:59','2018-10-11 03:59:59','OSTBTC','4h','0.000007420000000','0.000006670000000','0.001467500000000','0.001319167789757','197.77628032345015','197.776280323450152','test'),('2018-10-15 11:59:59','2018-10-15 19:59:59','OSTBTC','4h','0.000007240000000','0.000006860000000','0.001467500000000','0.001390476519337','202.69337016574585','202.693370165745847','test'),('2018-10-15 23:59:59','2018-10-18 19:59:59','OSTBTC','4h','0.000007070000000','0.000007170000000','0.001467500000000','0.001488256718529','207.56718528995756','207.567185289957564','test'),('2018-10-20 23:59:59','2018-10-21 23:59:59','OSTBTC','4h','0.000007310000000','0.000007190000000','0.001467500000000','0.001443409712722','200.75239398084815','200.752393980848154','test'),('2018-10-22 11:59:59','2018-10-25 03:59:59','OSTBTC','4h','0.000007420000000','0.000007390000000','0.001467500000000','0.001461566711590','197.77628032345015','197.776280323450152','test'),('2018-10-28 07:59:59','2018-10-29 15:59:59','OSTBTC','4h','0.000007680000000','0.000007610000000','0.001467500000000','0.001454124348958','191.08072916666669','191.080729166666686','test'),('2018-10-30 03:59:59','2018-10-30 07:59:59','OSTBTC','4h','0.000007560000000','0.000007530000000','0.001467500000000','0.001461676587302','194.11375661375664','194.113756613756635','test'),('2018-10-30 11:59:59','2018-11-02 15:59:59','OSTBTC','4h','0.000007720000000','0.000008080000000','0.001467500000000','0.001535932642487','190.09067357512953','190.090673575129529','test'),('2018-11-09 15:59:59','2018-11-10 07:59:59','OSTBTC','4h','0.000008180000000','0.000007850000000','0.001467500000000','0.001408297677262','179.40097799511003','179.400977995110026','test'),('2018-11-10 11:59:59','2018-11-11 11:59:59','OSTBTC','4h','0.000007920000000','0.000007810000000','0.001467500000000','0.001447118055556','185.29040404040404','185.290404040404042','test'),('2018-11-29 11:59:59','2018-11-30 11:59:59','OSTBTC','4h','0.000006640000000','0.000006120000000','0.001467500000000','0.001352575301205','221.00903614457832','221.009036144578317','test'),('2018-11-30 19:59:59','2018-12-06 23:59:59','OSTBTC','4h','0.000006250000000','0.000006630000000','0.000978333333333','0.001037816000000','156.53333333333333','156.533333333333331','test'),('2018-12-11 15:59:59','2018-12-14 11:59:59','OSTBTC','4h','0.000006890000000','0.000006850000000','0.001103587256774','0.001097180364137','160.1723159323294','160.172315932329411','test'),('2018-12-16 11:59:59','2018-12-17 23:59:59','OSTBTC','4h','0.000007260000000','0.000007060000000','0.001103587256774','0.001073185403970','152.0092640184573','152.009264018457287','test'),('2019-01-06 15:59:59','2019-01-07 11:59:59','OSTBTC','4h','0.000006740000000','0.000006390000000','0.001103587256774','0.001046279313173','163.73698171721068','163.736981717210682','test'),('2019-01-07 23:59:59','2019-01-08 03:59:59','OSTBTC','4h','0.000006440000000','0.000006320000000','0.001103587256774','0.001083023519070','171.36448086552792','171.364480865527923','test'),('2019-01-19 07:59:59','2019-01-20 15:59:59','OSTBTC','4h','0.000006130000000','0.000006840000000','0.001103587256774','0.001231408945568','180.03054759771615','180.030547597716151','test'),('2019-01-20 23:59:59','2019-01-22 11:59:59','OSTBTC','4h','0.000007000000000','0.000006180000000','0.001106872572286','0.000977210356675','158.12465318367856','158.124653183678561','test'),('2019-02-09 07:59:59','2019-02-09 19:59:59','OSTBTC','4h','0.000005840000000','0.000005670000000','0.001106872572286','0.001074651966586','189.53297470650682','189.532974706506820','test'),('2019-02-09 23:59:59','2019-02-10 07:59:59','OSTBTC','4h','0.000005740000000','0.000005540000000','0.001106872572286','0.001068305583705','192.83494290696862','192.834942906968621','test'),('2019-02-10 11:59:59','2019-02-10 15:59:59','OSTBTC','4h','0.000005720000000','0.000005710000000','0.001106872572286','0.001104937480376','193.5091909590909','193.509190959090887','test'),('2019-02-10 19:59:59','2019-02-11 03:59:59','OSTBTC','4h','0.000005890000000','0.000005630000000','0.001106872572286','0.001058012322915','187.92403604176567','187.924036041765675','test'),('2019-02-11 07:59:59','2019-02-11 11:59:59','OSTBTC','4h','0.000005720000000','0.000005670000000','0.001106872572286','0.001097197112738','193.5091909590909','193.509190959090887','test'),('2019-02-17 03:59:59','2019-02-18 23:59:59','OSTBTC','4h','0.000006130000000','0.000005850000000','0.001106872572286','0.001056313955607','180.5664881380098','180.566488138009788','test'),('2019-02-23 11:59:59','2019-02-23 19:59:59','OSTBTC','4h','0.000005900000000','0.000005790000000','0.001106872572286','0.001086235965006','187.60552072644066','187.605520726440659','test'),('2019-02-24 07:59:59','2019-02-24 15:59:59','OSTBTC','4h','0.000005800000000','0.000005630000000','0.001106872572286','0.001074429755512','190.84009866999997','190.840098669999975','test'),('2019-02-26 03:59:59','2019-02-27 23:59:59','OSTBTC','4h','0.000006110000000','0.000005960000000','0.001106872572286','0.001079698941215','181.1575404723404','181.157540472340401','test'),('2019-03-02 03:59:59','2019-03-02 11:59:59','OSTBTC','4h','0.000005970000000','0.000006010000000','0.001106872572286','0.001114288803926','185.40579100268008','185.405791002680076','test'),('2019-03-02 15:59:59','2019-03-04 07:59:59','OSTBTC','4h','0.000006150000000','0.000006210000000','0.001106872572286','0.001117671329089','179.97928004650404','179.979280046504044','test'),('2019-03-04 15:59:59','2019-03-06 11:59:59','OSTBTC','4h','0.000006260000000','0.000006110000000','0.001106872572286','0.001080350066560','176.81670483801915','176.816704838019149','test'),('2019-03-07 23:59:59','2019-03-10 19:59:59','OSTBTC','4h','0.000006240000000','0.000006430000000','0.001106872572286','0.001140575423045','177.38342504583332','177.383425045833320','test'),('2019-03-11 15:59:59','2019-03-16 11:59:59','OSTBTC','4h','0.000006540000000','0.000006850000000','0.001106872572286','0.001159339009199','169.2465706859327','169.246570685932710','test'),('2019-03-20 15:59:59','2019-03-21 15:59:59','OSTBTC','4h','0.000006910000000','0.000006650000000','0.001106872572286','0.001065224689682','160.1841638619392','160.184163861939197','test'),('2019-03-27 03:59:59','2019-03-30 03:59:59','OSTBTC','4h','0.000007510000000','0.000007100000000','0.001106872572286','0.001046444109618','147.38649431238346','147.386494312383462','test'),('2019-05-22 19:59:59','2019-05-25 03:59:59','OSTBTC','4h','0.000003370000000','0.000003160000000','0.001106872572286','0.001037898317040','328.44883450623144','328.448834506231435','test'),('2019-05-26 03:59:59','2019-05-26 23:59:59','OSTBTC','4h','0.000003330000000','0.000003260000000','0.001106872572286','0.001083604980676','332.3941658516516','332.394165851651621','test'),('2019-05-29 03:59:59','2019-05-30 15:59:59','OSTBTC','4h','0.000003700000000','0.000003260000000','0.001106872572286','0.000975244482609','299.1547492664865','299.154749266486476','test'),('2019-06-04 15:59:59','2019-06-04 19:59:59','OSTBTC','4h','0.000003310000000','0.000003170000000','0.001106872572286','0.001060056209712','334.4025898145015','334.402589814501482','test'),('2019-06-05 11:59:59','2019-06-05 23:59:59','OSTBTC','4h','0.000003430000000','0.000003380000000','0.001106872572286','0.001090737403594','322.7033738443148','322.703373844314797','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 22:44:20
