-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-19 07:59:59','2018-04-20 03:59:59','EVXETH','4h','0.002564800000000','0.002544100000000','0.072144500000000','0.071562235827355','28.128703992514037','28.128703992514037','test'),('2018-04-20 15:59:59','2018-04-20 19:59:59','EVXETH','4h','0.002521000000000','0.002519200000000','0.072144500000000','0.072092988655296','28.617413724712417','28.617413724712417','test'),('2018-04-21 19:59:59','2018-04-24 07:59:59','EVXETH','4h','0.002727200000000','0.002650700000000','0.072144500000000','0.070120792809475','26.453688765033736','26.453688765033736','test'),('2018-05-01 23:59:59','2018-05-03 03:59:59','EVXETH','4h','0.002604900000000','0.002549300000000','0.072144500000000','0.070604619697493','27.69568889400745','27.695688894007450','test'),('2018-07-02 19:59:59','2018-07-05 19:59:59','EVXETH','4h','0.001510500000000','0.001535600000000','0.072144500000000','0.073343326183383','47.761999337967566','47.761999337967566','test'),('2018-07-07 11:59:59','2018-07-07 23:59:59','EVXETH','4h','0.001650800000000','0.001495300000000','0.072144500000000','0.065348722346741','43.70275018173007','43.702750181730067','test'),('2018-07-18 03:59:59','2018-07-19 23:59:59','EVXETH','4h','0.001557300000000','0.001502200000000','0.072144500000000','0.069591901303538','46.32665510820009','46.326655108200093','test'),('2018-07-23 19:59:59','2018-07-24 07:59:59','EVXETH','4h','0.001601500000000','0.001436000000000','0.072144500000000','0.064689042772401','45.04807992507025','45.048079925070247','test'),('2018-08-09 03:59:59','2018-08-10 19:59:59','EVXETH','4h','0.001435900000000','0.001371900000000','0.072144500000000','0.068928922313532','50.24340135106902','50.243401351069018','test'),('2018-08-11 03:59:59','2018-08-11 07:59:59','EVXETH','4h','0.001427000000000','0.001412900000000','0.072144500000000','0.071431649649615','50.55676243868255','50.556762438682547','test'),('2018-08-11 15:59:59','2018-08-11 19:59:59','EVXETH','4h','0.001438600000000','0.001418900000000','0.072144500000000','0.071156562665091','50.14910329487002','50.149103294870017','test'),('2018-08-14 03:59:59','2018-08-14 07:59:59','EVXETH','4h','0.001418300000000','0.001402200000000','0.072144500000000','0.071325543185504','50.866882887964465','50.866882887964465','test'),('2018-08-14 11:59:59','2018-08-14 15:59:59','EVXETH','4h','0.001416600000000','0.001400000000000','0.072144500000000','0.071299096428067','50.927926020048','50.927926020047998','test'),('2018-08-16 11:59:59','2018-08-16 19:59:59','EVXETH','4h','0.001448400000000','0.001410000000000','0.072144500000000','0.070231804059652','49.80979011322839','49.809790113228388','test'),('2018-08-17 11:59:59','2018-08-18 07:59:59','EVXETH','4h','0.001476900000000','0.001460900000000','0.072144500000000','0.071362922371183','48.84860180106981','48.848601801069812','test'),('2018-08-18 15:59:59','2018-08-18 19:59:59','EVXETH','4h','0.001428800000000','0.001400900000000','0.072144500000000','0.070735743316069','50.49307110862262','50.493071108622622','test'),('2018-08-20 11:59:59','2018-08-21 19:59:59','EVXETH','4h','0.001465300000000','0.001465200000000','0.072144500000000','0.072139576468982','49.23531017539071','49.235310175390708','test'),('2018-08-22 03:59:59','2018-08-22 11:59:59','EVXETH','4h','0.001477500000000','0.001438000000000','0.072144500000000','0.070215763790186','48.82876480541455','48.828764805414551','test'),('2018-08-22 15:59:59','2018-08-26 19:59:59','EVXETH','4h','0.001484400000000','0.001549600000000','0.072144500000000','0.075313336836432','48.60179196981945','48.601791969819452','test'),('2018-08-27 11:59:59','2018-08-29 19:59:59','EVXETH','4h','0.001629900000000','0.001568800000000','0.072144500000000','0.069440021841831','44.26314497821952','44.263144978219522','test'),('2018-08-31 03:59:59','2018-09-13 03:59:59','EVXETH','4h','0.001651300000000','0.001934900000000','0.072144500000000','0.084534847120451','43.68951734996669','43.689517349966692','test'),('2018-09-13 11:59:59','2018-09-13 15:59:59','EVXETH','4h','0.001969000000000','0.001884500000000','0.072144500000000','0.069048405408837','36.64017267648553','36.640172676485527','test'),('2018-09-18 11:59:59','2018-09-19 11:59:59','EVXETH','4h','0.001897300000000','0.001883000000000','0.072144500000000','0.071600745006061','38.02482475096189','38.024824750961891','test'),('2018-09-19 19:59:59','2018-09-21 03:59:59','EVXETH','4h','0.001930000000000','0.001877700000000','0.072144500000000','0.070189496191710','37.380569948186526','37.380569948186526','test'),('2018-09-21 07:59:59','2018-09-21 15:59:59','EVXETH','4h','0.001896700000000','0.001836000000000','0.072144500000000','0.069835662993620','38.0368534823641','38.036853482364101','test'),('2018-09-25 11:59:59','2018-09-28 07:59:59','EVXETH','4h','0.001907900000000','0.001879900000000','0.072144500000000','0.071085720189737','37.81356465223544','37.813564652235442','test'),('2018-09-28 11:59:59','2018-09-28 15:59:59','EVXETH','4h','0.001931100000000','0.001911700000000','0.072144500000000','0.071419730024338','37.35927709595567','37.359277095955669','test'),('2018-09-28 19:59:59','2018-09-29 11:59:59','EVXETH','4h','0.001956800000000','0.001905300000000','0.072144500000000','0.070245766480989','36.86861201962388','36.868612019623882','test'),('2018-09-29 15:59:59','2018-10-02 07:59:59','EVXETH','4h','0.001920100000000','0.001964800000000','0.072144500000000','0.073824026665278','37.57330347377741','37.573303473777408','test'),('2018-10-02 19:59:59','2018-10-02 23:59:59','EVXETH','4h','0.001997300000000','0.001963800000000','0.072144500000000','0.070934446052170','36.12101336804686','36.121013368046860','test'),('2018-10-04 11:59:59','2018-10-08 23:59:59','EVXETH','4h','0.001990400000000','0.002209200000000','0.072144500000000','0.080075175542605','36.24623191318328','36.246231913183280','test'),('2018-10-10 19:59:59','2018-10-13 03:59:59','EVXETH','4h','0.002792700000000','0.002435900000000','0.072144500000000','0.062927198607083','25.833243814229956','25.833243814229956','test'),('2018-10-13 15:59:59','2018-10-15 07:59:59','EVXETH','4h','0.002949800000000','0.002444700000000','0.072144500000000','0.059791056732660','24.45742084209099','24.457420842090990','test'),('2018-10-15 15:59:59','2018-10-19 03:59:59','EVXETH','4h','0.002712500000000','0.002669200000000','0.072144500000000','0.070992847705069','26.597050691244238','26.597050691244238','test'),('2018-10-21 03:59:59','2018-10-22 03:59:59','EVXETH','4h','0.002709000000000','0.002650300000000','0.072144500000000','0.070581236009598','26.63141380583241','26.631413805832409','test'),('2018-10-24 07:59:59','2018-10-25 19:59:59','EVXETH','4h','0.002803500000000','0.002684400000000','0.072144500000000','0.069079613269128','25.733725700017835','25.733725700017835','test'),('2018-10-26 19:59:59','2018-10-26 23:59:59','EVXETH','4h','0.002775600000000','0.002742100000000','0.072144500000000','0.071273754665658','25.99239804006341','25.992398040063410','test'),('2018-10-27 07:59:59','2018-10-27 11:59:59','EVXETH','4h','0.002748500000000','0.002717400000000','0.072144500000000','0.071328166017828','26.24868109878115','26.248681098781152','test'),('2018-10-31 19:59:59','2018-11-01 11:59:59','EVXETH','4h','0.002849300000000','0.002694700000000','0.072144500000000','0.068230015845997','25.320078615800373','25.320078615800373','test'),('2018-11-01 19:59:59','2018-11-01 23:59:59','EVXETH','4h','0.002691400000000','0.002716100000000','0.072144500000000','0.072806597477149','26.805565876495503','26.805565876495503','test'),('2018-11-02 03:59:59','2018-11-02 07:59:59','EVXETH','4h','0.002718400000000','0.002683900000000','0.072144500000000','0.071228893301207','26.539324602707474','26.539324602707474','test'),('2018-11-02 11:59:59','2018-11-02 15:59:59','EVXETH','4h','0.002690800000000','0.002706500000000','0.072144500000000','0.072565441225658','26.811543035528466','26.811543035528466','test'),('2018-11-24 07:59:59','2018-11-24 19:59:59','EVXETH','4h','0.002299100000000','0.002244000000000','0.072144500000000','0.070415492149102','31.379452829368013','31.379452829368013','test'),('2018-11-27 19:59:59','2018-11-27 23:59:59','EVXETH','4h','0.002255700000000','0.002218100000000','0.072144500000000','0.070941931750676','31.98319812031742','31.983198120317422','test'),('2018-11-28 07:59:59','2018-11-28 11:59:59','EVXETH','4h','0.002221300000000','0.002219800000000','0.072144500000000','0.072095782244632','32.47850357898528','32.478503578985283','test'),('2018-11-28 15:59:59','2018-12-03 03:59:59','EVXETH','4h','0.002285200000000','0.002371700000000','0.072144500000000','0.074875332859268','31.570322072466308','31.570322072466308','test'),('2019-01-11 11:59:59','2019-01-14 15:59:59','EVXETH','4h','0.001717800000000','0.001677900000000','0.072144500000000','0.070468772004890','41.99819536616602','41.998195366166023','test'),('2019-01-15 19:59:59','2019-01-21 11:59:59','EVXETH','4h','0.001787200000000','0.001963500000000','0.072144500000000','0.079261261050806','40.36733437779767','40.367334377797668','test'),('2019-01-21 23:59:59','2019-01-29 07:59:59','EVXETH','4h','0.002303000000000','0.002542400000000','0.072144500000000','0.079644019452888','31.326313504125057','31.326313504125057','test'),('2019-01-30 11:59:59','2019-01-31 23:59:59','EVXETH','4h','0.003028500000000','0.002721000000000','0.072144500000000','0.064819278355622','23.821859006108635','23.821859006108635','test'),('2019-03-01 15:59:59','2019-03-06 03:59:59','EVXETH','4h','0.002014600000000','0.002030000000000','0.072144500000000','0.072695986796386','35.81083093418048','35.810830934180480','test'),('2019-03-06 23:59:59','2019-03-10 15:59:59','EVXETH','4h','0.002185600000000','0.002145500000000','0.072144500000000','0.070820838556918','33.0090135431918','33.009013543191799','test'),('2019-03-12 15:59:59','2019-03-16 07:59:59','EVXETH','4h','0.002219300000000','0.002200800000000','0.072144500000000','0.071543106204659','32.50777272112828','32.507772721128283','test'),('2019-03-20 03:59:59','2019-03-21 15:59:59','EVXETH','4h','0.002249400000000','0.002176200000000','0.072144500000000','0.069796772872766','32.072774962212144','32.072774962212144','test'),('2019-03-25 15:59:59','2019-03-26 03:59:59','EVXETH','4h','0.006822200000000','0.004785200000000','0.072144500000000','0.050603304124769','10.574961156225266','10.574961156225266','test'),('2019-03-26 07:59:59','2019-03-28 23:59:59','EVXETH','4h','0.006180900000000','0.006441100000000','0.048096333333333','0.050121065319505','7.78144498913319','7.781444989133190','test'),('2019-03-29 03:59:59','2019-03-31 03:59:59','EVXETH','4h','0.007919100000000','0.006754800000000','0.053792631366053','0.045883808305415','6.792770815629648','6.792770815629648','test'),('2019-04-01 07:59:59','2019-04-02 23:59:59','EVXETH','4h','0.009040000000000','0.007014800000000','0.053792631366053','0.041741653817101','5.950512319253651','5.950512319253651','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  6:45:47
