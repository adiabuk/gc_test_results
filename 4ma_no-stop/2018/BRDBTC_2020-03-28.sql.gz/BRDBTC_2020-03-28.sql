-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-16 19:59:59','2018-06-20 19:59:59','BRDBTC','4h','0.000070360000000','0.000071280000000','0.001467500000000','0.001486688459352','20.857021034678798','20.857021034678798','test'),('2018-06-29 11:59:59','2018-07-05 11:59:59','BRDBTC','4h','0.000069770000000','0.000072840000000','0.001472297114838','0.001537080720149','21.102151567120536','21.102151567120536','test'),('2018-08-06 19:59:59','2018-08-11 03:59:59','BRDBTC','4h','0.000052610000000','0.000053510000000','0.001488493016166','0.001513956686847','28.292967423793005','28.292967423793005','test'),('2018-08-17 19:59:59','2018-08-20 15:59:59','BRDBTC','4h','0.000054150000000','0.000052580000000','0.001494858933836','0.001451517686816','27.605889821532777','27.605889821532777','test'),('2018-08-21 03:59:59','2018-08-22 23:59:59','BRDBTC','4h','0.000054780000000','0.000053730000000','0.001494858933836','0.001466206106517','27.288406970354142','27.288406970354142','test'),('2018-09-09 15:59:59','2018-09-10 03:59:59','BRDBTC','4h','0.000054460000000','0.000050270000000','0.001494858933836','0.001379848670656','27.448750162247524','27.448750162247524','test'),('2018-09-10 11:59:59','2018-09-10 15:59:59','BRDBTC','4h','0.000049670000000','0.000050780000000','0.001494858933836','0.001528265284079','30.0958110295148','30.095811029514799','test'),('2018-09-12 11:59:59','2018-09-12 15:59:59','BRDBTC','4h','0.000052680000000','0.000048190000000','0.001494858933836','0.001367449734654','28.376213626347763','28.376213626347763','test'),('2018-09-12 19:59:59','2018-09-12 23:59:59','BRDBTC','4h','0.000049620000000','0.000048070000000','0.001494858933836','0.001448163420989','30.126137320354694','30.126137320354694','test'),('2018-09-15 11:59:59','2018-09-15 15:59:59','BRDBTC','4h','0.000050070000000','0.000049830000000','0.001494858933836','0.001487693642362','29.855381143119633','29.855381143119633','test'),('2018-09-15 19:59:59','2018-09-15 23:59:59','BRDBTC','4h','0.000050110000000','0.000049040000000','0.001494858933836','0.001462939176119','29.831549268329674','29.831549268329674','test'),('2018-09-16 03:59:59','2018-09-16 15:59:59','BRDBTC','4h','0.000050320000000','0.000049730000000','0.001494858933836','0.001477331772251','29.70705353410175','29.707053534101750','test'),('2018-09-16 19:59:59','2018-09-17 07:59:59','BRDBTC','4h','0.000050340000000','0.000049240000000','0.001494858933836','0.001462194157769','29.695250970123162','29.695250970123162','test'),('2018-09-17 11:59:59','2018-09-17 15:59:59','BRDBTC','4h','0.000052460000000','0.000050730000000','0.001494858933836','0.001445562213372','28.495214140983606','28.495214140983606','test'),('2018-09-17 23:59:59','2018-09-18 03:59:59','BRDBTC','4h','0.000050200000000','0.000050090000000','0.001494858933836','0.001491583346531','29.7780664110757','29.778066411075699','test'),('2018-09-18 11:59:59','2018-09-22 19:59:59','BRDBTC','4h','0.000051190000000','0.000054230000000','0.001494858933836','0.001583633521819','29.202167099746042','29.202167099746042','test'),('2018-10-01 03:59:59','2018-10-01 11:59:59','BRDBTC','4h','0.000053820000000','0.000052510000000','0.001494858933836','0.001458473478553','27.775156704496467','27.775156704496467','test'),('2018-10-02 03:59:59','2018-10-03 03:59:59','BRDBTC','4h','0.000052730000000','0.000052150000000','0.001494858933836','0.001478416336043','28.349306539654847','28.349306539654847','test'),('2018-10-03 07:59:59','2018-10-03 11:59:59','BRDBTC','4h','0.000052170000000','0.000052040000000','0.001494858933836','0.001491133964286','28.65361191941729','28.653611919417290','test'),('2018-10-04 11:59:59','2018-10-07 19:59:59','BRDBTC','4h','0.000054070000000','0.000055200000000','0.001494858933836','0.001526099743809','27.646734489291656','27.646734489291656','test'),('2018-10-08 11:59:59','2018-10-11 07:59:59','BRDBTC','4h','0.000055740000000','0.000055730000000','0.001494858933836','0.001494590749600','26.81842364255472','26.818423642554720','test'),('2018-10-11 11:59:59','2018-10-11 15:59:59','BRDBTC','4h','0.000056300000000','0.000059680000000','0.001494858933836','0.001584603573203','26.55166845179396','26.551668451793962','test'),('2018-10-12 03:59:59','2018-10-13 11:59:59','BRDBTC','4h','0.000058890000000','0.000057640000000','0.001494858933836','0.001463129036276','25.383918047817964','25.383918047817964','test'),('2018-10-13 15:59:59','2018-10-14 23:59:59','BRDBTC','4h','0.000059090000000','0.000057690000000','0.001494858933836','0.001459441731139','25.298001926485025','25.298001926485025','test'),('2018-10-17 03:59:59','2018-10-17 11:59:59','BRDBTC','4h','0.000058680000000','0.000057610000000','0.001494858933836','0.001467600940325','25.474760290320383','25.474760290320383','test'),('2018-10-17 23:59:59','2018-10-18 03:59:59','BRDBTC','4h','0.000057430000000','0.000056980000000','0.001494858933836','0.001483145778338','26.029234439073658','26.029234439073658','test'),('2018-10-20 19:59:59','2018-10-23 15:59:59','BRDBTC','4h','0.000059110000000','0.000057950000000','0.001494858933836','0.001465523180778','25.289442291253593','25.289442291253593','test'),('2018-10-24 11:59:59','2018-10-24 15:59:59','BRDBTC','4h','0.000060760000000','0.000059470000000','0.001494858933836','0.001463121474576','24.602681597037524','24.602681597037524','test'),('2018-10-24 19:59:59','2018-10-25 03:59:59','BRDBTC','4h','0.000060950000000','0.000059430000000','0.001494858933836','0.001457579432943','24.525987429630845','24.525987429630845','test'),('2018-10-25 07:59:59','2018-10-25 15:59:59','BRDBTC','4h','0.000061390000000','0.000058410000000','0.001494858933836','0.001422295330271','24.350202538459037','24.350202538459037','test'),('2018-11-18 15:59:59','2018-11-18 23:59:59','BRDBTC','4h','0.000055010000000','0.000054300000000','0.001494858933836','0.001475565171920','27.174312558371206','27.174312558371206','test'),('2018-11-21 07:59:59','2018-11-24 23:59:59','BRDBTC','4h','0.000056040000000','0.000059510000000','0.001494858933836','0.001587420684379','26.674856064168452','26.674856064168452','test'),('2018-12-02 19:59:59','2018-12-03 03:59:59','BRDBTC','4h','0.000058650000000','0.000058230000000','0.001494858933836','0.001484154061676','25.48779085824382','25.487790858243820','test'),('2018-12-03 07:59:59','2018-12-06 07:59:59','BRDBTC','4h','0.000059740000000','0.000058890000000','0.001494858933836','0.001473589598487','25.022747469635085','25.022747469635085','test'),('2018-12-23 15:59:59','2018-12-23 19:59:59','BRDBTC','4h','0.000055700000000','0.000054070000000','0.001494858933836','0.001451113510817','26.837682833680432','26.837682833680432','test'),('2018-12-24 03:59:59','2018-12-24 19:59:59','BRDBTC','4h','0.000054740000000','0.000053780000000','0.001494858933836','0.001468642920382','27.308347348118378','27.308347348118378','test'),('2018-12-24 23:59:59','2018-12-25 03:59:59','BRDBTC','4h','0.000053950000000','0.000053070000000','0.001494858933836','0.001470475692654','27.7082286160519','27.708228616051901','test'),('2018-12-30 15:59:59','2018-12-31 03:59:59','BRDBTC','4h','0.000057410000000','0.000052960000000','0.001494858933836','0.001378988488695','26.038302278975788','26.038302278975788','test'),('2018-12-31 07:59:59','2018-12-31 19:59:59','BRDBTC','4h','0.000053620000000','0.000052870000000','0.001494858933836','0.001473949866317','27.8787566922044','27.878756692204401','test'),('2019-01-02 03:59:59','2019-01-02 11:59:59','BRDBTC','4h','0.000054030000000','0.000053630000000','0.001494858933836','0.001483792052964','27.667202180936517','27.667202180936517','test'),('2019-01-02 15:59:59','2019-01-05 07:59:59','BRDBTC','4h','0.000056460000000','0.000054330000000','0.001494858933836','0.001438464149403','26.47642461629472','26.476424616294722','test'),('2019-01-05 11:59:59','2019-01-05 15:59:59','BRDBTC','4h','0.000055210000000','0.000054330000000','0.001494858933836','0.001471032165827','27.075872737475095','27.075872737475095','test'),('2019-01-16 03:59:59','2019-01-20 15:59:59','BRDBTC','4h','0.000055290000000','0.000055860000000','0.001494858933836','0.001510269850680','27.036696216965094','27.036696216965094','test'),('2019-01-22 07:59:59','2019-01-23 23:59:59','BRDBTC','4h','0.000057200000000','0.000056240000000','0.001494858933836','0.001469770392289','26.133897444685314','26.133897444685314','test'),('2019-01-24 11:59:59','2019-01-27 11:59:59','BRDBTC','4h','0.000057510000000','0.000057350000000','0.001494858933836','0.001490700049652','25.993026149121892','25.993026149121892','test'),('2019-01-27 19:59:59','2019-01-28 03:59:59','BRDBTC','4h','0.000059440000000','0.000057350000000','0.001494858933836','0.001442297440368','25.14903993667564','25.149039936675639','test'),('2019-02-18 03:59:59','2019-02-18 15:59:59','BRDBTC','4h','0.000055060000000','0.000054630000000','0.001494858933836','0.001483184590546','27.149635558227388','27.149635558227388','test'),('2019-02-18 19:59:59','2019-02-18 23:59:59','BRDBTC','4h','0.000055000000000','0.000055070000000','0.001494858933836','0.001496761481570','27.179253342472727','27.179253342472727','test'),('2019-02-19 03:59:59','2019-02-19 07:59:59','BRDBTC','4h','0.000055530000000','0.000054780000000','0.001494858933836','0.001474669050883','26.91984393725914','26.919843937259142','test'),('2019-02-19 11:59:59','2019-02-21 19:59:59','BRDBTC','4h','0.000055780000000','0.000055190000000','0.001494858933836','0.001479047410513','26.79919207307279','26.799192073072788','test'),('2019-02-23 11:59:59','2019-02-23 15:59:59','BRDBTC','4h','0.000056460000000','0.000055650000000','0.001494858933836','0.001473413029897','26.47642461629472','26.476424616294722','test'),('2019-02-27 15:59:59','2019-02-28 11:59:59','BRDBTC','4h','0.000060700000000','0.000057310000000','0.001494858933836','0.001411373401946','24.627000557429984','24.627000557429984','test'),('2019-02-28 19:59:59','2019-03-01 03:59:59','BRDBTC','4h','0.000057720000000','0.000057140000000','0.001494858933836','0.001479837828818','25.898456927165626','25.898456927165626','test'),('2019-03-06 19:59:59','2019-03-07 03:59:59','BRDBTC','4h','0.000057320000000','0.000056790000000','0.001494858933836','0.001481036965327','26.07918586594557','26.079185865945568','test'),('2019-03-07 11:59:59','2019-03-07 15:59:59','BRDBTC','4h','0.000056890000000','0.000056540000000','0.001494858933836','0.001485662227440','26.276303987273685','26.276303987273685','test'),('2019-03-07 19:59:59','2019-03-08 07:59:59','BRDBTC','4h','0.000057140000000','0.000056810000000','0.001494858933836','0.001486225691831','26.161339409100457','26.161339409100457','test'),('2019-03-08 15:59:59','2019-03-08 23:59:59','BRDBTC','4h','0.000057200000000','0.000057030000000','0.001494858933836','0.001490416171270','26.133897444685314','26.133897444685314','test'),('2019-03-09 03:59:59','2019-03-09 15:59:59','BRDBTC','4h','0.000061030000000','0.000057360000000','0.001494858933836','0.001404966548334','24.49383801140423','24.493838011404229','test'),('2019-03-09 19:59:59','2019-03-10 11:59:59','BRDBTC','4h','0.000059320000000','0.000058160000000','0.001494858933836','0.001465627032905','25.19991459602158','25.199914596021578','test'),('2019-03-10 15:59:59','2019-03-11 07:59:59','BRDBTC','4h','0.000058510000000','0.000057510000000','0.001494858933836','0.001469310156980','25.5487768558537','25.548776855853699','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','BRDBTC','4h','0.000087000000000','0.000058900000000','0.001494858933836','0.001012036680494','17.18228659581609','17.182286595816091','test'),('2019-03-12 11:59:59','2019-03-13 11:59:59','BRDBTC','4h','0.000060320000000','0.000059190000000','0.000996572622557','0.000977903407313','16.521429419053938','16.521429419053938','test'),('2019-03-13 19:59:59','2019-03-18 07:59:59','BRDBTC','4h','0.000061460000000','0.000064600000000','0.001047571551737','0.001101092128900','17.044769797225833','17.044769797225833','test'),('2019-03-23 07:59:59','2019-03-23 15:59:59','BRDBTC','4h','0.000063550000000','0.000063790000000','0.001060951696028','0.001064958437288','16.694755248280877','16.694755248280877','test'),('2019-03-23 19:59:59','2019-03-24 11:59:59','BRDBTC','4h','0.000064620000000','0.000063860000000','0.001061953381343','0.001049463678932','16.433818962291078','16.433818962291078','test'),('2019-03-25 15:59:59','2019-03-25 19:59:59','BRDBTC','4h','0.000066020000000','0.000063500000000','0.001061953381343','0.001021418353761','16.085328405680098','16.085328405680098','test'),('2019-03-26 03:59:59','2019-03-26 07:59:59','BRDBTC','4h','0.000063610000000','0.000063450000000','0.001061953381343','0.001059282220503','16.69475524827857','16.694755248278572','test'),('2019-03-26 11:59:59','2019-03-26 15:59:59','BRDBTC','4h','0.000064750000000','0.000065240000000','0.001061953381343','0.001069989785310','16.400824422285712','16.400824422285712','test'),('2019-03-26 19:59:59','2019-03-30 07:59:59','BRDBTC','4h','0.000066640000000','0.000068090000000','0.001061953381343','0.001085060110079','15.935674990141056','15.935674990141056','test'),('2019-03-31 15:59:59','2019-04-01 11:59:59','BRDBTC','4h','0.000071910000000','0.000070200000000','0.001061953381343','0.001036700422337','14.767812284007789','14.767812284007789','test'),('2019-04-30 07:59:59','2019-05-03 11:59:59','BRDBTC','4h','0.000063910000000','0.000060780000000','0.001061953381343','0.001009944085715','16.616388379643247','16.616388379643247','test'),('2019-05-04 11:59:59','2019-05-07 23:59:59','BRDBTC','4h','0.000062740000000','0.000061080000000','0.001061953381343','0.001033855794269','16.92625727355754','16.926257273557539','test'),('2019-05-09 11:59:59','2019-05-09 23:59:59','BRDBTC','4h','0.000066350000000','0.000062500000000','0.001061953381343','0.001000332876171','16.005326018733985','16.005326018733985','test'),('2019-05-12 19:59:59','2019-05-13 15:59:59','BRDBTC','4h','0.000064400000000','0.000063270000000','0.001061953381343','0.001043319727291','16.489959337624224','16.489959337624224','test'),('2019-06-10 03:59:59','2019-06-10 15:59:59','BRDBTC','4h','0.000056920000000','0.000055820000000','0.001061953381343','0.001041430740453','18.656946263931836','18.656946263931836','test'),('2019-06-10 19:59:59','2019-06-10 23:59:59','BRDBTC','4h','0.000056180000000','0.000056180000000','0.001061953381343','0.001061953381343','18.90269457712709','18.902694577127090','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:26:09
