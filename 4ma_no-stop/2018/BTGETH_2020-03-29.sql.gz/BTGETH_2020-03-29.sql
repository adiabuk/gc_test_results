-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-18 03:59:59','2018-04-21 15:59:59','BTGETH','4h','0.101469000000000','0.108155000000000','0.072144500000000','0.076898248701574','0.7110004040642954','0.711000404064295','test'),('2018-04-21 23:59:59','2018-04-22 07:59:59','BTGETH','4h','0.110998000000000','0.107706000000000','0.073332937175393','0.071158014841825','0.6606689956160786','0.660668995616079','test'),('2018-04-22 11:59:59','2018-04-22 15:59:59','BTGETH','4h','0.108252000000000','0.106351000000000','0.073332937175393','0.072045146524223','0.6774280121881628','0.677428012188163','test'),('2018-04-23 07:59:59','2018-04-25 11:59:59','BTGETH','4h','0.120969000000000','0.115250000000000','0.073332937175393','0.069866007071763','0.6062126427050981','0.606212642705098','test'),('2018-07-02 11:59:59','2018-07-05 15:59:59','BTGETH','4h','0.061034000000000','0.060714000000000','0.073332937175393','0.072948454102088','1.2015096040795787','1.201509604079579','test'),('2018-07-05 19:59:59','2018-07-05 23:59:59','BTGETH','4h','0.061558000000000','0.060761000000000','0.073332937175393','0.072383485423731','1.1912819970660677','1.191281997066068','test'),('2018-07-07 03:59:59','2018-07-09 07:59:59','BTGETH','4h','0.063633000000000','0.061708000000000','0.073332937175393','0.071114498565511','1.1524356414972265','1.152435641497227','test'),('2018-07-09 15:59:59','2018-07-10 07:59:59','BTGETH','4h','0.064197000000000','0.061500000000000','0.073332937175393','0.070252124496264','1.1423109674189293','1.142310967418929','test'),('2018-07-14 03:59:59','2018-07-14 15:59:59','BTGETH','4h','0.062818000000000','0.061205000000000','0.073332937175393','0.071449941415198','1.1673873280810119','1.167387328081012','test'),('2018-07-14 19:59:59','2018-07-16 11:59:59','BTGETH','4h','0.062534000000000','0.062603000000000','0.073332937175393','0.073413852719978','1.1726890519620206','1.172689051962021','test'),('2018-07-18 03:59:59','2018-07-20 07:59:59','BTGETH','4h','0.063850000000000','0.062000000000000','0.073332937175393','0.071208177053631','1.1485189847359907','1.148518984735991','test'),('2018-07-20 11:59:59','2018-07-20 15:59:59','BTGETH','4h','0.065063000000000','0.064664000000000','0.073332937175393','0.072883221639175','1.1271066070638152','1.127106607063815','test'),('2018-07-23 11:59:59','2018-07-25 07:59:59','BTGETH','4h','0.066652000000000','0.064597000000000','0.073332937175393','0.071071951970216','1.1002361095750015','1.100236109575002','test'),('2018-08-07 11:59:59','2018-08-07 19:59:59','BTGETH','4h','0.062214000000000','0.061000000000000','0.073332937175393','0.071901970098354','1.178720821284486','1.178720821284486','test'),('2018-08-07 23:59:59','2018-08-08 03:59:59','BTGETH','4h','0.061515000000000','0.060276000000000','0.073332937175393','0.071855907033796','1.1921147228382185','1.192114722838219','test'),('2018-08-11 03:59:59','2018-08-12 07:59:59','BTGETH','4h','0.063026000000000','0.060241000000000','0.073332937175393','0.070092493072428','1.1635346868814935','1.163534686881494','test'),('2018-08-12 11:59:59','2018-08-12 15:59:59','BTGETH','4h','0.060996000000000','0.061427000000000','0.073332937175393','0.073851110431387','1.2022581345562497','1.202258134556250','test'),('2018-08-12 19:59:59','2018-08-13 15:59:59','BTGETH','4h','0.061552000000000','0.060919000000000','0.073332937175393','0.072578782164475','1.1913981215134033','1.191398121513403','test'),('2018-08-13 19:59:59','2018-08-14 03:59:59','BTGETH','4h','0.062200000000000','0.058878000000000','0.073332937175393','0.069416345257440','1.1789861282217526','1.178986128221753','test'),('2018-08-18 23:59:59','2018-09-01 07:59:59','BTGETH','4h','0.063500000000000','0.074109000000000','0.073332937175393','0.085584734506003','1.1548494043368978','1.154849404336898','test'),('2018-09-05 07:59:59','2018-09-13 03:59:59','BTGETH','4h','0.075208000000000','0.101450000000000','0.073332937175393','0.098920679667637','0.9750683062359458','0.975068306235946','test'),('2018-09-13 07:59:59','2018-09-13 23:59:59','BTGETH','4h','0.102092000000000','0.096567000000000','0.075167475812209','0.071099573294260','0.7362719489500571','0.736271948950057','test'),('2018-09-17 19:59:59','2018-09-20 11:59:59','BTGETH','4h','0.103322000000000','0.098416000000000','0.075167475812209','0.071598326586152','0.7275069763671727','0.727506976367173','test'),('2018-09-25 07:59:59','2018-09-29 23:59:59','BTGETH','4h','0.103247000000000','0.113054000000000','0.075167475812209','0.082307319442439','0.7280354471530311','0.728035447153031','test'),('2018-10-03 03:59:59','2018-10-08 03:59:59','BTGETH','4h','0.115055000000000','0.119102000000000','0.075167475812209','0.077811452819832','0.653317768130103','0.653317768130103','test'),('2018-10-11 23:59:59','2018-10-14 03:59:59','BTGETH','4h','0.124440000000000','0.122840000000000','0.075704168035671','0.074730793968996','0.6083587916720586','0.608358791672059','test'),('2018-10-14 23:59:59','2018-10-15 07:59:59','BTGETH','4h','0.125805000000000','0.124988000000000','0.075704168035671','0.075212531731191','0.6017580226196971','0.601758022619697','test'),('2018-10-15 15:59:59','2018-10-22 11:59:59','BTGETH','4h','0.125944000000000','0.128078000000000','0.075704168035671','0.076986902382588','0.6010938832788462','0.601093883278846','test'),('2018-10-23 07:59:59','2018-10-26 23:59:59','BTGETH','4h','0.128999000000000','0.132638000000000','0.075704168035671','0.077839746353967','0.5868585650715974','0.586858565071597','test'),('2018-10-28 07:59:59','2018-10-29 03:59:59','BTGETH','4h','0.133798000000000','0.132784000000000','0.076192493609185','0.075615062044291','0.5694591369765278','0.569459136976528','test'),('2018-10-29 19:59:59','2018-10-30 23:59:59','BTGETH','4h','0.134742000000000','0.131587000000000','0.076192493609185','0.074408437284231','0.5654695166257365','0.565469516625737','test'),('2018-10-31 07:59:59','2018-11-01 07:59:59','BTGETH','4h','0.135298000000000','0.132664000000000','0.076192493609185','0.074709167705132','0.5631457494507309','0.563145749450731','test'),('2018-11-01 19:59:59','2018-11-02 07:59:59','BTGETH','4h','0.134498000000000','0.133055000000000','0.076192493609185','0.075375040797410','0.5664953650551309','0.566495365055131','test'),('2018-11-02 11:59:59','2018-11-08 19:59:59','BTGETH','4h','0.133768000000000','0.141454000000000','0.076192493609185','0.080570338130148','0.5695868489413387','0.569586848941339','test'),('2018-11-15 07:59:59','2018-11-20 07:59:59','BTGETH','4h','0.143100000000000','0.151939000000000','0.076192493609185','0.080898751128483','0.5324423033486023','0.532442303348602','test'),('2018-11-23 23:59:59','2018-11-24 23:59:59','BTGETH','4h','0.159228000000000','0.164918000000000','0.077297952467832','0.080060188692252','0.48545452098771397','0.485454520987714','test'),('2018-11-25 03:59:59','2018-11-26 15:59:59','BTGETH','4h','0.169407000000000','0.159796000000000','0.077988511523937','0.073563974260090','0.46036180042109665','0.460361800421097','test'),('2018-11-27 03:59:59','2018-11-27 23:59:59','BTGETH','4h','0.174157000000000','0.165353000000000','0.077988511523937','0.074046029421829','0.44780578170235474','0.447805781702355','test'),('2019-01-11 11:59:59','2019-01-14 15:59:59','BTGETH','4h','0.094829000000000','0.095373000000000','0.077988511523937','0.078435903674746','0.8224120419274379','0.822412041927438','test'),('2019-01-16 03:59:59','2019-01-16 15:59:59','BTGETH','4h','0.098734000000000','0.098324000000000','0.077988511523937','0.077664658649296','0.7898850601002391','0.789885060100239','test'),('2019-01-16 23:59:59','2019-01-17 11:59:59','BTGETH','4h','0.097187000000000','0.094646000000000','0.077988511523937','0.075949465069346','0.802458266269532','0.802458266269532','test'),('2019-01-22 11:59:59','2019-01-22 15:59:59','BTGETH','4h','0.095745000000000','0.094853000000000','0.077988511523937','0.077261938310930','0.8145439607701395','0.814543960770139','test'),('2019-01-22 19:59:59','2019-01-22 23:59:59','BTGETH','4h','0.095000000000000','0.094375000000000','0.077988511523937','0.077475429211280','0.8209317002519684','0.820931700251968','test'),('2019-01-23 07:59:59','2019-01-23 11:59:59','BTGETH','4h','0.094000000000000','0.094042000000000','0.077988511523937','0.078023357454618','0.8296650162120958','0.829665016212096','test'),('2019-01-23 15:59:59','2019-01-25 11:59:59','BTGETH','4h','0.095427000000000','0.094750000000000','0.077988511523937','0.077435227628376','0.817258339085762','0.817258339085762','test'),('2019-01-25 15:59:59','2019-01-26 19:59:59','BTGETH','4h','0.095814000000000','0.094895000000000','0.077988511523937','0.077240484700190','0.8139573707802304','0.813957370780230','test'),('2019-01-27 23:59:59','2019-01-28 03:59:59','BTGETH','4h','0.096532000000000','0.085159000000000','0.077988511523937','0.068800228451363','0.8079031981512556','0.807903198151256','test'),('2019-02-20 23:59:59','2019-02-21 11:59:59','BTGETH','4h','0.085157000000000','0.084215000000000','0.077988511523937','0.077125808776593','0.9158203262672123','0.915820326267212','test'),('2019-02-21 15:59:59','2019-02-22 11:59:59','BTGETH','4h','0.085625000000000','0.084315000000000','0.077988511523937','0.076795344223542','0.9108147331262715','0.910814733126271','test'),('2019-02-24 15:59:59','2019-03-01 15:59:59','BTGETH','4h','0.087384000000000','0.091008000000000','0.077988511523937','0.081222860669808','0.8924804486397624','0.892480448639762','test'),('2019-03-02 07:59:59','2019-03-03 11:59:59','BTGETH','4h','0.092655000000000','0.091609000000000','0.077988511523937','0.077108084314892','0.8417086128534563','0.841708612853456','test'),('2019-03-03 15:59:59','2019-03-04 07:59:59','BTGETH','4h','0.092756000000000','0.091500000000000','0.077988511523937','0.076932476653157','0.8407920945700224','0.840792094570022','test'),('2019-03-04 23:59:59','2019-03-05 07:59:59','BTGETH','4h','0.092500000000000','0.091000000000000','0.077988511523937','0.076723832958684','0.8431190435020216','0.843119043502022','test'),('2019-03-08 07:59:59','2019-03-09 11:59:59','BTGETH','4h','0.095886000000000','0.092697000000000','0.077988511523937','0.075394750565613','0.8133461769594832','0.813346176959483','test'),('2019-03-09 23:59:59','2019-03-10 23:59:59','BTGETH','4h','0.092335000000000','0.091663000000000','0.077988511523937','0.077420923071627','0.8446256730810311','0.844625673081031','test'),('2019-03-12 15:59:59','2019-03-16 19:59:59','BTGETH','4h','0.093682000000000','0.096225000000000','0.077988511523937','0.080105511425790','0.8324812826790312','0.832481282679031','test'),('2019-03-24 23:59:59','2019-03-25 03:59:59','BTGETH','4h','0.096349000000000','0.095360000000000','0.077988511523937','0.077187977653350','0.8094376851232187','0.809437685123219','test'),('2019-04-03 07:59:59','2019-04-08 03:59:59','BTGETH','4h','0.095466000000000','0.103403000000000','0.077988511523937','0.084472441048223','0.8169244707428509','0.816924470742851','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  0:50:48
