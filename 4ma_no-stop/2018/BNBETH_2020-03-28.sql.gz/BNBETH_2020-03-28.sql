-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-09 19:59:59','2018-02-11 03:59:59','BNBETH','4h','0.011335000000000','0.010693000000000','0.072144500000000','0.068058327172475','6.364755183061315','6.364755183061315','test'),('2018-02-14 19:59:59','2018-02-19 07:59:59','BNBETH','4h','0.010918000000000','0.011638000000000','0.072144500000000','0.076902151584539','6.60784942297124','6.607849422971240','test'),('2018-02-27 07:59:59','2018-03-02 11:59:59','BNBETH','4h','0.012053000000000','0.011878000000000','0.072312369689254','0.071262451436900','5.999532870592675','5.999532870592675','test'),('2018-03-03 03:59:59','2018-03-03 07:59:59','BNBETH','4h','0.012099000000000','0.011915000000000','0.072312369689254','0.071212652685963','5.976722843975039','5.976722843975039','test'),('2018-03-05 03:59:59','2018-03-05 07:59:59','BNBETH','4h','0.012037000000000','0.011821000000000','0.072312369689254','0.071014748034948','6.007507658823129','6.007507658823129','test'),('2018-03-05 19:59:59','2018-03-05 23:59:59','BNBETH','4h','0.011979000000000','0.011891000000000','0.072312369689254','0.071781149342593','6.036594848422573','6.036594848422573','test'),('2018-03-07 23:59:59','2018-03-08 03:59:59','BNBETH','4h','0.012088000000000','0.011250000000000','0.072312369689254','0.067299318249843','5.982161622208306','5.982161622208306','test'),('2018-03-13 15:59:59','2018-04-07 19:59:59','BNBETH','4h','0.014000000000000','0.031920000000000','0.072312369689254','0.164872202891499','5.165169263518143','5.165169263518143','test'),('2018-05-18 19:59:59','2018-05-20 11:59:59','BNBETH','4h','0.021751000000000','0.019536000000000','0.093204445815809','0.083713027146230','4.285064862112501','4.285064862112501','test'),('2018-05-21 19:59:59','2018-05-30 03:59:59','BNBETH','4h','0.020527000000000','0.021983000000000','0.093204445815809','0.099815527469622','4.540578058937448','4.540578058937448','test'),('2018-05-31 07:59:59','2018-06-03 15:59:59','BNBETH','4h','0.024200000000000','0.023644000000000','0.093204445815809','0.091063054416074','3.851423380818554','3.851423380818554','test'),('2018-06-05 03:59:59','2018-06-10 03:59:59','BNBETH','4h','0.024605000000000','0.026799000000000','0.093204445815809','0.101515380752606','3.788028685869092','3.788028685869092','test'),('2018-06-11 07:59:59','2018-06-14 19:59:59','BNBETH','4h','0.027400000000000','0.028611000000000','0.094026747446133','0.098182455152603','3.431633118472007','3.431633118472007','test'),('2018-06-15 19:59:59','2018-06-19 11:59:59','BNBETH','4h','0.031399000000000','0.030931000000000','0.095065674372750','0.093648726839184','3.0276656700133917','3.027665670013392','test'),('2018-06-22 07:59:59','2018-06-24 03:59:59','BNBETH','4h','0.032824000000000','0.031411000000000','0.095065674372750','0.090973309094640','2.8962245421871193','2.896224542187119','test'),('2018-06-26 23:59:59','2018-06-27 23:59:59','BNBETH','4h','0.032743000000000','0.031856000000000','0.095065674372750','0.092490368103666','2.9033892548865405','2.903389254886541','test'),('2018-06-28 11:59:59','2018-06-30 03:59:59','BNBETH','4h','0.033437000000000','0.032837000000000','0.095065674372750','0.093359797511080','2.8431281027828454','2.843128102782845','test'),('2018-07-26 23:59:59','2018-07-30 07:59:59','BNBETH','4h','0.028888000000000','0.029269000000000','0.095065674372750','0.096319482941568','3.290836138630227','3.290836138630227','test'),('2018-07-31 15:59:59','2018-08-05 15:59:59','BNBETH','4h','0.031963000000000','0.033133000000000','0.095065674372750','0.098545536682800','2.974241290640741','2.974241290640741','test'),('2018-08-06 15:59:59','2018-08-07 07:59:59','BNBETH','4h','0.033734000000000','0.033179000000000','0.095065674372750','0.093501630699397','2.818096708743404','2.818096708743404','test'),('2018-08-07 19:59:59','2018-08-08 19:59:59','BNBETH','4h','0.034545000000000','0.033240000000000','0.095065674372750','0.091474396183245','2.7519373099652626','2.751937309965263','test'),('2018-08-08 23:59:59','2018-08-14 03:59:59','BNBETH','4h','0.034260000000000','0.034927000000000','0.095065674372750','0.096916485954963','2.7748299583406304','2.774829958340630','test'),('2018-08-22 03:59:59','2018-08-30 15:59:59','BNBETH','4h','0.034990000000000','0.037802000000000','0.095065674372750','0.102705705134001','2.7169383930480135','2.716938393048014','test'),('2018-08-31 15:59:59','2018-09-02 11:59:59','BNBETH','4h','0.038546000000000','0.038497000000000','0.095065674372750','0.094944826086436','2.466291557431381','2.466291557431381','test'),('2018-09-03 07:59:59','2018-09-13 15:59:59','BNBETH','4h','0.038744000000000','0.047390000000000','0.095065674372750','0.116280257808296','2.453687651578309','2.453687651578309','test'),('2018-09-27 07:59:59','2018-09-27 15:59:59','BNBETH','4h','0.045471000000000','0.045120000000000','0.100158782014319','0.099385635778542','2.202695828425139','2.202695828425139','test'),('2018-09-29 03:59:59','2018-09-29 11:59:59','BNBETH','4h','0.045080000000000','0.042704000000000','0.100158782014319','0.094879783210725','2.2218008432635092','2.221800843263509','test'),('2018-10-03 07:59:59','2018-10-06 23:59:59','BNBETH','4h','0.046338000000000','0.046270000000000','0.100158782014319','0.100011801195618','2.161482627958026','2.161482627958026','test'),('2018-10-07 11:59:59','2018-10-08 19:59:59','BNBETH','4h','0.046690000000000','0.045821000000000','0.100158782014319','0.098294614492999','2.145187021082009','2.145187021082009','test'),('2018-10-11 03:59:59','2018-10-15 07:59:59','BNBETH','4h','0.047947000000000','0.047632000000000','0.100158782014319','0.099500763445180','2.088947838536697','2.088947838536697','test'),('2018-10-15 15:59:59','2018-10-16 15:59:59','BNBETH','4h','0.049001000000000','0.047713000000000','0.100158782014319','0.097526090615481','2.044015061209343','2.044015061209343','test'),('2018-10-18 19:59:59','2018-10-19 03:59:59','BNBETH','4h','0.048433000000000','0.048296000000000','0.100158782014319','0.099875467886845','2.067986331929036','2.067986331929036','test'),('2018-10-19 15:59:59','2018-10-20 07:59:59','BNBETH','4h','0.048113000000000','0.047757000000000','0.100158782014319','0.099417682386420','2.0817405278057697','2.081740527805770','test'),('2018-10-23 03:59:59','2018-10-24 03:59:59','BNBETH','4h','0.048314000000000','0.048125000000000','0.100158782014319','0.099766969914292','2.07307989432295','2.073079894322950','test'),('2018-10-24 15:59:59','2018-10-24 23:59:59','BNBETH','4h','0.048014000000000','0.048150000000000','0.100158782014319','0.100442482484056','2.08603286571248','2.086032865712480','test'),('2018-10-25 07:59:59','2018-10-25 11:59:59','BNBETH','4h','0.048252000000000','0.048029000000000','0.100158782014319','0.099695891183075','2.0757436378661818','2.075743637866182','test'),('2018-10-25 23:59:59','2018-10-26 03:59:59','BNBETH','4h','0.048142000000000','0.048015000000000','0.100158782014319','0.099894560226362','2.0804865193452495','2.080486519345250','test'),('2018-11-01 19:59:59','2018-11-02 11:59:59','BNBETH','4h','0.048048000000000','0.047836000000000','0.100158782014319','0.099716855986450','2.0845567352297496','2.084556735229750','test'),('2018-11-23 11:59:59','2018-11-23 15:59:59','BNBETH','4h','0.044930000000000','0.044972000000000','0.100158782014319','0.100252409186467','2.229218384471823','2.229218384471823','test'),('2018-11-23 19:59:59','2018-11-23 23:59:59','BNBETH','4h','0.045059000000000','0.045154000000000','0.100158782014319','0.100369951465291','2.2228363260240798','2.222836326024080','test'),('2018-11-27 11:59:59','2018-11-27 19:59:59','BNBETH','4h','0.045495000000000','0.044906000000000','0.100158782014319','0.098862078583031','2.201533839198132','2.201533839198132','test'),('2018-11-28 03:59:59','2018-11-28 07:59:59','BNBETH','4h','0.045050000000000','0.045126000000000','0.100158782014319','0.100327751324709','2.2232803998738957','2.223280399873896','test'),('2018-11-28 11:59:59','2018-11-28 15:59:59','BNBETH','4h','0.045180000000000','0.044986000000000','0.100158782014319','0.099728706677648','2.2168831787144536','2.216883178714454','test'),('2018-11-29 23:59:59','2018-11-30 11:59:59','BNBETH','4h','0.045568000000000','0.044400000000000','0.100158782014319','0.097591509862969','2.1980069788956946','2.198006978895695','test'),('2018-12-01 03:59:59','2018-12-01 07:59:59','BNBETH','4h','0.045132000000000','0.045176000000000','0.100158782014319','0.100256428615592','2.2192409380111453','2.219240938011145','test'),('2018-12-02 11:59:59','2018-12-03 03:59:59','BNBETH','4h','0.045113000000000','0.045149000000000','0.100158782014319','0.100238708336056','2.2201756038019864','2.220175603801986','test'),('2018-12-03 07:59:59','2018-12-07 15:59:59','BNBETH','4h','0.045153000000000','0.050910000000000','0.100158782014319','0.112929010084579','2.218208801504197','2.218208801504197','test'),('2018-12-11 11:59:59','2018-12-14 03:59:59','BNBETH','4h','0.052400000000000','0.053274000000000','0.100158782014319','0.101829369332649','1.9114271376778436','1.911427137677844','test'),('2018-12-14 11:59:59','2018-12-14 19:59:59','BNBETH','4h','0.054305000000000','0.053394000000000','0.100158782014319','0.098478556428921','1.8443749565292147','1.844374956529215','test'),('2018-12-15 11:59:59','2018-12-16 03:59:59','BNBETH','4h','0.054437000000000','0.053542000000000','0.100158782014319','0.098512069118626','1.839902676751456','1.839902676751456','test'),('2018-12-16 23:59:59','2018-12-17 19:59:59','BNBETH','4h','0.054549000000000','0.053070000000000','0.100158782014319','0.097443153155877','1.8361249888049094','1.836124988804909','test'),('2018-12-18 19:59:59','2018-12-19 03:59:59','BNBETH','4h','0.055429000000000','0.053402000000000','0.100158782014319','0.096496044978778','1.806974363858612','1.806974363858612','test'),('2018-12-19 19:59:59','2018-12-20 03:59:59','BNBETH','4h','0.054357000000000','0.054186000000000','0.100158782014319','0.099843695609174','1.8426105564015491','1.842610556401549','test'),('2019-01-09 07:59:59','2019-01-14 19:59:59','BNBETH','4h','0.045554000000000','0.046534000000000','0.100158782014319','0.102313490851612','2.1986824870333894','2.198682487033389','test'),('2019-01-15 23:59:59','2019-01-24 19:59:59','BNBETH','4h','0.048726000000000','0.055440000000000','0.100158782014319','0.113959751977873','2.055551081851968','2.055551081851968','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:58:19
