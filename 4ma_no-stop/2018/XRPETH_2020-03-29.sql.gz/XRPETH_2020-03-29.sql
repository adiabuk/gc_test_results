-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-19 15:59:59','2018-04-22 15:59:59','XRPETH','4h','0.001335000000000','0.001399100000000','0.072144500000000','0.075608516816479','54.04082397003745','54.040823970037451','test'),('2018-05-24 07:59:59','2018-05-31 11:59:59','XRPETH','4h','0.001022000000000','0.001062700000000','0.073010504204120','0.075918065379372','71.43884951479428','71.438849514794285','test'),('2018-06-01 23:59:59','2018-06-03 19:59:59','XRPETH','4h','0.001075290000000','0.001066570000000','0.073737394497933','0.073139425503502','68.57442596688591','68.574425966885912','test'),('2018-06-03 23:59:59','2018-06-09 15:59:59','XRPETH','4h','0.001113950000000','0.001106470000000','0.073737394497933','0.073242259428276','66.19452802902553','66.194528029025534','test'),('2018-06-12 19:59:59','2018-06-13 19:59:59','XRPETH','4h','0.001129000000000','0.001102520000000','0.073737394497933','0.072007929301914','65.31212975901948','65.312129759019484','test'),('2018-06-13 23:59:59','2018-06-14 03:59:59','XRPETH','4h','0.001112930000000','0.001125040000000','0.073737394497933','0.074539744912937','66.25519529344433','66.255195293444331','test'),('2018-06-14 07:59:59','2018-06-14 19:59:59','XRPETH','4h','0.001131750000000','0.001075240000000','0.073737394497933','0.070055574163868','65.15343008432339','65.153430084323389','test'),('2018-06-27 03:59:59','2018-06-28 15:59:59','XRPETH','4h','0.001059700000000','0.001057100000000','0.073737394497933','0.073556477987888','69.58327309420874','69.583273094208735','test'),('2018-06-28 23:59:59','2018-06-29 11:59:59','XRPETH','4h','0.001060350000000','0.001042860000000','0.073737394497933','0.072521129085787','69.54061819015702','69.540618190157019','test'),('2018-07-04 19:59:59','2018-07-05 03:59:59','XRPETH','4h','0.001065490000000','0.001048280000000','0.073737394497933','0.072546373878960','69.20514927210297','69.205149272102972','test'),('2018-07-18 11:59:59','2018-07-18 19:59:59','XRPETH','4h','0.001030000000000','0.001015460000000','0.073737394497933','0.072696480210554','71.58970339605145','71.589703396051448','test'),('2018-07-18 23:59:59','2018-07-19 03:59:59','XRPETH','4h','0.001018320000000','0.001006390000000','0.073737394497933','0.072873533318382','72.41082812665272','72.410828126652717','test'),('2018-07-19 07:59:59','2018-07-19 11:59:59','XRPETH','4h','0.001006620000000','0.001018000000000','0.073737394497933','0.074571007529053','73.25246319160458','73.252463191604576','test'),('2018-07-19 15:59:59','2018-07-19 23:59:59','XRPETH','4h','0.001028700000000','0.001018880000000','0.073737394497933','0.073033495193987','71.68017351796733','71.680173517967333','test'),('2018-07-31 15:59:59','2018-08-06 11:59:59','XRPETH','4h','0.001002400000000','0.001047020000000','0.073737394497933','0.077019679556291','73.5608484616251','73.560848461625099','test'),('2018-08-15 07:59:59','2018-08-15 19:59:59','XRPETH','4h','0.001014020000000','0.000991860000000','0.073737394497933','0.072125966062523','72.71788968455553','72.717889684555530','test'),('2018-08-15 23:59:59','2018-08-24 15:59:59','XRPETH','4h','0.000998660000000','0.001167000000000','0.073737394497933','0.086167003163327','73.83633518708369','73.836335187083691','test'),('2018-08-26 03:59:59','2018-08-29 11:59:59','XRPETH','4h','0.001186900000000','0.001181100000000','0.074746184954996','0.074380924298884','62.97597519167264','62.975975191672639','test'),('2018-08-29 19:59:59','2018-08-30 07:59:59','XRPETH','4h','0.001197570000000','0.001186990000000','0.074746184954996','0.074085835550098','62.41487758961564','62.414877589615642','test'),('2018-09-05 23:59:59','2018-09-13 15:59:59','XRPETH','4h','0.001222490000000','0.001376730000000','0.074746184954996','0.084176815526582','61.142573726571186','61.142573726571186','test'),('2018-09-18 11:59:59','2018-09-24 19:59:59','XRPETH','4h','0.001562510000000','0.002220550000000','0.076847440082640','0.109211194216681','49.18204688778968','49.182046887789681','test'),('2018-09-26 07:59:59','2018-09-28 11:59:59','XRPETH','4h','0.002480670000000','0.002344870000000','0.084938378616151','0.080288573597316','34.24009586770933','34.240095867709329','test'),('2018-09-28 19:59:59','2018-10-01 19:59:59','XRPETH','4h','0.002426800000000','0.002389810000000','0.084938378616151','0.083643722845172','35.000156014566926','35.000156014566926','test'),('2018-10-01 23:59:59','2018-10-02 03:59:59','XRPETH','4h','0.002498760000000','0.002471490000000','0.084938378616151','0.084011411006272','33.99221158340577','33.992211583405769','test'),('2018-10-16 23:59:59','2018-10-21 07:59:59','XRPETH','4h','0.002250180000000','0.002249500000000','0.084938378616151','0.084912710404071','37.7473707064106','37.747370706410599','test'),('2018-10-24 07:59:59','2018-10-27 03:59:59','XRPETH','4h','0.002284270000000','0.002255610000000','0.084938378616151','0.083872684135578','37.18403630750787','37.184036307507867','test'),('2018-10-30 03:59:59','2018-10-31 03:59:59','XRPETH','4h','0.002283150000000','0.002262790000000','0.084938378616151','0.084180940257469','37.20227694901825','37.202276949018248','test'),('2018-10-31 07:59:59','2018-10-31 11:59:59','XRPETH','4h','0.002264540000000','0.002262290000000','0.084938378616151','0.084853985603934','37.50800542986699','37.508005429866991','test'),('2018-10-31 15:59:59','2018-11-03 19:59:59','XRPETH','4h','0.002286340000000','0.002287000000000','0.084938378616151','0.084962897860833','37.150370730578565','37.150370730578565','test'),('2018-11-05 23:59:59','2018-11-08 15:59:59','XRPETH','4h','0.002385510000000','0.002378910000000','0.084938378616151','0.084703379266382','35.605962086158094','35.605962086158094','test'),('2018-11-12 07:59:59','2018-11-12 11:59:59','XRPETH','4h','0.002396640000000','0.002386470000000','0.084938378616151','0.084577947633389','35.44060794118057','35.440607941180573','test'),('2018-11-12 15:59:59','2018-11-14 19:59:59','XRPETH','4h','0.002478500000000','0.002506570000000','0.084938378616151','0.085900339595677','34.27007408357918','34.270074083579182','test'),('2018-11-14 23:59:59','2018-11-25 03:59:59','XRPETH','4h','0.002586730000000','0.003166640000000','0.084938378616151','0.103980418235010','32.83619806325012','32.836198063250123','test'),('2018-11-26 23:59:59','2018-11-28 15:59:59','XRPETH','4h','0.003283100000000','0.003259500000000','0.087595495377973','0.086965830216717','26.68072717187209','26.680727171872089','test'),('2018-12-04 03:59:59','2018-12-04 07:59:59','XRPETH','4h','0.003214530000000','0.003193960000000','0.087595495377973','0.087034965739138','27.249860905940523','27.249860905940523','test'),('2018-12-04 11:59:59','2018-12-04 15:59:59','XRPETH','4h','0.003203380000000','0.003187180000000','0.087595495377973','0.087152511084782','27.344709456253394','27.344709456253394','test'),('2018-12-04 19:59:59','2018-12-04 23:59:59','XRPETH','4h','0.003196000000000','0.003205770000000','0.087595495377973','0.087863270093193','27.40785212076752','27.407852120767519','test'),('2018-12-05 03:59:59','2018-12-07 19:59:59','XRPETH','4h','0.003231380000000','0.003203020000000','0.087595495377973','0.086826719112440','27.10776676775031','27.107766767750309','test'),('2018-12-07 23:59:59','2018-12-08 03:59:59','XRPETH','4h','0.003233320000000','0.003298690000000','0.087595495377973','0.089366466866368','27.091502040618618','27.091502040618618','test'),('2018-12-08 07:59:59','2018-12-09 15:59:59','XRPETH','4h','0.003348520000000','0.003272750000000','0.087595495377973','0.085613392632644','26.15946608590452','26.159466085904519','test'),('2018-12-11 03:59:59','2018-12-15 19:59:59','XRPETH','4h','0.003397000000000','0.003395010000000','0.087595495377973','0.087544180972379','25.7861334642252','25.786133464225198','test'),('2018-12-17 23:59:59','2018-12-19 03:59:59','XRPETH','4h','0.003479410000000','0.003632380000000','0.087595495377973','0.091446574419526','25.175387602488065','25.175387602488065','test'),('2018-12-19 11:59:59','2018-12-20 15:59:59','XRPETH','4h','0.003598820000000','0.003413370000000','0.087959108561831','0.083426507130586','24.441096960067682','24.441096960067682','test'),('2019-01-11 07:59:59','2019-01-14 19:59:59','XRPETH','4h','0.002592680000000','0.002596400000000','0.087959108561831','0.088085313062136','33.92594094212591','33.925940942125912','test'),('2019-01-16 23:59:59','2019-01-19 11:59:59','XRPETH','4h','0.002680390000000','0.002648540000000','0.087959108561831','0.086913925731088','32.815787464447716','32.815787464447716','test'),('2019-01-20 19:59:59','2019-01-23 03:59:59','XRPETH','4h','0.002686180000000','0.002687950000000','0.087959108561831','0.088017067307021','32.745053779654015','32.745053779654015','test'),('2019-01-24 03:59:59','2019-01-25 15:59:59','XRPETH','4h','0.002720640000000','0.002712620000000','0.087959108561831','0.087699819552383','32.33030042998376','32.330300429983758','test'),('2019-01-25 19:59:59','2019-01-26 11:59:59','XRPETH','4h','0.002720240000000','0.002703780000000','0.087959108561831','0.087426873565313','32.33505446645553','32.335054466455531','test'),('2019-01-27 23:59:59','2019-02-02 15:59:59','XRPETH','4h','0.002735430000000','0.002856100000000','0.087959108561831','0.091839312270263','32.15549605065054','32.155496050650541','test'),('2019-02-27 15:59:59','2019-02-28 03:59:59','XRPETH','4h','0.002289240000000','0.002287290000000','0.087959108561831','0.087884184018447','38.422842760842464','38.422842760842464','test'),('2019-02-28 07:59:59','2019-02-28 11:59:59','XRPETH','4h','0.002288530000000','0.002274310000000','0.087959108561831','0.087412566229526','38.43476317191866','38.434763171918661','test'),('2019-02-28 23:59:59','2019-03-05 15:59:59','XRPETH','4h','0.002317970000000','0.002341950000000','0.087959108561831','0.088869068321152','37.94661214848812','37.946612148488121','test'),('2019-03-11 19:59:59','2019-03-12 11:59:59','XRPETH','4h','0.002355840000000','0.002319890000000','0.087959108561831','0.086616856985834','37.33662241995679','37.336622419956790','test'),('2019-03-12 15:59:59','2019-03-14 15:59:59','XRPETH','4h','0.002324780000000','0.002354590000000','0.087959108561831','0.089086983468802','37.835454779304285','37.835454779304285','test'),('2019-03-14 23:59:59','2019-03-15 03:59:59','XRPETH','4h','0.002353960000000','0.002335890000000','0.087959108561831','0.087283896964475','37.36644146962183','37.366441469621833','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  3:23:56
