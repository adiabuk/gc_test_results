-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-12-02 19:59:59','2018-12-03 15:59:59','ETCBNB','4h','0.976500000000000','0.936200000000000','0.711908500000000','0.682528149206349','0.7290409626216078','0.729040962621608','test'),('2018-12-21 11:59:59','2018-12-22 07:59:59','ETCBNB','4h','0.837200000000000','0.797000000000000','0.711908500000000','0.677724647037745','0.8503446010511228','0.850344601051123','test'),('2018-12-24 03:59:59','2018-12-24 07:59:59','ETCBNB','4h','0.830500000000000','0.805800000000000','0.711908500000000','0.690735544009633','0.8572046959662855','0.857204695966285','test'),('2018-12-24 11:59:59','2018-12-29 03:59:59','ETCBNB','4h','0.841600000000000','0.896600000000000','0.711908500000000','0.758432938569392','0.845898883079848','0.845898883079848','test'),('2019-01-02 15:59:59','2019-01-03 15:59:59','ETCBNB','4h','0.893000000000000','0.866400000000000','0.711908500000000','0.690702714893617','0.7972099664053752','0.797209966405375','test'),('2019-03-21 03:59:59','2019-03-24 11:59:59','ETCBNB','4h','0.306900000000000','0.280000000000000','0.711908500000000','0.649509221244705','2.3196757901596614','2.319675790159661','test'),('2019-04-05 19:59:59','2019-04-11 07:59:59','ETCBNB','4h','0.294500000000000','0.371300000000000','0.711908500000000','0.897560699660442','2.4173463497453316','2.417346349745332','test'),('2019-05-01 11:59:59','2019-05-02 11:59:59','ETCBNB','4h','0.271800000000000','0.254100000000000','0.727867103655471','0.680467369532212','2.6779510804101205','2.677951080410121','test'),('2019-05-07 11:59:59','2019-05-11 19:59:59','ETCBNB','4h','0.261800000000000','0.292200000000000','0.727867103655471','0.812386431199880','2.7802410376450384','2.780241037645038','test'),('2019-05-12 07:59:59','2019-05-12 15:59:59','ETCBNB','4h','0.289100000000000','0.285300000000000','0.737147002010758','0.727457764350291','2.549799384333304','2.549799384333304','test'),('2019-05-12 19:59:59','2019-05-12 23:59:59','ETCBNB','4h','0.287800000000000','0.280100000000000','0.737147002010758','0.717424861929164','2.561316893713544','2.561316893713544','test'),('2019-05-16 03:59:59','2019-05-16 11:59:59','ETCBNB','4h','0.299300000000000','0.296400000000000','0.737147002010758','0.730004582011322','2.462903448081383','2.462903448081383','test'),('2019-05-16 15:59:59','2019-05-17 11:59:59','ETCBNB','4h','0.306000000000000','0.281000000000000','0.737147002010758','0.676922573741905','2.4089771307541112','2.408977130754111','test'),('2019-05-17 15:59:59','2019-05-17 19:59:59','ETCBNB','4h','0.287400000000000','0.280300000000000','0.737147002010758','0.718936341905412','2.5648817049782813','2.564881704978281','test'),('2019-05-29 15:59:59','2019-05-30 03:59:59','ETCBNB','4h','0.248800000000000','0.245400000000000','0.737147002010758','0.727073449732476','2.9628094936123714','2.962809493612371','test'),('2019-05-30 07:59:59','2019-06-04 19:59:59','ETCBNB','4h','0.253700000000000','0.264500000000000','0.737147002010758','0.768527323736088','2.9055853449379505','2.905585344937951','test'),('2019-06-09 23:59:59','2019-06-10 07:59:59','ETCBNB','4h','0.269200000000000','0.262400000000000','0.737147002010758','0.718526646833666','2.7382875260429347','2.738287526042935','test'),('2019-06-16 07:59:59','2019-06-17 07:59:59','ETCBNB','4h','0.265300000000000','0.258700000000000','0.737147002010758','0.718808629552141','2.778541281608587','2.778541281608587','test'),('2019-06-17 11:59:59','2019-06-17 15:59:59','ETCBNB','4h','0.262900000000000','0.256200000000000','0.737147002010758','0.718360828889905','2.803906435948109','2.803906435948109','test'),('2019-06-25 15:59:59','2019-06-27 07:59:59','ETCBNB','4h','0.251900000000000','0.236800000000000','0.737147002010758','0.692959150758823','2.926347765028813','2.926347765028813','test'),('2019-07-09 19:59:59','2019-07-10 15:59:59','ETCBNB','4h','0.241800000000000','0.232700000000000','0.737147002010758','0.709404910537235','3.04858148060694','3.048581480606940','test'),('2019-07-25 23:59:59','2019-07-26 03:59:59','ETCBNB','4h','0.208300000000000','0.209800000000000','0.737147002010758','0.742455309754474','3.538871829144301','3.538871829144301','test'),('2019-07-26 07:59:59','2019-07-28 23:59:59','ETCBNB','4h','0.212100000000000','0.212400000000000','0.737147002010758','0.738189642749104','3.475469127820641','3.475469127820641','test'),('2019-07-29 03:59:59','2019-07-31 11:59:59','ETCBNB','4h','0.216000000000000','0.214100000000000','0.737147002010758','0.730662838567145','3.4127176019016576','3.412717601901658','test'),('2019-08-04 15:59:59','2019-08-06 15:59:59','ETCBNB','4h','0.221500000000000','0.215800000000000','0.737147002010758','0.718177530627185','3.327977435714483','3.327977435714483','test'),('2019-08-15 01:59:59','2019-08-15 15:59:59','ETCBNB','4h','0.210700000000000','0.202800000000000','0.737147002010758','0.709508362637787','3.498561945945695','3.498561945945695','test'),('2019-08-16 03:59:59','2019-08-16 07:59:59','ETCBNB','4h','0.201500000000000','0.205100000000000','0.737147002010758','0.750316874006980','3.658297776728327','3.658297776728327','test'),('2019-08-20 15:59:59','2019-08-28 11:59:59','ETCBNB','4h','0.215400000000000','0.270000000000000','0.737147002010758','0.924000420347747','3.4222237790657286','3.422223779065729','test'),('2019-08-29 03:59:59','2019-08-29 15:59:59','ETCBNB','4h','0.286300000000000','0.272200000000000','0.737147002010758','0.700843220214210','2.5747362976275165','2.574736297627517','test'),('2019-08-30 19:59:59','2019-09-06 11:59:59','ETCBNB','4h','0.289600000000000','0.304200000000000','0.737147002010758','0.774309799764063','2.545397106390739','2.545397106390739','test'),('2019-09-06 19:59:59','2019-09-06 23:59:59','ETCBNB','4h','0.313200000000000','0.303000000000000','0.737147002010758','0.713140298880140','2.353598346139074','2.353598346139074','test'),('2019-09-11 07:59:59','2019-09-11 15:59:59','ETCBNB','4h','0.303000000000000','0.297300000000000','0.737147002010758','0.723279880190754','2.432828389474449','2.432828389474449','test'),('2019-09-11 19:59:59','2019-09-12 15:59:59','ETCBNB','4h','0.300700000000000','0.303700000000000','0.737147002010758','0.744501311974284','2.4514366545086728','2.451436654508673','test'),('2019-09-12 19:59:59','2019-09-12 23:59:59','ETCBNB','4h','0.304900000000000','0.297900000000000','0.737147002010758','0.720223325349311','2.4176680944924827','2.417668094492483','test'),('2019-09-15 11:59:59','2019-09-17 07:59:59','ETCBNB','4h','0.303500000000000','0.305600000000000','0.737147002010758','0.742247524924177','2.4288204349613114','2.428820434961311','test'),('2019-09-24 07:59:59','2019-09-24 15:59:59','ETCBNB','4h','0.302300000000000','0.297800000000000','0.737147002010758','0.726173923912682','2.438461799572471','2.438461799572471','test'),('2019-09-25 15:59:59','2019-09-26 03:59:59','ETCBNB','4h','0.310100000000000','0.296800000000000','0.737147002010758','0.705531216371470','2.3771267397960596','2.377126739796060','test'),('2019-09-26 07:59:59','2019-09-26 11:59:59','ETCBNB','4h','0.301000000000000','0.295100000000000','0.737147002010758','0.722697941174002','2.448993362161987','2.448993362161987','test'),('2019-09-26 15:59:59','2019-09-27 23:59:59','ETCBNB','4h','0.307400000000000','0.298900000000000','0.737147002010758','0.716763952182874','2.3980058621039624','2.398005862103962','test'),('2019-09-28 03:59:59','2019-09-28 07:59:59','ETCBNB','4h','0.301400000000000','0.300100000000000','0.737147002010758','0.733967535844155','2.4457432050788253','2.445743205078825','test'),('2019-09-30 11:59:59','2019-09-30 15:59:59','ETCBNB','4h','0.303100000000000','0.295100000000000','0.737147002010758','0.717690796085037','2.432025740715137','2.432025740715137','test'),('2019-10-07 03:59:59','2019-10-07 11:59:59','ETCBNB','4h','0.298400000000000','0.294600000000000','0.737147002010758','0.727759741261291','2.4703317761754624','2.470331776175462','test'),('2019-11-07 03:59:59','2019-11-10 03:59:59','ETCBNB','4h','0.248000000000000','0.248200000000000','0.737147002010758','0.737741475399476','2.972366943591766','2.972366943591766','test'),('2019-11-20 19:59:59','2019-11-24 07:59:59','ETCBNB','4h','0.239100000000000','0.243300000000000','0.737147002010758','0.750095631908061','3.0830071184055123','3.083007118405512','test'),('2019-11-24 15:59:59','2019-11-26 19:59:59','ETCBNB','4h','0.250600000000000','0.251900000000000','0.737147002010758','0.740970988852793','2.9415283400269674','2.941528340026967','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 23:49:42
