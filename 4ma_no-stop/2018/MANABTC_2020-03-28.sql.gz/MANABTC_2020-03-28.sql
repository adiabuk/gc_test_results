-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-31 19:59:59','2018-06-04 03:59:59','MANABTC','4h','0.000014090000000','0.000013610000000','0.001467500000000','0.001417507097232','104.15188076650107','104.151880766501066','test'),('2018-06-07 03:59:59','2018-06-08 15:59:59','MANABTC','4h','0.000013760000000','0.000013580000000','0.001467500000000','0.001448303052326','106.64970930232558','106.649709302325576','test'),('2018-06-08 19:59:59','2018-06-10 03:59:59','MANABTC','4h','0.000013670000000','0.000013800000000','0.001467500000000','0.001481455742502','107.35186539868326','107.351865398683259','test'),('2018-06-10 07:59:59','2018-06-10 19:59:59','MANABTC','4h','0.000014300000000','0.000014100000000','0.001467500000000','0.001446975524476','102.62237762237763','102.622377622377627','test'),('2018-06-10 23:59:59','2018-06-11 07:59:59','MANABTC','4h','0.000014230000000','0.000013860000000','0.001467500000000','0.001429342937456','103.12719606465215','103.127196064652153','test'),('2018-06-11 11:59:59','2018-06-12 07:59:59','MANABTC','4h','0.000014210000000','0.000013890000000','0.001467500000000','0.001434452850106','103.27234342012667','103.272343420126674','test'),('2018-06-12 11:59:59','2018-06-12 23:59:59','MANABTC','4h','0.000014030000000','0.000014550000000','0.001467500000000','0.001521890591589','104.59729151817534','104.597291518175339','test'),('2018-06-13 07:59:59','2018-06-19 07:59:59','MANABTC','4h','0.000014770000000','0.000015070000000','0.001467500000000','0.001497307041300','99.35680433310766','99.356804333107661','test'),('2018-06-24 07:59:59','2018-06-24 19:59:59','MANABTC','4h','0.000015910000000','0.000015800000000','0.001467500000000','0.001457353865493','92.23758642363295','92.237586423632948','test'),('2018-06-25 19:59:59','2018-06-26 15:59:59','MANABTC','4h','0.000015630000000','0.000015410000000','0.001467500000000','0.001446844209853','93.88995521433141','93.889955214331408','test'),('2018-06-26 19:59:59','2018-06-26 23:59:59','MANABTC','4h','0.000015530000000','0.000015170000000','0.001467500000000','0.001433481970380','94.49452672247264','94.494526722472642','test'),('2018-07-03 23:59:59','2018-07-04 00:22:27','MANABTC','4h','0.000037310000000','0.000019640000000','0.001467500000000','0.000772492629322','39.33261860091128','39.332618600911282','test'),('2018-07-04 19:59:59','2018-07-05 11:59:59','MANABTC','4h','0.000017440000000','0.000015420000000','0.001467500000000','0.001297525802752','84.14564220183487','84.145642201834875','test'),('2018-07-10 03:59:59','2018-07-10 19:59:59','MANABTC','4h','0.000015950000000','0.000015390000000','0.001467500000000','0.001415976489028','92.00626959247649','92.006269592476485','test'),('2018-07-17 03:59:59','2018-07-18 23:59:59','MANABTC','4h','0.000015980000000','0.000015750000000','0.001467500000000','0.001446378285357','91.83354192740927','91.833541927409271','test'),('2018-07-20 11:59:59','2018-07-23 11:59:59','MANABTC','4h','0.000017090000000','0.000016580000000','0.001467500000000','0.001423706846109','85.86892919836161','85.868929198361613','test'),('2018-07-23 15:59:59','2018-07-23 19:59:59','MANABTC','4h','0.000017000000000','0.000016620000000','0.001467500000000','0.001434697058824','86.32352941176471','86.323529411764710','test'),('2018-08-29 19:59:59','2018-08-30 19:59:59','MANABTC','4h','0.000011860000000','0.000010880000000','0.001467500000000','0.001346239460371','123.73524451939292','123.735244519392921','test'),('2018-08-30 23:59:59','2018-08-31 15:59:59','MANABTC','4h','0.000011170000000','0.000011040000000','0.001467500000000','0.001450420769919','131.37869292748434','131.378692927484337','test'),('2018-08-31 23:59:59','2018-09-02 11:59:59','MANABTC','4h','0.000011040000000','0.000010770000000','0.001467500000000','0.001431610054348','132.92572463768118','132.925724637681185','test'),('2018-09-15 03:59:59','2018-09-17 23:59:59','MANABTC','4h','0.000010160000000','0.000010400000000','0.001467500000000','0.001502165354331','144.43897637795277','144.438976377952770','test'),('2018-09-18 15:59:59','2018-09-18 19:59:59','MANABTC','4h','0.000010960000000','0.000010660000000','0.001467500000000','0.001427331204380','133.89598540145985','133.895985401459853','test'),('2018-09-18 23:59:59','2018-09-22 23:59:59','MANABTC','4h','0.000010890000000','0.000011450000000','0.001467500000000','0.001542963728191','134.7566574839302','134.756657483930212','test'),('2018-09-23 07:59:59','2018-09-23 11:59:59','MANABTC','4h','0.000011800000000','0.000011320000000','0.001467500000000','0.001407805084746','124.36440677966101','124.364406779661010','test'),('2018-09-24 19:59:59','2018-09-25 07:59:59','MANABTC','4h','0.000011730000000','0.000010930000000','0.001467500000000','0.001367414748508','125.10656436487639','125.106564364876391','test'),('2018-09-27 23:59:59','2018-09-29 07:59:59','MANABTC','4h','0.000011890000000','0.000011410000000','0.001467500000000','0.001408256938604','123.42304457527335','123.423044575273352','test'),('2018-09-29 11:59:59','2018-09-29 19:59:59','MANABTC','4h','0.000011590000000','0.000011450000000','0.001467500000000','0.001449773511648','126.61777394305436','126.617773943054360','test'),('2018-09-30 07:59:59','2018-10-01 11:59:59','MANABTC','4h','0.000011750000000','0.000011370000000','0.000978333333333','0.000946693617021','83.26241134751774','83.262411347517741','test'),('2018-10-02 19:59:59','2018-10-02 23:59:59','MANABTC','4h','0.000011610000000','0.000011460000000','0.001088883283210','0.001074815023737','93.78839648662787','93.788396486627875','test'),('2018-10-04 19:59:59','2018-10-05 23:59:59','MANABTC','4h','0.000011800000000','0.000011990000000','0.001088883283210','0.001106416149635','92.27824433983051','92.278244339830508','test'),('2018-10-06 07:59:59','2018-10-06 11:59:59','MANABTC','4h','0.000011920000000','0.000011760000000','0.001089749434948','0.001075121925754','91.42193246205953','91.421932462059530','test'),('2018-10-21 19:59:59','2018-10-22 07:59:59','MANABTC','4h','0.000011310000000','0.000011000000000','0.001089749434948','0.001059880087040','96.35273518549955','96.352735185499554','test'),('2018-10-22 15:59:59','2018-10-22 19:59:59','MANABTC','4h','0.000011040000000','0.000011030000000','0.001089749434948','0.001088762343069','98.70918794818841','98.709187948188415','test'),('2018-10-22 23:59:59','2018-10-23 11:59:59','MANABTC','4h','0.000011270000000','0.000011110000000','0.001089749434948','0.001074278280592','96.69471472475598','96.694714724755983','test'),('2018-10-23 15:59:59','2018-10-26 19:59:59','MANABTC','4h','0.000011500000000','0.000011360000000','0.001089749434948','0.001076482920088','94.76082043026088','94.760820430260878','test'),('2018-10-26 23:59:59','2018-10-29 15:59:59','MANABTC','4h','0.000011590000000','0.000011560000000','0.001089749434948','0.001086928685763','94.02497281691113','94.024972816911131','test'),('2018-10-31 03:59:59','2018-10-31 07:59:59','MANABTC','4h','0.000011840000000','0.000011600000000','0.001089749434948','0.001067659919375','92.03964822195947','92.039648221959467','test'),('2018-10-31 19:59:59','2018-11-04 11:59:59','MANABTC','4h','0.000011850000000','0.000011960000000','0.001089749434948','0.001099865252488','91.96197763274262','91.961977632742617','test'),('2018-11-08 03:59:59','2018-11-14 11:59:59','MANABTC','4h','0.000012620000000','0.000014770000000','0.001089749434948','0.001275404053422','86.35098533660856','86.350985336608559','test'),('2018-11-15 11:59:59','2018-11-16 15:59:59','MANABTC','4h','0.000016180000000','0.000015330000000','0.001113909073212','0.001055390982221','68.84481293031517','68.844812930315172','test'),('2018-11-19 03:59:59','2018-11-19 07:59:59','MANABTC','4h','0.000016060000000','0.000015160000000','0.001113909073212','0.001051485775211','69.3592200007472','69.359220000747200','test'),('2018-11-29 11:59:59','2018-11-30 23:59:59','MANABTC','4h','0.000014180000000','0.000014500000000','0.001113909073212','0.001139046654554','78.55494169337095','78.554941693370949','test'),('2018-12-01 03:59:59','2018-12-05 07:59:59','MANABTC','4h','0.000015190000000','0.000016240000000','0.001113909073212','0.001190907396245','73.33173622198815','73.331736221988152','test'),('2018-12-08 07:59:59','2018-12-10 15:59:59','MANABTC','4h','0.000016530000000','0.000016090000000','0.001113909073212','0.001084258740955','67.38711876660618','67.387118766606179','test'),('2018-12-23 15:59:59','2018-12-24 15:59:59','MANABTC','4h','0.000014990000000','0.000013830000000','0.001113909073212','0.001027709305038','74.31014497745163','74.310144977451628','test'),('2019-01-19 11:59:59','2019-01-20 07:59:59','MANABTC','4h','0.000011000000000','0.000010790000000','0.001113909073212','0.001092643536360','101.26446120109091','101.264461201090910','test'),('2019-01-23 15:59:59','2019-01-23 19:59:59','MANABTC','4h','0.000011020000000','0.000010800000000','0.001113909073212','0.001091671324019','101.08067814990926','101.080678149909261','test'),('2019-01-24 23:59:59','2019-01-25 11:59:59','MANABTC','4h','0.000011000000000','0.000010860000000','0.001113909073212','0.001099732048644','101.26446120109091','101.264461201090910','test'),('2019-01-25 15:59:59','2019-01-27 11:59:59','MANABTC','4h','0.000011020000000','0.000010850000000','0.001113909073212','0.001096725357927','101.08067814990926','101.080678149909261','test'),('2019-02-15 19:59:59','2019-02-18 19:59:59','MANABTC','4h','0.000009760000000','0.000010120000000','0.001113909073212','0.001154995883289','114.13002799303278','114.130027993032783','test'),('2019-02-26 15:59:59','2019-02-28 19:59:59','MANABTC','4h','0.000012980000000','0.000010960000000','0.001113909073212','0.000940558046410','85.8173400009245','85.817340000924503','test'),('2019-02-28 23:59:59','2019-03-01 19:59:59','MANABTC','4h','0.000011300000000','0.000011110000000','0.001113909073212','0.001095179628618','98.57602417805309','98.576024178053089','test'),('2019-03-05 23:59:59','2019-03-06 07:59:59','MANABTC','4h','0.000011140000000','0.000010780000000','0.001113909073212','0.001077912011600','99.991837810772','99.991837810771997','test'),('2019-03-06 11:59:59','2019-03-06 15:59:59','MANABTC','4h','0.000010850000000','0.000010680000000','0.001113909073212','0.001096456119991','102.66443071078342','102.664430710783421','test'),('2019-03-08 07:59:59','2019-03-11 15:59:59','MANABTC','4h','0.000011950000000','0.000011430000000','0.001113909073212','0.001065437716051','93.21414838594141','93.214148385941414','test'),('2019-03-12 19:59:59','2019-03-14 11:59:59','MANABTC','4h','0.000012010000000','0.000011660000000','0.001113909073212','0.001081447110212','92.74846571290591','92.748465712905912','test'),('2019-03-14 23:59:59','2019-03-16 15:59:59','MANABTC','4h','0.000012010000000','0.000012060000000','0.001113909073212','0.001118546496498','92.74846571290591','92.748465712905912','test'),('2019-03-16 23:59:59','2019-03-19 23:59:59','MANABTC','4h','0.000012190000000','0.000012320000000','0.001113909073212','0.001125788333222','91.37892315110746','91.378923151107458','test'),('2019-03-21 07:59:59','2019-03-21 15:59:59','MANABTC','4h','0.000012570000000','0.000012240000000','0.001113909073212','0.001084665636922','88.61647360477328','88.616473604773276','test'),('2019-03-22 11:59:59','2019-03-22 23:59:59','MANABTC','4h','0.000012630000000','0.000012470000000','0.001113909073212','0.001099797794375','88.19549273254157','88.195492732541567','test'),('2019-03-23 07:59:59','2019-03-25 19:59:59','MANABTC','4h','0.000012550000000','0.000012740000000','0.001113909073212','0.001130773035277','88.75769507665339','88.757695076653391','test'),('2019-03-27 11:59:59','2019-03-30 07:59:59','MANABTC','4h','0.000012920000000','0.000013980000000','0.001113909073212','0.001205297898104','86.21587253962848','86.215872539628478','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:42:13
