-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-02 15:59:59','2018-05-03 11:59:59','ARNBTC','4h','0.000232880000000','0.000223210000000','0.001467500000000','0.001406564217623','6.301528684300927','6.301528684300927','test'),('2018-05-22 15:59:59','2018-05-26 07:59:59','ARNBTC','4h','0.000165380000000','0.000171540000000','0.001467500000000','0.001522160781231','8.873503446607813','8.873503446607813','test'),('2018-06-03 03:59:59','2018-06-04 11:59:59','ARNBTC','4h','0.000170200000000','0.000164990000000','0.001467500000000','0.001422578290247','8.622209165687428','8.622209165687428','test'),('2018-06-04 15:59:59','2018-06-05 03:59:59','ARNBTC','4h','0.000169340000000','0.000163000000000','0.001467500000000','0.001412557576473','8.6659974016771','8.665997401677100','test'),('2018-07-01 23:59:59','2018-07-03 23:59:59','ARNBTC','4h','0.000110870000000','0.000106180000000','0.001467500000000','0.001405422115992','13.236222603048615','13.236222603048615','test'),('2018-07-05 15:59:59','2018-07-05 19:59:59','ARNBTC','4h','0.000113020000000','0.000108060000000','0.001467500000000','0.001403097239427','12.984427534949567','12.984427534949567','test'),('2018-07-18 15:59:59','2018-07-18 23:59:59','ARNBTC','4h','0.000103470000000','0.000095220000000','0.001467500000000','0.001350491446796','14.182854933797238','14.182854933797238','test'),('2018-08-25 11:59:59','2018-08-25 15:59:59','ARNBTC','4h','0.000044260000000','0.000043600000000','0.001467500000000','0.001445616809761','33.15634884771803','33.156348847718029','test'),('2018-08-25 19:59:59','2018-08-26 03:59:59','ARNBTC','4h','0.000044380000000','0.000042490000000','0.001467500000000','0.001405003943218','33.066696710229834','33.066696710229834','test'),('2018-08-26 23:59:59','2018-08-30 11:59:59','ARNBTC','4h','0.000043870000000','0.000044580000000','0.001467500000000','0.001491250284933','33.45110553909278','33.451105539092779','test'),('2018-08-31 15:59:59','2018-09-02 11:59:59','ARNBTC','4h','0.000047020000000','0.000045640000000','0.001467500000000','0.001424430029775','31.21012335176521','31.210123351765208','test'),('2018-09-04 11:59:59','2018-09-05 11:59:59','ARNBTC','4h','0.000048460000000','0.000047370000000','0.001467500000000','0.001434491848948','30.282707387536114','30.282707387536114','test'),('2018-09-16 23:59:59','2018-09-19 19:59:59','ARNBTC','4h','0.000049080000000','0.000045720000000','0.001467500000000','0.001367035452323','29.900162999185007','29.900162999185007','test'),('2018-09-20 11:59:59','2018-09-22 03:59:59','ARNBTC','4h','0.000048140000000','0.000045850000000','0.001467500000000','0.001397691628583','30.484004985459077','30.484004985459077','test'),('2018-09-22 23:59:59','2018-09-25 03:59:59','ARNBTC','4h','0.000049380000000','0.000047710000000','0.001467500000000','0.001417870089105','29.71850951802349','29.718509518023492','test'),('2018-09-26 15:59:59','2018-10-13 19:59:59','ARNBTC','4h','0.000051610000000','0.000110670000000','0.001467500000000','0.003146836368921','28.43441193567138','28.434411935671381','test'),('2018-10-16 23:59:59','2018-10-18 23:59:59','ARNBTC','4h','0.000125180000000','0.000112440000000','0.001710774530839','0.001536663111100','13.666516463005273','13.666516463005273','test'),('2018-10-21 19:59:59','2018-10-28 07:59:59','ARNBTC','4h','0.000119940000000','0.000129340000000','0.001710774530839','0.001844852241277','14.263586216766717','14.263586216766717','test'),('2018-11-10 15:59:59','2018-11-11 03:59:59','ARNBTC','4h','0.000118220000000','0.000109170000000','0.001710774530839','0.001579810992486','14.471109210277447','14.471109210277447','test'),('2018-11-11 07:59:59','2018-11-11 11:59:59','ARNBTC','4h','0.000110390000000','0.000108200000000','0.001710774530839','0.001676834896610','15.497549876247847','15.497549876247847','test'),('2018-11-29 15:59:59','2018-12-01 03:59:59','ARNBTC','4h','0.000104000000000','0.000081600000000','0.001710774530839','0.001342300016504','16.449755104221154','16.449755104221154','test'),('2018-12-18 23:59:59','2018-12-19 23:59:59','ARNBTC','4h','0.000073450000000','0.000071500000000','0.001710774530839','0.001665355737985','23.291688643144997','23.291688643144997','test'),('2018-12-20 07:59:59','2018-12-20 11:59:59','ARNBTC','4h','0.000072280000000','0.000072360000000','0.001710774530839','0.001712668027829','23.66871238017432','23.668712380174320','test'),('2018-12-21 15:59:59','2018-12-21 23:59:59','ARNBTC','4h','0.000076020000000','0.000073090000000','0.001710774530839','0.001644837022613','22.504269019192318','22.504269019192318','test'),('2018-12-22 03:59:59','2018-12-24 19:59:59','ARNBTC','4h','0.000074670000000','0.000074720000000','0.001710774530839','0.001711920087643','22.911136076590328','22.911136076590328','test'),('2018-12-30 23:59:59','2018-12-31 15:59:59','ARNBTC','4h','0.000074540000000','0.000073190000000','0.001710774530839','0.001679790554227','22.95109378640998','22.951093786409981','test'),('2019-01-05 11:59:59','2019-01-05 15:59:59','ARNBTC','4h','0.000072840000000','0.000072500000000','0.001710774530839','0.001702789037422','23.48674534375343','23.486745343753430','test'),('2019-01-05 19:59:59','2019-01-06 03:59:59','ARNBTC','4h','0.000073290000000','0.000073680000000','0.001710774530839','0.001719878120238','23.342536919620684','23.342536919620684','test'),('2019-01-06 11:59:59','2019-01-07 15:59:59','ARNBTC','4h','0.000074760000000','0.000072240000000','0.001710774530839','0.001653107973620','22.883554452100054','22.883554452100054','test'),('2019-01-16 11:59:59','2019-01-19 15:59:59','ARNBTC','4h','0.000073870000000','0.000081020000000','0.001710774530839','0.001876363239320','23.15925992742656','23.159259927426561','test'),('2019-01-21 07:59:59','2019-01-22 11:59:59','ARNBTC','4h','0.000082310000000','0.000079520000000','0.001710774530839','0.001652785696663','20.784528378556676','20.784528378556676','test'),('2019-01-23 11:59:59','2019-01-23 23:59:59','ARNBTC','4h','0.000083630000000','0.000081170000000','0.001710774530839','0.001660451616265','20.456469339220376','20.456469339220376','test'),('2019-02-10 23:59:59','2019-02-12 07:59:59','ARNBTC','4h','0.000079490000000','0.000076170000000','0.001710774530839','0.001639321877142','21.52188364371619','21.521883643716190','test'),('2019-02-12 11:59:59','2019-02-12 15:59:59','ARNBTC','4h','0.000076470000000','0.000076810000000','0.001710774530839','0.001718380956110','22.37183903281025','22.371839032810250','test'),('2019-02-13 07:59:59','2019-02-13 11:59:59','ARNBTC','4h','0.000078330000000','0.000077220000000','0.001710774530839','0.001686531460122','21.840604249189326','21.840604249189326','test'),('2019-02-13 15:59:59','2019-02-13 19:59:59','ARNBTC','4h','0.000077430000000','0.000077140000000','0.001710774530839','0.001704367135592','22.09446636754488','22.094466367544879','test'),('2019-02-18 11:59:59','2019-02-19 03:59:59','ARNBTC','4h','0.000083380000000','0.000075810000000','0.001710774530839','0.001555454751534','20.51780439960422','20.517804399604220','test'),('2019-02-19 07:59:59','2019-02-19 11:59:59','ARNBTC','4h','0.000076470000000','0.000077590000000','0.001710774530839','0.001735830990556','22.37183903281025','22.371839032810250','test'),('2019-02-21 07:59:59','2019-02-21 11:59:59','ARNBTC','4h','0.000076930000000','0.000074700000000','0.001710774530839','0.001661183640370','22.238067474834263','22.238067474834263','test'),('2019-02-23 11:59:59','2019-02-23 15:59:59','ARNBTC','4h','0.000077430000000','0.000076240000000','0.001710774530839','0.001684482115862','22.09446636754488','22.094466367544879','test'),('2019-02-26 15:59:59','2019-02-27 15:59:59','ARNBTC','4h','0.000079270000000','0.000076170000000','0.001710774530839','0.001643871527867','21.581613861978045','21.581613861978045','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','ARNBTC','4h','0.000076210000000','0.000076610000000','0.001710774530839','0.001719753796189','22.448163375396927','22.448163375396927','test'),('2019-03-01 23:59:59','2019-03-02 07:59:59','ARNBTC','4h','0.000077900000000','0.000076110000000','0.001710774530839','0.001671464050605','21.961162141707316','21.961162141707316','test'),('2019-03-02 11:59:59','2019-03-02 15:59:59','ARNBTC','4h','0.000076520000000','0.000076280000000','0.001710774530839','0.001705408797862','22.357220737571872','22.357220737571872','test'),('2019-03-02 19:59:59','2019-03-02 23:59:59','ARNBTC','4h','0.000076490000000','0.000076500000000','0.001710774530839','0.001710998190733','22.365989421349198','22.365989421349198','test'),('2019-03-03 03:59:59','2019-03-03 19:59:59','ARNBTC','4h','0.000076920000000','0.000076980000000','0.001710774530839','0.001712108988351','22.240958539248567','22.240958539248567','test'),('2019-03-03 23:59:59','2019-03-04 07:59:59','ARNBTC','4h','0.000077430000000','0.000075700000000','0.001710774530839','0.001672551104023','22.09446636754488','22.094466367544879','test'),('2019-03-05 07:59:59','2019-03-09 03:59:59','ARNBTC','4h','0.000080280000000','0.000079060000000','0.001710774530839','0.001684776213355','21.31009629844295','21.310096298442950','test'),('2019-03-09 15:59:59','2019-03-09 19:59:59','ARNBTC','4h','0.000082320000000','0.000080220000000','0.001710774530839','0.001667132323420','20.78200353302964','20.782003533029641','test'),('2019-03-10 15:59:59','2019-03-17 23:59:59','ARNBTC','4h','0.000082360000000','0.000108050000000','0.001710774530839','0.002244404905988','20.77191028216367','20.771910282163670','test'),('2019-03-26 11:59:59','2019-03-27 11:59:59','ARNBTC','4h','0.000108740000000','0.000114070000000','0.001710774530839','0.001794629857760','15.732706739369135','15.732706739369135','test'),('2019-03-27 19:59:59','2019-03-29 11:59:59','ARNBTC','4h','0.000116690000000','0.000110250000000','0.001710774530839','0.001616358659911','14.660849523001113','14.660849523001113','test'),('2019-03-29 15:59:59','2019-03-29 23:59:59','ARNBTC','4h','0.000114100000000','0.000112000000000','0.001710774530839','0.001679287883032','14.993641812787029','14.993641812787029','test'),('2019-03-30 19:59:59','2019-04-02 03:59:59','ARNBTC','4h','0.000114260000000','0.000114130000000','0.001710774530839','0.001708828086860','14.972645990189042','14.972645990189042','test'),('2019-04-18 19:59:59','2019-04-19 03:59:59','ARNBTC','4h','0.000092440000000','0.000089850000000','0.001710774530839','0.001662841752444','18.506864245337514','18.506864245337514','test'),('2019-04-19 07:59:59','2019-04-21 07:59:59','ARNBTC','4h','0.000091670000000','0.000089770000000','0.001710774530839','0.001675316129960','18.662316252198103','18.662316252198103','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 18:32:46
