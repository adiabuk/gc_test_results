-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 23:59:59','2019-01-14 19:59:59','VETETH','4h','0.000031730000000','0.000030920000000','0.072144500000000','0.070302803025528','2273.6999684840844','2273.699968484084366','test'),('2019-01-15 23:59:59','2019-01-16 15:59:59','VETETH','4h','0.000032300000000','0.000031820000000','0.072144500000000','0.071072383591331','2233.5758513931887','2233.575851393188714','test'),('2019-01-16 23:59:59','2019-01-19 23:59:59','VETETH','4h','0.000032390000000','0.000033170000000','0.072144500000000','0.073881848255634','2227.3695585057117','2227.369558505711666','test'),('2019-01-20 23:59:59','2019-01-27 07:59:59','VETETH','4h','0.000033640000000','0.000036390000000','0.072144500000000','0.078042162752675','2144.604637336504','2144.604637336503856','test'),('2019-01-30 03:59:59','2019-01-31 03:59:59','VETETH','4h','0.000037380000000','0.000036750000000','0.073324799406292','0.072088988180343','1961.605120553558','1961.605120553557981','test'),('2019-02-25 15:59:59','2019-03-04 07:59:59','VETETH','4h','0.000032330000000','0.000033140000000','0.073324799406292','0.075161888410904','2268.011116804578','2268.011116804577796','test'),('2019-03-09 15:59:59','2019-03-16 11:59:59','VETETH','4h','0.000034960000000','0.000037830000000','0.073475118850958','0.079506972143356','2101.6910426475333','2101.691042647533322','test'),('2019-03-19 19:59:59','2019-03-25 07:59:59','VETETH','4h','0.000038680000000','0.000041820000000','0.074983082174057','0.081070126590462','1938.549177198998','1938.549177198997995','test'),('2019-03-28 23:59:59','2019-03-29 11:59:59','VETETH','4h','0.000042260000000','0.000041710000000','0.076504843278158','0.075509157906578','1810.3370392370682','1810.337039237068211','test'),('2019-03-29 19:59:59','2019-03-30 03:59:59','VETETH','4h','0.000041600000000','0.000040480000000','0.076504843278158','0.074445097497592','1839.0587326480288','1839.058732648028808','test'),('2019-03-31 03:59:59','2019-04-03 03:59:59','VETETH','4h','0.000042370000000','0.000042390000000','0.076504843278158','0.076540956019852','1805.6370846862874','1805.637084686287380','test'),('2019-04-03 15:59:59','2019-04-06 23:59:59','VETETH','4h','0.000046500000000','0.000045460000000','0.076504843278158','0.074793767213442','1645.2654468421076','1645.265446842107622','test'),('2019-04-07 03:59:59','2019-04-07 19:59:59','VETETH','4h','0.000046170000000','0.000044780000000','0.076504843278158','0.074201578557416','1657.0249789507905','1657.024978950790455','test'),('2019-04-16 19:59:59','2019-04-17 03:59:59','VETETH','4h','0.000042500000000','0.000041850000000','0.076504843278158','0.075334769204492','1800.1139594860704','1800.113959486070371','test'),('2019-04-17 19:59:59','2019-04-18 03:59:59','VETETH','4h','0.000042280000000','0.000041070000000','0.076504843278158','0.074315371651702','1809.4806830217124','1809.480683021712366','test'),('2019-04-19 03:59:59','2019-04-19 15:59:59','VETETH','4h','0.000042430000000','0.000041930000000','0.076504843278158','0.075603301405920','1803.0837444769738','1803.083744476973834','test'),('2019-05-02 07:59:59','2019-05-03 11:59:59','VETETH','4h','0.000039900000000','0.000040180000000','0.076504843278158','0.077041719371338','1917.4146185002005','1917.414618500200504','test'),('2019-05-03 19:59:59','2019-05-03 23:59:59','VETETH','4h','0.000039800000000','0.000039750000000','0.076504843278158','0.076408731666000','1922.232243169799','1922.232243169798949','test'),('2019-05-04 03:59:59','2019-05-04 15:59:59','VETETH','4h','0.000039850000000','0.000039580000000','0.076504843278158','0.075986491767867','1919.8204084857716','1919.820408485771623','test'),('2019-06-04 23:59:59','2019-06-08 07:59:59','VETETH','4h','0.000030730000000','0.000030670000000','0.076504843278158','0.076355468380771','2489.5816231095996','2489.581623109599605','test'),('2019-06-08 23:59:59','2019-06-09 19:59:59','VETETH','4h','0.000031240000000','0.000030760000000','0.076504843278158','0.075329352728430','2448.9386452675417','2448.938645267541688','test'),('2019-06-09 23:59:59','2019-06-11 11:59:59','VETETH','4h','0.000031210000000','0.000030920000000','0.076504843278158','0.075793968412709','2451.29263947959','2451.292639479589980','test'),('2019-06-25 19:59:59','2019-06-26 15:59:59','VETETH','4h','0.000030570000000','0.000025580000000','0.076504843278158','0.064016810306028','2502.611818062087','2502.611818062086968','test'),('2019-06-28 07:59:59','2019-06-28 11:59:59','VETETH','4h','0.000027460000000','0.000026400000000','0.076504843278158','0.073551633741565','2786.0467326350326','2786.046732635032640','test'),('2019-06-28 15:59:59','2019-06-28 19:59:59','VETETH','4h','0.000026660000000','0.000026160000000','0.076504843278158','0.075070018760563','2869.6490351897223','2869.649035189722326','test'),('2019-06-28 23:59:59','2019-06-29 03:59:59','VETETH','4h','0.000026810000000','0.000026320000000','0.076504843278158','0.075106582434954','2853.593557559045','2853.593557559045166','test'),('2019-06-29 07:59:59','2019-06-29 11:59:59','VETETH','4h','0.000026620000000','0.000026210000000','0.076504843278158','0.075326519245700','2873.9610547767843','2873.961054776784295','test'),('2019-06-29 15:59:59','2019-07-02 03:59:59','VETETH','4h','0.000027070000000','0.000027260000000','0.076504843278158','0.077041818535744','2826.185566241522','2826.185566241521883','test'),('2019-07-16 19:59:59','2019-07-18 15:59:59','VETETH','4h','0.000025950000000','0.000025150000000','0.076504843278158','0.074146312464188','2948.163517462736','2948.163517462735854','test'),('2019-07-18 19:59:59','2019-07-19 03:59:59','VETETH','4h','0.000025540000000','0.000025400000000','0.076504843278158','0.076085474520956','2995.491122872279','2995.491122872278993','test'),('2019-07-19 11:59:59','2019-07-24 19:59:59','VETETH','4h','0.000025910000000','0.000027420000000','0.076504843278158','0.080963442789930','2952.714908458433','2952.714908458433001','test'),('2019-07-27 11:59:59','2019-07-28 07:59:59','VETETH','4h','0.000027630000000','0.000027200000000','0.076504843278158','0.075314214157289','2768.904932253275','2768.904932253275092','test'),('2019-08-15 01:59:59','2019-08-17 19:59:59','VETETH','4h','0.000024770000000','0.000024240000000','0.076504843278158','0.074867880543502','3088.608933312798','3088.608933312797944','test'),('2019-08-24 07:59:59','2019-08-25 19:59:59','VETETH','4h','0.000024160000000','0.000023810000000','0.076504843278158','0.075396536359807','3166.591195287997','3166.591195287996925','test'),('2019-08-25 23:59:59','2019-08-26 03:59:59','VETETH','4h','0.000024030000000','0.000023680000000','0.076504843278158','0.075390540525459','3183.722150568373','3183.722150568372854','test'),('2019-08-28 11:59:59','2019-08-29 07:59:59','VETETH','4h','0.000024490000000','0.000024250000000','0.076504843278158','0.075755102061876','3123.9217345103307','3123.921734510330680','test'),('2019-08-29 11:59:59','2019-08-29 19:59:59','VETETH','4h','0.000024260000000','0.000024200000000','0.076504843278158','0.076315630969968','3153.5384698333883','3153.538469833388262','test'),('2019-08-31 03:59:59','2019-08-31 15:59:59','VETETH','4h','0.000024650000000','0.000024290000000','0.076504843278158','0.075387531165374','3103.6447577346044','3103.644757734604354','test'),('2019-09-02 15:59:59','2019-09-02 19:59:59','VETETH','4h','0.000024740000000','0.000024780000000','0.076504843278158','0.076628537446756','3092.354214961924','3092.354214961923844','test'),('2019-09-03 11:59:59','2019-09-03 15:59:59','VETETH','4h','0.000024490000000','0.000024100000000','0.076504843278158','0.075286513801699','3123.9217345103307','3123.921734510330680','test'),('2019-10-09 07:59:59','2019-10-09 15:59:59','VETETH','4h','0.000020460000000','0.000019030000000','0.076504843278158','0.071157730575921','3739.2396519138806','3739.239651913880607','test'),('2019-10-09 23:59:59','2019-10-10 03:59:59','VETETH','4h','0.000019820000000','0.000019570000000','0.076504843278158','0.075539847777677','3859.982001925227','3859.982001925226996','test'),('2019-10-10 07:59:59','2019-10-10 15:59:59','VETETH','4h','0.000020030000000','0.000019540000000','0.076504843278158','0.074633281959821','3819.512894566051','3819.512894566050818','test'),('2019-10-10 19:59:59','2019-10-10 23:59:59','VETETH','4h','0.000019550000000','0.000019520000000','0.076504843278158','0.076387444541670','3913.2912162740663','3913.291216274066301','test'),('2019-10-11 11:59:59','2019-10-13 19:59:59','VETETH','4h','0.000020140000000','0.000019810000000','0.076504843278158','0.075251288249271','3798.6516026890763','3798.651602689076299','test'),('2019-10-27 15:59:59','2019-11-01 23:59:59','VETETH','4h','0.000022300000000','0.000021780000000','0.076504843278158','0.074720873838488','3430.710460903946','3430.710460903946114','test'),('2019-11-02 15:59:59','2019-11-09 15:59:59','VETETH','4h','0.000022620000000','0.000028210000000','0.076504843278158','0.095411212594025','3382.1769795825817','3382.176979582581680','test'),('2019-11-10 23:59:59','2019-11-17 19:59:59','VETETH','4h','0.000030300000000','0.000039240000000','0.076504843278158','0.099077559413694','2524.912319411155','2524.912319411154840','test'),('2019-11-17 23:59:59','2019-11-19 11:59:59','VETETH','4h','0.000041650000000','0.000038260000000','0.076504843278158','0.070277918459119','1836.8509790674188','1836.850979067418848','test'),('2019-11-24 11:59:59','2019-11-29 07:59:59','VETETH','4h','0.000039210000000','0.000041290000000','0.076504843278158','0.080563248634408','1951.1564212741139','1951.156421274113882','test'),('2019-12-01 15:59:59','2019-12-05 11:59:59','VETETH','4h','0.000044240000000','0.000046910000000','0.076504843278158','0.081122111170398','1729.3138173182188','1729.313817318218753','test'),('2019-12-07 07:59:59','2019-12-07 23:59:59','VETETH','4h','0.000047840000000','0.000046310000000','0.076504843278158','0.074058095572983','1599.1815066504598','1599.181506650459824','test'),('2019-12-09 03:59:59','2019-12-09 23:59:59','VETETH','4h','0.000048010000000','0.000046540000000','0.076504843278158','0.074162370467933','1593.5189185202664','1593.518918520266425','test'),('2019-12-21 07:59:59','2019-12-23 03:59:59','VETETH','4h','0.000043110000000','0.000041120000000','0.076504843278158','0.072973304467591','1774.6426183752726','1774.642618375272605','test'),('2019-12-23 07:59:59','2019-12-26 11:59:59','VETETH','4h','0.000041790000000','0.000044630000000','0.076504843278158','0.081704023821589','1830.6973744474276','1830.697374447427592','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 20:34:17
