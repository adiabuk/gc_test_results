-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-28 19:59:59','2018-05-29 03:59:59','STORJETH','4h','0.001313400000000','0.001268900000000','0.072144500000000','0.069700134041419','54.92957210293894','54.929572102938941','test'),('2018-05-29 11:59:59','2018-05-29 15:59:59','STORJETH','4h','0.001285000000000','0.001275100000000','0.072144500000000','0.071588678560311','56.143579766536966','56.143579766536966','test'),('2018-05-30 15:59:59','2018-06-03 11:59:59','STORJETH','4h','0.001289200000000','0.001342000000000','0.072144500000000','0.075099223549488','55.96067328575862','55.960673285758617','test'),('2018-07-02 03:59:59','2018-07-04 15:59:59','STORJETH','4h','0.001087300000000','0.001113700000000','0.072144500000000','0.073896192081302','66.3519727766026','66.351972776602594','test'),('2018-07-04 19:59:59','2018-07-05 19:59:59','STORJETH','4h','0.001128700000000','0.001069700000000','0.072571057058130','0.068777584597397','64.29614340225923','64.296143402259233','test'),('2018-07-18 19:59:59','2018-07-20 23:59:59','STORJETH','4h','0.001052500000000','0.001006800000000','0.072571057058130','0.069419990732661','68.95112309561044','68.951123095610441','test'),('2018-07-22 15:59:59','2018-07-23 11:59:59','STORJETH','4h','0.001035400000000','0.001020000000000','0.072571057058130','0.071491672975944','70.08987546661194','70.089875466611943','test'),('2018-07-23 19:59:59','2018-07-24 03:59:59','STORJETH','4h','0.001037100000000','0.001015000000000','0.072571057058130','0.071024609887187','69.97498511052936','69.974985110529360','test'),('2018-07-24 11:59:59','2018-07-24 15:59:59','STORJETH','4h','0.001039700000000','0.001029900000000','0.072571057058130','0.071887017085859','69.79999717046263','69.799997170462632','test'),('2018-07-24 19:59:59','2018-07-27 15:59:59','STORJETH','4h','0.001041200000000','0.001073400000000','0.072571057058130','0.074815379030154','69.6994401249808','69.699440124980796','test'),('2018-08-06 11:59:59','2018-08-08 15:59:59','STORJETH','4h','0.001125600000000','0.001161700000000','0.072571057058130','0.074898540320211','64.47322055626331','64.473220556263314','test'),('2018-08-08 23:59:59','2018-08-10 07:59:59','STORJETH','4h','0.001171600000000','0.001143400000000','0.072571057058130','0.070824297234778','61.941837707519625','61.941837707519625','test'),('2018-08-10 19:59:59','2018-08-11 19:59:59','STORJETH','4h','0.001194100000000','0.001045400000000','0.072571057058130','0.063533860688861','60.7746897731597','60.774689773159700','test'),('2018-08-25 23:59:59','2018-08-26 11:59:59','STORJETH','4h','0.001038300000000','0.001028500000000','0.072571057058130','0.071886094755164','69.8941125475585','69.894112547558507','test'),('2018-08-26 15:59:59','2018-08-29 15:59:59','STORJETH','4h','0.001050100000000','0.001064900000000','0.072571057058130','0.073593865975814','69.1087106543472','69.108710654347206','test'),('2018-08-29 19:59:59','2018-09-02 03:59:59','STORJETH','4h','0.001195200000000','0.001118100000000','0.072571057058130','0.067889640977824','60.718755905396584','60.718755905396584','test'),('2018-09-05 19:59:59','2018-09-10 23:59:59','STORJETH','4h','0.001215400000000','0.001191300000000','0.072571057058130','0.071132055515345','59.709607584441336','59.709607584441336','test'),('2018-09-11 11:59:59','2018-09-13 03:59:59','STORJETH','4h','0.001242600000000','0.001208000000000','0.072571057058130','0.070550327479656','58.40258897322549','58.402588973225491','test'),('2018-09-16 15:59:59','2018-09-18 15:59:59','STORJETH','4h','0.001389900000000','0.001214700000000','0.072571057058130','0.063423313194122','52.213149908720055','52.213149908720055','test'),('2018-09-18 19:59:59','2018-09-18 23:59:59','STORJETH','4h','0.001232000000000','0.001211300000000','0.072571057058130','0.071351721927364','58.90507878094967','58.905078780949673','test'),('2018-09-19 03:59:59','2018-09-21 19:59:59','STORJETH','4h','0.001285700000000','0.001225100000000','0.072571057058130','0.069150503229303','56.44478265390837','56.444782653908369','test'),('2018-10-08 19:59:59','2018-10-17 07:59:59','STORJETH','4h','0.001243000000000','0.001689000000000','0.072571057058130','0.098610229582608','58.38379489793242','58.383794897932418','test'),('2018-10-21 19:59:59','2018-10-24 03:59:59','STORJETH','4h','0.001724200000000','0.001682700000000','0.072571057058130','0.070824334596749','42.089697864592274','42.089697864592274','test'),('2018-11-01 11:59:59','2018-11-02 15:59:59','STORJETH','4h','0.001728300000000','0.001654100000000','0.072571057058130','0.069455410218048','41.989849596788744','41.989849596788744','test'),('2018-11-27 23:59:59','2018-12-03 19:59:59','STORJETH','4h','0.001337200000000','0.001501000000000','0.072571057058130','0.081460631651401','54.2709071628253','54.270907162825303','test'),('2018-12-12 19:59:59','2018-12-13 15:59:59','STORJETH','4h','0.001493200000000','0.001465800000000','0.072571057058130','0.071239388853340','48.601029371905966','48.601029371905966','test'),('2018-12-13 19:59:59','2018-12-14 03:59:59','STORJETH','4h','0.001486700000000','0.001440400000000','0.072571057058130','0.070310991179478','48.813517897444','48.813517897444001','test'),('2019-01-13 07:59:59','2019-01-14 15:59:59','STORJETH','4h','0.001038100000000','0.000986600000000','0.072571057058130','0.068970816774445','69.90757832398613','69.907578323986129','test'),('2019-01-15 19:59:59','2019-01-26 03:59:59','STORJETH','4h','0.001060000000000','0.001214000000000','0.072571057058130','0.083114399309972','68.46326137559434','68.463261375594342','test'),('2019-01-30 07:59:59','2019-01-30 15:59:59','STORJETH','4h','0.001237700000000','0.001202000000000','0.072571057058130','0.070477830317421','58.633802260749775','58.633802260749775','test'),('2019-01-31 11:59:59','2019-02-01 03:59:59','STORJETH','4h','0.001234900000000','0.001209000000000','0.072571057058130','0.071048998285917','58.76674796188355','58.766747961883553','test'),('2019-02-01 07:59:59','2019-02-01 11:59:59','STORJETH','4h','0.001215400000000','0.001240600000000','0.072571057058130','0.074075739169258','59.709607584441336','59.709607584441336','test'),('2019-02-01 19:59:59','2019-02-02 03:59:59','STORJETH','4h','0.001251000000000','0.001211000000000','0.072571057058130','0.070250639566263','58.010437296666666','58.010437296666666','test'),('2019-02-02 07:59:59','2019-02-02 11:59:59','STORJETH','4h','0.001222800000000','0.001218100000000','0.072571057058130','0.072292120217949','59.34826386827772','59.348263868277719','test'),('2019-02-03 19:59:59','2019-02-03 23:59:59','STORJETH','4h','0.001254500000000','0.001232900000000','0.072571057058130','0.071321527498580','57.848590719912316','57.848590719912316','test'),('2019-02-04 03:59:59','2019-02-06 03:59:59','STORJETH','4h','0.001238100000000','0.001262000000000','0.072571057058130','0.073971952190744','58.61485910518536','58.614859105185360','test'),('2019-02-07 11:59:59','2019-02-08 11:59:59','STORJETH','4h','0.001428700000000','0.001290000000000','0.072571057058130','0.065525767204443','50.7951683755372','50.795168375537202','test'),('2019-02-16 11:59:59','2019-02-18 15:59:59','STORJETH','4h','0.001650500000000','0.001576000000000','0.072571057058130','0.069295356512337','43.96913484285368','43.969134842853677','test'),('2019-02-20 07:59:59','2019-02-21 19:59:59','STORJETH','4h','0.001911300000000','0.001613500000000','0.072571057058130','0.061263747482495','37.969474733495524','37.969474733495524','test'),('2019-02-26 19:59:59','2019-02-28 11:59:59','STORJETH','4h','0.001674000000000','0.001607800000000','0.072571057058130','0.069701162209117','43.35188593675627','43.351885936756268','test'),('2019-03-01 15:59:59','2019-03-04 07:59:59','STORJETH','4h','0.001669100000000','0.001639500000000','0.072571057058130','0.071284074079926','43.47915466906117','43.479154669061167','test'),('2019-03-10 03:59:59','2019-03-13 19:59:59','STORJETH','4h','0.001652300000000','0.001907100000000','0.072571057058130','0.083762187808243','43.92123528301761','43.921235283017609','test'),('2019-03-14 11:59:59','2019-03-14 19:59:59','STORJETH','4h','0.002035100000000','0.001907900000000','0.072571057058130','0.068035143118867','35.65970078036951','35.659700780369512','test'),('2019-03-14 23:59:59','2019-03-15 03:59:59','STORJETH','4h','0.001943500000000','0.001903800000000','0.072571057058130','0.071088643389384','37.340394678739386','37.340394678739386','test'),('2019-03-15 07:59:59','2019-03-16 03:59:59','STORJETH','4h','0.001988300000000','0.001827500000000','0.072571057058130','0.066702010146222','36.499047959628825','36.499047959628825','test'),('2019-03-19 03:59:59','2019-03-21 15:59:59','STORJETH','4h','0.001909100000000','0.001932000000000','0.072571057058130','0.073441560021113','38.01322982459274','38.013229824592742','test'),('2019-03-21 19:59:59','2019-03-23 19:59:59','STORJETH','4h','0.001938200000000','0.001944500000000','0.072571057058130','0.072806944819695','37.442501835790935','37.442501835790935','test'),('2019-03-24 07:59:59','2019-03-25 15:59:59','STORJETH','4h','0.001989600000000','0.001955200000000','0.072571057058130','0.071316310193032','36.47519956681243','36.475199566812428','test'),('2019-03-26 19:59:59','2019-03-29 23:59:59','STORJETH','4h','0.002048100000000','0.002034000000000','0.072571057058130','0.072071446734162','35.433356309813966','35.433356309813966','test'),('2019-03-30 07:59:59','2019-04-02 07:59:59','STORJETH','4h','0.002163700000000','0.002197800000000','0.072571057058130','0.073714779868909','33.54025838061191','33.540258380611910','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  9:10:59
