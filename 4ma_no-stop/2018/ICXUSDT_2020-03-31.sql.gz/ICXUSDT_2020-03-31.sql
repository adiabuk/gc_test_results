-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-12-19 11:59:59','2018-12-25 03:59:59','ICXUSDT','4h','0.234700000000000','0.235700000000000','15.000000000000000','15.063911376224969','63.911376224968045','63.911376224968045','test'),('2019-01-02 11:59:59','2019-01-08 07:59:59','ICXUSDT','4h','0.242900000000000','0.265800000000000','15.015977844056241','16.431646401606212','61.81958766593759','61.819587665937590','test'),('2019-01-08 11:59:59','2019-01-10 07:59:59','ICXUSDT','4h','0.278200000000000','0.259700000000000','15.369894983443736','14.347813541338382','55.24764551920825','55.247645519208248','test'),('2019-02-08 07:59:59','2019-02-13 19:59:59','ICXUSDT','4h','0.209000000000000','0.218400000000000','15.369894983443736','16.061172556861781','73.54016738489825','73.540167384898254','test'),('2019-02-15 19:59:59','2019-02-16 11:59:59','ICXUSDT','4h','0.225700000000000','0.220800000000000','15.369894983443736','15.036210954117752','68.09878149509852','68.098781495098521','test'),('2019-02-16 15:59:59','2019-02-24 15:59:59','ICXUSDT','4h','0.224200000000000','0.240200000000000','15.369894983443736','16.466765276642217','68.55439332490515','68.554393324905149','test'),('2019-02-24 19:59:59','2019-02-24 23:59:59','ICXUSDT','4h','0.243100000000000','0.232400000000000','15.477990582240032','14.796729787382079','63.66923316429466','63.669233164294660','test'),('2019-02-26 07:59:59','2019-03-02 19:59:59','ICXUSDT','4h','0.286500000000000','0.279100000000000','15.477990582240032','15.078210022698755','54.02439993801059','54.024399938010589','test'),('2019-03-03 03:59:59','2019-03-03 23:59:59','ICXUSDT','4h','0.294700000000000','0.280100000000000','15.477990582240032','14.711181411894920','52.521176051035056','52.521176051035056','test'),('2019-03-06 07:59:59','2019-03-11 11:59:59','ICXUSDT','4h','0.285400000000000','0.323400000000000','15.477990582240032','17.538830253316142','54.23262292305548','54.232622923055480','test'),('2019-03-13 03:59:59','2019-03-13 15:59:59','ICXUSDT','4h','0.341900000000000','0.331900000000000','15.531237868822974','15.076975281258687','45.42625875642871','45.426258756428709','test'),('2019-03-15 15:59:59','2019-03-17 03:59:59','ICXUSDT','4h','0.345900000000000','0.327100000000000','15.531237868822974','14.687100048834909','44.90094787170562','44.900947871705618','test'),('2019-03-19 15:59:59','2019-03-20 03:59:59','ICXUSDT','4h','0.337400000000000','0.335900000000000','15.531237868822974','15.462189686240773','46.03212172146703','46.032121721467028','test'),('2019-03-20 11:59:59','2019-03-20 15:59:59','ICXUSDT','4h','0.335400000000000','0.333800000000000','15.531237868822974','15.457147288649699','46.30661260829748','46.306612608297478','test'),('2019-03-20 19:59:59','2019-03-21 07:59:59','ICXUSDT','4h','0.334900000000000','0.337500000000000','15.531237868822974','15.651814812564211','46.375747592782844','46.375747592782844','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','ICXUSDT','4h','0.341300000000000','0.318600000000000','15.531237868822974','14.498249003829475','45.50611740059471','45.506117400594711','test'),('2019-03-25 07:59:59','2019-03-25 15:59:59','ICXUSDT','4h','0.338100000000000','0.319900000000000','15.531237868822974','14.695187797209314','45.936817121629616','45.936817121629616','test'),('2019-03-29 23:59:59','2019-04-08 11:59:59','ICXUSDT','4h','0.333700000000000','0.407900000000000','15.531237868822974','18.984692618198650','46.542516837947176','46.542516837947176','test'),('2019-04-22 19:59:59','2019-04-23 23:59:59','ICXUSDT','4h','0.405000000000000','0.376600000000000','15.597101265373457','14.503378608739860','38.51136114907026','38.511361149070261','test'),('2019-04-25 11:59:59','2019-04-25 19:59:59','ICXUSDT','4h','0.390100000000000','0.378700000000000','15.597101265373457','15.141302869000071','39.982315471349544','39.982315471349544','test'),('2019-05-13 11:59:59','2019-05-13 23:59:59','ICXUSDT','4h','0.339900000000000','0.329500000000000','15.597101265373457','15.119873100737143','45.88732352272274','45.887323522722738','test'),('2019-05-14 03:59:59','2019-05-17 03:59:59','ICXUSDT','4h','0.342200000000000','0.358100000000000','15.597101265373457','16.321805853682744','45.57890492511238','45.578904925112383','test'),('2019-05-17 07:59:59','2019-05-17 11:59:59','ICXUSDT','4h','0.360600000000000','0.346400000000000','15.597101265373457','14.982905929909499','43.25319263830687','43.253192638306871','test'),('2019-05-18 11:59:59','2019-05-20 15:59:59','ICXUSDT','4h','0.376800000000000','0.370200000000000','15.597101265373457','15.323903631744301','41.393580852901955','41.393580852901955','test'),('2019-05-21 07:59:59','2019-05-22 23:59:59','ICXUSDT','4h','0.385300000000000','0.374500000000000','15.597101265373457','15.159912857208305','40.48040816344007','40.480408163440067','test'),('2019-05-24 23:59:59','2019-05-25 07:59:59','ICXUSDT','4h','0.386000000000000','0.379000000000000','15.597101265373457','15.314252278695699','40.40699809682243','40.406998096822427','test'),('2019-05-27 15:59:59','2019-05-28 15:59:59','ICXUSDT','4h','0.385900000000000','0.390900000000000','15.597101265373457','15.799188610091953','40.41746894369903','40.417468943699028','test'),('2019-05-28 19:59:59','2019-05-29 07:59:59','ICXUSDT','4h','0.400400000000000','0.389200000000000','15.597101265373457','15.160818712495878','38.953799364069575','38.953799364069575','test'),('2019-05-29 11:59:59','2019-05-30 23:59:59','ICXUSDT','4h','0.396700000000000','0.386800000000000','15.597101265373457','15.207861783328593','39.31711939847103','39.317119398471029','test'),('2019-06-02 11:59:59','2019-06-03 07:59:59','ICXUSDT','4h','0.415100000000000','0.403700000000000','15.597101265373457','15.168753988993650','37.57432248945665','37.574322489456648','test'),('2019-06-03 11:59:59','2019-06-03 15:59:59','ICXUSDT','4h','0.405600000000000','0.401900000000000','15.597101265373457','15.454820016157770','38.454391679914835','38.454391679914835','test'),('2019-06-03 19:59:59','2019-06-03 23:59:59','ICXUSDT','4h','0.410500000000000','0.386200000000000','15.597101265373457','14.673813663062678','37.995374580690516','37.995374580690516','test'),('2019-06-12 19:59:59','2019-06-14 03:59:59','ICXUSDT','4h','0.393300000000000','0.382500000000000','15.597101265373457','15.168805578452448','39.65700804824169','39.657008048241693','test'),('2019-07-07 23:59:59','2019-07-09 03:59:59','ICXUSDT','4h','0.354300000000000','0.325300000000000','15.597101265373457','14.320454534648562','44.02230105947913','44.022301059479133','test'),('2019-07-09 07:59:59','2019-07-09 15:59:59','ICXUSDT','4h','0.328100000000000','0.338100000000000','15.597101265373457','16.072477713571367','47.53764481979109','47.537644819791090','test'),('2019-07-26 19:59:59','2019-07-27 11:59:59','ICXUSDT','4h','0.282500000000000','0.263100000000000','15.597101265373457','14.526008293521263','55.210977930525516','55.210977930525516','test'),('2019-08-22 23:59:59','2019-08-25 23:59:59','ICXUSDT','4h','0.225500000000000','0.223100000000000','15.597101265373457','15.431101074522473','69.1667461879089','69.166746187908899','test'),('2019-08-26 23:59:59','2019-08-27 07:59:59','ICXUSDT','4h','0.240200000000000','0.231900000000000','15.597101265373457','15.058150638801434','64.9338104303641','64.933810430364105','test'),('2019-09-18 03:59:59','2019-09-19 03:59:59','ICXUSDT','4h','0.213800000000000','0.204800000000000','15.597101265373457','14.940534794894688','72.95183005319672','72.951830053196716','test'),('2019-09-19 07:59:59','2019-09-20 11:59:59','ICXUSDT','4h','0.209300000000000','0.207600000000000','15.597101265373457','15.470416735267699','74.5203118269157','74.520311826915702','test'),('2019-10-08 11:59:59','2019-10-09 15:59:59','ICXUSDT','4h','0.172500000000000','0.175300000000000','15.597101265373457','15.850271604753434','90.41797834999106','90.417978349991060','test'),('2019-10-09 19:59:59','2019-10-10 11:59:59','ICXUSDT','4h','0.175500000000000','0.171600000000000','15.597101265373457','15.250499015031826','88.87237188246985','88.872371882469849','test'),('2019-10-28 03:59:59','2019-10-31 11:59:59','ICXUSDT','4h','0.172200000000000','0.161700000000000','15.597101265373457','14.646058505289711','90.57550096035689','90.575500960356891','test'),('2019-11-03 07:59:59','2019-11-03 11:59:59','ICXUSDT','4h','0.164500000000000','0.162800000000000','15.597101265373457','15.435915416430387','94.81520526062891','94.815205260628915','test'),('2019-11-03 15:59:59','2019-11-08 07:59:59','ICXUSDT','4h','0.165300000000000','0.173900000000000','15.597101265373457','16.408565699022649','94.3563294940923','94.356329494092293','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  6:15:08
