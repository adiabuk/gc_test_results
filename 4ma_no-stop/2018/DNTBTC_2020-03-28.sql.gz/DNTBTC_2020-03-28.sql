-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-09 15:59:59','2018-04-12 11:59:59','DNTBTC','4h','0.000008030000000','0.000008080000000','0.001467500000000','0.001476637608966','182.75217932752182','182.752179327521816','test'),('2018-04-13 19:59:59','2018-04-16 23:59:59','DNTBTC','4h','0.000008850000000','0.000009150000000','0.001469784402242','0.001519607602318','166.0773335866102','166.077333586610195','test'),('2018-04-18 07:59:59','2018-04-21 03:59:59','DNTBTC','4h','0.000009360000000','0.000009430000000','0.001482240202261','0.001493325331979','158.35899596800215','158.358995968002148','test'),('2018-04-22 15:59:59','2018-04-25 03:59:59','DNTBTC','4h','0.000010650000000','0.000010150000000','0.001485011484690','0.001415292635644','139.43769809295776','139.437698092957760','test'),('2018-04-30 11:59:59','2018-05-01 03:59:59','DNTBTC','4h','0.000011530000000','0.000011050000000','0.001485011484690','0.001423189670930','128.79544533304423','128.795445333044228','test'),('2018-05-01 07:59:59','2018-05-04 11:59:59','DNTBTC','4h','0.000011220000000','0.000011360000000','0.001485011484690','0.001503541039757','132.3539647673797','132.353964767379694','test'),('2018-07-03 03:59:59','2018-07-06 03:59:59','DNTBTC','4h','0.000006120000000','0.000005910000000','0.001485011484690','0.001434055208255','242.64893540686276','242.648935406862762','test'),('2018-07-07 15:59:59','2018-07-09 03:59:59','DNTBTC','4h','0.000006280000000','0.000006010000000','0.001485011484690','0.001421165449520','236.46679692515923','236.466796925159230','test'),('2018-07-29 11:59:59','2018-07-29 19:59:59','DNTBTC','4h','0.000007710000000','0.000005960000000','0.001485011484690','0.001147946621109','192.60849347470815','192.608493474708155','test'),('2018-07-29 23:59:59','2018-07-30 19:59:59','DNTBTC','4h','0.000006140000000','0.000005190000000','0.001485011484690','0.001255245864095','241.858547995114','241.858547995114009','test'),('2018-08-27 15:59:59','2018-08-30 03:59:59','DNTBTC','4h','0.000003820000000','0.000003590000000','0.001485011484690','0.001395599798439','388.746461960733','388.746461960732972','test'),('2018-09-01 11:59:59','2018-09-02 03:59:59','DNTBTC','4h','0.000003650000000','0.000003590000000','0.001485011484690','0.001460600336996','406.8524615589041','406.852461558904110','test'),('2018-09-02 07:59:59','2018-09-02 11:59:59','DNTBTC','4h','0.000003620000000','0.000003470000000','0.001485011484690','0.001423477859634','410.22416704143643','410.224167041436431','test'),('2018-09-03 23:59:59','2018-09-04 07:59:59','DNTBTC','4h','0.000003570000000','0.000003540000000','0.001485011484690','0.001472532396583','415.9696035546218','415.969603554621813','test'),('2018-09-04 11:59:59','2018-09-05 11:59:59','DNTBTC','4h','0.000003590000000','0.000003470000000','0.001485011484690','0.001435373217792','413.6522241476323','413.652224147632296','test'),('2018-09-17 03:59:59','2018-09-18 03:59:59','DNTBTC','4h','0.000003590000000','0.000003240000000','0.001485011484690','0.001340233206238','413.6522241476323','413.652224147632296','test'),('2018-09-18 07:59:59','2018-09-19 15:59:59','DNTBTC','4h','0.000003310000000','0.000003410000000','0.001485011484690','0.001529875879998','448.6439530785498','448.643953078549828','test'),('2018-09-19 19:59:59','2018-09-23 03:59:59','DNTBTC','4h','0.000003600000000','0.000003650000000','0.001485011484690','0.001505636644200','412.5031901916667','412.503190191666704','test'),('2018-09-23 11:59:59','2018-09-24 07:59:59','DNTBTC','4h','0.000003880000000','0.000003570000000','0.001485011484690','0.001366363659882','382.73491873453605','382.734918734536052','test'),('2018-09-27 19:59:59','2018-09-28 11:59:59','DNTBTC','4h','0.000003640000000','0.000003620000000','0.001485011484690','0.001476852080928','407.9701881016484','407.970188101648375','test'),('2018-09-28 23:59:59','2018-09-29 03:59:59','DNTBTC','4h','0.000003590000000','0.000003580000000','0.001485011484690','0.001480874962449','413.6522241476323','413.652224147632296','test'),('2018-09-29 15:59:59','2018-10-01 15:59:59','DNTBTC','4h','0.000003700000000','0.000003590000000','0.001485011484690','0.001440862494605','401.35445532162163','401.354455321621629','test'),('2018-10-02 11:59:59','2018-10-03 07:59:59','DNTBTC','4h','0.000003670000000','0.000003620000000','0.001485011484690','0.001464779720593','404.6352819318801','404.635281931880115','test'),('2018-10-03 23:59:59','2018-10-05 07:59:59','DNTBTC','4h','0.000003690000000','0.000003710000000','0.001485011484690','0.001493060327425','402.44213677235774','402.442136772357742','test'),('2018-10-05 11:59:59','2018-10-09 11:59:59','DNTBTC','4h','0.000003750000000','0.000003740000000','0.001485011484690','0.001481051454064','396.00306258399996','396.003062583999963','test'),('2018-10-10 15:59:59','2018-10-11 03:59:59','DNTBTC','4h','0.000004530000000','0.000003810000000','0.001485011484690','0.001248983169243','327.81710478807946','327.817104788079462','test'),('2018-10-11 07:59:59','2018-10-11 19:59:59','DNTBTC','4h','0.000004230000000','0.000003830000000','0.000990007656460','0.000896389911168','234.04436322931443','234.044363229314428','test'),('2018-10-19 11:59:59','2018-10-21 23:59:59','DNTBTC','4h','0.000004050000000','0.000003860000000','0.001076939435994','0.001026416351342','265.91097185043213','265.910971850432134','test'),('2018-10-24 03:59:59','2018-10-26 07:59:59','DNTBTC','4h','0.000004050000000','0.000003920000000','0.001076939435994','0.001042371009653','265.9109718503704','265.910971850370402','test'),('2018-10-26 23:59:59','2018-10-27 15:59:59','DNTBTC','4h','0.000004040000000','0.000003910000000','0.001076939435994','0.001042285444242','266.5691673252475','266.569167325247520','test'),('2018-10-27 23:59:59','2018-10-29 15:59:59','DNTBTC','4h','0.000004110000000','0.000004080000000','0.001076939435994','0.001069078564198','262.0290598525548','262.029059852554781','test'),('2018-10-30 19:59:59','2018-11-02 23:59:59','DNTBTC','4h','0.000004590000000','0.000004770000000','0.001076939435994','0.001119172355053','234.62732810326798','234.627328103267985','test'),('2018-11-10 11:59:59','2018-11-11 07:59:59','DNTBTC','4h','0.000004660000000','0.000004470000000','0.001076939435994','0.001033029888175','231.10288326051503','231.102883260515028','test'),('2018-11-11 11:59:59','2018-11-11 15:59:59','DNTBTC','4h','0.000004500000000','0.000004460000000','0.001076939435994','0.001067366641007','239.31987466533334','239.319874665333344','test'),('2018-12-02 03:59:59','2018-12-02 07:59:59','DNTBTC','4h','0.000003150000000','0.000003130000000','0.001076939435994','0.001070101725289','341.8855352361905','341.885535236190492','test'),('2018-12-02 11:59:59','2018-12-02 15:59:59','DNTBTC','4h','0.000003150000000','0.000003110000000','0.001076939435994','0.001063264014585','341.8855352361905','341.885535236190492','test'),('2018-12-02 19:59:59','2018-12-02 23:59:59','DNTBTC','4h','0.000003120000000','0.000003110000000','0.001076939435994','0.001073487707032','345.17289615192306','345.172896151923055','test'),('2018-12-04 23:59:59','2018-12-05 03:59:59','DNTBTC','4h','0.000003170000000','0.000003130000000','0.001076939435994','0.001063350294846','339.7285287047319','339.728528704731900','test'),('2018-12-05 11:59:59','2018-12-06 03:59:59','DNTBTC','4h','0.000003110000000','0.000003060000000','0.001076939435994','0.001059625297152','346.28277684694535','346.282776846945353','test'),('2018-12-07 19:59:59','2018-12-11 19:59:59','DNTBTC','4h','0.000004120000000','0.000003880000000','0.001076939435994','0.001014205099917','261.39306698883496','261.393066988834960','test'),('2019-01-06 23:59:59','2019-01-07 11:59:59','DNTBTC','4h','0.000003200000000','0.000003060000000','0.001076939435994','0.001029823335669','336.543573748125','336.543573748125027','test'),('2019-01-07 15:59:59','2019-01-07 19:59:59','DNTBTC','4h','0.000003080000000','0.000003090000000','0.001076939435994','0.001080435992604','349.655661037013','349.655661037012976','test'),('2019-01-08 19:59:59','2019-01-08 23:59:59','DNTBTC','4h','0.000003090000000','0.000003060000000','0.001076939435994','0.001066483713314','348.5240893184466','348.524089318446613','test'),('2019-01-09 03:59:59','2019-01-09 11:59:59','DNTBTC','4h','0.000003090000000','0.000003100000000','0.001076939435994','0.001080424676887','348.5240893184466','348.524089318446613','test'),('2019-01-09 19:59:59','2019-01-10 07:59:59','DNTBTC','4h','0.000003110000000','0.000003060000000','0.001076939435994','0.001059625297152','346.28277684694535','346.282776846945353','test'),('2019-01-15 23:59:59','2019-01-21 03:59:59','DNTBTC','4h','0.000003380000000','0.000003250000000','0.001076939435994','0.001035518688456','318.6211349094675','318.621134909467514','test'),('2019-01-21 19:59:59','2019-01-26 23:59:59','DNTBTC','4h','0.000003310000000','0.000003470000000','0.001076939435994','0.001128996931389','325.3593462217523','325.359346221752276','test'),('2019-02-11 19:59:59','2019-02-11 23:59:59','DNTBTC','4h','0.000003050000000','0.000003040000000','0.001076939435994','0.001073408487024','353.0948970472131','353.094897047213124','test'),('2019-02-14 07:59:59','2019-02-14 11:59:59','DNTBTC','4h','0.000003060000000','0.000003060000000','0.001076939435994','0.001076939435994','351.940992154902','351.940992154902005','test'),('2019-02-14 19:59:59','2019-02-15 11:59:59','DNTBTC','4h','0.000003060000000','0.000003080000000','0.001076939435994','0.001083978255837','351.940992154902','351.940992154902005','test'),('2019-02-15 19:59:59','2019-02-15 23:59:59','DNTBTC','4h','0.000003080000000','0.000003050000000','0.001076939435994','0.001066449766163','349.655661037013','349.655661037012976','test'),('2019-02-17 11:59:59','2019-02-17 15:59:59','DNTBTC','4h','0.000003070000000','0.000003040000000','0.001076939435994','0.001066415597857','350.7946045583062','350.794604558306219','test'),('2019-02-17 19:59:59','2019-02-18 15:59:59','DNTBTC','4h','0.000003150000000','0.000003130000000','0.001076939435994','0.001070101725289','341.8855352361905','341.885535236190492','test'),('2019-02-22 19:59:59','2019-02-23 11:59:59','DNTBTC','4h','0.000003190000000','0.000003080000000','0.001076939435994','0.001039803593374','337.59856927711604','337.598569277116042','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','DNTBTC','4h','0.000003150000000','0.000003120000000','0.001076939435994','0.001066682869937','341.8855352361905','341.885535236190492','test'),('2019-02-23 23:59:59','2019-02-24 15:59:59','DNTBTC','4h','0.000003130000000','0.000003080000000','0.001076939435994','0.001059735930627','344.07010734632587','344.070107346325869','test'),('2019-02-25 23:59:59','2019-02-27 23:59:59','DNTBTC','4h','0.000003130000000','0.000003210000000','0.001076939435994','0.001104465044582','344.07010734632587','344.070107346325869','test'),('2019-02-28 03:59:59','2019-02-28 11:59:59','DNTBTC','4h','0.000003220000000','0.000003190000000','0.001076939435994','0.001066905838764','334.4532409919255','334.453240991925497','test'),('2019-03-01 15:59:59','2019-03-02 11:59:59','DNTBTC','4h','0.000003290000000','0.000003240000000','0.001076939435994','0.001060572575265','327.33721458784197','327.337214587841970','test'),('2019-03-02 15:59:59','2019-03-04 03:59:59','DNTBTC','4h','0.000003260000000','0.000003280000000','0.001076939435994','0.001083546426399','330.3495202435583','330.349520243558288','test'),('2019-03-04 19:59:59','2019-03-07 11:59:59','DNTBTC','4h','0.000003400000000','0.000003280000000','0.001076939435994','0.001038929808841','316.7468929394118','316.746892939411794','test'),('2019-03-10 03:59:59','2019-03-11 07:59:59','DNTBTC','4h','0.000003460000000','0.000003340000000','0.001076939435994','0.001039588935324','311.25417225260117','311.254172252601165','test'),('2019-03-12 11:59:59','2019-03-17 03:59:59','DNTBTC','4h','0.000003510000000','0.000003600000000','0.001076939435994','0.001104553267686','306.82035213504275','306.820352135042754','test'),('2019-03-17 15:59:59','2019-03-19 03:59:59','DNTBTC','4h','0.000003720000000','0.000003620000000','0.001076939435994','0.001047989451155','289.4998483854839','289.499848385483915','test'),('2019-03-20 19:59:59','2019-03-21 15:59:59','DNTBTC','4h','0.000003710000000','0.000003630000000','0.001076939435994','0.001053717022280','290.2801714269542','290.280171426954212','test'),('2019-03-22 03:59:59','2019-03-22 23:59:59','DNTBTC','4h','0.000003680000000','0.000003640000000','0.001076939435994','0.001065233572559','292.6465858679348','292.646585867934789','test'),('2019-03-27 03:59:59','2019-03-31 15:59:59','DNTBTC','4h','0.000003730000000','0.000003990000000','0.001076939435994','0.001152007600433','288.7237093817695','288.723709381769481','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:54:05
