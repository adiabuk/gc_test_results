-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-30 19:59:59','2018-03-31 07:59:59','ENGETH','4h','0.003785000000000','0.003672400000000','0.072144500000000','0.069998272602378','19.060634081902244','19.060634081902244','test'),('2018-04-02 19:59:59','2018-04-03 23:59:59','ENGETH','4h','0.003833500000000','0.003628600000000','0.072144500000000','0.068288387296205','18.819486109299596','18.819486109299596','test'),('2018-04-14 11:59:59','2018-04-16 03:59:59','ENGETH','4h','0.003595400000000','0.003564900000000','0.072144500000000','0.071532493755910','20.065778494743284','20.065778494743284','test'),('2018-04-16 07:59:59','2018-04-16 11:59:59','ENGETH','4h','0.003574500000000','0.003591600000000','0.072144500000000','0.072489631053294','20.183102531822634','20.183102531822634','test'),('2018-04-16 15:59:59','2018-04-17 03:59:59','ENGETH','4h','0.003609300000000','0.003622700000000','0.072144500000000','0.072412345925803','19.988501925581136','19.988501925581136','test'),('2018-04-17 07:59:59','2018-04-23 11:59:59','ENGETH','4h','0.003635000000000','0.003988700000000','0.072144500000000','0.079164447634113','19.847180192572214','19.847180192572214','test'),('2018-04-29 23:59:59','2018-05-01 07:59:59','ENGETH','4h','0.004150000000000','0.003950000000000','0.072399144566926','0.068910029166110','17.445577004078494','17.445577004078494','test'),('2018-05-01 11:59:59','2018-05-02 07:59:59','ENGETH','4h','0.004045000000000','0.004021000000000','0.072399144566926','0.071969582275305','17.898428817534242','17.898428817534242','test'),('2018-05-02 15:59:59','2018-05-03 03:59:59','ENGETH','4h','0.004008500000000','0.004085600000000','0.072399144566926','0.073791678942905','18.06140565471523','18.061405654715230','test'),('2018-05-03 07:59:59','2018-05-03 11:59:59','ENGETH','4h','0.004132500000000','0.004028900000000','0.072399144566926','0.070584129109664','17.51945422067175','17.519454220671751','test'),('2018-05-13 11:59:59','2018-05-15 23:59:59','ENGETH','4h','0.003894500000000','0.003724200000000','0.072399144566926','0.069233250531813','18.59010003002337','18.590100030023368','test'),('2018-06-01 19:59:59','2018-06-01 23:59:59','ENGETH','4h','0.003380600000000','0.003309700000000','0.072399144566926','0.070880745658509','21.41606358839437','21.416063588394369','test'),('2018-06-02 11:59:59','2018-06-03 11:59:59','ENGETH','4h','0.003554100000000','0.003283000000000','0.072399144566926','0.066876675280160','20.370598623259333','20.370598623259333','test'),('2018-06-07 03:59:59','2018-06-08 11:59:59','ENGETH','4h','0.003523100000000','0.003301200000000','0.072399144566926','0.067839134865413','20.54984092615197','20.549840926151969','test'),('2018-06-21 11:59:59','2018-06-23 11:59:59','ENGETH','4h','0.003260100000000','0.003050600000000','0.072399144566926','0.067746642868582','22.20764533815711','22.207645338157111','test'),('2018-06-23 19:59:59','2018-06-28 23:59:59','ENGETH','4h','0.003245100000000','0.003179000000000','0.072399144566926','0.070924433939866','22.31029692980987','22.310296929809869','test'),('2018-07-01 15:59:59','2018-07-04 23:59:59','ENGETH','4h','0.003290600000000','0.003356700000000','0.072399144566926','0.073853463978545','22.001806529789707','22.001806529789707','test'),('2018-07-05 03:59:59','2018-07-05 15:59:59','ENGETH','4h','0.003400000000000','0.003290000000000','0.072399144566926','0.070056819301525','21.293866049095886','21.293866049095886','test'),('2018-07-18 03:59:59','2018-07-20 07:59:59','ENGETH','4h','0.003095800000000','0.002977500000000','0.072399144566926','0.069632551504626','23.38624735671749','23.386247356717490','test'),('2018-08-17 15:59:59','2018-08-18 15:59:59','ENGETH','4h','0.002472300000000','0.002253500000000','0.072399144566926','0.065991777810770','29.28412594221009','29.284125942210089','test'),('2018-08-20 11:59:59','2018-08-22 23:59:59','ENGETH','4h','0.002327200000000','0.002301400000000','0.072399144566926','0.071596507092783','31.109979617964076','31.109979617964076','test'),('2018-08-24 11:59:59','2018-08-29 15:59:59','ENGETH','4h','0.002391700000000','0.002673300000000','0.072399144566926','0.080923457444815','30.270997435684244','30.270997435684244','test'),('2018-08-29 23:59:59','2018-08-31 19:59:59','ENGETH','4h','0.002863200000000','0.003014300000000','0.072399144566926','0.076219873382259','25.28609407897667','25.286094078976671','test'),('2018-08-31 23:59:59','2018-09-03 03:59:59','ENGETH','4h','0.003038600000000','0.002908100000000','0.072399144566926','0.069289788822180','23.826480802647932','23.826480802647932','test'),('2018-09-04 07:59:59','2018-09-05 11:59:59','ENGETH','4h','0.003059400000000','0.002922300000000','0.072399144566926','0.069154742814907','23.664491261987973','23.664491261987973','test'),('2018-09-05 15:59:59','2018-09-05 19:59:59','ENGETH','4h','0.003001200000000','0.002972800000000','0.072399144566926','0.071714040040170','24.12339882944356','24.123398829443559','test'),('2018-09-08 07:59:59','2018-09-10 03:59:59','ENGETH','4h','0.002973000000000','0.002973400000000','0.072399144566926','0.072408885454187','24.352218152346452','24.352218152346452','test'),('2018-09-10 07:59:59','2018-09-10 11:59:59','ENGETH','4h','0.003000000000000','0.003014500000000','0.072399144566926','0.072749073765666','24.133048188975334','24.133048188975334','test'),('2018-09-10 15:59:59','2018-09-10 19:59:59','ENGETH','4h','0.003052700000000','0.002975500000000','0.072399144566926','0.070568236203652','23.716429576088707','23.716429576088707','test'),('2018-09-12 19:59:59','2018-09-12 23:59:59','ENGETH','4h','0.003059000000000','0.003021200000000','0.072399144566926','0.071504509828570','23.667585670783264','23.667585670783264','test'),('2018-09-27 03:59:59','2018-09-28 15:59:59','ENGETH','4h','0.002726700000000','0.002704100000000','0.072399144566926','0.071799070973493','26.55192891294459','26.551928912944589','test'),('2018-09-28 19:59:59','2018-09-29 11:59:59','ENGETH','4h','0.002743200000000','0.002616500000000','0.072399144566926','0.069055249985186','26.39222242888816','26.392222428888161','test'),('2018-09-30 23:59:59','2018-10-01 11:59:59','ENGETH','4h','0.002770700000000','0.002716600000000','0.072399144566926','0.070985496852965','26.130271977090988','26.130271977090988','test'),('2018-10-02 03:59:59','2018-10-03 23:59:59','ENGETH','4h','0.002711200000000','0.002710500000000','0.072399144566926','0.072380451958045','26.703726972162144','26.703726972162144','test'),('2018-10-07 15:59:59','2018-10-12 19:59:59','ENGETH','4h','0.002766800000000','0.002800000000000','0.072399144566926','0.073267892434362','26.167104440843577','26.167104440843577','test'),('2018-10-14 11:59:59','2018-10-15 07:59:59','ENGETH','4h','0.002954200000000','0.002765000000000','0.072399144566926','0.067762383971143','24.507191309635772','24.507191309635772','test'),('2018-10-16 07:59:59','2018-10-17 11:59:59','ENGETH','4h','0.002919100000000','0.002897000000000','0.072399144566926','0.071851023195637','24.801872004016992','24.801872004016992','test'),('2018-10-17 15:59:59','2018-10-18 23:59:59','ENGETH','4h','0.002911600000000','0.002890100000000','0.072399144566926','0.071864530743534','24.865759227547056','24.865759227547056','test'),('2018-10-20 11:59:59','2018-10-29 11:59:59','ENGETH','4h','0.002980000000000','0.003175100000000','0.072399144566926','0.077139101984714','24.295014955344296','24.295014955344296','test'),('2018-11-01 15:59:59','2018-11-02 23:59:59','ENGETH','4h','0.003241200000000','0.003191000000000','0.072399144566926','0.071277820039819','22.33714197424596','22.337141974245959','test'),('2018-11-05 15:59:59','2018-11-05 23:59:59','ENGETH','4h','0.003262900000000','0.003220700000000','0.072399144566926','0.071462786143216','22.18858823958013','22.188588239580131','test'),('2018-11-22 15:59:59','2018-11-23 03:59:59','ENGETH','4h','0.002988000000000','0.002697500000000','0.072399144566926','0.065360338845142','24.229968061220212','24.229968061220212','test'),('2018-11-23 07:59:59','2018-11-23 11:59:59','ENGETH','4h','0.002720800000000','0.002754100000000','0.072399144566926','0.073285241124585','26.60950623600632','26.609506236006322','test'),('2018-11-23 15:59:59','2018-11-23 19:59:59','ENGETH','4h','0.002756000000000','0.002744200000000','0.072399144566926','0.072089162743309','26.269646069276487','26.269646069276487','test'),('2018-11-23 23:59:59','2018-11-24 15:59:59','ENGETH','4h','0.002763600000000','0.002708200000000','0.072399144566926','0.070947808407928','26.197403592027065','26.197403592027065','test'),('2018-11-29 07:59:59','2018-11-30 11:59:59','ENGETH','4h','0.002785900000000','0.002755400000000','0.072399144566926','0.071606519594999','25.987703997604367','25.987703997604367','test'),('2018-11-30 15:59:59','2018-11-30 23:59:59','ENGETH','4h','0.002779200000000','0.002749500000000','0.072399144566926','0.071625449045324','26.050354262710854','26.050354262710854','test'),('2018-12-01 03:59:59','2018-12-02 11:59:59','ENGETH','4h','0.002779800000000','0.002794200000000','0.072399144566926','0.072774188700232','26.04473147957623','26.044731479576232','test'),('2018-12-02 15:59:59','2018-12-03 03:59:59','ENGETH','4h','0.002802300000000','0.002751100000000','0.072399144566926','0.071076361067006','25.835615232818043','25.835615232818043','test'),('2018-12-07 03:59:59','2018-12-07 19:59:59','ENGETH','4h','0.002879100000000','0.002755100000000','0.072399144566926','0.069280984750908','25.146450129181343','25.146450129181343','test'),('2018-12-07 23:59:59','2018-12-08 03:59:59','ENGETH','4h','0.002790200000000','0.002754300000000','0.072399144566926','0.071467623783487','25.947654134802523','25.947654134802523','test'),('2018-12-08 07:59:59','2018-12-08 23:59:59','ENGETH','4h','0.002797400000000','0.002803800000000','0.072399144566926','0.072564782132247','25.88086958137056','25.880869581370561','test'),('2018-12-10 07:59:59','2018-12-10 11:59:59','ENGETH','4h','0.002824000000000','0.002782200000000','0.072399144566926','0.071327514169299','25.63709085231091','25.637090852310909','test'),('2018-12-10 15:59:59','2018-12-10 19:59:59','ENGETH','4h','0.002809800000000','0.002784400000000','0.072399144566926','0.071744671553900','25.766654056134247','25.766654056134247','test'),('2018-12-11 03:59:59','2018-12-11 23:59:59','ENGETH','4h','0.002895000000000','0.002789000000000','0.072399144566926','0.069748260517153','25.00834009220242','25.008340092202420','test'),('2018-12-28 11:59:59','2018-12-28 23:59:59','ENGETH','4h','0.003364900000000','0.002610000000000','0.072399144566926','0.056156726000677','21.51598697343933','21.515986973439329','test'),('2019-01-08 11:59:59','2019-01-11 23:59:59','ENGETH','4h','0.002296600000000','0.002308000000000','0.048266096377951','0.048505682504707','21.016326908451916','21.016326908451916','test'),('2019-01-12 15:59:59','2019-01-13 11:59:59','ENGETH','4h','0.002357100000000','0.002319900000000','0.053550101712363','0.052704968377460','22.718638035027233','22.718638035027233','test'),('2019-01-14 03:59:59','2019-01-14 15:59:59','ENGETH','4h','0.002341700000000','0.002293600000000','0.053550101712363','0.052450148732748','22.86804531424307','22.868045314243069','test'),('2019-01-16 07:59:59','2019-01-18 15:59:59','ENGETH','4h','0.002359300000000','0.002322100000000','0.053550101712363','0.052705756447369','22.697453360048744','22.697453360048744','test'),('2019-01-22 19:59:59','2019-01-27 11:59:59','ENGETH','4h','0.002443900000000','0.002499100000000','0.053550101712363','0.054759629767735','21.911740133541876','21.911740133541876','test'),('2019-02-02 03:59:59','2019-02-03 07:59:59','ENGETH','4h','0.002528600000000','0.002482200000000','0.053550101712363','0.052567453322165','21.177767030120616','21.177767030120616','test'),('2019-02-10 15:59:59','2019-02-11 19:59:59','ENGETH','4h','0.002662100000000','0.002498000000000','0.053550101712363','0.050249109378867','20.115736340619435','20.115736340619435','test'),('2019-02-12 03:59:59','2019-02-12 07:59:59','ENGETH','4h','0.002451800000000','0.002427200000000','0.053550101712363','0.053012809721938','21.841137822156373','21.841137822156373','test'),('2019-02-13 19:59:59','2019-02-14 07:59:59','ENGETH','4h','0.002532100000000','0.002501200000000','0.053550101712363','0.052896613247092','21.14849402170649','21.148494021706490','test'),('2019-02-14 11:59:59','2019-02-14 15:59:59','ENGETH','4h','0.002517400000000','0.002600000000000','0.053550101712363','0.055307167892327','21.27198765089497','21.271987650894971','test'),('2019-02-14 23:59:59','2019-02-15 15:59:59','ENGETH','4h','0.002602200000000','0.002469100000000','0.053550101712363','0.050811066074089','20.578780152318423','20.578780152318423','test'),('2019-02-23 11:59:59','2019-02-23 19:59:59','ENGETH','4h','0.002499500000000','0.002300500000000','0.053550101712363','0.049286660927902','21.42432555005521','21.424325550055212','test'),('2019-02-28 07:59:59','2019-03-04 15:59:59','ENGETH','4h','0.002441400000000','0.002504400000000','0.053550101712363','0.054931954914574','21.934177812879085','21.934177812879085','test'),('2019-03-07 15:59:59','2019-03-16 03:59:59','ENGETH','4h','0.002520400000000','0.003100600000000','0.053550101712363','0.065877418413487','21.246667875084512','21.246667875084512','test'),('2019-03-20 23:59:59','2019-03-21 15:59:59','ENGETH','4h','0.003192600000000','0.003085600000000','0.053902460451621','0.052095919303866','16.88356212855391','16.883562128553908','test'),('2019-03-21 19:59:59','2019-03-22 07:59:59','ENGETH','4h','0.003137100000000','0.003086900000000','0.053902460451621','0.053039911117946','17.18225764292531','17.182257642925311','test'),('2019-03-22 11:59:59','2019-03-22 19:59:59','ENGETH','4h','0.003096100000000','0.003124200000000','0.053902460451621','0.054391675638046','17.4097931112112','17.409793111211201','test'),('2019-03-23 03:59:59','2019-03-24 11:59:59','ENGETH','4h','0.003161000000000','0.003134000000000','0.053902460451621','0.053442047154502','17.05234433774786','17.052344337747861','test'),('2019-03-26 03:59:59','2019-03-30 15:59:59','ENGETH','4h','0.003176900000000','0.004087400000000','0.053902460451621','0.069350913421875','16.96699941818156','16.966999418181562','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  0:04:28
