-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-28 15:59:59','2018-05-05 11:59:59','AMBBNB','4h','0.045860000000000','0.053390000000000','0.711908500000000','0.828800584714348','15.52351722634104','15.523517226341040','test'),('2018-05-06 15:59:59','2018-05-07 11:59:59','AMBBNB','4h','0.059230000000000','0.054170000000000','0.741131521178587','0.677816891815703','12.51277260136058','12.512772601360579','test'),('2018-05-08 07:59:59','2018-05-08 11:59:59','AMBBNB','4h','0.057100000000000','0.055500000000000','0.741131521178587','0.720364263142059','12.979536272829897','12.979536272829897','test'),('2018-06-29 23:59:59','2018-07-07 19:59:59','AMBBNB','4h','0.021880000000000','0.022970000000000','0.741131521178587','0.778052607014266','33.872555812549685','33.872555812549685','test'),('2018-07-07 23:59:59','2018-07-09 07:59:59','AMBBNB','4h','0.024490000000000','0.022930000000000','0.741131521178587','0.693921836693548','30.26261825964014','30.262618259640139','test'),('2018-07-09 15:59:59','2018-07-10 11:59:59','AMBBNB','4h','0.024100000000000','0.023110000000000','0.741131521178587','0.710686699354238','30.752345277119794','30.752345277119794','test'),('2018-07-17 19:59:59','2018-07-19 11:59:59','AMBBNB','4h','0.023860000000000','0.023750000000000','0.741131521178587','0.737714737132919','31.061673142438686','31.061673142438686','test'),('2018-07-23 07:59:59','2018-07-23 23:59:59','AMBBNB','4h','0.023950000000000','0.023100000000000','0.741131521178587','0.714828314790203','30.94494869221658','30.944948692216581','test'),('2018-08-18 11:59:59','2018-08-18 15:59:59','AMBBNB','4h','0.013310000000000','0.012950000000000','0.741131521178587','0.721085890252645','55.682308127617354','55.682308127617354','test'),('2018-08-18 19:59:59','2018-08-19 03:59:59','AMBBNB','4h','0.013300000000000','0.012890000000000','0.741131521178587','0.718284609623458','55.724174524705795','55.724174524705795','test'),('2018-08-19 11:59:59','2018-08-20 23:59:59','AMBBNB','4h','0.012730000000000','0.012470000000000','0.741131521178587','0.725994506606204','58.2192868168568','58.219286816856801','test'),('2018-08-21 03:59:59','2018-08-21 07:59:59','AMBBNB','4h','0.012560000000000','0.012620000000000','0.741131521178587','0.744671958381669','59.00728671804037','59.007286718040369','test'),('2018-08-23 23:59:59','2018-08-24 15:59:59','AMBBNB','4h','0.013210000000000','0.013030000000000','0.741131521178587','0.731032832774942','56.10382446469244','56.103824464692437','test'),('2018-08-25 03:59:59','2018-08-26 07:59:59','AMBBNB','4h','0.013380000000000','0.013060000000000','0.741131521178587','0.723406402585377','55.390995603780794','55.390995603780794','test'),('2018-08-26 19:59:59','2018-08-27 19:59:59','AMBBNB','4h','0.013300000000000','0.013080000000000','0.741131521178587','0.728872202783152','55.724174524705795','55.724174524705795','test'),('2018-08-28 03:59:59','2018-09-02 15:59:59','AMBBNB','4h','0.013880000000000','0.015010000000000','0.741131521178587','0.801468597470504','53.39564273620944','53.395642736209439','test'),('2018-09-03 15:59:59','2018-09-04 03:59:59','AMBBNB','4h','0.016010000000000','0.015290000000000','0.741131521178587','0.707801434030018','46.291787706345225','46.291787706345225','test'),('2018-09-04 11:59:59','2018-09-05 11:59:59','AMBBNB','4h','0.015620000000000','0.014480000000000','0.741131521178587','0.687041256508703','47.44760058761761','47.447600587617607','test'),('2018-09-19 23:59:59','2018-09-21 23:59:59','AMBBNB','4h','0.013350000000000','0.013430000000000','0.741131521178587','0.745572758758683','55.51546975120502','55.515469751205018','test'),('2018-09-22 03:59:59','2018-09-25 03:59:59','AMBBNB','4h','0.013600000000000','0.013850000000000','0.741131521178587','0.754755262376723','54.49496479254317','54.494964792543172','test'),('2018-09-26 15:59:59','2018-09-27 07:59:59','AMBBNB','4h','0.014840000000000','0.014320000000000','0.741131521178587','0.715161953051035','49.941477168368394','49.941477168368394','test'),('2018-09-28 03:59:59','2018-09-28 07:59:59','AMBBNB','4h','0.014860000000000','0.014210000000000','0.741131521178587','0.708713251409672','49.87426118294664','49.874261182946640','test'),('2018-09-28 11:59:59','2018-09-28 15:59:59','AMBBNB','4h','0.014420000000000','0.014600000000000','0.741131521178587','0.750382816172494','51.39608329948592','51.396083299485923','test'),('2018-09-28 19:59:59','2018-10-01 11:59:59','AMBBNB','4h','0.014680000000000','0.014760000000000','0.741131521178587','0.745170385054220','50.48579844540784','50.485798445407838','test'),('2018-10-08 11:59:59','2018-10-09 11:59:59','AMBBNB','4h','0.014550000000000','0.014430000000000','0.741131521178587','0.735019096261650','50.93687430780667','50.936874307806669','test'),('2018-10-09 15:59:59','2018-10-12 23:59:59','AMBBNB','4h','0.015280000000000','0.016210000000000','0.741131521178587','0.786239656957127','48.503371804881354','48.503371804881354','test'),('2018-10-14 07:59:59','2018-10-15 07:59:59','AMBBNB','4h','0.018120000000000','0.016610000000000','0.741131521178587','0.679370561080371','40.90129807828847','40.901298078288470','test'),('2018-10-15 15:59:59','2018-10-15 19:59:59','AMBBNB','4h','0.016920000000000','0.015920000000000','0.741131521178587','0.697329421818150','43.802099360436586','43.802099360436586','test'),('2018-10-16 19:59:59','2018-10-24 07:59:59','AMBBNB','4h','0.016850000000000','0.020360000000000','0.741131521178587','0.895515594729735','43.98406653878855','43.984066538788547','test'),('2018-10-31 11:59:59','2018-10-31 15:59:59','AMBBNB','4h','0.021170000000000','0.020840000000000','0.741131521178587','0.729578691608963','35.008574453405146','35.008574453405146','test'),('2018-10-31 23:59:59','2018-11-01 15:59:59','AMBBNB','4h','0.020460000000000','0.019840000000000','0.741131521178587','0.718672990233781','36.22343700775108','36.223437007751080','test'),('2018-11-07 07:59:59','2018-11-07 11:59:59','AMBBNB','4h','0.020030000000000','0.019620000000000','0.741131521178587','0.725961080655211','37.00107444725847','37.001074447258468','test'),('2018-11-07 15:59:59','2018-11-07 19:59:59','AMBBNB','4h','0.019640000000000','0.019440000000000','0.741131521178587','0.733584357011799','37.735820833940274','37.735820833940274','test'),('2018-11-10 07:59:59','2018-11-14 11:59:59','AMBBNB','4h','0.019830000000000','0.019200000000000','0.741131521178587','0.717585739113912','37.37425724551624','37.374257245516240','test'),('2018-11-30 11:59:59','2018-11-30 19:59:59','AMBBNB','4h','0.016060000000000','0.015600000000000','0.741131521178587','0.719903594669113','46.14766632494315','46.147666324943152','test'),('2018-12-01 07:59:59','2018-12-02 07:59:59','AMBBNB','4h','0.016200000000000','0.015780000000000','0.741131521178587','0.721917000259142','45.74885933201155','45.748859332011548','test'),('2018-12-21 23:59:59','2018-12-22 15:59:59','AMBBNB','4h','0.012490000000000','0.012160000000000','0.741131521178587','0.721549983789561','59.33799208795733','59.337992087957332','test'),('2018-12-25 07:59:59','2018-12-25 11:59:59','AMBBNB','4h','0.012330000000000','0.011870000000000','0.741131521178587','0.713481845611503','60.10799036322685','60.107990363226847','test'),('2018-12-25 23:59:59','2018-12-26 03:59:59','AMBBNB','4h','0.012820000000000','0.011970000000000','0.741131521178587','0.691992535765030','57.81057107477278','57.810571074772781','test'),('2019-01-02 23:59:59','2019-01-04 15:59:59','AMBBNB','4h','0.012130000000000','0.011790000000000','0.741131521178587','0.720357842926261','61.09905368331303','61.099053683313031','test'),('2019-01-05 15:59:59','2019-01-06 07:59:59','AMBBNB','4h','0.012080000000000','0.012090000000000','0.741131521178587','0.741745040649761','61.3519471174327','61.351947117432701','test'),('2019-01-07 19:59:59','2019-01-08 03:59:59','AMBBNB','4h','0.012160000000000','0.011920000000000','0.741131521178587','0.726503925365852','60.948315886396955','60.948315886396955','test'),('2019-01-16 15:59:59','2019-01-16 23:59:59','AMBBNB','4h','0.012200000000000','0.011160000000000','0.741131521178587','0.677953096422380','60.74848534250713','60.748485342507131','test'),('2019-03-28 23:59:59','2019-03-31 03:59:59','AMBBNB','4h','0.003880000000000','0.003800000000000','0.741131521178587','0.725850458886245','191.013278654275','191.013278654275013','test'),('2019-04-08 07:59:59','2019-04-08 15:59:59','AMBBNB','4h','0.003880000000000','0.003830000000000','0.741131521178587','0.731580857245873','191.013278654275','191.013278654275013','test'),('2019-04-09 07:59:59','2019-04-09 11:59:59','AMBBNB','4h','0.003780000000000','0.003690000000000','0.741131521178587','0.723485532579097','196.0665399943352','196.066539994335187','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 13:17:21
