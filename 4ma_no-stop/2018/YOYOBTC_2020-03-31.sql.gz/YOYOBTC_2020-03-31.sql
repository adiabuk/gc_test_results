-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-15 15:59:59','2018-04-15 19:59:59','YOYOBTC','4h','0.000012410000000','0.000012260000000','0.001467500000000','0.001449762288477','118.25141015310234','118.251410153102341','test'),('2018-04-17 11:59:59','2018-04-21 11:59:59','YOYOBTC','4h','0.000012640000000','0.000013000000000','0.001467500000000','0.001509295886076','116.09968354430382','116.099683544303815','test'),('2018-04-22 15:59:59','2018-04-25 03:59:59','YOYOBTC','4h','0.000014920000000','0.000013480000000','0.001473514543638','0.001331298662751','98.76102839398459','98.761028393984589','test'),('2018-04-28 19:59:59','2018-04-29 11:59:59','YOYOBTC','4h','0.000014220000000','0.000013780000000','0.001473514543638','0.001427920563385','103.6226823936709','103.622682393670900','test'),('2018-04-29 15:59:59','2018-05-05 07:59:59','YOYOBTC','4h','0.000014160000000','0.000020230000000','0.001473514543638','0.002105169436285','104.06176155635593','104.061761556355933','test'),('2018-06-03 03:59:59','2018-06-04 11:59:59','YOYOBTC','4h','0.000013570000000','0.000013160000000','0.001584475801515','0.001536602914365','116.76313938946204','116.763139389462040','test'),('2018-07-04 19:59:59','2018-07-05 15:59:59','YOYOBTC','4h','0.000011100000000','0.000009760000000','0.001584475801515','0.001393196740792','142.74556770405405','142.745567704054054','test'),('2018-08-21 07:59:59','2018-08-23 23:59:59','YOYOBTC','4h','0.000004400000000','0.000004540000000','0.001584475801515','0.001634890940654','360.10813670795454','360.108136707954543','test'),('2018-09-16 23:59:59','2018-09-18 03:59:59','YOYOBTC','4h','0.000003720000000','0.000003400000000','0.001584475801515','0.001448176807836','425.93435524596777','425.934355245967765','test'),('2018-09-18 07:59:59','2018-09-25 03:59:59','YOYOBTC','4h','0.000003600000000','0.000003900000000','0.001584475801515','0.001716515451641','440.1321670875','440.132167087500022','test'),('2018-09-26 23:59:59','2018-09-29 03:59:59','YOYOBTC','4h','0.000003960000000','0.000004000000000','0.001584475801515','0.001600480607591','400.1201518977273','400.120151897727283','test'),('2018-09-30 03:59:59','2018-09-30 23:59:59','YOYOBTC','4h','0.000004100000000','0.000004000000000','0.001584475801515','0.001545830050259','386.4575125646342','386.457512564634214','test'),('2018-10-01 23:59:59','2018-10-10 03:59:59','YOYOBTC','4h','0.000004100000000','0.000004980000000','0.001584475801515','0.001924558412572','386.4575125646342','386.457512564634214','test'),('2018-10-14 15:59:59','2018-10-14 23:59:59','YOYOBTC','4h','0.000004860000000','0.000004490000000','0.001615587179912','0.001492589802017','332.4253456610082','332.425345661008180','test'),('2018-10-18 11:59:59','2018-10-18 15:59:59','YOYOBTC','4h','0.000004840000000','0.000004720000000','0.001615587179912','0.001575531299418','333.7990041140496','333.799004114049580','test'),('2018-10-20 15:59:59','2018-10-21 19:59:59','YOYOBTC','4h','0.000004850000000','0.000004780000000','0.001615587179912','0.001592269426800','333.11075874474227','333.110758744742270','test'),('2018-10-22 07:59:59','2018-10-22 11:59:59','YOYOBTC','4h','0.000004770000000','0.000004770000000','0.001615587179912','0.001615587179912','338.69752199412994','338.697521994129943','test'),('2018-10-22 15:59:59','2018-10-27 23:59:59','YOYOBTC','4h','0.000004920000000','0.000005010000000','0.001615587179912','0.001645140603935','328.3713780308943','328.371378030894277','test'),('2018-10-28 23:59:59','2018-10-29 15:59:59','YOYOBTC','4h','0.000005360000000','0.000005210000000','0.001615587179912','0.001570374852116','301.4155186402985','301.415518640298501','test'),('2018-10-29 19:59:59','2018-10-29 23:59:59','YOYOBTC','4h','0.000005240000000','0.000005170000000','0.001615587179912','0.001594004908425','308.3181641053435','308.318164105343499','test'),('2018-10-30 19:59:59','2018-11-01 23:59:59','YOYOBTC','4h','0.000005530000000','0.000007020000000','0.001615587179912','0.002050890054789','292.14958045424953','292.149580454249531','test'),('2018-11-02 07:59:59','2018-11-03 23:59:59','YOYOBTC','4h','0.000007150000000','0.000006110000000','0.001668509851941','0.001425817509840','233.35802125055937','233.358021250559375','test'),('2018-12-02 23:59:59','2018-12-03 03:59:59','YOYOBTC','4h','0.000004420000000','0.000004380000000','0.001668509851941','0.001653410215272','377.49091672873305','377.490916728733055','test'),('2018-12-03 11:59:59','2018-12-04 07:59:59','YOYOBTC','4h','0.000004410000000','0.000004330000000','0.001668509851941','0.001638242099525','378.34690520204083','378.346905202040830','test'),('2018-12-23 15:59:59','2018-12-24 19:59:59','YOYOBTC','4h','0.000003880000000','0.000003900000000','0.001668509851941','0.001677110418188','430.0283123559278','430.028312355927824','test'),('2018-12-24 23:59:59','2018-12-25 03:59:59','YOYOBTC','4h','0.000003970000000','0.000003730000000','0.001668509851941','0.001567642757617','420.27955968287154','420.279559682871536','test'),('2019-01-05 19:59:59','2019-01-06 03:59:59','YOYOBTC','4h','0.000003780000000','0.000003710000000','0.001668509851941','0.001637611521350','441.4047227357143','441.404722735714302','test'),('2019-01-06 11:59:59','2019-01-06 15:59:59','YOYOBTC','4h','0.000003710000000','0.000003690000000','0.001668509851941','0.001659515189666','449.7331137307278','449.733113730727780','test'),('2019-01-06 19:59:59','2019-01-07 23:59:59','YOYOBTC','4h','0.000003880000000','0.000003690000000','0.001668509851941','0.001586804472593','430.0283123559278','430.028312355927824','test'),('2019-01-09 11:59:59','2019-01-10 07:59:59','YOYOBTC','4h','0.000003790000000','0.000003680000000','0.001668509851941','0.001620083444629','440.24006647519786','440.240066475197864','test'),('2019-01-15 15:59:59','2019-01-20 15:59:59','YOYOBTC','4h','0.000004010000000','0.000004050000000','0.001668509851941','0.001685153341736','416.0872448730674','416.087244873067391','test'),('2019-01-20 23:59:59','2019-01-24 23:59:59','YOYOBTC','4h','0.000004250000000','0.000004550000000','0.001668509851941','0.001786287017960','392.5905533978824','392.590553397882388','test'),('2019-02-12 11:59:59','2019-02-14 11:59:59','YOYOBTC','4h','0.000003930000000','0.000003960000000','0.001668509851941','0.001681246568368','424.5572142343512','424.557214234351193','test'),('2019-02-14 15:59:59','2019-02-14 19:59:59','YOYOBTC','4h','0.000003980000000','0.000003960000000','0.001668509851941','0.001660125380323','419.2235808896985','419.223580889698496','test'),('2019-02-14 23:59:59','2019-02-15 19:59:59','YOYOBTC','4h','0.000003990000000','0.000003990000000','0.001668509851941','0.001668509851941','418.1728952233083','418.172895223308274','test'),('2019-02-16 03:59:59','2019-02-18 19:59:59','YOYOBTC','4h','0.000004000000000','0.000003940000000','0.001668509851941','0.001643482204162','417.12746298525','417.127462985250020','test'),('2019-02-19 19:59:59','2019-02-22 07:59:59','YOYOBTC','4h','0.000004650000000','0.000004430000000','0.001668509851941','0.001589569600881','358.8193229980645','358.819322998064479','test'),('2019-03-02 03:59:59','2019-03-02 07:59:59','YOYOBTC','4h','0.000004450000000','0.000004250000000','0.001668509851941','0.001593520645112','374.946034144045','374.946034144044972','test'),('2019-03-02 11:59:59','2019-03-07 11:59:59','YOYOBTC','4h','0.000004280000000','0.000004540000000','0.001668509851941','0.001769867927059','389.8387504535047','389.838750453504701','test'),('2019-03-07 15:59:59','2019-03-08 07:59:59','YOYOBTC','4h','0.000004600000000','0.000004510000000','0.001668509851941','0.001635865093968','362.7195330306522','362.719533030652201','test'),('2019-03-10 11:59:59','2019-03-11 07:59:59','YOYOBTC','4h','0.000004670000000','0.000004530000000','0.001668509851941','0.001618490284645','357.28262354197','357.282623541969997','test'),('2019-03-11 15:59:59','2019-03-14 23:59:59','YOYOBTC','4h','0.000004610000000','0.000004900000000','0.001668509851941','0.001773470341542','361.9327227637744','361.932722763774393','test'),('2019-03-15 03:59:59','2019-03-18 11:59:59','YOYOBTC','4h','0.000004930000000','0.000005070000000','0.001668509851941','0.001715891470455','338.44013223955375','338.440132239553748','test'),('2019-03-26 23:59:59','2019-03-29 19:59:59','YOYOBTC','4h','0.000005360000000','0.000005260000000','0.001668509851941','0.001637380936793','311.2891514815298','311.289151481529814','test'),('2019-03-31 11:59:59','2019-04-02 07:59:59','YOYOBTC','4h','0.000005420000000','0.000005300000000','0.001668509851941','0.001631568674407','307.8431461145757','307.843146114575688','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31 10:20:13
