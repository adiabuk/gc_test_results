-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-29 19:59:59','2018-12-03 23:59:59','ENJBNB','4h','0.005146000000000','0.005250000000000','0.711908500000000','0.726296079479207','138.34211037699183','138.342110376991826','test'),('2018-12-07 19:59:59','2018-12-12 15:59:59','ENJBNB','4h','0.005827000000000','0.005801000000000','0.715505394869802','0.712312818884455','122.79138405179368','122.791384051793685','test'),('2018-12-13 23:59:59','2018-12-14 15:59:59','ENJBNB','4h','0.006058000000000','0.005853000000000','0.715505394869802','0.691293013564370','118.10917709967019','118.109177099670191','test'),('2018-12-14 23:59:59','2018-12-18 07:59:59','ENJBNB','4h','0.006244000000000','0.006383000000000','0.715505394869802','0.731433525857454','114.5908704147665','114.590870414766499','test'),('2018-12-20 11:59:59','2018-12-23 23:59:59','ENJBNB','4h','0.006660000000000','0.007103000000000','0.715505394869802','0.763098321285316','107.43324247294325','107.433242472943249','test'),('2018-12-26 23:59:59','2018-12-28 11:59:59','ENJBNB','4h','0.007327000000000','0.007245000000000','0.724534419897898','0.716425804853319','98.88554932412971','98.885549324129713','test'),('2019-02-18 15:59:59','2019-02-19 15:59:59','ENJBNB','4h','0.003735000000000','0.003462000000000','0.724534419897898','0.671576482379256','193.98511911590307','193.985119115903075','test'),('2019-02-21 15:59:59','2019-02-24 23:59:59','ENJBNB','4h','0.003593000000000','0.003604000000000','0.724534419897898','0.726752588174791','201.6516615357356','201.651661535735599','test'),('2019-02-25 03:59:59','2019-03-01 07:59:59','ENJBNB','4h','0.004221000000000','0.007505000000000','0.724534419897898','1.288232840875083','171.6499454863535','171.649945486353488','test'),('2019-03-06 03:59:59','2019-03-06 23:59:59','ENJBNB','4h','0.007681000000000','0.006811000000000','0.850746929070613','0.754385800533777','110.75991785843155','110.759917858431550','test'),('2019-03-08 03:59:59','2019-03-11 19:59:59','ENJBNB','4h','0.008963000000000','0.011843000000000','0.850746929070613','1.124109771391640','94.91765358368994','94.917653583689940','test'),('2019-03-18 11:59:59','2019-03-23 07:59:59','ENJBNB','4h','0.013211000000000','0.012204000000000','0.894997357516661','0.826776758090480','67.74637480256305','67.746374802563054','test'),('2019-04-14 03:59:59','2019-04-14 19:59:59','ENJBNB','4h','0.009268000000000','0.008142000000000','0.894997357516661','0.786261165828728','96.56855389692069','96.568553896920690','test'),('2019-04-14 23:59:59','2019-04-15 03:59:59','ENJBNB','4h','0.008300000000000','0.008066000000000','0.894997357516661','0.869764901895107','107.83100692971819','107.831006929718185','test'),('2019-04-18 11:59:59','2019-04-18 15:59:59','ENJBNB','4h','0.008585000000000','0.008085000000000','0.894997357516661','0.842871710602470','104.25129382838217','104.251293828382174','test'),('2019-04-18 19:59:59','2019-04-18 23:59:59','ENJBNB','4h','0.008280000000000','0.008085000000000','0.894997357516661','0.873919521198334','108.09146829911366','108.091468299113657','test'),('2019-04-19 07:59:59','2019-04-19 15:59:59','ENJBNB','4h','0.008866000000000','0.007818000000000','0.894997357516661','0.789204753109097','100.9471416102708','100.947141610270805','test'),('2019-05-10 23:59:59','2019-05-12 11:59:59','ENJBNB','4h','0.007074000000000','0.006755000000000','0.894997357516661','0.854637708513577','126.51927587173607','126.519275871736070','test'),('2019-07-02 03:59:59','2019-07-02 07:59:59','ENJBNB','4h','0.003864000000000','0.003785000000000','0.894997357516661','0.876699016097454','231.6245749266721','231.624574926672096','test'),('2019-07-02 11:59:59','2019-07-02 19:59:59','ENJBNB','4h','0.003824000000000','0.003846000000000','0.894997357516661','0.900146400891495','234.04742612883393','234.047426128833933','test'),('2019-07-07 07:59:59','2019-07-08 07:59:59','ENJBNB','4h','0.003871000000000','0.003638000000000','0.894997357516661','0.841126423829918','231.20572397743763','231.205723977437628','test'),('2019-07-29 11:59:59','2019-07-29 15:59:59','ENJBNB','4h','0.003134000000000','0.003079000000000','0.894997357516661','0.879290639372623','285.576693527971','285.576693527970974','test'),('2019-07-29 23:59:59','2019-07-31 15:59:59','ENJBNB','4h','0.003069000000000','0.003118000000000','0.894997357516661','0.909286986229048','291.62507576300453','291.625075763004531','test'),('2019-07-31 19:59:59','2019-07-31 23:59:59','ENJBNB','4h','0.003125000000000','0.003136000000000','0.894997357516661','0.898147748215120','286.3991544053315','286.399154405331501','test'),('2019-08-22 03:59:59','2019-08-25 23:59:59','ENJBNB','4h','0.002372000000000','0.002591000000000','0.894997357516661','0.977629912869169','377.3176043493512','377.317604349351200','test'),('2019-08-27 11:59:59','2019-09-03 23:59:59','ENJBNB','4h','0.002731000000000','0.003369000000000','0.894997357516661','1.104081324596716','327.71781673989784','327.717816739897842','test'),('2019-09-04 03:59:59','2019-09-06 11:59:59','ENJBNB','4h','0.003620000000000','0.003590000000000','0.894997357516661','0.887580252343871','247.23683909300027','247.236839093000270','test'),('2019-09-08 19:59:59','2019-09-09 11:59:59','ENJBNB','4h','0.003678000000000','0.003552000000000','0.894997357516661','0.864336762887216','243.3380526146441','243.338052614644113','test'),('2019-09-24 11:59:59','2019-09-24 19:59:59','ENJBNB','4h','0.003433000000000','0.003444000000000','0.894997357516661','0.897865103200519','260.7041530779671','260.704153077967078','test'),('2019-09-24 23:59:59','2019-09-25 15:59:59','ENJBNB','4h','0.003467000000000','0.003465000000000','0.894997357516661','0.894481062531073','258.14749279396045','258.147492793960453','test'),('2019-09-25 23:59:59','2019-09-26 15:59:59','ENJBNB','4h','0.003502000000000','0.003426000000000','0.894997357516661','0.875574228113101','255.56749215210195','255.567492152101948','test'),('2019-09-26 19:59:59','2019-09-26 23:59:59','ENJBNB','4h','0.003440000000000','0.003426000000000','0.894997357516661','0.891354926410489','260.17365044088984','260.173650440889844','test'),('2019-09-27 15:59:59','2019-10-07 03:59:59','ENJBNB','4h','0.003503000000000','0.003952000000000','0.894997357516661','1.009714403912602','255.4945354029863','255.494535402986287','test'),('2019-10-08 23:59:59','2019-10-09 07:59:59','ENJBNB','4h','0.004156000000000','0.003900000000000','0.894997357516661','0.839867587660004','215.3506635025652','215.350663502565197','test'),('2019-10-24 11:59:59','2019-10-25 03:59:59','ENJBNB','4h','0.003535000000000','0.003330000000000','0.894997357516661','0.843095106232102','253.18171358321385','253.181713583213849','test'),('2019-10-25 07:59:59','2019-10-25 11:59:59','ENJBNB','4h','0.003334000000000','0.003277000000000','0.894997357516661','0.879695962982033','268.445518151368','268.445518151367992','test'),('2019-11-01 23:59:59','2019-11-02 15:59:59','ENJBNB','4h','0.003324000000000','0.003242000000000','0.894997357516661','0.872918602006322','269.25311597974155','269.253115979741551','test'),('2019-11-02 19:59:59','2019-11-03 07:59:59','ENJBNB','4h','0.003271000000000','0.003213000000000','0.894997357516661','0.879127639774085','273.61582314786335','273.615823147863352','test'),('2019-11-03 23:59:59','2019-11-04 03:59:59','ENJBNB','4h','0.003284000000000','0.003217000000000','0.894997357516661','0.876737667214098','272.5326910830271','272.532691083027089','test'),('2019-11-04 19:59:59','2019-11-04 23:59:59','ENJBNB','4h','0.003313000000000','0.003224000000000','0.894997357516661','0.870954265207883','270.1471045930157','270.147104593015683','test'),('2019-11-06 19:59:59','2019-11-06 23:59:59','ENJBNB','4h','0.003280000000000','0.003253000000000','0.894997357516661','0.887630001220030','272.86504802337225','272.865048023372253','test'),('2019-11-07 07:59:59','2019-11-07 11:59:59','ENJBNB','4h','0.003265000000000','0.003212000000000','0.894997357516661','0.880469069630479','274.1186393619176','274.118639361917587','test'),('2019-11-16 11:59:59','2019-11-22 03:59:59','ENJBNB','4h','0.003228000000000','0.003646000000000','0.894997357516661','1.010892306538335','277.260643592522','277.260643592522001','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:39:08
