-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-12-18 23:59:59','2018-12-22 15:59:59','ETCUSDT','4h','4.164200000000000','4.416600000000000','15.000000000000000','15.909178233514240','3.6021324624177513','3.602132462417751','test'),('2018-12-22 19:59:59','2018-12-25 03:59:59','ETCUSDT','4h','4.494200000000000','4.476900000000000','15.227294558378560','15.168678520850200','3.3882102617548306','3.388210261754831','test'),('2018-12-25 07:59:59','2018-12-25 11:59:59','ETCUSDT','4h','4.671800000000000','4.636200000000000','15.227294558378560','15.111259692528506','3.259406344102607','3.259406344102607','test'),('2018-12-26 19:59:59','2018-12-27 23:59:59','ETCUSDT','4h','5.068900000000000','4.704900000000000','15.227294558378560','14.133815653833235','3.0040629245750674','3.004062924575067','test'),('2018-12-28 15:59:59','2018-12-31 19:59:59','ETCUSDT','4h','5.113600000000000','4.941900000000000','15.227294558378560','14.716005745081942','2.977803222461389','2.977803222461389','test'),('2019-01-01 23:59:59','2019-01-03 19:59:59','ETCUSDT','4h','5.252000000000000','4.947900000000000','15.227294558378560','14.345607529588971','2.899332551100259','2.899332551100259','test'),('2019-01-05 15:59:59','2019-01-05 23:59:59','ETCUSDT','4h','5.147200000000000','5.056400000000000','15.227294558378560','14.958675047595849','2.9583646561972645','2.958364656197265','test'),('2019-01-06 11:59:59','2019-01-07 11:59:59','ETCUSDT','4h','5.183600000000000','5.149500000000000','15.227294558378560','15.127122719417082','2.9375905853805384','2.937590585380538','test'),('2019-02-09 07:59:59','2019-02-10 07:59:59','ETCUSDT','4h','4.127000000000000','3.970500000000000','15.227294558378560','14.649860199670965','3.689676413467061','3.689676413467061','test'),('2019-02-10 15:59:59','2019-02-11 19:59:59','ETCUSDT','4h','3.971200000000000','4.049100000000000','15.227294558378560','15.525996775868911','3.834431546731104','3.834431546731104','test'),('2019-02-11 23:59:59','2019-02-15 15:59:59','ETCUSDT','4h','4.069700000000000','4.081800000000000','15.227294558378560','15.272568230677841','3.7416258098578665','3.741625809857867','test'),('2019-02-16 03:59:59','2019-02-16 23:59:59','ETCUSDT','4h','4.122000000000000','4.075800000000000','15.227294558378560','15.056624735817403','3.6941520034882487','3.694152003488249','test'),('2019-02-17 19:59:59','2019-02-21 19:59:59','ETCUSDT','4h','4.107700000000000','4.437900000000000','15.227294558378560','16.451350030583587','3.707012332540974','3.707012332540974','test'),('2019-02-22 15:59:59','2019-02-24 15:59:59','ETCUSDT','4h','4.562700000000000','4.278100000000000','15.227294558378560','14.277486762267804','3.337342923790422','3.337342923790422','test'),('2019-03-07 15:59:59','2019-03-08 15:59:59','ETCUSDT','4h','4.334100000000000','4.311700000000000','15.227294558378560','15.148595082568660','3.513369455799026','3.513369455799026','test'),('2019-03-08 19:59:59','2019-03-08 23:59:59','ETCUSDT','4h','4.315900000000000','4.189200000000000','15.227294558378560','14.780273491962154','3.5281852124420308','3.528185212442031','test'),('2019-03-11 03:59:59','2019-03-11 07:59:59','ETCUSDT','4h','4.341400000000000','4.230400000000000','15.227294558378560','14.837966301138957','3.507461776933376','3.507461776933376','test'),('2019-03-15 03:59:59','2019-03-18 11:59:59','ETCUSDT','4h','4.349600000000000','4.347600000000000','15.227294558378560','15.220292859574819','3.500849401871106','3.500849401871106','test'),('2019-03-19 15:59:59','2019-03-24 15:59:59','ETCUSDT','4h','4.541800000000000','4.772500000000000','15.227294558378560','16.000762534647425','3.352700373943934','3.352700373943934','test'),('2019-03-27 19:59:59','2019-03-28 19:59:59','ETCUSDT','4h','4.781900000000000','4.704400000000000','15.227294558378560','14.980506602069488','3.184360726568636','3.184360726568636','test'),('2019-03-29 11:59:59','2019-03-30 19:59:59','ETCUSDT','4h','4.808200000000000','4.781700000000000','15.227294558378560','15.143370573145615','3.1669428389789442','3.166942838978944','test'),('2019-03-30 23:59:59','2019-03-31 07:59:59','ETCUSDT','4h','4.784300000000000','4.747100000000000','15.227294558378560','15.108895762823998','3.1827633213591455','3.182763321359146','test'),('2019-03-31 11:59:59','2019-04-02 07:59:59','ETCUSDT','4h','4.835200000000000','5.070600000000000','15.227294558378560','15.968630002422715','3.149258470875777','3.149258470875777','test'),('2019-04-02 11:59:59','2019-04-11 03:59:59','ETCUSDT','4h','5.124300000000000','6.560300000000000','15.227294558378560','19.494491050744660','2.9715853010905997','2.971585301090600','test'),('2019-05-01 23:59:59','2019-05-02 15:59:59','ETCUSDT','4h','5.810300000000000','5.821600000000000','15.540059823922038','15.570282476110448','2.674570990124785','2.674570990124785','test'),('2019-05-02 23:59:59','2019-05-03 11:59:59','ETCUSDT','4h','5.778900000000000','5.957400000000000','15.547615486969139','16.027853830671919','2.6904108890912006','2.690410889091201','test'),('2019-05-03 15:59:59','2019-05-04 15:59:59','ETCUSDT','4h','6.045900000000000','5.753300000000000','15.667675072894834','14.909415471126856','2.591454551496855','2.591454551496855','test'),('2019-05-11 19:59:59','2019-05-12 15:59:59','ETCUSDT','4h','6.184800000000000','5.789400000000000','15.667675072894834','14.666026074734406','2.5332549270622873','2.533254927062287','test'),('2019-05-12 19:59:59','2019-05-13 03:59:59','ETCUSDT','4h','5.916600000000000','5.889800000000000','15.667675072894834','15.596706325311159','2.6480875964058472','2.648087596405847','test'),('2019-05-13 07:59:59','2019-05-17 19:59:59','ETCUSDT','4h','5.899100000000000','6.920000000000000','15.667675072894834','18.379127579534551','2.6559432918402526','2.655943291840253','test'),('2019-05-18 03:59:59','2019-05-18 11:59:59','ETCUSDT','4h','7.344300000000000','7.197500000000000','15.887818862676744','15.570248527989850','2.1632856586300595','2.163285658630060','test'),('2019-05-18 15:59:59','2019-05-18 23:59:59','ETCUSDT','4h','7.323400000000000','7.160000000000000','15.887818862676744','15.533329199110451','2.169459385350622','2.169459385350622','test'),('2019-05-19 03:59:59','2019-05-20 19:59:59','ETCUSDT','4h','7.732200000000000','7.335000000000000','15.887818862676744','15.071668006225126','2.0547604643797035','2.054760464379703','test'),('2019-05-25 11:59:59','2019-05-26 07:59:59','ETCUSDT','4h','7.300900000000000','7.154000000000000','15.887818862676744','15.568143125311869','2.176145250952176','2.176145250952176','test'),('2019-05-26 19:59:59','2019-05-30 23:59:59','ETCUSDT','4h','7.430000000000000','8.066500000000000','15.887818862676744','17.248868217467287','2.138333628893236','2.138333628893236','test'),('2019-05-31 03:59:59','2019-05-31 11:59:59','ETCUSDT','4h','8.072900000000001','8.150300000000000','15.887818862676744','16.040145434289322','1.968043560886019','1.968043560886019','test'),('2019-05-31 19:59:59','2019-06-04 11:59:59','ETCUSDT','4h','8.381600000000001','8.921799999999999','15.887818862676744','16.911799934264263','1.8955591847232918','1.895559184723292','test'),('2019-06-12 23:59:59','2019-06-14 07:59:59','ETCUSDT','4h','8.620300000000000','8.250299999999999','16.070186464156983','15.380422883801531','1.8642258928525668','1.864225892852567','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','ETCUSDT','4h','8.330100000000000','8.353400000000001','16.070186464156983','16.115136145987314','1.9291708940057122','1.929170894005712','test'),('2019-06-14 23:59:59','2019-06-18 07:59:59','ETCUSDT','4h','8.540800000000001','8.525000000000000','16.070186464156983','16.040457522356018','1.8815785949977732','1.881578594997773','test'),('2019-06-21 19:59:59','2019-06-26 23:59:59','ETCUSDT','4h','8.653400000000000','9.085599999999999','16.070186464156983','16.872822952682725','1.8570950683149956','1.857095068314996','test'),('2019-08-05 11:59:59','2019-08-06 15:59:59','ETCUSDT','4h','6.310700000000000','5.956000000000000','16.102209876206899','15.197167037363256','2.5515727060717355','2.551572706071735','test'),('2019-08-20 19:59:59','2019-08-28 03:59:59','ETCUSDT','4h','6.078200000000000','6.902700000000000','16.102209876206899','18.286453902881345','2.6491740772279457','2.649174077227946','test'),('2019-09-03 11:59:59','2019-09-06 23:59:59','ETCUSDT','4h','6.784300000000000','6.656300000000000','16.422010173164598','16.112174626068352','2.42059021168943','2.420590211689430','test'),('2019-10-10 11:59:59','2019-10-11 07:59:59','ETCUSDT','4h','4.987700000000000','4.772400000000000','16.422010173164598','15.713134581151779','3.2925015885407296','3.292501588540730','test'),('2019-10-14 07:59:59','2019-10-14 19:59:59','ETCUSDT','4h','4.784400000000000','4.781300000000000','16.422010173164598','16.411369710089435','3.4324074436009946','3.432407443600995','test'),('2019-10-14 23:59:59','2019-10-15 07:59:59','ETCUSDT','4h','4.789200000000000','4.622600000000000','16.422010173164598','15.850744221680170','3.428967295824897','3.428967295824897','test'),('2019-10-26 23:59:59','2019-10-30 23:59:59','ETCUSDT','4h','4.573800000000000','4.787100000000000','16.422010173164598','17.187853622798599','3.590452178312256','3.590452178312256','test'),('2019-11-01 11:59:59','2019-11-08 15:59:59','ETCUSDT','4h','4.879800000000000','4.945500000000000','16.422010173164598','16.643110642113509','3.3653039413837855','3.365303941383786','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 15:59:11
