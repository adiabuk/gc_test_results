-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-30 03:59:59','2018-05-02 11:59:59','RCNBNB','4h','0.010610000000000','0.010810000000000','0.711908500000000','0.725328075871819','67.0978793590952','67.097879359095202','test'),('2018-05-03 07:59:59','2018-05-06 07:59:59','RCNBNB','4h','0.010570000000000','0.010650000000000','0.715263393967955','0.720676929589283','67.66919526659932','67.669195266599317','test'),('2018-07-02 15:59:59','2018-07-07 07:59:59','RCNBNB','4h','0.003578000000000','0.003689000000000','0.716616777873287','0.738848321289703','200.2841749226626','200.284174922662601','test'),('2018-07-08 19:59:59','2018-07-09 11:59:59','RCNBNB','4h','0.003811000000000','0.003630000000000','0.722174663727391','0.687875630892267','189.49741897858587','189.497418978585870','test'),('2018-07-09 15:59:59','2018-07-10 03:59:59','RCNBNB','4h','0.003768000000000','0.003494000000000','0.722174663727391','0.669659839454221','191.6599426028108','191.659942602810787','test'),('2018-07-17 23:59:59','2018-07-19 19:59:59','RCNBNB','4h','0.003633000000000','0.003643000000000','0.722174663727391','0.724162482785270','198.78190578788633','198.781905787886330','test'),('2018-07-23 15:59:59','2018-07-24 03:59:59','RCNBNB','4h','0.003956000000000','0.003517000000000','0.722174663727391','0.642034452054913','182.55173501703513','182.551735017035128','test'),('2018-07-24 07:59:59','2018-07-24 11:59:59','RCNBNB','4h','0.003534000000000','0.003584000000000','0.722174663727391','0.732392188681089','204.35049907396464','204.350499073964642','test'),('2018-07-24 23:59:59','2018-07-25 03:59:59','RCNBNB','4h','0.003691000000000','0.003475000000000','0.722174663727391','0.679912478041908','195.6582670624197','195.658267062419696','test'),('2018-07-31 03:59:59','2018-07-31 11:59:59','RCNBNB','4h','0.003680000000000','0.003247000000000','0.722174663727391','0.637201394870337','196.24311514331276','196.243115143312764','test'),('2018-08-20 11:59:59','2018-08-20 23:59:59','RCNBNB','4h','0.002156000000000','0.001949000000000','0.722174663727391','0.652837856959501','334.96041916854875','334.960419168548754','test'),('2018-08-27 11:59:59','2018-08-27 19:59:59','RCNBNB','4h','0.002131000000000','0.001972000000000','0.722174663727391','0.668291148226380','338.8900345975556','338.890034597555598','test'),('2018-08-27 23:59:59','2018-08-28 03:59:59','RCNBNB','4h','0.002009000000000','0.002089000000000','0.722174663727391','0.750932241177959','359.4697181321011','359.469718132101093','test'),('2018-09-05 03:59:59','2018-09-05 11:59:59','RCNBNB','4h','0.002098000000000','0.001928000000000','0.722174663727391','0.663657174292855','344.22052608550575','344.220526085505753','test'),('2018-09-05 15:59:59','2018-09-05 19:59:59','RCNBNB','4h','0.001978000000000','0.001972000000000','0.722174663727391','0.719984042907186','365.10347003407026','365.103470034070256','test'),('2018-09-10 03:59:59','2018-09-11 19:59:59','RCNBNB','4h','0.002124000000000','0.002015000000000','0.722174663727391','0.685113911210307','340.0069038264553','340.006903826455300','test'),('2018-09-13 07:59:59','2018-09-14 15:59:59','RCNBNB','4h','0.002189000000000','0.002090000000000','0.722174663727391','0.689513498031177','329.9107646082188','329.910764608218813','test'),('2018-09-15 11:59:59','2018-09-21 11:59:59','RCNBNB','4h','0.002138000000000','0.002852000000000','0.722174663727391','0.963349925608288','337.7804788247853','337.780478824785291','test'),('2018-09-23 03:59:59','2018-09-24 07:59:59','RCNBNB','4h','0.003141000000000','0.002785000000000','0.722174663727391','0.640323603464115','229.918708604709','229.918708604708996','test'),('2018-09-29 03:59:59','2018-09-29 19:59:59','RCNBNB','4h','0.002873000000000','0.002793000000000','0.722174663727391','0.702065379669545','251.36605072307378','251.366050723073784','test'),('2018-09-29 23:59:59','2018-10-01 03:59:59','RCNBNB','4h','0.002878000000000','0.002796000000000','0.722174663727391','0.701598457186166','250.9293480637217','250.929348063721704','test'),('2018-10-01 07:59:59','2018-10-01 15:59:59','RCNBNB','4h','0.002830000000000','0.002752000000000','0.722174663727391','0.702270203031018','255.1853935432477','255.185393543247699','test'),('2018-10-05 23:59:59','2018-10-06 15:59:59','RCNBNB','4h','0.002920000000000','0.002761000000000','0.722174663727391','0.682850769366893','247.3200903175997','247.320090317599693','test'),('2018-10-06 19:59:59','2018-10-07 11:59:59','RCNBNB','4h','0.002856000000000','0.002852000000000','0.722174663727391','0.721163214618529','252.86227721547306','252.862277215473057','test'),('2018-10-07 19:59:59','2018-10-07 23:59:59','RCNBNB','4h','0.002813000000000','0.002817000000000','0.722174663727391','0.723201574020640','256.7275733122613','256.727573312261313','test'),('2018-10-09 07:59:59','2018-10-09 11:59:59','RCNBNB','4h','0.002908000000000','0.002800000000000','0.722174663727391','0.695353871539441','248.34066840694328','248.340668406943280','test'),('2018-10-09 15:59:59','2018-10-11 03:59:59','RCNBNB','4h','0.002865000000000','0.002784000000000','0.722174663727391','0.701757160145569','252.06794545458675','252.067945454586749','test'),('2018-10-14 11:59:59','2018-10-15 07:59:59','RCNBNB','4h','0.002901000000000','0.002615000000000','0.722174663727391','0.650977850964194','248.93990476642227','248.939904766422273','test'),('2018-10-18 11:59:59','2018-10-18 19:59:59','RCNBNB','4h','0.002954000000000','0.002812000000000','0.722174663727391','0.687459429384368','244.47348128889337','244.473481288893367','test'),('2018-10-18 23:59:59','2018-10-19 23:59:59','RCNBNB','4h','0.002932000000000','0.002872000000000','0.722174663727391','0.707396191754798','246.30786620988778','246.307866209887777','test'),('2018-10-20 03:59:59','2018-10-20 11:59:59','RCNBNB','4h','0.002887000000000','0.002903000000000','0.722174663727391','0.726177017249954','250.14709516016316','250.147095160163161','test'),('2018-10-20 15:59:59','2018-10-25 11:59:59','RCNBNB','4h','0.002958000000000','0.003055000000000','0.722174663727391','0.745856523896950','244.14288834597397','244.142888345973972','test'),('2018-10-27 23:59:59','2018-10-30 07:59:59','RCNBNB','4h','0.003588000000000','0.003337000000000','0.722174663727391','0.671654641264856','201.27498989057722','201.274989890577217','test'),('2018-10-30 23:59:59','2018-11-03 19:59:59','RCNBNB','4h','0.003588000000000','0.003453000000000','0.722174663727391','0.695002540092163','201.27498989057722','201.274989890577217','test'),('2018-11-07 03:59:59','2018-11-10 11:59:59','RCNBNB','4h','0.003617000000000','0.003526000000000','0.722174663727391','0.704005491927780','199.66122856715262','199.661228567152619','test'),('2018-11-28 11:59:59','2018-11-30 15:59:59','RCNBNB','4h','0.003037000000000','0.002955000000000','0.722174663727391','0.702675710014633','237.79211844826835','237.792118448268354','test'),('2018-12-01 11:59:59','2018-12-03 23:59:59','RCNBNB','4h','0.003224000000000','0.003105000000000','0.722174663727391','0.695518713050108','223.99958552338433','223.999585523384326','test'),('2019-01-16 19:59:59','2019-01-17 07:59:59','RCNBNB','4h','0.001911000000000','0.001832000000000','0.481449775818261','0.461546828518605','251.93604176779735','251.936041767797349','test'),('2019-01-17 11:59:59','2019-01-17 15:59:59','RCNBNB','4h','0.001899000000000','0.001875000000000','0.534770937178497','0.528012378730743','281.60660198973005','281.606601989730052','test'),('2019-01-18 03:59:59','2019-01-18 11:59:59','RCNBNB','4h','0.002010000000000','0.001912000000000','0.534770937178497','0.508697528301137','266.0551926261179','266.055192626117901','test'),('2019-01-18 19:59:59','2019-01-18 23:59:59','RCNBNB','4h','0.001885000000000','0.001935000000000','0.534770937178497','0.548955842673948','283.698109909017','283.698109909016978','test'),('2019-01-19 07:59:59','2019-01-19 19:59:59','RCNBNB','4h','0.001937000000000','0.001917000000000','0.534770937178497','0.529249296113154','276.08205326716416','276.082053267164156','test'),('2019-01-19 23:59:59','2019-01-20 03:59:59','RCNBNB','4h','0.001934000000000','0.001905000000000','0.534770937178497','0.526752138223907','276.51030877895397','276.510308778953970','test'),('2019-01-20 15:59:59','2019-01-20 19:59:59','RCNBNB','4h','0.001936000000000','0.001916000000000','0.534770937178497','0.529246444025827','276.2246576335212','276.224657633521190','test'),('2019-01-20 23:59:59','2019-01-22 03:59:59','RCNBNB','4h','0.002027000000000','0.001910000000000','0.534770937178497','0.503903547119353','263.8238466593473','263.823846659347282','test'),('2019-01-22 07:59:59','2019-01-22 11:59:59','RCNBNB','4h','0.001947000000000','0.001895000000000','0.534770937178497','0.520488405728429','274.66406634745607','274.664066347456071','test'),('2019-02-22 07:59:59','2019-02-28 07:59:59','RCNBNB','4h','0.001575000000000','0.001918000000000','0.534770937178497','0.651232163497370','339.5371029704743','339.537102970474280','test'),('2019-02-28 19:59:59','2019-03-01 15:59:59','RCNBNB','4h','0.002194000000000','0.001840000000000','0.543170764630346','0.455530632142132','247.57099572941945','247.570995729419451','test'),('2019-03-19 19:59:59','2019-03-20 19:59:59','RCNBNB','4h','0.001595000000000','0.001618000000000','0.543170764630346','0.551003321110909','340.545933937521','340.545933937520999','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','RCNBNB','4h','0.001640000000000','0.001572000000000','0.543170764630346','0.520649049999332','331.20168575021097','331.201685750210970','test'),('2019-03-29 19:59:59','2019-04-01 11:59:59','RCNBNB','4h','0.001598000000000','0.001710000000000','0.543170764630346','0.581240305080032','339.90661115791363','339.906611157913630','test'),('2019-04-08 15:59:59','2019-04-09 11:59:59','RCNBNB','4h','0.001677000000000','0.001653000000000','0.543170764630346','0.535397301093597','323.89431403121404','323.894314031214037','test'),('2019-04-09 15:59:59','2019-04-09 23:59:59','RCNBNB','4h','0.001680000000000','0.001661000000000','0.543170764630346','0.537027761935122','323.3159313275869','323.315931327586895','test'),('2019-04-10 03:59:59','2019-04-11 11:59:59','RCNBNB','4h','0.001690000000000','0.001666000000000','0.543170764630346','0.535457096966956','321.402819307897','321.402819307897005','test'),('2019-04-14 03:59:59','2019-04-14 07:59:59','RCNBNB','4h','0.001676000000000','0.001652000000000','0.543170764630346','0.535392662988861','324.0875683951945','324.087568395194523','test'),('2019-04-14 11:59:59','2019-04-14 15:59:59','RCNBNB','4h','0.001664000000000','0.001596000000000','0.543170764630346','0.520973882421894','326.42473835958293','326.424738359582932','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  4:03:04
