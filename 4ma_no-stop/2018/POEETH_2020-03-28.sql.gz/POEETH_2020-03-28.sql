-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 03:59:59','2018-07-05 19:59:59','POEETH','4h','0.000033150000000','0.000042800000000','0.072144500000000','0.093145840120664','2176.3046757164407','2176.304675716440670','test'),('2018-07-18 11:59:59','2018-07-20 03:59:59','POEETH','4h','0.000039800000000','0.000038130000000','0.077394835030166','0.074147363309051','1944.5938449790453','1944.593844979045343','test'),('2018-07-25 23:59:59','2018-07-26 23:59:59','POEETH','4h','0.000039120000000','0.000037970000000','0.077394835030166','0.075119680114913','1978.3955784807263','1978.395578480726272','test'),('2018-07-28 11:59:59','2018-07-30 11:59:59','POEETH','4h','0.000039580000000','0.000039070000000','0.077394835030166','0.076397579702592','1955.402603086559','1955.402603086559111','test'),('2018-08-20 15:59:59','2018-08-23 15:59:59','POEETH','4h','0.000032450000000','0.000034160000000','0.077394835030166','0.081473268555639','2385.0488453055777','2385.048845305577743','test'),('2018-08-24 11:59:59','2018-08-26 07:59:59','POEETH','4h','0.000035540000000','0.000034550000000','0.077394835030166','0.075238929383574','2177.6824713046144','2177.682471304614410','test'),('2018-08-26 11:59:59','2018-08-29 15:59:59','POEETH','4h','0.000035350000000','0.000036240000000','0.077394835030166','0.079343389575480','2189.387129566224','2189.387129566223848','test'),('2018-08-31 19:59:59','2018-09-03 11:59:59','POEETH','4h','0.000037100000000','0.000037250000000','0.077394835030166','0.077707752152929','2086.114151756496','2086.114151756496085','test'),('2018-09-03 15:59:59','2018-09-05 15:59:59','POEETH','4h','0.000038150000000','0.000038270000000','0.077394835030166','0.077638278810077','2028.6981659283356','2028.698165928335584','test'),('2018-09-05 19:59:59','2018-09-06 11:59:59','POEETH','4h','0.000039530000000','0.000038780000000','0.077394835030166','0.075926428091825','1957.875917788161','1957.875917788160905','test'),('2018-09-06 19:59:59','2018-09-08 19:59:59','POEETH','4h','0.000040940000000','0.000039390000000','0.077394835030166','0.074464644646757','1890.4454086508551','1890.445408650855143','test'),('2018-09-08 23:59:59','2018-09-11 11:59:59','POEETH','4h','0.000040250000000','0.000040340000000','0.077394835030166','0.077567891804146','1922.8530442277267','1922.853044227726741','test'),('2018-09-16 19:59:59','2018-09-17 15:59:59','POEETH','4h','0.000040990000000','0.000040940000000','0.077394835030166','0.077300428058917','1888.1394249857528','1888.139424985752839','test'),('2018-09-17 19:59:59','2018-09-18 15:59:59','POEETH','4h','0.000042580000000','0.000041490000000','0.077394835030166','0.075413614499802','1817.6335140950212','1817.633514095021155','test'),('2018-09-18 19:59:59','2018-09-19 11:59:59','POEETH','4h','0.000041800000000','0.000040690000000','0.077394835030166','0.075339613334389','1851.5510772766986','1851.551077276698607','test'),('2018-09-20 03:59:59','2018-09-21 15:59:59','POEETH','4h','0.000041840000000','0.000039400000000','0.077394835030166','0.072881369507374','1849.7809519638147','1849.780951963814687','test'),('2018-09-25 03:59:59','2018-09-27 19:59:59','POEETH','4h','0.000042230000000','0.000045200000000','0.077394835030166','0.082837947983981','1832.6979642473598','1832.697964247359778','test'),('2018-10-03 03:59:59','2018-10-03 11:59:59','POEETH','4h','0.000044930000000','0.000045190000000','0.077394835030166','0.077842701869869','1722.5647680873806','1722.564768087380571','test'),('2018-10-03 19:59:59','2018-10-07 11:59:59','POEETH','4h','0.000045520000000','0.000046100000000','0.077394835030166','0.078380973086350','1700.2380279034712','1700.238027903471220','test'),('2018-10-10 15:59:59','2018-10-11 07:59:59','POEETH','4h','0.000047350000000','0.000045600000000','0.077394835030166','0.074534413460941','1634.5266109855545','1634.526610985554498','test'),('2018-10-11 11:59:59','2018-10-11 15:59:59','POEETH','4h','0.000046160000000','0.000046750000000','0.077394835030166','0.078384067107025','1676.664537048657','1676.664537048656939','test'),('2018-10-11 23:59:59','2018-10-12 03:59:59','POEETH','4h','0.000047530000000','0.000046150000000','0.077394835030166','0.075147730625756','1628.3365249351148','1628.336524935114767','test'),('2018-10-12 07:59:59','2018-10-12 11:59:59','POEETH','4h','0.000046900000000','0.000046000000000','0.077394835030166','0.075909646298244','1650.2097021357356','1650.209702135735597','test'),('2018-10-13 07:59:59','2018-10-13 11:59:59','POEETH','4h','0.000046750000000','0.000046350000000','0.077394835030166','0.076732633233116','1655.5044926238718','1655.504492623871784','test'),('2018-10-13 15:59:59','2018-10-15 07:59:59','POEETH','4h','0.000047460000000','0.000045810000000','0.077394835030166','0.074704116998144','1630.7382012255794','1630.738201225579360','test'),('2018-10-15 15:59:59','2018-10-15 19:59:59','POEETH','4h','0.000047840000000','0.000047470000000','0.077394835030166','0.076796254575292','1617.7850131723662','1617.785013172366234','test'),('2018-10-16 11:59:59','2018-10-20 11:59:59','POEETH','4h','0.000049200000000','0.000055290000000','0.077394835030166','0.086974805463778','1573.0657526456505','1573.065752645650491','test'),('2018-10-21 15:59:59','2018-10-22 07:59:59','POEETH','4h','0.000059580000000','0.000055800000000','0.077394835030166','0.072484588698947','1299.00696593095','1299.006965930949946','test'),('2018-10-23 07:59:59','2018-10-25 15:59:59','POEETH','4h','0.000058380000000','0.000057610000000','0.077394835030166','0.076374039843917','1325.7080340898597','1325.708034089859666','test'),('2018-10-28 11:59:59','2018-10-30 15:59:59','POEETH','4h','0.000061690000000','0.000063190000000','0.077394835030166','0.079276700041436','1254.5766741800292','1254.576674180029158','test'),('2018-10-31 07:59:59','2018-11-01 19:59:59','POEETH','4h','0.000065460000000','0.000062800000000','0.077394835030166','0.074249857010303','1182.3225638583258','1182.322563858325793','test'),('2018-11-02 15:59:59','2018-11-04 15:59:59','POEETH','4h','0.000064440000000','0.000062940000000','0.077394835030166','0.075593279279929','1201.0371668244259','1201.037166824425867','test'),('2018-11-28 11:59:59','2018-11-30 11:59:59','POEETH','4h','0.000051890000000','0.000048840000000','0.077394835030166','0.072845707128027','1491.5173449636925','1491.517344963692494','test'),('2018-12-02 15:59:59','2018-12-03 03:59:59','POEETH','4h','0.000051830000000','0.000049930000000','0.077394835030166','0.074557671484781','1493.2439712553735','1493.243971255373481','test'),('2018-12-04 15:59:59','2018-12-04 19:59:59','POEETH','4h','0.000052350000000','0.000052130000000','0.077394835030166','0.077069584529562','1478.4113663833048','1478.411366383304767','test'),('2018-12-04 23:59:59','2018-12-07 11:59:59','POEETH','4h','0.000052350000000','0.000055810000000','0.077394835030166','0.082510138357852','1478.4113663833048','1478.411366383304767','test'),('2019-01-08 23:59:59','2019-01-12 15:59:59','POEETH','4h','0.000039240000000','0.000039760000000','0.077394835030166','0.078420454658496','1972.345439096993','1972.345439096993005','test'),('2019-01-12 19:59:59','2019-01-14 19:59:59','POEETH','4h','0.000040520000000','0.000040120000000','0.077394835030166','0.076630818889691','1910.040351188697','1910.040351188697059','test'),('2019-01-14 23:59:59','2019-01-15 03:59:59','POEETH','4h','0.000040250000000','0.000040060000000','0.077394835030166','0.077029492951763','1922.8530442277267','1922.853044227726741','test'),('2019-01-15 07:59:59','2019-01-20 19:59:59','POEETH','4h','0.000041680000000','0.000044060000000','0.077394835030166','0.081814213805881','1856.8818385356526','1856.881838535652605','test'),('2019-01-21 19:59:59','2019-01-25 15:59:59','POEETH','4h','0.000045830000000','0.000045980000000','0.077394835030166','0.077648145640127','1688.7373997417849','1688.737399741784884','test'),('2019-01-25 19:59:59','2019-01-26 03:59:59','POEETH','4h','0.000046380000000','0.000046000000000','0.077394835030166','0.076760724695723','1668.7114064287625','1668.711406428762530','test'),('2019-01-26 11:59:59','2019-01-26 19:59:59','POEETH','4h','0.000047650000000','0.000046090000000','0.077394835030166','0.074861027209661','1624.2357823749423','1624.235782374942346','test'),('2019-01-28 07:59:59','2019-01-29 03:59:59','POEETH','4h','0.000046960000000','0.000046140000000','0.077394835030166','0.076043391999401','1648.1012570307923','1648.101257030792340','test'),('2019-01-30 03:59:59','2019-01-30 15:59:59','POEETH','4h','0.000046770000000','0.000046460000000','0.077394835030166','0.076881848097103','1654.7965582673937','1654.796558267393721','test'),('2019-01-30 19:59:59','2019-01-31 11:59:59','POEETH','4h','0.000047070000000','0.000044570000000','0.077394835030166','0.073284210692469','1644.2497350789463','1644.249735078946287','test'),('2019-03-02 19:59:59','2019-03-05 19:59:59','POEETH','4h','0.000035280000000','0.000034420000000','0.077394835030166','0.075508226239748','2193.731151648696','2193.731151648696141','test'),('2019-03-10 03:59:59','2019-03-11 15:59:59','POEETH','4h','0.000035420000000','0.000035620000000','0.077394835030166','0.077831847085672','2185.0602775315074','2185.060277531507381','test'),('2019-03-11 19:59:59','2019-03-16 07:59:59','POEETH','4h','0.000035870000000','0.000035880000000','0.077394835030166','0.077416411510520','2157.648035410259','2157.648035410259126','test'),('2019-03-21 19:59:59','2019-03-21 23:59:59','POEETH','4h','0.000036490000000','0.000036230000000','0.077394835030166','0.076843378271935','2120.987531657057','2120.987531657056934','test'),('2019-03-22 03:59:59','2019-03-24 03:59:59','POEETH','4h','0.000036410000000','0.000036730000000','0.077394835030166','0.078075042314144','2125.647762432464','2125.647762432463878','test'),('2019-03-24 23:59:59','2019-03-25 03:59:59','POEETH','4h','0.000037410000000','0.000036650000000','0.077394835030166','0.075822526165613','2068.8274533591552','2068.827453359155243','test'),('2019-03-25 23:59:59','2019-03-26 15:59:59','POEETH','4h','0.000038130000000','0.000037940000000','0.077394835030166','0.077009180200485','2029.7622614782586','2029.762261478258552','test'),('2019-03-26 19:59:59','2019-03-30 03:59:59','POEETH','4h','0.000041110000000','0.000039430000000','0.077394835030166','0.074232020073934','1882.6279501378256','1882.627950137825565','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','POEETH','4h','0.000041010000000','0.000041050000000','0.077394835030166','0.077470323774404','1887.2186059538162','1887.218605953816223','test'),('2019-04-21 07:59:59','2019-04-22 23:59:59','POEETH','4h','0.000037750000000','0.000037140000000','0.077394835030166','0.076144216503851','2050.194305434861','2050.194305434860780','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:51:24
