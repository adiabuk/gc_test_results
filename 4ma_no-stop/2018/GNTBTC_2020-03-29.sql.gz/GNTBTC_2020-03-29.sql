-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-10-12 03:59:59','2018-10-12 11:59:59','GNTBTC','4h','0.000024420000000','0.000023440000000','0.001467500000000','0.001408607698608','60.09418509418509','60.094185094185093','test'),('2018-10-18 07:59:59','2018-10-19 05:59:59','GNTBTC','4h','0.000025060000000','0.000023590000000','0.001467500000000','0.001381417597765','58.559457302474065','58.559457302474065','test'),('2018-10-19 11:59:59','2018-10-19 15:59:59','GNTBTC','4h','0.000023610000000','0.000023660000000','0.001467500000000','0.001470607793308','62.155866158407456','62.155866158407456','test'),('2018-10-19 23:59:59','2018-10-27 23:59:59','GNTBTC','4h','0.000023810000000','0.000026470000000','0.001467500000000','0.001631445821084','61.633767324653505','61.633767324653505','test'),('2018-11-01 11:59:59','2018-11-01 23:59:59','GNTBTC','4h','0.000026990000000','0.000026870000000','0.001473019727691','0.001466470547723','54.57649972920526','54.576499729205260','test'),('2018-11-02 07:59:59','2018-11-03 11:59:59','GNTBTC','4h','0.000027090000000','0.000026790000000','0.001473019727691','0.001456707216864','54.37503609047619','54.375036090476193','test'),('2018-12-01 07:59:59','2018-12-02 19:59:59','GNTBTC','4h','0.000021760000000','0.000021440000000','0.001473019727691','0.001451357672872','67.69392130932906','67.693921309329056','test'),('2018-12-02 23:59:59','2018-12-04 15:59:59','GNTBTC','4h','0.000022890000000','0.000022900000000','0.001473019727691','0.001473663248760','64.35210693276541','64.352106932765409','test'),('2018-12-04 23:59:59','2018-12-05 03:59:59','GNTBTC','4h','0.000023010000000','0.000022220000000','0.001473019727691','0.001422446690539','64.01650272451108','64.016502724511085','test'),('2018-12-24 07:59:59','2018-12-25 03:59:59','GNTBTC','4h','0.000018760000000','0.000017420000000','0.001473019727691','0.001367804032856','78.51917525005331','78.519175250053308','test'),('2018-12-29 07:59:59','2018-12-30 23:59:59','GNTBTC','4h','0.000019580000000','0.000018120000000','0.001473019727691','0.001363182710202','75.23083389637385','75.230833896373852','test'),('2019-01-04 11:59:59','2019-01-06 15:59:59','GNTBTC','4h','0.000019760000000','0.000018090000000','0.001473019727691','0.001348528687952','74.54553277788462','74.545532777884617','test'),('2019-01-09 11:59:59','2019-01-10 07:59:59','GNTBTC','4h','0.000018440000000','0.000017830000000','0.001473019727691','0.001424291851667','79.88176397456617','79.881763974566169','test'),('2019-01-17 07:59:59','2019-01-18 11:59:59','GNTBTC','4h','0.000018810000000','0.000017640000000','0.001473019727691','0.001381396491040','78.31045867575757','78.310458675757573','test'),('2019-01-18 15:59:59','2019-01-20 11:59:59','GNTBTC','4h','0.000018180000000','0.000018140000000','0.001473019727691','0.001469778760193','81.02418744174918','81.024187441749177','test'),('2019-01-23 03:59:59','2019-01-23 11:59:59','GNTBTC','4h','0.000018260000000','0.000018210000000','0.001473019727691','0.001468986267319','80.66920743105148','80.669207431051476','test'),('2019-01-23 15:59:59','2019-01-23 23:59:59','GNTBTC','4h','0.000018220000000','0.000018030000000','0.001473019727691','0.001457658929213','80.846307776674','80.846307776673996','test'),('2019-01-24 07:59:59','2019-01-25 11:59:59','GNTBTC','4h','0.000018320000000','0.000018220000000','0.001473019727691','0.001464979226994','80.40500697003274','80.405006970032744','test'),('2019-01-25 15:59:59','2019-01-25 19:59:59','GNTBTC','4h','0.000018470000000','0.000018280000000','0.001473019727691','0.001457866844732','79.75201557612344','79.752015576123441','test'),('2019-01-25 23:59:59','2019-01-26 07:59:59','GNTBTC','4h','0.000018420000000','0.000018290000000','0.001473019727691','0.001462623822990','79.96849770309447','79.968497703094471','test'),('2019-02-11 19:59:59','2019-02-12 03:59:59','GNTBTC','4h','0.000016680000000','0.000016300000000','0.001473019727691','0.001439461724302','88.31053523327338','88.310535233273384','test'),('2019-02-16 19:59:59','2019-02-19 15:59:59','GNTBTC','4h','0.000016830000000','0.000017040000000','0.001473019727691','0.001491399652992','87.523453814082','87.523453814082004','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','GNTBTC','4h','0.000017130000000','0.000016950000000','0.001473019727691','0.001457541411813','85.99064376479859','85.990643764798591','test'),('2019-02-27 07:59:59','2019-02-27 23:59:59','GNTBTC','4h','0.000017450000000','0.000016790000000','0.001473019727691','0.001417306660626','84.4137379765616','84.413737976561606','test'),('2019-02-28 03:59:59','2019-02-28 07:59:59','GNTBTC','4h','0.000016800000000','0.000016760000000','0.001473019727691','0.001469512537863','87.67974569589286','87.679745695892862','test'),('2019-03-01 07:59:59','2019-03-04 07:59:59','GNTBTC','4h','0.000017120000000','0.000017050000000','0.001473019727691','0.001466996866655','86.04087194456777','86.040871944567769','test'),('2019-03-06 23:59:59','2019-03-08 07:59:59','GNTBTC','4h','0.000017450000000','0.000017210000000','0.001473019727691','0.001452760430577','84.4137379765616','84.413737976561606','test'),('2019-03-08 15:59:59','2019-03-08 23:59:59','GNTBTC','4h','0.000017310000000','0.000017320000000','0.001473019727691','0.001473870692294','85.09646029410746','85.096460294107459','test'),('2019-03-09 03:59:59','2019-03-11 15:59:59','GNTBTC','4h','0.000017440000000','0.000018520000000','0.001473019727691','0.001564238839268','84.4621403492546','84.462140349254597','test'),('2019-03-11 23:59:59','2019-03-16 07:59:59','GNTBTC','4h','0.000018640000000','0.000018770000000','0.001473019727691','0.001483292933946','79.02466350273605','79.024663502736047','test'),('2019-03-20 11:59:59','2019-03-21 15:59:59','GNTBTC','4h','0.000020840000000','0.000019530000000','0.001473019727691','0.001380425877246','70.6823285840211','70.682328584021107','test'),('2019-03-21 19:59:59','2019-03-22 23:59:59','GNTBTC','4h','0.000019680000000','0.000019530000000','0.001473019727691','0.001461792443181','74.84856339893292','74.848563398932924','test'),('2019-03-24 23:59:59','2019-03-26 15:59:59','GNTBTC','4h','0.000019920000000','0.000020060000000','0.001473019727691','0.001483372275978','73.94677347846385','73.946773478463854','test'),('2019-03-26 19:59:59','2019-03-31 07:59:59','GNTBTC','4h','0.000020510000000','0.000021190000000','0.001473019727691','0.001521857046795','71.8195869181375','71.819586918137503','test'),('2019-03-31 11:59:59','2019-04-02 07:59:59','GNTBTC','4h','0.000021650000000','0.000020280000000','0.001473019727691','0.001379807855777','68.0378627109007','68.037862710900697','test'),('2019-05-17 15:59:59','2019-05-19 03:59:59','GNTBTC','4h','0.000011560000000','0.000011220000000','0.001473019727691','0.001429695618053','127.42385187638409','127.423851876384091','test'),('2019-05-21 07:59:59','2019-05-22 11:59:59','GNTBTC','4h','0.000012460000000','0.000011410000000','0.001473019727691','0.001348888851762','118.21988183715892','118.219881837158923','test'),('2019-05-22 15:59:59','2019-05-23 03:59:59','GNTBTC','4h','0.000011480000000','0.000011330000000','0.001473019727691','0.001453772954246','128.3118229695993','128.311822969599291','test'),('2019-05-24 07:59:59','2019-05-26 19:59:59','GNTBTC','4h','0.000011990000000','0.000011260000000','0.001473019727691','0.001383336291393','122.85402232618848','122.854022326188485','test'),('2019-05-29 03:59:59','2019-05-30 19:59:59','GNTBTC','4h','0.000012210000000','0.000011540000000','0.001473019727691','0.001392190635344','120.64043633832924','120.640436338329238','test'),('2019-06-08 07:59:59','2019-06-09 19:59:59','GNTBTC','4h','0.000012450000000','0.000011640000000','0.001473019727691','0.001377184709263','118.31483756554218','118.314837565542177','test'),('2019-06-10 03:59:59','2019-06-10 11:59:59','GNTBTC','4h','0.000011830000000','0.000011570000000','0.001473019727691','0.001440645667742','124.51561518943365','124.515615189433646','test'),('2019-06-10 23:59:59','2019-06-14 03:59:59','GNTBTC','4h','0.000011940000000','0.000012240000000','0.001473019727691','0.001510030273613','123.36848640628142','123.368486406281420','test'),('2019-07-25 23:59:59','2019-07-27 03:59:59','GNTBTC','4h','0.000006430000000','0.000006270000000','0.001473019727691','0.001436366048619','229.08549419766717','229.085494197667174','test'),('2019-07-27 07:59:59','2019-07-27 11:59:59','GNTBTC','4h','0.000006310000000','0.000006230000000','0.001473019727691','0.001454344358719','233.44211215388273','233.442112153882732','test'),('2019-07-27 19:59:59','2019-07-29 11:59:59','GNTBTC','4h','0.000006430000000','0.000006380000000','0.001473019727691','0.001461565452981','229.08549419766717','229.085494197667174','test'),('2019-07-30 15:59:59','2019-08-01 07:59:59','GNTBTC','4h','0.000006760000000','0.000006510000000','0.001473019727691','0.001418544146046','217.9023265815089','217.902326581508902','test'),('2019-08-22 19:59:59','2019-08-26 03:59:59','GNTBTC','4h','0.000005120000000','0.000006050000000','0.001473019727691','0.001740579951666','287.6991655646484','287.699165564648411','test'),('2019-08-26 19:59:59','2019-08-31 15:59:59','GNTBTC','4h','0.000005780000000','0.000006280000000','0.001473019727691','0.001600443579567','254.84770375276818','254.847703752768183','test'),('2019-09-10 07:59:59','2019-09-11 07:59:59','GNTBTC','4h','0.000005920000000','0.000005770000000','0.001473019727691','0.001435696592699','248.82089994780407','248.820899947804065','test'),('2019-09-13 11:59:59','2019-09-14 03:59:59','GNTBTC','4h','0.000005810000000','0.000005770000000','0.001473019727691','0.001462878455900','253.53179478330463','253.531794783304633','test'),('2019-09-14 11:59:59','2019-09-15 11:59:59','GNTBTC','4h','0.000005840000000','0.000005820000000','0.001473019727691','0.001467975139582','252.2294054265411','252.229405426541092','test'),('2019-09-15 23:59:59','2019-09-17 15:59:59','GNTBTC','4h','0.000005820000000','0.000005850000000','0.001473019727691','0.001480612612885','253.0961731427835','253.096173142783499','test'),('2019-09-17 19:59:59','2019-09-19 03:59:59','GNTBTC','4h','0.000005910000000','0.000005950000000','0.001473019727691','0.001482989404359','249.24191669898477','249.241916698984767','test'),('2019-09-19 07:59:59','2019-09-19 23:59:59','GNTBTC','4h','0.000006010000000','0.000006030000000','0.001473019727691','0.001477921623623','245.09479662079866','245.094796620798661','test'),('2019-09-21 07:59:59','2019-09-22 23:59:59','GNTBTC','4h','0.000006050000000','0.000006020000000','0.001473019727691','0.001465715497636','243.4743351555372','243.474335155537204','test'),('2019-10-05 11:59:59','2019-10-09 15:59:59','GNTBTC','4h','0.000006080000000','0.000005870000000','0.001473019727691','0.001422142401570','242.272981528125','242.272981528125001','test'),('2019-10-09 19:59:59','2019-10-09 23:59:59','GNTBTC','4h','0.000006150000000','0.000006190000000','0.001473019727691','0.001482600343806','239.51540287658534','239.515402876585341','test'),('2019-10-11 23:59:59','2019-10-11 23:59:59','GNTBTC','4h','0.000006180000000','0.000006180000000','0.001473019727691','0.001473019727691','238.3527067461165','238.352706746116496','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  5:13:30
