-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-10 03:59:59','2018-05-11 07:59:59','GXSBTC','4h','0.000472200000000','0.000429300000000','0.001467500000000','0.001334175667090','3.107793307920373','3.107793307920373','test'),('2018-05-13 15:59:59','2018-05-13 23:59:59','GXSBTC','4h','0.000441800000000','0.000437600000000','0.001467500000000','0.001453549117248','3.321638750565867','3.321638750565867','test'),('2018-05-14 07:59:59','2018-05-14 11:59:59','GXSBTC','4h','0.000436900000000','0.000437800000000','0.001467500000000','0.001470523002976','3.3588921950103','3.358892195010300','test'),('2018-05-17 23:59:59','2018-05-18 03:59:59','GXSBTC','4h','0.000438100000000','0.000439000000000','0.001467500000000','0.001470514722666','3.3496918511755305','3.349691851175530','test'),('2018-05-29 15:59:59','2018-06-03 03:59:59','GXSBTC','4h','0.000470100000000','0.000448200000000','0.001467500000000','0.001399135290364','3.1216762390980644','3.121676239098064','test'),('2018-06-03 07:59:59','2018-06-10 03:59:59','GXSBTC','4h','0.000450600000000','0.000508200000000','0.001467500000000','0.001655089880160','3.256768752774079','3.256768752774079','test'),('2018-06-11 19:59:59','2018-06-13 11:59:59','GXSBTC','4h','0.000519700000000','0.000506300000000','0.001467500000000','0.001429661824129','2.823744467962286','2.823744467962286','test'),('2018-07-13 19:59:59','2018-07-17 19:59:59','GXSBTC','4h','0.000406800000000','0.000410700000000','0.001467500000000','0.001481568952802','3.6074237954768926','3.607423795476893','test'),('2018-07-17 23:59:59','2018-07-19 11:59:59','GXSBTC','4h','0.000430000000000','0.000420000000000','0.001467500000000','0.001433372093023','3.412790697674419','3.412790697674419','test'),('2018-07-19 15:59:59','2018-07-20 19:59:59','GXSBTC','4h','0.000424000000000','0.000424300000000','0.001467500000000','0.001468538325472','3.4610849056603774','3.461084905660377','test'),('2018-07-21 23:59:59','2018-07-23 23:59:59','GXSBTC','4h','0.000439000000000','0.000423900000000','0.001467500000000','0.001417023348519','3.342824601366743','3.342824601366743','test'),('2018-07-24 03:59:59','2018-07-24 07:59:59','GXSBTC','4h','0.000439900000000','0.000399000000000','0.001467500000000','0.001331058195044','3.3359854512389178','3.335985451238918','test'),('2018-09-21 15:59:59','2018-09-29 15:59:59','GXSBTC','4h','0.000172800000000','0.000208800000000','0.001467500000000','0.001773229166667','8.492476851851853','8.492476851851853','test'),('2018-10-05 07:59:59','2018-10-06 15:59:59','GXSBTC','4h','0.000207900000000','0.000204100000000','0.001477484896540','0.001450479400596','7.106709459066858','7.106709459066858','test'),('2018-10-08 11:59:59','2018-10-11 03:59:59','GXSBTC','4h','0.000210200000000','0.000215200000000','0.001477484896540','0.001512629637181','7.0289481281636546','7.028948128163655','test'),('2018-10-12 23:59:59','2018-10-15 07:59:59','GXSBTC','4h','0.000221800000000','0.000231100000000','0.001479519707714','0.001541555475441','6.670512658765778','6.670512658765778','test'),('2018-10-15 11:59:59','2018-10-15 23:59:59','GXSBTC','4h','0.000232200000000','0.000230200000000','0.001495028649646','0.001482151572560','6.438538542833763','6.438538542833763','test'),('2018-11-04 03:59:59','2018-11-04 15:59:59','GXSBTC','4h','0.000214400000000','0.000209300000000','0.001495028649646','0.001459465934566','6.973081388274253','6.973081388274253','test'),('2018-11-04 19:59:59','2018-11-04 23:59:59','GXSBTC','4h','0.000209800000000','0.000209300000000','0.001495028649646','0.001491465664304','7.125970684680648','7.125970684680648','test'),('2018-11-07 11:59:59','2018-11-07 15:59:59','GXSBTC','4h','0.000211300000000','0.000210800000000','0.001495028649646','0.001491490957621','7.07538404943682','7.075384049436820','test'),('2018-11-07 19:59:59','2018-11-08 03:59:59','GXSBTC','4h','0.000211500000000','0.000207900000000','0.001495028649646','0.001469581353482','7.068693378940899','7.068693378940899','test'),('2018-12-24 07:59:59','2018-12-25 03:59:59','GXSBTC','4h','0.000148400000000','0.000144400000000','0.001495028649646','0.001454731381461','10.074317046132075','10.074317046132075','test'),('2018-12-25 11:59:59','2018-12-25 15:59:59','GXSBTC','4h','0.000145800000000','0.000139500000000','0.001495028649646','0.001430428646266','10.253968790438957','10.253968790438957','test'),('2019-01-01 15:59:59','2019-01-02 03:59:59','GXSBTC','4h','0.000145200000000','0.000143400000000','0.001495028649646','0.001476495236634','10.296340562300275','10.296340562300275','test'),('2019-01-02 11:59:59','2019-01-03 03:59:59','GXSBTC','4h','0.000144300000000','0.000143000000000','0.001495028649646','0.001481559923073','10.360558902605682','10.360558902605682','test'),('2019-01-03 11:59:59','2019-01-03 15:59:59','GXSBTC','4h','0.000143800000000','0.000142600000000','0.001495028649646','0.001482552749927','10.39658309906815','10.396583099068151','test'),('2019-01-03 19:59:59','2019-01-06 19:59:59','GXSBTC','4h','0.000143500000000','0.000144800000000','0.001495028649646','0.001508572463197','10.418318116','10.418318116000000','test'),('2019-01-12 15:59:59','2019-01-13 11:59:59','GXSBTC','4h','0.000147000000000','0.000144400000000','0.001495028649646','0.001468585966047','10.170262922761905','10.170262922761905','test'),('2019-01-13 15:59:59','2019-01-13 19:59:59','GXSBTC','4h','0.000145100000000','0.000142900000000','0.001495028649646','0.001472361089141','10.303436593011716','10.303436593011716','test'),('2019-01-13 23:59:59','2019-01-14 03:59:59','GXSBTC','4h','0.000144200000000','0.000145900000000','0.001495028649646','0.001512653814032','10.367743756213592','10.367743756213592','test'),('2019-01-14 11:59:59','2019-01-15 03:59:59','GXSBTC','4h','0.000145700000000','0.000143200000000','0.001495028649646','0.001469376133351','10.261006517817433','10.261006517817433','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','GXSBTC','4h','0.000144400000000','0.000143400000000','0.001495028649646','0.001484675265646','10.353384000318558','10.353384000318558','test'),('2019-01-16 15:59:59','2019-01-16 19:59:59','GXSBTC','4h','0.000146200000000','0.000145600000000','0.001495028649646','0.001488893101152','10.22591415626539','10.225914156265389','test'),('2019-01-16 23:59:59','2019-01-20 19:59:59','GXSBTC','4h','0.000146000000000','0.000176700000000','0.001495028649646','0.001809394262962','10.239922257849315','10.239922257849315','test'),('2019-01-21 15:59:59','2019-01-23 23:59:59','GXSBTC','4h','0.000165100000000','0.000155800000000','0.001501008605094','0.001416457544965','9.091511841880676','9.091511841880676','test'),('2019-01-29 23:59:59','2019-01-31 11:59:59','GXSBTC','4h','0.000159600000000','0.000156800000000','0.001501008605094','0.001474675120794','9.404815821390978','9.404815821390978','test'),('2019-02-03 23:59:59','2019-02-04 07:59:59','GXSBTC','4h','0.000158400000000','0.000158000000000','0.001501008605094','0.001497218179324','9.476064426098484','9.476064426098484','test'),('2019-02-04 11:59:59','2019-02-04 19:59:59','GXSBTC','4h','0.000159100000000','0.000157000000000','0.001501008605094','0.001481196423631','9.434372125040856','9.434372125040856','test'),('2019-02-04 23:59:59','2019-02-05 07:59:59','GXSBTC','4h','0.000158000000000','0.000157100000000','0.001501008605094','0.001492458556078','9.500054462620254','9.500054462620254','test'),('2019-02-05 15:59:59','2019-02-05 19:59:59','GXSBTC','4h','0.000158500000000','0.000155200000000','0.001501008605094','0.001469757321833','9.470085836555205','9.470085836555205','test'),('2019-02-08 03:59:59','2019-02-09 19:59:59','GXSBTC','4h','0.000158700000000','0.000158400000000','0.001501008605094','0.001498171159716','9.458151260831757','9.458151260831757','test'),('2019-02-10 15:59:59','2019-02-10 23:59:59','GXSBTC','4h','0.000161800000000','0.000164200000000','0.001501008605094','0.001523273256838','9.276938226786156','9.276938226786156','test'),('2019-02-11 15:59:59','2019-02-11 19:59:59','GXSBTC','4h','0.000160500000000','0.000159000000000','0.001501008605094','0.001486980487289','9.352078536411215','9.352078536411215','test'),('2019-02-16 23:59:59','2019-02-18 15:59:59','GXSBTC','4h','0.000160600000000','0.000160400000000','0.001501008605094','0.001499139354029','9.346255324371107','9.346255324371107','test'),('2019-02-19 23:59:59','2019-02-20 03:59:59','GXSBTC','4h','0.000163600000000','0.000158600000000','0.001501008605094','0.001455134258973','9.174869224290953','9.174869224290953','test'),('2019-02-20 19:59:59','2019-02-21 11:59:59','GXSBTC','4h','0.000163500000000','0.000159000000000','0.001501008605094','0.001459696441651','9.180480765100917','9.180480765100917','test'),('2019-02-23 11:59:59','2019-02-24 15:59:59','GXSBTC','4h','0.000167100000000','0.000161300000000','0.001501008605094','0.001448908964702','8.98269661935368','8.982696619353680','test'),('2019-02-24 19:59:59','2019-02-25 03:59:59','GXSBTC','4h','0.000162900000000','0.000160900000000','0.001501008605094','0.001482580015713','9.214294690570902','9.214294690570902','test'),('2019-02-26 11:59:59','2019-03-04 07:59:59','GXSBTC','4h','0.000167300000000','0.000169000000000','0.001501008605094','0.001516260934016','8.971958189444113','8.971958189444113','test'),('2019-03-06 07:59:59','2019-03-06 23:59:59','GXSBTC','4h','0.000169800000000','0.000170600000000','0.001501008605094','0.001508080494871','8.83986222081272','8.839862220812719','test'),('2019-03-07 11:59:59','2019-03-14 15:59:59','GXSBTC','4h','0.000173900000000','0.000224100000000','0.001501008605094','0.001934307236352','8.631446837803335','8.631446837803335','test'),('2019-03-15 19:59:59','2019-03-16 07:59:59','GXSBTC','4h','0.000231000000000','0.000225300000000','0.001532795971139','0.001494973732890','6.635480394540043','6.635480394540043','test'),('2019-03-17 19:59:59','2019-03-23 15:59:59','GXSBTC','4h','0.000232000000000','0.000273100000000','0.001532795971139','0.001804338705681','6.606879185943965','6.606879185943965','test'),('2019-03-28 11:59:59','2019-04-02 07:59:59','GXSBTC','4h','0.000266400000000','0.000262500000000','0.001591226095212','0.001567931118593','5.973070927972972','5.973070927972972','test'),('2019-04-14 11:59:59','2019-04-17 11:59:59','GXSBTC','4h','0.000260400000000','0.000256100000000','0.001591226095212','0.001564950088263','6.110699290368664','6.110699290368664','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:18:17
