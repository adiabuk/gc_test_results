-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-17 19:59:59','2018-07-19 23:59:59','INSETH','4h','0.001480000000000','0.001378000000000','0.072144500000000','0.067172379054054','48.74628378378379','48.746283783783788','test'),('2018-08-12 15:59:59','2018-08-14 07:59:59','INSETH','4h','0.000880000000000','0.000880000000000','0.072144500000000','0.072144500000000','81.98238636363637','81.982386363636365','test'),('2018-08-14 11:59:59','2018-08-18 15:59:59','INSETH','4h','0.000918000000000','0.000990000000000','0.072144500000000','0.077802892156863','78.58877995642702','78.588779956427018','test'),('2018-08-20 03:59:59','2018-08-22 23:59:59','INSETH','4h','0.001013000000000','0.001018000000000','0.072316067802729','0.072673007920215','71.38802349726481','71.388023497264811','test'),('2018-08-24 07:59:59','2018-08-29 19:59:59','INSETH','4h','0.001045000000000','0.001131000000000','0.072405302832101','0.078364016749384','69.2873711311969','69.287371131196906','test'),('2018-08-30 03:59:59','2018-08-30 11:59:59','INSETH','4h','0.001151000000000','0.001099000000000','0.073894981311421','0.070556546013251','64.20067881096568','64.200678810965684','test'),('2018-08-31 15:59:59','2018-09-02 11:59:59','INSETH','4h','0.001151000000000','0.001114000000000','0.073894981311421','0.071519556195415','64.20067881096526','64.200678810965258','test'),('2018-09-03 15:59:59','2018-09-05 11:59:59','INSETH','4h','0.001191000000000','0.001127000000000','0.073894981311421','0.069924134288809','62.04448472831318','62.044484728313179','test'),('2018-09-05 15:59:59','2018-09-05 19:59:59','INSETH','4h','0.001145000000000','0.001138000000000','0.073894981311421','0.073443221600347','64.53710158202708','64.537101582027077','test'),('2018-09-06 19:59:59','2018-09-13 15:59:59','INSETH','4h','0.001195000000000','0.001263000000000','0.073894981311421','0.078099884013661','61.83680444470376','61.836804444703759','test'),('2018-09-17 19:59:59','2018-09-21 03:59:59','INSETH','4h','0.001418000000000','0.001361000000000','0.073894981311421','0.070924590666322','52.11211658069182','52.112116580691819','test'),('2018-09-22 23:59:59','2018-09-29 19:59:59','INSETH','4h','0.001639000000000','0.001587000000000','0.073894981311421','0.071550540171583','45.08540653533923','45.085406535339231','test'),('2018-10-04 11:59:59','2018-10-13 15:59:59','INSETH','4h','0.001652000000000','0.002154000000000','0.073894981311421','0.096349751661502','44.73061822725242','44.730618227252421','test'),('2018-10-14 19:59:59','2018-10-15 07:59:59','INSETH','4h','0.002354000000000','0.002098000000000','0.076697074841302','0.068356186498323','32.58159508976295','32.581595089762949','test'),('2018-10-16 19:59:59','2018-10-21 15:59:59','INSETH','4h','0.002277000000000','0.002428000000000','0.076697074841302','0.081783266453527','33.68338816043127','33.683388160431271','test'),('2018-10-24 23:59:59','2018-10-25 11:59:59','INSETH','4h','0.002453000000000','0.002327000000000','0.076697074841302','0.072757477845785','31.266642821566247','31.266642821566247','test'),('2018-11-02 07:59:59','2018-11-04 19:59:59','INSETH','4h','0.002465000000000','0.002244000000000','0.076697074841302','0.069820785372771','31.114431984301014','31.114431984301014','test'),('2018-11-05 03:59:59','2018-11-06 07:59:59','INSETH','4h','0.002481000000000','0.002352000000000','0.076697074841302','0.072709197914850','30.913774623660622','30.913774623660622','test'),('2018-11-06 11:59:59','2018-11-06 15:59:59','INSETH','4h','0.002392000000000','0.002377000000000','0.076697074841302','0.076216114923819','32.06399449887208','32.063994498872077','test'),('2018-11-07 07:59:59','2018-11-09 11:59:59','INSETH','4h','0.002495000000000','0.002511000000000','0.076697074841302','0.077188919810224','30.740310557636075','30.740310557636075','test'),('2018-11-10 23:59:59','2018-11-11 07:59:59','INSETH','4h','0.002626000000000','0.002532000000000','0.076697074841302','0.073951634995498','29.206806870259715','29.206806870259715','test'),('2018-11-18 11:59:59','2018-11-19 03:59:59','INSETH','4h','0.002481000000000','0.002415000000000','0.076697074841302','0.074656765716140','30.913774623660622','30.913774623660622','test'),('2018-11-19 07:59:59','2018-11-19 11:59:59','INSETH','4h','0.002433000000000','0.002393000000000','0.076697074841302','0.075436128275888','31.523664135348135','31.523664135348135','test'),('2018-11-29 19:59:59','2018-11-30 03:59:59','INSETH','4h','0.002202000000000','0.002106000000000','0.076697074841302','0.073353333158847','34.83064252556858','34.830642525568578','test'),('2018-12-01 11:59:59','2018-12-03 03:59:59','INSETH','4h','0.002149000000000','0.002111000000000','0.076697074841302','0.075340867840851','35.68965790660866','35.689657906608659','test'),('2018-12-03 07:59:59','2018-12-03 15:59:59','INSETH','4h','0.002234000000000','0.002188000000000','0.076697074841302','0.075117815466772','34.33172553325963','34.331725533259629','test'),('2018-12-03 23:59:59','2018-12-06 23:59:59','INSETH','4h','0.002196000000000','0.002274000000000','0.076697074841302','0.079421287882113','34.925808215529145','34.925808215529145','test'),('2018-12-07 03:59:59','2018-12-07 19:59:59','INSETH','4h','0.002319000000000','0.002185000000000','0.076697074841302','0.072265247317053','33.07333973320483','33.073339733204833','test'),('2018-12-13 07:59:59','2018-12-16 07:59:59','INSETH','4h','0.002344000000000','0.002555000000000','0.076697074841302','0.083601120400822','32.720595068814845','32.720595068814845','test'),('2018-12-20 23:59:59','2018-12-22 15:59:59','INSETH','4h','0.002820000000000','0.002536000000000','0.076697074841302','0.068972972268632','27.19754426996525','27.197544269965249','test'),('2019-01-08 03:59:59','2019-01-17 15:59:59','INSETH','4h','0.002263000000000','0.002407000000000','0.076697074841302','0.081577489678751','33.89176970450818','33.891769704508178','test'),('2019-01-18 15:59:59','2019-01-22 11:59:59','INSETH','4h','0.002548000000000','0.002582000000000','0.076697074841302','0.077720505196327','30.1008927948595','30.100892794859501','test'),('2019-01-22 15:59:59','2019-01-23 23:59:59','INSETH','4h','0.002664000000000','0.002628000000000','0.076697074841302','0.075660627883987','28.790193258746996','28.790193258746996','test'),('2019-02-05 03:59:59','2019-02-05 11:59:59','INSETH','4h','0.002576000000000','0.002522000000000','0.076697074841302','0.075089294545716','29.77370917752407','29.773709177524069','test'),('2019-02-27 03:59:59','2019-02-28 11:59:59','INSETH','4h','0.002052000000000','0.001990000000000','0.076697074841302','0.074379716829528','37.37674212539084','37.376742125390841','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','INSETH','4h','0.001996000000000','0.001995000000000','0.076697074841302','0.076658649453105','38.425388197045095','38.425388197045095','test'),('2019-03-01 07:59:59','2019-03-05 11:59:59','INSETH','4h','0.002031000000000','0.002118000000000','0.076697074841302','0.079982473911313','37.76320770128115','37.763207701281146','test'),('2019-03-12 01:59:59','2019-03-15 15:59:59','INSETH','4h','0.002080000000000','0.002128000000000','0.076697074841302','0.078467007337640','36.87359367370289','36.873593673702892','test'),('2019-03-20 03:59:59','2019-03-21 03:59:59','INSETH','4h','0.002115000000000','0.002154000000000','0.076697074841302','0.078111347143340','36.26339235995366','36.263392359953663','test'),('2019-03-25 15:59:59','2019-03-26 07:59:59','INSETH','4h','0.002111000000000','0.002109000000000','0.076697074841302','0.076624410630178','36.3321055619621','36.332105561962102','test'),('2019-03-26 15:59:59','2019-03-27 07:59:59','INSETH','4h','0.002143000000000','0.002130000000000','0.076697074841302','0.076231810271569','35.789582287121796','35.789582287121796','test'),('2019-03-27 11:59:59','2019-03-30 03:59:59','INSETH','4h','0.002173000000000','0.002137000000000','0.076697074841302','0.075426437614295','35.29547852798068','35.295478527980677','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','INSETH','4h','0.002258000000000','0.002309000000000','0.076697074841302','0.078429382554724','33.96681791023118','33.966817910231178','test'),('2019-04-07 11:59:59','2019-04-07 23:59:59','INSETH','4h','0.002315000000000','0.002132000000000','0.076697074841302','0.070634195922962','33.130485892571066','33.130485892571066','test'),('2019-05-24 19:59:59','2019-05-24 23:59:59','INSETH','4h','0.001376000000000','0.001374000000000','0.076697074841302','0.076585596534847','55.73915322769041','55.739153227690409','test'),('2019-05-25 07:59:59','2019-05-25 11:59:59','INSETH','4h','0.001348000000000','0.001292000000000','0.076697074841302','0.073510846212880','56.896939793250745','56.896939793250745','test'),('2019-05-27 19:59:59','2019-05-28 19:59:59','INSETH','4h','0.001432000000000','0.001378000000000','0.076697074841302','0.073804866711812','53.5594098053785','53.559409805378500','test'),('2019-05-29 03:59:59','2019-05-29 07:59:59','INSETH','4h','0.001380000000000','0.001389000000000','0.076697074841302','0.077197273155484','55.5775904647116','55.577590464711598','test'),('2019-05-29 11:59:59','2019-05-30 03:59:59','INSETH','4h','0.001399000000000','0.001358000000000','0.076697074841302','0.074449340696560','54.82278401808578','54.822784018085777','test'),('2019-06-02 23:59:59','2019-06-03 03:59:59','INSETH','4h','0.001384000000000','0.001359000000000','0.076697074841302','0.075311650801539','55.416961590536125','55.416961590536125','test'),('2019-06-03 15:59:59','2019-06-03 23:59:59','INSETH','4h','0.001421000000000','0.001378000000000','0.076697074841302','0.074376192210636','53.97401466664462','53.974014666644621','test'),('2019-06-04 11:59:59','2019-06-04 15:59:59','INSETH','4h','0.001379000000000','0.001384000000000','0.076697074841302','0.076975164307732','55.617893285933285','55.617893285933285','test'),('2019-06-05 03:59:59','2019-06-08 19:59:59','INSETH','4h','0.001430000000000','0.001428000000000','0.076697074841302','0.076589806205160','53.63431807084056','53.634318070840557','test'),('2019-06-08 23:59:59','2019-06-12 19:59:59','INSETH','4h','0.001458000000000','0.001508000000000','0.076697074841302','0.079327290027904','52.604303732031546','52.604303732031546','test'),('2019-06-12 23:59:59','2019-06-14 11:59:59','INSETH','4h','0.001510000000000','0.001470000000000','0.076697074841302','0.074665364249479','50.79276479556424','50.792764795564239','test'),('2019-06-20 15:59:59','2019-06-20 23:59:59','INSETH','4h','0.001487000000000','0.001493000000000','0.076697074841302','0.077006545217259','51.57839599280565','51.578395992805653','test'),('2019-06-21 03:59:59','2019-06-21 07:59:59','INSETH','4h','0.001517000000000','0.001498000000000','0.076697074841302','0.075736465466230','50.55838816170205','50.558388161702048','test'),('2019-06-21 11:59:59','2019-06-21 19:59:59','INSETH','4h','0.001510000000000','0.001438000000000','0.076697074841302','0.073039995776021','50.79276479556424','50.792764795564239','test'),('2019-06-21 23:59:59','2019-06-22 03:59:59','INSETH','4h','0.001605000000000','0.001432000000000','0.076697074841302','0.068430038113859','47.78633946498567','47.786339464985673','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  8:02:42
