-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 19:59:59','2018-07-05 19:59:59','POEBTC','4h','0.000003300000000','0.000003050000000','0.001467500000000','0.001356325757576','444.6969696969697','444.696969696969688','test'),('2018-07-18 15:59:59','2018-07-19 03:59:59','POEBTC','4h','0.000002920000000','0.000002530000000','0.001467500000000','0.001271498287671','502.56849315068496','502.568493150684958','test'),('2018-07-19 07:59:59','2018-07-19 11:59:59','POEBTC','4h','0.000002630000000','0.000002580000000','0.001467500000000','0.001439600760456','557.9847908745248','557.984790874524833','test'),('2018-07-19 15:59:59','2018-07-19 19:59:59','POEBTC','4h','0.000002660000000','0.000002530000000','0.001467500000000','0.001395780075188','551.6917293233083','551.691729323308323','test'),('2018-08-27 23:59:59','2018-08-29 03:59:59','POEBTC','4h','0.000001560000000','0.000001510000000','0.001467500000000','0.001420464743590','940.7051282051282','940.705128205128176','test'),('2018-08-29 07:59:59','2018-08-29 11:59:59','POEBTC','4h','0.000001540000000','0.000001540000000','0.001467500000000','0.001467500000000','952.922077922078','952.922077922077960','test'),('2018-09-01 11:59:59','2018-09-02 11:59:59','POEBTC','4h','0.000001570000000','0.000001500000000','0.001467500000000','0.001402070063694','934.7133757961784','934.713375796178411','test'),('2018-09-02 15:59:59','2018-09-02 19:59:59','POEBTC','4h','0.000001520000000','0.000001520000000','0.001467500000000','0.001467500000000','965.4605263157895','965.460526315789480','test'),('2018-09-04 07:59:59','2018-09-05 11:59:59','POEBTC','4h','0.000001540000000','0.000001430000000','0.001467500000000','0.001362678571429','952.922077922078','952.922077922077960','test'),('2018-09-16 19:59:59','2018-09-17 15:59:59','POEBTC','4h','0.000001390000000','0.000001340000000','0.001467500000000','0.001414712230216','1055.7553956834533','1055.755395683453344','test'),('2018-09-18 07:59:59','2018-09-18 11:59:59','POEBTC','4h','0.000001330000000','0.000001300000000','0.001467500000000','0.001434398496241','1103.3834586466166','1103.383458646616646','test'),('2018-09-18 19:59:59','2018-09-19 11:59:59','POEBTC','4h','0.000001390000000','0.000001340000000','0.001467500000000','0.001414712230216','1055.7553956834533','1055.755395683453344','test'),('2018-09-19 19:59:59','2018-09-21 15:59:59','POEBTC','4h','0.000001350000000','0.000001330000000','0.001467500000000','0.001445759259259','1087.0370370370372','1087.037037037037180','test'),('2018-09-21 19:59:59','2018-09-22 07:59:59','POEBTC','4h','0.000001400000000','0.000001360000000','0.001467500000000','0.001425571428571','1048.2142857142858','1048.214285714285779','test'),('2018-09-23 19:59:59','2018-09-24 11:59:59','POEBTC','4h','0.000001400000000','0.000001390000000','0.001467500000000','0.001457017857143','1048.2142857142858','1048.214285714285779','test'),('2018-09-24 15:59:59','2018-09-25 11:59:59','POEBTC','4h','0.000001480000000','0.000001830000000','0.001467500000000','0.001814543918919','991.5540540540541','991.554054054054063','test'),('2018-09-26 03:59:59','2018-09-27 15:59:59','POEBTC','4h','0.000001640000000','0.000001550000000','0.001467500000000','0.001386966463415','894.8170731707318','894.817073170731760','test'),('2018-09-30 15:59:59','2018-09-30 19:59:59','POEBTC','4h','0.000001570000000','0.000001540000000','0.001467500000000','0.001439458598726','934.7133757961784','934.713375796178411','test'),('2018-10-02 15:59:59','2018-10-03 03:59:59','POEBTC','4h','0.000001580000000','0.000001520000000','0.001467500000000','0.001411772151899','928.7974683544305','928.797468354430521','test'),('2018-10-04 23:59:59','2018-10-07 11:59:59','POEBTC','4h','0.000001570000000','0.000001570000000','0.001467500000000','0.001467500000000','934.7133757961784','934.713375796178411','test'),('2018-10-10 19:59:59','2018-10-11 03:59:59','POEBTC','4h','0.000001620000000','0.000001540000000','0.001467500000000','0.001395030864198','905.8641975308643','905.864197530864317','test'),('2018-10-17 15:59:59','2018-10-17 19:59:59','POEBTC','4h','0.000001550000000','0.000001640000000','0.001467500000000','0.001552709677419','946.7741935483872','946.774193548387188','test'),('2018-10-17 23:59:59','2018-10-20 15:59:59','POEBTC','4h','0.000001670000000','0.000001790000000','0.001467500000000','0.001572949101796','878.7425149700598','878.742514970059801','test'),('2018-10-21 15:59:59','2018-10-22 07:59:59','POEBTC','4h','0.000001880000000','0.000001760000000','0.001467500000000','0.001373829787234','780.5851063829788','780.585106382978779','test'),('2018-10-23 11:59:59','2018-10-25 15:59:59','POEBTC','4h','0.000001840000000','0.000001780000000','0.001467500000000','0.001419646739130','797.554347826087','797.554347826086996','test'),('2018-10-28 07:59:59','2018-10-30 19:59:59','POEBTC','4h','0.000001900000000','0.000001910000000','0.001467500000000','0.001475223684211','772.3684210526316','772.368421052631561','test'),('2018-10-31 07:59:59','2018-11-01 19:59:59','POEBTC','4h','0.000002030000000','0.000001960000000','0.001467500000000','0.001416896551724','722.9064039408867','722.906403940886662','test'),('2018-11-02 03:59:59','2018-11-04 19:59:59','POEBTC','4h','0.000002000000000','0.000001960000000','0.001467500000000','0.001438150000000','733.7500000000001','733.750000000000114','test'),('2018-11-29 15:59:59','2018-11-30 07:59:59','POEBTC','4h','0.000001510000000','0.000001460000000','0.001467500000000','0.001418907284768','971.8543046357617','971.854304635761650','test'),('2018-12-02 23:59:59','2018-12-03 03:59:59','POEBTC','4h','0.000001470000000','0.000001420000000','0.001467500000000','0.001417585034014','998.2993197278913','998.299319727891316','test'),('2018-12-05 11:59:59','2018-12-06 19:59:59','POEBTC','4h','0.000001560000000','0.000001530000000','0.001467500000000','0.001439278846154','940.7051282051282','940.705128205128176','test'),('2018-12-22 07:59:59','2018-12-22 15:59:59','POEBTC','4h','0.000001430000000','0.000001380000000','0.001467500000000','0.001416188811189','1026.2237762237762','1026.223776223776213','test'),('2018-12-22 23:59:59','2018-12-25 03:59:59','POEBTC','4h','0.000001390000000','0.000001370000000','0.001467500000000','0.001446384892086','1055.7553956834533','1055.755395683453344','test'),('2018-12-26 19:59:59','2018-12-27 03:59:59','POEBTC','4h','0.000001440000000','0.000001390000000','0.001467500000000','0.001416545138889','1019.0972222222223','1019.097222222222285','test'),('2018-12-27 07:59:59','2018-12-27 19:59:59','POEBTC','4h','0.000001410000000','0.000001370000000','0.001467500000000','0.001425868794326','1040.7801418439717','1040.780141843971705','test'),('2019-01-02 11:59:59','2019-01-02 23:59:59','POEBTC','4h','0.000001400000000','0.000001400000000','0.001467500000000','0.001467500000000','1048.2142857142858','1048.214285714285779','test'),('2019-01-03 03:59:59','2019-01-03 19:59:59','POEBTC','4h','0.000001410000000','0.000001390000000','0.001467500000000','0.001446684397163','1040.7801418439717','1040.780141843971705','test'),('2019-01-04 03:59:59','2019-01-04 07:59:59','POEBTC','4h','0.000001400000000','0.000001390000000','0.001467500000000','0.001457017857143','1048.2142857142858','1048.214285714285779','test'),('2019-01-05 07:59:59','2019-01-05 23:59:59','POEBTC','4h','0.000001410000000','0.000001390000000','0.001467500000000','0.001446684397163','1040.7801418439717','1040.780141843971705','test'),('2019-01-06 03:59:59','2019-01-06 19:59:59','POEBTC','4h','0.000001410000000','0.000001390000000','0.001467500000000','0.001446684397163','1040.7801418439717','1040.780141843971705','test'),('2019-01-06 23:59:59','2019-01-07 03:59:59','POEBTC','4h','0.000001400000000','0.000001400000000','0.001467500000000','0.001467500000000','1048.2142857142858','1048.214285714285779','test'),('2019-01-07 07:59:59','2019-01-07 11:59:59','POEBTC','4h','0.000001410000000','0.000001460000000','0.001467500000000','0.001519539007092','1040.7801418439717','1040.780141843971705','test'),('2019-01-07 23:59:59','2019-01-10 07:59:59','POEBTC','4h','0.000001460000000','0.000001430000000','0.001467500000000','0.001437345890411','1005.1369863013699','1005.136986301369916','test'),('2019-01-15 23:59:59','2019-01-16 23:59:59','POEBTC','4h','0.000001470000000','0.000001450000000','0.001467500000000','0.001447534013605','998.2993197278913','998.299319727891316','test'),('2019-01-17 03:59:59','2019-01-18 11:59:59','POEBTC','4h','0.000001460000000','0.000001450000000','0.001467500000000','0.001457448630137','1005.1369863013699','1005.136986301369916','test'),('2019-01-18 23:59:59','2019-01-20 15:59:59','POEBTC','4h','0.000001590000000','0.000001460000000','0.001467500000000','0.001347515723270','922.9559748427673','922.955974842767318','test'),('2019-01-22 23:59:59','2019-01-23 03:59:59','POEBTC','4h','0.000001500000000','0.000001480000000','0.001467500000000','0.001447933333333','978.3333333333334','978.333333333333371','test'),('2019-01-23 07:59:59','2019-01-23 11:59:59','POEBTC','4h','0.000001490000000','0.000001500000000','0.001467500000000','0.001477348993289','984.8993288590605','984.899328859060461','test'),('2019-01-23 19:59:59','2019-01-25 11:59:59','POEBTC','4h','0.000001510000000','0.000001500000000','0.001467500000000','0.001457781456954','971.8543046357617','971.854304635761650','test'),('2019-03-03 11:59:59','2019-03-04 07:59:59','POEBTC','4h','0.000001230000000','0.000001220000000','0.001467500000000','0.001455569105691','1193.0894308943089','1193.089430894308862','test'),('2019-03-04 19:59:59','2019-03-05 03:59:59','POEBTC','4h','0.000001220000000','0.000001220000000','0.001467500000000','0.001467500000000','1202.8688524590166','1202.868852459016580','test'),('2019-03-05 07:59:59','2019-03-05 15:59:59','POEBTC','4h','0.000001230000000','0.000001220000000','0.001467500000000','0.001455569105691','1193.0894308943089','1193.089430894308862','test'),('2019-03-10 23:59:59','2019-03-11 11:59:59','POEBTC','4h','0.000001240000000','0.000001210000000','0.001467500000000','0.001431995967742','1183.467741935484','1183.467741935483900','test'),('2019-03-11 15:59:59','2019-03-11 23:59:59','POEBTC','4h','0.000001230000000','0.000001250000000','0.001467500000000','0.001491361788618','1193.0894308943089','1193.089430894308862','test'),('2019-03-12 11:59:59','2019-03-16 07:59:59','POEBTC','4h','0.000001290000000','0.000001270000000','0.001467500000000','0.001444748062016','1137.5968992248063','1137.596899224806293','test'),('2019-03-22 15:59:59','2019-03-23 19:59:59','POEBTC','4h','0.000001320000000','0.000001250000000','0.001467500000000','0.001389678030303','1111.7424242424242','1111.742424242424249','test'),('2019-03-23 23:59:59','2019-03-24 03:59:59','POEBTC','4h','0.000001260000000','0.000001240000000','0.001467500000000','0.001444206349206','1164.6825396825398','1164.682539682539755','test'),('2019-03-25 23:59:59','2019-03-30 07:59:59','POEBTC','4h','0.000001300000000','0.000001370000000','0.001467500000000','0.001546519230769','1128.8461538461538','1128.846153846153811','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','POEBTC','4h','0.000001420000000','0.000001320000000','0.001467500000000','0.001364154929577','1033.4507042253522','1033.450704225352183','test'),('2019-04-21 07:59:59','2019-04-21 15:59:59','POEBTC','4h','0.000001220000000','0.000001220000000','0.001467500000000','0.001467500000000','1202.8688524590166','1202.868852459016580','test'),('2019-04-21 19:59:59','2019-04-22 23:59:59','POEBTC','4h','0.000001230000000','0.000001190000000','0.001467500000000','0.001419776422764','1193.0894308943089','1193.089430894308862','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 21:51:23
