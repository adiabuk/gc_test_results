-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-28 19:59:59','2018-04-01 15:59:59','EOSBTC','4h','0.000783890000000','0.000814000000000','0.001467500000000','0.001523868144765','1.8720738879179477','1.872073887917948','test'),('2018-04-05 03:59:59','2018-04-07 19:59:59','EOSBTC','4h','0.000834780000000','0.000848500000000','0.001481592036191','0.001505942694732','1.774829339695788','1.774829339695788','test'),('2018-04-09 15:59:59','2018-04-14 11:59:59','EOSBTC','4h','0.000866230000000','0.001049000000000','0.001487679700827','0.001801572337794','1.7174188158185473','1.717418815818547','test'),('2018-04-17 15:59:59','2018-04-30 19:59:59','EOSBTC','4h','0.001088500000000','0.001959200000000','0.001566152860068','0.002818931266371','1.4388175103980247','1.438817510398025','test'),('2018-05-02 03:59:59','2018-05-03 07:59:59','EOSBTC','4h','0.002074400000000','0.001913700000000','0.001879347461644','0.001733757827491','0.9059715877574238','0.905971587757424','test'),('2018-05-07 23:59:59','2018-05-11 07:59:59','EOSBTC','4h','0.001897800000000','0.001751100000000','0.001879347461644','0.001734073843442','0.9902768793571503','0.990276879357150','test'),('2018-05-26 07:59:59','2018-05-28 15:59:59','EOSBTC','4h','0.001666700000000','0.001658700000000','0.001879347461644','0.001870326774242','1.1275859252678946','1.127585925267895','test'),('2018-05-28 19:59:59','2018-05-28 23:59:59','EOSBTC','4h','0.001679700000000','0.001617400000000','0.001879347461644','0.001809642545968','1.118858999609454','1.118858999609454','test'),('2018-06-01 03:59:59','2018-06-01 07:59:59','EOSBTC','4h','0.001643500000000','0.001618100000000','0.001879347461644','0.001850302481099','1.1435031710641923','1.143503171064192','test'),('2018-06-02 07:59:59','2018-06-04 23:59:59','EOSBTC','4h','0.001665500000000','0.001798300000000','0.001879347461644','0.002029198763299','1.1283983558354846','1.128398355835485','test'),('2018-06-05 23:59:59','2018-06-06 23:59:59','EOSBTC','4h','0.001861600000000','0.001816400000000','0.001879347461644','0.001833716549920','1.0095334452320583','1.009533445232058','test'),('2018-06-07 19:59:59','2018-06-08 07:59:59','EOSBTC','4h','0.001871700000000','0.001830200000000','0.001879347461644','0.001837677899397','1.0040858372837527','1.004085837283753','test'),('2018-06-08 11:59:59','2018-06-10 03:59:59','EOSBTC','4h','0.001834700000000','0.001805000000000','0.001879347461644','0.001848924711543','1.0243350202452717','1.024335020245272','test'),('2018-07-05 03:59:59','2018-07-05 19:59:59','EOSBTC','4h','0.001362400000000','0.001337900000000','0.001879347461644','0.001845551210315','1.3794388297445683','1.379438829744568','test'),('2018-07-05 23:59:59','2018-07-06 07:59:59','EOSBTC','4h','0.001353100000000','0.001295100000000','0.001879347461644','0.001798790109804','1.3889198593186016','1.388919859318602','test'),('2018-08-06 19:59:59','2018-08-07 19:59:59','EOSBTC','4h','0.001008000000000','0.000993300000000','0.001879347461644','0.001851940311162','1.8644320055992063','1.864432005599206','test'),('2018-08-28 19:59:59','2018-09-03 03:59:59','EOSBTC','4h','0.000823500000000','0.000893900000000','0.001879347461644','0.002040010559761','2.282146280077717','2.282146280077717','test'),('2018-09-15 11:59:59','2018-09-17 15:59:59','EOSBTC','4h','0.000831800000000','0.000786700000000','0.001879347461644','0.001777449685111','2.2593742025054095','2.259374202505410','test'),('2018-09-20 07:59:59','2018-09-24 11:59:59','EOSBTC','4h','0.000817800000000','0.000857200000000','0.001879347461644','0.001969890736270','2.298052655470775','2.298052655470775','test'),('2018-09-27 19:59:59','2018-09-29 03:59:59','EOSBTC','4h','0.000882400000000','0.000861400000000','0.001879347461644','0.001834621377448','2.1298135331414323','2.129813533141432','test'),('2018-09-29 11:59:59','2018-09-30 07:59:59','EOSBTC','4h','0.000871800000000','0.000870500000000','0.001879347461644','0.001876545039414','2.155709407712778','2.155709407712778','test'),('2018-09-30 11:59:59','2018-09-30 23:59:59','EOSBTC','4h','0.000878800000000','0.000863200000000','0.001879347461644','0.001845986264100','2.1385383041010466','2.138538304101047','test'),('2018-10-04 19:59:59','2018-10-05 03:59:59','EOSBTC','4h','0.000880800000000','0.000870000000000','0.001879347461644','0.001856303691678','2.1336824042279745','2.133682404227975','test'),('2018-10-05 11:59:59','2018-10-06 15:59:59','EOSBTC','4h','0.000870500000000','0.000868800000000','0.001879347461644','0.001875677282799','2.158928732503159','2.158928732503159','test'),('2018-10-06 23:59:59','2018-10-07 11:59:59','EOSBTC','4h','0.000869100000000','0.000862600000000','0.001879347461644','0.001865291819600','2.1624064683511675','2.162406468351167','test'),('2018-10-08 11:59:59','2018-10-11 03:59:59','EOSBTC','4h','0.000873600000000','0.000858400000000','0.001879347461644','0.001846648192623','2.151267698768315','2.151267698768315','test'),('2018-10-28 15:59:59','2018-10-29 07:59:59','EOSBTC','4h','0.000836800000000','0.000835100000000','0.001879347461644','0.001875529475644','2.2458741176434036','2.245874117643404','test'),('2018-10-29 11:59:59','2018-10-29 15:59:59','EOSBTC','4h','0.000837500000000','0.000811400000000','0.001879347461644','0.001820779140750','2.243996969127164','2.243996969127164','test'),('2018-11-03 07:59:59','2018-11-03 23:59:59','EOSBTC','4h','0.000838000000000','0.000834600000000','0.001879347461644','0.001871722424210','2.2426580687875894','2.242658068787589','test'),('2018-11-04 07:59:59','2018-11-08 03:59:59','EOSBTC','4h','0.000847600000000','0.000849900000000','0.001879347461644','0.001884447153907','2.2172575054789996','2.217257505479000','test'),('2018-11-22 11:59:59','2018-11-22 15:59:59','EOSBTC','4h','0.000832100000000','0.000824400000000','0.001879347461644','0.001861956552553','2.258559622213676','2.258559622213676','test'),('2018-11-22 19:59:59','2018-11-22 23:59:59','EOSBTC','4h','0.000830100000000','0.000808900000000','0.001879347461644','0.001831350634531','2.264001278935068','2.264001278935068','test'),('2018-11-23 03:59:59','2018-11-23 07:59:59','EOSBTC','4h','0.000833900000000','0.000838400000000','0.001879347461644','0.001889489041662','2.253684448547787','2.253684448547787','test'),('2018-11-24 07:59:59','2018-11-24 11:59:59','EOSBTC','4h','0.000828900000000','0.000825000000000','0.001879347461644','0.001870505074021','2.2672788776016404','2.267278877601640','test'),('2018-11-24 15:59:59','2018-11-24 19:59:59','EOSBTC','4h','0.000833700000000','0.000818900000000','0.001879347461644','0.001845984930239','2.25422509493103','2.254225094931030','test'),('2018-11-24 23:59:59','2018-11-25 03:59:59','EOSBTC','4h','0.000840300000000','0.000835900000000','0.001879347461644','0.001869506775185','2.236519649701297','2.236519649701297','test'),('2018-11-25 11:59:59','2018-11-25 23:59:59','EOSBTC','4h','0.000845000000000','0.000833300000000','0.001879347461644','0.001853325727560','2.2240798362650884','2.224079836265088','test'),('2018-11-26 07:59:59','2018-11-26 15:59:59','EOSBTC','4h','0.000834400000000','0.000846500000000','0.001879347461644','0.001906600702639','2.2523339664956854','2.252333966495685','test'),('2018-11-26 23:59:59','2018-11-27 03:59:59','EOSBTC','4h','0.000842200000000','0.000828100000000','0.001879347461644','0.001847883677259','2.23147406986939','2.231474069869390','test'),('2018-12-17 03:59:59','2018-12-20 11:59:59','EOSBTC','4h','0.000594900000000','0.000657200000000','0.001879347461644','0.002076159273479','3.1590981032845855','3.159098103284586','test'),('2018-12-23 07:59:59','2018-12-25 11:59:59','EOSBTC','4h','0.000676800000000','0.000658700000000','0.001879347461644','0.001829087135025','2.77681362536052','2.776813625360520','test'),('2018-12-29 07:59:59','2018-12-31 11:59:59','EOSBTC','4h','0.000685900000000','0.000671800000000','0.001879347461644','0.001840713842736','2.739972972217524','2.739972972217524','test'),('2018-12-31 15:59:59','2019-01-03 19:59:59','EOSBTC','4h','0.000685300000000','0.000691000000000','0.001879347461644','0.001894978981462','2.7423718979191594','2.742371897919159','test'),('2019-01-03 23:59:59','2019-01-04 15:59:59','EOSBTC','4h','0.000699700000000','0.000702500000000','0.001879347461644','0.001886868074610','2.6859332022924107','2.685933202292411','test'),('2019-01-04 19:59:59','2019-01-05 07:59:59','EOSBTC','4h','0.000705300000000','0.000699800000000','0.001879347461644','0.001864692122017','2.664607204939742','2.664607204939742','test'),('2019-01-05 11:59:59','2019-01-06 03:59:59','EOSBTC','4h','0.000707900000000','0.000698200000000','0.001879347461644','0.001853595702387','2.654820541946602','2.654820541946602','test'),('2019-01-06 15:59:59','2019-01-07 03:59:59','EOSBTC','4h','0.000715100000000','0.000694000000000','0.001879347461644','0.001823894753714','2.6280904232191302','2.628090423219130','test'),('2019-01-09 23:59:59','2019-01-10 11:59:59','EOSBTC','4h','0.000721200000000','0.000677800000000','0.001879347461644','0.001766253063647','2.605861704997227','2.605861704997227','test'),('2019-01-18 07:59:59','2019-01-18 11:59:59','EOSBTC','4h','0.000686700000000','0.000676900000000','0.001879347461644','0.001852527008573','2.7367809256502107','2.736780925650211','test'),('2019-01-18 23:59:59','2019-01-19 07:59:59','EOSBTC','4h','0.000675700000000','0.000672400000000','0.001879347461644','0.001870169059064','2.7813341152049724','2.781334115204972','test'),('2019-01-23 11:59:59','2019-01-26 07:59:59','EOSBTC','4h','0.000682600000000','0.000676200000000','0.001879347461644','0.001861726858429','2.753219252335189','2.753219252335189','test'),('2019-01-26 11:59:59','2019-01-26 19:59:59','EOSBTC','4h','0.000678100000000','0.000677800000000','0.001879347461644','0.001878516014603','2.771490136622917','2.771490136622917','test'),('2019-02-01 15:59:59','2019-02-02 23:59:59','EOSBTC','4h','0.000672400000000','0.000695900000000','0.001879347461644','0.001945029593334','2.794984327251636','2.794984327251636','test'),('2019-02-03 23:59:59','2019-02-06 03:59:59','EOSBTC','4h','0.000685600000000','0.000679200000000','0.001879347461644','0.001861803961419','2.7411719102158694','2.741171910215869','test'),('2019-02-07 03:59:59','2019-02-14 11:59:59','EOSBTC','4h','0.000693000000000','0.000761100000000','0.001879347461644','0.002064027926490','2.711901099053391','2.711901099053391','test'),('2019-02-16 15:59:59','2019-02-24 19:59:59','EOSBTC','4h','0.000781100000000','0.000941900000000','0.001879347461644','0.002266236556296','2.4060267080322624','2.406026708032262','test'),('2019-03-06 07:59:59','2019-03-08 23:59:59','EOSBTC','4h','0.000971300000000','0.000928400000000','0.001879347461644','0.001796341175116','1.9348784738433027','1.934878473843303','test'),('2019-03-16 23:59:59','2019-03-18 03:59:59','EOSBTC','4h','0.000947900000000','0.000935700000000','0.001879347461644','0.001855159214960','1.9826431708450258','1.982643170845026','test'),('2019-03-26 23:59:59','2019-03-28 15:59:59','EOSBTC','4h','0.000948800000000','0.001065800000000','0.001879347461644','0.002111096674347','1.980762501732715','1.980762501732715','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  3:42:38
