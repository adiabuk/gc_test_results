-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-02 11:59:59','2018-07-05 11:59:59','BCDETH','4h','0.029640000000000','0.027190000000000','0.072144500000000','0.066181138832659','2.4340249662618083','2.434024966261808','test'),('2018-07-07 15:59:59','2018-07-12 23:59:59','BCDETH','4h','0.036890000000000','0.035780000000000','0.072144500000000','0.069973711303876','1.955665492003253','1.955665492003253','test'),('2018-07-15 15:59:59','2018-07-15 23:59:59','BCDETH','4h','0.036870000000000','0.035000000000000','0.072144500000000','0.068485421752102','1.9567263357743423','1.956726335774342','test'),('2018-07-19 03:59:59','2018-07-19 07:59:59','BCDETH','4h','0.036070000000000','0.034200000000000','0.072144500000000','0.068404266703632','2.0001247574161356','2.000124757416136','test'),('2018-07-19 15:59:59','2018-07-21 11:59:59','BCDETH','4h','0.036520000000000','0.037380000000000','0.072144500000000','0.073843412102957','1.9754791894852137','1.975479189485214','test'),('2018-07-21 19:59:59','2018-07-21 23:59:59','BCDETH','4h','0.036560000000000','0.036440000000000','0.072144500000000','0.071907701859956','1.9733178336980306','1.973317833698031','test'),('2018-07-23 07:59:59','2018-07-24 07:59:59','BCDETH','4h','0.037770000000000','0.036680000000000','0.072144500000000','0.070062490336246','1.9101006089489014','1.910100608948901','test'),('2018-07-24 11:59:59','2018-07-24 15:59:59','BCDETH','4h','0.036690000000000','0.039250000000000','0.072144500000000','0.077178294494413','1.96632597437994','1.966325974379940','test'),('2018-07-24 23:59:59','2018-07-28 07:59:59','BCDETH','4h','0.038890000000000','0.038630000000000','0.072144500000000','0.071662176266392','1.855091283106197','1.855091283106197','test'),('2018-08-13 23:59:59','2018-08-14 03:59:59','BCDETH','4h','0.034240000000000','0.033090000000000','0.072144500000000','0.069721422459112','2.107023948598131','2.107023948598131','test'),('2018-08-14 11:59:59','2018-08-15 23:59:59','BCDETH','4h','0.033970000000000','0.032710000000000','0.072144500000000','0.069468548572270','2.123770974389167','2.123770974389167','test'),('2018-08-17 11:59:59','2018-08-18 07:59:59','BCDETH','4h','0.035330000000000','0.032860000000000','0.072144500000000','0.067100715256156','2.0420181149165018','2.042018114916502','test'),('2018-08-18 11:59:59','2018-08-18 15:59:59','BCDETH','4h','0.033480000000000','0.033260000000000','0.072144500000000','0.071670432198327','2.154853643966547','2.154853643966547','test'),('2018-08-18 23:59:59','2018-08-19 19:59:59','BCDETH','4h','0.034870000000000','0.034500000000000','0.072144500000000','0.071378986234586','2.068956122741612','2.068956122741612','test'),('2018-08-19 23:59:59','2018-08-22 15:59:59','BCDETH','4h','0.034940000000000','0.035430000000000','0.072144500000000','0.073156257441328','2.064811104751002','2.064811104751002','test'),('2018-08-23 03:59:59','2018-08-26 11:59:59','BCDETH','4h','0.036120000000000','0.037250000000000','0.072144500000000','0.074401512320044','1.997356035437431','1.997356035437431','test'),('2018-08-27 03:59:59','2018-08-29 19:59:59','BCDETH','4h','0.037900000000000','0.037880000000000','0.072144500000000','0.072106429023747','1.9035488126649076','1.903548812664908','test'),('2018-08-30 07:59:59','2018-08-30 23:59:59','BCDETH','4h','0.039200000000000','0.037940000000000','0.072144500000000','0.069825569642857','1.840420918367347','1.840420918367347','test'),('2018-08-31 03:59:59','2018-09-01 03:59:59','BCDETH','4h','0.038730000000000','0.038000000000000','0.072144500000000','0.070784688871676','1.8627549703072552','1.862754970307255','test'),('2018-09-03 15:59:59','2018-09-05 11:59:59','BCDETH','4h','0.038390000000000','0.013100000000000','0.072144500000000','0.024618206564209','1.8792524094816359','1.879252409481636','test'),('2018-10-03 03:59:59','2018-10-05 11:59:59','BCDETH','4h','0.008830000000000','0.008720000000000','0.072144500000000','0.071245757644394','8.170385050962627','8.170385050962627','test'),('2018-10-14 23:59:59','2018-10-15 03:59:59','BCDETH','4h','0.008760000000000','0.008780000000000','0.072144500000000','0.072309213470320','8.235673515981734','8.235673515981734','test'),('2018-10-22 11:59:59','2018-10-25 11:59:59','BCDETH','4h','0.008790000000000','0.009240000000000','0.072144500000000','0.075837904436860','8.207565415244597','8.207565415244597','test'),('2018-11-24 03:59:59','2018-11-28 11:59:59','BCDETH','4h','0.008730000000000','0.009290000000000','0.072144500000000','0.076772325887743','8.26397479954181','8.263974799541810','test'),('2018-12-14 23:59:59','2018-12-16 19:59:59','BCDETH','4h','0.008740000000000','0.008350000000000','0.072144500000000','0.068925237414188','8.254519450800915','8.254519450800915','test'),('2018-12-16 23:59:59','2018-12-17 03:59:59','BCDETH','4h','0.008470000000000','0.008300000000000','0.072144500000000','0.070696499409681','8.517650531286895','8.517650531286895','test'),('2018-12-20 11:59:59','2018-12-22 03:59:59','BCDETH','4h','0.009630000000000','0.008520000000000','0.072144500000000','0.063828778816199','7.491640706126688','7.491640706126688','test'),('2019-01-11 11:59:59','2019-01-14 19:59:59','BCDETH','4h','0.006650000000000','0.006470000000000','0.048096333333333','0.046794477694235','7.232531328320802','7.232531328320802','test'),('2019-01-16 03:59:59','2019-01-16 11:59:59','BCDETH','4h','0.006750000000000','0.006640000000000','0.052730435919208','0.051871125111636','7.811916432475259','7.811916432475259','test'),('2019-01-16 15:59:59','2019-01-16 19:59:59','BCDETH','4h','0.006720000000000','0.006510000000000','0.052730435919208','0.051082609796733','7.846791059405952','7.846791059405952','test'),('2019-01-16 23:59:59','2019-01-17 15:59:59','BCDETH','4h','0.006590000000000','0.006530000000000','0.052730435919208','0.052250340903252','8.001583599272838','8.001583599272838','test'),('2019-01-20 07:59:59','2019-01-22 07:59:59','BCDETH','4h','0.006820000000000','0.006600000000000','0.052730435919208','0.051029454115363','7.731735472024634','7.731735472024634','test'),('2019-01-22 11:59:59','2019-01-22 15:59:59','BCDETH','4h','0.006670000000000','0.006630000000000','0.052730435919208','0.052414211415944','7.905612581590405','7.905612581590405','test'),('2019-01-24 11:59:59','2019-01-25 11:59:59','BCDETH','4h','0.006780000000000','0.006650000000000','0.052730435919208','0.051719380363235','7.777350430561652','7.777350430561652','test'),('2019-01-26 07:59:59','2019-01-26 15:59:59','BCDETH','4h','0.006750000000000','0.006690000000000','0.052730435919208','0.052261720933259','7.811916432475259','7.811916432475259','test'),('2019-01-26 19:59:59','2019-01-26 23:59:59','BCDETH','4h','0.006710000000000','0.006680000000000','0.052730435919208','0.052494681362192','7.858485233861103','7.858485233861103','test'),('2019-01-27 03:59:59','2019-01-27 11:59:59','BCDETH','4h','0.006730000000000','0.006650000000000','0.052730435919208','0.052103625388222','7.835131637326597','7.835131637326597','test'),('2019-01-27 23:59:59','2019-01-28 07:59:59','BCDETH','4h','0.006770000000000','0.006690000000000','0.052730435919208','0.052107328847785','7.78883839279291','7.788838392792910','test'),('2019-01-28 11:59:59','2019-01-28 15:59:59','BCDETH','4h','0.006750000000000','0.006770000000000','0.052730435919208','0.052886674247858','7.811916432475259','7.811916432475259','test'),('2019-01-28 23:59:59','2019-01-29 03:59:59','BCDETH','4h','0.006780000000000','0.006750000000000','0.052730435919208','0.052497115406291','7.777350430561652','7.777350430561652','test'),('2019-01-29 11:59:59','2019-01-29 19:59:59','BCDETH','4h','0.006770000000000','0.006780000000000','0.052730435919208','0.052808324303136','7.78883839279291','7.788838392792910','test'),('2019-01-29 23:59:59','2019-01-30 11:59:59','BCDETH','4h','0.006810000000000','0.006840000000000','0.052730435919208','0.052962728588456','7.743088974920411','7.743088974920411','test'),('2019-02-28 07:59:59','2019-02-28 11:59:59','BCDETH','4h','0.005500000000000','0.005380000000000','0.052730435919208','0.051579953680971','9.587351985310546','9.587351985310546','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','BCDETH','4h','0.005410000000000','0.005410000000000','0.052730435919208','0.052730435919208','9.746845826101294','9.746845826101294','test'),('2019-03-01 11:59:59','2019-03-01 15:59:59','BCDETH','4h','0.005440000000000','0.005400000000000','0.052730435919208','0.052342712125684','9.693094838089705','9.693094838089705','test'),('2019-03-02 03:59:59','2019-03-02 07:59:59','BCDETH','4h','0.005470000000000','0.005480000000000','0.052730435919208','0.052826835253612','9.639933440440219','9.639933440440219','test'),('2019-03-02 15:59:59','2019-03-03 07:59:59','BCDETH','4h','0.005490000000000','0.005430000000000','0.052730435919208','0.052154147002058','9.604815285830236','9.604815285830236','test'),('2019-03-03 11:59:59','2019-03-03 15:59:59','BCDETH','4h','0.005470000000000','0.005640000000000','0.052730435919208','0.054369224604083','9.639933440440219','9.639933440440219','test'),('2019-03-03 19:59:59','2019-03-05 15:59:59','BCDETH','4h','0.005680000000000','0.005520000000000','0.052730435919208','0.051245071527118','9.283527450564788','9.283527450564788','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','BCDETH','4h','0.005500000000000','0.005520000000000','0.052730435919208','0.052922182958914','9.587351985310546','9.587351985310546','test'),('2019-03-12 11:59:59','2019-03-15 23:59:59','BCDETH','4h','0.005530000000000','0.006340000000000','0.052730435919208','0.060454062156922','9.535341034214827','9.535341034214827','test'),('2019-03-16 03:59:59','2019-03-16 07:59:59','BCDETH','4h','0.006530000000000','0.006390000000000','0.052730435919208','0.051599921213436','8.07510504122634','8.075105041226340','test'),('2019-04-01 07:59:59','2019-04-02 11:59:59','BCDETH','4h','0.006240000000000','0.006200000000000','0.052730435919208','0.052392420304341','8.450390371667948','8.450390371667948','test'),('2019-04-03 03:59:59','2019-04-07 23:59:59','BCDETH','4h','0.006660000000000','0.007230000000000','0.052730435919208','0.057243401155537','7.917482870751952','7.917482870751952','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:50:58
