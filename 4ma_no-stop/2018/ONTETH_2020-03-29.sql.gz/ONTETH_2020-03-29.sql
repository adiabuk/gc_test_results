-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-25 15:59:59','2018-08-29 19:59:59','ONTETH','4h','0.008306000000000','0.008801000000000','0.072144500000000','0.076443985612810','8.685829520828317','8.685829520828317','test'),('2018-09-01 11:59:59','2018-09-02 03:59:59','ONTETH','4h','0.009022000000000','0.008585000000000','0.073219371403203','0.069672833462259','8.115647462115108','8.115647462115108','test'),('2018-09-07 15:59:59','2018-09-13 03:59:59','ONTETH','4h','0.009240000000000','0.009380000000000','0.073219371403203','0.074328755818403','7.924174394286039','7.924174394286039','test'),('2018-09-26 19:59:59','2018-09-26 23:59:59','ONTETH','4h','0.008530000000000','0.008516000000000','0.073219371403203','0.073099198929622','8.583748112919462','8.583748112919462','test'),('2018-09-27 07:59:59','2018-09-27 11:59:59','ONTETH','4h','0.008550000000000','0.008450000000000','0.073219371403203','0.072363004486206','8.563669169965264','8.563669169965264','test'),('2018-09-27 15:59:59','2018-09-27 19:59:59','ONTETH','4h','0.008524000000000','0.008397000000000','0.073219371403203','0.072128468051701','8.589790169310534','8.589790169310534','test'),('2018-09-28 03:59:59','2018-09-29 11:59:59','ONTETH','4h','0.008654000000000','0.008574000000000','0.073219371403203','0.072542511025082','8.46075472650832','8.460754726508320','test'),('2018-09-29 15:59:59','2018-09-29 19:59:59','ONTETH','4h','0.008581000000000','0.008597000000000','0.073219371403203','0.073355895111681','8.532731779886145','8.532731779886145','test'),('2018-10-02 11:59:59','2018-10-03 07:59:59','ONTETH','4h','0.008708000000000','0.008613000000000','0.073219371403203','0.072420584048666','8.40828794249001','8.408287942490009','test'),('2018-10-03 11:59:59','2018-10-03 15:59:59','ONTETH','4h','0.008723000000000','0.008698000000000','0.073219371403203','0.073009525675233','8.393829118789752','8.393829118789752','test'),('2018-10-03 23:59:59','2018-10-04 03:59:59','ONTETH','4h','0.008647000000000','0.008640000000000','0.073219371403203','0.073160098175515','8.467603955499364','8.467603955499364','test'),('2018-10-05 03:59:59','2018-10-05 07:59:59','ONTETH','4h','0.008686000000000','0.008666000000000','0.073219371403203','0.073050779712199','8.42958455021909','8.429584550219090','test'),('2018-10-08 11:59:59','2018-10-12 03:59:59','ONTETH','4h','0.009175000000000','0.008981000000000','0.073219371403203','0.071671190689064','7.980312959477166','7.980312959477166','test'),('2018-10-14 07:59:59','2018-10-14 23:59:59','ONTETH','4h','0.009114000000000','0.009177000000000','0.073219371403203','0.073725496090322','8.033725192363725','8.033725192363725','test'),('2018-10-18 15:59:59','2018-10-19 11:59:59','ONTETH','4h','0.009055000000000','0.008906000000000','0.073219371403203','0.072014546848915','8.086070834147211','8.086070834147211','test'),('2018-10-19 19:59:59','2018-10-19 23:59:59','ONTETH','4h','0.008979000000000','0.008917000000000','0.073219371403203','0.072713791602891','8.154512908252924','8.154512908252924','test'),('2018-10-20 23:59:59','2018-10-21 07:59:59','ONTETH','4h','0.008978000000000','0.008913000000000','0.073219371403203','0.072689269026147','8.155421185475943','8.155421185475943','test'),('2018-10-21 11:59:59','2018-10-21 15:59:59','ONTETH','4h','0.008956000000000','0.008930000000000','0.073219371403203','0.073006809583587','8.175454600625613','8.175454600625613','test'),('2018-10-21 19:59:59','2018-10-21 23:59:59','ONTETH','4h','0.008943000000000','0.008894000000000','0.073219371403203','0.072818191799182','8.187338857564912','8.187338857564912','test'),('2018-11-23 23:59:59','2018-11-25 11:59:59','ONTETH','4h','0.008033000000000','0.007523000000000','0.073219371403203','0.068570811784675','9.114822781426989','9.114822781426989','test'),('2018-12-18 19:59:59','2018-12-20 07:59:59','ONTETH','4h','0.006694000000000','0.006056000000000','0.073219371403203','0.066240889336390','10.938059665850464','10.938059665850464','test'),('2018-12-20 11:59:59','2018-12-20 15:59:59','ONTETH','4h','0.006124000000000','0.006043000000000','0.073219371403203','0.072250924459431','11.956135108295722','11.956135108295722','test'),('2018-12-21 19:59:59','2018-12-23 03:59:59','ONTETH','4h','0.006498000000000','0.005868000000000','0.073219371403203','0.066120540380732','11.267985749954294','11.267985749954294','test'),('2019-01-09 19:59:59','2019-01-14 15:59:59','ONTETH','4h','0.004742000000000','0.004712000000000','0.073219371403203','0.072756153110901','15.440609743400044','15.440609743400044','test'),('2019-01-16 07:59:59','2019-01-19 23:59:59','ONTETH','4h','0.004882000000000','0.004987000000000','0.073219371403203','0.074794142807819','14.99782290110672','14.997822901106719','test'),('2019-01-20 03:59:59','2019-01-20 15:59:59','ONTETH','4h','0.005028000000000','0.004960000000000','0.073219371403203','0.072229133285578','14.56232525918914','14.562325259189141','test'),('2019-01-22 11:59:59','2019-01-27 15:59:59','ONTETH','4h','0.005078000000000','0.005225000000000','0.073219371403203','0.075338955411921','14.418938834817448','14.418938834817448','test'),('2019-01-27 23:59:59','2019-01-29 11:59:59','ONTETH','4h','0.005351000000000','0.005184000000000','0.073219371403203','0.070934259270081','13.683306186358251','13.683306186358251','test'),('2019-02-15 19:59:59','2019-02-17 11:59:59','ONTETH','4h','0.005395000000000','0.005018000000000','0.073219371403203','0.068102837015991','13.571709249898612','13.571709249898612','test'),('2019-02-17 15:59:59','2019-02-17 23:59:59','ONTETH','4h','0.005055000000000','0.004829000000000','0.073219371403203','0.069945864392892','14.484544293413059','14.484544293413059','test'),('2019-02-21 15:59:59','2019-02-27 03:59:59','ONTETH','4h','0.005004000000000','0.006455000000000','0.073219371403203','0.094450647963165','14.632168545803959','14.632168545803959','test'),('2019-03-01 15:59:59','2019-03-02 19:59:59','ONTETH','4h','0.006782000000000','0.006648000000000','0.073219371403203','0.071772689632630','10.796132616219847','10.796132616219847','test'),('2019-03-03 19:59:59','2019-03-04 03:59:59','ONTETH','4h','0.006711000000000','0.006483000000000','0.073219371403203','0.070731811176720','10.910351870541351','10.910351870541351','test'),('2019-03-07 03:59:59','2019-03-10 11:59:59','ONTETH','4h','0.006647000000000','0.007068000000000','0.073219371403203','0.077856855284766','11.015401143854822','11.015401143854822','test'),('2019-03-12 19:59:59','2019-03-24 03:59:59','ONTETH','4h','0.007311000000000','0.008976000000000','0.073219371403203','0.089894279539755','10.014959841773083','10.014959841773083','test'),('2019-03-30 07:59:59','2019-04-02 07:59:59','ONTETH','4h','0.009093000000000','0.009100000000000','0.073295150723507','0.073351575011978','8.060612638678926','8.060612638678926','test'),('2019-04-02 11:59:59','2019-04-02 15:59:59','ONTETH','4h','0.009135000000000','0.009065000000000','0.073309256795625','0.072747500038570','8.02509652935142','8.025096529351419','test'),('2019-04-04 03:59:59','2019-04-06 19:59:59','ONTETH','4h','0.009367000000000','0.009408000000000','0.073309256795625','0.073630136429299','7.826332528624426','7.826332528624426','test'),('2019-05-14 19:59:59','2019-05-15 15:59:59','ONTETH','4h','0.006965000000000','0.006364000000000','0.073309256795625','0.066983504701702','10.525377860104092','10.525377860104092','test'),('2019-05-15 19:59:59','2019-05-15 23:59:59','ONTETH','4h','0.006443000000000','0.006403000000000','0.073309256795625','0.072854131811639','11.378124599662424','11.378124599662424','test'),('2019-05-30 11:59:59','2019-05-31 19:59:59','ONTETH','4h','0.005545000000000','0.005574000000000','0.073309256795625','0.073692659581391','13.22078571607304','13.220785716073040','test'),('2019-05-31 23:59:59','2019-06-01 07:59:59','ONTETH','4h','0.005687000000000','0.005597000000000','0.073309256795625','0.072149096234414','12.890672902343063','12.890672902343063','test'),('2019-06-02 07:59:59','2019-06-02 15:59:59','ONTETH','4h','0.005638000000000','0.005608000000000','0.073309256795625','0.072919175613669','13.00270606520486','13.002706065204860','test'),('2019-06-09 19:59:59','2019-06-12 19:59:59','ONTETH','4h','0.005572000000000','0.005582000000000','0.073309256795625','0.073440824018876','13.156722325130115','13.156722325130115','test'),('2019-07-20 15:59:59','2019-07-23 07:59:59','ONTETH','4h','0.004491000000000','0.004399000000000','0.073309256795625','0.071807486226665','16.323593140865064','16.323593140865064','test'),('2019-07-24 11:59:59','2019-07-27 23:59:59','ONTETH','4h','0.004541000000000','0.004718000000000','0.073309256795625','0.076166719568764','16.143857475363358','16.143857475363358','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 15:28:21
