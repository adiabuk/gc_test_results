-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-19 15:59:59','2018-04-19 23:59:59','YOYOETH','4h','0.000206160000000','0.000201710000000','0.072144500000000','0.070587248229530','349.9442180830423','349.944218083042301','test'),('2018-04-20 07:59:59','2018-04-20 11:59:59','YOYOETH','4h','0.000203870000000','0.000214780000000','0.072144500000000','0.076005276450679','353.87501839407463','353.875018394074630','test'),('2018-04-23 03:59:59','2018-04-23 19:59:59','YOYOETH','4h','0.000211190000000','0.000202850000000','0.072720381170052','0.069848616508097','344.3362904022551','344.336290402255088','test'),('2018-04-23 23:59:59','2018-04-24 03:59:59','YOYOETH','4h','0.000204560000000','0.000199470000000','0.072720381170052','0.070910903558810','355.49658374096595','355.496583740965946','test'),('2018-04-30 15:59:59','2018-05-03 23:59:59','YOYOETH','4h','0.000213310000000','0.000247620000000','0.072720381170052','0.084417143056248','340.9140742114856','340.914074211485627','test'),('2018-06-02 03:59:59','2018-06-03 11:59:59','YOYOETH','4h','0.000175710000000','0.000169620000000','0.074474261073302','0.071893029214350','423.8475958869842','423.847595886984209','test'),('2018-07-04 11:59:59','2018-07-05 15:59:59','YOYOETH','4h','0.000140400000000','0.000135750000000','0.074474261073302','0.072007699007840','530.4434549380485','530.443454938048490','test'),('2018-07-19 03:59:59','2018-07-19 23:59:59','YOYOETH','4h','0.000129190000000','0.000127010000000','0.074474261073302','0.073217554755942','576.4707877800295','576.470787780029468','test'),('2018-08-17 19:59:59','2018-08-18 15:59:59','YOYOETH','4h','0.000085450000000','0.000082000000000','0.074474261073302','0.071467400912940','871.5536696700059','871.553669670005888','test'),('2018-08-18 19:59:59','2018-08-24 03:59:59','YOYOETH','4h','0.000082560000000','0.000102780000000','0.074474261073302','0.092713960187912','902.0622707522045','902.062270752204540','test'),('2018-09-05 03:59:59','2018-09-05 11:59:59','YOYOETH','4h','0.000099000000000','0.000093560000000','0.076706345751420','0.072491370792958','774.8115732466716','774.811573246671628','test'),('2018-09-05 15:59:59','2018-09-06 03:59:59','YOYOETH','4h','0.000095080000000','0.000092440000000','0.076706345751420','0.074576510320375','806.755845092764','806.755845092764048','test'),('2018-09-06 07:59:59','2018-09-06 11:59:59','YOYOETH','4h','0.000094040000000','0.000092380000000','0.076706345751420','0.075352320507403','815.6778578415568','815.677857841556829','test'),('2018-09-06 23:59:59','2018-09-07 03:59:59','YOYOETH','4h','0.000094870000000','0.000095440000000','0.076706345751420','0.077167214488411','808.5416438433646','808.541643843364568','test'),('2018-09-07 07:59:59','2018-09-09 11:59:59','YOYOETH','4h','0.000097410000000','0.000099710000000','0.076706345751420','0.078517500614661','787.4586361915615','787.458636191561482','test'),('2018-09-09 19:59:59','2018-09-13 11:59:59','YOYOETH','4h','0.000099320000000','0.000103020000000','0.076706345751420','0.079563911994677','772.3152008801852','772.315200880185216','test'),('2018-09-16 23:59:59','2018-09-21 07:59:59','YOYOETH','4h','0.000109830000000','0.000110380000000','0.076706345751420','0.077090471128487','698.4097764856597','698.409776485659677','test'),('2018-09-23 15:59:59','2018-09-24 03:59:59','YOYOETH','4h','0.000115580000000','0.000110050000000','0.076706345751420','0.073036280930470','663.6645245840111','663.664524584011133','test'),('2018-09-24 07:59:59','2018-09-25 03:59:59','YOYOETH','4h','0.000114660000000','0.000113400000000','0.076706345751420','0.075863418875031','668.9895844358974','668.989584435897427','test'),('2018-09-25 11:59:59','2018-09-29 07:59:59','YOYOETH','4h','0.000112480000000','0.000118100000000','0.076706345751420','0.080538935217307','681.9554209763514','681.955420976351434','test'),('2018-10-02 11:59:59','2018-10-10 03:59:59','YOYOETH','4h','0.000121730000000','0.000145240000000','0.076706345751420','0.091520821957909','630.1351002334676','630.135100233467597','test'),('2018-10-13 23:59:59','2018-10-15 07:59:59','YOYOETH','4h','0.000151670000000','0.000137180000000','0.079693584141938','0.072079949051171','525.440654987392','525.440654987392008','test'),('2018-10-17 15:59:59','2018-10-18 23:59:59','YOYOETH','4h','0.000154450000000','0.000146500000000','0.079693584141938','0.075591518787918','515.9830633987569','515.983063398756940','test'),('2018-10-19 03:59:59','2018-10-19 05:59:59','YOYOETH','4h','0.000147000000000','0.000147000000000','0.079693584141938','0.079693584141938','542.1332254553606','542.133225455360616','test'),('2018-10-20 15:59:59','2018-10-27 23:59:59','YOYOETH','4h','0.000153130000000','0.000159090000000','0.079693584141938','0.082795352322477','520.4309027750147','520.430902775014715','test'),('2018-10-29 07:59:59','2018-10-29 15:59:59','YOYOETH','4h','0.000171730000000','0.000168020000000','0.079693584141938','0.077971909436490','464.06326292399694','464.063262923996945','test'),('2018-10-29 19:59:59','2018-10-30 11:59:59','YOYOETH','4h','0.000171030000000','0.000165100000000','0.079693584141938','0.076930425900918','465.9626038819973','465.962603881997325','test'),('2018-10-30 15:59:59','2018-11-02 23:59:59','YOYOETH','4h','0.000168500000000','0.000199850000000','0.079693584141938','0.094520847422945','472.95895633197625','472.958956331976253','test'),('2018-11-03 07:59:59','2018-11-03 19:59:59','YOYOETH','4h','0.000195130000000','0.000198010000000','0.080125708659510','0.081308315336799','410.62731850310297','410.627318503102970','test'),('2018-11-19 11:59:59','2018-11-19 23:59:59','YOYOETH','4h','0.000173280000000','0.000157100000000','0.080421360328833','0.072912025090372','464.1121902633468','464.112190263346804','test'),('2018-11-28 19:59:59','2018-11-30 11:59:59','YOYOETH','4h','0.000157700000000','0.000148410000000','0.080421360328833','0.075683792558035','509.9642379761128','509.964237976112827','test'),('2018-12-01 15:59:59','2018-12-04 07:59:59','YOYOETH','4h','0.000159130000000','0.000156370000000','0.080421360328833','0.079026507350089','505.3815140377867','505.381514037786701','test'),('2018-12-04 15:59:59','2018-12-04 19:59:59','YOYOETH','4h','0.000158120000000','0.000155380000000','0.080421360328833','0.079027769845017','508.6096656263154','508.609665626315405','test'),('2019-01-10 07:59:59','2019-01-10 19:59:59','YOYOETH','4h','0.000102900000000','0.000100800000000','0.080421360328833','0.078780108077224','781.5486912423032','781.548691242303221','test'),('2019-01-11 07:59:59','2019-01-14 19:59:59','YOYOETH','4h','0.000100120000000','0.000104080000000','0.080421360328833','0.083602229155263','803.2497036439572','803.249703643957218','test'),('2019-01-14 23:59:59','2019-01-15 03:59:59','YOYOETH','4h','0.000106190000000','0.000104800000000','0.080421360328833','0.079368665245896','757.3345920409926','757.334592040992561','test'),('2019-01-15 15:59:59','2019-01-20 15:59:59','YOYOETH','4h','0.000116360000000','0.000121400000000','0.080421360328833','0.083904719353045','691.142663534144','691.142663534144049','test'),('2019-01-20 23:59:59','2019-01-25 03:59:59','YOYOETH','4h','0.000128100000000','0.000137850000000','0.080421360328833','0.086542424054095','627.8014077192272','627.801407719227200','test'),('2019-01-26 15:59:59','2019-01-27 07:59:59','YOYOETH','4h','0.000143070000000','0.000136570000000','0.080421360328833','0.076767632488353','562.111975458398','562.111975458397978','test'),('2019-02-20 19:59:59','2019-02-21 23:59:59','YOYOETH','4h','0.000155000000000','0.000120720000000','0.080421360328833','0.062635268509011','518.847485992471','518.847485992470979','test'),('2019-03-01 19:59:59','2019-03-02 07:59:59','YOYOETH','4h','0.000125000000000','0.000121590000000','0.080421360328833','0.078227465619062','643.370882630664','643.370882630664028','test'),('2019-03-02 11:59:59','2019-03-06 11:59:59','YOYOETH','4h','0.000122510000000','0.000127950000000','0.080421360328833','0.083992433712139','656.4473131077708','656.447313107770810','test'),('2019-03-10 11:59:59','2019-03-14 23:59:59','YOYOETH','4h','0.000133370000000','0.000143160000000','0.080421360328833','0.086324675299361','602.9943790120192','602.994379012019181','test'),('2019-03-15 03:59:59','2019-03-18 11:59:59','YOYOETH','4h','0.000143780000000','0.000147540000000','0.080421360328833','0.082524464479872','559.3362103827584','559.336210382758395','test'),('2019-03-26 15:59:59','2019-03-29 19:59:59','YOYOETH','4h','0.000161040000000','0.000152410000000','0.080421360328833','0.076111646346979','499.38748341302164','499.387483413021641','test'),('2019-03-31 11:59:59','2019-04-02 19:59:59','YOYOETH','4h','0.000157210000000','0.000153990000000','0.080421360328833','0.078774157350277','511.5537200485529','511.553720048552918','test'),('2019-04-05 19:59:59','2019-04-06 03:59:59','YOYOETH','4h','0.000157000000000','0.000155710000000','0.080421360328833','0.079760573355430','512.2379638779172','512.237963877917196','test'),('2019-04-06 11:59:59','2019-04-06 15:59:59','YOYOETH','4h','0.000155150000000','0.000153320000000','0.080421360328833','0.079472787403266','518.3458609657299','518.345860965729912','test'),('2019-04-07 15:59:59','2019-04-07 23:59:59','YOYOETH','4h','0.000159240000000','0.000154900000000','0.080421360328833','0.078229519686864','505.0324059836285','505.032405983628507','test'),('2019-04-15 19:59:59','2019-04-16 07:59:59','YOYOETH','4h','0.000199640000000','0.000150600000000','0.080421360328833','0.060666483998809','402.8318990624774','402.831899062477419','test'),('2019-04-16 19:59:59','2019-04-17 03:59:59','YOYOETH','4h','0.000151050000000','0.000146650000000','0.080421360328833','0.078078732156394','532.4154937360674','532.415493736067447','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 12:05:17
