-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-12-18 03:59:59','2018-12-22 15:59:59','EOSUSDT','4h','2.519100000000000','2.525800000000000','15.000000000000000','15.039895200666905','5.954507562224604','5.954507562224604','test'),('2018-12-23 03:59:59','2018-12-25 03:59:59','EOSUSDT','4h','2.686000000000000','2.505600000000000','15.009973800166726','14.001857912769079','5.58822553989826','5.588225539898260','test'),('2018-12-29 07:59:59','2018-12-30 03:59:59','EOSUSDT','4h','2.648200000000000','2.526600000000000','15.009973800166726','14.320746093007044','5.667991012826344','5.667991012826344','test'),('2018-12-30 07:59:59','2018-12-31 11:59:59','EOSUSDT','4h','2.541900000000000','2.500900000000000','15.009973800166726','14.767867924323131','5.9050213620389185','5.905021362038918','test'),('2018-12-31 15:59:59','2018-12-31 19:59:59','EOSUSDT','4h','2.571300000000000','2.519700000000000','15.009973800166726','14.708758598483296','5.837503908593601','5.837503908593601','test'),('2019-01-01 11:59:59','2019-01-01 15:59:59','EOSUSDT','4h','2.570800000000000','2.546300000000000','15.009973800166726','14.866927138386702','5.838639256327495','5.838639256327495','test'),('2019-01-01 19:59:59','2019-01-03 19:59:59','EOSUSDT','4h','2.568600000000000','2.595500000000000','15.009973800166726','15.167167717173843','5.8436400374393545','5.843640037439354','test'),('2019-01-03 23:59:59','2019-01-04 03:59:59','EOSUSDT','4h','2.637900000000000','2.674600000000000','15.009973800166726','15.218801291150507','5.690122370130303','5.690122370130303','test'),('2019-01-04 07:59:59','2019-01-04 15:59:59','EOSUSDT','4h','2.702300000000000','2.616900000000000','15.009973800166726','14.535617969010215','5.554517929233144','5.554517929233144','test'),('2019-01-05 03:59:59','2019-01-06 03:59:59','EOSUSDT','4h','2.713900000000000','2.635700000000000','15.009973800166726','14.577467093518345','5.530776299851404','5.530776299851404','test'),('2019-01-06 11:59:59','2019-01-10 07:59:59','EOSUSDT','4h','2.692300000000000','2.659100000000000','15.009973800166726','14.824878851548247','5.5751490547735125','5.575149054773513','test'),('2019-01-25 07:59:59','2019-01-25 11:59:59','EOSUSDT','4h','2.439000000000000','2.423800000000000','15.009973800166726','14.916430708013165','6.154150799576353','6.154150799576353','test'),('2019-01-25 15:59:59','2019-01-25 19:59:59','EOSUSDT','4h','2.432600000000000','2.419200000000000','15.009973800166726','14.927291218187678','6.170341938734986','6.170341938734986','test'),('2019-01-25 23:59:59','2019-01-26 15:59:59','EOSUSDT','4h','2.428500000000000','2.420200000000000','15.009973800166726','14.958673498523167','6.180759234163774','6.180759234163774','test'),('2019-02-03 23:59:59','2019-02-05 15:59:59','EOSUSDT','4h','2.370700000000000','2.377700000000000','15.009973800166726','15.054293965772313','6.331452229369692','6.331452229369692','test'),('2019-02-05 19:59:59','2019-02-06 03:59:59','EOSUSDT','4h','2.382200000000000','2.325700000000000','15.009973800166726','14.653973665959095','6.300887331108524','6.300887331108524','test'),('2019-02-08 11:59:59','2019-02-14 11:59:59','EOSUSDT','4h','2.428500000000000','2.730200000000000','15.009973800166726','16.874708861113938','6.180759234163774','6.180759234163774','test'),('2019-02-16 11:59:59','2019-02-24 15:59:59','EOSUSDT','4h','2.812500000000000','3.570400000000000','15.009973800166726','19.054794828840986','5.336879573392614','5.336879573392614','test'),('2019-03-06 07:59:59','2019-03-08 23:59:59','EOSUSDT','4h','3.739300000000000','3.589700000000000','15.575149483403328','14.952026876841368','4.165258065253744','4.165258065253744','test'),('2019-03-09 07:59:59','2019-03-10 15:59:59','EOSUSDT','4h','3.753600000000000','3.685900000000000','15.575149483403328','15.294235795203624','4.149389781384092','4.149389781384092','test'),('2019-03-15 19:59:59','2019-03-18 15:59:59','EOSUSDT','4h','3.699100000000000','3.705600000000000','15.575149483403328','15.602517889675699','4.210524041902984','4.210524041902984','test'),('2019-03-27 03:59:59','2019-03-30 23:59:59','EOSUSDT','4h','4.036000000000000','4.150200000000000','15.575149483403328','16.015853663533324','3.859055868038486','3.859055868038486','test'),('2019-04-01 23:59:59','2019-04-02 03:59:59','EOSUSDT','4h','4.204300000000000','4.182900000000000','15.575149483403328','15.495871553915700','3.704576144281647','3.704576144281647','test'),('2019-04-02 07:59:59','2019-04-11 11:59:59','EOSUSDT','4h','4.533900000000000','5.246600000000000','15.575149483403328','18.023463084678511','3.435265330819676','3.435265330819676','test'),('2019-04-15 15:59:59','2019-04-15 19:59:59','EOSUSDT','4h','5.484400000000000','5.269100000000000','16.058417474260391','15.428015373354501','2.9280171895303755','2.928017189530375','test'),('2019-04-15 23:59:59','2019-04-16 03:59:59','EOSUSDT','4h','5.323400000000000','5.341200000000000','16.058417474260391','16.112112449472068','3.016571641105382','3.016571641105382','test'),('2019-04-16 11:59:59','2019-04-16 15:59:59','EOSUSDT','4h','5.383300000000000','5.366300000000000','16.058417474260391','16.007706368235752','2.9830062367433343','2.983006236743334','test'),('2019-04-16 19:59:59','2019-04-19 03:59:59','EOSUSDT','4h','5.452900000000000','5.401800000000000','16.058417474260391','15.907931469944394','2.9449315913111174','2.944931591311117','test'),('2019-04-19 07:59:59','2019-04-20 15:59:59','EOSUSDT','4h','5.441400000000000','5.422400000000000','16.058417474260391','16.002345519981905','2.951155488341308','2.951155488341308','test'),('2019-05-03 23:59:59','2019-05-04 15:59:59','EOSUSDT','4h','5.084100000000000','4.847800000000000','16.058417474260391','15.312050555992117','3.158556573289351','3.158556573289351','test'),('2019-05-04 19:59:59','2019-05-04 23:59:59','EOSUSDT','4h','4.859800000000000','4.947200000000000','16.058417474260391','16.347216537442076','3.3043371073419463','3.304337107341946','test'),('2019-05-05 15:59:59','2019-05-05 19:59:59','EOSUSDT','4h','4.888500000000000','4.909200000000000','16.058417474260391','16.126415682650940','3.284937603408079','3.284937603408079','test'),('2019-05-07 03:59:59','2019-05-07 15:59:59','EOSUSDT','4h','4.999100000000000','4.852100000000000','16.058417474260391','15.586215004072502','3.2122617019584307','3.212261701958431','test'),('2019-05-07 19:59:59','2019-05-07 23:59:59','EOSUSDT','4h','4.885000000000000','4.849200000000000','16.058417474260391','15.940732449576968','3.2872911922743895','3.287291192274389','test'),('2019-05-08 11:59:59','2019-05-08 15:59:59','EOSUSDT','4h','4.908600000000000','4.910000000000000','16.058417474260391','16.062997555029646','3.2714862637534923','3.271486263753492','test'),('2019-05-08 23:59:59','2019-05-09 07:59:59','EOSUSDT','4h','4.900000000000000','4.888100000000000','16.058417474260391','16.019418460394327','3.2772280559715083','3.277228055971508','test'),('2019-05-11 11:59:59','2019-05-17 11:59:59','EOSUSDT','4h','5.276000000000000','5.801400000000000','16.058417474260391','17.657563141617562','3.043672758578543','3.043672758578543','test'),('2019-05-19 07:59:59','2019-05-22 23:59:59','EOSUSDT','4h','6.312500000000000','5.928500000000000','16.058417474260391','15.081556910281620','2.5439077186947157','2.543907718694716','test'),('2019-05-24 15:59:59','2019-05-30 23:59:59','EOSUSDT','4h','6.392300000000000','7.300000000000000','16.058417474260391','18.338696175414306','2.5121501610156582','2.512150161015658','test'),('2019-05-31 23:59:59','2019-06-01 23:59:59','EOSUSDT','4h','8.564500000000001','7.702700000000000','16.322095359149095','14.679689873654938','1.9057849680832617','1.905784968083262','test'),('2019-06-15 19:59:59','2019-06-18 15:59:59','EOSUSDT','4h','6.884700000000000','6.857200000000000','16.322095359149095','16.256898963899253','2.3707780090852317','2.370778009085232','test'),('2019-06-21 07:59:59','2019-06-21 15:59:59','EOSUSDT','4h','6.997600000000000','6.909200000000000','16.322095359149095','16.115899916461775','2.3325276322094854','2.332527632209485','test'),('2019-06-21 19:59:59','2019-06-24 15:59:59','EOSUSDT','4h','6.974600000000000','7.161200000000000','16.322095359149095','16.758780329472447','2.340219562290181','2.340219562290181','test'),('2019-06-26 11:59:59','2019-06-26 23:59:59','EOSUSDT','4h','7.380200000000000','6.809600000000000','16.322095359149095','15.060152916948276','2.211606102700346','2.211606102700346','test'),('2019-07-25 11:59:59','2019-07-27 11:59:59','EOSUSDT','4h','4.590400000000000','4.358800000000000','16.322095359149095','15.498594730624580','3.5557021957017025','3.555702195701703','test'),('2019-08-05 19:59:59','2019-08-06 11:59:59','EOSUSDT','4h','4.505900000000000','4.335800000000000','16.322095359149095','15.705928018419995','3.622382955491488','3.622382955491488','test'),('2019-09-08 03:59:59','2019-09-11 15:59:59','EOSUSDT','4h','3.644500000000000','3.672200000000000','16.322095359149095','16.446151345278448','4.478555455933351','4.478555455933351','test'),('2019-09-14 15:59:59','2019-09-19 03:59:59','EOSUSDT','4h','3.936100000000000','3.887800000000000','16.322095359149095','16.121806442239741','4.146768466032137','4.146768466032137','test'),('2019-10-07 23:59:59','2019-10-10 11:59:59','EOSUSDT','4h','3.175900000000000','3.110000000000000','16.322095359149095','15.983411494994705','5.139360609323057','5.139360609323057','test'),('2019-10-10 15:59:59','2019-10-10 23:59:59','EOSUSDT','4h','3.113800000000000','3.105300000000000','16.322095359149095','16.277539571830463','5.24185733160418','5.241857331604180','test'),('2019-10-14 03:59:59','2019-10-14 19:59:59','EOSUSDT','4h','3.123800000000000','3.158800000000000','16.322095359149095','16.504973052205699','5.225076944474388','5.225076944474388','test'),('2019-10-14 23:59:59','2019-10-15 07:59:59','EOSUSDT','4h','3.163400000000000','3.113000000000000','16.322095359149095','16.062048066330888','5.159668508297748','5.159668508297748','test'),('2019-10-26 03:59:59','2019-10-30 15:59:59','EOSUSDT','4h','3.291700000000000','3.246300000000000','16.322095359149095','16.096976688156794','4.958561035072788','4.958561035072788','test'),('2019-11-01 23:59:59','2019-11-03 15:59:59','EOSUSDT','4h','3.341900000000000','3.273900000000000','16.322095359149095','15.989978155037022','4.884076531059905','4.884076531059905','test'),('2019-11-04 11:59:59','2019-11-07 15:59:59','EOSUSDT','4h','3.369100000000000','3.447100000000000','16.322095359149095','16.699977712897461','4.844645560876524','4.844645560876524','test'),('2019-11-10 07:59:59','2019-11-11 11:59:59','EOSUSDT','4h','3.544500000000000','3.460800000000000','16.322095359149095','15.936664584269483','4.604907704654844','4.604907704654844','test'),('2019-11-11 15:59:59','2019-11-11 19:59:59','EOSUSDT','4h','3.462600000000000','3.474200000000000','16.322095359149095','16.376775745611909','4.713826419207848','4.713826419207848','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  0:01:48
