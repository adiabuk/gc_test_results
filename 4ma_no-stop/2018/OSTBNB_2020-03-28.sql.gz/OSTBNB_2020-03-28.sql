-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-02 15:59:59','2018-07-06 07:59:59','OSTBNB','4h','0.005230000000000','0.005278000000000','0.711908500000000','0.718442268260038','136.12017208413002','136.120172084130019','test'),('2018-07-06 11:59:59','2018-07-06 15:59:59','OSTBNB','4h','0.005446000000000','0.005350000000000','0.713541942065010','0.700963898282740','131.02128939864295','131.021289398642949','test'),('2018-07-06 23:59:59','2018-07-07 11:59:59','OSTBNB','4h','0.005531000000000','0.005298000000000','0.713541942065010','0.683483133079086','129.00776388808714','129.007763888087140','test'),('2018-07-07 19:59:59','2018-07-09 23:59:59','OSTBNB','4h','0.005651000000000','0.005584000000000','0.713541942065010','0.705081968588040','126.26826085029376','126.268260850293757','test'),('2018-07-17 11:59:59','2018-07-17 15:59:59','OSTBNB','4h','0.005306000000000','0.005187000000000','0.713541942065010','0.697539022520016','134.47831550414813','134.478315504148128','test'),('2018-07-17 19:59:59','2018-07-20 03:59:59','OSTBNB','4h','0.005542000000000','0.005295000000000','0.713541942065010','0.681740271243996','128.75170372880007','128.751703728800067','test'),('2018-07-22 19:59:59','2018-07-23 03:59:59','OSTBNB','4h','0.005739000000000','0.005512000000000','0.713541942065010','0.685318554567405','124.33210351368008','124.332103513680082','test'),('2018-08-07 19:59:59','2018-08-08 03:59:59','OSTBNB','4h','0.005503000000000','0.004111000000000','0.713541942065010','0.533049413743278','129.66417264492276','129.664172644922758','test'),('2018-08-08 11:59:59','2018-08-08 15:59:59','OSTBNB','4h','0.003935000000000','0.003817000000000','0.713541942065010','0.692144750409693','181.33213267217533','181.332132672175334','test'),('2018-08-25 23:59:59','2018-08-26 07:59:59','OSTBNB','4h','0.002949000000000','0.002943000000000','0.713541942065010','0.712090178195091','241.9606449864395','241.960644986439490','test'),('2018-08-26 15:59:59','2018-08-27 15:59:59','OSTBNB','4h','0.002962000000000','0.002916000000000','0.713541942065010','0.702460601978923','240.89869752363606','240.898697523636059','test'),('2018-08-28 03:59:59','2018-08-30 19:59:59','OSTBNB','4h','0.003412000000000','0.003278000000000','0.713541942065010','0.685518899791648','209.12718114449297','209.127181144492965','test'),('2018-08-30 23:59:59','2018-09-01 11:59:59','OSTBNB','4h','0.003358000000000','0.003299000000000','0.713541942065010','0.701005022892337','212.49015546903217','212.490155469032175','test'),('2018-09-01 19:59:59','2018-09-02 11:59:59','OSTBNB','4h','0.003488000000000','0.003292000000000','0.713541942065010','0.673446121926036','204.57051091313357','204.570510913133575','test'),('2018-09-02 15:59:59','2018-09-03 11:59:59','OSTBNB','4h','0.003430000000000','0.003300000000000','0.713541942065010','0.686498078371584','208.02972071866182','208.029720718661821','test'),('2018-09-04 07:59:59','2018-09-05 11:59:59','OSTBNB','4h','0.003437000000000','0.003163000000000','0.713541942065010','0.656657888493345','207.6060349330841','207.606034933084089','test'),('2018-09-18 07:59:59','2018-09-19 23:59:59','OSTBNB','4h','0.003144000000000','0.003177000000000','0.713541942065010','0.721031409014166','226.95354391380724','226.953543913807238','test'),('2018-09-20 03:59:59','2018-09-21 15:59:59','OSTBNB','4h','0.003302000000000','0.003116000000000','0.713541942065010','0.673348483184304','216.09386495003332','216.093864950033321','test'),('2018-09-21 19:59:59','2018-09-24 15:59:59','OSTBNB','4h','0.003328000000000','0.003335000000000','0.713541942065010','0.715042781486421','214.40563163011117','214.405631630111174','test'),('2018-09-25 03:59:59','2018-09-28 07:59:59','OSTBNB','4h','0.005180000000000','0.004879000000000','0.713541942065010','0.672079369755827','137.74940966505986','137.749409665059858','test'),('2018-10-15 03:59:59','2018-10-19 03:59:59','OSTBNB','4h','0.004760000000000','0.004741000000000','0.713541942065010','0.710693770447524','149.90376934138865','149.903769341388653','test'),('2018-10-20 19:59:59','2018-10-22 03:59:59','OSTBNB','4h','0.004886000000000','0.004769000000000','0.713541942065010','0.696455489502258','146.03805609189726','146.038056091897261','test'),('2018-10-22 11:59:59','2018-10-25 07:59:59','OSTBNB','4h','0.004967000000000','0.004909000000000','0.713541942065010','0.705209863820643','143.65652145460237','143.656521454602370','test'),('2018-10-28 03:59:59','2018-10-29 15:59:59','OSTBNB','4h','0.005091000000000','0.005121000000000','0.713541942065010','0.717746667710649','140.15752152131407','140.157521521314067','test'),('2018-10-30 11:59:59','2018-11-02 11:59:59','OSTBNB','4h','0.005211000000000','0.005436000000000','0.713541942065010','0.744351179632584','136.92994474477257','136.929944744772570','test'),('2018-11-09 15:59:59','2018-11-10 07:59:59','OSTBNB','4h','0.005464000000000','0.005267000000000','0.713541942065010','0.687815777609152','130.58966728861822','130.589667288618216','test'),('2018-11-10 11:59:59','2018-11-11 11:59:59','OSTBNB','4h','0.005295000000000','0.005292000000000','0.713541942065010','0.713137669010016','134.75768499811332','134.757684998113319','test'),('2018-11-28 15:59:59','2018-12-04 03:59:59','OSTBNB','4h','0.004783000000000','0.004928000000000','0.713541942065010','0.735173466547432','149.1829274649822','149.182927464982214','test'),('2018-12-11 07:59:59','2018-12-11 23:59:59','OSTBNB','4h','0.005105000000000','0.004744000000000','0.713541942065010','0.663083834114869','139.7731522164564','139.773152216456396','test'),('2018-12-12 03:59:59','2018-12-12 11:59:59','OSTBNB','4h','0.004990000000000','0.004864000000000','0.713541942065010','0.695524650541926','142.9943771673367','142.994377167336694','test'),('2018-12-12 15:59:59','2018-12-13 07:59:59','OSTBNB','4h','0.004960000000000','0.004959000000000','0.713541942065010','0.713398082802497','143.85926251310684','143.859262513106842','test'),('2018-12-13 11:59:59','2018-12-13 15:59:59','OSTBNB','4h','0.004972000000000','0.004854000000000','0.713541942065010','0.696607519465720','143.51205592618865','143.512055926188651','test'),('2018-12-13 19:59:59','2018-12-14 03:59:59','OSTBNB','4h','0.005024000000000','0.005088000000000','0.713541942065010','0.722631648333354','142.0266604428762','142.026660442876192','test'),('2018-12-16 23:59:59','2018-12-17 07:59:59','OSTBNB','4h','0.004990000000000','0.005000000000000','0.713541942065010','0.714971885836683','142.9943771673367','142.994377167336694','test'),('2018-12-17 19:59:59','2018-12-17 23:59:59','OSTBNB','4h','0.005145000000000','0.004946000000000','0.713541942065010','0.685943332449667','138.68648047910787','138.686480479107871','test'),('2019-01-07 19:59:59','2019-01-07 23:59:59','OSTBNB','4h','0.004161000000000','0.004117000000000','0.713541942065010','0.705996677597127','171.48328336097333','171.483283360973331','test'),('2019-02-17 15:59:59','2019-02-18 03:59:59','OSTBNB','4h','0.002700000000000','0.002355000000000','0.713541942065010','0.622367138356703','264.2747933574111','264.274793357411113','test'),('2019-02-18 07:59:59','2019-02-18 15:59:59','OSTBNB','4h','0.002358000000000','0.002390000000000','0.475694628043340','0.482150195514666','201.7364834789398','201.736483478939789','test'),('2019-02-18 23:59:59','2019-02-19 03:59:59','OSTBNB','4h','0.002364000000000','0.002311000000000','0.520680480673436','0.509007018120267','220.25401043715573','220.254010437155728','test'),('2019-02-26 03:59:59','2019-02-27 23:59:59','OSTBNB','4h','0.002415000000000','0.002312000000000','0.520680480673436','0.498473404272043','215.60268350866914','215.602683508669145','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','OSTBNB','4h','0.001868000000000','0.001828000000000','0.520680480673436','0.509531005712549','278.736874022182','278.736874022182008','test'),('2019-03-21 19:59:59','2019-03-22 15:59:59','OSTBNB','4h','0.001830000000000','0.001858000000000','0.520680480673436','0.528647176552592','284.5248528270142','284.524852827014172','test'),('2019-03-22 23:59:59','2019-03-23 07:59:59','OSTBNB','4h','0.001849000000000','0.001784000000000','0.520680480673436','0.502376407529156','281.6011252966122','281.601125296612224','test'),('2019-03-28 15:59:59','2019-03-30 07:59:59','OSTBNB','4h','0.001793000000000','0.001764000000000','0.520680480673436','0.512258989351891','290.3962524670585','290.396252467058503','test'),('2019-05-08 23:59:59','2019-05-09 11:59:59','OSTBNB','4h','0.001050000000000','0.001015000000000','0.520680480673436','0.503324464650988','495.88617206993905','495.886172069939050','test'),('2019-05-09 15:59:59','2019-05-09 19:59:59','OSTBNB','4h','0.001027000000000','0.001011000000000','0.520680480673436','0.512568613399069','506.9917046479416','506.991704647941617','test'),('2019-05-09 23:59:59','2019-05-10 03:59:59','OSTBNB','4h','0.001026000000000','0.001032000000000','0.520680480673436','0.523725395765093','507.4858486095867','507.485848609586697','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','OSTBNB','4h','0.001033000000000','0.001028000000000','0.520680480673436','0.518160246013836','504.0469319200735','504.046931920073519','test'),('2019-05-10 15:59:59','2019-05-11 15:59:59','OSTBNB','4h','0.001068000000000','0.001010000000000','0.520680480673436','0.492403825355965','487.5285399564008','487.528539956400778','test'),('2019-05-28 07:59:59','2019-05-29 03:59:59','OSTBNB','4h','0.000829000000000','0.000988000000000','0.520680480673436','0.620545615084867','628.0826063612014','628.082606361201442','test'),('2019-05-29 23:59:59','2019-05-30 03:59:59','OSTBNB','4h','0.000892000000000','0.000857000000000','0.520680480673436','0.500250192754635','583.7225119657354','583.722511965735407','test'),('2019-05-30 07:59:59','2019-05-30 23:59:59','OSTBNB','4h','0.000877000000000','0.000844000000000','0.520680480673436','0.501088170682303','593.7063633676579','593.706363367657900','test'),('2019-06-03 15:59:59','2019-06-04 03:59:59','OSTBNB','4h','0.000868000000000','0.000861000000000','0.520680480673436','0.516481444538973','599.8623049233133','599.862304923313332','test'),('2019-06-04 07:59:59','2019-06-04 19:59:59','OSTBNB','4h','0.000875000000000','0.000819000000000','0.520680480673436','0.487356929910336','595.0634064839268','595.063406483926769','test'),('2019-06-05 11:59:59','2019-06-05 23:59:59','OSTBNB','4h','0.000910000000000','0.000848000000000','0.520680480673436','0.485205546825356','572.1763523883911','572.176352388391138','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:35:35
