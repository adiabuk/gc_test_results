-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-30 11:59:59','2018-07-06 03:59:59','ELFETH','4h','0.001309300000000','0.001525840000000','0.072144500000000','0.084076196349194','55.101580997479566','55.101580997479566','test'),('2018-07-17 19:59:59','2018-07-20 19:59:59','ELFETH','4h','0.001452720000000','0.001456230000000','0.075127424087298','0.075308943759738','51.71500639304099','51.715006393040987','test'),('2018-07-25 19:59:59','2018-07-26 23:59:59','ELFETH','4h','0.001512530000000','0.001463300000000','0.075172804005409','0.072726070954702','49.7000416556422','49.700041655642202','test'),('2018-07-27 07:59:59','2018-07-27 11:59:59','ELFETH','4h','0.001466200000000','0.001433030000000','0.075172804005409','0.073472161590418','51.27049788938003','51.270497889380032','test'),('2018-07-27 19:59:59','2018-07-28 03:59:59','ELFETH','4h','0.001492040000000','0.001449600000000','0.075172804005409','0.073034567897805','50.38256615466677','50.382566154666769','test'),('2018-07-28 07:59:59','2018-07-28 11:59:59','ELFETH','4h','0.001471340000000','0.001429690000000','0.075172804005409','0.073044847661651','51.091388805720634','51.091388805720634','test'),('2018-08-08 15:59:59','2018-08-10 11:59:59','ELFETH','4h','0.001366900000000','0.001317560000000','0.075172804005409','0.072459345705879','54.995101328121294','54.995101328121294','test'),('2018-08-10 23:59:59','2018-08-11 03:59:59','ELFETH','4h','0.001375260000000','0.001277620000000','0.075172804005409','0.069835724047373','54.660794326461186','54.660794326461186','test'),('2018-08-17 23:59:59','2018-08-18 07:59:59','ELFETH','4h','0.001469190000000','0.001292930000000','0.075172804005409','0.066154257436216','51.16615550433164','51.166155504331641','test'),('2018-08-18 11:59:59','2018-08-18 19:59:59','ELFETH','4h','0.001332740000000','0.001297240000000','0.075172804005409','0.073170437045468','56.40470309693489','56.404703096934888','test'),('2018-08-19 03:59:59','2018-08-20 23:59:59','ELFETH','4h','0.001297920000000','0.001305740000000','0.075172804005409','0.075625722002914','57.91790249430551','57.917902494305508','test'),('2018-08-24 11:59:59','2018-08-24 15:59:59','ELFETH','4h','0.001366300000000','0.001297870000000','0.075172804005409','0.071407836591159','55.0192519983964','55.019251998396399','test'),('2018-08-24 19:59:59','2018-08-29 15:59:59','ELFETH','4h','0.001310270000000','0.001404620000000','0.075172804005409','0.080585851742067','57.37199508911064','57.371995089110641','test'),('2018-09-01 11:59:59','2018-09-02 03:59:59','ELFETH','4h','0.001454650000000','0.001428390000000','0.075172804005409','0.073815750533315','51.677588427050495','51.677588427050495','test'),('2018-09-02 07:59:59','2018-09-13 03:59:59','ELFETH','4h','0.001488200000000','0.001673770000000','0.075172804005409','0.084546421287551','50.51256820683309','50.512568206833087','test'),('2018-09-27 07:59:59','2018-09-27 15:59:59','ELFETH','4h','0.001543120000000','0.001516860000000','0.075172804005409','0.073893552985928','48.714814146280915','48.714814146280915','test'),('2018-09-28 19:59:59','2018-09-29 11:59:59','ELFETH','4h','0.001540810000000','0.001458740000000','0.075172804005409','0.071168785323856','48.78784795361466','48.787847953614659','test'),('2018-10-02 07:59:59','2018-10-05 15:59:59','ELFETH','4h','0.001567780000000','0.001559210000000','0.075172804005409','0.074761884788219','47.94856676664392','47.948566766643921','test'),('2018-10-07 11:59:59','2018-10-08 07:59:59','ELFETH','4h','0.001580670000000','0.001550740000000','0.075172804005409','0.073749406317162','47.557557241808226','47.557557241808226','test'),('2018-10-08 11:59:59','2018-10-09 03:59:59','ELFETH','4h','0.001569390000000','0.001556990000000','0.075172804005409','0.074578851724799','47.89937746857633','47.899377468576333','test'),('2018-10-09 07:59:59','2018-10-09 15:59:59','ELFETH','4h','0.001567000000000','0.001539120000000','0.075172804005409','0.073835332546781','47.97243395367518','47.972433953675178','test'),('2018-10-10 19:59:59','2018-10-12 03:59:59','ELFETH','4h','0.001605180000000','0.001610480000000','0.075172804005409','0.075421010350634','46.83138589155671','46.831385891556707','test'),('2018-10-12 11:59:59','2018-10-12 19:59:59','ELFETH','4h','0.001621820000000','0.001585750000000','0.075172804005409','0.073500927323363','46.35089221085509','46.350892210855093','test'),('2018-10-13 03:59:59','2018-10-13 07:59:59','ELFETH','4h','0.001593780000000','0.001583210000000','0.075172804005409','0.074674255561874','47.166361734623976','47.166361734623976','test'),('2018-10-13 19:59:59','2018-10-15 07:59:59','ELFETH','4h','0.001608430000000','0.001546090000000','0.075172804005409','0.072259234498687','46.73675820856923','46.736758208569228','test'),('2018-10-19 03:59:59','2018-10-21 11:59:59','ELFETH','4h','0.001914540000000','0.001656440000000','0.075172804005409','0.065038724428176','39.26415953984195','39.264159539841948','test'),('2018-10-25 15:59:59','2018-10-26 11:59:59','ELFETH','4h','0.001651340000000','0.001641320000000','0.075172804005409','0.074716670504050','45.52230552485194','45.522305524851937','test'),('2018-10-26 15:59:59','2018-10-26 19:59:59','ELFETH','4h','0.001645560000000','0.001640660000000','0.075172804005409','0.074948961216555','45.68220180692835','45.682201806928347','test'),('2018-10-27 15:59:59','2018-10-28 15:59:59','ELFETH','4h','0.001657710000000','0.001638540000000','0.075172804005409','0.074303494745778','45.34737921916922','45.347379219169220','test'),('2018-11-29 23:59:59','2018-11-30 11:59:59','ELFETH','4h','0.001240820000000','0.001101520000000','0.075172804005409','0.066733568985057','60.583165975249436','60.583165975249436','test'),('2018-11-30 15:59:59','2018-12-04 03:59:59','ELFETH','4h','0.001122820000000','0.001129130000000','0.075172804005409','0.075595258533538','66.95000445789084','66.950004457890842','test'),('2018-12-06 11:59:59','2018-12-07 19:59:59','ELFETH','4h','0.001199350000000','0.001117210000000','0.075172804005409','0.070024436872375','62.677953896201274','62.677953896201274','test'),('2018-12-07 23:59:59','2018-12-08 03:59:59','ELFETH','4h','0.001158700000000','0.001160970000000','0.075172804005409','0.075320074450815','64.87684819660741','64.876848196607412','test'),('2018-12-09 11:59:59','2018-12-11 15:59:59','ELFETH','4h','0.001335060000000','0.001246150000000','0.075172804005409','0.070166576566851','56.306685845886335','56.306685845886335','test'),('2019-01-11 11:59:59','2019-01-14 15:59:59','ELFETH','4h','0.000847830000000','0.000815950000000','0.075172804005409','0.072346165420206','88.66494934763926','88.664949347639265','test'),('2019-01-16 03:59:59','2019-01-26 03:59:59','ELFETH','4h','0.000849740000000','0.000957230000000','0.075172804005409','0.084681977049565','88.46565302964319','88.465653029643192','test'),('2019-01-28 15:59:59','2019-01-30 15:59:59','ELFETH','4h','0.001028340000000','0.000956870000000','0.075172804005409','0.069948267079619','73.10111831243461','73.101118312434608','test'),('2019-01-30 19:59:59','2019-01-30 23:59:59','ELFETH','4h','0.000963450000000','0.000966010000000','0.075172804005409','0.075372546989740','78.0246032543557','78.024603254355696','test'),('2019-02-06 23:59:59','2019-02-08 19:59:59','ELFETH','4h','0.000959380000000','0.000939000000000','0.075172804005409','0.073575916697324','78.35560883634118','78.355608836341176','test'),('2019-02-16 03:59:59','2019-02-17 15:59:59','ELFETH','4h','0.001096450000000','0.000973420000000','0.075172804005409','0.066737845660947','68.56017511551735','68.560175115517353','test'),('2019-02-21 15:59:59','2019-02-21 23:59:59','ELFETH','4h','0.000947350000000','0.000933610000000','0.075172804005409','0.074082526571478','79.3506138232005','79.350613823200504','test'),('2019-02-23 07:59:59','2019-02-23 19:59:59','ELFETH','4h','0.000950970000000','0.000929040000000','0.075172804005409','0.073439269202167','79.0485546393777','79.048554639377699','test'),('2019-02-24 07:59:59','2019-02-24 15:59:59','ELFETH','4h','0.000946490000000','0.000927300000000','0.075172804005409','0.073648682135274','79.4227133994115','79.422713399411506','test'),('2019-02-24 19:59:59','2019-03-03 11:59:59','ELFETH','4h','0.000948880000000','0.001138630000000','0.075172804005409','0.090205305017156','79.22266672857369','79.222666728573685','test'),('2019-03-07 19:59:59','2019-03-14 15:59:59','ELFETH','4h','0.001158490000000','0.001269450000000','0.075172804005409','0.082372843999229','64.88860845187183','64.888608451871832','test'),('2019-03-21 03:59:59','2019-03-21 15:59:59','ELFETH','4h','0.001260000000000','0.001240460000000','0.075172804005409','0.074007028933770','59.66095555984841','59.660955559848411','test'),('2019-03-21 19:59:59','2019-03-23 19:59:59','ELFETH','4h','0.001257310000000','0.001244200000000','0.075172804005409','0.074388975466297','59.78859947459974','59.788599474599742','test'),('2019-03-24 11:59:59','2019-03-26 11:59:59','ELFETH','4h','0.001273820000000','0.001261950000000','0.075172804005409','0.074472311641069','59.01367854595548','59.013678545955479','test'),('2019-03-26 15:59:59','2019-03-29 23:59:59','ELFETH','4h','0.001274180000000','0.001285410000000','0.075172804005409','0.075835340373097','58.99700513695789','58.997005136957888','test'),('2019-04-01 11:59:59','2019-04-02 03:59:59','ELFETH','4h','0.001315440000000','0.001284560000000','0.075172804005409','0.073408119802643','57.146509156942926','57.146509156942926','test'),('2019-04-04 15:59:59','2019-04-06 19:59:59','ELFETH','4h','0.001448900000000','0.001330370000000','0.075172804005409','0.069023150848696','51.88267237587757','51.882672375877569','test'),('2019-04-07 03:59:59','2019-04-07 11:59:59','ELFETH','4h','0.001377040000000','0.001346820000000','0.075172804005409','0.073523090026844','54.590138271516444','54.590138271516444','test'),('2019-05-23 15:59:59','2019-05-26 15:59:59','ELFETH','4h','0.000923930000000','0.000940540000000','0.075172804005409','0.076524227029372','81.36201227951143','81.362012279511433','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:01:14
