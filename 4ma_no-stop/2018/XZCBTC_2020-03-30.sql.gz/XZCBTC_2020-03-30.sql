-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-05 11:59:59','2018-07-05 15:59:59','XZCBTC','4h','0.002587000000000','0.002539000000000','0.001467500000000','0.001440271550058','0.5672593737920372','0.567259373792037','test'),('2018-07-05 23:59:59','2018-07-06 03:59:59','XZCBTC','4h','0.002551000000000','0.002534000000000','0.001467500000000','0.001457720501764','0.575264602116817','0.575264602116817','test'),('2018-07-07 19:59:59','2018-07-10 19:59:59','XZCBTC','4h','0.002590000000000','0.002650000000000','0.001467500000000','0.001501496138996','0.5666023166023166','0.566602316602317','test'),('2018-08-07 11:59:59','2018-08-11 07:59:59','XZCBTC','4h','0.001950000000000','0.001971000000000','0.001467500000000','0.001483303846154','0.7525641025641027','0.752564102564103','test'),('2018-08-14 23:59:59','2018-08-16 15:59:59','XZCBTC','4h','0.002138000000000','0.002077000000000','0.001470698009243','0.001428737027688','0.687884943518709','0.687884943518709','test'),('2018-08-16 19:59:59','2018-08-16 23:59:59','XZCBTC','4h','0.002085000000000','0.002086000000000','0.001470698009243','0.001471403379991','0.7053707478383693','0.705370747838369','test'),('2018-08-17 03:59:59','2018-08-18 15:59:59','XZCBTC','4h','0.002166000000000','0.002083000000000','0.001470698009243','0.001414341622001','0.6789926173790397','0.678992617379040','test'),('2018-08-20 03:59:59','2018-08-21 03:59:59','XZCBTC','4h','0.002214000000000','0.002139000000000','0.001470698009243','0.001420877615976','0.6642719102271906','0.664271910227191','test'),('2018-09-29 03:59:59','2018-10-03 03:59:59','XZCBTC','4h','0.001540000000000','0.001496000000000','0.001470698009243','0.001428678066122','0.9549987073006494','0.954998707300649','test'),('2018-10-07 11:59:59','2018-10-09 15:59:59','XZCBTC','4h','0.001508000000000','0.001494000000000','0.001470698009243','0.001457044314197','0.9752639318587533','0.975263931858753','test'),('2018-10-09 19:59:59','2018-10-10 07:59:59','XZCBTC','4h','0.001506000000000','0.001497000000000','0.001470698009243','0.001461908977315','0.9765591030830013','0.976559103083001','test'),('2018-10-10 11:59:59','2018-10-11 03:59:59','XZCBTC','4h','0.001581000000000','0.001485000000000','0.001470698009243','0.001381395663331','0.9302327699196711','0.930232769919671','test'),('2018-10-17 11:59:59','2018-10-18 15:59:59','XZCBTC','4h','0.001526000000000','0.001479000000000','0.001470698009243','0.001425401281566','0.9637601633309305','0.963760163330931','test'),('2018-10-20 23:59:59','2018-10-22 03:59:59','XZCBTC','4h','0.001595000000000','0.001487000000000','0.001470698009243','0.001371114695764','0.9220677173937303','0.922067717393730','test'),('2018-10-22 19:59:59','2018-10-23 11:59:59','XZCBTC','4h','0.001550000000000','0.001490000000000','0.001470698009243','0.001413767763724','0.9488374253180645','0.948837425318064','test'),('2018-10-25 07:59:59','2018-10-29 19:59:59','XZCBTC','4h','0.001531000000000','0.001647000000000','0.001470698009243','0.001582129079832','0.9606126774937949','0.960612677493795','test'),('2018-11-10 03:59:59','2018-11-12 15:59:59','XZCBTC','4h','0.001649000000000','0.001627000000000','0.001470698009243','0.001451076810818','0.8918726556961795','0.891872655696179','test'),('2018-11-12 19:59:59','2018-11-12 23:59:59','XZCBTC','4h','0.001629000000000','0.001614000000000','0.001470698009243','0.001457155670300','0.9028225962203805','0.902822596220381','test'),('2018-11-13 15:59:59','2018-11-13 19:59:59','XZCBTC','4h','0.001647000000000','0.001622000000000','0.001470698009243','0.001448374117178','0.8929556826004856','0.892955682600486','test'),('2018-12-01 07:59:59','2018-12-05 23:59:59','XZCBTC','4h','0.001426000000000','0.001570000000000','0.001470698009243','0.001619211693206','1.0313450275196354','1.031345027519635','test'),('2018-12-23 03:59:59','2018-12-23 11:59:59','XZCBTC','4h','0.001393000000000','0.001376000000000','0.001470698009243','0.001452749792332','1.0557774653575018','1.055777465357502','test'),('2018-12-23 15:59:59','2018-12-23 19:59:59','XZCBTC','4h','0.001384000000000','0.001401000000000','0.001470698009243','0.001488762941437','1.062643070262283','1.062643070262283','test'),('2018-12-23 23:59:59','2018-12-25 23:59:59','XZCBTC','4h','0.001409000000000','0.001450000000000','0.001470698009243','0.001513493338114','1.0437885090440027','1.043788509044003','test'),('2018-12-26 03:59:59','2018-12-26 07:59:59','XZCBTC','4h','0.001487000000000','0.001463000000000','0.001470698009243','0.001446961121400','0.9890369934384666','0.989036993438467','test'),('2018-12-30 03:59:59','2018-12-31 07:59:59','XZCBTC','4h','0.001501000000000','0.001435000000000','0.001470698009243','0.001406030408570','0.9798121314077282','0.979812131407728','test'),('2018-12-31 11:59:59','2018-12-31 15:59:59','XZCBTC','4h','0.001443000000000','0.001409000000000','0.001470698009243','0.001436045388097','1.0191947396001384','1.019194739600138','test'),('2019-01-03 23:59:59','2019-01-04 03:59:59','XZCBTC','4h','0.001429000000000','0.001423000000000','0.001470698009243','0.001464522930128','1.0291798525143456','1.029179852514346','test'),('2019-01-08 23:59:59','2019-01-09 15:59:59','XZCBTC','4h','0.001466000000000','0.001420000000000','0.001470698009243','0.001424550595583','1.003204644776944','1.003204644776944','test'),('2019-01-17 23:59:59','2019-01-20 15:59:59','XZCBTC','4h','0.001447000000000','0.001424000000000','0.001470698009243','0.001447321330451','1.0163773387995854','1.016377338799585','test'),('2019-01-21 23:59:59','2019-01-22 07:59:59','XZCBTC','4h','0.001474000000000','0.001435000000000','0.001470698009243','0.001431785375349','0.9977598434484395','0.997759843448439','test'),('2019-01-22 15:59:59','2019-01-24 03:59:59','XZCBTC','4h','0.001482000000000','0.001440000000000','0.001470698009243','0.001429018308576','0.9923738254001349','0.992373825400135','test'),('2019-02-10 15:59:59','2019-02-11 23:59:59','XZCBTC','4h','0.001374000000000','0.001379000000000','0.001470698009243','0.001476049894284','1.0703770081826782','1.070377008182678','test'),('2019-02-12 11:59:59','2019-02-12 15:59:59','XZCBTC','4h','0.001368000000000','0.001363000000000','0.001470698009243','0.001465322651022','1.0750716441834793','1.075071644183479','test'),('2019-02-13 03:59:59','2019-02-13 15:59:59','XZCBTC','4h','0.001383000000000','0.001372000000000','0.001470698009243','0.001459000483501','1.0634114311229212','1.063411431122921','test'),('2019-02-13 23:59:59','2019-02-14 11:59:59','XZCBTC','4h','0.001383000000000','0.001358000000000','0.001470698009243','0.001444112723465','1.0634114311229212','1.063411431122921','test'),('2019-02-14 15:59:59','2019-02-14 23:59:59','XZCBTC','4h','0.001376000000000','0.001362000000000','0.001470698009243','0.001455734512056','1.068821227647529','1.068821227647529','test'),('2019-02-15 03:59:59','2019-02-15 19:59:59','XZCBTC','4h','0.001375000000000','0.001362000000000','0.001470698009243','0.001456793228065','1.0695985521767273','1.069598552176727','test'),('2019-02-15 23:59:59','2019-02-20 03:59:59','XZCBTC','4h','0.001384000000000','0.001382000000000','0.001470698009243','0.001468572723102','1.062643070262283','1.062643070262283','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','XZCBTC','4h','0.001391000000000','0.001389000000000','0.001470698009243','0.001468583418288','1.0572954775291157','1.057295477529116','test'),('2019-02-25 23:59:59','2019-02-26 07:59:59','XZCBTC','4h','0.001398000000000','0.001397000000000','0.001470698009243','0.001469646007806','1.0520014372267525','1.052001437226753','test'),('2019-02-26 11:59:59','2019-02-27 19:59:59','XZCBTC','4h','0.001404000000000','0.001399000000000','0.001470698009243','0.001465460480720','1.0475057045890313','1.047505704589031','test'),('2019-02-27 23:59:59','2019-02-28 03:59:59','XZCBTC','4h','0.001402000000000','0.001398000000000','0.001470698009243','0.001466502009217','1.0490000065927245','1.049000006592725','test'),('2019-02-28 07:59:59','2019-02-28 11:59:59','XZCBTC','4h','0.001410000000000','0.001405000000000','0.001470698009243','0.001465482768075','1.0430482335056737','1.043048233505674','test'),('2019-03-01 15:59:59','2019-03-02 15:59:59','XZCBTC','4h','0.001413000000000','0.001408000000000','0.001470698009243','0.001465493840774','1.0408336937317764','1.040833693731776','test'),('2019-03-02 23:59:59','2019-03-03 19:59:59','XZCBTC','4h','0.001413000000000','0.001413000000000','0.001470698009243','0.001470698009243','1.0408336937317764','1.040833693731776','test'),('2019-03-04 03:59:59','2019-03-04 07:59:59','XZCBTC','4h','0.001420000000000','0.001425000000000','0.001470698009243','0.001475876523360','1.0357028234105632','1.035702823410563','test'),('2019-03-04 11:59:59','2019-03-09 15:59:59','XZCBTC','4h','0.001429000000000','0.001464000000000','0.001470698009243','0.001506719304081','1.0291798525143456','1.029179852514346','test'),('2019-03-11 15:59:59','2019-03-14 15:59:59','XZCBTC','4h','0.001485000000000','0.001633000000000','0.001470698009243','0.001617272625652','0.9903690297932659','0.990369029793266','test'),('2019-03-15 19:59:59','2019-03-16 03:59:59','XZCBTC','4h','0.001732000000000','0.001673000000000','0.001470698009243','0.001420599174055','0.8491327997938798','0.849132799793880','test'),('2019-03-18 03:59:59','2019-03-18 11:59:59','XZCBTC','4h','0.001709000000000','0.001638000000000','0.001470698009243','0.001409598208976','0.8605605671404329','0.860560567140433','test'),('2019-03-22 19:59:59','2019-03-24 07:59:59','XZCBTC','4h','0.001746000000000','0.001674000000000','0.001470698009243','0.001410050668656','0.8423241748241695','0.842324174824170','test'),('2019-03-24 15:59:59','2019-03-25 07:59:59','XZCBTC','4h','0.001700000000000','0.001668000000000','0.001470698009243','0.001443014282010','0.8651164760252941','0.865116476025294','test'),('2019-03-26 11:59:59','2019-03-28 11:59:59','XZCBTC','4h','0.001727000000000','0.001797000000000','0.001470698009243','0.001530309393520','0.8515912039623624','0.851591203962362','test'),('2019-03-29 07:59:59','2019-03-29 19:59:59','XZCBTC','4h','0.001783000000000','0.001735000000000','0.001470698009243','0.001431105466089','0.8248446490426247','0.824844649042625','test'),('2019-03-31 07:59:59','2019-04-02 07:59:59','XZCBTC','4h','0.001778000000000','0.001722000000000','0.001470698009243','0.001424376812101','0.8271642346698537','0.827164234669854','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 18:11:08
