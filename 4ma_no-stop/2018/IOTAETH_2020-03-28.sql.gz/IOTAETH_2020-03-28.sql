-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-18 07:59:59','2018-03-31 23:59:59','IOTAETH','4h','0.002198500000000','0.002715560000000','0.072144500000000','0.089111993823061','32.81532863315897','32.815328633158970','test'),('2018-04-01 07:59:59','2018-04-01 11:59:59','IOTAETH','4h','0.002793000000000','0.002761520000000','0.076386373455765','0.075525419987671','27.349220714559703','27.349220714559703','test'),('2018-04-13 03:59:59','2018-04-13 23:59:59','IOTAETH','4h','0.002775990000000','0.002659660000000','0.076386373455765','0.073185343616281','27.516804259296684','27.516804259296684','test'),('2018-04-14 03:59:59','2018-04-21 15:59:59','IOTAETH','4h','0.002688170000000','0.003141750000000','0.076386373455765','0.089275190484474','28.415752521516495','28.415752521516495','test'),('2018-04-22 07:59:59','2018-04-24 11:59:59','IOTAETH','4h','0.003254110000000','0.003158800000000','0.078593081886048','0.076291160121093','24.15194381445249','24.151943814452490','test'),('2018-05-03 11:59:59','2018-05-04 11:59:59','IOTAETH','4h','0.003213810000000','0.002987910000000','0.078593081886048','0.073068742488866','24.454800341665496','24.454800341665496','test'),('2018-05-04 15:59:59','2018-05-04 19:59:59','IOTAETH','4h','0.003037850000000','0.003099360000000','0.078593081886048','0.080184424601064','25.871284588129104','25.871284588129104','test'),('2018-05-08 23:59:59','2018-05-09 19:59:59','IOTAETH','4h','0.003240800000000','0.003064140000000','0.078593081886048','0.074308876181904','24.251136104063193','24.251136104063193','test'),('2018-05-28 19:59:59','2018-05-29 03:59:59','IOTAETH','4h','0.002637380000000','0.002578980000000','0.078593081886048','0.076852780533135','29.799680700561918','29.799680700561918','test'),('2018-05-29 07:59:59','2018-06-03 19:59:59','IOTAETH','4h','0.002630000000000','0.002968630000000','0.078593081886048','0.088712464136646','29.883301097356654','29.883301097356654','test'),('2018-07-01 23:59:59','2018-07-06 03:59:59','IOTAETH','4h','0.002360230000000','0.002442250000000','0.078593081886048','0.081324258329146','33.298908108975816','33.298908108975816','test'),('2018-07-18 11:59:59','2018-07-18 23:59:59','IOTAETH','4h','0.002281420000000','0.002274190000000','0.078740865183428','0.078491329168457','34.513971641971885','34.513971641971885','test'),('2018-07-29 03:59:59','2018-07-29 23:59:59','IOTAETH','4h','0.002200000000000','0.002165670000000','0.078740865183428','0.077512149773543','35.791302356103635','35.791302356103635','test'),('2018-07-31 15:59:59','2018-07-31 19:59:59','IOTAETH','4h','0.002189000000000','0.002164290000000','0.078740865183428','0.077852017865620','35.97115814683783','35.971158146837830','test'),('2018-07-31 23:59:59','2018-08-01 03:59:59','IOTAETH','4h','0.002178870000000','0.002194000000000','0.078740865183428','0.079287639103040','36.13839521560626','36.138395215606259','test'),('2018-08-01 11:59:59','2018-08-02 15:59:59','IOTAETH','4h','0.002201800000000','0.002156370000000','0.078740865183428','0.077116195592510','35.76204250314652','35.762042503146517','test'),('2018-08-03 19:59:59','2018-08-04 11:59:59','IOTAETH','4h','0.002244520000000','0.002148200000000','0.078740865183428','0.075361826398090','35.08138273814803','35.081382738148029','test'),('2018-08-05 19:59:59','2018-08-06 11:59:59','IOTAETH','4h','0.002251300000000','0.002165570000000','0.078740865183428','0.075742395689280','34.97573188088127','34.975731880881270','test'),('2018-08-06 15:59:59','2018-08-06 19:59:59','IOTAETH','4h','0.002196050000000','0.002148000000000','0.078740865183428','0.077017999778695','35.85567959902006','35.855679599020057','test'),('2018-08-20 11:59:59','2018-08-22 23:59:59','IOTAETH','4h','0.001781040000000','0.001766190000000','0.078740865183428','0.078084337622018','44.21061019596865','44.210610195968648','test'),('2018-08-23 23:59:59','2018-09-02 03:59:59','IOTAETH','4h','0.001840240000000','0.002463400000000','0.078740865183428','0.105404864198614','42.78836737785724','42.788367377857242','test'),('2018-09-05 03:59:59','2018-09-06 07:59:59','IOTAETH','4h','0.002477710000000','0.002401000000000','0.082356391022324','0.079806633885564','33.23891457124694','33.238914571246937','test'),('2018-09-06 19:59:59','2018-09-13 15:59:59','IOTAETH','4h','0.002602440000000','0.002858110000000','0.082356391022324','0.090447282067911','31.645836608077037','31.645836608077037','test'),('2018-10-05 23:59:59','2018-10-06 15:59:59','IOTAETH','4h','0.002519740000000','0.002516660000000','0.083741674499531','0.083639313002925','33.23425214487645','33.234252144876450','test'),('2018-10-06 19:59:59','2018-10-06 23:59:59','IOTAETH','4h','0.002526820000000','0.002511090000000','0.083741674499531','0.083220364497284','33.141131738521544','33.141131738521544','test'),('2018-10-07 03:59:59','2018-10-07 07:59:59','IOTAETH','4h','0.002522170000000','0.002515240000000','0.083741674499531','0.083511583028979','33.20223240286381','33.202232402863807','test'),('2018-10-07 11:59:59','2018-10-10 07:59:59','IOTAETH','4h','0.002531100000000','0.002562360000000','0.083741674499531','0.084775914452459','33.08509126448224','33.085091264482237','test'),('2018-10-10 11:59:59','2018-10-11 07:59:59','IOTAETH','4h','0.002563600000000','0.002546250000000','0.083786793745412','0.083219739262855','32.683255478784424','32.683255478784424','test'),('2018-11-03 11:59:59','2018-11-03 23:59:59','IOTAETH','4h','0.002386000000000','0.002385330000000','0.083786793745412','0.083763266020429','35.116007437305946','35.116007437305946','test'),('2018-11-04 07:59:59','2018-11-04 11:59:59','IOTAETH','4h','0.002378650000000','0.002388420000000','0.083786793745412','0.084130937261647','35.22451547954176','35.224515479541758','test'),('2018-11-04 15:59:59','2018-11-04 19:59:59','IOTAETH','4h','0.002392990000000','0.002346520000000','0.083786793745412','0.082159719538938','35.013432461235524','35.013432461235524','test'),('2018-11-05 07:59:59','2018-11-05 11:59:59','IOTAETH','4h','0.002401020000000','0.002379240000000','0.083786793745412','0.083026751610080','34.89633311901275','34.896333119012752','test'),('2018-11-05 23:59:59','2018-11-06 07:59:59','IOTAETH','4h','0.002411970000000','0.002378270000000','0.083786793745412','0.082616126220849','34.737908740743876','34.737908740743876','test'),('2018-11-13 15:59:59','2018-11-14 19:59:59','IOTAETH','4h','0.002359750000000','0.002326700000000','0.083786793745412','0.082613299293336','35.506640002293466','35.506640002293466','test'),('2018-11-14 23:59:59','2018-11-15 03:59:59','IOTAETH','4h','0.002364750000000','0.002329800000000','0.083786793745412','0.082548460542578','35.43156517408267','35.431565174082671','test'),('2018-11-16 23:59:59','2018-11-17 03:59:59','IOTAETH','4h','0.002349520000000','0.002356090000000','0.083786793745412','0.084021088084216','35.661238782990566','35.661238782990566','test'),('2018-11-17 11:59:59','2018-11-17 19:59:59','IOTAETH','4h','0.002364000000000','0.002327970000000','0.083786793745412','0.082509789439724','35.44280615288155','35.442806152881552','test'),('2018-11-17 23:59:59','2018-11-18 11:59:59','IOTAETH','4h','0.002336650000000','0.002327620000000','0.083786793745412','0.083462999104571','35.85765679302077','35.857656793020773','test'),('2018-11-19 23:59:59','2018-11-20 03:59:59','IOTAETH','4h','0.002359970000000','0.002334750000000','0.083786793745412','0.082891399762328','35.50333001920024','35.503330019200241','test'),('2018-11-21 23:59:59','2018-11-24 23:59:59','IOTAETH','4h','0.002402010000000','0.002458610000000','0.083786793745412','0.085761112139586','34.88195042710563','34.881950427105629','test'),('2018-11-25 03:59:59','2018-11-25 07:59:59','IOTAETH','4h','0.002461000000000','0.002467110000000','0.083786793745412','0.083994813781895','34.0458324849297','34.045832484929697','test'),('2018-11-25 11:59:59','2018-11-25 19:59:59','IOTAETH','4h','0.002526850000000','0.002466510000000','0.083786793745412','0.081786004171596','33.15859419649445','33.158594196494448','test'),('2018-11-27 03:59:59','2018-11-27 19:59:59','IOTAETH','4h','0.002536660000000','0.002450400000000','0.083786793745412','0.080937594866382','33.030360294801824','33.030360294801824','test'),('2018-11-28 15:59:59','2018-11-28 19:59:59','IOTAETH','4h','0.002496430000000','0.002451740000000','0.083786793745412','0.082286879142366','33.56264495516077','33.562644955160771','test'),('2018-11-29 11:59:59','2018-11-30 11:59:59','IOTAETH','4h','0.002551960000000','0.002459840000000','0.083786793745412','0.080762279474096','32.8323303442891','32.832330344289097','test'),('2018-11-30 15:59:59','2018-12-01 11:59:59','IOTAETH','4h','0.002496640000000','0.002495940000000','0.083786793745412','0.083763301870083','33.55982189879678','33.559821898796777','test'),('2018-12-02 03:59:59','2018-12-02 15:59:59','IOTAETH','4h','0.002533250000000','0.002509160000000','0.083786793745412','0.082990021274741','33.0748223607666','33.074822360766603','test'),('2018-12-02 19:59:59','2018-12-03 03:59:59','IOTAETH','4h','0.002533090000000','0.002488250000000','0.083786793745412','0.082303625033860','33.07691149758279','33.076911497582792','test'),('2018-12-06 07:59:59','2018-12-06 15:59:59','IOTAETH','4h','0.002522440000000','0.002477870000000','0.083786793745412','0.082306331416384','33.2165656052917','33.216565605291699','test'),('2018-12-06 19:59:59','2018-12-07 03:59:59','IOTAETH','4h','0.002518740000000','0.002539570000000','0.083786793745412','0.084479711201647','33.26536035692925','33.265360356929250','test'),('2018-12-07 11:59:59','2018-12-07 15:59:59','IOTAETH','4h','0.002548670000000','0.002514960000000','0.083786793745412','0.082678587183889','32.87471259339656','32.874712593396559','test'),('2018-12-10 19:59:59','2018-12-11 07:59:59','IOTAETH','4h','0.002516980000000','0.002534820000000','0.083786793745412','0.084380662747318','33.288621183089255','33.288621183089255','test'),('2018-12-11 11:59:59','2018-12-11 15:59:59','IOTAETH','4h','0.002539780000000','0.002520670000000','0.083786793745412','0.083156358972134','32.98978405429289','32.989784054292890','test'),('2018-12-11 19:59:59','2018-12-11 23:59:59','IOTAETH','4h','0.002533030000000','0.002525000000000','0.083786793745412','0.083521179854627','33.0776949919314','33.077694991931402','test'),('2018-12-12 07:59:59','2018-12-13 11:59:59','IOTAETH','4h','0.002521690000000','0.002506590000000','0.083786793745412','0.083285074427988','33.22644486253742','33.226444862537420','test'),('2018-12-15 11:59:59','2018-12-15 15:59:59','IOTAETH','4h','0.002532640000000','0.002592790000000','0.083786793745412','0.085776723480308','33.0827886100717','33.082788610071702','test'),('2018-12-15 19:59:59','2018-12-23 03:59:59','IOTAETH','4h','0.002630260000000','0.002822030000000','0.083786793745412','0.089895616993516','31.85494732285477','31.854947322854770','test'),('2019-01-18 03:59:59','2019-01-21 15:59:59','IOTAETH','4h','0.002534760000000','0.002582220000000','0.083786793745412','0.085355589698937','33.05511912189398','33.055119121893981','test'),('2019-01-21 19:59:59','2019-01-22 11:59:59','IOTAETH','4h','0.002593630000000','0.002546060000000','0.083786793745412','0.082250052661113','32.30483675212424','32.304836752124238','test'),('2019-01-22 15:59:59','2019-01-23 15:59:59','IOTAETH','4h','0.002556780000000','0.002549370000000','0.083786793745412','0.083543964819320','32.77043537004044','32.770435370040438','test'),('2019-03-01 11:59:59','2019-03-02 11:59:59','IOTAETH','4h','0.002167430000000','0.002162490000000','0.083786793745412','0.083595827134678','38.65720865052712','38.657208650527117','test'),('2019-03-02 15:59:59','2019-03-04 07:59:59','IOTAETH','4h','0.002170810000000','0.002156790000000','0.083786793745412','0.083245663545942','38.59701850710656','38.597018507106561','test'),('2019-03-04 11:59:59','2019-03-04 15:59:59','IOTAETH','4h','0.002157320000000','0.002138320000000','0.083786793745412','0.083048864703284','38.83837063829752','38.838370638297519','test'),('2019-03-12 19:59:59','2019-03-16 07:59:59','IOTAETH','4h','0.002127600000000','0.002164770000000','0.083786793745412','0.085250581639526','39.380895725423954','39.380895725423954','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:57:48
