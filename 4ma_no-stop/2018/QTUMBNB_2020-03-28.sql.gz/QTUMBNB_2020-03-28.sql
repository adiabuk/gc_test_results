-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-21 19:59:59','2018-09-23 15:59:59','QTUMBNB','4h','0.379300000000000','0.397020000000000','0.711908500000000','0.745167183416820','1.876900870023728','1.876900870023728','test'),('2018-09-23 23:59:59','2018-09-25 03:59:59','QTUMBNB','4h','0.403850000000000','0.370000000000000','0.720223170854205','0.659855325531895','1.7833927717078248','1.783392771707825','test'),('2018-09-27 15:59:59','2018-10-01 15:59:59','QTUMBNB','4h','0.397370000000000','0.380360000000000','0.720223170854205','0.689392971955873','1.8124749499313106','1.812474949931311','test'),('2018-10-02 03:59:59','2018-10-02 19:59:59','QTUMBNB','4h','0.390980000000000','0.384460000000000','0.720223170854205','0.708212696983497','1.8420972194337433','1.842097219433743','test'),('2018-10-10 19:59:59','2018-10-11 03:59:59','QTUMBNB','4h','0.390510000000000','0.370890000000000','0.720223170854205','0.684037724611703','1.8443142835118305','1.844314283511830','test'),('2018-10-11 15:59:59','2018-10-11 19:59:59','QTUMBNB','4h','0.368300000000000','0.372900000000000','0.720223170854205','0.729218627237396','1.955533996345927','1.955533996345927','test'),('2018-10-17 15:59:59','2018-10-23 19:59:59','QTUMBNB','4h','0.403930000000000','0.420600000000000','0.720223170854205','0.749946440376497','1.783039563424863','1.783039563424863','test'),('2018-11-07 03:59:59','2018-11-08 03:59:59','QTUMBNB','4h','0.429740000000000','0.409370000000000','0.720223170854205','0.686084049547601','1.6759509723418926','1.675950972341893','test'),('2018-11-08 07:59:59','2018-11-08 15:59:59','QTUMBNB','4h','0.411610000000000','0.409080000000000','0.720223170854205','0.715796250657268','1.749770828828758','1.749770828828758','test'),('2018-11-09 03:59:59','2018-11-09 07:59:59','QTUMBNB','4h','0.415870000000000','0.411150000000000','0.720223170854205','0.712048853479949','1.731846901325426','1.731846901325426','test'),('2018-11-21 07:59:59','2018-11-21 23:59:59','QTUMBNB','4h','0.404760000000000','0.397310000000000','0.720223170854205','0.706966765520516','1.7793832662669358','1.779383266266936','test'),('2018-11-22 03:59:59','2018-11-22 07:59:59','QTUMBNB','4h','0.399610000000000','0.399950000000000','0.720223170854205','0.720835958016915','1.8023151844403416','1.802315184440342','test'),('2018-11-22 15:59:59','2018-11-22 19:59:59','QTUMBNB','4h','0.400000000000000','0.402400000000000','0.720223170854205','0.724544509879330','1.8005579271355123','1.800557927135512','test'),('2018-11-22 23:59:59','2018-11-25 03:59:59','QTUMBNB','4h','0.410130000000000','0.407100000000000','0.720223170854205','0.714902233084014','1.7560850726701411','1.756085072670141','test'),('2018-11-25 07:59:59','2018-11-25 11:59:59','QTUMBNB','4h','0.412160000000000','0.409470000000000','0.720223170854205','0.715522568346446','1.7474358764902098','1.747435876490210','test'),('2018-11-29 15:59:59','2018-11-29 19:59:59','QTUMBNB','4h','0.404670000000000','0.402410000000000','0.720223170854205','0.716200870297874','1.7797790072261472','1.779779007226147','test'),('2018-12-13 19:59:59','2018-12-17 07:59:59','QTUMBNB','4h','0.382900000000000','0.371640000000000','0.720223170854205','0.699043455775024','1.8809693676004307','1.880969367600431','test'),('2018-12-17 15:59:59','2018-12-18 23:59:59','QTUMBNB','4h','0.403820000000000','0.385340000000000','0.720223170854205','0.687263624032884','1.783525260893975','1.783525260893975','test'),('2018-12-19 03:59:59','2018-12-22 11:59:59','QTUMBNB','4h','0.398540000000000','0.401290000000000','0.720223170854205','0.725192844462498','1.8071540393792467','1.807154039379247','test'),('2018-12-23 19:59:59','2018-12-26 11:59:59','QTUMBNB','4h','0.434570000000000','0.422510000000000','0.720223170854205','0.700235846739559','1.6573237242658374','1.657323724265837','test'),('2019-02-26 03:59:59','2019-02-27 07:59:59','QTUMBNB','4h','0.215770000000000','0.215020000000000','0.720223170854205','0.717719730254767','3.3379207992501505','3.337920799250151','test'),('2019-03-15 11:59:59','2019-03-16 11:59:59','QTUMBNB','4h','0.167250000000000','0.157050000000000','0.720223170854205','0.676299246533052','4.306267090309148','4.306267090309148','test'),('2019-03-16 19:59:59','2019-03-16 23:59:59','QTUMBNB','4h','0.157760000000000','0.156460000000000','0.720223170854205','0.714288268964559','4.565309145881116','4.565309145881116','test'),('2019-03-18 11:59:59','2019-03-19 07:59:59','QTUMBNB','4h','0.162000000000000','0.156350000000000','0.720223170854205','0.695104276315154','4.445822042309907','4.445822042309907','test'),('2019-03-19 19:59:59','2019-03-20 03:59:59','QTUMBNB','4h','0.162920000000000','0.160410000000000','0.720223170854205','0.709127171843377','4.420716737381567','4.420716737381567','test'),('2019-03-20 07:59:59','2019-03-24 11:59:59','QTUMBNB','4h','0.162270000000000','0.151900000000000','0.720223170854205','0.674196707048461','4.438424667863468','4.438424667863468','test'),('2019-03-30 03:59:59','2019-03-31 07:59:59','QTUMBNB','4h','0.167100000000000','0.169000000000000','0.720223170854205','0.728412422946503','4.310132680156822','4.310132680156822','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','QTUMBNB','4h','0.167130000000000','0.169560000000000','0.720223170854205','0.730694913241423','4.309359007085532','4.309359007085532','test'),('2019-04-03 03:59:59','2019-04-03 15:59:59','QTUMBNB','4h','0.175660000000000','0.166430000000000','0.720223170854205','0.682379268617018','4.100097750507827','4.100097750507827','test'),('2019-04-03 19:59:59','2019-04-04 03:59:59','QTUMBNB','4h','0.185210000000000','0.162970000000000','0.720223170854205','0.633738837827924','3.888684038951487','3.888684038951487','test'),('2019-04-04 07:59:59','2019-04-04 19:59:59','QTUMBNB','4h','0.174000000000000','0.161690000000000','0.720223170854205','0.669269451123083','4.139213625598879','4.139213625598879','test'),('2019-04-05 07:59:59','2019-04-06 15:59:59','QTUMBNB','4h','0.174940000000000','0.173290000000000','0.720223170854205','0.713430166213131','4.116972509741654','4.116972509741654','test'),('2019-04-06 19:59:59','2019-04-09 23:59:59','QTUMBNB','4h','0.175500000000000','0.179510000000000','0.720223170854205','0.736679552136971','4.103835731362992','4.103835731362992','test'),('2019-05-08 11:59:59','2019-05-11 19:59:59','QTUMBNB','4h','0.117000000000000','0.118410000000000','0.720223170854205','0.728902783426038','6.1557535970444865','6.155753597044487','test'),('2019-05-11 23:59:59','2019-05-12 11:59:59','QTUMBNB','4h','0.121110000000000','0.115890000000000','0.720223170854205','0.689180606641019','5.946851381836388','5.946851381836388','test'),('2019-05-15 23:59:59','2019-05-16 15:59:59','QTUMBNB','4h','0.121000000000000','0.125000000000000','0.720223170854205','0.744032201295666','5.95225761036533','5.952257610365330','test'),('2019-05-30 07:59:59','2019-06-03 23:59:59','QTUMBNB','4h','0.101770000000000','0.102570000000000','0.720223170854205','0.725884746335028','7.076969351028839','7.076969351028839','test'),('2019-06-14 23:59:59','2019-06-18 03:59:59','QTUMBNB','4h','0.104620000000000','0.102950000000000','0.720223170854205','0.708726586115852','6.884182478055868','6.884182478055868','test'),('2019-06-24 07:59:59','2019-06-28 03:59:59','QTUMBNB','4h','0.103720000000000','0.130690000000000','0.720223170854205','0.907500638246587','6.943917960414625','6.943917960414625','test'),('2019-06-28 11:59:59','2019-07-01 15:59:59','QTUMBNB','4h','0.146730000000000','0.145510000000000','0.720223170854205','0.714234809452705','4.908492952049376','4.908492952049376','test'),('2019-07-02 15:59:59','2019-07-04 15:59:59','QTUMBNB','4h','0.162930000000000','0.152810000000000','0.720223170854205','0.675488263292402','4.420445411245351','4.420445411245351','test'),('2019-07-30 11:59:59','2019-07-31 03:59:59','QTUMBNB','4h','0.107890000000000','0.106140000000000','0.720223170854205','0.708540989475070','6.6755322166484845','6.675532216648485','test'),('2019-07-31 07:59:59','2019-07-31 11:59:59','QTUMBNB','4h','0.106490000000000','0.109370000000000','0.720223170854205','0.739701457379326','6.763293932333599','6.763293932333599','test'),('2019-07-31 15:59:59','2019-08-01 07:59:59','QTUMBNB','4h','0.110920000000000','0.107180000000000','0.720223170854205','0.695938689615522','6.493176801786918','6.493176801786918','test'),('2019-08-02 15:59:59','2019-08-02 19:59:59','QTUMBNB','4h','0.109570000000000','0.107530000000000','0.720223170854205','0.706813886665626','6.573178523813133','6.573178523813133','test'),('2019-08-03 03:59:59','2019-08-06 03:59:59','QTUMBNB','4h','0.110000000000000','0.108560000000000','0.720223170854205','0.710794794799386','6.547483371401863','6.547483371401863','test'),('2019-08-06 07:59:59','2019-08-06 11:59:59','QTUMBNB','4h','0.110770000000000','0.108680000000000','0.720223170854205','0.706634054422994','6.501969584311682','6.501969584311682','test'),('2019-08-20 07:59:59','2019-08-20 11:59:59','QTUMBNB','4h','0.092590000000000','0.091560000000000','0.720223170854205','0.712211183965990','7.778628046810724','7.778628046810724','test'),('2019-08-20 15:59:59','2019-08-20 23:59:59','QTUMBNB','4h','0.091760000000000','0.093320000000000','0.720223170854205','0.732467592677794','7.848988348454719','7.848988348454719','test'),('2019-08-21 07:59:59','2019-08-21 15:59:59','QTUMBNB','4h','0.091900000000000','0.091720000000000','0.720223170854205','0.718812505231204','7.837031238892329','7.837031238892329','test'),('2019-08-21 19:59:59','2019-08-22 03:59:59','QTUMBNB','4h','0.092400000000000','0.093030000000000','0.720223170854205','0.725133783382756','7.794623061192695','7.794623061192695','test'),('2019-08-22 07:59:59','2019-08-26 07:59:59','QTUMBNB','4h','0.093410000000000','0.093770000000000','0.720223170854205','0.722998894454542','7.7103433342704735','7.710343334270473','test'),('2019-08-26 19:59:59','2019-08-27 19:59:59','QTUMBNB','4h','0.097620000000000','0.096960000000000','0.720223170854205','0.715353807068467','7.37782391778534','7.377823917785340','test'),('2019-08-28 03:59:59','2019-08-28 07:59:59','QTUMBNB','4h','0.097030000000000','0.095900000000000','0.720223170854205','0.711835536276597','7.422685466909254','7.422685466909254','test'),('2019-08-30 07:59:59','2019-08-30 11:59:59','QTUMBNB','4h','0.096950000000000','0.095620000000000','0.720223170854205','0.710342852986891','7.428810426551882','7.428810426551882','test'),('2019-08-31 23:59:59','2019-09-02 15:59:59','QTUMBNB','4h','0.099420000000000','0.094290000000000','0.720223170854205','0.683060176824009','7.244248348966053','7.244248348966053','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:53:44
