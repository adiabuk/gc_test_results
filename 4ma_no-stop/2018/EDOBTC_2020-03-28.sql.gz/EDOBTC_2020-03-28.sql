-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-02 11:59:59','2018-07-03 23:59:59','EDOBTC','4h','0.000158300000000','0.000151800000000','0.001467500000000','0.001407242577385','9.27037271004422','9.270372710044221','test'),('2018-07-04 00:22:27','2018-07-04 11:59:59','EDOBTC','4h','0.000152400000000','0.000150400000000','0.001467500000000','0.001448241469816','9.629265091863518','9.629265091863518','test'),('2018-07-05 07:59:59','2018-07-05 23:59:59','EDOBTC','4h','0.000154800000000','0.000151900000000','0.001467500000000','0.001440008074935','9.47997416020672','9.479974160206719','test'),('2018-07-17 03:59:59','2018-07-18 23:59:59','EDOBTC','4h','0.000147500000000','0.000144000000000','0.001467500000000','0.001432677966102','9.94915254237288','9.949152542372881','test'),('2018-07-19 03:59:59','2018-07-19 07:59:59','EDOBTC','4h','0.000144300000000','0.000143900000000','0.001467500000000','0.001463432085932','10.16978516978517','10.169785169785170','test'),('2018-08-18 11:59:59','2018-08-18 19:59:59','EDOBTC','4h','0.000111400000000','0.000105500000000','0.001467500000000','0.001389777827648','13.173249551166966','13.173249551166966','test'),('2018-08-19 07:59:59','2018-08-22 11:59:59','EDOBTC','4h','0.000106600000000','0.000123000000000','0.001467500000000','0.001693269230769','13.76641651031895','13.766416510318949','test'),('2018-08-24 03:59:59','2018-08-29 15:59:59','EDOBTC','4h','0.000127800000000','0.000128000000000','0.001468037308147','0.001470334706125','11.486989891602114','11.486989891602114','test'),('2018-09-17 11:59:59','2018-09-17 15:59:59','EDOBTC','4h','0.000117800000000','0.000111600000000','0.001468611657641','0.001391316307239','12.466992000350169','12.466992000350169','test'),('2018-09-17 19:59:59','2018-09-17 23:59:59','EDOBTC','4h','0.000115400000000','0.000113700000000','0.001468611657641','0.001446976997173','12.726270863440208','12.726270863440208','test'),('2018-09-18 15:59:59','2018-09-18 19:59:59','EDOBTC','4h','0.000116700000000','0.000115000000000','0.001468611657641','0.001447218000246','12.584504349965723','12.584504349965723','test'),('2018-09-19 03:59:59','2018-09-24 03:59:59','EDOBTC','4h','0.000128000000000','0.000132300000000','0.001468611657641','0.001517947830515','11.473528575320312','11.473528575320312','test'),('2018-09-25 23:59:59','2018-09-27 11:59:59','EDOBTC','4h','0.000136200000000','0.000129900000000','0.001468611657641','0.001400680281407','10.782758132459618','10.782758132459618','test'),('2018-09-28 15:59:59','2018-09-29 11:59:59','EDOBTC','4h','0.000136200000000','0.000132500000000','0.001468611657641','0.001428715452551','10.782758132459618','10.782758132459618','test'),('2018-09-29 15:59:59','2018-09-29 23:59:59','EDOBTC','4h','0.000133700000000','0.000132200000000','0.001468611657641','0.001452135087062','10.984380386245325','10.984380386245325','test'),('2018-10-01 11:59:59','2018-10-01 19:59:59','EDOBTC','4h','0.000134300000000','0.000145000000000','0.001468611657641','0.001585619436768','10.935306460469098','10.935306460469098','test'),('2018-10-02 03:59:59','2018-10-02 11:59:59','EDOBTC','4h','0.000134100000000','0.000133600000000','0.001468611657641','0.001463135849820','10.951615642363906','10.951615642363906','test'),('2018-10-02 15:59:59','2018-10-08 03:59:59','EDOBTC','4h','0.000136000000000','0.000157300000000','0.001468611657641','0.001698622159904','10.798615129713236','10.798615129713236','test'),('2018-10-08 15:59:59','2018-10-11 03:59:59','EDOBTC','4h','0.000169900000000','0.000159300000000','0.001505174364210','0.001411267076037','8.859178129546793','8.859178129546793','test'),('2018-10-14 03:59:59','2018-10-14 23:59:59','EDOBTC','4h','0.000168900000000','0.000157300000000','0.001505174364210','0.001401799452281','8.911630338721135','8.911630338721135','test'),('2018-10-18 03:59:59','2018-10-25 07:59:59','EDOBTC','4h','0.000164200000000','0.000188900000000','0.001505174364210','0.001731592188790','9.166713545736906','9.166713545736906','test'),('2018-10-28 03:59:59','2018-10-28 11:59:59','EDOBTC','4h','0.000194600000000','0.000185800000000','0.001512458270330','0.001444063446184','7.772139107551388','7.772139107551388','test'),('2018-10-28 15:59:59','2018-10-28 19:59:59','EDOBTC','4h','0.000186700000000','0.000186400000000','0.001512458270330','0.001510027967807','8.101008410980182','8.101008410980182','test'),('2018-10-31 23:59:59','2018-11-05 11:59:59','EDOBTC','4h','0.000191700000000','0.000196100000000','0.001512458270330','0.001547173014146','7.88971450354721','7.889714503547210','test'),('2018-11-05 15:59:59','2018-11-05 23:59:59','EDOBTC','4h','0.000206300000000','0.000203000000000','0.001512458270330','0.001488264803088','7.331353709791566','7.331353709791566','test'),('2018-11-07 03:59:59','2018-11-08 23:59:59','EDOBTC','4h','0.000215800000000','0.000206800000000','0.001512458270330','0.001449380770641','7.0086110765987035','7.008611076598704','test'),('2018-11-10 03:59:59','2018-11-10 07:59:59','EDOBTC','4h','0.000210700000000','0.000208700000000','0.001512458270330','0.001498101760882','7.178254723920266','7.178254723920266','test'),('2018-11-10 19:59:59','2018-11-10 23:59:59','EDOBTC','4h','0.000210700000000','0.000208500000000','0.001512458270330','0.001496666109937','7.178254723920266','7.178254723920266','test'),('2018-11-11 03:59:59','2018-11-11 15:59:59','EDOBTC','4h','0.000210600000000','0.000211700000000','0.001512458270330','0.001520358099852','7.181663201946819','7.181663201946819','test'),('2018-11-26 07:59:59','2018-11-26 19:59:59','EDOBTC','4h','0.000190800000000','0.000185000000000','0.001512458270330','0.001466482075530','7.926930137997904','7.926930137997904','test'),('2018-11-26 23:59:59','2018-11-27 15:59:59','EDOBTC','4h','0.000185100000000','0.000185900000000','0.001512458270330','0.001518995096998','8.171033335116153','8.171033335116153','test'),('2018-11-28 23:59:59','2018-11-29 23:59:59','EDOBTC','4h','0.000188900000000','0.000185600000000','0.001512458270330','0.001486036288900','8.00666103933298','8.006661039332981','test'),('2018-11-30 03:59:59','2018-12-01 19:59:59','EDOBTC','4h','0.000189600000000','0.000189000000000','0.001512458270330','0.001507672009981','7.9771005819092835','7.977100581909284','test'),('2018-12-04 03:59:59','2018-12-05 15:59:59','EDOBTC','4h','0.000191100000000','0.000190200000000','0.001512458270330','0.001505335232950','7.914485977655677','7.914485977655677','test'),('2018-12-05 19:59:59','2018-12-06 07:59:59','EDOBTC','4h','0.000191600000000','0.000189600000000','0.001512458270330','0.001496670605713','7.8938323086116915','7.893832308611691','test'),('2018-12-10 15:59:59','2018-12-11 19:59:59','EDOBTC','4h','0.000194500000000','0.000189700000000','0.001512458270330','0.001475132822013','7.77613506596401','7.776135065964010','test'),('2018-12-11 23:59:59','2018-12-12 03:59:59','EDOBTC','4h','0.000190300000000','0.000187700000000','0.001512458270330','0.001491794100583','7.947757595007883','7.947757595007883','test'),('2018-12-12 19:59:59','2018-12-12 23:59:59','EDOBTC','4h','0.000203500000000','0.000199500000000','0.001512458270330','0.001482729360839','7.432227372628993','7.432227372628993','test'),('2018-12-13 03:59:59','2018-12-17 07:59:59','EDOBTC','4h','0.000203500000000','0.000203900000000','0.001512458270330','0.001515431161279','7.432227372628993','7.432227372628993','test'),('2018-12-18 03:59:59','2018-12-18 23:59:59','EDOBTC','4h','0.000213000000000','0.000206100000000','0.001512458270330','0.001463463143263','7.100743053192488','7.100743053192488','test'),('2018-12-19 03:59:59','2018-12-19 19:59:59','EDOBTC','4h','0.000212800000000','0.000209300000000','0.001512458270330','0.001487582311936','7.1074166838815795','7.107416683881580','test'),('2018-12-20 11:59:59','2018-12-20 23:59:59','EDOBTC','4h','0.000212000000000','0.000210000000000','0.001512458270330','0.001498189796082','7.134237124198114','7.134237124198114','test'),('2018-12-21 03:59:59','2018-12-24 03:59:59','EDOBTC','4h','0.000212800000000','0.000207100000000','0.001512458270330','0.001471945995232','7.1074166838815795','7.107416683881580','test'),('2019-01-02 23:59:59','2019-01-05 03:59:59','EDOBTC','4h','0.000210300000000','0.000202900000000','0.001512458270330','0.001459238150499','7.191908085259154','7.191908085259154','test'),('2019-01-05 15:59:59','2019-01-10 11:59:59','EDOBTC','4h','0.000216600000000','0.000224000000000','0.001512458270330','0.001564130436537','6.982725163111727','6.982725163111727','test'),('2019-01-13 07:59:59','2019-01-13 19:59:59','EDOBTC','4h','0.000229500000000','0.000218700000000','0.001512458270330','0.001441283763491','6.5902321147276695','6.590232114727669','test'),('2019-01-17 11:59:59','2019-01-20 03:59:59','EDOBTC','4h','0.000229600000000','0.000226900000000','0.001512458270330','0.001494672393458','6.587361804573171','6.587361804573171','test'),('2019-01-20 11:59:59','2019-01-20 15:59:59','EDOBTC','4h','0.000230000000000','0.000229800000000','0.001512458270330','0.001511143089225','6.575905523173914','6.575905523173914','test'),('2019-01-20 19:59:59','2019-01-22 03:59:59','EDOBTC','4h','0.000230300000000','0.000226500000000','0.001512458270330','0.001487502380503','6.567339428267478','6.567339428267478','test'),('2019-02-12 03:59:59','2019-02-14 11:59:59','EDOBTC','4h','0.000195500000000','0.000197100000000','0.001512458270330','0.001524836445432','7.736359439028133','7.736359439028133','test'),('2019-02-15 19:59:59','2019-02-15 23:59:59','EDOBTC','4h','0.000199900000000','0.000197400000000','0.001512458270330','0.001493543084358','7.566074388844422','7.566074388844422','test'),('2019-02-16 03:59:59','2019-02-16 19:59:59','EDOBTC','4h','0.000203400000000','0.000199400000000','0.001512458270330','0.001482714744856','7.435881368387414','7.435881368387414','test'),('2019-02-17 03:59:59','2019-02-18 19:59:59','EDOBTC','4h','0.000200700000000','0.000200800000000','0.001512458270330','0.001513211861895','7.5359156468859','7.535915646885900','test'),('2019-02-22 19:59:59','2019-02-23 19:59:59','EDOBTC','4h','0.000202600000000','0.000198800000000','0.001512458270330','0.001484090346207','7.465243190177691','7.465243190177691','test'),('2019-02-27 07:59:59','2019-02-27 15:59:59','EDOBTC','4h','0.000203100000000','0.000205900000000','0.001512458270330','0.001533309492176','7.446864945002462','7.446864945002462','test'),('2019-02-28 03:59:59','2019-02-28 07:59:59','EDOBTC','4h','0.000199900000000','0.000194200000000','0.001512458270330','0.001469331646314','7.566074388844422','7.566074388844422','test'),('2019-03-01 11:59:59','2019-03-01 15:59:59','EDOBTC','4h','0.000201400000000','0.000199200000000','0.001512458270330','0.001495936879095','7.509723288629593','7.509723288629593','test'),('2019-03-01 19:59:59','2019-03-01 23:59:59','EDOBTC','4h','0.000200500000000','0.000201100000000','0.001512458270330','0.001516984329992','7.543432769725686','7.543432769725686','test'),('2019-03-02 11:59:59','2019-03-02 15:59:59','EDOBTC','4h','0.000200400000000','0.000198000000000','0.001512458270330','0.001494344997631','7.547196957734531','7.547196957734531','test'),('2019-03-03 03:59:59','2019-03-04 07:59:59','EDOBTC','4h','0.000201100000000','0.000201000000000','0.001512458270330','0.001511706177704','7.520926257235207','7.520926257235207','test'),('2019-03-04 15:59:59','2019-03-04 19:59:59','EDOBTC','4h','0.000202200000000','0.000202000000000','0.001512458270330','0.001510962268084','7.480011228140455','7.480011228140455','test'),('2019-03-04 23:59:59','2019-03-05 11:59:59','EDOBTC','4h','0.000203200000000','0.000204100000000','0.001512458270330','0.001519157150464','7.443200149261811','7.443200149261811','test'),('2019-03-05 19:59:59','2019-03-05 23:59:59','EDOBTC','4h','0.000202300000000','0.000200000000000','0.001512458270330','0.001495262748720','7.476313743598616','7.476313743598616','test'),('2019-03-07 07:59:59','2019-03-07 11:59:59','EDOBTC','4h','0.000203700000000','0.000200400000000','0.001512458270330','0.001487956000855','7.424930143986255','7.424930143986255','test'),('2019-03-09 07:59:59','2019-03-09 15:59:59','EDOBTC','4h','0.000203000000000','0.000202900000000','0.001512458270330','0.001511713216995','7.450533351379311','7.450533351379311','test'),('2019-03-09 19:59:59','2019-03-10 11:59:59','EDOBTC','4h','0.000207000000000','0.000202100000000','0.001512458270330','0.001476656118037','7.3065616924154595','7.306561692415459','test'),('2019-03-10 15:59:59','2019-03-11 07:59:59','EDOBTC','4h','0.000203500000000','0.000201700000000','0.001512458270330','0.001499080261059','7.432227372628993','7.432227372628993','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','EDOBTC','4h','0.000216500000000','0.000202700000000','0.001512458270330','0.001416052154254','6.985950440323326','6.985950440323326','test'),('2019-03-12 11:59:59','2019-03-15 03:59:59','EDOBTC','4h','0.000211000000000','0.000206900000000','0.001512458270330','0.001483069270764','7.168048674549763','7.168048674549763','test'),('2019-05-20 07:59:59','2019-05-26 23:59:59','EDOBTC','4h','0.000093300000000','0.000094600000000','0.001512458270330','0.001533532179777','16.210699574812434','16.210699574812434','test'),('2019-05-27 15:59:59','2019-05-31 07:59:59','EDOBTC','4h','0.000107900000000','0.000105000000000','0.001512458270330','0.001471808326086','14.017222153197407','14.017222153197407','test'),('2019-06-08 23:59:59','2019-06-09 19:59:59','EDOBTC','4h','0.000103400000000','0.000107600000000','0.001512458270330','0.001573892745527','14.627255999323017','14.627255999323017','test'),('2019-06-10 03:59:59','2019-06-10 11:59:59','EDOBTC','4h','0.000108000000000','0.000103700000000','0.001512458270330','0.001452240024382','14.004243243796298','14.004243243796298','test'),('2019-06-10 15:59:59','2019-06-11 11:59:59','EDOBTC','4h','0.000104900000000','0.000104000000000','0.001512458270330','0.001499481983931','14.418095999332698','14.418095999332698','test'),('2019-06-11 15:59:59','2019-06-11 23:59:59','EDOBTC','4h','0.000108500000000','0.000108900000000','0.001512458270330','0.001518034153354','13.939707560645163','13.939707560645163','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:48:43
