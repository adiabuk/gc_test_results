-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-21 03:59:59','2018-03-30 03:59:59','ZRXETH','4h','0.000985430000000','0.001298350000000','0.072144500000000','0.095053744634322','73.21118699451002','73.211186994510015','test'),('2018-03-31 19:59:59','2018-04-01 23:59:59','ZRXETH','4h','0.001397120000000','0.001333330000000','0.077871811158580','0.074316323559944','55.737382013413665','55.737382013413665','test'),('2018-04-02 03:59:59','2018-04-04 23:59:59','ZRXETH','4h','0.001366000000000','0.001368310000000','0.077871811158580','0.078003497749924','57.00718240013177','57.007182400131768','test'),('2018-04-05 19:59:59','2018-04-06 07:59:59','ZRXETH','4h','0.001780000000000','0.001394990000000','0.077871811158580','0.061028313397813','43.74820851605618','43.748208516056181','test'),('2018-04-06 11:59:59','2018-04-06 19:59:59','ZRXETH','4h','0.001398520000000','0.001405410000000','0.077871811158580','0.078255457283686','55.681585646669326','55.681585646669326','test'),('2018-04-08 15:59:59','2018-04-09 11:59:59','ZRXETH','4h','0.001430380000000','0.001362800000000','0.077871811158580','0.074192665058874','54.44134506814972','54.441345068149722','test'),('2018-04-11 19:59:59','2018-04-12 03:59:59','ZRXETH','4h','0.001442510000000','0.001444240000000','0.077871811158580','0.077965202700617','53.983550310625226','53.983550310625226','test'),('2018-04-14 07:59:59','2018-04-14 15:59:59','ZRXETH','4h','0.001434780000000','0.001423880000000','0.077871811158580','0.077280220293340','54.27439130638843','54.274391306388431','test'),('2018-04-14 19:59:59','2018-04-20 07:59:59','ZRXETH','4h','0.001470000000000','0.001612310000000','0.077871811158580','0.085410544115027','52.974021196312925','52.974021196312925','test'),('2018-04-23 11:59:59','2018-04-23 19:59:59','ZRXETH','4h','0.001612700000000','0.001549820000000','0.077871811158580','0.074835549308483','48.286607030805484','48.286607030805484','test'),('2018-04-24 15:59:59','2018-04-25 07:59:59','ZRXETH','4h','0.001627220000000','0.001605000000000','0.077871811158580','0.076808456698861','47.8557362609727','47.855736260972698','test'),('2018-04-25 19:59:59','2018-04-28 03:59:59','ZRXETH','4h','0.001669840000000','0.001651510000000','0.077871811158580','0.077017004531276','46.634294997472814','46.634294997472814','test'),('2018-04-28 07:59:59','2018-04-28 11:59:59','ZRXETH','4h','0.001710330000000','0.001669230000000','0.077871811158580','0.076000516473567','45.53028430687645','45.530284306876453','test'),('2018-04-28 15:59:59','2018-05-01 07:59:59','ZRXETH','4h','0.001703190000000','0.001726950000000','0.077871811158580','0.078958145761958','45.7211533408369','45.721153340836899','test'),('2018-05-02 11:59:59','2018-05-06 03:59:59','ZRXETH','4h','0.001880100000000','0.001943240000000','0.077871811158580','0.080487005114515','41.41897301131854','41.418973011318542','test'),('2018-05-07 07:59:59','2018-05-13 03:59:59','ZRXETH','4h','0.002101060000000','0.002400060000000','0.077871811158580','0.088953680089698','37.0631067930378','37.063106793037797','test'),('2018-05-24 15:59:59','2018-05-26 15:59:59','ZRXETH','4h','0.002331150000000','0.002099680000000','0.077871811158580','0.070139581088067','33.40489078719945','33.404890787199449','test'),('2018-05-29 15:59:59','2018-06-01 11:59:59','ZRXETH','4h','0.002184630000000','0.002189860000000','0.077871811158580','0.078058236124070','35.645308889184896','35.645308889184896','test'),('2018-06-07 15:59:59','2018-06-07 23:59:59','ZRXETH','4h','0.002199630000000','0.002144250000000','0.077871811158580','0.075911235560883','35.40223181106822','35.402231811068219','test'),('2018-06-08 03:59:59','2018-06-08 07:59:59','ZRXETH','4h','0.002151290000000','0.002127050000000','0.077871811158580','0.076994378221838','36.19772841345425','36.197728413454250','test'),('2018-07-01 11:59:59','2018-07-07 15:59:59','ZRXETH','4h','0.001698110000000','0.001985020000000','0.077871811158580','0.091028910133033','45.85793096947783','45.857930969477827','test'),('2018-07-13 23:59:59','2018-07-20 15:59:59','ZRXETH','4h','0.002229000000000','0.002433460000000','0.077871811158580','0.085014776842511','34.93576095046209','34.935760950462090','test'),('2018-07-22 03:59:59','2018-07-23 11:59:59','ZRXETH','4h','0.002559770000000','0.002462370000000','0.078209727603032','0.075233824506842','30.55341987875152','30.553419878751519','test'),('2018-07-23 23:59:59','2018-07-24 03:59:59','ZRXETH','4h','0.002539780000000','0.002453630000000','0.078209727603032','0.075556833244859','30.793898527837843','30.793898527837843','test'),('2018-07-28 07:59:59','2018-07-30 07:59:59','ZRXETH','4h','0.002484590000000','0.002460720000000','0.078209727603032','0.077458349630053','31.477920945923476','31.477920945923476','test'),('2018-08-01 23:59:59','2018-08-02 11:59:59','ZRXETH','4h','0.002517650000000','0.002443240000000','0.078209727603032','0.075898212566811','31.06457514071932','31.064575140719320','test'),('2018-08-09 23:59:59','2018-08-10 11:59:59','ZRXETH','4h','0.002557430000000','0.002435210000000','0.078209727603032','0.074472071867531','30.581375679112238','30.581375679112238','test'),('2018-08-10 15:59:59','2018-08-14 03:59:59','ZRXETH','4h','0.002493680000000','0.002518190000000','0.078209727603032','0.078978439075053','31.36317715305573','31.363177153055730','test'),('2018-08-17 15:59:59','2018-08-18 07:59:59','ZRXETH','4h','0.002701320000000','0.002475750000000','0.078209727603032','0.071678932193597','28.9524112667259','28.952411266725900','test'),('2018-08-18 11:59:59','2018-08-18 15:59:59','ZRXETH','4h','0.002547150000000','0.002540000000000','0.078209727603032','0.077990188293466','30.704798540734547','30.704798540734547','test'),('2018-08-19 11:59:59','2018-08-19 15:59:59','ZRXETH','4h','0.002598570000000','0.002572170000000','0.078209727603032','0.077415161049612','30.097217932567528','30.097217932567528','test'),('2018-08-20 03:59:59','2018-08-20 07:59:59','ZRXETH','4h','0.002572000000000','0.002538000000000','0.078209727603032','0.077175850955091','30.40813670413375','30.408136704133749','test'),('2018-08-20 23:59:59','2018-08-21 03:59:59','ZRXETH','4h','0.002587430000000','0.002513000000000','0.078209727603032','0.075959946922784','30.22679941217038','30.226799412170379','test'),('2018-08-24 15:59:59','2018-08-25 15:59:59','ZRXETH','4h','0.002616020000000','0.002573660000000','0.078209727603032','0.076943313714276','29.8964562973647','29.896456297364701','test'),('2018-08-25 19:59:59','2018-08-26 07:59:59','ZRXETH','4h','0.002580140000000','0.002534000000000','0.078209727603032','0.076811122553847','30.312203059923885','30.312203059923885','test'),('2018-08-26 15:59:59','2018-08-30 11:59:59','ZRXETH','4h','0.002617520000000','0.002700890000000','0.078209727603032','0.080700766827284','29.879323788560168','29.879323788560168','test'),('2018-09-01 07:59:59','2018-09-02 11:59:59','ZRXETH','4h','0.002750170000000','0.002700280000000','0.078209727603032','0.076790948651143','28.438142952265498','28.438142952265498','test'),('2018-09-04 07:59:59','2018-09-05 19:59:59','ZRXETH','4h','0.002804180000000','0.002734730000000','0.078209727603032','0.076272738685762','27.8904091759559','27.890409175955899','test'),('2018-09-06 15:59:59','2018-09-10 19:59:59','ZRXETH','4h','0.002858290000000','0.002833800000000','0.078209727603032','0.077539621970294','27.36241864997324','27.362418649973240','test'),('2018-09-24 15:59:59','2018-09-28 23:59:59','ZRXETH','4h','0.002931780000000','0.002928430000000','0.078209727603032','0.078120361215557','26.676533574494677','26.676533574494677','test'),('2018-10-06 03:59:59','2018-10-14 19:59:59','ZRXETH','4h','0.002872020000000','0.003598220000000','0.078209727603032','0.097985322545032','27.231609669512054','27.231609669512054','test'),('2018-10-16 19:59:59','2018-10-21 15:59:59','ZRXETH','4h','0.004069980000000','0.004345780000000','0.078209727603032','0.083509567620161','19.216243716930308','19.216243716930308','test'),('2018-10-22 15:59:59','2018-10-23 23:59:59','ZRXETH','4h','0.004418280000000','0.004332530000000','0.078209727603032','0.076691832824530','17.701396833843035','17.701396833843035','test'),('2018-11-22 19:59:59','2018-11-23 03:59:59','ZRXETH','4h','0.003294660000000','0.003236760000000','0.078209727603032','0.076835278273445','23.738330390095488','23.738330390095488','test'),('2018-11-23 07:59:59','2018-11-23 11:59:59','ZRXETH','4h','0.003238340000000','0.003240110000000','0.078209727603032','0.078252475189097','24.151178567732853','24.151178567732853','test'),('2018-11-23 15:59:59','2018-11-24 03:59:59','ZRXETH','4h','0.003264160000000','0.003246680000000','0.078209727603032','0.077790904371787','23.960139087248177','23.960139087248177','test'),('2018-11-24 07:59:59','2018-11-24 15:59:59','ZRXETH','4h','0.003276050000000','0.003224750000000','0.078209727603032','0.076985033527534','23.873178859612036','23.873178859612036','test'),('2018-11-26 11:59:59','2018-11-26 15:59:59','ZRXETH','4h','0.003267960000000','0.003215720000000','0.078209727603032','0.076959505394075','23.93227811938702','23.932278119387021','test'),('2018-11-26 19:59:59','2018-11-26 23:59:59','ZRXETH','4h','0.003224860000000','0.003233850000000','0.078209727603032','0.078427754261911','24.252131132214114','24.252131132214114','test'),('2018-11-27 03:59:59','2018-11-27 07:59:59','ZRXETH','4h','0.003253190000000','0.003160010000000','0.078209727603032','0.075969593329273','24.040934468331702','24.040934468331702','test'),('2018-11-27 11:59:59','2018-11-27 23:59:59','ZRXETH','4h','0.003287520000000','0.003262630000000','0.078209727603032','0.077617597328527','23.789886480700346','23.789886480700346','test'),('2018-11-28 03:59:59','2018-11-30 11:59:59','ZRXETH','4h','0.003308080000000','0.003420350000000','0.078209727603032','0.080864018345092','23.6420303024812','23.642030302481199','test'),('2018-11-30 15:59:59','2018-11-30 23:59:59','ZRXETH','4h','0.003490100000000','0.003458520000000','0.078209727603032','0.077502050688988','22.40902197731641','22.409021977316410','test'),('2018-12-01 15:59:59','2018-12-02 11:59:59','ZRXETH','4h','0.003574210000000','0.003492830000000','0.078209727603032','0.076428996299517','21.881682274693432','21.881682274693432','test'),('2018-12-07 03:59:59','2018-12-07 11:59:59','ZRXETH','4h','0.003549080000000','0.003434670000000','0.078209727603032','0.075688517899373','22.03662008267833','22.036620082678329','test'),('2018-12-07 15:59:59','2018-12-07 19:59:59','ZRXETH','4h','0.003477170000000','0.003281900000000','0.078209727603032','0.073817646252668','22.492350849406847','22.492350849406847','test'),('2018-12-08 03:59:59','2018-12-08 23:59:59','ZRXETH','4h','0.003582000000000','0.003518790000000','0.078209727603032','0.076829594470205','21.83409480821664','21.834094808216641','test'),('2018-12-09 03:59:59','2018-12-10 11:59:59','ZRXETH','4h','0.003542430000000','0.003475390000000','0.078209727603032','0.076729619276683','22.077988161525283','22.077988161525283','test'),('2019-01-12 07:59:59','2019-01-12 11:59:59','ZRXETH','4h','0.002243850000000','0.002237890000000','0.078209727603032','0.078001990910956','34.85514967713172','34.855149677131720','test'),('2019-01-12 19:59:59','2019-01-12 23:59:59','ZRXETH','4h','0.002235550000000','0.002255510000000','0.078209727603032','0.078908019371481','34.98455753753304','34.984557537533043','test'),('2019-01-13 03:59:59','2019-01-14 15:59:59','ZRXETH','4h','0.002269340000000','0.002248650000000','0.078209727603032','0.077496674792917','34.463644761486606','34.463644761486606','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','ZRXETH','4h','0.002249900000000','0.002213830000000','0.078209727603032','0.076955883043433','34.76142388685364','34.761423886853642','test'),('2019-01-15 23:59:59','2019-01-20 03:59:59','ZRXETH','4h','0.002330220000000','0.002416540000000','0.078209727603032','0.081106906275730','33.56323763551596','33.563237635515961','test'),('2019-01-21 07:59:59','2019-01-21 19:59:59','ZRXETH','4h','0.002456420000000','0.002409870000000','0.078209727603032','0.076727626488434','31.83890686569561','31.838906865695609','test'),('2019-01-22 19:59:59','2019-01-25 11:59:59','ZRXETH','4h','0.002455920000000','0.002469490000000','0.078209727603032','0.078641869530934','31.845388938984986','31.845388938984986','test'),('2019-01-25 15:59:59','2019-01-25 19:59:59','ZRXETH','4h','0.002517440000000','0.002509820000000','0.078209727603032','0.077972995794395','31.06716648779395','31.067166487793951','test'),('2019-02-27 11:59:59','2019-02-28 11:59:59','ZRXETH','4h','0.001958440000000','0.001813540000000','0.078209727603032','0.072423188556812','39.93470701325136','39.934707013251362','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  1:48:07
