-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-19 19:59:59','2018-05-21 03:59:59','BTSBTC','4h','0.000031640000000','0.000030790000000','0.001467500000000','0.001428076011378','46.381163084702905','46.381163084702905','test'),('2018-06-02 19:59:59','2018-06-05 03:59:59','BTSBTC','4h','0.000029260000000','0.000028740000000','0.001467500000000','0.001441420027341','50.153793574846205','50.153793574846205','test'),('2018-06-05 19:59:59','2018-06-06 19:59:59','BTSBTC','4h','0.000029700000000','0.000028450000000','0.001467500000000','0.001405736531987','49.410774410774415','49.410774410774415','test'),('2018-07-02 23:59:59','2018-07-10 11:59:59','BTSBTC','4h','0.000024310000000','0.000025630000000','0.001467500000000','0.001547183257919','60.36610448375155','60.366104483751549','test'),('2018-07-14 19:59:59','2018-07-19 03:59:59','BTSBTC','4h','0.000025850000000','0.000028400000000','0.001467500000000','0.001612263056093','56.76982591876209','56.769825918762088','test'),('2018-07-19 11:59:59','2018-07-19 15:59:59','BTSBTC','4h','0.000030440000000','0.000028870000000','0.001491794721180','0.001414852614996','49.00771094545007','49.007710945450071','test'),('2018-08-29 19:59:59','2018-08-30 03:59:59','BTSBTC','4h','0.000016860000000','0.000016500000000','0.001491794721180','0.001459941453112','88.48130018861208','88.481300188612082','test'),('2018-08-31 19:59:59','2018-09-02 11:59:59','BTSBTC','4h','0.000016700000000','0.000016670000000','0.001491794721180','0.001489114850423','89.32902522035928','89.329025220359284','test'),('2018-09-02 15:59:59','2018-09-02 19:59:59','BTSBTC','4h','0.000016730000000','0.000016810000000','0.001491794721180','0.001498928228514','89.1688416724447','89.168841672444699','test'),('2018-09-02 23:59:59','2018-09-03 03:59:59','BTSBTC','4h','0.000016870000000','0.000016660000000','0.001491794721180','0.001473224662410','88.42885128512151','88.428851285121510','test'),('2018-09-14 19:59:59','2018-09-18 03:59:59','BTSBTC','4h','0.000017340000000','0.000017570000000','0.001491794721180','0.001511582079073','86.03199084083045','86.031990840830446','test'),('2018-09-18 11:59:59','2018-09-23 03:59:59','BTSBTC','4h','0.000017800000000','0.000018360000000','0.001491794721180','0.001538727588813','83.80869220112359','83.808692201123591','test'),('2018-09-23 07:59:59','2018-09-24 07:59:59','BTSBTC','4h','0.000018490000000','0.000017880000000','0.001491794721180','0.001442579211179','80.6811639361817','80.681163936181704','test'),('2018-11-06 23:59:59','2018-11-07 03:59:59','BTSBTC','4h','0.000015240000000','0.000015260000000','0.001491794721180','0.001493752457035','97.88679272834645','97.886792728346450','test'),('2018-11-07 07:59:59','2018-11-07 15:59:59','BTSBTC','4h','0.000015270000000','0.000015150000000','0.001491794721180','0.001480071383489','97.69448075834968','97.694480758349684','test'),('2018-12-16 23:59:59','2018-12-17 15:59:59','BTSBTC','4h','0.000011080000000','0.000010970000000','0.001491794721180','0.001476984484778','134.63851274187724','134.638512741877236','test'),('2018-12-17 19:59:59','2018-12-17 23:59:59','BTSBTC','4h','0.000010990000000','0.000010890000000','0.001491794721180','0.001478220610887','135.74110292811648','135.741102928116476','test'),('2018-12-23 19:59:59','2018-12-25 03:59:59','BTSBTC','4h','0.000010960000000','0.000010550000000','0.001491794721180','0.001435988531793','136.1126570419708','136.112657041970806','test'),('2018-12-25 07:59:59','2018-12-25 11:59:59','BTSBTC','4h','0.000010790000000','0.000010550000000','0.001491794721180','0.001458613003563','138.25715673586654','138.257156735866545','test'),('2019-01-07 03:59:59','2019-01-08 07:59:59','BTSBTC','4h','0.000011300000000','0.000010650000000','0.001491794721180','0.001405983520404','132.01723196283186','132.017231962831858','test'),('2019-01-08 11:59:59','2019-01-08 15:59:59','BTSBTC','4h','0.000010740000000','0.000010890000000','0.001491794721180','0.001512629842984','138.90081202793294','138.900812027932943','test'),('2019-01-12 19:59:59','2019-01-13 19:59:59','BTSBTC','4h','0.000010900000000','0.000010480000000','0.001491794721180','0.001434312722749','136.86190102568804','136.861901025688041','test'),('2019-01-13 23:59:59','2019-01-14 03:59:59','BTSBTC','4h','0.000010560000000','0.000010660000000','0.001491794721180','0.001505921565131','141.2684395056818','141.268439505681812','test'),('2019-01-14 11:59:59','2019-01-15 03:59:59','BTSBTC','4h','0.000010620000000','0.000010630000000','0.001491794721180','0.001493199424307','140.47031272881355','140.470312728813553','test'),('2019-01-16 15:59:59','2019-01-17 15:59:59','BTSBTC','4h','0.000010900000000','0.000010790000000','0.001491794721180','0.001476739912067','136.86190102568804','136.861901025688041','test'),('2019-01-17 23:59:59','2019-01-18 07:59:59','BTSBTC','4h','0.000010670000000','0.000010670000000','0.001491794721180','0.001491794721180','139.8120638406748','139.812063840674796','test'),('2019-01-18 15:59:59','2019-01-18 19:59:59','BTSBTC','4h','0.000010750000000','0.000010690000000','0.001491794721180','0.001483468425062','138.77160197023255','138.771601970232553','test'),('2019-01-18 23:59:59','2019-01-20 15:59:59','BTSBTC','4h','0.000010830000000','0.000010990000000','0.001491794721180','0.001513834163044','137.74651165096952','137.746511650969524','test'),('2019-01-20 19:59:59','2019-01-22 07:59:59','BTSBTC','4h','0.000011170000000','0.000010950000000','0.001491794721180','0.001462412909304','133.55369034735898','133.553690347358980','test'),('2019-02-01 11:59:59','2019-02-03 19:59:59','BTSBTC','4h','0.000010980000000','0.000010860000000','0.001491794721180','0.001475490953735','135.86472870491804','135.864728704918036','test'),('2019-02-03 23:59:59','2019-02-04 03:59:59','BTSBTC','4h','0.000010870000000','0.000010810000000','0.001491794721180','0.001483560343694','137.23962476356945','137.239624763569452','test'),('2019-02-07 15:59:59','2019-02-09 19:59:59','BTSBTC','4h','0.000010950000000','0.000010830000000','0.001491794721180','0.001475446285879','136.23696083835614','136.236960838356140','test'),('2019-02-09 23:59:59','2019-02-10 03:59:59','BTSBTC','4h','0.000010940000000','0.000010850000000','0.001491794721180','0.001479522186911','136.36149188117','136.361491881169997','test'),('2019-02-12 15:59:59','2019-02-14 11:59:59','BTSBTC','4h','0.000011340000000','0.000011000000000','0.001491794721180','0.001447067189857','131.5515627142857','131.551562714285694','test'),('2019-02-14 15:59:59','2019-02-16 11:59:59','BTSBTC','4h','0.000011110000000','0.000011110000000','0.001491794721180','0.001491794721180','134.27495240144012','134.274952401440117','test'),('2019-02-16 15:59:59','2019-02-18 11:59:59','BTSBTC','4h','0.000011330000000','0.000011350000000','0.001491794721180','0.001494428074615','131.66767177228596','131.667671772285956','test'),('2019-02-18 19:59:59','2019-02-21 07:59:59','BTSBTC','4h','0.000011380000000','0.000011370000000','0.001491794721180','0.001490483829509','131.0891670632689','131.089167063268889','test'),('2019-02-22 19:59:59','2019-02-27 19:59:59','BTSBTC','4h','0.000011630000000','0.000011960000000','0.001491794721180','0.001534124236054','128.27125719518486','128.271257195184859','test'),('2019-03-07 03:59:59','2019-03-08 07:59:59','BTSBTC','4h','0.000012100000000','0.000012030000000','0.001491794721180','0.001483164503785','123.2888199322314','123.288819932231405','test'),('2019-03-08 15:59:59','2019-03-08 19:59:59','BTSBTC','4h','0.000011990000000','0.000012000000000','0.001491794721180','0.001493038920280','124.41991002335278','124.419910023352784','test'),('2019-03-09 15:59:59','2019-03-10 07:59:59','BTSBTC','4h','0.000012110000000','0.000011850000000','0.001491794721180','0.001459766097934','123.1870124838976','123.187012483897604','test'),('2019-03-12 11:59:59','2019-03-16 19:59:59','BTSBTC','4h','0.000012680000000','0.000012720000000','0.001491794721180','0.001496500698218','117.64942596056781','117.649425960567811','test'),('2019-03-23 03:59:59','2019-03-28 19:59:59','BTSBTC','4h','0.000013300000000','0.000014400000000','0.001491794721180','0.001615176239473','112.16501663007519','112.165016630075186','test'),('2019-03-30 03:59:59','2019-03-31 03:59:59','BTSBTC','4h','0.000015000000000','0.000014500000000','0.001491794721180','0.001442068230474','99.45298141199999','99.452981411999986','test'),('2019-04-01 11:59:59','2019-04-02 07:59:59','BTSBTC','4h','0.000014780000000','0.000013760000000','0.001491794721180','0.001388842717418','100.93333702165087','100.933337021650871','test'),('2019-04-05 11:59:59','2019-04-06 11:59:59','BTSBTC','4h','0.000014580000000','0.000014500000000','0.001491794721180','0.001483609290611','102.3178821111111','102.317882111111103','test'),('2019-04-06 15:59:59','2019-04-06 19:59:59','BTSBTC','4h','0.000014540000000','0.000014410000000','0.001491794721180','0.001478456804141','102.59936184181568','102.599361841815679','test'),('2019-04-06 23:59:59','2019-04-07 03:59:59','BTSBTC','4h','0.000014510000000','0.000014160000000','0.001491794721180','0.001455810699649','102.81149008821502','102.811490088215024','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  7:53:40
