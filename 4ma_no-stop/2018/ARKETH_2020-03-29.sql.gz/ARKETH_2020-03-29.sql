-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-18 19:59:59','2018-04-19 19:59:59','ARKETH','4h','0.005630000000000','0.005363000000000','0.072144500000000','0.068723082326821','12.81429840142096','12.814298401420960','test'),('2018-04-23 19:59:59','2018-04-23 23:59:59','ARKETH','4h','0.005373000000000','0.005312000000000','0.072144500000000','0.071325439047087','13.427228736273962','13.427228736273962','test'),('2018-04-28 11:59:59','2018-04-30 11:59:59','ARKETH','4h','0.005420000000000','0.005550000000000','0.072144500000000','0.073874903136531','13.310793357933578','13.310793357933578','test'),('2018-05-13 19:59:59','2018-05-14 23:59:59','ARKETH','4h','0.004985000000000','0.004798000000000','0.072144500000000','0.069438176730191','14.472316950852559','14.472316950852559','test'),('2018-05-15 07:59:59','2018-05-15 19:59:59','ARKETH','4h','0.004949000000000','0.004664000000000','0.072144500000000','0.067989886441705','14.577591432612648','14.577591432612648','test'),('2018-05-31 15:59:59','2018-06-01 23:59:59','ARKETH','4h','0.004399000000000','0.004244000000000','0.072144500000000','0.069602468288247','16.400204591952715','16.400204591952715','test'),('2018-06-02 03:59:59','2018-06-03 07:59:59','ARKETH','4h','0.004326000000000','0.004223000000000','0.072144500000000','0.070426773809524','16.676953305594083','16.676953305594083','test'),('2018-07-01 19:59:59','2018-07-05 19:59:59','ARKETH','4h','0.003071000000000','0.003191000000000','0.072144500000000','0.074963562194725','23.49218495604038','23.492184956040379','test'),('2018-07-06 19:59:59','2018-07-07 11:59:59','ARKETH','4h','0.003402000000000','0.003225000000000','0.072144500000000','0.068390950176367','21.2064961787184','21.206496178718400','test'),('2018-07-09 15:59:59','2018-07-10 23:59:59','ARKETH','4h','0.003385000000000','0.003170000000000','0.072144500000000','0.067562205317578','21.312998522895125','21.312998522895125','test'),('2018-07-18 15:59:59','2018-07-20 07:59:59','ARKETH','4h','0.003232000000000','0.003011000000000','0.072144500000000','0.067211351949257','22.32193688118812','22.321936881188119','test'),('2018-07-20 11:59:59','2018-07-20 15:59:59','ARKETH','4h','0.003066000000000','0.003024000000000','0.072144500000000','0.071156219178082','23.530495759947815','23.530495759947815','test'),('2018-08-12 07:59:59','2018-08-13 19:59:59','ARKETH','4h','0.002345000000000','0.002302000000000','0.072144500000000','0.070821594456290','30.76524520255864','30.765245202558638','test'),('2018-08-19 15:59:59','2018-08-19 23:59:59','ARKETH','4h','0.002341000000000','0.002284000000000','0.072144500000000','0.070387884664673','30.81781290046988','30.817812900469882','test'),('2018-08-20 03:59:59','2018-08-30 15:59:59','ARKETH','4h','0.002326000000000','0.003092000000000','0.072144500000000','0.095903178847807','31.016552020636286','31.016552020636286','test'),('2018-08-31 07:59:59','2018-09-01 07:59:59','ARKETH','4h','0.003245000000000','0.003160000000000','0.072144500000000','0.070254736517720','22.232511556240368','22.232511556240368','test'),('2018-09-07 19:59:59','2018-09-09 23:59:59','ARKETH','4h','0.003171000000000','0.003140000000000','0.072144500000000','0.071439208451593','22.75134027120782','22.751340271207820','test'),('2018-09-10 03:59:59','2018-09-13 03:59:59','ARKETH','4h','0.003142000000000','0.003157000000000','0.072144500000000','0.072488919955442','22.961330362826228','22.961330362826228','test'),('2018-09-16 23:59:59','2018-09-17 15:59:59','ARKETH','4h','0.003296000000000','0.003171000000000','0.072144500000000','0.069408437348301','21.888501213592235','21.888501213592235','test'),('2018-09-17 19:59:59','2018-09-18 15:59:59','ARKETH','4h','0.003301000000000','0.003221000000000','0.072144500000000','0.070396072250833','21.855346864586487','21.855346864586487','test'),('2018-09-18 19:59:59','2018-09-19 03:59:59','ARKETH','4h','0.003270000000000','0.003101000000000','0.072144500000000','0.068415931039755','22.062538226299694','22.062538226299694','test'),('2018-09-20 15:59:59','2018-09-20 23:59:59','ARKETH','4h','0.003309000000000','0.003152000000000','0.072144500000000','0.068721506195225','21.802508310667875','21.802508310667875','test'),('2018-09-21 11:59:59','2018-09-21 15:59:59','ARKETH','4h','0.003265000000000','0.003136000000000','0.072144500000000','0.069294074119449','22.096324655436447','22.096324655436447','test'),('2018-09-26 15:59:59','2018-09-26 19:59:59','ARKETH','4h','0.003199000000000','0.003175000000000','0.072144500000000','0.071603247108471','22.55220381369178','22.552203813691779','test'),('2018-09-26 23:59:59','2018-09-27 19:59:59','ARKETH','4h','0.003217000000000','0.003225000000000','0.072144500000000','0.072323908144234','22.426018029219772','22.426018029219772','test'),('2018-09-28 03:59:59','2018-09-28 11:59:59','ARKETH','4h','0.003221000000000','0.003171000000000','0.072144500000000','0.071024591586464','22.398168270723378','22.398168270723378','test'),('2018-09-29 03:59:59','2018-09-29 07:59:59','ARKETH','4h','0.003245000000000','0.003192000000000','0.072144500000000','0.070966176887519','22.232511556240368','22.232511556240368','test'),('2018-10-07 19:59:59','2018-10-08 19:59:59','ARKETH','4h','0.003241000000000','0.003160000000000','0.072144500000000','0.070341443998766','22.259950632520827','22.259950632520827','test'),('2018-10-08 23:59:59','2018-10-10 07:59:59','ARKETH','4h','0.003188000000000','0.003250000000000','0.072144500000000','0.073547561166876','22.630018820577167','22.630018820577167','test'),('2018-10-10 11:59:59','2018-10-15 07:59:59','ARKETH','4h','0.003400000000000','0.003298000000000','0.072144500000000','0.069980165000000','21.218970588235294','21.218970588235294','test'),('2018-10-16 15:59:59','2018-10-19 23:59:59','ARKETH','4h','0.003571000000000','0.003642000000000','0.072144500000000','0.073578904788575','20.202884346121536','20.202884346121536','test'),('2018-10-20 07:59:59','2018-10-22 03:59:59','ARKETH','4h','0.003708000000000','0.003656000000000','0.072144500000000','0.071132764832794','19.456445523193096','19.456445523193096','test'),('2018-10-22 23:59:59','2018-10-27 15:59:59','ARKETH','4h','0.003840000000000','0.003911000000000','0.072144500000000','0.073478421744792','18.787630208333333','18.787630208333333','test'),('2018-10-30 07:59:59','2018-11-03 19:59:59','ARKETH','4h','0.004062000000000','0.003990000000000','0.072144500000000','0.070865720088626','17.760832102412607','17.760832102412607','test'),('2018-11-22 07:59:59','2018-11-24 23:59:59','ARKETH','4h','0.003565000000000','0.003311000000000','0.072144500000000','0.067004330855540','20.23688639551192','20.236886395511920','test'),('2018-11-26 23:59:59','2018-11-27 11:59:59','ARKETH','4h','0.003454000000000','0.003500000000000','0.072144500000000','0.073105312680950','20.887232194557036','20.887232194557036','test'),('2018-11-27 15:59:59','2018-11-30 07:59:59','ARKETH','4h','0.003667000000000','0.003517000000000','0.072144500000000','0.069193402372512','19.673984183256067','19.673984183256067','test'),('2018-12-01 19:59:59','2018-12-03 03:59:59','ARKETH','4h','0.003650000000000','0.003477000000000','0.072144500000000','0.068725048356164','19.765616438356165','19.765616438356165','test'),('2018-12-03 19:59:59','2018-12-06 03:59:59','ARKETH','4h','0.003734000000000','0.003703000000000','0.072144500000000','0.071545549946438','19.32096946973755','19.320969469737548','test'),('2018-12-06 11:59:59','2018-12-06 15:59:59','ARKETH','4h','0.003752000000000','0.003576000000000','0.072144500000000','0.068760323027719','19.228278251599146','19.228278251599146','test'),('2018-12-07 07:59:59','2018-12-07 19:59:59','ARKETH','4h','0.003789000000000','0.003593000000000','0.072144500000000','0.068412559646345','19.0405120084455','19.040512008445500','test'),('2018-12-08 19:59:59','2018-12-08 23:59:59','ARKETH','4h','0.003807000000000','0.003622000000000','0.072144500000000','0.068638660099816','18.950485946939846','18.950485946939846','test'),('2018-12-15 23:59:59','2018-12-16 03:59:59','ARKETH','4h','0.003648000000000','0.003574000000000','0.072144500000000','0.070681042489035','19.77645285087719','19.776452850877192','test'),('2018-12-16 11:59:59','2018-12-16 15:59:59','ARKETH','4h','0.003597000000000','0.003530000000000','0.072144500000000','0.070800690853489','20.05685293299972','20.056852932999721','test'),('2018-12-16 23:59:59','2018-12-18 03:59:59','ARKETH','4h','0.003653000000000','0.003588000000000','0.072144500000000','0.070860790035587','19.749384067889405','19.749384067889405','test'),('2018-12-19 23:59:59','2018-12-20 19:59:59','ARKETH','4h','0.003710000000000','0.003615000000000','0.072144500000000','0.070297134097035','19.445956873315364','19.445956873315364','test'),('2019-01-07 23:59:59','2019-01-08 19:59:59','ARKETH','4h','0.002978000000000','0.003006000000000','0.072144500000000','0.072822823035594','24.22582269979852','24.225822699798520','test'),('2019-01-09 03:59:59','2019-01-11 23:59:59','ARKETH','4h','0.003012000000000','0.003093000000000','0.072144500000000','0.074084640936255','23.952357237715805','23.952357237715805','test'),('2019-01-13 19:59:59','2019-01-14 07:59:59','ARKETH','4h','0.003259000000000','0.003113000000000','0.072144500000000','0.068912497238417','22.137005216324024','22.137005216324024','test'),('2019-01-16 15:59:59','2019-01-21 11:59:59','ARKETH','4h','0.003180000000000','0.003363000000000','0.072144500000000','0.076296211792453','22.68694968553459','22.686949685534589','test'),('2019-01-21 19:59:59','2019-01-23 03:59:59','ARKETH','4h','0.003448000000000','0.003395000000000','0.072144500000000','0.071035550319026','20.923578886310903','20.923578886310903','test'),('2019-01-23 15:59:59','2019-01-23 23:59:59','ARKETH','4h','0.003461000000000','0.003386000000000','0.072144500000000','0.070581125975152','20.84498699797746','20.844986997977461','test'),('2019-01-24 19:59:59','2019-01-26 15:59:59','ARKETH','4h','0.003499000000000','0.003447000000000','0.072144500000000','0.071072332523578','20.618605315804515','20.618605315804515','test'),('2019-01-27 07:59:59','2019-01-31 11:59:59','ARKETH','4h','0.003570000000000','0.003561000000000','0.072144500000000','0.071962623109244','20.208543417366947','20.208543417366947','test'),('2019-02-03 11:59:59','2019-02-04 07:59:59','ARKETH','4h','0.003682000000000','0.003617000000000','0.072144500000000','0.070870900733297','19.593834872351984','19.593834872351984','test'),('2019-02-10 11:59:59','2019-02-12 19:59:59','ARKETH','4h','0.004389000000000','0.003925000000000','0.072144500000000','0.064517466962862','16.437571200729096','16.437571200729096','test'),('2019-02-13 07:59:59','2019-02-14 11:59:59','ARKETH','4h','0.004341000000000','0.004038000000000','0.072144500000000','0.067108843814789','16.61932734392997','16.619327343929971','test'),('2019-02-17 15:59:59','2019-02-17 23:59:59','ARKETH','4h','0.006457000000000','0.004659000000000','0.072144500000000','0.052055323757163','11.173067988229828','11.173067988229828','test'),('2019-02-18 07:59:59','2019-02-19 03:59:59','ARKETH','4h','0.004963000000000','0.004216000000000','0.048096333333333','0.040857171334542','9.690979918060311','9.690979918060311','test'),('2019-02-20 07:59:59','2019-02-20 15:59:59','ARKETH','4h','0.004676000000000','0.004419000000000','0.048335622612497','0.045679024021519','10.336959497967761','10.336959497967761','test'),('2019-02-27 19:59:59','2019-02-28 03:59:59','ARKETH','4h','0.004383000000000','0.004111000000000','0.048335622612497','0.045336012904398','11.027976868012093','11.027976868012093','test'),('2019-03-01 07:59:59','2019-03-01 15:59:59','ARKETH','4h','0.004283000000000','0.004190000000000','0.048335622612497','0.047286074888247','11.285459400536306','11.285459400536306','test'),('2019-03-01 23:59:59','2019-03-02 03:59:59','ARKETH','4h','0.004232000000000','0.004220000000000','0.048335622612497','0.048198565081460','11.421460919777175','11.421460919777175','test'),('2019-03-02 07:59:59','2019-03-02 15:59:59','ARKETH','4h','0.004256000000000','0.004209000000000','0.048335622612497','0.047801841065789','11.35705418526715','11.357054185267151','test'),('2019-03-02 19:59:59','2019-03-04 07:59:59','ARKETH','4h','0.004265000000000','0.004200000000000','0.048335622612497','0.047598971857559','11.333088537513952','11.333088537513952','test'),('2019-03-10 15:59:59','2019-03-11 07:59:59','ARKETH','4h','0.004448000000000','0.004257000000000','0.048335622612497','0.046260059681070','10.86682163050742','10.866821630507420','test'),('2019-03-11 15:59:59','2019-03-16 03:59:59','ARKETH','4h','0.004691000000000','0.004700000000000','0.048335622612497','0.048428357765665','10.30390590758836','10.303905907588360','test'),('2019-03-22 19:59:59','2019-03-22 23:59:59','ARKETH','4h','0.004624000000000','0.004648000000000','0.048335622612497','0.048586499546472','10.453205582287413','10.453205582287413','test'),('2019-03-23 11:59:59','2019-03-23 15:59:59','ARKETH','4h','0.004567000000000','0.004575000000000','0.048335622612497','0.048420291975514','10.583670377161594','10.583670377161594','test'),('2019-03-24 03:59:59','2019-03-24 07:59:59','ARKETH','4h','0.004604000000000','0.004589000000000','0.048335622612497','0.048178143390258','10.498614815920288','10.498614815920288','test'),('2019-03-24 11:59:59','2019-03-24 23:59:59','ARKETH','4h','0.004609000000000','0.004644000000000','0.048335622612497','0.048702675507146','10.487225561400955','10.487225561400955','test'),('2019-03-26 23:59:59','2019-03-29 15:59:59','ARKETH','4h','0.004711000000000','0.004800000000000','0.048335622612497','0.049248777019738','10.260161879112077','10.260161879112077','test'),('2019-03-30 23:59:59','2019-04-02 07:59:59','ARKETH','4h','0.004892000000000','0.004775000000000','0.048335622612497','0.047179598931863','9.880544278924162','9.880544278924162','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  6:09:10
