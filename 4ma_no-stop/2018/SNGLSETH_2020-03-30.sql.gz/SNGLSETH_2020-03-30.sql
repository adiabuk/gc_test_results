-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-20 23:59:59','2018-03-21 07:59:59','SNGLSETH','4h','0.000115500000000','0.000112870000000','0.072144500000000','0.070501729134199','624.6277056277056','624.627705627705609','test'),('2018-03-21 11:59:59','2018-03-21 19:59:59','SNGLSETH','4h','0.000117060000000','0.000114940000000','0.072144500000000','0.070837936357424','616.3036049888946','616.303604988894563','test'),('2018-03-21 23:59:59','2018-03-28 15:59:59','SNGLSETH','4h','0.000118990000000','0.000145750000000','0.072144500000000','0.088369282082528','606.3072527103118','606.307252710311786','test'),('2018-03-28 19:59:59','2018-03-29 15:59:59','SNGLSETH','4h','0.000147920000000','0.000142770000000','0.075463361893538','0.072836020670230','510.16334433165053','510.163344331650535','test'),('2018-04-01 11:59:59','2018-04-02 07:59:59','SNGLSETH','4h','0.000148600000000','0.000138990000000','0.075463361893538','0.070583126982388','507.8288148959488','507.828814895948824','test'),('2018-04-02 11:59:59','2018-04-03 03:59:59','SNGLSETH','4h','0.000143310000000','0.000138840000000','0.075463361893538','0.073109574804960','526.5742927467587','526.574292746758715','test'),('2018-04-03 11:59:59','2018-04-03 19:59:59','SNGLSETH','4h','0.000144650000000','0.000139080000000','0.075463361893538','0.072557513806798','521.6962453753059','521.696245375305921','test'),('2018-04-04 23:59:59','2018-04-06 19:59:59','SNGLSETH','4h','0.000143420000000','0.000141960000000','0.075463361893538','0.074695153077720','526.170421792902','526.170421792901948','test'),('2018-04-06 23:59:59','2018-04-07 19:59:59','SNGLSETH','4h','0.000142900000000','0.000141440000000','0.075463361893538','0.074692357636263','528.0851077224493','528.085107722449266','test'),('2018-04-08 03:59:59','2018-04-08 23:59:59','SNGLSETH','4h','0.000143800000000','0.000140350000000','0.075463361893538','0.073652870944076','524.7799853514465','524.779985351446498','test'),('2018-04-09 03:59:59','2018-04-09 11:59:59','SNGLSETH','4h','0.000145170000000','0.000140830000000','0.075463361893538','0.073207310432369','519.8275256150582','519.827525615058221','test'),('2018-04-09 19:59:59','2018-04-10 07:59:59','SNGLSETH','4h','0.000146710000000','0.000143180000000','0.075463361893538','0.073647632444392','514.3709487665326','514.370948766532592','test'),('2018-04-10 11:59:59','2018-04-13 07:59:59','SNGLSETH','4h','0.000145610000000','0.000178140000000','0.075463361893538','0.092322253194938','518.2567261420095','518.256726142009484','test'),('2018-04-17 15:59:59','2018-04-20 07:59:59','SNGLSETH','4h','0.000179490000000','0.000177050000000','0.075463361893538','0.074437507511566','420.43212375919546','420.432123759195463','test'),('2018-04-20 11:59:59','2018-04-20 23:59:59','SNGLSETH','4h','0.000181510000000','0.000167640000000','0.075463361893538','0.069696865119457','415.7531920750262','415.753192075026220','test'),('2018-04-30 07:59:59','2018-05-03 15:59:59','SNGLSETH','4h','0.000189130000000','0.000166300000000','0.075463361893538','0.066354132516763','399.00260082238674','399.002600822386739','test'),('2018-07-02 15:59:59','2018-07-05 15:59:59','SNGLSETH','4h','0.000086730000000','0.000084500000000','0.075463361893538','0.073523049463899','870.0952599277989','870.095259927798907','test'),('2018-07-08 15:59:59','2018-07-09 07:59:59','SNGLSETH','4h','0.000086060000000','0.000082840000000','0.075463361893538','0.072639843124107','876.8691830529631','876.869183052963081','test'),('2018-07-18 03:59:59','2018-07-20 03:59:59','SNGLSETH','4h','0.000083960000000','0.000082400000000','0.075463361893538','0.074061231777365','898.801356521415','898.801356521414959','test'),('2018-08-13 23:59:59','2018-08-14 23:59:59','SNGLSETH','4h','0.000074820000000','0.000070690000000','0.075463361893538','0.071297848867338','1008.598795690163','1008.598795690163001','test'),('2018-08-15 03:59:59','2018-08-15 15:59:59','SNGLSETH','4h','0.000072000000000','0.000072000000000','0.075463361893538','0.075463361893538','1048.1022485213612','1048.102248521361162','test'),('2018-08-15 19:59:59','2018-08-16 03:59:59','SNGLSETH','4h','0.000072290000000','0.000070990000000','0.075463361893538','0.074106294934600','1043.897660721234','1043.897660721233933','test'),('2018-08-16 23:59:59','2018-08-22 19:59:59','SNGLSETH','4h','0.000074360000000','0.000079680000000','0.075463361893538','0.080862300641166','1014.8381104564013','1014.838110456401296','test'),('2018-08-26 19:59:59','2018-08-29 23:59:59','SNGLSETH','4h','0.000086050000000','0.000083570000000','0.075463361893538','0.073288473601894','876.9710853403602','876.971085340360219','test'),('2018-08-31 19:59:59','2018-09-05 15:59:59','SNGLSETH','4h','0.000086570000000','0.000091180000000','0.075463361893538','0.079481914490618','871.70338331452','871.703383314520011','test'),('2018-09-07 15:59:59','2018-09-13 23:59:59','SNGLSETH','4h','0.000093730000000','0.000095980000000','0.075463361893538','0.077274869033839','805.1142845784487','805.114284578448746','test'),('2018-09-16 23:59:59','2018-09-19 03:59:59','SNGLSETH','4h','0.000133610000000','0.000111540000000','0.075463361893538','0.062998154222029','564.8032474630493','564.803247463049274','test'),('2018-09-25 19:59:59','2018-09-25 23:59:59','SNGLSETH','4h','0.000116200000000','0.000104140000000','0.075463361893538','0.067631278034364','649.4265223196041','649.426522319604146','test'),('2018-09-26 07:59:59','2018-09-26 15:59:59','SNGLSETH','4h','0.000107740000000','0.000102590000000','0.075463361893538','0.071856193583238','700.4210311262112','700.421031126211233','test'),('2018-10-02 03:59:59','2018-10-06 11:59:59','SNGLSETH','4h','0.000108520000000','0.000111200000000','0.075463361893538','0.077326998180625','695.3866742861961','695.386674286196126','test'),('2018-10-07 11:59:59','2018-10-07 19:59:59','SNGLSETH','4h','0.000113280000000','0.000114100000000','0.075463361893538','0.076009618573911','666.1666833822211','666.166683382221095','test'),('2018-10-08 03:59:59','2018-10-09 11:59:59','SNGLSETH','4h','0.000113120000000','0.000112670000000','0.075463361893538','0.075163162876104','667.1089276302864','667.108927630286416','test'),('2018-10-13 15:59:59','2018-10-17 15:59:59','SNGLSETH','4h','0.000120560000000','0.000133910000000','0.075463361893538','0.083819664823853','625.9402944055906','625.940294405590635','test'),('2018-10-22 11:59:59','2018-10-26 11:59:59','SNGLSETH','4h','0.000138680000000','0.000135240000000','0.075463361893538','0.073591470020782','544.1546141731901','544.154614173190112','test'),('2018-10-28 19:59:59','2018-10-29 11:59:59','SNGLSETH','4h','0.000139770000000','0.000135390000000','0.075463361893538','0.073098551668928','539.9110101848609','539.911010184860856','test'),('2018-10-29 15:59:59','2018-10-29 19:59:59','SNGLSETH','4h','0.000135500000000','0.000135450000000','0.075463361893538','0.075435515634537','556.9251800261108','556.925180026110752','test'),('2018-10-30 19:59:59','2018-11-04 03:59:59','SNGLSETH','4h','0.000143170000000','0.000145810000000','0.075463361893538','0.076854877402366','527.0892078894881','527.089207889488080','test'),('2018-11-10 07:59:59','2018-11-11 03:59:59','SNGLSETH','4h','0.000144970000000','0.000138290000000','0.075463361893538','0.071986123448006','520.5446774749121','520.544677474912078','test'),('2018-11-11 07:59:59','2018-11-11 15:59:59','SNGLSETH','4h','0.000140630000000','0.000134870000000','0.075463361893538','0.072372492487958','536.6092718021617','536.609271802161743','test'),('2018-11-29 15:59:59','2018-11-30 03:59:59','SNGLSETH','4h','0.000121230000000','0.000115730000000','0.075463361893538','0.072039716835265','622.4809196860348','622.480919686034781','test'),('2018-12-01 11:59:59','2018-12-03 15:59:59','SNGLSETH','4h','0.000118370000000','0.000120540000000','0.075463361893538','0.076846782484135','637.5210094917462','637.521009491746213','test'),('2018-12-05 15:59:59','2018-12-05 23:59:59','SNGLSETH','4h','0.000123740000000','0.000118540000000','0.075463361893538','0.072292119919670','609.8542257438015','609.854225743801521','test'),('2019-01-10 15:59:59','2019-01-14 19:59:59','SNGLSETH','4h','0.000074450000000','0.000076390000000','0.075463361893538','0.077429767831395','1013.6113081737811','1013.611308173781140','test'),('2019-01-15 11:59:59','2019-01-21 15:59:59','SNGLSETH','4h','0.000079600000000','0.000098510000000','0.075463361893538','0.093390650504176','948.032184592186','948.032184592186013','test'),('2019-01-21 19:59:59','2019-01-22 03:59:59','SNGLSETH','4h','0.000099620000000','0.000098520000000','0.075463361893538','0.074630098511859','757.5121651629994','757.512165162999395','test'),('2019-01-22 11:59:59','2019-01-30 15:59:59','SNGLSETH','4h','0.000101520000000','0.000124520000000','0.075463361893538','0.092560065238213','743.3349280293342','743.334928029334151','test'),('2019-02-22 15:59:59','2019-02-23 11:59:59','SNGLSETH','4h','0.000111780000000','0.000092000000000','0.075463361893538','0.062109762875340','675.1061182102164','675.106118210216437','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','SNGLSETH','4h','0.000092140000000','0.000088830000000','0.075463361893538','0.072752446678999','819.0076176854569','819.007617685456921','test'),('2019-02-26 11:59:59','2019-02-27 11:59:59','SNGLSETH','4h','0.000095720000000','0.000092230000000','0.075463361893538','0.072711929246145','788.3761167314877','788.376116731487741','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','SNGLSETH','4h','0.000092240000000','0.000092730000000','0.075463361893538','0.075864240550605','818.1197082994146','818.119708299414583','test'),('2019-02-28 23:59:59','2019-03-06 07:59:59','SNGLSETH','4h','0.000095390000000','0.000104110000000','0.075463361893538','0.082361784324733','791.1034898158925','791.103489815892544','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  3:29:42
