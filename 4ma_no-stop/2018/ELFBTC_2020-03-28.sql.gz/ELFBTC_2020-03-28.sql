-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 11:59:59','2018-07-06 03:59:59','ELFBTC','4h','0.000098150000000','0.000109150000000','0.001467500000000','0.001631967651554','14.951604686704025','14.951604686704025','test'),('2018-07-17 23:59:59','2018-07-19 19:59:59','ELFBTC','4h','0.000100240000000','0.000099960000000','0.001508616912888','0.001504402899165','15.05004901125798','15.050049011257981','test'),('2018-07-19 23:59:59','2018-07-20 03:59:59','ELFBTC','4h','0.000101960000000','0.000097630000000','0.001508616912888','0.001444549521432','14.79616430843468','14.796164308434680','test'),('2018-08-08 19:59:59','2018-08-10 03:59:59','ELFBTC','4h','0.000077800000000','0.000076550000000','0.001508616912888','0.001484378209275','19.39096289059126','19.390962890591261','test'),('2018-08-27 23:59:59','2018-08-29 15:59:59','ELFBTC','4h','0.000062670000000','0.000057740000000','0.001508616912888','0.001389940011970','24.07239369535663','24.072393695356631','test'),('2018-09-02 07:59:59','2018-09-02 11:59:59','ELFBTC','4h','0.000061200000000','0.000057320000000','0.001508616912888','0.001412972572659','24.650603151764706','24.650603151764706','test'),('2018-09-02 15:59:59','2018-09-02 19:59:59','ELFBTC','4h','0.000058080000000','0.000058500000000','0.001508616912888','0.001519526332713','25.974809106198347','25.974809106198347','test'),('2018-09-02 23:59:59','2018-09-03 03:59:59','ELFBTC','4h','0.000059660000000','0.000058320000000','0.001508616912888','0.001474732456581','25.286907691719744','25.286907691719744','test'),('2018-09-03 15:59:59','2018-09-05 11:59:59','ELFBTC','4h','0.000059890000000','0.000059300000000','0.001508616912888','0.001493754932948','25.189796508398732','25.189796508398732','test'),('2018-09-22 15:59:59','2018-09-24 03:59:59','ELFBTC','4h','0.000052240000000','0.000052310000000','0.001508616912888','0.001510638413346','28.878577964931086','28.878577964931086','test'),('2018-09-29 19:59:59','2018-09-29 23:59:59','ELFBTC','4h','0.000051980000000','0.000051100000000','0.001508616912888','0.001483076649646','29.02302641185071','29.023026411850712','test'),('2018-09-30 03:59:59','2018-09-30 23:59:59','ELFBTC','4h','0.000051590000000','0.000051310000000','0.001508616912888','0.001500429032764','29.242429015080443','29.242429015080443','test'),('2018-10-01 03:59:59','2018-10-01 07:59:59','ELFBTC','4h','0.000051580000000','0.000052040000000','0.001508616912888','0.001522071038129','29.248098349903064','29.248098349903064','test'),('2018-10-01 11:59:59','2018-10-03 23:59:59','ELFBTC','4h','0.000052230000000','0.000053140000000','0.001508616912888','0.001534901450333','28.88410708190695','28.884107081906951','test'),('2018-10-04 15:59:59','2018-10-04 23:59:59','ELFBTC','4h','0.000053890000000','0.000053170000000','0.001508616912888','0.001488460962298','27.99437581903878','27.994375819038780','test'),('2018-10-08 11:59:59','2018-10-09 15:59:59','ELFBTC','4h','0.000053520000000','0.000052960000000','0.001508616912888','0.001492831683605','28.187909433632285','28.187909433632285','test'),('2018-10-09 19:59:59','2018-10-10 03:59:59','ELFBTC','4h','0.000053410000000','0.000052640000000','0.001508616912888','0.001486867520959','28.24596354405542','28.245963544055421','test'),('2018-10-10 15:59:59','2018-10-11 03:59:59','ELFBTC','4h','0.000053940000000','0.000052540000000','0.001508616912888','0.001469461116113','27.968426267853168','27.968426267853168','test'),('2018-10-20 07:59:59','2018-10-21 15:59:59','ELFBTC','4h','0.000053210000000','0.000052000000000','0.001508616912888','0.001474310833869','28.352131420560045','28.352131420560045','test'),('2018-10-26 11:59:59','2018-10-26 15:59:59','ELFBTC','4h','0.000051540000000','0.000051370000000','0.001508616912888','0.001503640877281','29.27079768894063','29.270797688940629','test'),('2018-10-27 11:59:59','2018-10-27 19:59:59','ELFBTC','4h','0.000051740000000','0.000051890000000','0.001508616912888','0.001512990560683','29.157651969230766','29.157651969230766','test'),('2018-10-28 03:59:59','2018-10-28 07:59:59','ELFBTC','4h','0.000051960000000','0.000051890000000','0.001508616912888','0.001506584519048','29.03419770762125','29.034197707621249','test'),('2018-10-28 11:59:59','2018-10-28 15:59:59','ELFBTC','4h','0.000051900000000','0.000051670000000','0.001508616912888','0.001501931327340','29.067763254104044','29.067763254104044','test'),('2018-10-28 19:59:59','2018-10-29 11:59:59','ELFBTC','4h','0.000052050000000','0.000050740000000','0.001508616912888','0.001470647880114','28.983994483919307','28.983994483919307','test'),('2018-12-01 07:59:59','2018-12-02 07:59:59','ELFBTC','4h','0.000034320000000','0.000033080000000','0.001508616912888','0.001454109775010','43.95736925664336','43.957369256643361','test'),('2018-12-02 19:59:59','2018-12-03 15:59:59','ELFBTC','4h','0.000032990000000','0.000032600000000','0.001508616912888','0.001490782399520','45.72952145765383','45.729521457653831','test'),('2018-12-03 19:59:59','2018-12-03 23:59:59','ELFBTC','4h','0.000033100000000','0.000033000000000','0.001508616912888','0.001504059157864','45.577550238308156','45.577550238308156','test'),('2018-12-09 19:59:59','2018-12-11 07:59:59','ELFBTC','4h','0.000034330000000','0.000032160000000','0.001508616912888','0.001413257207063','43.944564896242355','43.944564896242355','test'),('2018-12-22 03:59:59','2018-12-24 23:59:59','ELFBTC','4h','0.000032710000000','0.000031840000000','0.001508616912888','0.001468491669409','46.12096951660043','46.120969516600432','test'),('2019-01-04 23:59:59','2019-01-07 03:59:59','ELFBTC','4h','0.000031260000000','0.000030090000000','0.001508616912888','0.001452152364325','48.26029791708253','48.260297917082532','test'),('2019-01-17 11:59:59','2019-01-18 11:59:59','ELFBTC','4h','0.000031370000000','0.000029440000000','0.001508616912888','0.001415801144897','48.0910714978642','48.091071497864199','test'),('2019-01-18 15:59:59','2019-01-18 19:59:59','ELFBTC','4h','0.000029530000000','0.000029910000000','0.001508616912888','0.001528030201980','51.08760287463596','51.087602874635962','test'),('2019-01-19 03:59:59','2019-01-20 15:59:59','ELFBTC','4h','0.000030070000000','0.000030530000000','0.001508616912888','0.001531695189573','50.17016670728301','50.170166707283009','test'),('2019-01-21 03:59:59','2019-01-21 19:59:59','ELFBTC','4h','0.000030880000000','0.000030650000000','0.001508616912888','0.001497380452721','48.854174640155435','48.854174640155435','test'),('2019-01-22 23:59:59','2019-01-23 03:59:59','ELFBTC','4h','0.000030920000000','0.000031120000000','0.001508616912888','0.001518375107667','48.79097389676584','48.790973896765841','test'),('2019-01-23 11:59:59','2019-01-23 23:59:59','ELFBTC','4h','0.000031270000000','0.000030420000000','0.001508616912888','0.001467608778064','48.244864499136554','48.244864499136554','test'),('2019-01-24 03:59:59','2019-01-25 15:59:59','ELFBTC','4h','0.000031710000000','0.000031080000000','0.001508616912888','0.001478644391440','47.57543087000946','47.575430870009463','test'),('2019-02-07 15:59:59','2019-02-09 11:59:59','ELFBTC','4h','0.000031970000000','0.000030160000000','0.001508616912888','0.001423205695737','47.18851776315295','47.188517763152952','test'),('2019-02-09 15:59:59','2019-02-09 19:59:59','ELFBTC','4h','0.000030250000000','0.000030150000000','0.001508616912888','0.001503629749540','49.87163348390082','49.871633483900823','test'),('2019-02-11 03:59:59','2019-02-11 15:59:59','ELFBTC','4h','0.000030700000000','0.000030030000000','0.001508616912888','0.001475692700131','49.14061605498371','49.140616054983710','test'),('2019-02-15 03:59:59','2019-02-18 07:59:59','ELFBTC','4h','0.000030510000000','0.000032850000000','0.001508616912888','0.001624322044850','49.44663759056047','49.446637590560471','test'),('2019-02-20 11:59:59','2019-02-22 19:59:59','ELFBTC','4h','0.000034940000000','0.000034190000000','0.001508616912888','0.001476233893865','43.177358697424154','43.177358697424154','test'),('2019-02-22 23:59:59','2019-02-24 19:59:59','ELFBTC','4h','0.000034440000000','0.000034990000000','0.001508616912888','0.001532709227118','43.80420769128919','43.804207691289193','test'),('2019-02-24 23:59:59','2019-02-28 23:59:59','ELFBTC','4h','0.000035010000000','0.000039970000000','0.001508616912888','0.001722348414971','43.09102864575836','43.091028645758357','test'),('2019-03-01 03:59:59','2019-03-02 15:59:59','ELFBTC','4h','0.000041290000000','0.000039830000000','0.001508616912888','0.001455272744983','36.5371013051102','36.537101305110198','test'),('2019-03-07 03:59:59','2019-03-07 07:59:59','ELFBTC','4h','0.000039290000000','0.000038620000000','0.001508616912888','0.001482890943643','38.39696902234665','38.396969022346653','test'),('2019-03-07 11:59:59','2019-03-14 11:59:59','ELFBTC','4h','0.000038980000000','0.000043080000000','0.001508616912888','0.001667296475301','38.7023322957414','38.702332295741400','test'),('2019-03-21 07:59:59','2019-03-21 15:59:59','ELFBTC','4h','0.000043810000000','0.000042180000000','0.001508616912888','0.001452487135029','34.435446539328915','34.435446539328915','test'),('2019-03-21 19:59:59','2019-03-21 23:59:59','ELFBTC','4h','0.000042660000000','0.000042250000000','0.001508616912888','0.001494117781751','35.36373447932489','35.363734479324890','test'),('2019-03-22 03:59:59','2019-03-22 11:59:59','ELFBTC','4h','0.000043040000000','0.000042970000000','0.001508616912888','0.001506163307314','35.05150819907063','35.051508199070632','test'),('2019-03-22 23:59:59','2019-03-23 11:59:59','ELFBTC','4h','0.000043330000000','0.000042900000000','0.001508616912888','0.001493645639578','34.816914675467345','34.816914675467345','test'),('2019-03-24 11:59:59','2019-03-26 11:59:59','ELFBTC','4h','0.000043450000000','0.000042920000000','0.001508616912888','0.001490214911419','34.72075748879171','34.720757488791712','test'),('2019-03-26 23:59:59','2019-03-30 03:59:59','ELFBTC','4h','0.000044120000000','0.000044560000000','0.001508616912888','0.001523662049825','34.193493039165915','34.193493039165915','test'),('2019-04-01 11:59:59','2019-04-02 03:59:59','ELFBTC','4h','0.000045280000000','0.000043470000000','0.001508616912888','0.001448312217386','33.3175113270318','33.317511327031802','test'),('2019-04-05 11:59:59','2019-04-06 15:59:59','ELFBTC','4h','0.000045690000000','0.000044130000000','0.001508616912888','0.001457107996624','33.01853606671044','33.018536066710439','test'),('2019-04-06 23:59:59','2019-04-07 03:59:59','ELFBTC','4h','0.000044050000000','0.000045000000000','0.001508616912888','0.001541152351418','34.24783003150965','34.247830031509650','test'),('2019-05-17 07:59:59','2019-05-19 07:59:59','ELFBTC','4h','0.000027190000000','0.000026490000000','0.001508616912888','0.001469777933888','55.484255714895184','55.484255714895184','test'),('2019-05-19 11:59:59','2019-05-26 15:59:59','ELFBTC','4h','0.000027000000000','0.000029210000000','0.001508616912888','0.001632100000943','55.874700477333334','55.874700477333334','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:52:51
