-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-14 23:59:59','2018-04-15 15:59:59','REQETH','4h','0.000413990000000','0.000400930000000','0.072144500000000','0.069868582296674','174.2662866252808','174.266286625280799','test'),('2018-04-15 19:59:59','2018-04-16 03:59:59','REQETH','4h','0.000410990000000','0.000395820000000','0.072144500000000','0.069481583469184','175.53833426604052','175.538334266040522','test'),('2018-04-16 07:59:59','2018-04-16 11:59:59','REQETH','4h','0.000396190000000','0.000390390000000','0.072144500000000','0.071088344872410','182.0957116534996','182.095711653499592','test'),('2018-04-16 19:59:59','2018-04-17 19:59:59','REQETH','4h','0.000414450000000','0.000401660000000','0.072144500000000','0.069918108022681','174.07286765592954','174.072867655929542','test'),('2018-04-17 23:59:59','2018-04-18 03:59:59','REQETH','4h','0.000404070000000','0.000400990000000','0.072144500000000','0.071594582757938','178.54455911104512','178.544559111045118','test'),('2018-04-18 07:59:59','2018-04-19 19:59:59','REQETH','4h','0.000404570000000','0.000406550000000','0.072144500000000','0.072497581320909','178.3238994487975','178.323899448797505','test'),('2018-04-29 19:59:59','2018-04-30 03:59:59','REQETH','4h','0.000393640000000','0.000383650000000','0.072144500000000','0.070313579476171','183.2753277105985','183.275327710598503','test'),('2018-04-30 11:59:59','2018-04-30 15:59:59','REQETH','4h','0.000382680000000','0.000425650000000','0.072144500000000','0.080245391515104','188.52435455210622','188.524354552106217','test'),('2018-05-01 07:59:59','2018-05-03 07:59:59','REQETH','4h','0.000413810000000','0.000404590000000','0.072144500000000','0.070537065936058','174.34208936468426','174.342089364684256','test'),('2018-06-18 23:59:59','2018-06-19 07:59:59','REQETH','4h','0.000203050000000','0.000191920000000','0.072144500000000','0.068189965230239','355.30411228761386','355.304112287613862','test'),('2018-07-03 03:59:59','2018-07-03 15:59:59','REQETH','4h','0.000182600000000','0.000171020000000','0.072144500000000','0.067569290197152','395.0958378970427','395.095837897042713','test'),('2018-07-03 19:59:59','2018-07-03 23:59:59','REQETH','4h','0.000171880000000','0.000170590000000','0.072144500000000','0.071603038486153','419.7376076332325','419.737607633232528','test'),('2018-07-04 00:22:26','2018-07-04 11:59:59','REQETH','4h','0.000171000000000','0.000173600000000','0.072144500000000','0.073241433918129','421.8976608187134','421.897660818713405','test'),('2018-07-04 15:59:59','2018-07-05 19:59:59','REQETH','4h','0.000179130000000','0.000171220000000','0.072144500000000','0.068958752246971','402.74939987718415','402.749399877184146','test'),('2018-07-19 11:59:59','2018-07-20 15:59:59','REQETH','4h','0.000174420000000','0.000164510000000','0.072144500000000','0.068045474687536','413.62515766540537','413.625157665405368','test'),('2018-08-10 23:59:59','2018-08-11 11:59:59','REQETH','4h','0.000130780000000','0.000125850000000','0.072144500000000','0.069424876319009','551.6478054748433','551.647805474843267','test'),('2018-08-17 19:59:59','2018-08-29 15:59:59','REQETH','4h','0.000135200000000','0.000162610000000','0.072144500000000','0.086770836871302','533.6131656804733','533.613165680473344','test'),('2018-08-31 15:59:59','2018-09-02 15:59:59','REQETH','4h','0.000172270000000','0.000165470000000','0.072144500000000','0.069296745893075','418.787368665467','418.787368665467000','test'),('2018-09-02 23:59:59','2018-09-03 07:59:59','REQETH','4h','0.000174190000000','0.000168810000000','0.072144500000000','0.069916258367300','414.17130719329464','414.171307193294638','test'),('2018-09-03 23:59:59','2018-09-05 11:59:59','REQETH','4h','0.000171280000000','0.000169710000000','0.072144500000000','0.071483203497198','421.20796356842595','421.207963568425953','test'),('2018-09-05 15:59:59','2018-09-05 19:59:59','REQETH','4h','0.000170960000000','0.000167740000000','0.072144500000000','0.070785671677585','421.9963734206832','421.996373420683199','test'),('2018-09-07 15:59:59','2018-09-08 19:59:59','REQETH','4h','0.000178330000000','0.000170000000000','0.072144500000000','0.068774547187798','404.55615992822294','404.556159928222939','test'),('2018-09-08 23:59:59','2018-09-10 19:59:59','REQETH','4h','0.000173940000000','0.000173660000000','0.072144500000000','0.072028365355870','414.7665861791422','414.766586179142223','test'),('2018-09-11 03:59:59','2018-09-11 19:59:59','REQETH','4h','0.000176800000000','0.000173960000000','0.072144500000000','0.070985617760181','408.0571266968326','408.057126696832597','test'),('2018-09-17 19:59:59','2018-09-21 19:59:59','REQETH','4h','0.000181900000000','0.000172880000000','0.072144500000000','0.068567021220451','396.6162726772952','396.616272677295228','test'),('2018-09-25 15:59:59','2018-09-29 11:59:59','REQETH','4h','0.000182980000000','0.000181800000000','0.072144500000000','0.071679255109848','394.2753306372281','394.275330637228080','test'),('2018-09-29 15:59:59','2018-10-06 19:59:59','REQETH','4h','0.000187650000000','0.000203200000000','0.072144500000000','0.078122901145750','384.46309618971486','384.463096189714861','test'),('2018-10-10 23:59:59','2018-10-11 03:59:59','REQETH','4h','0.000206830000000','0.000204490000000','0.072144500000000','0.071328283155248','348.8106174152686','348.810617415268609','test'),('2018-10-11 15:59:59','2018-10-21 15:59:59','REQETH','4h','0.000215300000000','0.000306500000000','0.072144500000000','0.102704548304691','335.0882489549466','335.088248954946607','test'),('2018-11-02 07:59:59','2018-11-02 23:59:59','REQETH','4h','0.000272180000000','0.000258390000000','0.075352101574654','0.071534387265320','276.8465779067299','276.846577906729920','test'),('2018-11-27 03:59:59','2018-11-28 23:59:59','REQETH','4h','0.000257590000000','0.000210000000000','0.075352101574654','0.061430728408235','292.527278134454','292.527278134453979','test'),('2018-11-29 07:59:59','2018-11-30 07:59:59','REQETH','4h','0.000226710000000','0.000218000000000','0.075352101574654','0.072457139708326','332.3722004969079','332.372200496907908','test'),('2018-12-01 03:59:59','2018-12-02 11:59:59','REQETH','4h','0.000223580000000','0.000217300000000','0.075352101574654','0.073235583111961','337.0252329128455','337.025232912845524','test'),('2018-12-02 15:59:59','2018-12-03 03:59:59','REQETH','4h','0.000227710000000','0.000219080000000','0.075352101574654','0.072496326085702','330.9125711416011','330.912571141601120','test'),('2018-12-03 07:59:59','2018-12-04 07:59:59','REQETH','4h','0.000230730000000','0.000223000000000','0.075352101574654','0.072827628185099','326.58129230986','326.581292309859975','test'),('2018-12-04 11:59:59','2018-12-04 15:59:59','REQETH','4h','0.000224380000000','0.000226610000000','0.075352101574654','0.076100988224585','335.8236098344505','335.823609834450508','test'),('2018-12-06 11:59:59','2018-12-06 23:59:59','REQETH','4h','0.000232500000000','0.000219890000000','0.075352101574654','0.071265262861293','324.0950605361462','324.095060536146207','test'),('2018-12-07 03:59:59','2018-12-07 07:59:59','REQETH','4h','0.000223520000000','0.000215750000000','0.075352101574654','0.072732712574855','337.11570138982637','337.115701389826370','test'),('2018-12-08 11:59:59','2018-12-08 19:59:59','REQETH','4h','0.000230090000000','0.000228140000000','0.075352101574654','0.074713496689302','327.4896847957495','327.489684795749497','test'),('2018-12-09 03:59:59','2018-12-09 15:59:59','REQETH','4h','0.000228060000000','0.000226520000000','0.075352101574654','0.074843278298214','330.4047249612119','330.404724961211912','test'),('2018-12-09 23:59:59','2018-12-10 19:59:59','REQETH','4h','0.000227310000000','0.000225200000000','0.075352101574654','0.074652647374124','331.49488176786764','331.494881767867639','test'),('2018-12-11 07:59:59','2018-12-14 03:59:59','REQETH','4h','0.000228900000000','0.000230380000000','0.075352101574654','0.075839306075879','329.1922305576845','329.192230557684525','test'),('2019-01-08 23:59:59','2019-01-10 07:59:59','REQETH','4h','0.000170440000000','0.000163130000000','0.075352101574654','0.072120325803059','442.10338872714146','442.103388727141464','test'),('2019-01-10 11:59:59','2019-01-10 19:59:59','REQETH','4h','0.000166840000000','0.000163000000000','0.075352101574654','0.073617792835463','451.6429008310597','451.642900831059706','test'),('2019-01-11 11:59:59','2019-01-12 03:59:59','REQETH','4h','0.000168620000000','0.000162320000000','0.075352101574654','0.072536787614742','446.87523173202464','446.875231732024645','test'),('2019-01-13 19:59:59','2019-01-14 15:59:59','REQETH','4h','0.000170490000000','0.000161710000000','0.075352101574654','0.071471572207386','441.97373203504014','441.973732035040143','test'),('2019-01-15 19:59:59','2019-01-22 23:59:59','REQETH','4h','0.000168910000000','0.000189010000000','0.075352101574654','0.084318872290719','446.10799582413114','446.107995824131137','test'),('2019-01-25 07:59:59','2019-01-27 15:59:59','REQETH','4h','0.000192140000000','0.000189500000000','0.075352101574654','0.074316765110841','392.17290295958156','392.172902959581563','test'),('2019-01-27 23:59:59','2019-01-28 03:59:59','REQETH','4h','0.000192330000000','0.000192490000000','0.075352101574654','0.075414787251626','391.7854810723964','391.785481072396408','test'),('2019-01-30 11:59:59','2019-01-31 03:59:59','REQETH','4h','0.000195350000000','0.000190560000000','0.075352101574654','0.073504461100927','385.72870015179933','385.728700151799330','test'),('2019-03-01 07:59:59','2019-03-04 07:59:59','REQETH','4h','0.000158090000000','0.000159190000000','0.075352101574654','0.075876406158955','476.64053118257954','476.640531182579537','test'),('2019-03-04 15:59:59','2019-03-05 19:59:59','REQETH','4h','0.000160890000000','0.000155830000000','0.075352101574654','0.072982273530849','468.3454632025234','468.345463202523376','test'),('2019-03-09 03:59:59','2019-03-16 15:59:59','REQETH','4h','0.000163850000000','0.000186430000000','0.075352101574654','0.085736297202092','459.88466020539516','459.884660205395164','test'),('2019-03-17 23:59:59','2019-03-18 23:59:59','REQETH','4h','0.000193310000000','0.000189640000000','0.075352101574654','0.073921538164696','389.79929426648386','389.799294266483855','test'),('2019-03-21 03:59:59','2019-03-21 15:59:59','REQETH','4h','0.000190990000000','0.000183110000000','0.075352101574654','0.072243171471464','394.53427705457875','394.534277054578752','test'),('2019-03-27 15:59:59','2019-03-29 23:59:59','REQETH','4h','0.000219480000000','0.000190730000000','0.075352101574654','0.065481621711927','343.32103870354473','343.321038703544730','test'),('2019-03-31 19:59:59','2019-04-02 07:59:59','REQETH','4h','0.000197620000000','0.000203790000000','0.075352101574654','0.077704709947873','381.29795352015987','381.297953520159865','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31 10:52:19
