-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-28 15:59:59','2018-04-29 11:59:59','RCNBTC','4h','0.000016100000000','0.000015550000000','0.001467500000000','0.001417368012422','91.14906832298138','91.149068322981378','test'),('2018-04-29 15:59:59','2018-05-01 03:59:59','RCNBTC','4h','0.000016260000000','0.000015760000000','0.001467500000000','0.001422373923739','90.25215252152522','90.252152521525218','test'),('2018-05-01 07:59:59','2018-05-01 15:59:59','RCNBTC','4h','0.000016230000000','0.000016150000000','0.001467500000000','0.001460266481824','90.41897720271103','90.418977202711034','test'),('2018-05-01 19:59:59','2018-05-06 07:59:59','RCNBTC','4h','0.000016280000000','0.000016300000000','0.001467500000000','0.001469302825553','90.14127764127764','90.141277641277640','test'),('2018-07-03 03:59:59','2018-07-03 23:59:59','RCNBTC','4h','0.000008370000000','0.000007500000000','0.001467500000000','0.001314964157706','175.32855436081243','175.328554360812433','test'),('2018-07-04 11:59:59','2018-07-06 11:59:59','RCNBTC','4h','0.000007840000000','0.000007490000000','0.001467500000000','0.001401986607143','187.1811224489796','187.181122448979607','test'),('2018-07-09 15:59:59','2018-07-09 19:59:59','RCNBTC','4h','0.000007820000000','0.000007810000000','0.001467500000000','0.001465623401535','187.6598465473146','187.659846547314601','test'),('2018-08-27 23:59:59','2018-08-28 19:59:59','RCNBTC','4h','0.000003260000000','0.000003210000000','0.001467500000000','0.001444992331288','450.15337423312883','450.153374233128829','test'),('2018-08-28 23:59:59','2018-08-29 03:59:59','RCNBTC','4h','0.000003220000000','0.000003130000000','0.001467500000000','0.001426482919255','455.74534161490686','455.745341614906863','test'),('2018-09-04 23:59:59','2018-09-05 11:59:59','RCNBTC','4h','0.000003200000000','0.000002860000000','0.001467500000000','0.001311578125000','458.59375000000006','458.593750000000057','test'),('2018-09-10 07:59:59','2018-09-11 07:59:59','RCNBTC','4h','0.000003400000000','0.000003090000000','0.001467500000000','0.001333698529412','431.61764705882354','431.617647058823536','test'),('2018-09-14 07:59:59','2018-09-14 11:59:59','RCNBTC','4h','0.000003180000000','0.000003090000000','0.001467500000000','0.001425966981132','461.47798742138366','461.477987421383659','test'),('2018-09-14 15:59:59','2018-09-21 15:59:59','RCNBTC','4h','0.000003130000000','0.000004130000000','0.001467500000000','0.001936349840256','468.84984025559106','468.849840255591062','test'),('2018-09-22 23:59:59','2018-09-24 07:59:59','RCNBTC','4h','0.000004550000000','0.000004240000000','0.001467500000000','0.001367516483516','322.5274725274726','322.527472527472582','test'),('2018-09-29 07:59:59','2018-10-01 03:59:59','RCNBTC','4h','0.000004330000000','0.000004210000000','0.001467500000000','0.001426830254042','338.9145496535797','338.914549653579684','test'),('2018-10-04 23:59:59','2018-10-07 15:59:59','RCNBTC','4h','0.000004360000000','0.000004410000000','0.001467500000000','0.001484329128440','336.5825688073395','336.582568807339499','test'),('2018-10-09 07:59:59','2018-10-11 03:59:59','RCNBTC','4h','0.000004540000000','0.000004320000000','0.001467500000000','0.001396387665198','323.2378854625551','323.237885462555084','test'),('2018-10-18 11:59:59','2018-10-18 15:59:59','RCNBTC','4h','0.000004460000000','0.000004300000000','0.001467500000000','0.001414854260090','329.0358744394619','329.035874439461907','test'),('2018-10-18 23:59:59','2018-10-19 03:59:59','RCNBTC','4h','0.000004300000000','0.000004360000000','0.001467500000000','0.001487976744186','341.27906976744185','341.279069767441854','test'),('2018-10-19 11:59:59','2018-10-19 15:59:59','RCNBTC','4h','0.000004320000000','0.000004380000000','0.001467500000000','0.001487881944444','339.6990740740741','339.699074074074076','test'),('2018-10-19 23:59:59','2018-10-20 03:59:59','RCNBTC','4h','0.000004320000000','0.000004270000000','0.001467500000000','0.001450515046296','339.6990740740741','339.699074074074076','test'),('2018-10-20 07:59:59','2018-10-20 11:59:59','RCNBTC','4h','0.000004390000000','0.000004370000000','0.001467500000000','0.001460814350797','334.2824601366743','334.282460136674274','test'),('2018-10-20 15:59:59','2018-10-25 07:59:59','RCNBTC','4h','0.000004480000000','0.000004630000000','0.001467500000000','0.001516635044643','327.5669642857143','327.566964285714278','test'),('2018-10-27 23:59:59','2018-10-30 07:59:59','RCNBTC','4h','0.000005300000000','0.000004970000000','0.001467500000000','0.001376127358491','276.8867924528302','276.886792452830207','test'),('2018-10-30 23:59:59','2018-10-31 15:59:59','RCNBTC','4h','0.000005280000000','0.000004970000000','0.001467500000000','0.001381339962121','277.93560606060606','277.935606060606062','test'),('2018-10-31 19:59:59','2018-11-03 19:59:59','RCNBTC','4h','0.000005180000000','0.000005170000000','0.001467500000000','0.001464666988417','283.3011583011583','283.301158301158296','test'),('2018-11-06 11:59:59','2018-11-09 15:59:59','RCNBTC','4h','0.000005630000000','0.000005360000000','0.001467500000000','0.001397122557726','260.65719360568386','260.657193605683858','test'),('2018-11-09 19:59:59','2018-11-10 11:59:59','RCNBTC','4h','0.000005450000000','0.000005230000000','0.001467500000000','0.001408261467890','269.26605504587155','269.266055045871553','test'),('2018-11-29 07:59:59','2018-11-30 11:59:59','RCNBTC','4h','0.000004090000000','0.000003720000000','0.001467500000000','0.001334743276284','358.80195599022005','358.801955990220051','test'),('2018-12-01 11:59:59','2018-12-06 03:59:59','RCNBTC','4h','0.000003990000000','0.000003950000000','0.001467500000000','0.001452788220551','367.7944862155389','367.794486215538882','test'),('2018-12-23 23:59:59','2018-12-25 03:59:59','RCNBTC','4h','0.000003450000000','0.000003290000000','0.001467500000000','0.001399442028986','425.36231884057975','425.362318840579746','test'),('2019-01-15 19:59:59','2019-01-15 23:59:59','RCNBTC','4h','0.000003300000000','0.000003100000000','0.001467500000000','0.001378560606061','444.6969696969697','444.696969696969688','test'),('2019-01-16 03:59:59','2019-01-22 19:59:59','RCNBTC','4h','0.000003200000000','0.000003470000000','0.001467500000000','0.001591320312500','458.59375000000006','458.593750000000057','test'),('2019-02-21 23:59:59','2019-02-24 19:59:59','RCNBTC','4h','0.000004040000000','0.000003880000000','0.001467500000000','0.001409381188119','363.24257425742576','363.242574257425758','test'),('2019-02-25 19:59:59','2019-02-28 11:59:59','RCNBTC','4h','0.000005140000000','0.000004870000000','0.001467500000000','0.001390413424125','285.5058365758755','285.505836575875492','test'),('2019-02-28 15:59:59','2019-03-03 15:59:59','RCNBTC','4h','0.000005330000000','0.000005160000000','0.001467500000000','0.001420694183865','275.328330206379','275.328330206379007','test'),('2019-03-05 03:59:59','2019-03-07 03:59:59','RCNBTC','4h','0.000005670000000','0.000005380000000','0.001467500000000','0.001392442680776','258.8183421516755','258.818342151675495','test'),('2019-03-08 11:59:59','2019-03-11 07:59:59','RCNBTC','4h','0.000006070000000','0.000005600000000','0.001467500000000','0.001353871499176','241.76276771004942','241.762767710049417','test'),('2019-03-12 23:59:59','2019-03-13 03:59:59','RCNBTC','4h','0.000006130000000','0.000005790000000','0.001467500000000','0.001386105220228','239.39641109298535','239.396411092985346','test'),('2019-03-15 15:59:59','2019-03-20 15:59:59','RCNBTC','4h','0.000006180000000','0.000006070000000','0.001467500000000','0.001441379449838','237.45954692556634','237.459546925566343','test'),('2019-03-28 07:59:59','2019-04-01 23:59:59','RCNBTC','4h','0.000006310000000','0.000007330000000','0.001467500000000','0.001704718700475','232.56735340729003','232.567353407290028','test'),('2019-04-16 23:59:59','2019-04-17 11:59:59','RCNBTC','4h','0.000006340000000','0.000006100000000','0.001467500000000','0.001411947949527','231.46687697160883','231.466876971608826','test'),('2019-04-17 15:59:59','2019-04-17 19:59:59','RCNBTC','4h','0.000006110000000','0.000005960000000','0.001467500000000','0.001431472995090','240.18003273322424','240.180032733224238','test'),('2019-04-19 19:59:59','2019-04-20 11:59:59','RCNBTC','4h','0.000006140000000','0.000006310000000','0.001467500000000','0.001508131107492','239.0065146579805','239.006514657980489','test'),('2019-04-21 03:59:59','2019-04-21 07:59:59','RCNBTC','4h','0.000006130000000','0.000006110000000','0.001467500000000','0.001462712071778','239.39641109298535','239.396411092985346','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:02:45
