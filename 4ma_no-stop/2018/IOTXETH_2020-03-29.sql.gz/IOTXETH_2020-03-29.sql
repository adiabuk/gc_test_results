-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-24 15:59:59','2018-11-24 23:59:59','IOTXETH','4h','0.000078870000000','0.000075140000000','0.072144500000000','0.068732569164448','914.7267655635857','914.726765563585673','test'),('2018-11-25 03:59:59','2018-11-25 07:59:59','IOTXETH','4h','0.000076950000000','0.000077320000000','0.072144500000000','0.072491393632229','937.5503573749188','937.550357374918804','test'),('2018-11-27 11:59:59','2018-11-27 19:59:59','IOTXETH','4h','0.000078190000000','0.000075580000000','0.072144500000000','0.069736300166262','922.6819286353755','922.681928635375471','test'),('2018-11-28 03:59:59','2018-11-28 07:59:59','IOTXETH','4h','0.000076970000000','0.000079520000000','0.072144500000000','0.074534632194361','937.306742886839','937.306742886838947','test'),('2018-11-28 11:59:59','2018-11-28 23:59:59','IOTXETH','4h','0.000081650000000','0.000077480000000','0.072144500000000','0.068459961543172','883.5823637477035','883.582363747703539','test'),('2018-11-29 07:59:59','2018-11-30 11:59:59','IOTXETH','4h','0.000080970000000','0.000075440000000','0.072144500000000','0.067217254291713','891.0028405582314','891.002840558231355','test'),('2018-11-30 19:59:59','2018-12-05 19:59:59','IOTXETH','4h','0.000082140000000','0.000081490000000','0.072144500000000','0.071573597577307','878.3114195276357','878.311419527635735','test'),('2018-12-06 07:59:59','2018-12-06 15:59:59','IOTXETH','4h','0.000083980000000','0.000081540000000','0.072144500000000','0.070048374970231','859.0676351512265','859.067635151226455','test'),('2018-12-06 19:59:59','2018-12-07 11:59:59','IOTXETH','4h','0.000085500000000','0.000081030000000','0.072144500000000','0.068372734912281','843.7953216374268','843.795321637426810','test'),('2018-12-15 15:59:59','2018-12-16 23:59:59','IOTXETH','4h','0.000084150000000','0.000083560000000','0.072144500000000','0.071638674034462','857.3321449792038','857.332144979203804','test'),('2018-12-17 15:59:59','2018-12-17 19:59:59','IOTXETH','4h','0.000082240000000','0.000080050000000','0.072144500000000','0.070223336879864','877.2434338521401','877.243433852140129','test'),('2018-12-20 15:59:59','2018-12-20 19:59:59','IOTXETH','4h','0.000081450000000','0.000079400000000','0.072144500000000','0.070328708410068','885.7519950890116','885.751995089011643','test'),('2019-01-12 23:59:59','2019-01-14 03:59:59','IOTXETH','4h','0.000056750000000','0.000055850000000','0.072144500000000','0.071000358149780','1271.2687224669605','1271.268722466960526','test'),('2019-01-14 07:59:59','2019-01-14 15:59:59','IOTXETH','4h','0.000056660000000','0.000054250000000','0.072144500000000','0.069075875838334','1273.2880338863395','1273.288033886339463','test'),('2019-01-16 07:59:59','2019-01-24 11:59:59','IOTXETH','4h','0.000056610000000','0.000064260000000','0.072144500000000','0.081893756756757','1274.4126479420597','1274.412647942059721','test'),('2019-01-28 15:59:59','2019-01-31 11:59:59','IOTXETH','4h','0.000066330000000','0.000062740000000','0.072144500000000','0.068239799939695','1087.6601839288408','1087.660183928840752','test'),('2019-02-26 19:59:59','2019-02-27 19:59:59','IOTXETH','4h','0.000054770000000','0.000053560000000','0.072144500000000','0.070550655833485','1317.2265838962937','1317.226583896293732','test'),('2019-02-27 23:59:59','2019-03-06 23:59:59','IOTXETH','4h','0.000054940000000','0.000061310000000','0.072144500000000','0.080509270021842','1313.1507098653076','1313.150709865307590','test'),('2019-03-07 11:59:59','2019-03-08 11:59:59','IOTXETH','4h','0.000064000000000','0.000061330000000','0.072144500000000','0.069134721640625','1127.2578125','1127.257812500000000','test'),('2019-03-10 11:59:59','2019-03-14 11:59:59','IOTXETH','4h','0.000067470000000','0.000066790000000','0.072144500000000','0.071417387801986','1069.2826441381355','1069.282644138135538','test'),('2019-03-18 19:59:59','2019-03-19 03:59:59','IOTXETH','4h','0.000068190000000','0.000066650000000','0.072144500000000','0.070515191743657','1057.9923742484236','1057.992374248423630','test'),('2019-03-19 07:59:59','2019-03-19 11:59:59','IOTXETH','4h','0.000067310000000','0.000067700000000','0.072144500000000','0.072562511513891','1071.8243945921854','1071.824394592185399','test'),('2019-03-20 11:59:59','2019-03-20 15:59:59','IOTXETH','4h','0.000067450000000','0.000067110000000','0.072144500000000','0.071780836100815','1069.5997034840623','1069.599703484062275','test'),('2019-03-20 23:59:59','2019-03-21 03:59:59','IOTXETH','4h','0.000066670000000','0.000066830000000','0.072144500000000','0.072317638143093','1082.1133943302834','1082.113394330283427','test'),('2019-03-21 07:59:59','2019-03-21 15:59:59','IOTXETH','4h','0.000067940000000','0.000067050000000','0.072144500000000','0.071199421916397','1061.8854871945834','1061.885487194583447','test'),('2019-03-22 03:59:59','2019-03-23 15:59:59','IOTXETH','4h','0.000067140000000','0.000067650000000','0.072144500000000','0.072692514521895','1074.5382782246054','1074.538278224605392','test'),('2019-03-23 19:59:59','2019-03-23 23:59:59','IOTXETH','4h','0.000067830000000','0.000067570000000','0.072144500000000','0.071867962037447','1063.6075482824708','1063.607548282470816','test'),('2019-03-26 07:59:59','2019-03-28 03:59:59','IOTXETH','4h','0.000068750000000','0.000069110000000','0.072144500000000','0.072522274836364','1049.3745454545453','1049.374545454545341','test'),('2019-03-28 15:59:59','2019-04-01 07:59:59','IOTXETH','4h','0.000069540000000','0.000071800000000','0.072144500000000','0.074489144377337','1037.4532643083116','1037.453264308311645','test'),('2019-04-03 23:59:59','2019-04-08 03:59:59','IOTXETH','4h','0.000079890000000','0.000092330000000','0.072144500000000','0.083378416385029','903.0479409187634','903.047940918763402','test'),('2019-04-15 07:59:59','2019-04-18 07:59:59','IOTXETH','4h','0.000092750000000','0.000089740000000','0.072144500000000','0.069803206792453','777.8382749326145','777.838274932614468','test'),('2019-05-23 19:59:59','2019-05-24 19:59:59','IOTXETH','4h','0.000050120000000','0.000045160000000','0.072144500000000','0.065004900638468','1439.4353551476456','1439.435355147645623','test'),('2019-05-24 23:59:59','2019-05-25 19:59:59','IOTXETH','4h','0.000045730000000','0.000046020000000','0.072144500000000','0.072602009403018','1577.6186310955609','1577.618631095560886','test'),('2019-05-26 03:59:59','2019-05-26 11:59:59','IOTXETH','4h','0.000047350000000','0.000046000000000','0.072144500000000','0.070087581837381','1523.6430834213306','1523.643083421330630','test'),('2019-06-08 23:59:59','2019-06-12 11:59:59','IOTXETH','4h','0.000044310000000','0.000044470000000','0.072144500000000','0.072405008237418','1628.1764838636877','1628.176483863687736','test'),('2019-07-11 15:59:59','2019-07-13 03:59:59','IOTXETH','4h','0.000031650000000','0.000031400000000','0.072144500000000','0.071574638230648','2279.447077409163','2279.447077409162830','test'),('2019-07-13 07:59:59','2019-07-14 03:59:59','IOTXETH','4h','0.000032060000000','0.000031150000000','0.072144500000000','0.070096730349345','2250.2963194011227','2250.296319401122673','test'),('2019-07-14 23:59:59','2019-07-17 15:59:59','IOTXETH','4h','0.000032180000000','0.000032550000000','0.072144500000000','0.072974004816656','2241.904909881914','2241.904909881914136','test'),('2019-07-19 03:59:59','2019-07-20 23:59:59','IOTXETH','4h','0.000034270000000','0.000033290000000','0.072144500000000','0.070081424131894','2105.17945725124','2105.179457251239910','test'),('2019-08-16 23:59:59','2019-08-18 15:59:59','IOTXETH','4h','0.000026390000000','0.000025710000000','0.072144500000000','0.070285528419856','2733.7817355058733','2733.781735505873257','test'),('2019-08-25 11:59:59','2019-08-26 03:59:59','IOTXETH','4h','0.000026610000000','0.000025390000000','0.072144500000000','0.068836860390831','2711.1800075159713','2711.180007515971283','test'),('2019-08-26 07:59:59','2019-08-26 11:59:59','IOTXETH','4h','0.000026670000000','0.000026260000000','0.072144500000000','0.071035416947882','2705.0806149231344','2705.080614923134362','test'),('2019-08-26 15:59:59','2019-08-29 11:59:59','IOTXETH','4h','0.000026320000000','0.000025440000000','0.072144500000000','0.069732373860182','2741.052431610942','2741.052431610942222','test'),('2019-08-30 23:59:59','2019-09-01 11:59:59','IOTXETH','4h','0.000026150000000','0.000026130000000','0.072144500000000','0.072089322562141','2758.8718929254305','2758.871892925430529','test'),('2019-09-01 15:59:59','2019-09-01 19:59:59','IOTXETH','4h','0.000026430000000','0.000026160000000','0.072144500000000','0.071407496027242','2729.6443435489973','2729.644343548997313','test'),('2019-09-01 23:59:59','2019-09-02 03:59:59','IOTXETH','4h','0.000026350000000','0.000026180000000','0.072144500000000','0.071679051612903','2737.931688804554','2737.931688804554142','test'),('2019-09-12 07:59:59','2019-09-12 15:59:59','IOTXETH','4h','0.000024950000000','0.000023880000000','0.072144500000000','0.069050527454910','2891.563126252505','2891.563126252504844','test'),('2019-09-12 23:59:59','2019-09-13 03:59:59','IOTXETH','4h','0.000023900000000','0.000023300000000','0.072144500000000','0.070333341004184','3018.5983263598323','3018.598326359832299','test'),('2019-09-13 15:59:59','2019-09-13 19:59:59','IOTXETH','4h','0.000025880000000','0.000024810000000','0.072144500000000','0.069161709621329','2787.6545595054095','2787.654559505409452','test'),('2019-09-14 07:59:59','2019-09-14 11:59:59','IOTXETH','4h','0.000024790000000','0.000024430000000','0.072144500000000','0.071096818676886','2910.22589753933','2910.225897539330163','test'),('2019-10-05 19:59:59','2019-10-05 23:59:59','IOTXETH','4h','0.000021140000000','0.000021040000000','0.072144500000000','0.071803229895932','3412.701040681173','3412.701040681172799','test'),('2019-10-06 03:59:59','2019-10-14 07:59:59','IOTXETH','4h','0.000021260000000','0.000032210000000','0.072144500000000','0.109302650282220','3393.438381937912','3393.438381937911799','test'),('2019-11-02 23:59:59','2019-11-03 03:59:59','IOTXETH','4h','0.000024110000000','0.000023960000000','0.072144500000000','0.071695654085442','2992.3060970551637','2992.306097055163718','test'),('2019-11-03 07:59:59','2019-11-04 15:59:59','IOTXETH','4h','0.000024210000000','0.000023790000000','0.072144500000000','0.070892922552664','2979.946303180504','2979.946303180503946','test'),('2019-11-06 07:59:59','2019-11-07 23:59:59','IOTXETH','4h','0.000027680000000','0.000027150000000','0.072144500000000','0.070763120484104','2606.376445086705','2606.376445086705189','test'),('2019-11-08 07:59:59','2019-11-08 11:59:59','IOTXETH','4h','0.000026890000000','0.000026340000000','0.072144500000000','0.070668878021569','2682.949051692079','2682.949051692079138','test'),('2019-11-14 15:59:59','2019-11-15 23:59:59','IOTXETH','4h','0.000025210000000','0.000027210000000','0.072144500000000','0.077867982744942','2861.7413724712414','2861.741372471241448','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  3:22:53
