-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-12 07:59:59','2018-11-13 07:59:59','EOSBNB','4h','0.575000000000000','0.572100000000000','0.711908500000000','0.708318004956522','1.238101739130435','1.238101739130435','test'),('2018-11-13 11:59:59','2018-11-13 19:59:59','EOSBNB','4h','0.574200000000000','0.561800000000000','0.711908500000000','0.696534648728666','1.2398267154301637','1.239826715430164','test'),('2018-11-16 19:59:59','2018-11-18 23:59:59','EOSBNB','4h','0.570900000000000','0.575000000000000','0.711908500000000','0.717021172709757','1.246993343843055','1.246993343843055','test'),('2018-11-19 15:59:59','2018-11-26 23:59:59','EOSBNB','4h','0.594700000000000','0.644000000000000','0.711908500000000','0.770924960484278','1.1970884479569532','1.197088447956953','test'),('2018-12-17 15:59:59','2018-12-20 03:59:59','EOSBNB','4h','0.458100000000000','0.454900000000000','0.723199696719806','0.718147876092206','1.5786939461248761','1.578693946124876','test'),('2018-12-20 23:59:59','2018-12-22 07:59:59','EOSBNB','4h','0.478500000000000','0.463100000000000','0.723199696719806','0.699924304181697','1.5113891258512142','1.511389125851214','test'),('2018-12-23 23:59:59','2018-12-24 19:59:59','EOSBNB','4h','0.466000000000000','0.457500000000000','0.723199696719806','0.710008285942728','1.551930679656236','1.551930679656236','test'),('2019-01-03 07:59:59','2019-01-03 19:59:59','EOSBNB','4h','0.467600000000000','0.448400000000000','0.723199696719806','0.693504585135075','1.5466203950380795','1.546620395038079','test'),('2019-01-03 23:59:59','2019-01-04 11:59:59','EOSBNB','4h','0.453000000000000','0.445100000000000','0.723199696719806','0.710587604878555','1.5964673216772758','1.596467321677276','test'),('2019-01-06 19:59:59','2019-01-06 23:59:59','EOSBNB','4h','0.452300000000000','0.448900000000000','0.723199696719806','0.717763307224234','1.5989380869330223','1.598938086933022','test'),('2019-01-07 07:59:59','2019-01-07 11:59:59','EOSBNB','4h','0.451800000000000','0.444000000000000','0.723199696719806','0.710714177387326','1.6007076067282116','1.600707606728212','test'),('2019-01-31 11:59:59','2019-02-01 07:59:59','EOSBNB','4h','0.379400000000000','0.358300000000000','0.723199696719806','0.682979576527956','1.9061668337369688','1.906166833736969','test'),('2019-02-18 11:59:59','2019-02-20 03:59:59','EOSBNB','4h','0.331500000000000','0.328500000000000','0.723199696719806','0.716654903084333','2.181597878491119','2.181597878491119','test'),('2019-02-20 07:59:59','2019-02-20 11:59:59','EOSBNB','4h','0.335600000000000','0.346500000000000','0.723199696719806','0.746688602244972','2.1549454610244516','2.154945461024452','test'),('2019-02-20 15:59:59','2019-02-24 23:59:59','EOSBNB','4h','0.353500000000000','0.355300000000000','0.723199696719806','0.726882184567319','2.045826581951361','2.045826581951361','test'),('2019-03-28 15:59:59','2019-03-30 19:59:59','EOSBNB','4h','0.259300000000000','0.250300000000000','0.723199696719806','0.698098280327680','2.7890462657917703','2.789046265791770','test'),('2019-04-03 03:59:59','2019-04-11 23:59:59','EOSBNB','4h','0.270300000000000','0.301300000000000','0.723199696719806','0.806141578326591','2.6755445679608068','2.675544567960807','test'),('2019-05-07 03:59:59','2019-05-13 07:59:59','EOSBNB','4h','0.225000000000000','0.234400000000000','0.723199696719806','0.753413372938322','3.2142208743102487','3.214220874310249','test'),('2019-05-14 23:59:59','2019-05-15 02:59:59','EOSBNB','4h','0.253800000000000','0.239400000000000','0.723199696719806','0.682167089813718','2.849486590700575','2.849486590700575','test'),('2019-05-16 15:59:59','2019-05-17 03:59:59','EOSBNB','4h','0.254800000000000','0.249700000000000','0.723199696719806','0.708724349571961','2.838303362322629','2.838303362322629','test'),('2019-05-28 07:59:59','2019-06-01 23:59:59','EOSBNB','4h','0.235300000000000','0.231400000000000','0.723199696719806','0.711212961415058','3.07352187301235','3.073521873012350','test'),('2019-06-16 07:59:59','2019-06-18 03:59:59','EOSBNB','4h','0.215000000000000','0.204000000000000','0.723199696719806','0.686198782003909','3.3637195196270047','3.363719519627005','test'),('2019-06-26 19:59:59','2019-06-26 23:59:59','EOSBNB','4h','0.204000000000000','0.188800000000000','0.723199696719806','0.669314229121075','3.5450965525480687','3.545096552548069','test'),('2019-07-25 11:59:59','2019-07-27 23:59:59','EOSBNB','4h','0.156100000000000','0.154000000000000','0.723199696719806','0.713470552817746','4.632925667647701','4.632925667647701','test'),('2019-07-30 03:59:59','2019-07-31 03:59:59','EOSBNB','4h','0.158300000000000','0.153500000000000','0.723199696719806','0.701270710337904','4.568538829562893','4.568538829562893','test'),('2019-07-31 23:59:59','2019-08-01 07:59:59','EOSBNB','4h','0.159200000000000','0.153500000000000','0.723199696719806','0.697306240241773','4.542711662812851','4.542711662812851','test'),('2019-08-04 07:59:59','2019-08-04 11:59:59','EOSBNB','4h','0.154300000000000','0.153400000000000','0.723199696719806','0.718981422403229','4.686971462863292','4.686971462863292','test'),('2019-08-04 15:59:59','2019-08-05 03:59:59','EOSBNB','4h','0.154200000000000','0.156900000000000','0.723199696719806','0.735862726428908','4.690011003370985','4.690011003370985','test'),('2019-08-05 11:59:59','2019-08-06 11:59:59','EOSBNB','4h','0.156300000000000','0.157100000000000','0.723199696719806','0.726901294655672','4.626997419832412','4.626997419832412','test'),('2019-08-23 23:59:59','2019-08-25 23:59:59','EOSBNB','4h','0.136100000000000','0.136500000000000','0.723199696719806','0.725325191787315','5.313737668771536','5.313737668771536','test'),('2019-08-26 03:59:59','2019-08-26 07:59:59','EOSBNB','4h','0.139400000000000','0.133700000000000','0.723199696719806','0.693628403525381','5.187946174460588','5.187946174460588','test'),('2019-08-26 15:59:59','2019-08-28 03:59:59','EOSBNB','4h','0.138200000000000','0.139400000000000','0.723199696719806','0.729479288876563','5.232993463963864','5.232993463963864','test'),('2019-08-28 15:59:59','2019-08-28 19:59:59','EOSBNB','4h','0.139500000000000','0.137000000000000','0.723199696719806','0.710239128678232','5.184227216629433','5.184227216629433','test'),('2019-08-28 23:59:59','2019-09-02 15:59:59','EOSBNB','4h','0.139200000000000','0.147600000000000','0.723199696719806','0.766841057728760','5.19540012011355','5.195400120113550','test'),('2019-09-04 03:59:59','2019-09-05 19:59:59','EOSBNB','4h','0.152200000000000','0.140200000000000','0.723199696719806','0.666180009724815','4.75164058291594','4.751640582915940','test'),('2019-09-07 19:59:59','2019-09-14 11:59:59','EOSBNB','4h','0.158600000000000','0.177800000000000','0.723199696719806','0.810749723056630','4.559897205042914','4.559897205042914','test'),('2019-09-14 15:59:59','2019-09-18 03:59:59','EOSBNB','4h','0.188200000000000','0.189600000000000','0.723199696719806','0.728579503177870','3.84271889861746','3.842718898617460','test'),('2019-09-21 19:59:59','2019-09-22 19:59:59','EOSBNB','4h','0.191800000000000','0.187000000000000','0.723199696719806','0.705100851337871','3.7705927879030554','3.770592787903055','test'),('2019-09-22 23:59:59','2019-09-24 15:59:59','EOSBNB','4h','0.187400000000000','0.181400000000000','0.723199696719806','0.700044957230378','3.8591232482380255','3.859123248238026','test'),('2019-09-30 19:59:59','2019-10-01 15:59:59','EOSBNB','4h','0.187000000000000','0.185300000000000','0.723199696719806','0.716625154022353','3.867378057325166','3.867378057325166','test'),('2019-10-01 19:59:59','2019-10-03 19:59:59','EOSBNB','4h','0.185400000000000','0.185200000000000','0.723199696719806','0.722419546022158','3.900753488240593','3.900753488240593','test'),('2019-10-03 23:59:59','2019-10-09 07:59:59','EOSBNB','4h','0.186900000000000','0.187500000000000','0.723199696719806','0.725521365088088','3.8694472804698017','3.869447280469802','test'),('2019-10-26 03:59:59','2019-10-26 19:59:59','EOSBNB','4h','0.171100000000000','0.167900000000000','0.723199696719806','0.709674044881680','4.226766199414413','4.226766199414413','test'),('2019-10-27 03:59:59','2019-10-27 07:59:59','EOSBNB','4h','0.166700000000000','0.163900000000000','0.723199696719806','0.711052371280001','4.338330514215993','4.338330514215993','test'),('2019-10-27 11:59:59','2019-10-27 15:59:59','EOSBNB','4h','0.166000000000000','0.175100000000000','0.723199696719806','0.762844981299024','4.356624679034976','4.356624679034976','test'),('2019-10-28 11:59:59','2019-10-28 15:59:59','EOSBNB','4h','0.166700000000000','0.166700000000000','0.723199696719806','0.723199696719806','4.338330514215993','4.338330514215993','test'),('2019-11-02 03:59:59','2019-11-02 11:59:59','EOSBNB','4h','0.167500000000000','0.165700000000000','0.723199696719806','0.715427998486399','4.317610129670483','4.317610129670483','test'),('2019-11-02 23:59:59','2019-11-03 03:59:59','EOSBNB','4h','0.164500000000000','0.163500000000000','0.723199696719806','0.718803345979868','4.39635073993803','4.396350739938030','test'),('2019-11-05 07:59:59','2019-11-07 23:59:59','EOSBNB','4h','0.168800000000000','0.170000000000000','0.723199696719806','0.728340926791274','4.284358392889846','4.284358392889846','test'),('2019-11-08 03:59:59','2019-11-11 11:59:59','EOSBNB','4h','0.172800000000000','0.173200000000000','0.723199696719806','0.724873770091843','4.185183430091469','4.185183430091469','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 23:02:30
