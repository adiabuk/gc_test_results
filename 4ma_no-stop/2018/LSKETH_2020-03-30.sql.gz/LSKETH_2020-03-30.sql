-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-21 07:59:59','2018-05-21 15:59:59','LSKETH','4h','0.016200000000000','0.015535000000000','0.072144500000000','0.069183012808642','4.453364197530864','4.453364197530864','test'),('2018-05-21 23:59:59','2018-05-22 03:59:59','LSKETH','4h','0.015645000000000','0.015323000000000','0.072144500000000','0.070659646756152','4.611345477788431','4.611345477788431','test'),('2018-05-24 23:59:59','2018-05-25 07:59:59','LSKETH','4h','0.015630000000000','0.015138000000000','0.072144500000000','0.069873540690979','4.615770953294946','4.615770953294946','test'),('2018-05-28 07:59:59','2018-05-28 23:59:59','LSKETH','4h','0.015795000000000','0.015396000000000','0.072144500000000','0.070322046343780','4.567553023108578','4.567553023108578','test'),('2018-05-29 03:59:59','2018-05-29 07:59:59','LSKETH','4h','0.015459000000000','0.015409000000000','0.072144500000000','0.071911158580762','4.666828384759687','4.666828384759687','test'),('2018-05-29 11:59:59','2018-05-29 15:59:59','LSKETH','4h','0.015539000000000','0.015580000000000','0.072144500000000','0.072334854881266','4.642801982109531','4.642801982109531','test'),('2018-05-29 19:59:59','2018-05-30 03:59:59','LSKETH','4h','0.015793000000000','0.015583000000000','0.072144500000000','0.071185192395365','4.5681314506426896','4.568131450642690','test'),('2018-06-02 23:59:59','2018-06-03 11:59:59','LSKETH','4h','0.015862000000000','0.015361000000000','0.072144500000000','0.069865821743790','4.548259992434749','4.548259992434749','test'),('2018-06-03 15:59:59','2018-06-04 11:59:59','LSKETH','4h','0.015855000000000','0.015799000000000','0.072144500000000','0.071889684988962','4.550268054241564','4.550268054241564','test'),('2018-07-03 03:59:59','2018-07-03 23:59:59','LSKETH','4h','0.012490000000000','0.012189000000000','0.072144500000000','0.070405869535629','5.776180944755805','5.776180944755805','test'),('2018-07-04 11:59:59','2018-07-05 15:59:59','LSKETH','4h','0.012295000000000','0.011936000000000','0.072144500000000','0.070037962749085','5.867791785278568','5.867791785278568','test'),('2018-07-18 19:59:59','2018-07-19 11:59:59','LSKETH','4h','0.012084000000000','0.011465000000000','0.072144500000000','0.068448915301225','5.970249917245946','5.970249917245946','test'),('2018-07-19 15:59:59','2018-07-19 19:59:59','LSKETH','4h','0.011830000000000','0.011467000000000','0.072144500000000','0.069930767666948','6.09843617920541','6.098436179205410','test'),('2018-07-19 23:59:59','2018-07-20 03:59:59','LSKETH','4h','0.011469000000000','0.011332000000000','0.072144500000000','0.071282716365856','6.290391490103758','6.290391490103758','test'),('2018-08-14 07:59:59','2018-08-14 23:59:59','LSKETH','4h','0.009604000000000','0.009330000000000','0.072144500000000','0.070086233340275','7.51192211578509','7.511922115785090','test'),('2018-08-15 03:59:59','2018-08-15 15:59:59','LSKETH','4h','0.009675000000000','0.009423000000000','0.072144500000000','0.070265387441860','7.456795865633075','7.456795865633075','test'),('2018-08-15 19:59:59','2018-08-27 07:59:59','LSKETH','4h','0.010336000000000','0.017157000000000','0.072144500000000','0.119754565257353','6.979924535603716','6.979924535603716','test'),('2018-08-27 11:59:59','2018-08-28 07:59:59','LSKETH','4h','0.018036000000000','0.017439000000000','0.077389719211982','0.074828083462949','4.290847150808508','4.290847150808508','test'),('2018-09-06 19:59:59','2018-09-12 11:59:59','LSKETH','4h','0.016595000000000','0.017494000000000','0.077389719211982','0.081582148110540','4.663435927205906','4.663435927205906','test'),('2018-10-10 15:59:59','2018-10-12 15:59:59','LSKETH','4h','0.015015000000000','0.014792000000000','0.077797417499364','0.076641984658714','5.1813131867707956','5.181313186770796','test'),('2018-10-12 19:59:59','2018-10-12 23:59:59','LSKETH','4h','0.014819000000000','0.014813000000000','0.077797417499364','0.077765918443760','5.24984260067238','5.249842600672380','test'),('2018-10-22 23:59:59','2018-10-25 07:59:59','LSKETH','4h','0.014722000000000','0.014449000000000','0.077797417499364','0.076354767385431','5.284432651770412','5.284432651770412','test'),('2018-11-25 03:59:59','2018-11-25 07:59:59','LSKETH','4h','0.011950000000000','0.011977000000000','0.077797417499364','0.077973194091204','6.510244142206193','6.510244142206193','test'),('2018-11-27 11:59:59','2018-11-30 11:59:59','LSKETH','4h','0.012690000000000','0.011870000000000','0.077797417499364','0.072770318811462','6.13060815597825','6.130608155978250','test'),('2018-12-01 19:59:59','2018-12-03 03:59:59','LSKETH','4h','0.012923000000000','0.012374000000000','0.077797417499364','0.074492396822497','6.020074092653718','6.020074092653718','test'),('2018-12-04 19:59:59','2018-12-05 11:59:59','LSKETH','4h','0.012750000000000','0.012712000000000','0.077797417499364','0.077565550686425','6.101758235244236','6.101758235244236','test'),('2018-12-05 19:59:59','2018-12-07 19:59:59','LSKETH','4h','0.012768000000000','0.012537000000000','0.077797417499364','0.076389898432764','6.093156132468986','6.093156132468986','test'),('2018-12-07 23:59:59','2018-12-08 03:59:59','LSKETH','4h','0.012930000000000','0.013029000000000','0.077797417499364','0.078393082180914','6.016814965148027','6.016814965148027','test'),('2018-12-08 07:59:59','2018-12-08 23:59:59','LSKETH','4h','0.013255000000000','0.013124000000000','0.077797417499364','0.077028540721362','5.869288381694757','5.869288381694757','test'),('2018-12-09 07:59:59','2018-12-11 07:59:59','LSKETH','4h','0.013260000000000','0.013164000000000','0.077797417499364','0.077234178277649','5.8670752261963806','5.867075226196381','test'),('2018-12-11 11:59:59','2018-12-11 19:59:59','LSKETH','4h','0.013489000000000','0.013400000000000','0.077797417499364','0.077284112572576','5.767471087505672','5.767471087505672','test'),('2018-12-15 19:59:59','2018-12-15 23:59:59','LSKETH','4h','0.013170000000000','0.013211000000000','0.077797417499364','0.078039611433872','5.907169134348064','5.907169134348064','test'),('2018-12-16 07:59:59','2018-12-16 19:59:59','LSKETH','4h','0.013262000000000','0.013137000000000','0.077797417499364','0.077064143695457','5.866190431259539','5.866190431259539','test'),('2018-12-16 23:59:59','2018-12-17 03:59:59','LSKETH','4h','0.013292000000000','0.013241000000000','0.077797417499364','0.077498917025961','5.852950458874812','5.852950458874812','test'),('2018-12-17 07:59:59','2018-12-17 19:59:59','LSKETH','4h','0.013438000000000','0.013125000000000','0.077797417499364','0.075985347870156','5.78935983772615','5.789359837726150','test'),('2018-12-19 07:59:59','2018-12-20 19:59:59','LSKETH','4h','0.013495000000000','0.013449000000000','0.077797417499364','0.077532231785769','5.764906817292627','5.764906817292627','test'),('2019-01-12 07:59:59','2019-01-14 15:59:59','LSKETH','4h','0.009560000000000','0.009524000000000','0.077797417499364','0.077504456512965','8.13780517775774','8.137805177757739','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','LSKETH','4h','0.009560000000000','0.009466000000000','0.077797417499364','0.077032463812655','8.13780517775774','8.137805177757739','test'),('2019-01-16 07:59:59','2019-01-16 15:59:59','LSKETH','4h','0.009815000000000','0.009887000000000','0.077797417499364','0.078368116843221','7.926379775788487','7.926379775788487','test'),('2019-01-16 23:59:59','2019-01-26 03:59:59','LSKETH','4h','0.009786000000000','0.010589000000000','0.077797417499364','0.084181162262494','7.9498689453672595','7.949868945367260','test'),('2019-01-28 11:59:59','2019-01-28 19:59:59','LSKETH','4h','0.010754000000000','0.010700000000000','0.077797417499364','0.077406766528101','7.234277245616887','7.234277245616887','test'),('2019-02-27 19:59:59','2019-03-05 19:59:59','LSKETH','4h','0.009005000000000','0.009056000000000','0.077797417499364','0.078238024750054','8.639357856675623','8.639357856675623','test'),('2019-03-05 23:59:59','2019-03-06 07:59:59','LSKETH','4h','0.009341000000000','0.009167000000000','0.077797417499364','0.076348241753203','8.32859624230425','8.328596242304251','test'),('2019-03-07 19:59:59','2019-03-10 15:59:59','LSKETH','4h','0.009422000000000','0.009355000000000','0.077797417499364','0.077244198758921','8.256996126020379','8.256996126020379','test'),('2019-03-11 15:59:59','2019-03-16 11:59:59','LSKETH','4h','0.009480000000000','0.010622000000000','0.077797417499364','0.087169216105300','8.206478639173417','8.206478639173417','test'),('2019-03-17 23:59:59','2019-03-18 19:59:59','LSKETH','4h','0.011108000000000','0.010929000000000','0.077797417499364','0.076543750076571','7.003728618956068','7.003728618956068','test'),('2019-03-20 11:59:59','2019-03-21 15:59:59','LSKETH','4h','0.011061000000000','0.010915000000000','0.077797417499364','0.076770528162513','7.033488608567399','7.033488608567399','test'),('2019-03-21 19:59:59','2019-03-22 07:59:59','LSKETH','4h','0.010996000000000','0.010889000000000','0.077797417499364','0.077040385517513','7.075065250942524','7.075065250942524','test'),('2019-03-24 07:59:59','2019-03-27 07:59:59','LSKETH','4h','0.011009000000000','0.011129000000000','0.077797417499364','0.078645422776857','7.066710645777455','7.066710645777455','test'),('2019-03-27 11:59:59','2019-04-02 07:59:59','LSKETH','4h','0.011475000000000','0.012263000000000','0.077797417499364','0.083139845820889','6.779731372493594','6.779731372493594','test'),('2019-04-03 23:59:59','2019-04-06 19:59:59','LSKETH','4h','0.012771000000000','0.012627000000000','0.077797417499364','0.076920209127278','6.091724806151751','6.091724806151751','test'),('2019-04-15 15:59:59','2019-04-15 23:59:59','LSKETH','4h','0.012327000000000','0.012106000000000','0.077797417499364','0.076402655654036','6.3111395716203464','6.311139571620346','test'),('2019-04-16 03:59:59','2019-04-17 19:59:59','LSKETH','4h','0.012255000000000','0.012091000000000','0.077797417499364','0.076756309668283','6.348218482200245','6.348218482200245','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 16:13:54
