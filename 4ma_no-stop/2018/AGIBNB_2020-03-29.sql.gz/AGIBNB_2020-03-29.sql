-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-25 23:59:59','2018-11-26 03:59:59','AGIBNB','4h','0.006840000000000','0.006520000000000','0.711908500000000','0.678602839181287','104.08019005847954','104.080190058479545','test'),('2018-11-26 07:59:59','2018-11-26 11:59:59','AGIBNB','4h','0.006670000000000','0.006470000000000','0.711908500000000','0.690561918290855','106.73290854572716','106.732908545727156','test'),('2018-11-26 15:59:59','2018-11-26 19:59:59','AGIBNB','4h','0.006500000000000','0.006710000000000','0.711908500000000','0.734908620769231','109.52438461538463','109.524384615384633','test'),('2018-11-27 03:59:59','2018-11-30 23:59:59','AGIBNB','4h','0.006640000000000','0.007060000000000','0.711908500000000','0.756938856927711','107.21513554216868','107.215135542168682','test'),('2018-12-01 03:59:59','2018-12-04 19:59:59','AGIBNB','4h','0.007300000000000','0.008060000000000','0.715253058792271','0.789717760803521','97.97987106743437','97.979871067434374','test'),('2018-12-06 11:59:59','2018-12-07 03:59:59','AGIBNB','4h','0.008840000000000','0.007210000000000','0.733869234295084','0.598551717111714','83.01688170758862','83.016881707588624','test'),('2018-12-07 19:59:59','2018-12-09 19:59:59','AGIBNB','4h','0.008470000000000','0.008450000000000','0.733869234295084','0.732136367153891','86.64335705963211','86.643357059632109','test'),('2018-12-19 07:59:59','2018-12-22 15:59:59','AGIBNB','4h','0.008110000000000','0.008200000000000','0.733869234295084','0.742013282517841','90.48942469729766','90.489424697297665','test'),('2019-01-02 03:59:59','2019-01-07 11:59:59','AGIBNB','4h','0.008060000000000','0.008750000000000','0.733869234295084','0.796694268000246','91.05077348574244','91.050773485742440','test'),('2019-01-15 07:59:59','2019-01-15 15:59:59','AGIBNB','4h','0.009010000000000','0.007850000000000','0.733869234295084','0.639386624774296','81.45052544895493','81.450525448954934','test'),('2019-01-15 19:59:59','2019-01-15 23:59:59','AGIBNB','4h','0.007920000000000','0.007890000000000','0.733869234295084','0.731089426589421','92.6602568554399','92.660256855439897','test'),('2019-01-29 19:59:59','2019-01-30 03:59:59','AGIBNB','4h','0.007480000000000','0.007380000000000','0.733869234295084','0.724058148275096','98.11086019987755','98.110860199877550','test'),('2019-01-30 07:59:59','2019-01-30 11:59:59','AGIBNB','4h','0.007470000000000','0.007490000000000','0.733869234295084','0.735834078295874','98.24220003950253','98.242200039502535','test'),('2019-01-30 19:59:59','2019-01-30 23:59:59','AGIBNB','4h','0.007440000000000','0.007450000000000','0.733869234295084','0.734855617674513','98.63833794288763','98.638337942887631','test'),('2019-02-26 15:59:59','2019-02-27 23:59:59','AGIBNB','4h','0.004880000000000','0.004710000000000','0.733869234295084','0.708304117526608','150.3830398145664','150.383039814566388','test'),('2019-02-28 03:59:59','2019-02-28 11:59:59','AGIBNB','4h','0.004850000000000','0.004570000000000','0.733869234295084','0.691501525923409','151.31324418455338','151.313244184553383','test'),('2019-03-15 03:59:59','2019-03-16 11:59:59','AGIBNB','4h','0.003940000000000','0.003390000000000','0.733869234295084','0.631425559456938','186.26122697844772','186.261226978447723','test'),('2019-03-16 23:59:59','2019-03-18 03:59:59','AGIBNB','4h','0.003590000000000','0.003520000000000','0.733869234295084','0.719559806328328','204.42039952509305','204.420399525093046','test'),('2019-03-20 11:59:59','2019-03-21 07:59:59','AGIBNB','4h','0.003650000000000','0.003620000000000','0.733869234295084','0.727837432369371','201.06006419043396','201.060064190433962','test'),('2019-03-21 23:59:59','2019-03-22 03:59:59','AGIBNB','4h','0.003530000000000','0.003510000000000','0.733869234295084','0.729711334950636','207.89496722240338','207.894967222403380','test'),('2019-03-22 07:59:59','2019-03-22 11:59:59','AGIBNB','4h','0.003570000000000','0.003480000000000','0.733869234295084','0.715368329228821','205.56561184736248','205.565611847362476','test'),('2019-03-23 03:59:59','2019-03-23 07:59:59','AGIBNB','4h','0.003600000000000','0.003490000000000','0.733869234295084','0.711445452136068','203.85256508196778','203.852565081967782','test'),('2019-05-07 11:59:59','2019-05-10 03:59:59','AGIBNB','4h','0.001860000000000','0.001990000000000','0.733869234295084','0.785161170025386','394.5533517715505','394.553351771550524','test'),('2019-05-10 11:59:59','2019-05-11 19:59:59','AGIBNB','4h','0.001930000000000','0.001960000000000','0.733869234295084','0.745276528092417','380.2431265777637','380.243126577763690','test'),('2019-05-12 03:59:59','2019-05-12 11:59:59','AGIBNB','4h','0.002000000000000','0.001860000000000','0.733869234295084','0.682498387894428','366.934617147542','366.934617147541985','test'),('2019-06-01 11:59:59','2019-06-01 19:59:59','AGIBNB','4h','0.001610000000000','0.001500000000000','0.733869234295084','0.683729100274923','455.81940018328197','455.819400183281971','test'),('2019-06-01 23:59:59','2019-06-02 23:59:59','AGIBNB','4h','0.001520000000000','0.001590000000000','0.733869234295084','0.767665843769200','482.80870677308155','482.808706773081553','test'),('2019-06-03 03:59:59','2019-06-04 15:59:59','AGIBNB','4h','0.001630000000000','0.001580000000000','0.733869234295084','0.711357908089713','450.2265241074135','450.226524107413525','test'),('2019-06-04 23:59:59','2019-06-06 03:59:59','AGIBNB','4h','0.001570000000000','0.001550000000000','0.733869234295084','0.724520581628905','467.4326333089707','467.432633308970708','test'),('2019-06-07 19:59:59','2019-06-09 15:59:59','AGIBNB','4h','0.001620000000000','0.001560000000000','0.733869234295084','0.706688892284155','453.00570018215063','453.005700182150633','test'),('2019-07-22 03:59:59','2019-07-22 11:59:59','AGIBNB','4h','0.000952000000000','0.000871000000000','0.733869234295084','0.671428679696448','770.8710444276091','770.871044427609149','test'),('2019-07-22 15:59:59','2019-07-25 19:59:59','AGIBNB','4h','0.000945000000000','0.001113000000000','0.733869234295084','0.864334875947543','776.5812003122583','776.581200312258261','test'),('2019-08-03 15:59:59','2019-08-06 23:59:59','AGIBNB','4h','0.001110000000000','0.001100000000000','0.733869234295084','0.727257799751885','661.1434543198955','661.143454319895454','test'),('2019-08-07 03:59:59','2019-08-07 15:59:59','AGIBNB','4h','0.001121000000000','0.001088000000000','0.733869234295084','0.712265590466594','654.6558735906191','654.655873590619080','test'),('2019-08-12 15:59:59','2019-08-14 19:59:59','AGIBNB','4h','0.001147000000000','0.001119000000000','0.733869234295084','0.715954379403835','639.8162461160279','639.816246116027855','test'),('2019-08-15 01:59:59','2019-08-15 11:59:59','AGIBNB','4h','0.001145000000000','0.001083000000000','0.733869234295084','0.694131336892206','640.933829078676','640.933829078676013','test'),('2019-08-16 03:59:59','2019-08-19 07:59:59','AGIBNB','4h','0.001165000000000','0.001214000000000','0.733869234295084','0.764735837282603','629.9306732146644','629.930673214664353','test'),('2019-08-21 15:59:59','2019-08-23 15:59:59','AGIBNB','4h','0.001267000000000','0.001213000000000','0.733869234295084','0.702591461089137','579.2180223323473','579.218022332347346','test'),('2019-08-24 07:59:59','2019-08-28 19:59:59','AGIBNB','4h','0.001284000000000','0.001328000000000','0.733869234295084','0.759017401202392','571.5492478933676','571.549247893367578','test'),('2019-08-29 11:59:59','2019-08-29 19:59:59','AGIBNB','4h','0.001449000000000','0.001360000000000','0.733869234295084','0.688793760276959','506.4660002036467','506.466000203646672','test'),('2019-08-31 19:59:59','2019-09-02 15:59:59','AGIBNB','4h','0.001423000000000','0.001372000000000','0.733869234295084','0.707567525968275','515.719771113903','515.719771113902993','test'),('2019-09-05 11:59:59','2019-09-05 19:59:59','AGIBNB','4h','0.001440000000000','0.001292000000000','0.733869234295084','0.658443785214756','509.6314127049194','509.631412704919398','test'),('2019-09-21 03:59:59','2019-09-22 03:59:59','AGIBNB','4h','0.001262000000000','0.001238000000000','0.733869234295084','0.719912925560471','581.5128639422218','581.512863942221770','test'),('2019-09-23 15:59:59','2019-09-24 19:59:59','AGIBNB','4h','0.001414000000000','0.001250000000000','0.733869234295084','0.648752859171750','519.0022873374003','519.002287337400276','test'),('2019-09-24 23:59:59','2019-09-26 15:59:59','AGIBNB','4h','0.001328000000000','0.001290000000000','0.733869234295084','0.712869964036640','552.6123752222018','552.612375222201763','test'),('2019-09-27 23:59:59','2019-09-29 15:59:59','AGIBNB','4h','0.001334000000000','0.001339000000000','0.733869234295084','0.736619868606535','550.126862290168','550.126862290167992','test'),('2019-09-29 19:59:59','2019-09-30 07:59:59','AGIBNB','4h','0.001352000000000','0.001353000000000','0.733869234295084','0.734412036983172','542.8026880880799','542.802688088079890','test'),('2019-10-03 11:59:59','2019-10-03 15:59:59','AGIBNB','4h','0.001352000000000','0.001325000000000','0.733869234295084','0.719213561716706','542.8026880880799','542.802688088079890','test'),('2019-10-04 03:59:59','2019-10-09 07:59:59','AGIBNB','4h','0.001359000000000','0.001402000000000','0.489246156196723','0.504726350984405','360.00452994607997','360.004529946079970','test'),('2019-11-16 03:59:59','2019-11-17 11:59:59','AGIBNB','4h','0.001105000000000','0.001098000000000','0.552388801729877','0.548889506153308','499.89936808133683','499.899368081336831','test'),('2019-11-17 19:59:59','2019-11-20 03:59:59','AGIBNB','4h','0.001084000000000','0.001233000000000','0.552388801729877','0.628316782779463','509.58376543346594','509.583765433465942','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  3:30:03
