-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-13 11:59:59','2018-04-13 23:59:59','DASHBTC','4h','0.047614000000000','0.044730000000000','0.001467500000000','0.001378612907968','0.03082076700130214','0.030820767001302','test'),('2018-04-14 03:59:59','2018-04-14 19:59:59','DASHBTC','4h','0.045119000000000','0.044508000000000','0.001467500000000','0.001447627163723','0.03252510029034331','0.032525100290343','test'),('2018-04-15 11:59:59','2018-04-16 07:59:59','DASHBTC','4h','0.045500000000000','0.045000000000000','0.001467500000000','0.001451373626374','0.03225274725274725','0.032252747252747','test'),('2018-04-16 11:59:59','2018-04-16 15:59:59','DASHBTC','4h','0.045442000000000','0.044840000000000','0.001467500000000','0.001448059064302','0.032293913120021125','0.032293913120021','test'),('2018-04-17 07:59:59','2018-04-21 19:59:59','DASHBTC','4h','0.045504000000000','0.050115000000000','0.001467500000000','0.001616204344673','0.032249912095639946','0.032249912095640','test'),('2018-04-22 11:59:59','2018-04-25 07:59:59','DASHBTC','4h','0.052886000000000','0.052750000000000','0.001468594276760','0.001464817685192','0.027769055643459516','0.027769055643460','test'),('2018-04-26 23:59:59','2018-04-27 07:59:59','DASHBTC','4h','0.054365000000000','0.052800000000000','0.001468594276760','0.001426317995271','0.02701359839529109','0.027013598395291','test'),('2018-05-03 11:59:59','2018-05-03 19:59:59','DASHBTC','4h','0.052835000000000','0.051780000000000','0.001468594276760','0.001439269644187','0.02779586025854074','0.027795860258541','test'),('2018-05-15 23:59:59','2018-05-16 07:59:59','DASHBTC','4h','0.050447000000000','0.048742000000000','0.001468594276760','0.001418958951728','0.029111627584593732','0.029111627584594','test'),('2018-05-16 11:59:59','2018-05-16 15:59:59','DASHBTC','4h','0.049389000000000','0.049459000000000','0.001468594276760','0.001470675744281','0.029735250293790115','0.029735250293790','test'),('2018-05-16 19:59:59','2018-05-17 15:59:59','DASHBTC','4h','0.049714000000000','0.048506000000000','0.001468594276760','0.001432908918786','0.029540859250110633','0.029540859250111','test'),('2018-06-17 15:59:59','2018-06-17 23:59:59','DASHBTC','4h','0.041568000000000','0.040996000000000','0.001468594276760','0.001448385560288','0.03532992390204003','0.035329923902040','test'),('2018-07-16 11:59:59','2018-07-17 15:59:59','DASHBTC','4h','0.036316000000000','0.036560000000000','0.001468594276760','0.001478461470381','0.0404393181176341','0.040439318117634','test'),('2018-07-20 11:59:59','2018-07-20 15:59:59','DASHBTC','4h','0.036957000000000','0.035526000000000','0.001468594276760','0.001411729314505','0.039737919115729096','0.039737919115729','test'),('2018-08-28 11:59:59','2018-09-05 11:59:59','DASHBTC','4h','0.026569000000000','0.028078000000000','0.001468594276760','0.001552003842932','0.05527472907373255','0.055274729073733','test'),('2018-09-08 03:59:59','2018-09-11 19:59:59','DASHBTC','4h','0.029338000000000','0.029535000000000','0.001468594276760','0.001478455653559','0.05005775024746063','0.050057750247461','test'),('2018-09-18 23:59:59','2018-09-19 15:59:59','DASHBTC','4h','0.030284000000000','0.029810000000000','0.001468594276760','0.001445608089757','0.04849406540615507','0.048494065406155','test'),('2018-09-19 19:59:59','2018-09-20 11:59:59','DASHBTC','4h','0.029978000000000','0.030110000000000','0.001468594276760','0.001475060833720','0.048989067875108414','0.048989067875108','test'),('2018-09-20 19:59:59','2018-09-20 23:59:59','DASHBTC','4h','0.029582000000000','0.030636000000000','0.001468594276760','0.001520919960206','0.04964486095463458','0.049644860954635','test'),('2018-09-21 03:59:59','2018-09-21 19:59:59','DASHBTC','4h','0.031401000000000','0.030801000000000','0.001468594276760','0.001440532859415','0.046769028908633485','0.046769028908633','test'),('2018-09-21 23:59:59','2018-09-22 19:59:59','DASHBTC','4h','0.031039000000000','0.030184000000000','0.001468594276760','0.001428140392723','0.04731448425400303','0.047314484254003','test'),('2018-09-23 03:59:59','2018-09-24 07:59:59','DASHBTC','4h','0.030500000000000','0.029660000000000','0.001468594276760','0.001428147745859','0.04815063202491804','0.048150632024918','test'),('2018-10-31 03:59:59','2018-10-31 19:59:59','DASHBTC','4h','0.025183000000000','0.024041000000000','0.001468594276760','0.001401996386752','0.05831689142516777','0.058316891425168','test'),('2018-10-31 23:59:59','2018-11-01 03:59:59','DASHBTC','4h','0.024054000000000','0.024011000000000','0.001468594276760','0.001465968952327','0.06105405657104848','0.061054056571048','test'),('2018-11-02 23:59:59','2018-11-04 07:59:59','DASHBTC','4h','0.024238000000000','0.024262000000000','0.001468594276760','0.001470048450481','0.060590571695684464','0.060590571695684','test'),('2018-11-04 11:59:59','2018-11-07 15:59:59','DASHBTC','4h','0.024540000000000','0.025305000000000','0.001468594276760','0.001514375638688','0.05984491755338223','0.059844917553382','test'),('2018-11-08 03:59:59','2018-11-09 03:59:59','DASHBTC','4h','0.025768000000000','0.025353000000000','0.001468594276760','0.001444942203458','0.05699294771654766','0.056992947716548','test'),('2018-11-12 19:59:59','2018-11-13 15:59:59','DASHBTC','4h','0.025889000000000','0.025287000000000','0.001468594276760','0.001434444879154','0.056726574095561824','0.056726574095562','test'),('2018-12-18 07:59:59','2018-12-18 11:59:59','DASHBTC','4h','0.020036000000000','0.019592000000000','0.001468594276760','0.001436050063400','0.07329777783789179','0.073297777837892','test'),('2018-12-18 15:59:59','2018-12-18 23:59:59','DASHBTC','4h','0.019794000000000','0.019893000000000','0.001468594276760','0.001475939473961','0.07419391112256239','0.074193911122562','test'),('2018-12-19 03:59:59','2018-12-20 03:59:59','DASHBTC','4h','0.020301000000000','0.019598000000000','0.001468594276760','0.001417738566373','0.0723409820580267','0.072340982058027','test'),('2018-12-20 07:59:59','2018-12-20 11:59:59','DASHBTC','4h','0.019736000000000','0.019626000000000','0.001468594276760','0.001460408962084','0.07441195159910823','0.074411951599108','test'),('2018-12-20 19:59:59','2018-12-25 03:59:59','DASHBTC','4h','0.021262000000000','0.021487000000000','0.001468594276760','0.001484135322394','0.06907131392907535','0.069071313929075','test'),('2019-01-03 03:59:59','2019-01-03 11:59:59','DASHBTC','4h','0.021536000000000','0.021156000000000','0.001468594276760','0.001442681116230','0.06819252770988113','0.068192527709881','test'),('2019-01-23 11:59:59','2019-01-23 19:59:59','DASHBTC','4h','0.020214000000000','0.019796000000000','0.001468594276760','0.001438225601204','0.07265233386563769','0.072652333865638','test'),('2019-01-24 07:59:59','2019-01-27 07:59:59','DASHBTC','4h','0.020033000000000','0.020095000000000','0.001468594276760','0.001473139419532','0.07330875439325114','0.073308754393251','test'),('2019-02-08 07:59:59','2019-02-08 19:59:59','DASHBTC','4h','0.019849000000000','0.020011000000000','0.001468594276760','0.001480580385523','0.07398832569701246','0.073988325697012','test'),('2019-02-08 23:59:59','2019-02-14 15:59:59','DASHBTC','4h','0.020175000000000','0.021612000000000','0.001468594276760','0.001573197497365','0.07279277703890955','0.072792777038910','test'),('2019-02-19 03:59:59','2019-02-20 03:59:59','DASHBTC','4h','0.022516000000000','0.021726000000000','0.001468594276760','0.001417066941592','0.0652244748960739','0.065224474896074','test'),('2019-02-24 03:59:59','2019-02-24 15:59:59','DASHBTC','4h','0.022349000000000','0.021228000000000','0.001468594276760','0.001394931285832','0.06571185631392903','0.065711856313929','test'),('2019-03-02 23:59:59','2019-03-03 03:59:59','DASHBTC','4h','0.021502000000000','0.021628000000000','0.001468594276760','0.001477200121745','0.06830035702539299','0.068300357025393','test'),('2019-03-12 15:59:59','2019-03-16 11:59:59','DASHBTC','4h','0.022295000000000','0.022725000000000','0.001468594276760','0.001496918813159','0.06587101488046648','0.065871014880466','test'),('2019-03-17 23:59:59','2019-03-18 23:59:59','DASHBTC','4h','0.023199000000000','0.022852000000000','0.001468594276760','0.001446627717252','0.06330420607612397','0.063304206076124','test'),('2019-03-23 23:59:59','2019-03-25 11:59:59','DASHBTC','4h','0.022929000000000','0.022737000000000','0.001468594276760','0.001456296745200','0.06404964354136683','0.064049643541367','test'),('2019-03-27 19:59:59','2019-04-02 07:59:59','DASHBTC','4h','0.023264000000000','0.025451000000000','0.001468594276760','0.001606653754205','0.06312733307943603','0.063127333079436','test'),('2019-04-02 11:59:59','2019-04-02 15:59:59','DASHBTC','4h','0.025685000000000','0.025379000000000','0.001468594276760','0.001451098078641','0.057177118036207904','0.057177118036208','test'),('2019-04-03 11:59:59','2019-04-03 23:59:59','DASHBTC','4h','0.027077000000000','0.025084000000000','0.001468594276760','0.001360498535224','0.054237702727776345','0.054237702727776','test'),('2019-04-05 19:59:59','2019-04-06 15:59:59','DASHBTC','4h','0.026111000000000','0.026255000000000','0.001468594276760','0.001476693452427','0.056244275468576466','0.056244275468576','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 13:50:21
