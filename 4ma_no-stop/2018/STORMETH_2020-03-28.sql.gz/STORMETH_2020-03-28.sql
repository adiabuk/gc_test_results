-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-26 23:59:59','2018-08-29 03:59:59','STORMETH','4h','0.000030850000000','0.000030280000000','0.072144500000000','0.070811522204214','2338.5575364667748','2338.557536466774764','test'),('2018-08-29 07:59:59','2018-08-29 15:59:59','STORMETH','4h','0.000030880000000','0.000030180000000','0.072144500000000','0.070509100064767','2336.2856217616577','2336.285621761657694','test'),('2018-08-31 15:59:59','2018-09-02 11:59:59','STORMETH','4h','0.000031710000000','0.000031280000000','0.072144500000000','0.071166192368338','2275.1340271207823','2275.134027120782321','test'),('2018-09-02 15:59:59','2018-09-03 07:59:59','STORMETH','4h','0.000032230000000','0.000032740000000','0.072144500000000','0.073286097735029','2238.426931430344','2238.426931430344212','test'),('2018-09-03 11:59:59','2018-09-05 19:59:59','STORMETH','4h','0.000035300000000','0.000033480000000','0.072144500000000','0.068424868555241','2043.7535410764874','2043.753541076487409','test'),('2018-09-07 03:59:59','2018-09-09 19:59:59','STORMETH','4h','0.000034940000000','0.000034420000000','0.072144500000000','0.071070798225529','2064.8111047510015','2064.811104751001494','test'),('2018-09-09 23:59:59','2018-09-10 03:59:59','STORMETH','4h','0.000034500000000','0.000034100000000','0.072144500000000','0.071308042028986','2091.144927536232','2091.144927536231990','test'),('2018-09-10 15:59:59','2018-09-10 23:59:59','STORMETH','4h','0.000035030000000','0.000034320000000','0.072144500000000','0.070682250642307','2059.506137596346','2059.506137596345980','test'),('2018-09-11 03:59:59','2018-09-12 19:59:59','STORMETH','4h','0.000035050000000','0.000034920000000','0.072144500000000','0.071876916975749','2058.330955777461','2058.330955777460986','test'),('2018-09-17 19:59:59','2018-09-20 23:59:59','STORMETH','4h','0.000036960000000','0.000034380000000','0.072144500000000','0.067108439123377','1951.9615800865802','1951.961580086580170','test'),('2018-09-25 07:59:59','2018-09-27 19:59:59','STORMETH','4h','0.000035570000000','0.000036060000000','0.072144500000000','0.073138337644082','2028.2400899634524','2028.240089963452419','test'),('2018-10-02 19:59:59','2018-10-03 03:59:59','STORMETH','4h','0.000036440000000','0.000036210000000','0.072144500000000','0.071689142288694','1979.8161361141604','1979.816136114160372','test'),('2018-10-03 11:59:59','2018-10-04 03:59:59','STORMETH','4h','0.000036190000000','0.000036050000000','0.072144500000000','0.071865411025145','1993.4926775352308','1993.492677535230769','test'),('2018-10-04 07:59:59','2018-10-08 23:59:59','STORMETH','4h','0.000036150000000','0.000039000000000','0.072144500000000','0.077832240663900','1995.6984785615493','1995.698478561549337','test'),('2018-10-14 19:59:59','2018-10-15 03:59:59','STORMETH','4h','0.000038640000000','0.000038450000000','0.072144500000000','0.071789752199793','1867.093685300207','1867.093685300206971','test'),('2018-10-18 11:59:59','2018-10-19 11:59:59','STORMETH','4h','0.000038880000000','0.000037920000000','0.072144500000000','0.070363154320988','1855.56841563786','1855.568415637859971','test'),('2018-10-19 19:59:59','2018-10-19 23:59:59','STORMETH','4h','0.000037900000000','0.000037310000000','0.072144500000000','0.071021406200528','1903.5488126649077','1903.548812664907700','test'),('2018-10-20 15:59:59','2018-10-27 15:59:59','STORMETH','4h','0.000039270000000','0.000045000000000','0.072144500000000','0.082671313980138','1837.1403106697223','1837.140310669722339','test'),('2018-10-29 03:59:59','2018-11-02 19:59:59','STORMETH','4h','0.000048260000000','0.000049130000000','0.072144500000000','0.073445074285122','1494.9129714048902','1494.912971404890186','test'),('2018-11-03 23:59:59','2018-11-04 11:59:59','STORMETH','4h','0.000050590000000','0.000049020000000','0.072144500000000','0.069905581933188','1426.0624629373394','1426.062462937339433','test'),('2018-11-28 11:59:59','2018-11-30 11:59:59','STORMETH','4h','0.000037510000000','0.000032890000000','0.072144500000000','0.063258667155425','1923.3404425486538','1923.340442548653755','test'),('2018-12-01 15:59:59','2018-12-02 03:59:59','STORMETH','4h','0.000036170000000','0.000035480000000','0.072144500000000','0.070768229471938','1994.5949682056953','1994.594968205695295','test'),('2018-12-04 23:59:59','2018-12-05 03:59:59','STORMETH','4h','0.000035780000000','0.000035970000000','0.072144500000000','0.072527603828955','2016.3359418669647','2016.335941866964731','test'),('2018-12-05 15:59:59','2018-12-05 19:59:59','STORMETH','4h','0.000036250000000','0.000035390000000','0.072144500000000','0.070432933931034','1990.193103448276','1990.193103448275906','test'),('2019-01-09 11:59:59','2019-01-13 03:59:59','STORMETH','4h','0.000022460000000','0.000022820000000','0.072144500000000','0.073300867764915','3212.13268032057','3212.132680320570216','test'),('2019-01-16 23:59:59','2019-01-23 07:59:59','STORMETH','4h','0.000023290000000','0.000024500000000','0.072144500000000','0.075892668527265','3097.659939888364','3097.659939888364079','test'),('2019-01-23 15:59:59','2019-01-23 23:59:59','STORMETH','4h','0.000024830000000','0.000024550000000','0.072144500000000','0.071330949456303','2905.5376560612162','2905.537656061216239','test'),('2019-01-24 11:59:59','2019-01-26 23:59:59','STORMETH','4h','0.000025570000000','0.000024750000000','0.072144500000000','0.069830910246382','2821.4509190457566','2821.450919045756564','test'),('2019-01-27 23:59:59','2019-01-31 03:59:59','STORMETH','4h','0.000026490000000','0.000025470000000','0.072144500000000','0.069366569082673','2723.461683654209','2723.461683654209082','test'),('2019-02-06 23:59:59','2019-02-08 15:59:59','STORMETH','4h','0.000027350000000','0.000025240000000','0.072144500000000','0.066578690310786','2637.8244972577695','2637.824497257769508','test'),('2019-03-03 11:59:59','2019-03-06 03:59:59','STORMETH','4h','0.000020940000000','0.000021020000000','0.072144500000000','0.072420123686724','3445.2960840496658','3445.296084049665751','test'),('2019-03-09 15:59:59','2019-03-14 03:59:59','STORMETH','4h','0.000021510000000','0.000023430000000','0.072144500000000','0.078584176429568','3353.998140399814','3353.998140399814019','test'),('2019-03-14 23:59:59','2019-03-16 03:59:59','STORMETH','4h','0.000025220000000','0.000023830000000','0.072144500000000','0.068168256740682','2860.6066613798575','2860.606661379857542','test'),('2019-03-18 15:59:59','2019-03-21 15:59:59','STORMETH','4h','0.000024810000000','0.000024740000000','0.072144500000000','0.071940948407900','2907.8798871422814','2907.879887142281405','test'),('2019-03-28 07:59:59','2019-03-30 03:59:59','STORMETH','4h','0.000025210000000','0.000024400000000','0.072144500000000','0.069826489488298','2861.7413724712414','2861.741372471241448','test'),('2019-04-01 11:59:59','2019-04-02 07:59:59','STORMETH','4h','0.000025010000000','0.000024630000000','0.072144500000000','0.071048342063175','2884.626149540184','2884.626149540184088','test'),('2019-05-24 03:59:59','2019-05-24 11:59:59','STORMETH','4h','0.000013800000000','0.000013490000000','0.072144500000000','0.070523862681159','5227.86231884058','5227.862318840579974','test'),('2019-05-24 19:59:59','2019-05-24 23:59:59','STORMETH','4h','0.000013450000000','0.000013280000000','0.072144500000000','0.071232636431227','5363.903345724907','5363.903345724907012','test'),('2019-05-25 19:59:59','2019-05-26 23:59:59','STORMETH','4h','0.000013750000000','0.000013570000000','0.072144500000000','0.071200062909091','5246.872727272727','5246.872727272727388','test'),('2019-05-27 07:59:59','2019-05-27 11:59:59','STORMETH','4h','0.000013540000000','0.000014080000000','0.072144500000000','0.075021754800591','5328.249630723781','5328.249630723780683','test'),('2019-05-29 23:59:59','2019-05-30 03:59:59','STORMETH','4h','0.000014230000000','0.000013140000000','0.072144500000000','0.066618322557976','5069.887561489811','5069.887561489810651','test'),('2019-06-08 07:59:59','2019-06-10 03:59:59','STORMETH','4h','0.000014320000000','0.000014040000000','0.072144500000000','0.070733853351955','5038.02374301676','5038.023743016759909','test'),('2019-07-06 23:59:59','2019-07-07 23:59:59','STORMETH','4h','0.000010370000000','0.000009770000000','0.072144500000000','0.067970276277724','6957.039537126326','6957.039537126325740','test'),('2019-07-10 15:59:59','2019-07-13 23:59:59','STORMETH','4h','0.000009970000000','0.000010370000000','0.072144500000000','0.075038963390171','7236.158475426279','7236.158475426279438','test'),('2019-07-14 15:59:59','2019-07-17 03:59:59','STORMETH','4h','0.000010990000000','0.000010560000000','0.072144500000000','0.069321739763421','6564.5586897179255','6564.558689717925517','test'),('2019-07-22 23:59:59','2019-07-24 07:59:59','STORMETH','4h','0.000010600000000','0.000010460000000','0.072144500000000','0.071191648113208','6806.084905660377','6806.084905660377444','test'),('2019-07-24 15:59:59','2019-07-24 19:59:59','STORMETH','4h','0.000010550000000','0.000010410000000','0.072144500000000','0.071187132227488','6838.341232227488','6838.341232227488035','test'),('2019-08-23 15:59:59','2019-08-26 23:59:59','STORMETH','4h','0.000008500000000','0.000009300000000','0.072144500000000','0.078934570588235','8487.588235294117','8487.588235294117112','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 23:11:49
