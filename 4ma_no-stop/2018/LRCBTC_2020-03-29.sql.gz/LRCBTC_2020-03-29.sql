-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-08 07:59:59','2018-04-16 07:59:59','LRCBTC','4h','0.000056500000000','0.000073610000000','0.001467500000000','0.001911905752212','25.97345132743363','25.973451327433629','test'),('2018-04-16 15:59:59','2018-04-21 11:59:59','LRCBTC','4h','0.000080860000000','0.000081360000000','0.001578601438053','0.001588362762800','19.522649493606234','19.522649493606234','test'),('2018-04-23 11:59:59','2018-04-25 03:59:59','LRCBTC','4h','0.000087900000000','0.000082410000000','0.001581041769240','0.001482294109250','17.986823313307738','17.986823313307738','test'),('2018-04-28 07:59:59','2018-05-03 15:59:59','LRCBTC','4h','0.000088230000000','0.000098350000000','0.001581041769240','0.001762387600643','17.91954855763346','17.919548557633458','test'),('2018-06-03 11:59:59','2018-06-04 07:59:59','LRCBTC','4h','0.000073300000000','0.000068260000000','0.001601691312093','0.001491561377401','21.85117751832196','21.851177518321961','test'),('2018-06-05 23:59:59','2018-06-07 11:59:59','LRCBTC','4h','0.000071480000000','0.000067560000000','0.001601691312093','0.001513853735940','22.4075449369474','22.407544936947399','test'),('2018-06-30 19:59:59','2018-06-30 23:59:59','LRCBTC','4h','0.000055020000000','0.000055800000000','0.001601691312093','0.001624397950105','29.111074374645586','29.111074374645586','test'),('2018-07-01 03:59:59','2018-07-01 15:59:59','LRCBTC','4h','0.000056010000000','0.000053110000000','0.001601691312093','0.001518761392345','28.596524050937333','28.596524050937333','test'),('2018-07-02 23:59:59','2018-07-03 11:59:59','LRCBTC','4h','0.000056800000000','0.000054700000000','0.001601691312093','0.001542473851611','28.198790705862677','28.198790705862677','test'),('2018-07-03 23:59:59','2018-07-04 00:22:25','LRCBTC','4h','0.000054510000000','0.000054360000000','0.001601691312093','0.001597283796099','29.383439957677492','29.383439957677492','test'),('2018-07-04 23:59:59','2018-07-05 03:59:59','LRCBTC','4h','0.000055640000000','0.000054920000000','0.001601691312093','0.001580964896839','28.786687852138748','28.786687852138748','test'),('2018-08-27 15:59:59','2018-08-30 11:59:59','LRCBTC','4h','0.000019050000000','0.000016770000000','0.001601691312093','0.001409992824346','84.07828409937008','84.078284099370080','test'),('2018-09-02 07:59:59','2018-09-02 11:59:59','LRCBTC','4h','0.000017610000000','0.000016870000000','0.001601691312093','0.001534385714651','90.95351005638842','90.953510056388424','test'),('2018-09-20 07:59:59','2018-09-20 23:59:59','LRCBTC','4h','0.000014470000000','0.000014660000000','0.001601691312093','0.001622722504166','110.69048459523151','110.690484595231510','test'),('2018-09-21 07:59:59','2018-09-21 15:59:59','LRCBTC','4h','0.000014770000000','0.000014330000000','0.001601691312093','0.001553976743554','108.44220122498308','108.442201224983080','test'),('2018-09-21 19:59:59','2018-09-24 11:59:59','LRCBTC','4h','0.000014770000000','0.000014700000000','0.001601691312093','0.001594100358007','108.44220122498308','108.442201224983080','test'),('2018-09-28 15:59:59','2018-10-01 19:59:59','LRCBTC','4h','0.000015190000000','0.000015280000000','0.001601691312093','0.001611181254034','105.4437993477946','105.443799347794595','test'),('2018-10-02 07:59:59','2018-10-03 23:59:59','LRCBTC','4h','0.000015850000000','0.000015770000000','0.001601691312093','0.001593607065723','101.05307962731862','101.053079627318624','test'),('2018-10-04 03:59:59','2018-10-06 23:59:59','LRCBTC','4h','0.000016080000000','0.000016790000000','0.001601691312093','0.001672412756843','99.6076686625','99.607668662500004','test'),('2018-10-09 07:59:59','2018-10-11 07:59:59','LRCBTC','4h','0.000017300000000','0.000016440000000','0.001601691312093','0.001522069663053','92.58331283774567','92.583312837745666','test'),('2018-10-14 11:59:59','2018-10-14 23:59:59','LRCBTC','4h','0.000017500000000','0.000016710000000','0.001601691312093','0.001529386390004','91.52521783388572','91.525217833885719','test'),('2018-10-16 11:59:59','2018-10-18 11:59:59','LRCBTC','4h','0.000016870000000','0.000016890000000','0.001601691312093','0.001603590175534','94.94317202685241','94.943172026852409','test'),('2018-10-20 11:59:59','2018-10-22 03:59:59','LRCBTC','4h','0.000017250000000','0.000016940000000','0.001601691312093','0.001572907294310','92.85167026626088','92.851670266260882','test'),('2018-10-22 19:59:59','2018-10-27 15:59:59','LRCBTC','4h','0.000017220000000','0.000017700000000','0.001601691312093','0.001646337759817','93.01343275801393','93.013432758013934','test'),('2018-11-01 11:59:59','2018-11-04 11:59:59','LRCBTC','4h','0.000018020000000','0.000017750000000','0.001601691312093','0.001577692607639','88.88409057119867','88.884090571198669','test'),('2018-12-05 15:59:59','2018-12-06 11:59:59','LRCBTC','4h','0.000013330000000','0.000011010000000','0.001601691312093','0.001322927332794','120.15688762888223','120.156887628882231','test'),('2018-12-06 15:59:59','2018-12-06 19:59:59','LRCBTC','4h','0.000012620000000','0.000011270000000','0.001601691312093','0.001430353493446','126.91690270150555','126.916902701505549','test'),('2018-12-18 19:59:59','2018-12-19 23:59:59','LRCBTC','4h','0.000011050000000','0.000010790000000','0.001601691312093','0.001564004457691','144.9494400084163','144.949440008416303','test'),('2018-12-20 07:59:59','2018-12-20 11:59:59','LRCBTC','4h','0.000010750000000','0.000010620000000','0.001601691312093','0.001582322021807','148.99454065981394','148.994540659813936','test'),('2018-12-21 15:59:59','2018-12-25 07:59:59','LRCBTC','4h','0.000010960000000','0.000011080000000','0.001601691312093','0.001619228078284','146.1397182566606','146.139718256660586','test'),('2019-01-02 23:59:59','2019-01-03 19:59:59','LRCBTC','4h','0.000010920000000','0.000010720000000','0.001601691312093','0.001572356306377','146.67502857994506','146.675028579945064','test'),('2019-01-05 15:59:59','2019-01-06 23:59:59','LRCBTC','4h','0.000011360000000','0.000011000000000','0.001601691312093','0.001550933488822','140.9939535293134','140.993953529313387','test'),('2019-01-07 23:59:59','2019-01-08 23:59:59','LRCBTC','4h','0.000011820000000','0.000010900000000','0.001601691312093','0.001477024983233','135.5068791956853','135.506879195685286','test'),('2019-01-09 03:59:59','2019-01-09 19:59:59','LRCBTC','4h','0.000011050000000','0.000011070000000','0.001601691312093','0.001604590300893','144.9494400084163','144.949440008416303','test'),('2019-01-10 03:59:59','2019-01-10 07:59:59','LRCBTC','4h','0.000011130000000','0.000010830000000','0.001601691312093','0.001558519039530','143.90757521051214','143.907575210512135','test'),('2019-01-12 15:59:59','2019-01-12 19:59:59','LRCBTC','4h','0.000011090000000','0.000010980000000','0.001601691312093','0.001585804382938','144.42662868286743','144.426628682867431','test'),('2019-01-12 23:59:59','2019-01-13 03:59:59','LRCBTC','4h','0.000011020000000','0.000011160000000','0.001601691312093','0.001622039477582','145.34403920989112','145.344039209891122','test'),('2019-01-13 11:59:59','2019-01-13 19:59:59','LRCBTC','4h','0.000011200000000','0.000010910000000','0.001601691312093','0.001560218947762','143.00815286544645','143.008152865446448','test'),('2019-01-14 15:59:59','2019-01-15 11:59:59','LRCBTC','4h','0.000011210000000','0.000011030000000','0.001601691312093','0.001575972807528','142.88058091819804','142.880580918198035','test'),('2019-01-15 15:59:59','2019-01-15 19:59:59','LRCBTC','4h','0.000011060000000','0.000011680000000','0.001601691312093','0.001691478709335','144.81838264855332','144.818382648553325','test'),('2019-01-16 03:59:59','2019-01-24 15:59:59','LRCBTC','4h','0.000011550000000','0.000022260000000','0.001601691312093','0.003086895983307','138.67457247558443','138.674572475584426','test'),('2019-02-15 07:59:59','2019-02-15 11:59:59','LRCBTC','4h','0.000015530000000','0.000015130000000','0.001615629156070','0.001574016041941','104.03278532326142','104.032785323261422','test'),('2019-02-27 15:59:59','2019-03-01 03:59:59','LRCBTC','4h','0.000015730000000','0.000014710000000','0.001615629156070','0.001510864900559','102.71005442275906','102.710054422759058','test'),('2019-03-01 07:59:59','2019-03-02 11:59:59','LRCBTC','4h','0.000014870000000','0.000014720000000','0.001615629156070','0.001599331619190','108.65024586886348','108.650245868863479','test'),('2019-03-02 23:59:59','2019-03-04 07:59:59','LRCBTC','4h','0.000014920000000','0.000014820000000','0.001615629156070','0.001604800542423','108.28613646581769','108.286136465817691','test'),('2019-03-08 11:59:59','2019-03-09 03:59:59','LRCBTC','4h','0.000014970000000','0.000015460000000','0.001615629156070','0.001668512141138','107.92445932331329','107.924459323313286','test'),('2019-03-09 07:59:59','2019-03-12 01:59:59','LRCBTC','4h','0.000016390000000','0.000015630000000','0.001615629156070','0.001540712855972','98.57407907687613','98.574079076876131','test'),('2019-03-12 11:59:59','2019-03-13 19:59:59','LRCBTC','4h','0.000016160000000','0.000016010000000','0.001615629156070','0.001600632598309','99.97705173700494','99.977051737004942','test'),('2019-03-14 11:59:59','2019-03-16 07:59:59','LRCBTC','4h','0.000016520000000','0.000016060000000','0.001615629156070','0.001570641903540','97.79837506476997','97.798375064769971','test'),('2019-03-29 15:59:59','2019-03-29 19:59:59','LRCBTC','4h','0.000015500000000','0.000015390000000','0.001615629156070','0.001604163400769','104.23413910129031','104.234139101290310','test'),('2019-03-29 23:59:59','2019-04-02 07:59:59','LRCBTC','4h','0.000015600000000','0.000015410000000','0.001615629156070','0.001595951621477','103.56597154294872','103.565971542948716','test'),('2019-04-04 07:59:59','2019-04-04 19:59:59','LRCBTC','4h','0.000016690000000','0.000016330000000','0.001615629156070','0.001580780354621','96.80222624745356','96.802226247453561','test'),('2019-04-04 23:59:59','2019-04-08 07:59:59','LRCBTC','4h','0.000016460000000','0.000017900000000','0.001615629156070','0.001756972168509','98.15486974908869','98.154869749088689','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  7:28:49
