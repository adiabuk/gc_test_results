-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-04 03:59:59','2018-05-04 11:59:59','GVTBTC','4h','0.002599900000000','0.002541200000000','0.001467500000000','0.001434367091042','0.564444786337936','0.564444786337936','test'),('2018-06-01 15:59:59','2018-06-04 07:59:59','GVTBTC','4h','0.002230800000000','0.002026400000000','0.001467500000000','0.001333038371885','0.6578357539896003','0.657835753989600','test'),('2018-06-05 23:59:59','2018-06-08 07:59:59','GVTBTC','4h','0.002213500000000','0.002067000000000','0.001467500000000','0.001370373842331','0.6629771854529026','0.662977185452903','test'),('2018-07-05 03:59:59','2018-07-05 15:59:59','GVTBTC','4h','0.001394600000000','0.001380200000000','0.001467500000000','0.001452347268034','1.0522730532052202','1.052273053205220','test'),('2018-07-17 03:59:59','2018-07-18 23:59:59','GVTBTC','4h','0.001377200000000','0.001292000000000','0.001467500000000','0.001376713621841','1.065567818762707','1.065567818762707','test'),('2018-08-25 07:59:59','2018-08-29 15:59:59','GVTBTC','4h','0.000801900000000','0.000895500000000','0.001467500000000','0.001638790684624','1.8300286818805338','1.830028681880534','test'),('2018-09-01 03:59:59','2018-09-03 03:59:59','GVTBTC','4h','0.000936900000000','0.000918700000000','0.001467500000000','0.001438992688654','1.5663357882378057','1.566335788237806','test'),('2018-09-03 15:59:59','2018-09-05 11:59:59','GVTBTC','4h','0.000943600000000','0.000918100000000','0.001467500000000','0.001427842041119','1.555214073760068','1.555214073760068','test'),('2018-09-07 03:59:59','2018-09-08 19:59:59','GVTBTC','4h','0.000984400000000','0.000925000000000','0.001467500000000','0.001378949106054','1.4907557903291344','1.490755790329134','test'),('2018-09-09 11:59:59','2018-09-14 23:59:59','GVTBTC','4h','0.000996700000000','0.001286500000000','0.001467500000000','0.001894189575599','1.4723587839871575','1.472358783987157','test'),('2018-09-15 15:59:59','2018-09-16 15:59:59','GVTBTC','4h','0.001353100000000','0.001294400000000','0.001485151072796','0.001420722451132','1.097591510454327','1.097591510454327','test'),('2018-09-16 19:59:59','2018-09-17 19:59:59','GVTBTC','4h','0.001326300000000','0.001291700000000','0.001485151072796','0.001446407027619','1.1197700918314106','1.119770091831411','test'),('2018-09-19 11:59:59','2018-09-21 15:59:59','GVTBTC','4h','0.001406900000000','0.001337200000000','0.001485151072796','0.001411574393733','1.0556194987532874','1.055619498753287','test'),('2018-09-26 07:59:59','2018-09-28 11:59:59','GVTBTC','4h','0.001374900000000','0.001380000000000','0.001485151072796','0.001490660033790','1.0801884302829297','1.080188430282930','test'),('2018-10-01 03:59:59','2018-10-01 11:59:59','GVTBTC','4h','0.001397000000000','0.001375700000000','0.001485151072796','0.001462507037112','1.0631002668546885','1.063100266854689','test'),('2018-10-01 15:59:59','2018-10-06 19:59:59','GVTBTC','4h','0.001394300000000','0.001741800000000','0.001485151072796','0.001855293795163','1.0651589132869541','1.065158913286954','test'),('2018-10-10 07:59:59','2018-10-11 07:59:59','GVTBTC','4h','0.001817000000000','0.001704600000000','0.001529215648239','0.001434618048425','0.8416156567083103','0.841615656708310','test'),('2018-10-11 15:59:59','2018-10-11 19:59:59','GVTBTC','4h','0.001759600000000','0.001724900000000','0.001529215648239','0.001499058917736','0.8690700433274607','0.869070043327461','test'),('2018-10-12 15:59:59','2018-10-15 03:59:59','GVTBTC','4h','0.001849300000000','0.001825300000000','0.001529215648239','0.001509369665674','0.8269159402146758','0.826915940214676','test'),('2018-10-17 07:59:59','2018-10-25 19:59:59','GVTBTC','4h','0.001866000000000','0.002283300000000','0.001529215648239','0.001871199404943','0.8195153527540193','0.819515352754019','test'),('2018-12-17 19:59:59','2018-12-19 23:59:59','GVTBTC','4h','0.001009100000000','0.000976300000000','0.001578561509194','0.001527251611759','1.5643261413085918','1.564326141308592','test'),('2018-12-23 07:59:59','2018-12-23 11:59:59','GVTBTC','4h','0.001020500000000','0.001023200000000','0.001578561509194','0.001582738007063','1.5468510624145027','1.546851062414503','test'),('2018-12-23 23:59:59','2018-12-24 03:59:59','GVTBTC','4h','0.001013300000000','0.001017300000000','0.001578561509194','0.001584792878025','1.5578422078298628','1.557842207829863','test'),('2018-12-24 07:59:59','2018-12-25 03:59:59','GVTBTC','4h','0.001049200000000','0.000989000000000','0.001578561509194','0.001487988307847','1.5045382283587496','1.504538228358750','test'),('2018-12-26 03:59:59','2018-12-26 07:59:59','GVTBTC','4h','0.001041600000000','0.001030100000000','0.001578561509194','0.001561133074713','1.5155160418529185','1.515516041852919','test'),('2018-12-26 15:59:59','2018-12-30 03:59:59','GVTBTC','4h','0.001040000000000','0.001129700000000','0.001578561509194','0.001714712439362','1.5178476049942309','1.517847604994231','test'),('2019-01-18 07:59:59','2019-01-18 15:59:59','GVTBTC','4h','0.001023800000000','0.001001000000000','0.001578561509194','0.001543406984473','1.5418651193533892','1.541865119353389','test'),('2019-01-18 19:59:59','2019-01-18 23:59:59','GVTBTC','4h','0.001001700000000','0.001001300000000','0.001578561509194','0.001577931156190','1.575882508928821','1.575882508928821','test'),('2019-01-19 03:59:59','2019-01-20 11:59:59','GVTBTC','4h','0.001012700000000','0.000999600000000','0.001578561509194','0.001558141685188','1.5587651912649352','1.558765191264935','test'),('2019-01-23 15:59:59','2019-01-25 19:59:59','GVTBTC','4h','0.001139700000000','0.001050900000000','0.001578561509194','0.001455567509004','1.385067569706063','1.385067569706063','test'),('2019-01-31 03:59:59','2019-01-31 11:59:59','GVTBTC','4h','0.001074200000000','0.001006000000000','0.001578561509194','0.001478340046778','1.4695229093222864','1.469522909322286','test'),('2019-01-31 15:59:59','2019-01-31 19:59:59','GVTBTC','4h','0.001017000000000','0.001015100000000','0.001578561509194','0.001575612377564','1.5521745419803343','1.552174541980334','test'),('2019-02-08 15:59:59','2019-02-08 19:59:59','GVTBTC','4h','0.001043700000000','0.001042500000000','0.001578561509194','0.001576746549137','1.5124667138009005','1.512466713800900','test'),('2019-02-09 07:59:59','2019-02-12 03:59:59','GVTBTC','4h','0.001029200000000','0.001034800000000','0.001578561509194','0.001587150650713','1.533775271272833','1.533775271272833','test'),('2019-02-16 11:59:59','2019-02-17 19:59:59','GVTBTC','4h','0.001046600000000','0.001041800000000','0.001578561509194','0.001571321785093','1.5082758543798969','1.508275854379897','test'),('2019-02-17 23:59:59','2019-02-18 19:59:59','GVTBTC','4h','0.001046800000000','0.001034300000000','0.001578561509194','0.001559711663125','1.5079876855120364','1.507987685512036','test'),('2019-02-18 23:59:59','2019-02-19 03:59:59','GVTBTC','4h','0.001045100000000','0.001031600000000','0.001578561509194','0.001558170560601','1.5104406364883742','1.510440636488374','test'),('2019-02-20 11:59:59','2019-02-21 03:59:59','GVTBTC','4h','0.001083300000000','0.001045500000000','0.001578561509194','0.001523480160493','1.4571785370571402','1.457178537057140','test'),('2019-02-25 23:59:59','2019-02-27 07:59:59','GVTBTC','4h','0.001058400000000','0.001094900000000','0.001578561509194','0.001632999807650','1.4914602316647771','1.491460231664777','test'),('2019-02-27 19:59:59','2019-02-28 11:59:59','GVTBTC','4h','0.001176900000000','0.001101700000000','0.001578561509194','0.001477696673191','1.341287712799728','1.341287712799728','test'),('2019-02-28 15:59:59','2019-02-28 23:59:59','GVTBTC','4h','0.001118200000000','0.001071600000000','0.001578561509194','0.001512776348822','1.4116987204382043','1.411698720438204','test'),('2019-03-14 11:59:59','2019-03-16 03:59:59','GVTBTC','4h','0.001015400000000','0.001019500000000','0.001578561509194','0.001584935452652','1.554620355715974','1.554620355715974','test'),('2019-03-16 07:59:59','2019-03-16 11:59:59','GVTBTC','4h','0.001037100000000','0.001022000000000','0.001578561509194','0.001555577921508','1.5220918997145887','1.522091899714589','test'),('2019-03-27 07:59:59','2019-03-30 19:59:59','GVTBTC','4h','0.001054600000000','0.001041200000000','0.001578561509194','0.001558503928857','1.4968343534932675','1.496834353493268','test'),('2019-03-31 19:59:59','2019-04-02 07:59:59','GVTBTC','4h','0.001054700000000','0.000967500000000','0.001578561509194','0.001448049929027','1.496692433103252','1.496692433103252','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  6:08:49
