-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-15 03:59:59','2018-05-20 03:59:59','ZECETH','4h','0.457080000000000','0.488950000000000','0.072144500000000','0.077174790572766','0.15783779644701146','0.157837796447011','test'),('2018-05-23 03:59:59','2018-05-24 07:59:59','ZECETH','4h','0.506230000000000','0.474750000000000','0.073402072643191','0.068837552075845','0.14499747672637242','0.144997476726372','test'),('2018-05-24 19:59:59','2018-05-25 03:59:59','ZECETH','4h','0.492800000000000','0.485370000000000','0.073402072643191','0.072295381491123','0.14894901104543629','0.148949011045436','test'),('2018-06-27 07:59:59','2018-06-27 11:59:59','ZECETH','4h','0.372850000000000','0.373510000000000','0.073402072643191','0.073532005237919','0.1968675677703929','0.196867567770393','test'),('2018-06-27 23:59:59','2018-06-28 03:59:59','ZECETH','4h','0.381940000000000','0.372480000000000','0.073402072643191','0.071584028952547','0.19218220831332408','0.192182208313324','test'),('2018-06-28 07:59:59','2018-06-28 15:59:59','ZECETH','4h','0.375750000000000','0.373920000000000','0.073402072643191','0.073044585502973','0.1953481640537352','0.195348164053735','test'),('2018-06-29 19:59:59','2018-06-29 23:59:59','ZECETH','4h','0.383860000000000','0.374810000000000','0.073402072643191','0.071671523074544','0.19122094681183505','0.191220946811835','test'),('2018-06-30 03:59:59','2018-07-02 07:59:59','ZECETH','4h','0.375270000000000','0.369390000000000','0.073402072643191','0.072251956227965','0.1955980298003864','0.195598029800386','test'),('2018-07-02 11:59:59','2018-07-05 11:59:59','ZECETH','4h','0.380170000000000','0.382800000000000','0.073402072643191','0.073909865080920','0.19307697252069073','0.193076972520691','test'),('2018-07-14 07:59:59','2018-07-16 11:59:59','ZECETH','4h','0.398560000000000','0.380000000000000','0.073402072643191','0.069983911090959','0.18416818708147079','0.184168187081471','test'),('2018-07-16 19:59:59','2018-07-20 19:59:59','ZECETH','4h','0.392280000000000','0.414520000000000','0.073402072643191','0.077563544284836','0.18711653064951309','0.187116530649513','test'),('2018-07-23 15:59:59','2018-07-23 23:59:59','ZECETH','4h','0.432780000000000','0.422220000000000','0.073402072643191','0.071611033576894','0.1696059721872337','0.169605972187234','test'),('2018-07-24 03:59:59','2018-07-29 23:59:59','ZECETH','4h','0.423420000000000','0.465000000000000','0.073402072643191','0.080610183220169','0.1733552327315455','0.173355232731545','test'),('2018-07-31 07:59:59','2018-07-31 15:59:59','ZECETH','4h','0.471740000000000','0.459540000000000','0.073402072643191','0.071503770005622','0.15559857684994063','0.155598576849941','test'),('2018-07-31 23:59:59','2018-08-02 11:59:59','ZECETH','4h','0.485110000000000','0.460300000000000','0.073402072643191','0.069648067526253','0.1513101619080023','0.151310161908002','test'),('2018-08-08 07:59:59','2018-08-08 19:59:59','ZECETH','4h','0.460010000000000','0.447650000000000','0.073402072643191','0.071429833739972','0.1595662543057564','0.159566254305756','test'),('2018-08-08 23:59:59','2018-08-09 03:59:59','ZECETH','4h','0.451530000000000','0.453190000000000','0.073402072643191','0.073671927227798','0.16256300277543242','0.162563002775432','test'),('2018-08-09 15:59:59','2018-08-14 03:59:59','ZECETH','4h','0.457180000000000','0.495230000000000','0.073402072643191','0.079511151920660','0.16055398889538258','0.160553988895383','test'),('2018-08-14 07:59:59','2018-08-14 19:59:59','ZECETH','4h','0.496810000000000','0.485780000000000','0.073402072643191','0.071772425773655','0.14774676967692077','0.147746769676921','test'),('2018-08-24 19:59:59','2018-09-02 11:59:59','ZECETH','4h','0.495300000000000','0.521230000000000','0.073402072643191','0.077244826012135','0.1481971989565738','0.148197198956574','test'),('2018-09-03 19:59:59','2018-09-12 03:59:59','ZECETH','4h','0.548000000000000','0.601180000000000','0.073402072643191','0.080525288378893','0.13394538803502007','0.133945388035020','test'),('2018-09-12 15:59:59','2018-09-12 19:59:59','ZECETH','4h','0.611870000000000','0.602030000000000','0.074442424527657','0.073245252812502','0.12166379219059112','0.121663792190591','test'),('2018-09-24 19:59:59','2018-09-28 15:59:59','ZECETH','4h','0.598500000000000','0.605260000000000','0.074442424527657','0.075283244560751','0.12438166170034586','0.124381661700346','test'),('2018-09-28 19:59:59','2018-09-28 23:59:59','ZECETH','4h','0.619350000000000','0.608480000000000','0.074442424527657','0.073135910997964','0.12019443695431824','0.120194436954318','test'),('2018-10-18 07:59:59','2018-10-23 15:59:59','ZECETH','4h','0.587470000000000','0.595960000000000','0.074442424527657','0.075518251692005','0.12671698048863259','0.126716980488633','test'),('2018-10-24 15:59:59','2018-10-26 15:59:59','ZECETH','4h','0.616170000000000','0.593820000000000','0.074442424527657','0.071742214864426','0.12081475003271337','0.120814750032713','test'),('2018-11-07 23:59:59','2018-11-11 03:59:59','ZECETH','4h','0.595000000000000','0.615370000000000','0.074442424527657','0.076990982826192','0.1251133185338773','0.125113318533877','test'),('2018-11-13 07:59:59','2018-11-13 19:59:59','ZECETH','4h','0.639350000000000','0.614720000000000','0.074442424527657','0.071574641754346','0.1164345421563416','0.116434542156342','test'),('2018-11-13 23:59:59','2018-11-14 11:59:59','ZECETH','4h','0.615590000000000','0.617470000000000','0.074442424527657','0.074669770257952','0.12092857994388635','0.120928579943886','test'),('2018-11-14 15:59:59','2018-11-14 19:59:59','ZECETH','4h','0.632360000000000','0.610270000000000','0.074442424527657','0.071841954608915','0.11772158980273419','0.117721589802734','test'),('2018-11-17 23:59:59','2018-11-19 15:59:59','ZECETH','4h','0.638090000000000','0.628860000000000','0.074442424527657','0.073365611572760','0.11666445881875126','0.116664458818751','test'),('2018-11-19 19:59:59','2018-11-20 19:59:59','ZECETH','4h','0.635450000000000','0.626240000000000','0.074442424527657','0.073363480897317','0.11714914553097333','0.117149145530973','test'),('2018-11-20 23:59:59','2018-11-21 03:59:59','ZECETH','4h','0.650060000000000','0.634950000000000','0.074442424527657','0.072712084198129','0.11451623623612743','0.114516236236127','test'),('2018-11-21 07:59:59','2018-11-21 15:59:59','ZECETH','4h','0.646240000000000','0.630880000000000','0.074442424527657','0.072673057665895','0.11519315506260366','0.115193155062604','test'),('2018-11-27 19:59:59','2018-12-01 23:59:59','ZECETH','4h','0.665500000000000','0.677400000000000','0.074442424527657','0.075773551277288','0.11185939072525469','0.111859390725255','test'),('2019-01-11 03:59:59','2019-01-13 19:59:59','ZECETH','4h','0.453750000000000','0.457000000000000','0.074442424527657','0.074975620956781','0.16406043973037354','0.164060439730374','test'),('2019-01-14 07:59:59','2019-01-14 23:59:59','ZECETH','4h','0.452620000000000','0.432620000000000','0.074442424527657','0.071153023947583','0.16447002900370508','0.164470029003705','test'),('2019-01-16 15:59:59','2019-01-16 23:59:59','ZECETH','4h','0.441160000000000','0.430790000000000','0.074442424527657','0.072692565196911','0.16874246198126983','0.168742461981270','test'),('2019-01-17 15:59:59','2019-01-18 11:59:59','ZECETH','4h','0.441230000000000','0.437010000000000','0.074442424527657','0.073730444309842','0.1687156914254629','0.168715691425463','test'),('2019-01-18 19:59:59','2019-01-19 11:59:59','ZECETH','4h','0.439710000000000','0.436050000000000','0.074442424527657','0.073822790510302','0.16929891184566417','0.169298911845664','test'),('2019-01-20 19:59:59','2019-01-26 15:59:59','ZECETH','4h','0.444750000000000','0.449110000000000','0.074442424527657','0.075172202989581','0.16738038117517032','0.167380381175170','test'),('2019-01-27 23:59:59','2019-01-30 15:59:59','ZECETH','4h','0.453580000000000','0.455420000000000','0.074442424527657','0.074744408876903','0.1641219289379095','0.164121928937910','test'),('2019-01-30 19:59:59','2019-01-30 23:59:59','ZECETH','4h','0.457730000000000','0.456900000000000','0.074442424527657','0.074307438373466','0.16263392071233476','0.162633920712335','test'),('2019-03-02 15:59:59','2019-03-04 07:59:59','ZECETH','4h','0.386190000000000','0.384550000000000','0.074442424527657','0.074126296258605','0.19276113966611513','0.192761139666115','test'),('2019-03-04 11:59:59','2019-03-04 23:59:59','ZECETH','4h','0.387530000000000','0.384640000000000','0.074442424527657','0.073887271102413','0.19209461081118107','0.192094610811181','test'),('2019-03-12 19:59:59','2019-03-16 07:59:59','ZECETH','4h','0.387000000000000','0.383790000000000','0.074442424527657','0.073824956355218','0.1923576861179767','0.192357686117977','test'),('2019-03-18 15:59:59','2019-03-22 07:59:59','ZECETH','4h','0.391260000000000','0.403890000000000','0.074442424527657','0.076845450192903','0.19026331474635025','0.190263314746350','test'),('2019-03-23 23:59:59','2019-03-25 23:59:59','ZECETH','4h','0.413020000000000','0.412530000000000','0.074442424527657','0.074354107283895','0.18023927298352863','0.180239272983529','test'),('2019-03-31 19:59:59','2019-04-04 11:59:59','ZECETH','4h','0.417870000000000','0.418580000000000','0.074442424527657','0.074568909131516','0.17814732937912986','0.178147329379130','test'),('2019-04-05 11:59:59','2019-04-06 19:59:59','ZECETH','4h','0.440510000000000','0.428050000000000','0.074442424527657','0.072336791035535','0.16899145201620167','0.168991452016202','test'),('2019-04-06 23:59:59','2019-04-07 03:59:59','ZECETH','4h','0.430770000000000','0.429300000000000','0.074442424527657','0.074188390207589','0.17281246263123476','0.172812462631235','test'),('2019-04-07 07:59:59','2019-04-07 23:59:59','ZECETH','4h','0.437450000000000','0.425010000000000','0.074442424527657','0.072325465421190','0.17017356161311462','0.170173561613115','test'),('2019-04-12 15:59:59','2019-04-14 07:59:59','ZECETH','4h','0.433060000000000','0.417070000000000','0.074442424527657','0.071693765292915','0.17189863882061837','0.171898638820618','test'),('2019-04-14 11:59:59','2019-04-14 15:59:59','ZECETH','4h','0.422220000000000','0.420730000000000','0.074442424527657','0.074179719746864','0.17631193341778456','0.176311933417785','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 10:36:51
