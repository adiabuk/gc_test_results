-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-03 03:59:59','2018-07-03 23:59:59','AIONBNB','4h','0.081100000000000','0.073550000000000','0.711908500000000','0.645633417694205','8.778156596794082','8.778156596794082','test'),('2018-07-04 00:22:27','2018-07-04 11:59:59','AIONBNB','4h','0.073610000000000','0.078080000000000','0.711908500000000','0.755139460399402','9.671355794049722','9.671355794049722','test'),('2018-07-04 15:59:59','2018-07-05 19:59:59','AIONBNB','4h','0.080240000000000','0.077370000000000','0.711908500000000','0.686445172544865','8.872239531405782','8.872239531405782','test'),('2018-07-05 23:59:59','2018-07-06 03:59:59','AIONBNB','4h','0.078560000000000','0.075840000000000','0.711908500000000','0.687259936863544','9.061971741344196','9.061971741344196','test'),('2018-07-06 19:59:59','2018-07-06 23:59:59','AIONBNB','4h','0.079750000000000','0.078600000000000','0.711908500000000','0.701642734796238','8.926752351097178','8.926752351097178','test'),('2018-07-14 19:59:59','2018-07-16 07:59:59','AIONBNB','4h','0.078460000000000','0.071980000000000','0.711908500000000','0.653112080423146','9.073521539638033','9.073521539638033','test'),('2018-07-16 11:59:59','2018-07-19 11:59:59','AIONBNB','4h','0.078600000000000','0.078580000000000','0.711908500000000','0.711727352798982','9.057360050890585','9.057360050890585','test'),('2018-08-17 15:59:59','2018-08-20 23:59:59','AIONBNB','4h','0.048650000000000','0.047260000000000','0.711908500000000','0.691568257142857','14.63326824254882','14.633268242548819','test'),('2018-08-21 07:59:59','2018-08-21 19:59:59','AIONBNB','4h','0.051500000000000','0.047740000000000','0.711908500000000','0.659932267766990','13.823466019417477','13.823466019417477','test'),('2018-08-23 15:59:59','2018-08-28 11:59:59','AIONBNB','4h','0.050000000000000','0.059800000000000','0.711908500000000','0.851442566000000','14.23817','14.238170000000000','test'),('2018-09-21 23:59:59','2018-09-22 03:59:59','AIONBNB','4h','0.046420000000000','0.044700000000000','0.711908500000000','0.685530158336924','15.336245152951314','15.336245152951314','test'),('2018-09-22 07:59:59','2018-09-22 11:59:59','AIONBNB','4h','0.045080000000000','0.044490000000000','0.711908500000000','0.702591152728483','15.792114019520852','15.792114019520852','test'),('2018-09-23 07:59:59','2018-09-23 15:59:59','AIONBNB','4h','0.045910000000000','0.044340000000000','0.711908500000000','0.687563121106513','15.506610760182967','15.506610760182967','test'),('2018-09-23 19:59:59','2018-09-23 23:59:59','AIONBNB','4h','0.045670000000000','0.045000000000000','0.711908500000000','0.701464473396102','15.588099408802277','15.588099408802277','test'),('2018-09-24 07:59:59','2018-09-24 11:59:59','AIONBNB','4h','0.047370000000000','0.045270000000000','0.711908500000000','0.680348275174161','15.028678488494828','15.028678488494828','test'),('2018-09-24 15:59:59','2018-09-24 19:59:59','AIONBNB','4h','0.046190000000000','0.044710000000000','0.711908500000000','0.689097835786967','15.412610954752111','15.412610954752111','test'),('2018-10-09 15:59:59','2018-10-10 07:59:59','AIONBNB','4h','0.043880000000000','0.042010000000000','0.711908500000000','0.681569646422060','16.223985870556064','16.223985870556064','test'),('2018-10-10 11:59:59','2018-10-11 03:59:59','AIONBNB','4h','0.042350000000000','0.040000000000000','0.711908500000000','0.672404722550177','16.81011806375443','16.810118063754430','test'),('2018-10-13 19:59:59','2018-10-15 03:59:59','AIONBNB','4h','0.046560000000000','0.044560000000000','0.711908500000000','0.681328237972509','15.290131013745707','15.290131013745707','test'),('2018-10-15 11:59:59','2018-10-15 19:59:59','AIONBNB','4h','0.044520000000000','0.043530000000000','0.711908500000000','0.696077650606469','15.990756963162626','15.990756963162626','test'),('2018-10-15 23:59:59','2018-10-16 03:59:59','AIONBNB','4h','0.044390000000000','0.044010000000000','0.711908500000000','0.705814216828115','16.037587294435685','16.037587294435685','test'),('2018-10-18 03:59:59','2018-10-18 19:59:59','AIONBNB','4h','0.045170000000000','0.043540000000000','0.711908500000000','0.686218642683197','15.760648660615454','15.760648660615454','test'),('2018-10-20 23:59:59','2018-10-21 19:59:59','AIONBNB','4h','0.044690000000000','0.044370000000000','0.711908500000000','0.706810922913403','15.929928395614233','15.929928395614233','test'),('2018-10-26 11:59:59','2018-10-27 19:59:59','AIONBNB','4h','0.045130000000000','0.044340000000000','0.711908500000000','0.699446551961002','15.774617770884113','15.774617770884113','test'),('2018-11-02 11:59:59','2018-11-03 03:59:59','AIONBNB','4h','0.044600000000000','0.043260000000000','0.711908500000000','0.690519320852018','15.96207399103139','15.962073991031390','test'),('2018-12-01 07:59:59','2018-12-03 03:59:59','AIONBNB','4h','0.029990000000000','0.030000000000000','0.711908500000000','0.712145881960654','23.738196065355122','23.738196065355122','test'),('2018-12-20 15:59:59','2018-12-22 03:59:59','AIONBNB','4h','0.030260000000000','0.028380000000000','0.711908500000000','0.667678890614673','23.52638797091871','23.526387970918709','test'),('2018-12-22 07:59:59','2018-12-22 23:59:59','AIONBNB','4h','0.028450000000000','0.027900000000000','0.711908500000000','0.698145769771529','25.023145869947278','25.023145869947278','test'),('2018-12-23 03:59:59','2018-12-23 19:59:59','AIONBNB','4h','0.029650000000000','0.028090000000000','0.711908500000000','0.674452268634064','24.010404721753797','24.010404721753797','test'),('2018-12-24 03:59:59','2018-12-25 03:59:59','AIONBNB','4h','0.030510000000000','0.027330000000000','0.711908500000000','0.637707614060964','23.33361193051459','23.333611930514589','test'),('2019-01-07 19:59:59','2019-01-07 23:59:59','AIONBNB','4h','0.026660000000000','0.025770000000000','0.711908500000000','0.688142612340585','26.703244561140288','26.703244561140288','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','AIONBNB','4h','0.009670000000000','0.009260000000000','0.711908500000000','0.681724168562565','73.62032057911065','73.620320579110654','test'),('2019-03-21 07:59:59','2019-03-21 15:59:59','AIONBNB','4h','0.009370000000000','0.009340000000000','0.711908500000000','0.709629177161153','75.97742796157952','75.977427961579522','test'),('2019-03-21 23:59:59','2019-03-22 11:59:59','AIONBNB','4h','0.009640000000000','0.009280000000000','0.711908500000000','0.685322705394191','73.84942946058092','73.849429460580922','test'),('2019-03-23 19:59:59','2019-03-24 11:59:59','AIONBNB','4h','0.009480000000000','0.008420000000000','0.711908500000000','0.632306916666667','75.09583333333333','75.095833333333331','test'),('2019-03-28 23:59:59','2019-04-01 23:59:59','AIONBNB','4h','0.009530000000000','0.009570000000000','0.474605666666667','0.476597715634838','49.80122420426723','49.801224204267228','test'),('2019-04-02 23:59:59','2019-04-08 03:59:59','AIONBNB','4h','0.010350000000000','0.011310000000000','0.532693182470886','0.582102405192823','51.46794033535129','51.467940335351287','test'),('2019-04-08 07:59:59','2019-04-08 11:59:59','AIONBNB','4h','0.011760000000000','0.011310000000000','0.545045488151370','0.524189155696598','46.347405455048474','46.347405455048474','test'),('2019-04-08 15:59:59','2019-04-08 23:59:59','AIONBNB','4h','0.011700000000000','0.011380000000000','0.545045488151370','0.530138261125008','46.58508445738205','46.585084457382052','test'),('2019-05-04 03:59:59','2019-05-06 03:59:59','AIONBNB','4h','0.008600000000000','0.008250000000000','0.545045488151370','0.522863404331256','63.37738234318256','63.377382343182560','test'),('2019-05-06 07:59:59','2019-05-08 07:59:59','AIONBNB','4h','0.008480000000000','0.008640000000000','0.545045488151370','0.555329365286302','64.27423209332194','64.274232093321942','test'),('2019-05-08 11:59:59','2019-05-09 03:59:59','AIONBNB','4h','0.009060000000000','0.008380000000000','0.545045488151370','0.504136996766940','60.15954615357285','60.159546153572848','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','AIONBNB','4h','0.009160000000000','0.008750000000000','0.545045488151370','0.520649347306167','59.502782549276205','59.502782549276205','test'),('2019-05-10 15:59:59','2019-05-13 07:59:59','AIONBNB','4h','0.008960000000000','0.009020000000000','0.545045488151370','0.548695346330955','60.83096965975112','60.830969659751119','test'),('2019-06-01 15:59:59','2019-06-03 23:59:59','AIONBNB','4h','0.006800000000000','0.006640000000000','0.545045488151370','0.532220888430161','80.15374825755441','80.153748257554412','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  7:11:49
