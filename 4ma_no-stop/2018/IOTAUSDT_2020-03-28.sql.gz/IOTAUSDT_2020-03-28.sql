-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-12-18 15:59:59','2018-12-25 03:59:59','IOTAUSDT','4h','0.262700000000000','0.317800000000000','15.000000000000000','18.146174343357444','57.099352874000765','57.099352874000765','test'),('2018-12-28 23:59:59','2019-01-05 15:59:59','IOTAUSDT','4h','0.356800000000000','0.364200000000000','15.786543585839361','16.113955083976165','44.244797045513906','44.244797045513906','test'),('2019-01-07 07:59:59','2019-01-07 19:59:59','IOTAUSDT','4h','0.370100000000000','0.364000000000000','15.868396460373562','15.606853043977241','42.87596990103638','42.875969901036378','test'),('2019-02-09 11:59:59','2019-02-11 19:59:59','IOTAUSDT','4h','0.278100000000000','0.270000000000000','15.868396460373562','15.406210155702487','57.060037613712915','57.060037613712915','test'),('2019-02-13 03:59:59','2019-02-13 15:59:59','IOTAUSDT','4h','0.273100000000000','0.267200000000000','15.868396460373562','15.525578667930484','58.10471058357218','58.104710583572178','test'),('2019-02-15 23:59:59','2019-02-21 23:59:59','IOTAUSDT','4h','0.270900000000000','0.299900000000000','15.868396460373562','17.567117380826989','58.57658346391127','58.576583463911270','test'),('2019-02-22 23:59:59','2019-02-23 07:59:59','IOTAUSDT','4h','0.306900000000000','0.301200000000000','16.026439812109299','15.728783549714308','52.220396911402084','52.220396911402084','test'),('2019-02-23 19:59:59','2019-02-24 15:59:59','IOTAUSDT','4h','0.316300000000000','0.282100000000000','16.026439812109299','14.293577840645062','50.66847869778469','50.668478697784693','test'),('2019-03-13 19:59:59','2019-03-14 19:59:59','IOTAUSDT','4h','0.285000000000000','0.294500000000000','16.026439812109299','16.560654472512944','56.23312214775193','56.233122147751928','test'),('2019-03-14 23:59:59','2019-03-17 23:59:59','IOTAUSDT','4h','0.297000000000000','0.295400000000000','16.026439812109299','15.940102089215781','53.96107680844882','53.961076808448823','test'),('2019-03-20 11:59:59','2019-03-20 19:59:59','IOTAUSDT','4h','0.296600000000000','0.295700000000000','16.026439812109299','15.977809347406339','54.033849669957185','54.033849669957185','test'),('2019-03-20 23:59:59','2019-03-21 15:59:59','IOTAUSDT','4h','0.298500000000000','0.289900000000000','16.026439812109299','15.564706537790572','53.68991561845662','53.689915618456617','test'),('2019-03-21 19:59:59','2019-03-24 19:59:59','IOTAUSDT','4h','0.305000000000000','0.305700000000000','16.026439812109299','16.063221805120698','52.5457043019977','52.545704301997702','test'),('2019-03-28 15:59:59','2019-03-30 07:59:59','IOTAUSDT','4h','0.305500000000000','0.306400000000000','16.026439812109299','16.073653546416661','52.459704785955154','52.459704785955154','test'),('2019-03-30 19:59:59','2019-03-31 07:59:59','IOTAUSDT','4h','0.304700000000000','0.303300000000000','16.026439812109299','15.952803396825567','52.597439488379706','52.597439488379706','test'),('2019-03-31 11:59:59','2019-03-31 19:59:59','IOTAUSDT','4h','0.306800000000000','0.305500000000000','16.026439812109299','15.958531168837647','52.2374179012689','52.237417901268898','test'),('2019-03-31 23:59:59','2019-04-01 03:59:59','IOTAUSDT','4h','0.306300000000000','0.310500000000000','16.026439812109299','16.246195108259670','52.32268955961246','52.322689559612463','test'),('2019-04-01 07:59:59','2019-04-03 23:59:59','IOTAUSDT','4h','0.311500000000000','0.335900000000000','16.026439812109299','17.281801389687040','51.44924498269438','51.449244982694381','test'),('2019-04-04 07:59:59','2019-04-04 19:59:59','IOTAUSDT','4h','0.345300000000000','0.325700000000000','16.026439812109299','15.116743257468864','46.41308952247118','46.413089522471182','test'),('2019-04-05 11:59:59','2019-04-08 11:59:59','IOTAUSDT','4h','0.348800000000000','0.335800000000000','16.026439812109299','15.429124108102933','45.94736184664363','45.947361846643631','test'),('2019-04-08 23:59:59','2019-04-09 03:59:59','IOTAUSDT','4h','0.353800000000000','0.344600000000000','16.026439812109299','15.609698019369318','45.29802094999802','45.298020949998019','test'),('2019-04-10 15:59:59','2019-04-10 23:59:59','IOTAUSDT','4h','0.351000000000000','0.348000000000000','16.026439812109299','15.889461694057083','45.65937268407208','45.659372684072082','test'),('2019-04-30 11:59:59','2019-05-01 15:59:59','IOTAUSDT','4h','0.304000000000000','0.287800000000000','16.026439812109299','15.172399269490317','52.71855201351743','52.718552013517431','test'),('2019-05-01 19:59:59','2019-05-02 03:59:59','IOTAUSDT','4h','0.294500000000000','0.290900000000000','16.026439812109299','15.830530870433261','54.41915046556638','54.419150465566382','test'),('2019-05-11 19:59:59','2019-05-17 11:59:59','IOTAUSDT','4h','0.300100000000000','0.365500000000000','16.026439812109299','19.519039491256077','53.40366481875808','53.403664818758081','test'),('2019-05-19 03:59:59','2019-05-22 23:59:59','IOTAUSDT','4h','0.415000000000000','0.382400000000000','16.026439812109299','14.767495383495413','38.617927258094696','38.617927258094696','test'),('2019-05-27 15:59:59','2019-05-31 11:59:59','IOTAUSDT','4h','0.411200000000000','0.468900000000000','16.026439812109299','18.275286060063351','38.974804990538175','38.974804990538175','test'),('2019-05-31 23:59:59','2019-06-01 19:59:59','IOTAUSDT','4h','0.508000000000000','0.477400000000000','16.200535400077708','15.224676377947043','31.890817716688403','31.890817716688403','test'),('2019-06-02 23:59:59','2019-06-03 07:59:59','IOTAUSDT','4h','0.489100000000000','0.471000000000000','16.200535400077708','15.601006283861379','33.123155592062375','33.123155592062375','test'),('2019-06-16 07:59:59','2019-06-17 07:59:59','IOTAUSDT','4h','0.456100000000000','0.435800000000000','16.200535400077708','15.479485479837461','35.51970050444575','35.519700504445751','test'),('2019-06-17 11:59:59','2019-06-17 15:59:59','IOTAUSDT','4h','0.440100000000000','0.433600000000000','16.200535400077708','15.961263688874562','36.81103249279189','36.811032492791888','test'),('2019-06-22 19:59:59','2019-06-25 15:59:59','IOTAUSDT','4h','0.452700000000000','0.445100000000000','16.200535400077708','15.928558220840706','35.78647095223704','35.786470952237039','test'),('2019-06-26 03:59:59','2019-06-26 23:59:59','IOTAUSDT','4h','0.473000000000000','0.447200000000000','16.200535400077708','15.316869832800743','34.25060338282814','34.250603382828139','test'),('2019-06-27 03:59:59','2019-06-27 07:59:59','IOTAUSDT','4h','0.447600000000000','0.426400000000000','16.200535400077708','15.433217816338550','36.19422564807352','36.194225648073520','test'),('2019-08-23 11:59:59','2019-08-27 11:59:59','IOTAUSDT','4h','0.258000000000000','0.259500000000000','16.200535400077708','16.294724559380487','62.79277286851825','62.792772868518249','test'),('2019-09-15 11:59:59','2019-09-16 15:59:59','IOTAUSDT','4h','0.248200000000000','0.243400000000000','16.200535400077708','15.887229316595143','65.27210072553468','65.272100725534685','test'),('2019-09-16 19:59:59','2019-09-22 07:59:59','IOTAUSDT','4h','0.244400000000000','0.287900000000000','16.200535400077708','19.084018582988428','66.28696972208554','66.286969722085544','test'),('2019-10-02 03:59:59','2019-10-03 15:59:59','IOTAUSDT','4h','0.268900000000000','0.269300000000000','16.200535400077708','16.224634374268977','60.247435478161805','60.247435478161805','test'),('2019-10-03 23:59:59','2019-10-04 03:59:59','IOTAUSDT','4h','0.269900000000000','0.269100000000000','16.200535400077708','16.152516028754768','60.02421415367807','60.024214153678066','test'),('2019-10-05 07:59:59','2019-10-06 11:59:59','IOTAUSDT','4h','0.275000000000000','0.270700000000000','16.200535400077708','15.947217937458309','58.911037818464386','58.911037818464386','test'),('2019-10-06 15:59:59','2019-10-06 19:59:59','IOTAUSDT','4h','0.271300000000000','0.266300000000000','16.200535400077708','15.901963055807938','59.71446885395396','59.714468853953960','test'),('2019-10-07 11:59:59','2019-10-08 15:59:59','IOTAUSDT','4h','0.279700000000000','0.272200000000000','16.200535400077708','15.766127050057747','57.92111333599467','57.921113335994669','test'),('2019-10-08 19:59:59','2019-10-08 23:59:59','IOTAUSDT','4h','0.272500000000000','0.275200000000000','16.200535400077708','16.361054466427099','59.45150605533104','59.451506055331038','test'),('2019-10-09 15:59:59','2019-10-10 11:59:59','IOTAUSDT','4h','0.276500000000000','0.271600000000000','16.200535400077708','15.913437304380126','58.59144810154686','58.591448101546860','test'),('2019-10-13 19:59:59','2019-10-15 19:59:59','IOTAUSDT','4h','0.280800000000000','0.278800000000000','16.200535400077708','16.085146971302226','57.69421438774113','57.694214387741127','test'),('2019-10-15 23:59:59','2019-10-16 11:59:59','IOTAUSDT','4h','0.279600000000000','0.274600000000000','16.200535400077708','15.910826254868880','57.941829041765764','57.941829041765764','test'),('2019-10-28 03:59:59','2019-10-31 03:59:59','IOTAUSDT','4h','0.278100000000000','0.277100000000000','16.200535400077708','16.142281047686204','58.2543523915056','58.254352391505599','test'),('2019-11-05 19:59:59','2019-11-07 11:59:59','IOTAUSDT','4h','0.276900000000000','0.269400000000000','16.200535400077708','15.761734332903337','58.50680895658255','58.506808956582553','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:59:00
