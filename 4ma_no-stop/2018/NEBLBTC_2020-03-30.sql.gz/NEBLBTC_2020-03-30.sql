-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-03 19:59:59','2018-07-03 23:59:59','NEBLBTC','4h','0.000640900000000','0.000620000000000','0.001467500000000','0.001419644250273','2.2897487907629896','2.289748790762990','test'),('2018-07-04 11:59:59','2018-07-04 19:59:59','NEBLBTC','4h','0.000640300000000','0.000663500000000','0.001467500000000','0.001520671950648','2.291894424488521','2.291894424488521','test'),('2018-07-04 23:59:59','2018-07-05 15:59:59','NEBLBTC','4h','0.000665700000000','0.000641000000000','0.001468829050230','0.001414329910166','2.20644291757586','2.206442917575860','test'),('2018-07-18 07:59:59','2018-07-18 23:59:59','NEBLBTC','4h','0.000608600000000','0.000579500000000','0.001468829050230','0.001398597493605','2.413455554107788','2.413455554107788','test'),('2018-08-27 23:59:59','2018-08-30 11:59:59','NEBLBTC','4h','0.000305500000000','0.000302600000000','0.001468829050230','0.001454885992143','4.807951064582651','4.807951064582651','test'),('2018-08-31 19:59:59','2018-09-03 11:59:59','NEBLBTC','4h','0.000346600000000','0.000339400000000','0.001468829050230','0.001438316732972','4.237821841402192','4.237821841402192','test'),('2018-09-03 19:59:59','2018-09-04 03:59:59','NEBLBTC','4h','0.000353800000000','0.000344900000000','0.001468829050230','0.001431879987067','4.1515801306670435','4.151580130667043','test'),('2018-09-21 23:59:59','2018-09-24 11:59:59','NEBLBTC','4h','0.000295700000000','0.000278200000000','0.001468829050230','0.001381901392540','4.967294725160635','4.967294725160635','test'),('2018-09-29 11:59:59','2018-09-30 23:59:59','NEBLBTC','4h','0.000282900000000','0.000287100000000','0.001468829050230','0.001490635632100','5.19204330233298','5.192043302332980','test'),('2018-10-01 03:59:59','2018-10-01 19:59:59','NEBLBTC','4h','0.000289000000000','0.000286600000000','0.001468829050230','0.001456631161924','5.08245346100346','5.082453461003460','test'),('2018-10-01 23:59:59','2018-10-03 03:59:59','NEBLBTC','4h','0.000289200000000','0.000285400000000','0.001468829050230','0.001449529083457','5.078938624585062','5.078938624585062','test'),('2018-10-03 07:59:59','2018-10-03 11:59:59','NEBLBTC','4h','0.000288900000000','0.000294800000000','0.001468829050230','0.001498825905185','5.084212704153686','5.084212704153686','test'),('2018-10-03 19:59:59','2018-10-07 15:59:59','NEBLBTC','4h','0.000294000000000','0.000306900000000','0.001468829050230','0.001533277671822','4.996017177653061','4.996017177653061','test'),('2018-10-08 15:59:59','2018-10-09 11:59:59','NEBLBTC','4h','0.000314500000000','0.000312500000000','0.001468829050230','0.001459488324950','4.670362639841017','4.670362639841017','test'),('2018-10-09 19:59:59','2018-10-11 03:59:59','NEBLBTC','4h','0.000316700000000','0.000306000000000','0.001468829050230','0.001419203313452','4.637919325007894','4.637919325007894','test'),('2018-10-18 07:59:59','2018-10-18 15:59:59','NEBLBTC','4h','0.000315300000000','0.000298300000000','0.001468829050230','0.001389634334550','4.658512687059942','4.658512687059942','test'),('2018-10-19 11:59:59','2018-10-19 15:59:59','NEBLBTC','4h','0.000302800000000','0.000301600000000','0.001468829050230','0.001463008063241','4.850822490852048','4.850822490852048','test'),('2018-10-20 15:59:59','2018-10-25 11:59:59','NEBLBTC','4h','0.000304100000000','0.000340300000000','0.001468829050230','0.001643678151244','4.830085663367313','4.830085663367313','test'),('2018-10-25 15:59:59','2018-10-29 23:59:59','NEBLBTC','4h','0.000396300000000','0.000411400000000','0.001468829050230','0.001524795032209','3.7063564224829673','3.706356422482967','test'),('2018-10-30 03:59:59','2018-10-31 07:59:59','NEBLBTC','4h','0.000441100000000','0.000413300000000','0.001468829050230','0.001376257189889','3.3299230338472','3.329923033847200','test'),('2018-10-31 15:59:59','2018-10-31 23:59:59','NEBLBTC','4h','0.000448800000000','0.000401700000000','0.001468829050230','0.001314680546964','3.272792001403743','3.272792001403743','test'),('2018-11-29 23:59:59','2018-11-30 03:59:59','NEBLBTC','4h','0.000263700000000','0.000261700000000','0.001468829050230','0.001457688898162','5.570076034243458','5.570076034243458','test'),('2018-12-01 11:59:59','2018-12-02 03:59:59','NEBLBTC','4h','0.000269000000000','0.000272100000000','0.001468829050230','0.001485756076459','5.460331041747212','5.460331041747212','test'),('2018-12-02 11:59:59','2018-12-02 19:59:59','NEBLBTC','4h','0.000271300000000','0.000271300000000','0.001468829050230','0.001468829050230','5.414039993475857','5.414039993475857','test'),('2018-12-03 11:59:59','2018-12-03 15:59:59','NEBLBTC','4h','0.000265500000000','0.000258200000000','0.001468829050230','0.001428443166740','5.532312806892655','5.532312806892655','test'),('2018-12-03 23:59:59','2018-12-05 19:59:59','NEBLBTC','4h','0.000278700000000','0.000264200000000','0.001468829050230','0.001392409885435','5.270287227233585','5.270287227233585','test'),('2018-12-08 15:59:59','2018-12-10 15:59:59','NEBLBTC','4h','0.000269200000000','0.000265100000000','0.001468829050230','0.001446458325468','5.4562743322065375','5.456274332206537','test'),('2018-12-14 03:59:59','2018-12-20 23:59:59','NEBLBTC','4h','0.000270100000000','0.000287400000000','0.001468829050230','0.001562908067516','5.43809348474639','5.438093484746390','test'),('2018-12-21 07:59:59','2018-12-25 07:59:59','NEBLBTC','4h','0.000294900000000','0.000322100000000','0.001468829050230','0.001604305992130','4.980769922787385','4.980769922787385','test'),('2018-12-29 15:59:59','2018-12-31 23:59:59','NEBLBTC','4h','0.000327500000000','0.000327400000000','0.001468829050230','0.001468380552810','4.484974199175572','4.484974199175572','test'),('2019-01-01 15:59:59','2019-01-07 03:59:59','NEBLBTC','4h','0.000336800000000','0.000341800000000','0.001468829050230','0.001490634707151','4.361131384293349','4.361131384293349','test'),('2019-01-20 03:59:59','2019-01-20 11:59:59','NEBLBTC','4h','0.000325000000000','0.000313000000000','0.001468829050230','0.001414595362222','4.519474000707692','4.519474000707692','test'),('2019-01-20 15:59:59','2019-01-20 19:59:59','NEBLBTC','4h','0.000314300000000','0.000313600000000','0.001468829050230','0.001465557716042','4.673334553706649','4.673334553706649','test'),('2019-01-23 11:59:59','2019-01-23 23:59:59','NEBLBTC','4h','0.000321600000000','0.000310600000000','0.001468829050230','0.001418589250626','4.567254509421641','4.567254509421641','test'),('2019-01-24 23:59:59','2019-01-25 15:59:59','NEBLBTC','4h','0.000321400000000','0.000319600000000','0.001468829050230','0.001460602876333','4.570096609303048','4.570096609303048','test'),('2019-01-25 23:59:59','2019-01-27 11:59:59','NEBLBTC','4h','0.000324400000000','0.000313700000000','0.001468829050230','0.001420381236304','4.527833077157829','4.527833077157829','test'),('2019-02-10 03:59:59','2019-02-11 23:59:59','NEBLBTC','4h','0.000303400000000','0.000291400000000','0.001468829050230','0.001410734295442','4.8412295656888595','4.841229565688860','test'),('2019-02-12 23:59:59','2019-02-14 23:59:59','NEBLBTC','4h','0.000309400000000','0.000296700000000','0.001468829050230','0.001408537747910','4.747346639398836','4.747346639398836','test'),('2019-02-18 03:59:59','2019-02-18 11:59:59','NEBLBTC','4h','0.000301300000000','0.000297500000000','0.001468829050230','0.001450304156799','4.874971955625622','4.874971955625622','test'),('2019-02-21 07:59:59','2019-02-21 19:59:59','NEBLBTC','4h','0.000307700000000','0.000293900000000','0.001468829050230','0.001402953714211','4.773575073870653','4.773575073870653','test'),('2019-02-21 23:59:59','2019-02-22 03:59:59','NEBLBTC','4h','0.000295000000000','0.000293900000000','0.001468829050230','0.001463352060551','4.979081526203389','4.979081526203389','test'),('2019-02-22 11:59:59','2019-02-22 15:59:59','NEBLBTC','4h','0.000297400000000','0.000305000000000','0.001468829050230','0.001506364695091','4.938900639643577','4.938900639643577','test'),('2019-02-23 11:59:59','2019-02-23 19:59:59','NEBLBTC','4h','0.000301800000000','0.000300400000000','0.001468829050230','0.001462015396584','4.866895461332008','4.866895461332008','test'),('2019-02-24 03:59:59','2019-02-24 15:59:59','NEBLBTC','4h','0.000300000000000','0.000292100000000','0.001468829050230','0.001430149885241','4.8960968341','4.896096834100000','test'),('2019-02-27 23:59:59','2019-03-01 23:59:59','NEBLBTC','4h','0.000308200000000','0.000300000000000','0.001468829050230','0.001429749237732','4.765830792439973','4.765830792439973','test'),('2019-03-02 03:59:59','2019-03-02 07:59:59','NEBLBTC','4h','0.000301200000000','0.000300700000000','0.001468829050230','0.001466390754994','4.876590472211155','4.876590472211155','test'),('2019-03-02 19:59:59','2019-03-03 19:59:59','NEBLBTC','4h','0.000303200000000','0.000301400000000','0.001468829050230','0.001460109088850','4.844422988885224','4.844422988885224','test'),('2019-03-06 07:59:59','2019-03-06 23:59:59','NEBLBTC','4h','0.000304800000000','0.000301000000000','0.001468829050230','0.001450516877032','4.818992946948819','4.818992946948819','test'),('2019-03-07 03:59:59','2019-03-11 15:59:59','NEBLBTC','4h','0.000303900000000','0.000316600000000','0.001468829050230','0.001530211508071','4.833264396939782','4.833264396939782','test'),('2019-03-12 11:59:59','2019-03-18 11:59:59','NEBLBTC','4h','0.000340300000000','0.000367300000000','0.001468829050230','0.001585368528209','4.316276962180429','4.316276962180429','test'),('2019-03-28 23:59:59','2019-03-31 23:59:59','NEBLBTC','4h','0.000382000000000','0.000369600000000','0.001468829050230','0.001421149782631','3.845102225732984','3.845102225732984','test'),('2019-04-01 19:59:59','2019-04-02 03:59:59','NEBLBTC','4h','0.000374500000000','0.000363100000000','0.001468829050230','0.001424117031077','3.9221069432042723','3.922106943204272','test'),('2019-06-02 23:59:59','2019-06-03 03:59:59','NEBLBTC','4h','0.000160900000000','0.000158900000000','0.001468829050230','0.001450571386461','9.128831884586699','9.128831884586699','test'),('2019-06-08 03:59:59','2019-06-08 23:59:59','NEBLBTC','4h','0.000160000000000','0.000166900000000','0.001468829050230','0.001532172303021','9.180181563937499','9.180181563937499','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  7:22:39
