-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-10-12 03:59:59','2018-10-13 19:59:59','GNTETH','4h','0.000783650000000','0.000742060000000','0.072144500000000','0.068315635385695','92.06214509028266','92.062145090282655','test'),('2018-10-17 23:59:59','2018-10-20 11:59:59','GNTETH','4h','0.000761510000000','0.000749630000000','0.072144500000000','0.071019003735998','94.73874276109309','94.738742761093093','test'),('2018-10-20 19:59:59','2018-10-27 19:59:59','GNTETH','4h','0.000760150000000','0.000856920000000','0.072144500000000','0.081328770558442','94.90824179438269','94.908241794382690','test'),('2018-10-31 03:59:59','2018-11-02 23:59:59','GNTETH','4h','0.000871310000000','0.000864150000000','0.073201977420034','0.072600439324147','84.01370054289947','84.013700542899471','test'),('2018-11-22 23:59:59','2018-11-24 19:59:59','GNTETH','4h','0.000778360000000','0.000720700000000','0.073201977420034','0.067779260402151','94.04642764277969','94.046427642779690','test'),('2018-11-25 07:59:59','2018-11-25 11:59:59','GNTETH','4h','0.000740700000000','0.000741350000000','0.073201977420034','0.073266215688325','98.82810506282435','98.828105062824349','test'),('2018-11-25 23:59:59','2018-11-26 03:59:59','GNTETH','4h','0.000735770000000','0.000730060000000','0.073201977420034','0.072633887811775','99.49029916962365','99.490299169623654','test'),('2018-11-26 07:59:59','2018-11-26 11:59:59','GNTETH','4h','0.000742730000000','0.000728440000000','0.073201977420034','0.071793583713933','98.5579920294508','98.557992029450801','test'),('2018-11-29 03:59:59','2018-11-30 15:59:59','GNTETH','4h','0.000751390000000','0.000753440000000','0.073201977420034','0.073401692686022','97.42208096998097','97.422080969980968','test'),('2018-11-30 23:59:59','2018-12-05 03:59:59','GNTETH','4h','0.000769640000000','0.000808950000000','0.073201977420034','0.076940829003088','95.111971077431','95.111971077430994','test'),('2019-01-10 11:59:59','2019-01-14 15:59:59','GNTETH','4h','0.000499970000000','0.000494520000000','0.073201977420034','0.072404027989190','146.41273960444425','146.412739604444255','test'),('2019-01-16 03:59:59','2019-01-20 23:59:59','GNTETH','4h','0.000522060000000','0.000544490000000','0.073201977420034','0.076347057206900','140.21755625796652','140.217556257966521','test'),('2019-01-21 03:59:59','2019-01-22 07:59:59','GNTETH','4h','0.000549810000000','0.000545820000000','0.073201977420034','0.072670746831456','133.14049839041488','133.140498390414876','test'),('2019-01-22 11:59:59','2019-01-22 19:59:59','GNTETH','4h','0.000557500000000','0.000546080000000','0.073201977420034','0.071702485792883','131.30399537225827','131.303995372258271','test'),('2019-01-22 23:59:59','2019-01-27 11:59:59','GNTETH','4h','0.000550810000000','0.000564740000000','0.073201977420034','0.075053257435758','132.8987807411521','132.898780741152109','test'),('2019-02-27 19:59:59','2019-02-28 11:59:59','GNTETH','4h','0.000482000000000','0.000468580000000','0.073201977420034','0.071163864272779','151.8713224482033','151.871322448203301','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','GNTETH','4h','0.000471080000000','0.000468960000000','0.073201977420034','0.072872546766789','155.39181756821344','155.391817568213440','test'),('2019-02-28 23:59:59','2019-03-05 11:59:59','GNTETH','4h','0.000473720000000','0.000494540000000','0.073201977420034','0.076419205254799','154.52583260160853','154.525832601608528','test'),('2019-03-07 15:59:59','2019-03-15 23:59:59','GNTETH','4h','0.000503430000000','0.000559020000000','0.073201977420034','0.081285122891658','145.40646648001507','145.406466480015069','test'),('2019-03-20 11:59:59','2019-03-23 03:59:59','GNTETH','4h','0.000608730000000','0.000570620000000','0.074977623507811','0.070283592932872','123.1705739947284','123.170573994728400','test'),('2019-03-24 23:59:59','2019-03-27 11:59:59','GNTETH','4h','0.000582190000000','0.000591620000000','0.074977623507811','0.076192070663686','128.78548842785173','128.785488427851732','test'),('2019-03-27 15:59:59','2019-03-30 19:59:59','GNTETH','4h','0.000613570000000','0.000613350000000','0.074977623507811','0.074950739733879','122.19897242011668','122.198972420116675','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','GNTETH','4h','0.000635900000000','0.000627640000000','0.074977623507811','0.074003704385033','117.90788411355716','117.907884113557159','test'),('2019-05-24 23:59:59','2019-05-26 19:59:59','GNTETH','4h','0.000384410000000','0.000367410000000','0.074977623507811','0.071661841921399','195.04597567131705','195.045975671317052','test'),('2019-05-29 03:59:59','2019-05-30 03:59:59','GNTETH','4h','0.000396980000000','0.000369130000000','0.074977623507811','0.069717593242577','188.87002747697866','188.870027476978663','test'),('2019-06-08 07:59:59','2019-06-12 19:59:59','GNTETH','4h','0.000400990000000','0.000392380000000','0.074977623507811','0.073367714686139','186.98128010127684','186.981280101276838','test'),('2019-06-13 03:59:59','2019-06-13 19:59:59','GNTETH','4h','0.000420310000000','0.000396090000000','0.074977623507811','0.070657102841257','178.3864849939592','178.386484993959186','test'),('2019-07-04 11:59:59','2019-07-05 07:59:59','GNTETH','4h','0.000320040000000','0.000318460000000','0.074977623507811','0.074607467761210','234.27578898828583','234.275788988285825','test'),('2019-07-06 07:59:59','2019-07-07 11:59:59','GNTETH','4h','0.000323060000000','0.000317980000000','0.074977623507811','0.073798627880312','232.0857534445954','232.085753444595412','test'),('2019-07-20 11:59:59','2019-07-20 15:59:59','GNTETH','4h','0.000299990000000','0.000292520000000','0.074977623507811','0.073110618448965','249.93374281746392','249.933742817463923','test'),('2019-07-20 23:59:59','2019-07-23 15:59:59','GNTETH','4h','0.000290890000000','0.000290000000000','0.074977623507811','0.074748223786535','257.7524958156382','257.752495815638213','test'),('2019-07-28 03:59:59','2019-07-29 11:59:59','GNTETH','4h','0.000294940000000','0.000289320000000','0.074977623507811','0.073548945661083','254.2131399871533','254.213139987153312','test'),('2019-07-29 15:59:59','2019-07-29 19:59:59','GNTETH','4h','0.000290060000000','0.000288210000000','0.074977623507811','0.074499416917832','258.49004863756113','258.490048637561131','test'),('2019-07-30 15:59:59','2019-08-01 19:59:59','GNTETH','4h','0.000306810000000','0.000286900000000','0.074977623507811','0.070112056922496','244.37803040256506','244.378030402565059','test'),('2019-08-13 23:59:59','2019-08-14 03:59:59','GNTETH','4h','0.000269560000000','0.000267250000000','0.074977623507811','0.074335101211094','278.14818039698395','278.148180396983946','test'),('2019-08-14 19:59:59','2019-08-15 01:59:59','GNTETH','4h','0.000273000000000','0.000269070000000','0.074977623507811','0.073898275301270','274.6433095524212','274.643309552421215','test'),('2019-08-15 15:59:59','2019-08-15 23:59:59','GNTETH','4h','0.000269850000000','0.000268900000000','0.074977623507811','0.074713666708358','277.849262582216','277.849262582215999','test'),('2019-08-16 03:59:59','2019-08-16 07:59:59','GNTETH','4h','0.000270520000000','0.000269160000000','0.074977623507811','0.074600684398057','277.1611101131561','277.161110113156099','test'),('2019-08-17 03:59:59','2019-08-17 23:59:59','GNTETH','4h','0.000280020000000','0.000268560000000','0.074977623507811','0.071909115667658','267.758101234951','267.758101234951027','test'),('2019-08-18 03:59:59','2019-08-18 07:59:59','GNTETH','4h','0.000269770000000','0.000268070000000','0.074977623507811','0.074505139688397','277.93165847874485','277.931658478744851','test'),('2019-08-18 15:59:59','2019-08-18 19:59:59','GNTETH','4h','0.000277990000000','0.000268210000000','0.074977623507811','0.072339826616173','269.71338360304685','269.713383603046850','test'),('2019-08-19 03:59:59','2019-08-19 07:59:59','GNTETH','4h','0.000275930000000','0.000263790000000','0.074977623507811','0.071678858062282','271.7269724488493','271.726972448849324','test'),('2019-08-22 07:59:59','2019-08-22 15:59:59','GNTETH','4h','0.000276310000000','0.000271460000000','0.074977623507811','0.073661560122436','271.3532753349897','271.353275334989689','test'),('2019-08-22 23:59:59','2019-09-01 03:59:59','GNTETH','4h','0.000273920000000','0.000351740000000','0.074977623507811','0.096278582405949','273.72088021251096','273.720880212510963','test'),('2019-09-14 11:59:59','2019-09-14 15:59:59','GNTETH','4h','0.000335200000000','0.000326810000000','0.074977623507811','0.073100946117505','223.68026106148864','223.680261061488636','test'),('2019-10-06 03:59:59','2019-10-09 15:59:59','GNTETH','4h','0.000282080000000','0.000265950000000','0.074977623507811','0.070690226077362','265.80269252627266','265.802692526272665','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  7:58:03
