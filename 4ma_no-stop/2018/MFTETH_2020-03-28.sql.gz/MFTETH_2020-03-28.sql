-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 11:59:59','2019-01-14 15:59:59','MFTETH','4h','0.000021170000000','0.000020890000000','0.072144500000000','0.071190297827114','3407.864903164856','3407.864903164856059','test'),('2019-01-16 07:59:59','2019-01-22 19:59:59','MFTETH','4h','0.000022090000000','0.000024290000000','0.072144500000000','0.079329556586691','3265.9348121321864','3265.934812132186380','test'),('2019-01-23 03:59:59','2019-01-26 15:59:59','MFTETH','4h','0.000024750000000','0.000024410000000','0.073702213603451','0.072689738749909','2977.8672163010606','2977.867216301060580','test'),('2019-01-27 23:59:59','2019-01-28 07:59:59','MFTETH','4h','0.000026350000000','0.000025630000000','0.073702213603451','0.071688339076146','2797.047954590171','2797.047954590170775','test'),('2019-01-28 11:59:59','2019-01-31 11:59:59','MFTETH','4h','0.000025790000000','0.000026070000000','0.073702213603451','0.074502392735245','2857.7826135498644','2857.782613549864436','test'),('2019-02-01 15:59:59','2019-02-02 07:59:59','MFTETH','4h','0.000028550000000','0.000027610000000','0.073702213603451','0.071275590808801','2581.513611329282','2581.513611329281957','test'),('2019-02-02 11:59:59','2019-02-03 03:59:59','MFTETH','4h','0.000027870000000','0.000026800000000','0.073702213603451','0.070872598657068','2644.4999498905995','2644.499949890599510','test'),('2019-02-05 03:59:59','2019-02-08 15:59:59','MFTETH','4h','0.000027870000000','0.000028980000000','0.073702213603451','0.076637608547830','2644.4999498905995','2644.499949890599510','test'),('2019-03-03 07:59:59','2019-03-04 11:59:59','MFTETH','4h','0.000022700000000','0.000022580000000','0.073702213603451','0.073312598377353','3246.7935508128194','3246.793550812819376','test'),('2019-03-04 19:59:59','2019-03-05 19:59:59','MFTETH','4h','0.000022740000000','0.000021930000000','0.073702213603451','0.071076936865597','3241.082392412093','3241.082392412093213','test'),('2019-03-10 07:59:59','2019-03-16 03:59:59','MFTETH','4h','0.000022260000000','0.000022840000000','0.073702213603451','0.075622576761133','3310.97096152071','3310.970961520709807','test'),('2019-03-19 03:59:59','2019-03-22 11:59:59','MFTETH','4h','0.000024090000000','0.000024680000000','0.073702213603451','0.075507290648949','3059.4526194873806','3059.452619487380616','test'),('2019-03-23 19:59:59','2019-03-25 07:59:59','MFTETH','4h','0.000025670000000','0.000024810000000','0.073702213603451','0.071233031534929','2871.141940142228','2871.141940142228123','test'),('2019-04-01 19:59:59','2019-04-02 07:59:59','MFTETH','4h','0.000024920000000','0.000024800000000','0.073702213603451','0.073347307277913','2957.552712819061','2957.552712819061071','test'),('2019-04-15 11:59:59','2019-04-15 23:59:59','MFTETH','4h','0.000024320000000','0.000023200000000','0.073702213603451','0.070308032713818','3030.518651457689','3030.518651457688975','test'),('2019-04-16 03:59:59','2019-04-16 07:59:59','MFTETH','4h','0.000023560000000','0.000023010000000','0.073702213603451','0.071981661078752','3128.277317633743','3128.277317633743223','test'),('2019-05-05 07:59:59','2019-05-05 23:59:59','MFTETH','4h','0.000020070000000','0.000019030000000','0.073702213603451','0.069883065514383','3672.257777949726','3672.257777949726005','test'),('2019-05-06 07:59:59','2019-05-06 15:59:59','MFTETH','4h','0.000019240000000','0.000018110000000','0.073702213603451','0.069373549290982','3830.676382715749','3830.676382715748787','test'),('2019-05-08 07:59:59','2019-05-08 23:59:59','MFTETH','4h','0.000018800000000','0.000018620000000','0.073702213603451','0.072996554111503','3920.330510821862','3920.330510821861935','test'),('2019-05-09 03:59:59','2019-05-09 23:59:59','MFTETH','4h','0.000018910000000','0.000018640000000','0.073702213603451','0.072649881627093','3897.5258383633527','3897.525838363352705','test'),('2019-05-10 03:59:59','2019-05-10 07:59:59','MFTETH','4h','0.000018720000000','0.000018640000000','0.073702213603451','0.073387246878650','3937.084060013408','3937.084060013407907','test'),('2019-05-10 11:59:59','2019-05-10 23:59:59','MFTETH','4h','0.000019060000000','0.000019280000000','0.073702213603451','0.074552921210626','3866.8527598872506','3866.852759887250613','test'),('2019-05-11 07:59:59','2019-05-11 11:59:59','MFTETH','4h','0.000019690000000','0.000018400000000','0.073702213603451','0.068873576958024','3743.1291825013204','3743.129182501320429','test'),('2019-05-12 03:59:59','2019-05-12 07:59:59','MFTETH','4h','0.000019210000000','0.000018850000000','0.073702213603451','0.072321016471892','3836.658698774128','3836.658698774127970','test'),('2019-05-12 11:59:59','2019-05-12 19:59:59','MFTETH','4h','0.000018860000000','0.000018710000000','0.073702213603451','0.073116034810210','3907.858621603977','3907.858621603977099','test'),('2019-05-13 11:59:59','2019-05-14 07:59:59','MFTETH','4h','0.000019600000000','0.000018870000000','0.073702213603451','0.070957182178425','3760.317020584235','3760.317020584234797','test'),('2019-05-14 11:59:59','2019-05-14 15:59:59','MFTETH','4h','0.000019090000000','0.000019200000000','0.073702213603451','0.074126898962088','3860.7759876087484','3860.775987608748437','test'),('2019-06-04 11:59:59','2019-06-04 23:59:59','MFTETH','4h','0.000015220000000','0.000014420000000','0.073702213603451','0.069828247053992','4842.4581868233245','4842.458186823324468','test'),('2019-06-05 03:59:59','2019-06-05 19:59:59','MFTETH','4h','0.000014970000000','0.000015210000000','0.073702213603451','0.074883812218336','4923.327562020775','4923.327562020775076','test'),('2019-06-06 03:59:59','2019-06-08 15:59:59','MFTETH','4h','0.000015290000000','0.000014850000000','0.073702213603451','0.071581286593280','4820.2886594801175','4820.288659480117531','test'),('2019-06-08 19:59:59','2019-06-08 23:59:59','MFTETH','4h','0.000015270000000','0.000015200000000','0.073702213603451','0.073364351458576','4826.602069643156','4826.602069643156028','test'),('2019-07-22 23:59:59','2019-07-24 03:59:59','MFTETH','4h','0.000008320000000','0.000008190000000','0.073702213603451','0.072550616515897','8858.439135030168','8858.439135030168472','test'),('2019-07-27 11:59:59','2019-07-27 15:59:59','MFTETH','4h','0.000008200000000','0.000008260000000','0.073702213603451','0.074241498093232','8988.074829689147','8988.074829689147009','test'),('2019-07-27 23:59:59','2019-07-28 23:59:59','MFTETH','4h','0.000008260000000','0.000008220000000','0.073702213603451','0.073345302157429','8922.786150538861','8922.786150538860966','test'),('2019-07-29 03:59:59','2019-07-29 11:59:59','MFTETH','4h','0.000008250000000','0.000008760000000','0.073702213603451','0.078258350444392','8933.601648903152','8933.601648903151727','test'),('2019-07-29 19:59:59','2019-07-31 03:59:59','MFTETH','4h','0.000008470000000','0.000008310000000','0.073702213603451','0.072309963995830','8701.56004763294','8701.560047632940041','test'),('2019-07-31 07:59:59','2019-07-31 11:59:59','MFTETH','4h','0.000008410000000','0.000008340000000','0.073702213603451','0.073088758793434','8763.64014309762','8763.640143097620239','test'),('2019-08-24 11:59:59','2019-08-26 11:59:59','MFTETH','4h','0.000006860000000','0.000006170000000','0.073702213603451','0.066289017191442','10743.762915954956','10743.762915954956043','test'),('2019-08-26 19:59:59','2019-08-27 23:59:59','MFTETH','4h','0.000006400000000','0.000006290000000','0.073702213603451','0.072435456807142','11515.970875539218','11515.970875539218468','test'),('2019-09-09 19:59:59','2019-09-11 19:59:59','MFTETH','4h','0.000006990000000','0.000006230000000','0.073702213603451','0.065688811266023','10543.950443984406','10543.950443984405865','test'),('2019-10-03 19:59:59','2019-10-06 19:59:59','MFTETH','4h','0.000005320000000','0.000005020000000','0.073702213603451','0.069546073738595','13853.799549520865','13853.799549520865185','test'),('2019-10-08 15:59:59','2019-10-09 15:59:59','MFTETH','4h','0.000005280000000','0.000005040000000','0.073702213603451','0.070352112985112','13958.752576411174','13958.752576411174232','test'),('2019-10-11 23:59:59','2019-10-16 15:59:59','MFTETH','4h','0.000005240000000','0.000005200000000','0.073702213603451','0.073139601285867','14065.307939589886','14065.307939589885791','test'),('2019-10-20 23:59:59','2019-10-23 03:59:59','MFTETH','4h','0.000005380000000','0.000005370000000','0.073702213603451','0.073565220641363','13699.296208819887','13699.296208819887397','test'),('2019-10-23 07:59:59','2019-10-23 15:59:59','MFTETH','4h','0.000005380000000','0.000005100000000','0.073702213603451','0.069866410664981','13699.296208819887','13699.296208819887397','test'),('2019-10-25 19:59:59','2019-10-25 23:59:59','MFTETH','4h','0.000005210000000','0.000005240000000','0.073702213603451','0.074126602549344','14146.298196439731','14146.298196439731328','test'),('2019-10-28 15:59:59','2019-10-29 19:59:59','MFTETH','4h','0.000005460000000','0.000005230000000','0.073702213603451','0.070597541601840','13498.57392004597','13498.573920045970226','test'),('2019-10-30 03:59:59','2019-10-30 07:59:59','MFTETH','4h','0.000005310000000','0.000005230000000','0.073702213603451','0.072591822438051','13879.889567504897','13879.889567504897059','test'),('2019-10-31 15:59:59','2019-11-02 11:59:59','MFTETH','4h','0.000005460000000','0.000005380000000','0.073702213603451','0.072622327689847','13498.57392004597','13498.573920045970226','test'),('2019-11-02 15:59:59','2019-11-03 07:59:59','MFTETH','4h','0.000005400000000','0.000005350000000','0.073702213603451','0.073019785699715','13648.558074713148','13648.558074713148017','test'),('2019-11-04 03:59:59','2019-11-05 19:59:59','MFTETH','4h','0.000005600000000','0.000005440000000','0.073702213603451','0.071596436071924','13161.109572044823','13161.109572044822926','test'),('2019-11-05 23:59:59','2019-11-06 03:59:59','MFTETH','4h','0.000005490000000','0.000005400000000','0.073702213603451','0.072493980593558','13424.811221029326','13424.811221029325679','test'),('2019-11-07 07:59:59','2019-11-08 15:59:59','MFTETH','4h','0.000005960000000','0.000005560000000','0.073702213603451','0.068755756314629','12366.143222055538','12366.143222055537990','test'),('2019-11-08 19:59:59','2019-11-08 23:59:59','MFTETH','4h','0.000005640000000','0.000005680000000','0.049134809068967','0.049483282892151','8711.845579604136','8711.845579604136219','test'),('2019-11-10 15:59:59','2019-11-11 07:59:59','MFTETH','4h','0.000005850000000','0.000005760000000','0.054694302793035','0.053852851980834','9349.453468894788','9349.453468894787875','test'),('2019-11-11 15:59:59','2019-11-12 07:59:59','MFTETH','4h','0.000005660000000','0.000005760000000','0.054694302793035','0.055660633231074','9663.304380394877','9663.304380394876716','test'),('2019-11-12 19:59:59','2019-11-13 23:59:59','MFTETH','4h','0.000005760000000','0.000005630000000','0.054725522699494','0.053490398055235','9500.958801995488','9500.958801995488102','test'),('2019-11-14 15:59:59','2019-11-15 15:59:59','MFTETH','4h','0.000006000000000','0.000005890000000','0.054725522699494','0.053722221450003','9120.920449915668','9120.920449915667632','test'),('2019-11-15 23:59:59','2019-11-16 11:59:59','MFTETH','4h','0.000005970000000','0.000005810000000','0.054725522699494','0.053258842024131','9166.754221020772','9166.754221020772093','test'),('2019-11-16 23:59:59','2019-11-20 23:59:59','MFTETH','4h','0.000005980000000','0.000006810000000','0.054725522699494','0.062321205615979','9151.42520058428','9151.425200584280901','test'),('2019-11-21 15:59:59','2019-11-24 11:59:59','MFTETH','4h','0.000007180000000','0.000007730000000','0.055698166786337','0.059964739451029','7757.404844893734','7757.404844893733753','test'),('2019-11-26 19:59:59','2019-11-27 11:59:59','MFTETH','4h','0.000008030000000','0.000008630000000','0.056764809952510','0.061006265241614','7069.092148506851','7069.092148506851117','test'),('2019-11-28 03:59:59','2019-11-29 11:59:59','MFTETH','4h','0.000008160000000','0.000007860000000','0.057825173774786','0.055699248268360','7086.4183547531875','7086.418354753187486','test'),('2019-12-09 07:59:59','2019-12-09 19:59:59','MFTETH','4h','0.000007520000000','0.000007360000000','0.057825173774786','0.056594850928514','7689.517789200266','7689.517789200265725','test'),('2019-12-09 23:59:59','2019-12-10 03:59:59','MFTETH','4h','0.000007500000000','0.000006870000000','0.057825173774786','0.052967859177704','7710.023169971467','7710.023169971466814','test'),('2019-12-13 03:59:59','2019-12-14 15:59:59','MFTETH','4h','0.000007470000000','0.000007170000000','0.057825173774786','0.055502877639252','7740.987118445248','7740.987118445247688','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:01:35
