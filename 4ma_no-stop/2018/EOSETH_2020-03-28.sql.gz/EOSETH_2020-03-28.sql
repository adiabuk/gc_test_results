-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-01-12 19:59:59','2018-01-14 23:59:59','EOSETH','4h','0.011136000000000','0.009795000000000','0.072144500000000','0.063456840651940','6.4784931752873565','6.478493175287356','test'),('2018-01-19 15:59:59','2018-01-24 19:59:59','EOSETH','4h','0.010424000000000','0.012945000000000','0.072144500000000','0.089592340032617','6.920999616270146','6.920999616270146','test'),('2018-01-24 23:59:59','2018-01-27 19:59:59','EOSETH','4h','0.013146000000000','0.013058000000000','0.074334545171139','0.073836945903296','5.654537134576239','5.654537134576239','test'),('2018-03-19 15:59:59','2018-03-25 23:59:59','EOSETH','4h','0.009899000000000','0.012316000000000','0.074334545171139','0.092484519479518','7.509298431269723','7.509298431269723','test'),('2018-03-27 15:59:59','2018-04-01 15:59:59','EOSETH','4h','0.013054000000000','0.014571000000000','0.078747638931273','0.087898869838178','6.0324528061340015','6.032452806134001','test'),('2018-04-02 23:59:59','2018-04-03 11:59:59','EOSETH','4h','0.015099000000000','0.014720000000000','0.081035446657999','0.079001375906070','5.3669412979667195','5.366941297966719','test'),('2018-04-04 19:59:59','2018-04-07 19:59:59','EOSETH','4h','0.015018000000000','0.015225000000000','0.081035446657999','0.082152395483289','5.3958880448794115','5.395888044879412','test'),('2018-04-11 15:59:59','2018-04-14 11:59:59','EOSETH','4h','0.016923000000000','0.016849000000000','0.081035446657999','0.080681099139669','4.7884799774271105','4.788479977427111','test'),('2018-04-18 03:59:59','2018-04-19 19:59:59','EOSETH','4h','0.016955000000000','0.016568000000000','0.081035446657999','0.079185802431715','4.779442445178354','4.779442445178354','test'),('2018-04-20 07:59:59','2018-04-23 19:59:59','EOSETH','4h','0.017295000000000','0.017955000000000','0.081035446657999','0.084127866131505','4.68548405076606','4.685484050766060','test'),('2018-04-24 03:59:59','2018-04-30 19:59:59','EOSETH','4h','0.019405000000000','0.026930000000000','0.081035446657999','0.112459911285747','4.176008588404999','4.176008588404999','test'),('2018-05-02 11:59:59','2018-05-03 03:59:59','EOSETH','4h','0.027586000000000','0.026250000000000','0.088884389265500','0.084579686008097','3.2220832764989398','3.222083276498940','test'),('2018-05-10 23:59:59','2018-05-11 03:59:59','EOSETH','4h','0.023962000000000','0.023886000000000','0.088884389265500','0.088602475669632','3.7093894193097405','3.709389419309741','test'),('2018-05-25 11:59:59','2018-05-29 07:59:59','EOSETH','4h','0.020457000000000','0.021338000000000','0.088884389265500','0.092712279324790','4.3449376382411895','4.344937638241190','test'),('2018-05-29 11:59:59','2018-05-29 19:59:59','EOSETH','4h','0.021399000000000','0.021580000000000','0.088884389265500','0.089636203577246','4.153670230641619','4.153670230641619','test'),('2018-06-02 11:59:59','2018-06-04 15:59:59','EOSETH','4h','0.023539000000000','0.022838000000000','0.088884389265500','0.086237379754683','3.7760478043034964','3.776047804303496','test'),('2018-06-05 23:59:59','2018-06-06 15:59:59','EOSETH','4h','0.023304000000000','0.023001000000000','0.088884389265500','0.087728709127007','3.8141258696146587','3.814125869614659','test'),('2018-06-07 19:59:59','2018-06-08 07:59:59','EOSETH','4h','0.023764000000000','0.023240000000000','0.088884389265500','0.086924474269072','3.7402957947104865','3.740295794710486','test'),('2018-06-08 11:59:59','2018-06-10 03:59:59','EOSETH','4h','0.023250000000000','0.023028000000000','0.088884389265500','0.088035686709933','3.822984484537635','3.822984484537635','test'),('2018-07-03 15:59:59','2018-07-06 03:59:59','EOSETH','4h','0.019174000000000','0.018676000000000','0.088884389265500','0.086575824237117','4.63567274775738','4.635672747757380','test'),('2018-07-18 03:59:59','2018-07-21 03:59:59','EOSETH','4h','0.018023000000000','0.017092000000000','0.088884389265500','0.084292957960713','4.931719983659768','4.931719983659768','test'),('2018-07-23 07:59:59','2018-07-23 15:59:59','EOSETH','4h','0.017855000000000','0.017369000000000','0.088884389265500','0.086465021403107','4.9781231736488385','4.978123173648838','test'),('2018-07-23 23:59:59','2018-07-24 03:59:59','EOSETH','4h','0.017607000000000','0.017173000000000','0.088884389265500','0.086693452425537','5.048241566734822','5.048241566734822','test'),('2018-07-24 19:59:59','2018-07-27 03:59:59','EOSETH','4h','0.017922000000000','0.017617000000000','0.088884389265500','0.087371737846798','4.9595128482033255','4.959512848203325','test'),('2018-08-17 19:59:59','2018-08-21 11:59:59','EOSETH','4h','0.017239000000000','0.017188000000000','0.088884389265500','0.088621432954082','5.156006106241661','5.156006106241661','test'),('2018-08-22 03:59:59','2018-08-22 23:59:59','EOSETH','4h','0.017841000000000','0.017455000000000','0.088884389265500','0.086961325857816','4.982029553584441','4.982029553584441','test'),('2018-08-23 11:59:59','2018-09-05 19:59:59','EOSETH','4h','0.017588000000000','0.022067000000000','0.088884389265500','0.111519889579360','5.0536950912838305','5.053695091283831','test'),('2018-09-06 23:59:59','2018-09-13 15:59:59','EOSETH','4h','0.022797000000000','0.026184000000000','0.089086466379747','0.102322236947287','3.9078153432358307','3.907815343235831','test'),('2018-09-13 19:59:59','2018-09-13 23:59:59','EOSETH','4h','0.026598000000000','0.025547000000000','0.092395409021632','0.088744473805385','3.4737728032796538','3.473772803279654','test'),('2018-09-20 15:59:59','2018-09-21 19:59:59','EOSETH','4h','0.025140000000000','0.024698000000000','0.092395409021632','0.090770955131912','3.675235044615434','3.675235044615434','test'),('2018-09-21 23:59:59','2018-09-22 03:59:59','EOSETH','4h','0.024940000000000','0.024677000000000','0.092395409021632','0.091421070907250','3.704707659247474','3.704707659247474','test'),('2018-09-26 03:59:59','2018-09-28 07:59:59','EOSETH','4h','0.025288000000000','0.026086000000000','0.092395409021632','0.095311081925747','3.6537254437532423','3.653725443753242','test'),('2018-09-28 19:59:59','2018-09-29 11:59:59','EOSETH','4h','0.026190000000000','0.024723000000000','0.092395409021632','0.087219996076434','3.5278888515323406','3.527888851532341','test'),('2018-10-03 23:59:59','2018-10-06 15:59:59','EOSETH','4h','0.025460000000000','0.025446000000000','0.092395409021632','0.092344602433796','3.6290419882809113','3.629041988280911','test'),('2018-10-08 11:59:59','2018-10-13 15:59:59','EOSETH','4h','0.025634000000000','0.026194000000000','0.092395409021632','0.094413877815114','3.60440855978903','3.604408559789030','test'),('2018-10-18 11:59:59','2018-10-20 07:59:59','EOSETH','4h','0.026257000000000','0.026342000000000','0.092395409021632','0.092694514394174','3.5188867357897706','3.518886735789771','test'),('2018-10-20 11:59:59','2018-10-20 23:59:59','EOSETH','4h','0.026350000000000','0.026226000000000','0.092395409021632','0.091960607096824','3.506467135545807','3.506467135545807','test'),('2018-10-21 03:59:59','2018-10-24 23:59:59','EOSETH','4h','0.026496000000000','0.026489000000000','0.092395409021632','0.092370999002642','3.4871455699589373','3.487145569958937','test'),('2018-10-25 03:59:59','2018-10-26 11:59:59','EOSETH','4h','0.026654000000000','0.026482000000000','0.092395409021632','0.091799175422483','3.4664744136576875','3.466474413657687','test'),('2018-11-02 11:59:59','2018-11-03 23:59:59','EOSETH','4h','0.026520000000000','0.026584000000000','0.092395409021632','0.092618384367687','3.4839897821128205','3.483989782112821','test'),('2018-11-04 03:59:59','2018-11-04 19:59:59','EOSETH','4h','0.026620000000000','0.025901000000000','0.092395409021632','0.089899830543550','3.470901916665364','3.470901916665364','test'),('2018-11-17 15:59:59','2018-11-18 19:59:59','EOSETH','4h','0.026219000000000','0.025790000000000','0.092395409021632','0.090883618698955','3.523986766147908','3.523986766147908','test'),('2018-11-18 23:59:59','2018-11-19 03:59:59','EOSETH','4h','0.025916000000000','0.026028000000000','0.092395409021632','0.092794710063862','3.5651878770501617','3.565187877050162','test'),('2018-11-19 07:59:59','2018-11-27 11:59:59','EOSETH','4h','0.026720000000000','0.028041000000000','0.092395409021632','0.096963310792499','3.4579120142826345','3.457912014282635','test'),('2018-12-15 23:59:59','2018-12-20 11:59:59','EOSETH','4h','0.022515000000000','0.024440000000000','0.092395409021632','0.100295083121860','4.1037268053134355','4.103726805313435','test'),('2019-01-10 03:59:59','2019-01-10 19:59:59','EOSETH','4h','0.019393000000000','0.018863000000000','0.092841493579740','0.090304186737206','4.787371401007566','4.787371401007566','test'),('2019-01-10 23:59:59','2019-01-10 23:59:59','EOSETH','4h','0.018998000000000','0.018998000000000','0.092841493579740','0.092841493579740','4.886908810387409','4.886908810387409','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 20:19:58
