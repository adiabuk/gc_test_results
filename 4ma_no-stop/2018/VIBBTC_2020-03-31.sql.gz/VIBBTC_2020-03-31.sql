-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-16 19:59:59','2018-04-21 03:59:59','VIBBTC','4h','0.000021160000000','0.000021270000000','0.001467500000000','0.001475128780718','69.35255198487712','69.352551984877124','test'),('2018-04-22 23:59:59','2018-04-24 23:59:59','VIBBTC','4h','0.000022320000000','0.000021930000000','0.001469407195179','0.001443732069457','65.83365569800627','65.833655698006268','test'),('2018-04-26 23:59:59','2018-04-27 15:59:59','VIBBTC','4h','0.000023110000000','0.000022940000000','0.001469407195179','0.001458598055275','63.58317590562527','63.583175905625268','test'),('2018-04-27 23:59:59','2018-05-03 19:59:59','VIBBTC','4h','0.000023480000000','0.000023410000000','0.001469407195179','0.001465026509333','62.581226370485524','62.581226370485524','test'),('2018-05-15 07:59:59','2018-05-16 07:59:59','VIBBTC','4h','0.000023880000000','0.000021870000000','0.001469407195179','0.001345725936288','61.532964622236186','61.532964622236186','test'),('2018-05-16 11:59:59','2018-05-16 15:59:59','VIBBTC','4h','0.000022170000000','0.000022010000000','0.001469407195179','0.001458802542440','66.27907962016238','66.279079620162378','test'),('2018-05-16 19:59:59','2018-05-16 23:59:59','VIBBTC','4h','0.000022830000000','0.000022100000000','0.001469407195179','0.001422422208211','64.36299584664914','64.362995846649142','test'),('2018-05-17 19:59:59','2018-05-19 11:59:59','VIBBTC','4h','0.000024870000000','0.000022910000000','0.001469407195179','0.001353603491819','59.08352212219541','59.083522122195411','test'),('2018-05-20 23:59:59','2018-05-22 03:59:59','VIBBTC','4h','0.000023480000000','0.000022760000000','0.001469407195179','0.001424348712192','62.581226370485524','62.581226370485524','test'),('2018-07-04 15:59:59','2018-07-07 19:59:59','VIBBTC','4h','0.000012400000000','0.000012740000000','0.001469407195179','0.001509697392466','118.50058025637097','118.500580256370966','test'),('2018-07-09 23:59:59','2018-07-10 07:59:59','VIBBTC','4h','0.000013120000000','0.000012510000000','0.001469407195179','0.001401088720403','111.99749963254573','111.997499632545725','test'),('2018-08-25 19:59:59','2018-08-26 03:59:59','VIBBTC','4h','0.000005840000000','0.000005620000000','0.001469407195179','0.001414052814539','251.61082109229451','251.610821092294515','test'),('2018-08-26 07:59:59','2018-08-26 11:59:59','VIBBTC','4h','0.000005770000000','0.000005690000000','0.001469407195179','0.001449034131814','254.66329205875218','254.663292058752177','test'),('2018-08-26 15:59:59','2018-08-27 03:59:59','VIBBTC','4h','0.000005760000000','0.000005670000000','0.001469407195179','0.001446447707754','255.1054158296875','255.105415829687502','test'),('2018-08-27 07:59:59','2018-08-27 15:59:59','VIBBTC','4h','0.000005820000000','0.000005750000000','0.001469407195179','0.001451733912763','252.47546308917524','252.475463089175236','test'),('2018-08-27 23:59:59','2018-08-29 03:59:59','VIBBTC','4h','0.000005790000000','0.000005720000000','0.001469407195179','0.001451642341351','253.78362611036272','253.783626110362718','test'),('2018-08-29 07:59:59','2018-08-29 15:59:59','VIBBTC','4h','0.000005950000000','0.000005740000000','0.001469407195179','0.001417545764761','246.9591924670588','246.959192467058813','test'),('2018-08-29 19:59:59','2018-08-29 23:59:59','VIBBTC','4h','0.000005860000000','0.000005730000000','0.001469407195179','0.001436809424637','250.75208108856654','250.752081088566541','test'),('2018-09-01 19:59:59','2018-09-02 03:59:59','VIBBTC','4h','0.000005880000000','0.000005790000000','0.001469407195179','0.001446916268722','249.89918285357143','249.899182853571432','test'),('2018-09-02 07:59:59','2018-09-02 11:59:59','VIBBTC','4h','0.000005930000000','0.000005610000000','0.001469407195179','0.001390113720903','247.79210711281618','247.792107112816183','test'),('2018-09-05 07:59:59','2018-09-05 11:59:59','VIBBTC','4h','0.000006030000000','0.000005400000000','0.001469407195179','0.001315887040459','243.68278527014925','243.682785270149253','test'),('2018-09-17 03:59:59','2018-09-19 07:59:59','VIBBTC','4h','0.000005820000000','0.000005280000000','0.001469407195179','0.001333070445111','252.47546308917524','252.475463089175236','test'),('2018-09-21 03:59:59','2018-09-21 15:59:59','VIBBTC','4h','0.000005500000000','0.000005330000000','0.001469407195179','0.001423989154601','267.164944578','267.164944578000018','test'),('2018-09-21 19:59:59','2018-09-24 11:59:59','VIBBTC','4h','0.000005730000000','0.000005390000000','0.001469407195179','0.001382217239444','256.44104627905756','256.441046279057559','test'),('2018-09-24 15:59:59','2018-09-24 23:59:59','VIBBTC','4h','0.000005660000000','0.000005580000000','0.001469407195179','0.001448638188887','259.61257865353355','259.612578653533546','test'),('2018-09-25 19:59:59','2018-09-28 07:59:59','VIBBTC','4h','0.000005920000000','0.000005910000000','0.001469407195179','0.001466925088430','248.21067486131756','248.210674861317557','test'),('2018-10-02 03:59:59','2018-10-09 15:59:59','VIBBTC','4h','0.000006100000000','0.000006580000000','0.001469407195179','0.001585032679390','240.88642543918033','240.886425439180329','test'),('2018-10-10 07:59:59','2018-10-11 15:59:59','VIBBTC','4h','0.000006860000000','0.000007030000000','0.001469407195179','0.001505821076109','214.1992995887755','214.199299588775489','test'),('2018-10-14 11:59:59','2018-10-14 19:59:59','VIBBTC','4h','0.000007000000000','0.000006640000000','0.001469407195179','0.001393837682284','209.915313597','209.915313596999994','test'),('2018-10-15 03:59:59','2018-10-15 07:59:59','VIBBTC','4h','0.000006640000000','0.000006260000000','0.001469407195179','0.001385314614732','221.29626433418673','221.296264334186731','test'),('2018-10-16 23:59:59','2018-10-22 19:59:59','VIBBTC','4h','0.000006790000000','0.000007040000000','0.001469407195179','0.001523509080127','216.40753979072164','216.407539790721643','test'),('2018-10-23 15:59:59','2018-10-25 19:59:59','VIBBTC','4h','0.000007700000000','0.000007380000000','0.001469407195179','0.001408340922133','190.83210326999998','190.832103269999976','test'),('2018-10-26 19:59:59','2018-10-27 15:59:59','VIBBTC','4h','0.000007650000000','0.000007350000000','0.001469407195179','0.001411783383603','192.07937191882354','192.079371918823540','test'),('2018-10-28 15:59:59','2018-10-29 11:59:59','VIBBTC','4h','0.000007660000000','0.000007430000000','0.001469407195179','0.001425286613601','191.8286155586162','191.828615558616207','test'),('2018-10-30 23:59:59','2018-11-02 07:59:59','VIBBTC','4h','0.000009340000000','0.000008080000000','0.001469407195179','0.001271178815530','157.32411083286937','157.324110832869366','test'),('2018-11-02 11:59:59','2018-11-02 15:59:59','VIBBTC','4h','0.000008270000000','0.000008100000000','0.000979604796786','0.000959467817892','118.45281702370012','118.452817023700121','test'),('2018-11-02 19:59:59','2018-11-02 23:59:59','VIBBTC','4h','0.000008200000000','0.000008140000000','0.001091455228827','0.001083468971055','133.1042961983842','133.104296198384191','test'),('2018-11-03 23:59:59','2018-11-04 11:59:59','VIBBTC','4h','0.000008260000000','0.000008060000000','0.001091455228827','0.001065027741446','132.13743690399514','132.137436903995138','test'),('2018-11-08 03:59:59','2018-11-09 11:59:59','VIBBTC','4h','0.000008130000000','0.000007900000000','0.001091455228827','0.001060577651628','134.25033564907747','134.250335649077471','test'),('2018-11-09 15:59:59','2018-11-09 19:59:59','VIBBTC','4h','0.000007970000000','0.000008030000000','0.001091455228827','0.001099671955769','136.94544903726475','136.945449037264751','test'),('2018-11-09 23:59:59','2018-11-10 15:59:59','VIBBTC','4h','0.000008120000000','0.000008040000000','0.001091455228827','0.001080701975341','134.41566857475368','134.415668574753681','test'),('2018-11-10 19:59:59','2018-11-11 07:59:59','VIBBTC','4h','0.000008200000000','0.000008220000000','0.001091455228827','0.001094117314751','133.10429619841463','133.104296198414630','test'),('2018-11-11 19:59:59','2018-11-13 15:59:59','VIBBTC','4h','0.000008370000000','0.000008190000000','0.001091455228827','0.001067983073368','130.4008636591398','130.400863659139787','test'),('2018-11-13 19:59:59','2018-11-13 23:59:59','VIBBTC','4h','0.000008300000000','0.000008220000000','0.001091455228827','0.001080935178429','131.50062997915663','131.500629979156628','test'),('2018-11-29 07:59:59','2018-11-30 11:59:59','VIBBTC','4h','0.000007280000000','0.000006060000000','0.001091455228827','0.000908546522897','149.92516879491757','149.925168794917568','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','VIBBTC','4h','0.000006240000000','0.000006140000000','0.001091455228827','0.001073963959134','174.91269692740383','174.912696927403829','test'),('2018-12-04 11:59:59','2018-12-06 03:59:59','VIBBTC','4h','0.000006260000000','0.000006110000000','0.001091455228827','0.001065302148264','174.35387041964856','174.353870419648558','test'),('2018-12-09 19:59:59','2018-12-10 15:59:59','VIBBTC','4h','0.000006460000000','0.000006130000000','0.001091455228827','0.001035699775961','168.95591777507738','168.955917775077381','test'),('2018-12-10 23:59:59','2018-12-11 03:59:59','VIBBTC','4h','0.000006150000000','0.000006160000000','0.001091455228827','0.001093229952776','177.4723949312195','177.472394931219497','test'),('2018-12-12 19:59:59','2018-12-13 23:59:59','VIBBTC','4h','0.000006220000000','0.000006080000000','0.001091455228827','0.001066888712423','175.47511717475885','175.475117174758850','test'),('2018-12-16 19:59:59','2018-12-16 23:59:59','VIBBTC','4h','0.000006130000000','0.000006070000000','0.001091455228827','0.001080772143390','178.05142395220227','178.051423952202271','test'),('2018-12-17 03:59:59','2018-12-17 07:59:59','VIBBTC','4h','0.000006140000000','0.000006190000000','0.001091455228827','0.001100343300723','177.76143791970685','177.761437919706850','test'),('2018-12-17 11:59:59','2018-12-17 23:59:59','VIBBTC','4h','0.000006260000000','0.000006170000000','0.001091455228827','0.001075763380489','174.35387041964856','174.353870419648558','test'),('2018-12-18 03:59:59','2018-12-18 11:59:59','VIBBTC','4h','0.000006220000000','0.000006150000000','0.001091455228827','0.001079171970625','175.47511717475885','175.475117174758850','test'),('2018-12-18 19:59:59','2018-12-18 23:59:59','VIBBTC','4h','0.000006130000000','0.000006250000000','0.001091455228827','0.001112821399701','178.05142395220227','178.051423952202271','test'),('2018-12-19 07:59:59','2018-12-19 23:59:59','VIBBTC','4h','0.000006210000000','0.000006130000000','0.001091455228827','0.001077394613963','175.75768580144927','175.757685801449270','test'),('2018-12-22 19:59:59','2018-12-25 03:59:59','VIBBTC','4h','0.000006360000000','0.000006150000000','0.001091455228827','0.001055416612781','171.61245736273585','171.612457362735853','test'),('2018-12-29 15:59:59','2018-12-30 03:59:59','VIBBTC','4h','0.000006320000000','0.000006290000000','0.001091455228827','0.001086274270462','172.6986121561709','172.698612156170896','test'),('2018-12-30 11:59:59','2018-12-31 19:59:59','VIBBTC','4h','0.000006410000000','0.000006160000000','0.001091455228827','0.001048886772164','170.273826650078','170.273826650078007','test'),('2019-01-02 19:59:59','2019-01-06 03:59:59','VIBBTC','4h','0.000006350000000','0.000006450000000','0.001091455228827','0.001108643500147','171.88271320110235','171.882713201102348','test'),('2019-01-06 07:59:59','2019-01-06 19:59:59','VIBBTC','4h','0.000006500000000','0.000006640000000','0.001091455228827','0.001114963495294','167.9161890503077','167.916189050307707','test'),('2019-01-07 07:59:59','2019-01-07 11:59:59','VIBBTC','4h','0.000006520000000','0.000006500000000','0.001091455228827','0.001088107206653','167.40110871579753','167.401108715797534','test'),('2019-01-07 15:59:59','2019-01-10 07:59:59','VIBBTC','4h','0.000006620000000','0.000006300000000','0.001091455228827','0.001038696063687','164.87239106148036','164.872391061480357','test'),('2019-01-16 15:59:59','2019-01-18 19:59:59','VIBBTC','4h','0.000006400000000','0.000006570000000','0.001091455228827','0.001120447008343','170.53987950421876','170.539879504218760','test'),('2019-01-18 23:59:59','2019-01-20 11:59:59','VIBBTC','4h','0.000006720000000','0.000006470000000','0.001091455228827','0.001050850495612','162.4189328611607','162.418932861160698','test'),('2019-01-22 15:59:59','2019-01-23 23:59:59','VIBBTC','4h','0.000006970000000','0.000006770000000','0.001091455228827','0.001060136570898','156.59328964519366','156.593289645193664','test'),('2019-01-24 07:59:59','2019-01-24 15:59:59','VIBBTC','4h','0.000006860000000','0.000006750000000','0.001091455228827','0.001073953760143','159.10426076195333','159.104260761953327','test'),('2019-01-25 03:59:59','2019-01-25 11:59:59','VIBBTC','4h','0.000006870000000','0.000006800000000','0.001091455228827','0.001080334142070','158.87266795152837','158.872667951528371','test'),('2019-01-25 15:59:59','2019-01-27 11:59:59','VIBBTC','4h','0.000007010000000','0.000006730000000','0.001091455228827','0.001047859299573','155.69974733623394','155.699747336233941','test'),('2019-02-09 19:59:59','2019-02-09 23:59:59','VIBBTC','4h','0.000006540000000','0.000006500000000','0.001091455228827','0.001084779661678','166.88917871972475','166.889178719724754','test'),('2019-02-10 03:59:59','2019-02-10 07:59:59','VIBBTC','4h','0.000006520000000','0.000006390000000','0.001091455228827','0.001069693084694','167.40110871579753','167.401108715797534','test'),('2019-02-27 07:59:59','2019-02-27 11:59:59','VIBBTC','4h','0.000006260000000','0.000006200000000','0.001091455228827','0.001080993996602','174.35387041964856','174.353870419648558','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','VIBBTC','4h','0.000006370000000','0.000006300000000','0.001091455228827','0.001079461215323','171.34305005133436','171.343050051334359','test'),('2019-02-28 11:59:59','2019-02-28 19:59:59','VIBBTC','4h','0.000006280000000','0.000006240000000','0.001091455228827','0.001084503284694','173.79860331640126','173.798603316401255','test'),('2019-03-01 07:59:59','2019-03-02 07:59:59','VIBBTC','4h','0.000006300000000','0.000006200000000','0.001091455228827','0.001074130542655','173.24686171857144','173.246861718571438','test'),('2019-03-02 11:59:59','2019-03-02 15:59:59','VIBBTC','4h','0.000006240000000','0.000006260000000','0.001091455228827','0.001094953482766','174.91269692740383','174.912696927403829','test'),('2019-03-02 19:59:59','2019-03-03 15:59:59','VIBBTC','4h','0.000006270000000','0.000006240000000','0.001091455228827','0.001086232955005','174.07579407129185','174.075794071291853','test'),('2019-03-03 23:59:59','2019-03-04 03:59:59','VIBBTC','4h','0.000006280000000','0.000006260000000','0.001091455228827','0.001087979256761','173.79860331640126','173.798603316401255','test'),('2019-03-04 23:59:59','2019-03-07 11:59:59','VIBBTC','4h','0.000006450000000','0.000006390000000','0.001091455228827','0.001081302156931','169.2178649344186','169.217864934418600','test'),('2019-03-07 15:59:59','2019-03-18 07:59:59','VIBBTC','4h','0.000006420000000','0.000007150000000','0.001091455228827','0.001215561508740','170.00860262102802','170.008602621028018','test'),('2019-03-27 03:59:59','2019-03-30 03:59:59','VIBBTC','4h','0.000007630000000','0.000008590000000','0.001091455228827','0.001228781181602','143.0478674740498','143.047867474049809','test'),('2019-04-08 23:59:59','2019-04-09 15:59:59','VIBBTC','4h','0.000008520000000','0.000007710000000','0.001091455228827','0.000987690119044','128.1050738059859','128.105073805985910','test'),('2019-04-09 19:59:59','2019-04-09 23:59:59','VIBBTC','4h','0.000007720000000','0.000007630000000','0.001091455228827','0.001078731009838','141.38021098795335','141.380210987953348','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  5:12:06
