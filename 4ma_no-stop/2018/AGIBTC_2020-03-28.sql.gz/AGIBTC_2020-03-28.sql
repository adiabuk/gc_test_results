-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-28 19:59:59','2018-11-30 15:59:59','AGIBTC','4h','0.000009140000000','0.000008920000000','0.001467500000000','0.001432177242888','160.55798687089714','160.557986870897139','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','AGIBTC','4h','0.000009090000000','0.000008970000000','0.001467500000000','0.001448127062706','161.44114411441146','161.441144114411458','test'),('2018-12-01 03:59:59','2018-12-06 23:59:59','AGIBTC','4h','0.000009410000000','0.000010840000000','0.001467500000000','0.001690510095643','155.95111583421894','155.951115834218939','test'),('2018-12-17 23:59:59','2018-12-25 03:59:59','AGIBTC','4h','0.000011100000000','0.000011290000000','0.001509578600309','0.001535418234008','135.99807209993241','135.998072099932415','test'),('2018-12-30 19:59:59','2019-01-07 15:59:59','AGIBTC','4h','0.000012240000000','0.000013550000000','0.001516038508734','0.001678294264162','123.8593552887255','123.859355288725496','test'),('2019-01-15 03:59:59','2019-01-15 15:59:59','AGIBTC','4h','0.000014120000000','0.000012570000000','0.001556602447591','0.001385728949449','110.24096654327195','110.240966543271952','test'),('2019-01-15 19:59:59','2019-01-15 23:59:59','AGIBTC','4h','0.000012970000000','0.000013130000000','0.001556602447591','0.001575804945017','120.01560891218197','120.015608912181975','test'),('2019-01-22 23:59:59','2019-01-23 19:59:59','AGIBTC','4h','0.000013480000000','0.000013080000000','0.001556602447591','0.001510412463983','115.47495902010387','115.474959020103867','test'),('2019-01-24 11:59:59','2019-01-24 15:59:59','AGIBTC','4h','0.000013270000000','0.000013020000000','0.001556602447591','0.001527276855135','117.3023698259985','117.302369825998497','test'),('2019-01-25 03:59:59','2019-01-27 15:59:59','AGIBTC','4h','0.000013600000000','0.000013620000000','0.001556602447591','0.001558891568837','114.45606232286765','114.456062322867652','test'),('2019-01-27 19:59:59','2019-01-28 03:59:59','AGIBTC','4h','0.000014320000000','0.000013390000000','0.001556602447591','0.001455510249528','108.70128823959497','108.701288239594973','test'),('2019-02-17 07:59:59','2019-02-18 03:59:59','AGIBTC','4h','0.000011990000000','0.000011960000000','0.001556602447591','0.001552707695846','129.82505818106756','129.825058181067561','test'),('2019-02-18 15:59:59','2019-02-18 19:59:59','AGIBTC','4h','0.000012010000000','0.000011720000000','0.001556602447591','0.001519015877250','129.60886324654456','129.608863246544558','test'),('2019-02-19 19:59:59','2019-02-21 19:59:59','AGIBTC','4h','0.000012530000000','0.000011920000000','0.001556602447591','0.001480822120933','124.23004370239425','124.230043702394255','test'),('2019-02-26 23:59:59','2019-02-27 23:59:59','AGIBTC','4h','0.000012160000000','0.000012290000000','0.001556602447591','0.001573243756652','128.01006970320725','128.010069703207250','test'),('2019-02-28 03:59:59','2019-02-28 11:59:59','AGIBTC','4h','0.000012440000000','0.000012170000000','0.001556602447591','0.001522817667780','125.12881411503217','125.128814115032171','test'),('2019-03-01 23:59:59','2019-03-02 15:59:59','AGIBTC','4h','0.000012350000000','0.000012210000000','0.001556602447591','0.001538956751829','126.04068401546559','126.040684015465587','test'),('2019-03-14 03:59:59','2019-03-18 11:59:59','AGIBTC','4h','0.000013540000000','0.000013680000000','0.001556602447591','0.001572697303031','114.96325314556869','114.963253145568686','test'),('2019-05-22 07:59:59','2019-05-24 15:59:59','AGIBTC','4h','0.000006320000000','0.000006210000000','0.001556602447591','0.001529509683472','246.29785563148738','246.297855631487380','test'),('2019-05-24 19:59:59','2019-05-24 23:59:59','AGIBTC','4h','0.000006240000000','0.000006140000000','0.001556602447591','0.001531656895546','249.45552044727563','249.455520447275632','test'),('2019-06-01 23:59:59','2019-06-02 07:59:59','AGIBTC','4h','0.000005900000000','0.000005780000000','0.001556602447591','0.001524942736793','263.8309233205085','263.830923320508475','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','AGIBTC','4h','0.000005840000000','0.000005870000000','0.001556602447591','0.001564598693041','266.5415149984589','266.541514998458922','test'),('2019-06-02 23:59:59','2019-06-09 15:59:59','AGIBTC','4h','0.000005990000000','0.000006190000000','0.001556602447591','0.001608575818128','259.86685268631055','259.866852686310551','test'),('2019-06-13 11:59:59','2019-06-13 19:59:59','AGIBTC','4h','0.000006330000000','0.000005960000000','0.001556602447591','0.001465616206579','245.90875949304896','245.908759493048962','test'),('2019-07-21 03:59:59','2019-07-21 11:59:59','AGIBTC','4h','0.000002550000000','0.000002670000000','0.001556602447591','0.001629854327478','610.4323323886274','610.432332388627401','test'),('2019-07-21 23:59:59','2019-07-25 15:59:59','AGIBTC','4h','0.000002660000000','0.000003260000000','0.001556602447591','0.001907715781634','585.1888900718045','585.188890071804508','test'),('2019-08-12 07:59:59','2019-08-14 19:59:59','AGIBTC','4h','0.000002850000000','0.000002970000000','0.001556602447591','0.001622143603279','546.1762974003509','546.176297400350904','test'),('2019-08-15 01:59:59','2019-08-19 11:59:59','AGIBTC','4h','0.000002990000000','0.000003130000000','0.001556602447591','0.001629486843130','520.602825281271','520.602825281270952','test'),('2019-08-22 03:59:59','2019-08-23 15:59:59','AGIBTC','4h','0.000003460000000','0.000003180000000','0.001556602447591','0.001430634619462','449.8851004598266','449.885100459826617','test'),('2019-08-25 11:59:59','2019-08-25 15:59:59','AGIBTC','4h','0.000003320000000','0.000003480000000','0.001556602447591','0.001631619433017','468.85615891295186','468.856158912951855','test'),('2019-08-25 19:59:59','2019-08-26 03:59:59','AGIBTC','4h','0.000003550000000','0.000003330000000','0.001556602447591','0.001460136943797','438.47956270169016','438.479562701690156','test'),('2019-08-26 07:59:59','2019-08-28 07:59:59','AGIBTC','4h','0.000003500000000','0.000003430000000','0.001556602447591','0.001525470398639','444.7435564545715','444.743556454571490','test'),('2019-09-18 23:59:59','2019-09-19 03:59:59','AGIBTC','4h','0.000002680000000','0.000002550000000','0.001556602447591','0.001481095612447','580.8218088026119','580.821808802611940','test'),('2019-09-19 07:59:59','2019-09-19 11:59:59','AGIBTC','4h','0.000002590000000','0.000002510000000','0.001556602447591','0.001508522063109','601.0048060196912','601.004806019691159','test'),('2019-09-19 15:59:59','2019-09-19 23:59:59','AGIBTC','4h','0.000002580000000','0.000002600000000','0.001556602447591','0.001568669133231','603.3342820120156','603.334282012015592','test'),('2019-09-20 03:59:59','2019-09-20 15:59:59','AGIBTC','4h','0.000002630000000','0.000002610000000','0.001556602447591','0.001544765166621','591.8640485136883','591.864048513688317','test'),('2019-09-21 03:59:59','2019-09-22 03:59:59','AGIBTC','4h','0.000002670000000','0.000002550000000','0.001556602447591','0.001486642787025','582.997171382397','582.997171382397028','test'),('2019-09-24 03:59:59','2019-09-24 15:59:59','AGIBTC','4h','0.000002900000000','0.000002590000000','0.001556602447591','0.001390207013538','536.7594646865517','536.759464686551723','test'),('2019-09-28 19:59:59','2019-09-29 11:59:59','AGIBTC','4h','0.000002680000000','0.000002530000000','0.001556602447591','0.001469479176271','580.8218088026119','580.821808802611940','test'),('2019-09-29 23:59:59','2019-09-30 03:59:59','AGIBTC','4h','0.000002630000000','0.000002560000000','0.001556602447591','0.001515171964195','591.8640485136883','591.864048513688317','test'),('2019-10-04 11:59:59','2019-10-09 15:59:59','AGIBTC','4h','0.000002680000000','0.000002680000000','0.001556602447591','0.001556602447591','580.8218088026119','580.821808802611940','test'),('2019-10-12 15:59:59','2019-10-13 11:59:59','AGIBTC','4h','0.000002810000000','0.000002740000000','0.001556602447591','0.001517825874163','553.9510489647687','553.951048964768688','test'),('2019-10-18 23:59:59','2019-10-19 15:59:59','AGIBTC','4h','0.000002760000000','0.000002710000000','0.001556602447591','0.001528403127888','563.9863940547102','563.986394054710217','test'),('2019-10-21 23:59:59','2019-10-22 07:59:59','AGIBTC','4h','0.000002740000000','0.000002700000000','0.001556602447591','0.001533878324269','568.1030830624088','568.103083062408814','test'),('2019-11-12 23:59:59','2019-11-14 03:59:59','AGIBTC','4h','0.000002470000000','0.000002410000000','0.001556602447591','0.001518790242386','630.2034200773279','630.203420077327905','test'),('2019-11-14 07:59:59','2019-11-14 11:59:59','AGIBTC','4h','0.000002430000000','0.000002370000000','0.001556602447591','0.001518167819255','640.5771389263375','640.577138926337511','test'),('2019-11-14 15:59:59','2019-11-17 11:59:59','AGIBTC','4h','0.000002430000000','0.000002570000000','0.001556602447591','0.001646283247041','640.5771389263375','640.577138926337511','test'),('2019-11-18 03:59:59','2019-11-20 03:59:59','AGIBTC','4h','0.000002700000000','0.000002820000000','0.001556602447591','0.001625784778595','576.5194250337038','576.519425033703783','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:03:58
