-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-28 19:59:59','2018-08-29 15:59:59','AEBTC','4h','0.000165800000000','0.000159500000000','0.001467500000000','0.001411738540410','8.851025331724971','8.851025331724971','test'),('2018-08-29 19:59:59','2018-08-30 03:59:59','AEBTC','4h','0.000162900000000','0.000162100000000','0.001467500000000','0.001460293124616','9.008594229588706','9.008594229588706','test'),('2018-08-31 19:59:59','2018-09-02 11:59:59','AEBTC','4h','0.000162800000000','0.000160000000000','0.001467500000000','0.001442260442260','9.014127764127764','9.014127764127764','test'),('2018-09-02 15:59:59','2018-09-02 19:59:59','AEBTC','4h','0.000163700000000','0.000162000000000','0.001467500000000','0.001452260232132','8.964569334147832','8.964569334147832','test'),('2018-09-15 19:59:59','2018-09-17 15:59:59','AEBTC','4h','0.000156600000000','0.000145600000000','0.001467500000000','0.001364418901660','9.371008939974457','9.371008939974457','test'),('2018-09-21 07:59:59','2018-09-21 11:59:59','AEBTC','4h','0.000152000000000','0.000151600000000','0.001467500000000','0.001463638157895','9.654605263157894','9.654605263157894','test'),('2018-09-21 19:59:59','2018-09-22 11:59:59','AEBTC','4h','0.000152200000000','0.000149700000000','0.001467500000000','0.001443395203679','9.6419185282523','9.641918528252299','test'),('2018-09-22 15:59:59','2018-09-22 23:59:59','AEBTC','4h','0.000150300000000','0.000150600000000','0.001467500000000','0.001470429141717','9.763805721889556','9.763805721889556','test'),('2018-09-23 07:59:59','2018-09-23 19:59:59','AEBTC','4h','0.000151100000000','0.000150400000000','0.001467500000000','0.001460701522171','9.71211118464593','9.712111184645931','test'),('2018-09-23 23:59:59','2018-09-24 07:59:59','AEBTC','4h','0.000153100000000','0.000150200000000','0.001467500000000','0.001439702808622','9.585238406270411','9.585238406270411','test'),('2018-09-26 19:59:59','2018-09-26 23:59:59','AEBTC','4h','0.000152200000000','0.000149700000000','0.001467500000000','0.001443395203679','9.6419185282523','9.641918528252299','test'),('2018-09-27 03:59:59','2018-09-27 07:59:59','AEBTC','4h','0.000150800000000','0.000149100000000','0.001467500000000','0.001450956564987','9.731432360742705','9.731432360742705','test'),('2018-09-27 11:59:59','2018-09-28 03:59:59','AEBTC','4h','0.000149700000000','0.000150600000000','0.001467500000000','0.001476322645291','9.802939211756847','9.802939211756847','test'),('2018-09-28 11:59:59','2018-09-28 15:59:59','AEBTC','4h','0.000150600000000','0.000151400000000','0.001467500000000','0.001475295484728','9.744355909694555','9.744355909694555','test'),('2018-09-29 03:59:59','2018-09-29 07:59:59','AEBTC','4h','0.000150600000000','0.000152700000000','0.001467500000000','0.001487963147410','9.744355909694555','9.744355909694555','test'),('2018-09-29 11:59:59','2018-10-01 19:59:59','AEBTC','4h','0.000153700000000','0.000156900000000','0.001467500000000','0.001498053025374','9.547820429407938','9.547820429407938','test'),('2018-10-01 23:59:59','2018-10-03 03:59:59','AEBTC','4h','0.000161900000000','0.000156400000000','0.001467500000000','0.001417646695491','9.064237183446572','9.064237183446572','test'),('2018-10-03 15:59:59','2018-10-05 03:59:59','AEBTC','4h','0.000163100000000','0.000159500000000','0.001467500000000','0.001435108828939','8.997547516860822','8.997547516860822','test'),('2018-10-05 15:59:59','2018-10-06 19:59:59','AEBTC','4h','0.000163900000000','0.000160000000000','0.001467500000000','0.001432580841977','8.953630262355095','8.953630262355095','test'),('2018-10-08 15:59:59','2018-10-09 03:59:59','AEBTC','4h','0.000163100000000','0.000161700000000','0.001467500000000','0.001454903433476','8.997547516860822','8.997547516860822','test'),('2018-10-09 07:59:59','2018-10-12 15:59:59','AEBTC','4h','0.000164800000000','0.000179400000000','0.001467500000000','0.001597509101942','8.904733009708739','8.904733009708739','test'),('2018-10-12 19:59:59','2018-10-12 23:59:59','AEBTC','4h','0.000180900000000','0.000178500000000','0.001467500000000','0.001448030679934','8.112216694306246','8.112216694306246','test'),('2018-10-13 03:59:59','2018-10-13 11:59:59','AEBTC','4h','0.000180500000000','0.000176900000000','0.001467500000000','0.001438231301939','8.130193905817174','8.130193905817174','test'),('2018-10-14 15:59:59','2018-10-15 07:59:59','AEBTC','4h','0.000186000000000','0.000175200000000','0.001467500000000','0.001382290322581','7.88978494623656','7.889784946236560','test'),('2018-10-16 11:59:59','2018-10-22 07:59:59','AEBTC','4h','0.000182200000000','0.000205900000000','0.001467500000000','0.001658387760703','8.054335894621294','8.054335894621294','test'),('2018-12-21 19:59:59','2018-12-25 03:59:59','AEBTC','4h','0.000115800000000','0.000107500000000','0.001467500000000','0.001362316493955','12.672711571675304','12.672711571675304','test'),('2019-01-15 19:59:59','2019-01-18 15:59:59','AEBTC','4h','0.000113600000000','0.000116900000000','0.001467500000000','0.001510129841549','12.918133802816902','12.918133802816902','test'),('2019-02-16 03:59:59','2019-02-18 11:59:59','AEBTC','4h','0.000112800000000','0.000111300000000','0.001467500000000','0.001447985372340','13.009751773049645','13.009751773049645','test'),('2019-02-18 15:59:59','2019-02-19 07:59:59','AEBTC','4h','0.000112200000000','0.000114600000000','0.001467500000000','0.001498890374332','13.079322638146168','13.079322638146168','test'),('2019-02-23 03:59:59','2019-02-24 15:59:59','AEBTC','4h','0.000115300000000','0.000111700000000','0.001467500000000','0.001421680398959','12.727666955767564','12.727666955767564','test'),('2019-02-24 19:59:59','2019-02-24 23:59:59','AEBTC','4h','0.000113300000000','0.000111800000000','0.001467500000000','0.001448071491615','12.952338923212709','12.952338923212709','test'),('2019-02-25 03:59:59','2019-02-25 07:59:59','AEBTC','4h','0.000112700000000','0.000110600000000','0.001467500000000','0.001440155279503','13.021295474711623','13.021295474711623','test'),('2019-02-27 07:59:59','2019-03-02 07:59:59','AEBTC','4h','0.000114800000000','0.000115100000000','0.001467500000000','0.001471334930314','12.783101045296167','12.783101045296167','test'),('2019-03-13 15:59:59','2019-03-13 23:59:59','AEBTC','4h','0.000113800000000','0.000112600000000','0.001467500000000','0.001452025483304','12.89543057996485','12.895430579964851','test'),('2019-03-14 03:59:59','2019-03-14 07:59:59','AEBTC','4h','0.000113000000000','0.000112000000000','0.001467500000000','0.001454513274336','12.986725663716815','12.986725663716815','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','AEBTC','4h','0.000113400000000','0.000117500000000','0.001467500000000','0.001520557760141','12.940917107583774','12.940917107583774','test'),('2019-03-14 19:59:59','2019-03-16 15:59:59','AEBTC','4h','0.000118900000000','0.000116400000000','0.001467500000000','0.001436644238856','12.342304457527334','12.342304457527334','test'),('2019-03-16 19:59:59','2019-03-17 07:59:59','AEBTC','4h','0.000117900000000','0.000115800000000','0.001467500000000','0.001441361323155','12.446988973706532','12.446988973706532','test'),('2019-03-20 15:59:59','2019-03-21 15:59:59','AEBTC','4h','0.000116600000000','0.000116300000000','0.001467500000000','0.001463724271012','12.585763293310464','12.585763293310464','test'),('2019-03-21 23:59:59','2019-03-24 23:59:59','AEBTC','4h','0.000117400000000','0.000118900000000','0.001467500000000','0.001486250000000','12.500000000000002','12.500000000000002','test'),('2019-03-28 07:59:59','2019-03-28 11:59:59','AEBTC','4h','0.000118800000000','0.000116200000000','0.001467500000000','0.001435382996633','12.352693602693604','12.352693602693604','test'),('2019-03-28 15:59:59','2019-03-28 23:59:59','AEBTC','4h','0.000117500000000','0.000117100000000','0.001467500000000','0.001462504255319','12.48936170212766','12.489361702127660','test'),('2019-03-30 03:59:59','2019-03-30 07:59:59','AEBTC','4h','0.000118200000000','0.000117900000000','0.001467500000000','0.001463775380711','12.415397631133672','12.415397631133672','test'),('2019-03-30 11:59:59','2019-04-02 07:59:59','AEBTC','4h','0.000119800000000','0.000118900000000','0.001467500000000','0.001456475375626','12.24958263772955','12.249582637729549','test'),('2019-04-03 11:59:59','2019-04-03 23:59:59','AEBTC','4h','0.000130200000000','0.000127300000000','0.001467500000000','0.001434813748080','11.271121351766514','11.271121351766514','test'),('2019-04-04 07:59:59','2019-04-04 11:59:59','AEBTC','4h','0.000128300000000','0.000128800000000','0.001467500000000','0.001473219017927','11.438035853468433','11.438035853468433','test'),('2019-04-04 23:59:59','2019-04-07 19:59:59','AEBTC','4h','0.000126100000000','0.000131500000000','0.001467500000000','0.001530342981761','11.637589214908802','11.637589214908802','test'),('2019-05-22 23:59:59','2019-05-23 07:59:59','AEBTC','4h','0.000073800000000','0.000068000000000','0.001467500000000','0.001352168021680','19.884823848238483','19.884823848238483','test'),('2019-05-23 11:59:59','2019-05-23 15:59:59','AEBTC','4h','0.000069300000000','0.000069700000000','0.001467500000000','0.001475970418470','21.176046176046174','21.176046176046174','test'),('2019-05-24 07:59:59','2019-05-24 19:59:59','AEBTC','4h','0.000071900000000','0.000069000000000','0.001467500000000','0.001408310152990','20.410292072322672','20.410292072322672','test'),('2019-05-24 23:59:59','2019-05-26 19:59:59','AEBTC','4h','0.000070500000000','0.000066300000000','0.001467500000000','0.001380074468085','20.81560283687943','20.815602836879432','test'),('2019-06-10 19:59:59','2019-06-11 11:59:59','AEBTC','4h','0.000065900000000','0.000064100000000','0.001467500000000','0.001427416540212','22.268588770864948','22.268588770864948','test'),('2019-06-11 15:59:59','2019-06-11 19:59:59','AEBTC','4h','0.000064200000000','0.000064300000000','0.001467500000000','0.001469785825545','22.858255451713397','22.858255451713397','test'),('2019-06-11 23:59:59','2019-06-12 03:59:59','AEBTC','4h','0.000064400000000','0.000063700000000','0.001467500000000','0.001451548913043','22.787267080745345','22.787267080745345','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:50:25
