-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-15 07:59:59','2018-11-25 03:59:59','XRPBNB','4h','0.056070000000000','0.071570000000000','0.711908500000000','0.908708602550383','12.696780809702158','12.696780809702158','test'),('2018-11-27 23:59:59','2018-11-28 07:59:59','XRPBNB','4h','0.073350000000000','0.072180000000000','0.761108525637596','0.748968144247058','10.376394350887468','10.376394350887468','test'),('2018-12-19 03:59:59','2018-12-19 23:59:59','XRPBNB','4h','0.068230000000000','0.064700000000000','0.761108525637596','0.721731226861387','11.155042146234736','11.155042146234736','test'),('2018-12-20 07:59:59','2018-12-20 15:59:59','XRPBNB','4h','0.064820000000000','0.064720000000000','0.761108525637596','0.759934337847350','11.741877902462141','11.741877902462141','test'),('2018-12-20 19:59:59','2018-12-21 07:59:59','XRPBNB','4h','0.065860000000000','0.064980000000000','0.761108525637596','0.750938839901776','11.55646106343146','11.556461063431460','test'),('2018-12-21 11:59:59','2018-12-21 15:59:59','XRPBNB','4h','0.065500000000000','0.065340000000000','0.761108525637596','0.759249329239092','11.61997749065032','11.619977490650321','test'),('2018-12-21 19:59:59','2018-12-21 23:59:59','XRPBNB','4h','0.066010000000000','0.064620000000000','0.761108525637596','0.745081547139849','11.530200358091138','11.530200358091138','test'),('2018-12-25 03:59:59','2018-12-27 15:59:59','XRPBNB','4h','0.067600000000000','0.066180000000000','0.761108525637596','0.745120742998463','11.259001858544321','11.259001858544321','test'),('2019-01-31 03:59:59','2019-02-01 03:59:59','XRPBNB','4h','0.052950000000000','0.048730000000000','0.761108525637596','0.700449829165629','14.374098690039586','14.374098690039586','test'),('2019-02-26 19:59:59','2019-02-27 07:59:59','XRPBNB','4h','0.033690000000000','0.032350000000000','0.761108525637596','0.730835880213008','22.5915264362599','22.591526436259901','test'),('2019-04-07 03:59:59','2019-04-11 03:59:59','XRPBNB','4h','0.018990000000000','0.019110000000000','0.761108525637596','0.765918058185069','40.079437895608','40.079437895608002','test'),('2019-05-07 15:59:59','2019-05-12 11:59:59','XRPBNB','4h','0.013820000000000','0.014990000000000','0.761108525637596','0.825543907330504','55.07297580590419','55.072975805904193','test'),('2019-05-14 11:59:59','2019-05-15 15:59:59','XRPBNB','4h','0.016320000000000','0.015990000000000','0.761108525637596','0.745718463538306','46.63655181602916','46.636551816029161','test'),('2019-05-15 19:59:59','2019-05-16 11:59:59','XRPBNB','4h','0.016360000000000','0.016170000000000','0.761108525637596','0.752269245694372','46.52252601696797','46.522526016967973','test'),('2019-05-16 15:59:59','2019-05-17 03:59:59','XRPBNB','4h','0.016570000000000','0.016210000000000','0.761108525637596','0.744572673541667','45.93292248869016','45.932922488690160','test'),('2019-05-29 15:59:59','2019-05-30 03:59:59','XRPBNB','4h','0.013430000000000','0.013070000000000','0.761108525637596','0.740706510058331','56.6722654979595','56.672265497959501','test'),('2019-05-30 07:59:59','2019-06-01 07:59:59','XRPBNB','4h','0.013570000000000','0.013060000000000','0.761108525637596','0.732503857393294','56.087584792748416','56.087584792748416','test'),('2019-06-02 23:59:59','2019-06-04 15:59:59','XRPBNB','4h','0.013400000000000','0.013380000000000','0.761108525637596','0.759972542763510','56.79914370429821','56.799143704298210','test'),('2019-06-04 23:59:59','2019-06-05 03:59:59','XRPBNB','4h','0.013640000000000','0.013340000000000','0.761108525637596','0.744368602053191','55.799745281348685','55.799745281348685','test'),('2019-06-07 15:59:59','2019-06-08 03:59:59','XRPBNB','4h','0.013520000000000','0.013190000000000','0.761108525637596','0.742531172570998','56.295009292721595','56.295009292721595','test'),('2019-06-16 23:59:59','2019-06-17 15:59:59','XRPBNB','4h','0.013270000000000','0.012630000000000','0.761108525637596','0.724400955448594','57.3555784203162','57.355578420316199','test'),('2019-06-17 23:59:59','2019-06-18 07:59:59','XRPBNB','4h','0.013210000000000','0.012670000000000','0.761108525637596','0.729995837988519','57.61608823903074','57.616088239030738','test'),('2019-06-24 11:59:59','2019-06-24 15:59:59','XRPBNB','4h','0.012570000000000','0.012300000000000','0.761108525637596','0.744760132485476','60.54960426711185','60.549604267111853','test'),('2019-06-24 19:59:59','2019-06-27 07:59:59','XRPBNB','4h','0.012430000000000','0.012470000000000','0.761108525637596','0.763557788793308','61.2315788928074','61.231578892807399','test'),('2019-06-27 11:59:59','2019-06-27 15:59:59','XRPBNB','4h','0.012660000000000','0.011900000000000','0.761108525637596','0.715417966436603','60.11915684341201','60.119156843412007','test'),('2019-07-17 11:59:59','2019-07-17 15:59:59','XRPBNB','4h','0.012190000000000','0.011430000000000','0.761108525637596','0.713656312390297','62.43712269381428','62.437122693814281','test'),('2019-07-17 19:59:59','2019-07-17 23:59:59','XRPBNB','4h','0.011500000000000','0.011220000000000','0.761108525637596','0.742577187622072','66.18335005544313','66.183350055443128','test'),('2019-07-18 03:59:59','2019-07-18 07:59:59','XRPBNB','4h','0.011270000000000','0.010850000000000','0.761108525637596','0.732744232756692','67.53403066881953','67.534030668819526','test'),('2019-07-26 23:59:59','2019-08-01 03:59:59','XRPBNB','4h','0.011170000000000','0.011400000000000','0.761108525637596','0.776780411125210','68.13863255484297','68.138632554842971','test'),('2019-08-04 03:59:59','2019-08-06 11:59:59','XRPBNB','4h','0.011430000000000','0.011480000000000','0.761108525637596','0.764437959258058','66.5886724092385','66.588672409238498','test'),('2019-08-23 15:59:59','2019-08-26 07:59:59','XRPBNB','4h','0.010140000000000','0.010050000000000','0.761108525637596','0.754353124522469','75.06001239029547','75.060012390295469','test'),('2019-08-26 15:59:59','2019-08-28 19:59:59','XRPBNB','4h','0.010410000000000','0.010800000000000','0.761108525637596','0.789622677894912','73.11321091619557','73.113210916195570','test'),('2019-08-28 23:59:59','2019-09-02 19:59:59','XRPBNB','4h','0.010960000000000','0.011640000000000','0.761108525637596','0.808330587447228','69.44420854357628','69.444208543576281','test'),('2019-09-04 07:59:59','2019-09-05 19:59:59','XRPBNB','4h','0.011880000000000','0.011140000000000','0.761108525637596','0.713699408720776','64.06637421191886','64.066374211918856','test'),('2019-09-08 15:59:59','2019-09-21 03:59:59','XRPBNB','4h','0.011730000000000','0.013710000000000','0.761108525637596','0.889582087509927','64.88563730925797','64.885637309257973','test'),('2019-09-21 15:59:59','2019-09-22 03:59:59','XRPBNB','4h','0.013920000000000','0.013650000000000','0.761108525637596','0.746345644752384','54.677336611896266','54.677336611896266','test'),('2019-09-23 15:59:59','2019-09-24 19:59:59','XRPBNB','4h','0.014200000000000','0.014630000000000','0.761108525637596','0.784156178174509','53.599191946309574','53.599191946309574','test'),('2019-09-24 23:59:59','2019-09-28 23:59:59','XRPBNB','4h','0.014710000000000','0.015380000000000','0.761108525637596','0.795774923474251','51.74089229351434','51.740892293514342','test'),('2019-09-29 11:59:59','2019-10-01 23:59:59','XRPBNB','4h','0.015550000000000','0.015660000000000','0.761108525637596','0.766492573085836','48.94588589309299','48.945885893092992','test'),('2019-10-04 03:59:59','2019-10-09 07:59:59','XRPBNB','4h','0.016080000000000','0.016360000000000','0.761108525637596','0.774361659168599','47.33261975358184','47.332619753581838','test'),('2019-10-18 11:59:59','2019-10-18 15:59:59','XRPBNB','4h','0.016120000000000','0.016010000000000','0.761108525637596','0.755914857038332','47.21516908421812','47.215169084218118','test'),('2019-10-18 19:59:59','2019-10-19 19:59:59','XRPBNB','4h','0.016030000000000','0.015960000000000','0.761108525637596','0.757784907621711','47.48025736978141','47.480257369781413','test'),('2019-10-19 23:59:59','2019-10-20 03:59:59','XRPBNB','4h','0.016010000000000','0.015870000000000','0.761108525637596','0.754452985750696','47.53957062071181','47.539570620711807','test'),('2019-10-22 03:59:59','2019-10-22 07:59:59','XRPBNB','4h','0.016240000000000','0.015950000000000','0.761108525637596','0.747517301965496','46.86628852448251','46.866288524482513','test'),('2019-10-23 07:59:59','2019-10-23 11:59:59','XRPBNB','4h','0.016080000000000','0.016110000000000','0.761108525637596','0.762528504230203','47.33261975358184','47.332619753581838','test'),('2019-10-23 15:59:59','2019-10-23 19:59:59','XRPBNB','4h','0.016280000000000','0.015990000000000','0.761108525637596','0.747550695635452','46.75113793842728','46.751137938427277','test'),('2019-10-23 23:59:59','2019-10-25 03:59:59','XRPBNB','4h','0.016360000000000','0.016070000000000','0.761108525637596','0.747616993092675','46.52252601696797','46.522526016967973','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  2:00:24
