-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 19:59:59','2019-01-08 23:59:59','NULSUSDT','4h','0.433500000000000','0.422100000000000','15.000000000000000','14.605536332179931','34.602076124567475','34.602076124567475','test'),('2019-01-09 07:59:59','2019-01-10 07:59:59','NULSUSDT','4h','0.436500000000000','0.395200000000000','15.000000000000000','13.580756013745704','34.36426116838488','34.364261168384878','test'),('2019-01-18 07:59:59','2019-01-19 03:59:59','NULSUSDT','4h','0.418500000000000','0.393100000000000','15.000000000000000','14.089605734767026','35.842293906810035','35.842293906810035','test'),('2019-01-19 07:59:59','2019-01-20 15:59:59','NULSUSDT','4h','0.397600000000000','0.392400000000000','15.000000000000000','14.803822937625755','37.72635814889336','37.726358148893361','test'),('2019-01-23 03:59:59','2019-01-23 23:59:59','NULSUSDT','4h','0.407500000000000','0.396600000000000','15.000000000000000','14.598773006134971','36.809815950920246','36.809815950920246','test'),('2019-01-24 19:59:59','2019-01-27 15:59:59','NULSUSDT','4h','0.425000000000000','0.432300000000000','15.000000000000000','15.257647058823530','35.294117647058826','35.294117647058826','test'),('2019-02-10 03:59:59','2019-02-10 15:59:59','NULSUSDT','4h','0.411000000000000','0.398600000000000','15.000000000000000','14.547445255474454','36.496350364963504','36.496350364963504','test'),('2019-02-10 19:59:59','2019-02-12 03:59:59','NULSUSDT','4h','0.403600000000000','0.398900000000000','15.000000000000000','14.825322101090187','37.16551040634291','37.165510406342911','test'),('2019-02-13 03:59:59','2019-02-14 11:59:59','NULSUSDT','4h','0.406800000000000','0.400100000000000','15.000000000000000','14.752949852507376','36.87315634218289','36.873156342182888','test'),('2019-02-14 19:59:59','2019-02-15 15:59:59','NULSUSDT','4h','0.406100000000000','0.401300000000000','15.000000000000000','14.822703767544938','36.936715094804235','36.936715094804235','test'),('2019-02-16 03:59:59','2019-02-17 03:59:59','NULSUSDT','4h','0.411600000000000','0.408600000000000','15.000000000000000','14.890670553935859','36.44314868804665','36.443148688046648','test'),('2019-02-17 07:59:59','2019-02-22 11:59:59','NULSUSDT','4h','0.424200000000000','0.434000000000000','15.000000000000000','15.346534653465346','35.36067892503536','35.360678925035359','test'),('2019-02-23 11:59:59','2019-02-24 15:59:59','NULSUSDT','4h','0.446200000000000','0.410300000000000','15.000000000000000','13.793142088749439','33.617212012550425','33.617212012550425','test'),('2019-03-05 23:59:59','2019-03-08 23:59:59','NULSUSDT','4h','0.438200000000000','0.429000000000000','15.000000000000000','14.685075308078503','34.230944774075766','34.230944774075766','test'),('2019-03-09 03:59:59','2019-03-11 15:59:59','NULSUSDT','4h','0.441900000000000','0.487200000000000','15.000000000000000','16.537678207739308','33.944331296673454','33.944331296673454','test'),('2019-03-11 19:59:59','2019-03-11 23:59:59','NULSUSDT','4h','0.518000000000000','0.492500000000000','15.000000000000000','14.261583011583010','28.957528957528957','28.957528957528957','test'),('2019-03-13 03:59:59','2019-03-19 19:59:59','NULSUSDT','4h','0.514500000000000','0.570100000000000','15.000000000000000','16.620991253644320','29.15451895043732','29.154518950437321','test'),('2019-03-19 23:59:59','2019-03-21 15:59:59','NULSUSDT','4h','0.571000000000000','0.547700000000000','15.000000000000000','14.387915936952714','26.269702276707534','26.269702276707534','test'),('2019-03-22 07:59:59','2019-03-24 23:59:59','NULSUSDT','4h','0.669500000000000','0.630100000000000','15.000000000000000','14.117251680358477','22.404779686333086','22.404779686333086','test'),('2019-03-27 03:59:59','2019-04-04 19:59:59','NULSUSDT','4h','0.654600000000000','0.868200000000000','15.000000000000000','19.894592117323555','22.914757103574704','22.914757103574704','test'),('2019-04-06 03:59:59','2019-04-08 07:59:59','NULSUSDT','4h','0.946100000000000','0.930200000000000','15.104999217931100','14.851147101278414','15.965541927841771','15.965541927841771','test'),('2019-04-17 15:59:59','2019-04-18 23:59:59','NULSUSDT','4h','0.874900000000000','0.869500000000000','15.104999217931100','15.011769139320027','17.264829372420962','17.264829372420962','test'),('2019-04-20 03:59:59','2019-04-20 11:59:59','NULSUSDT','4h','0.891600000000000','0.867700000000000','15.104999217931100','14.700098498652778','16.941452689469607','16.941452689469607','test'),('2019-04-20 15:59:59','2019-04-21 11:59:59','NULSUSDT','4h','0.871300000000000','0.854600000000000','15.104999217931100','14.815485288240467','17.33616345452898','17.336163454528979','test'),('2019-04-23 07:59:59','2019-04-24 07:59:59','NULSUSDT','4h','0.907900000000000','0.832500000000000','15.104999217931100','13.850547250718845','16.637293994857473','16.637293994857473','test'),('2019-05-14 23:59:59','2019-05-17 03:59:59','NULSUSDT','4h','0.696300000000000','0.675500000000000','15.104999217931100','14.653779939268214','21.693234551100243','21.693234551100243','test'),('2019-05-19 07:59:59','2019-05-19 15:59:59','NULSUSDT','4h','0.734100000000000','0.704000000000000','15.104999217931100','14.485655155187978','20.576214709073835','20.576214709073835','test'),('2019-05-19 19:59:59','2019-05-20 03:59:59','NULSUSDT','4h','0.707000000000000','0.697200000000000','15.104999217931100','14.895622991147897','21.364921100326875','21.364921100326875','test'),('2019-05-21 07:59:59','2019-05-22 11:59:59','NULSUSDT','4h','0.747000000000000','0.711800000000000','15.104999217931100','14.393224154382004','20.220882487190227','20.220882487190227','test'),('2019-05-22 15:59:59','2019-05-22 23:59:59','NULSUSDT','4h','0.741900000000000','0.712300000000000','15.104999217931100','14.502346600528808','20.35988572305041','20.359885723050411','test'),('2019-05-23 19:59:59','2019-05-26 11:59:59','NULSUSDT','4h','0.745500000000000','0.745500000000000','15.104999217931100','15.104999217931100','20.26156836744614','20.261568367446142','test'),('2019-05-27 03:59:59','2019-05-29 07:59:59','NULSUSDT','4h','0.774300000000000','0.761000000000000','15.104999217931100','14.845543594014682','19.50794164785109','19.507941647851091','test'),('2019-05-29 19:59:59','2019-05-30 19:59:59','NULSUSDT','4h','0.792700000000000','0.772300000000000','15.104999217931100','14.716274625972233','19.055127056807244','19.055127056807244','test'),('2019-06-01 11:59:59','2019-06-03 07:59:59','NULSUSDT','4h','0.788100000000000','0.762500000000000','15.104999217931100','14.614340697465375','19.166348455692297','19.166348455692297','test'),('2019-06-03 11:59:59','2019-06-03 15:59:59','NULSUSDT','4h','0.778200000000000','0.774200000000000','15.104999217931100','15.027358512621765','19.41017632733372','19.410176327333719','test'),('2019-06-03 19:59:59','2019-06-03 23:59:59','NULSUSDT','4h','0.794500000000000','0.750000000000000','15.104999217931100','14.258967166077188','19.01195622143625','19.011956221436250','test'),('2019-06-07 19:59:59','2019-06-09 19:59:59','NULSUSDT','4h','0.786700000000000','0.833800000000000','15.104999217931100','16.009340724432381','19.20045661361523','19.200456613615231','test'),('2019-06-09 23:59:59','2019-06-12 19:59:59','NULSUSDT','4h','0.894200000000000','0.881800000000000','15.104999217931100','14.895536021439995','16.892193265411652','16.892193265411652','test'),('2019-06-14 03:59:59','2019-06-14 19:59:59','NULSUSDT','4h','0.926300000000000','1.036400000000000','15.104999217931100','16.900379131451789','16.306811203639317','16.306811203639317','test'),('2019-06-14 23:59:59','2019-06-16 23:59:59','NULSUSDT','4h','1.050900000000000','0.961600000000000','15.104999217931100','13.821455179334425','14.373393489324485','14.373393489324485','test'),('2019-06-17 15:59:59','2019-06-20 23:59:59','NULSUSDT','4h','0.992400000000000','0.998900000000000','15.104999217931100','15.203933614259752','15.22067635825383','15.220676358253829','test'),('2019-07-04 19:59:59','2019-07-04 23:59:59','NULSUSDT','4h','0.922900000000000','0.890000000000000','15.104999217931100','14.566528663949159','16.36688613926872','16.366886139268718','test'),('2019-07-05 03:59:59','2019-07-05 07:59:59','NULSUSDT','4h','0.891700000000000','0.895700000000000','15.104999217931100','15.172757429069067','16.939552784491532','16.939552784491532','test'),('2019-07-05 11:59:59','2019-07-08 11:59:59','NULSUSDT','4h','0.914000000000000','0.903400000000000','15.104999217931100','14.929820890020739','16.526257350034026','16.526257350034026','test'),('2019-08-19 03:59:59','2019-08-19 07:59:59','NULSUSDT','4h','0.449600000000000','0.446400000000000','15.104999217931100','14.997490326700275','33.59652850963323','33.596528509633231','test'),('2019-08-19 11:59:59','2019-08-19 15:59:59','NULSUSDT','4h','0.448400000000000','0.451600000000000','15.104999217931100','15.212795822519366','33.686438933833855','33.686438933833855','test'),('2019-08-19 19:59:59','2019-08-20 03:59:59','NULSUSDT','4h','0.452300000000000','0.440000000000000','15.104999217931100','14.694228732897820','33.39597439294959','33.395974392949590','test'),('2019-08-24 19:59:59','2019-08-26 23:59:59','NULSUSDT','4h','0.514400000000000','0.468800000000000','15.104999217931100','13.765986845579510','29.364306411219093','29.364306411219093','test'),('2019-08-27 23:59:59','2019-08-28 19:59:59','NULSUSDT','4h','0.491500000000000','0.452900000000000','15.104999217931100','13.918726644559504','30.7324500873471','30.732450087347100','test'),('2019-09-17 19:59:59','2019-09-19 03:59:59','NULSUSDT','4h','0.443200000000000','0.422000000000000','15.104999217931100','14.382467666892879','34.08167693576512','34.081676935765117','test'),('2019-09-20 15:59:59','2019-09-20 23:59:59','NULSUSDT','4h','0.440100000000000','0.432400000000000','15.104999217931100','14.840721794668049','34.32174328091593','34.321743280915932','test'),('2019-09-21 03:59:59','2019-09-21 07:59:59','NULSUSDT','4h','0.434200000000000','0.431300000000000','15.104999217931100','15.004113686535431','34.788114274369185','34.788114274369185','test'),('2019-10-03 19:59:59','2019-10-04 03:59:59','NULSUSDT','4h','0.366100000000000','0.364100000000000','15.104999217931100','15.022480784618175','41.25921665646299','41.259216656462989','test'),('2019-10-04 07:59:59','2019-10-06 07:59:59','NULSUSDT','4h','0.366300000000000','0.367000000000000','15.104999217931100','15.133864900302248','41.236689101641005','41.236689101641005','test'),('2019-10-08 15:59:59','2019-10-10 11:59:59','NULSUSDT','4h','0.374600000000000','0.372800000000000','15.104999217931100','15.032417801507513','40.32300912421543','40.323009124215432','test'),('2019-10-10 15:59:59','2019-10-10 19:59:59','NULSUSDT','4h','0.376700000000000','0.370200000000000','15.104999217931100','14.844360792349596','40.09821932023122','40.098219320231223','test'),('2019-10-27 23:59:59','2019-11-03 15:59:59','NULSUSDT','4h','0.377000000000000','0.413400000000000','15.104999217931100','16.563412935524447','40.06631092289417','40.066310922894168','test'),('2019-11-12 19:59:59','2019-11-12 23:59:59','NULSUSDT','4h','0.404500000000000','0.407600000000000','15.104999217931100','15.220760645806466','37.34239608882843','37.342396088828430','test'),('2019-11-13 01:59:59','2019-11-14 15:59:59','NULSUSDT','4h','0.412800000000000','0.413900000000000','15.104999217931100','15.145249942591285','36.591567872895105','36.591567872895105','test'),('2019-12-28 19:59:59','2019-12-29 03:59:59','NULSUSDT','4h','0.256900000000000','0.248900000000000','15.104999217931100','14.634621663460686','58.79719430880147','58.797194308801473','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 14:42:28
