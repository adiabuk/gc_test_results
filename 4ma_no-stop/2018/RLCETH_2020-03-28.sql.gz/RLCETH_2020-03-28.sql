-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-04 15:59:59','2018-07-05 15:59:59','RLCETH','4h','0.001744000000000','0.001718000000000','0.072144500000000','0.071068951261468','41.367259174311926','41.367259174311926','test'),('2018-07-07 15:59:59','2018-07-08 11:59:59','RLCETH','4h','0.001764000000000','0.001702000000000','0.072144500000000','0.069608808956916','40.89824263038549','40.898242630385489','test'),('2018-07-18 15:59:59','2018-07-20 15:59:59','RLCETH','4h','0.001688000000000','0.001612000000000','0.072144500000000','0.068896287914692','42.7396327014218','42.739632701421797','test'),('2018-08-13 23:59:59','2018-08-14 07:59:59','RLCETH','4h','0.001157000000000','0.001122000000000','0.072144500000000','0.069962082108902','62.35479688850475','62.354796888504751','test'),('2018-08-14 11:59:59','2018-08-14 19:59:59','RLCETH','4h','0.001125000000000','0.001088000000000','0.072144500000000','0.069771747555556','64.12844444444445','64.128444444444455','test'),('2018-08-18 07:59:59','2018-08-18 15:59:59','RLCETH','4h','0.001156000000000','0.001133000000000','0.072144500000000','0.070709099048443','62.40873702422146','62.408737024221459','test'),('2018-08-19 15:59:59','2018-08-27 07:59:59','RLCETH','4h','0.001138000000000','0.001578000000000','0.072144500000000','0.100038682776801','63.395869947275926','63.395869947275926','test'),('2018-09-01 11:59:59','2018-09-02 03:59:59','RLCETH','4h','0.001504000000000','0.001467000000000','0.075905539905694','0.074038182873440','50.46910897985007','50.469108979850070','test'),('2018-09-02 11:59:59','2018-09-02 15:59:59','RLCETH','4h','0.001490000000000','0.001452000000000','0.075905539905694','0.073969693921522','50.943315372948994','50.943315372948994','test'),('2018-09-04 11:59:59','2018-09-05 11:59:59','RLCETH','4h','0.001507000000000','0.001452000000000','0.075905539905694','0.073135264726654','50.368639618907764','50.368639618907764','test'),('2018-09-05 19:59:59','2018-09-06 03:59:59','RLCETH','4h','0.001534000000000','0.001465000000000','0.075905539905694','0.072491275072909','49.48209902587614','49.482099025876138','test'),('2018-09-06 07:59:59','2018-09-06 11:59:59','RLCETH','4h','0.001472000000000','0.001548000000000','0.075905539905694','0.079824575933434','51.56626352288995','51.566263522889948','test'),('2018-09-06 15:59:59','2018-09-10 19:59:59','RLCETH','4h','0.001560000000000','0.001733000000000','0.075905539905694','0.084323269651646','48.65739737544487','48.657397375444873','test'),('2018-09-11 03:59:59','2018-09-13 11:59:59','RLCETH','4h','0.001787000000000','0.001741000000000','0.076492795592055','0.074523758884033','42.805145826555545','42.805145826555545','test'),('2018-09-18 11:59:59','2018-09-18 23:59:59','RLCETH','4h','0.001733000000000','0.001711000000000','0.076492795592055','0.075521738752456','44.138947254503755','44.138947254503755','test'),('2018-09-19 03:59:59','2018-09-19 19:59:59','RLCETH','4h','0.001727000000000','0.001716000000000','0.076492795592055','0.076005580333507','44.29229623164737','44.292296231647370','test'),('2018-09-19 23:59:59','2018-09-20 23:59:59','RLCETH','4h','0.001733000000000','0.001659000000000','0.076492795592055','0.073226513495222','44.138947254503755','44.138947254503755','test'),('2018-09-27 03:59:59','2018-09-27 23:59:59','RLCETH','4h','0.001723000000000','0.001682000000000','0.076492795592055','0.074672595580869','44.39512222405978','44.395122224059783','test'),('2018-09-28 03:59:59','2018-09-28 07:59:59','RLCETH','4h','0.001683000000000','0.001703000000000','0.076492795592055','0.077401800887267','45.45026476057932','45.450264760579323','test'),('2018-09-28 11:59:59','2018-09-29 11:59:59','RLCETH','4h','0.001748000000000','0.001694000000000','0.076492795592055','0.074129745842644','43.76018054465389','43.760180544653892','test'),('2018-10-01 03:59:59','2018-10-05 11:59:59','RLCETH','4h','0.001734000000000','0.001726000000000','0.076492795592055','0.076139887653914','44.113492267621105','44.113492267621105','test'),('2018-10-07 11:59:59','2018-10-08 03:59:59','RLCETH','4h','0.001802000000000','0.001752000000000','0.076492795592055','0.074370353982952','42.4488321820505','42.448832182050502','test'),('2018-10-08 07:59:59','2018-10-11 07:59:59','RLCETH','4h','0.001845000000000','0.001790000000000','0.076492795592055','0.074212522552725','41.45950980599187','41.459509805991871','test'),('2018-10-12 19:59:59','2018-10-15 07:59:59','RLCETH','4h','0.001952000000000','0.001931000000000','0.076492795592055','0.075669871049313','39.1868829877331','39.186882987733100','test'),('2018-10-17 11:59:59','2018-10-26 23:59:59','RLCETH','4h','0.002041000000000','0.002411000000000','0.076492795592055','0.090359691412271','37.47809681139393','37.478096811393932','test'),('2018-11-01 19:59:59','2018-11-02 23:59:59','RLCETH','4h','0.002486000000000','0.002323000000000','0.076492795592055','0.071477378986462','30.76942702817981','30.769427028179809','test'),('2018-11-03 03:59:59','2018-11-03 07:59:59','RLCETH','4h','0.002352000000000','0.002245000000000','0.076492795592055','0.073012893751770','32.52244710546557','32.522447105465567','test'),('2018-11-18 07:59:59','2018-11-18 15:59:59','RLCETH','4h','0.002038000000000','0.002023000000000','0.076492795592055','0.075929796605852','37.53326574683759','37.533265746837593','test'),('2018-11-18 23:59:59','2018-11-19 03:59:59','RLCETH','4h','0.002033000000000','0.002001000000000','0.076492795592055','0.075288777166602','37.62557579540334','37.625575795403343','test'),('2018-11-22 03:59:59','2018-11-22 07:59:59','RLCETH','4h','0.002021000000000','0.002010000000000','0.076492795592055','0.076076456773889','37.84898346959674','37.848983469596739','test'),('2018-11-28 11:59:59','2018-11-29 23:59:59','RLCETH','4h','0.002135000000000','0.002129000000000','0.076492795592055','0.076277827548237','35.82800730307026','35.828007303070258','test'),('2019-01-09 07:59:59','2019-01-09 11:59:59','RLCETH','4h','0.001387000000000','0.001406000000000','0.076492795592055','0.077540642107015','55.14981657682409','55.149816576824087','test'),('2019-01-09 15:59:59','2019-01-14 19:59:59','RLCETH','4h','0.001409000000000','0.001471000000000','0.076492795592055','0.079858695752955','54.288712272572745','54.288712272572745','test'),('2019-01-15 07:59:59','2019-01-18 11:59:59','RLCETH','4h','0.001522000000000','0.001674000000000','0.076492795592055','0.084132023535545','50.25807857559462','50.258078575594617','test'),('2019-01-21 23:59:59','2019-02-01 03:59:59','RLCETH','4h','0.001757000000000','0.002251000000000','0.076492795592055','0.097999591848444','43.5360248105037','43.536024810503697','test'),('2019-02-03 11:59:59','2019-02-04 19:59:59','RLCETH','4h','0.002408000000000','0.002312000000000','0.081739455961738','0.078480740109443','33.944956794741785','33.944956794741785','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','RLCETH','4h','0.002179000000000','0.001940000000000','0.081739455961738','0.072773999341795','37.51237079473979','37.512370794739788','test'),('2019-02-23 23:59:59','2019-02-24 03:59:59','RLCETH','4h','0.001954000000000','0.001847000000000','0.081739455961738','0.077263446858408','41.831860778780964','41.831860778780964','test'),('2019-02-24 23:59:59','2019-03-06 03:59:59','RLCETH','4h','0.002047000000000','0.002507000000000','0.081739455961738','0.100107873031791','39.931341456638','39.931341456638002','test'),('2019-03-10 23:59:59','2019-03-11 07:59:59','RLCETH','4h','0.002514000000000','0.002446000000000','0.082156514835359','0.079934302023583','32.679600173174016','32.679600173174016','test'),('2019-03-11 15:59:59','2019-03-11 19:59:59','RLCETH','4h','0.002432000000000','0.002440000000000','0.082156514835359','0.082426766528896','33.781461692170645','33.781461692170645','test'),('2019-03-12 15:59:59','2019-03-16 11:59:59','RLCETH','4h','0.002598000000000','0.002948000000000','0.082156514835359','0.093224559559137','31.62298492508045','31.622984925080448','test'),('2019-03-22 23:59:59','2019-03-23 19:59:59','RLCETH','4h','0.002942000000000','0.002877000000000','0.084435535736744','0.082570032737802','28.700046137574514','28.700046137574514','test'),('2019-03-26 03:59:59','2019-03-29 23:59:59','RLCETH','4h','0.002984000000000','0.003024000000000','0.084435535736744','0.085567379379328','28.296091064592495','28.296091064592495','test'),('2019-03-31 11:59:59','2019-04-03 03:59:59','RLCETH','4h','0.003100000000000','0.002959000000000','0.084435535736744','0.080595080724202','27.237269592498066','27.237269592498066','test'),('2019-04-04 19:59:59','2019-04-07 15:59:59','RLCETH','4h','0.003347000000000','0.003243000000000','0.084435535736744','0.081811903912238','25.22722908178787','25.227229081787868','test'),('2019-04-19 19:59:59','2019-04-20 03:59:59','RLCETH','4h','0.003034000000000','0.002997000000000','0.084435535736744','0.083405834081418','27.82977446827423','27.829774468274231','test'),('2019-04-20 07:59:59','2019-04-20 11:59:59','RLCETH','4h','0.003018000000000','0.003105000000000','0.084435535736744','0.086869562114841','27.97731469077005','27.977314690770051','test'),('2019-04-20 19:59:59','2019-04-23 15:59:59','RLCETH','4h','0.003146000000000','0.003171000000000','0.084435535736744','0.085106511068409','26.839013266606486','26.839013266606486','test'),('2019-05-02 11:59:59','2019-05-03 11:59:59','RLCETH','4h','0.003296000000000','0.003066000000000','0.084435535736744','0.078543492891037','25.617577590031555','25.617577590031555','test'),('2019-05-03 15:59:59','2019-05-10 19:59:59','RLCETH','4h','0.003142000000000','0.003596000000000','0.084435535736744','0.096635960060258','26.873181329326545','26.873181329326545','test'),('2019-05-13 23:59:59','2019-05-14 03:59:59','RLCETH','4h','0.003581000000000','0.003295000000000','0.084732019571453','0.077964815550946','23.661552519255366','23.661552519255366','test'),('2019-06-10 03:59:59','2019-06-12 15:59:59','RLCETH','4h','0.001856000000000','0.001814000000000','0.084732019571453','0.082814592404427','45.65302778634321','45.653027786343209','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 21:56:47
