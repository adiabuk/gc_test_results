-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-03 11:59:59','2018-06-04 07:59:59','LTCUSDT','4h','126.930000000000007','122.510000000000005','15.000000000000000','14.477664854644292','0.11817537225242258','0.118175372252423','test'),('2018-07-03 15:59:59','2018-07-05 15:59:59','LTCUSDT','4h','86.290000000000006','84.230000000000004','15.000000000000000','14.641905203383937','0.17383242554177772','0.173832425541778','test'),('2018-07-08 15:59:59','2018-07-08 23:59:59','LTCUSDT','4h','84.519999999999996','82.219999999999999','15.000000000000000','14.591812588736394','0.17747278750591577','0.177472787505916','test'),('2018-07-16 23:59:59','2018-07-20 07:59:59','LTCUSDT','4h','83.489999999999995','83.939999999999998','15.000000000000000','15.080848005749193','0.17966223499820339','0.179662234998203','test'),('2018-07-24 11:59:59','2018-07-26 23:59:59','LTCUSDT','4h','87.829999999999998','83.370000000000005','15.000000000000000','14.238301263805081','0.17078446999886143','0.170784469998861','test'),('2018-08-27 23:59:59','2018-08-30 11:59:59','LTCUSDT','4h','60.609999999999999','59.100000000000001','15.000000000000000','14.626299290546115','0.24748391354561955','0.247483913545620','test'),('2018-08-31 19:59:59','2018-09-05 11:59:59','LTCUSDT','4h','62.039999999999999','62.299999999999997','15.000000000000000','15.062862669245648','0.24177949709864605','0.241779497098646','test'),('2018-09-16 19:59:59','2018-09-17 11:59:59','LTCUSDT','4h','57.009999999999998','55.990000000000002','15.000000000000000','14.731626030520962','0.26311173478337135','0.263111734783371','test'),('2018-09-21 11:59:59','2018-09-24 11:59:59','LTCUSDT','4h','58.619999999999997','57.369999999999997','15.000000000000000','14.680143295803481','0.25588536335721596','0.255885363357216','test'),('2018-09-27 15:59:59','2018-09-29 07:59:59','LTCUSDT','4h','62.350000000000001','60.289999999999999','15.000000000000000','14.504410585404971','0.24057738572574178','0.240577385725742','test'),('2018-09-29 11:59:59','2018-09-30 19:59:59','LTCUSDT','4h','61.939999999999998','60.930000000000000','15.000000000000000','14.755408459799806','0.24216984178237005','0.242169841782370','test'),('2018-10-01 03:59:59','2018-10-01 07:59:59','LTCUSDT','4h','61.590000000000003','60.590000000000003','15.000000000000000','14.756453969800292','0.24354603019970772','0.243546030199708','test'),('2018-11-04 15:59:59','2018-11-08 03:59:59','LTCUSDT','4h','54.250000000000000','53.320000000000000','15.000000000000000','14.742857142857144','0.2764976958525346','0.276497695852535','test'),('2018-12-17 15:59:59','2018-12-25 03:59:59','LTCUSDT','4h','27.920000000000002','29.870000000000001','15.000000000000000','16.047636103151863','0.5372492836676217','0.537249283667622','test'),('2018-12-29 07:59:59','2018-12-29 23:59:59','LTCUSDT','4h','32.079999999999998','30.280000000000001','15.000000000000000','14.158354114713219','0.46758104738154616','0.467581047381546','test'),('2018-12-30 03:59:59','2018-12-31 03:59:59','LTCUSDT','4h','30.510000000000002','30.660000000000000','15.000000000000000','15.073746312684364','0.4916420845624385','0.491642084562439','test'),('2018-12-31 07:59:59','2018-12-31 11:59:59','LTCUSDT','4h','30.690000000000001','30.219999999999999','15.000000000000000','14.770283479960897','0.48875855327468226','0.488758553274682','test'),('2019-01-01 23:59:59','2019-01-03 19:59:59','LTCUSDT','4h','31.480000000000000','30.850000000000001','15.000000000000000','14.699809402795426','0.4764930114358323','0.476493011435832','test'),('2019-01-03 23:59:59','2019-01-04 15:59:59','LTCUSDT','4h','31.390000000000001','31.090000000000000','15.000000000000000','14.856642242752470','0.47785919082510353','0.477859190825104','test'),('2019-01-04 23:59:59','2019-01-10 07:59:59','LTCUSDT','4h','31.760000000000002','35.170000000000002','15.000000000000000','16.610516372795971','0.4722921914357682','0.472292191435768','test'),('2019-01-25 03:59:59','2019-01-27 03:59:59','LTCUSDT','4h','32.700000000000003','32.930000000000000','15.000000000000000','15.105504587155963','0.4587155963302752','0.458715596330275','test'),('2019-01-27 19:59:59','2019-01-27 23:59:59','LTCUSDT','4h','32.609999999999999','32.210000000000001','15.000000000000000','14.816007359705612','0.45998160073597055','0.459981600735971','test'),('2019-02-01 19:59:59','2019-02-06 03:59:59','LTCUSDT','4h','33.020000000000003','32.789999999999999','15.000000000000000','14.895517867958810','0.4542701393095093','0.454270139309509','test'),('2019-02-08 11:59:59','2019-02-13 11:59:59','LTCUSDT','4h','37.649999999999999','42.469999999999999','15.000000000000000','16.920318725099602','0.39840637450199207','0.398406374501992','test'),('2019-02-16 03:59:59','2019-02-23 11:59:59','LTCUSDT','4h','43.270000000000003','48.890000000000001','15.000000000000000','16.948232031430550','0.3466605038132655','0.346660503813266','test'),('2019-02-23 19:59:59','2019-02-24 15:59:59','LTCUSDT','4h','51.200000000000003','44.390000000000001','15.198290490125515','13.176799118294367','0.29684161113526397','0.296841611135264','test'),('2019-03-01 19:59:59','2019-03-02 11:59:59','LTCUSDT','4h','48.170000000000002','48.450000000000003','15.198290490125515','15.286634300323463','0.31551360784981347','0.315513607849813','test'),('2019-03-02 23:59:59','2019-03-04 07:59:59','LTCUSDT','4h','48.490000000000002','46.140000000000001','15.198290490125515','14.461726607844735','0.3134314392684165','0.313431439268416','test'),('2019-03-05 15:59:59','2019-03-11 07:59:59','LTCUSDT','4h','52.140000000000001','55.289999999999999','15.198290490125515','16.116484104316065','0.29149003625096886','0.291490036250969','test'),('2019-03-12 23:59:59','2019-03-13 15:59:59','LTCUSDT','4h','56.579999999999998','55.630000000000003','15.198290490125515','14.943105336968584','0.2686159506915079','0.268615950691508','test'),('2019-03-15 03:59:59','2019-03-18 19:59:59','LTCUSDT','4h','56.289999999999999','58.880000000000003','15.198290490125515','15.897590052559785','0.2699998310557029','0.269999831055703','test'),('2019-03-20 15:59:59','2019-03-21 15:59:59','LTCUSDT','4h','60.020000000000003','58.460000000000001','15.198290490125515','14.803266612008290','0.2532204346905284','0.253220434690528','test'),('2019-03-23 07:59:59','2019-03-24 07:59:59','LTCUSDT','4h','60.990000000000002','59.299999999999997','15.198290490125515','14.777154059098917','0.2491931544536074','0.249193154453607','test'),('2019-03-24 11:59:59','2019-03-24 19:59:59','LTCUSDT','4h','59.759999999999998','59.320000000000000','15.198290490125515','15.086388752915756','0.2543221300221807','0.254322130022181','test'),('2019-03-25 03:59:59','2019-03-25 07:59:59','LTCUSDT','4h','60.060000000000002','59.539999999999999','15.198290490125515','15.066703559475078','0.2530517897123795','0.253051789712380','test'),('2019-03-27 11:59:59','2019-03-30 19:59:59','LTCUSDT','4h','61.090000000000003','60.259999999999998','15.198290490125515','14.991798738499975','0.24878524292233614','0.248785242922336','test'),('2019-04-02 07:59:59','2019-04-08 11:59:59','LTCUSDT','4h','66.909999999999997','85.379999999999995','15.198290490125515','19.393663757987095','0.22714527709050242','0.227145277090502','test'),('2019-04-10 19:59:59','2019-04-11 03:59:59','LTCUSDT','4h','89.359999999999999','84.390000000000001','15.603747769821997','14.735902800976703','0.1746166939326544','0.174616693932654','test'),('2019-04-19 15:59:59','2019-04-20 11:59:59','LTCUSDT','4h','82.750000000000000','80.769999999999996','15.603747769821997','15.230389212912659','0.18856492773198788','0.188564927731988','test'),('2019-04-20 15:59:59','2019-04-20 19:59:59','LTCUSDT','4h','80.840000000000003','80.519999999999996','15.603747769821997','15.541981326398652','0.19302013569794652','0.193020135697947','test'),('2019-04-20 23:59:59','2019-04-21 03:59:59','LTCUSDT','4h','81.150000000000006','80.840000000000003','15.603747769821997','15.544140107361800','0.19228278212966107','0.192282782129661','test'),('2019-05-03 11:59:59','2019-05-04 15:59:59','LTCUSDT','4h','78.829999999999998','75.950000000000003','15.603747769821997','15.033675543802875','0.19794174514552831','0.197941745145528','test'),('2019-05-04 19:59:59','2019-05-05 23:59:59','LTCUSDT','4h','76.340000000000003','75.700000000000003','15.603747769821997','15.472933012516703','0.2043980582895205','0.204398058289521','test'),('2019-05-07 03:59:59','2019-05-07 15:59:59','LTCUSDT','4h','77.650000000000006','74.709999999999994','15.603747769821997','15.012955516849983','0.20094974590884734','0.200949745908847','test'),('2019-05-10 15:59:59','2019-05-17 03:59:59','LTCUSDT','4h','76.319999999999993','89.939999999999998','15.603747769821997','18.388378857675452','0.20445162172198636','0.204451621721986','test'),('2019-05-19 15:59:59','2019-05-20 15:59:59','LTCUSDT','4h','93.099999999999994','90.250000000000000','15.636341324801711','15.157677814858802','0.1679521087518981','0.167952108751898','test'),('2019-05-20 19:59:59','2019-05-21 03:59:59','LTCUSDT','4h','90.670000000000002','89.799999999999997','15.636341324801711','15.486306947912137','0.17245330676962292','0.172453306769623','test'),('2019-05-24 11:59:59','2019-05-30 19:59:59','LTCUSDT','4h','99.239999999999995','113.379999999999995','15.636341324801711','17.864252110096917','0.15756087590489432','0.157560875904894','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 14:28:39
