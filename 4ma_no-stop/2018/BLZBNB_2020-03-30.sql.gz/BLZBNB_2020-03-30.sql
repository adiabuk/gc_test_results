-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-26 03:59:59','2018-07-26 07:59:59','BLZBNB','4h','0.025740000000000','0.024560000000000','0.711908500000000','0.679272445998446','27.657672882672887','27.657672882672887','test'),('2018-08-28 03:59:59','2018-08-29 15:59:59','BLZBNB','4h','0.013090000000000','0.012360000000000','0.711908500000000','0.672206956455309','54.385676088617274','54.385676088617274','test'),('2018-08-31 11:59:59','2018-09-04 23:59:59','BLZBNB','4h','0.012990000000000','0.013540000000000','0.711908500000000','0.742050892224788','54.80434949961509','54.804349499615093','test'),('2018-09-05 07:59:59','2018-09-05 11:59:59','BLZBNB','4h','0.014300000000000','0.012820000000000','0.711908500000000','0.638228459440560','49.78381118881119','49.783811188811192','test'),('2018-09-19 07:59:59','2018-09-19 11:59:59','BLZBNB','4h','0.012050000000000','0.011240000000000','0.711908500000000','0.664054069709544','59.079543568464736','59.079543568464736','test'),('2018-09-19 15:59:59','2018-09-19 19:59:59','BLZBNB','4h','0.011360000000000','0.011790000000000','0.711908500000000','0.738855740757042','62.668001760563385','62.668001760563385','test'),('2018-09-20 03:59:59','2018-09-20 23:59:59','BLZBNB','4h','0.011670000000000','0.011610000000000','0.711908500000000','0.708248302056555','61.00329905741217','61.003299057412171','test'),('2018-09-21 03:59:59','2018-09-24 15:59:59','BLZBNB','4h','0.011900000000000','0.012040000000000','0.711908500000000','0.720283894117647','59.82424369747899','59.824243697478991','test'),('2018-09-26 19:59:59','2018-09-27 03:59:59','BLZBNB','4h','0.012470000000000','0.012390000000000','0.711908500000000','0.707341324378508','57.08969526864475','57.089695268644753','test'),('2018-09-27 11:59:59','2018-09-27 19:59:59','BLZBNB','4h','0.012210000000000','0.012050000000000','0.711908500000000','0.702579641687142','58.30536445536446','58.305364455364462','test'),('2018-09-27 23:59:59','2018-09-28 03:59:59','BLZBNB','4h','0.012320000000000','0.012360000000000','0.711908500000000','0.714219891233766','57.784780844155854','57.784780844155854','test'),('2018-09-30 03:59:59','2018-10-02 23:59:59','BLZBNB','4h','0.012340000000000','0.012370000000000','0.711908500000000','0.713639233792545','57.69112641815235','57.691126418152351','test'),('2018-10-06 23:59:59','2018-10-07 15:59:59','BLZBNB','4h','0.013260000000000','0.012760000000000','0.711908500000000','0.685064288084465','53.6884238310709','53.688423831070899','test'),('2018-10-07 19:59:59','2018-10-08 07:59:59','BLZBNB','4h','0.012810000000000','0.012350000000000','0.711908500000000','0.686344260343482','55.57443403590945','55.574434035909448','test'),('2018-10-08 11:59:59','2018-10-10 07:59:59','BLZBNB','4h','0.012650000000000','0.012880000000000','0.711908500000000','0.724852290909091','56.27735177865613','56.277351778656133','test'),('2018-10-10 11:59:59','2018-10-11 03:59:59','BLZBNB','4h','0.013270000000000','0.012440000000000','0.711908500000000','0.667380688771665','53.64796533534288','53.647965335342882','test'),('2018-10-16 15:59:59','2018-10-19 05:59:59','BLZBNB','4h','0.013550000000000','0.013310000000000','0.711908500000000','0.699299050553506','52.539372693726946','52.539372693726946','test'),('2018-10-20 19:59:59','2018-10-22 03:59:59','BLZBNB','4h','0.013580000000000','0.013210000000000','0.711908500000000','0.692511876656848','52.42330633284242','52.423306332842422','test'),('2018-10-27 07:59:59','2018-10-27 15:59:59','BLZBNB','4h','0.013560000000000','0.012940000000000','0.711908500000000','0.679358111356932','52.50062684365783','52.500626843657827','test'),('2018-10-28 11:59:59','2018-10-29 03:59:59','BLZBNB','4h','0.013510000000000','0.013490000000000','0.711908500000000','0.710854601406366','52.694929681717255','52.694929681717255','test'),('2018-10-29 07:59:59','2018-10-31 15:59:59','BLZBNB','4h','0.013750000000000','0.014050000000000','0.711908500000000','0.727441049090909','51.775163636363644','51.775163636363644','test'),('2018-11-01 11:59:59','2018-11-04 11:59:59','BLZBNB','4h','0.015140000000000','0.014480000000000','0.711908500000000','0.680874179656539','47.02169749009247','47.021697490092471','test'),('2018-11-29 03:59:59','2018-11-30 11:59:59','BLZBNB','4h','0.011620000000000','0.011160000000000','0.711908500000000','0.683726235800344','61.265791738382106','61.265791738382106','test'),('2018-11-30 15:59:59','2018-12-03 07:59:59','BLZBNB','4h','0.011710000000000','0.011400000000000','0.711908500000000','0.693062075149445','60.79491887275833','60.794918872758331','test'),('2018-12-11 07:59:59','2018-12-11 15:59:59','BLZBNB','4h','0.010830000000000','0.009870000000000','0.711908500000000','0.648803037396122','65.73485687903971','65.734856879039711','test'),('2019-01-05 03:59:59','2019-01-05 15:59:59','BLZBNB','4h','0.007920000000000','0.007550000000000','0.711908500000000','0.678650148358586','89.88743686868688','89.887436868686876','test'),('2019-01-06 19:59:59','2019-01-07 03:59:59','BLZBNB','4h','0.007620000000000','0.007380000000000','0.711908500000000','0.689486185039370','93.42631233595802','93.426312335958016','test'),('2019-02-26 11:59:59','2019-02-27 23:59:59','BLZBNB','4h','0.004510000000000','0.004420000000000','0.711908500000000','0.697701900221730','157.85110864745013','157.851108647450133','test'),('2019-03-15 19:59:59','2019-03-16 15:59:59','BLZBNB','4h','0.004120000000000','0.003710000000000','0.711908500000000','0.641063236650485','172.79332524271845','172.793325242718453','test'),('2019-03-16 19:59:59','2019-03-16 23:59:59','BLZBNB','4h','0.003770000000000','0.003690000000000','0.711908500000000','0.696801688328913','188.83514588859418','188.835145888594184','test'),('2019-03-22 03:59:59','2019-03-22 15:59:59','BLZBNB','4h','0.003750000000000','0.003740000000000','0.711908500000000','0.710010077333333','189.8422666666667','189.842266666666688','test'),('2019-03-24 03:59:59','2019-03-24 11:59:59','BLZBNB','4h','0.003840000000000','0.003190000000000','0.711908500000000','0.591403154947917','185.39283854166666','185.392838541666663','test'),('2019-03-28 23:59:59','2019-03-31 07:59:59','BLZBNB','4h','0.003940000000000','0.003720000000000','0.711908500000000','0.672157263959391','180.68743654822336','180.687436548223360','test'),('2019-04-01 03:59:59','2019-04-01 07:59:59','BLZBNB','4h','0.003960000000000','0.003770000000000','0.474605666666667','0.451834182659933','119.84991582491584','119.849915824915840','test'),('2019-04-03 19:59:59','2019-04-04 03:59:59','BLZBNB','4h','0.003900000000000','0.003580000000000','0.522427066965139','0.479561256342358','133.95565819618943','133.955658196189432','test'),('2019-04-04 11:59:59','2019-04-04 19:59:59','BLZBNB','4h','0.003950000000000','0.003730000000000','0.522427066965139','0.493329863235435','132.26001695319974','132.260016953199738','test'),('2019-04-04 23:59:59','2019-04-09 07:59:59','BLZBNB','4h','0.003930000000000','0.004410000000000','0.522427066965139','0.586234953006682','132.93309591988267','132.933095919882675','test'),('2019-05-08 23:59:59','2019-05-11 07:59:59','BLZBNB','4h','0.002490000000000','0.002380000000000','0.522427066965139','0.499347959589169','209.81006705427268','209.810067054272679','test'),('2019-05-16 15:59:59','2019-05-17 03:59:59','BLZBNB','4h','0.002380000000000','0.002280000000000','0.522427066965139','0.500476349865763','219.50717099375586','219.507170993755864','test'),('2019-06-03 19:59:59','2019-06-04 03:59:59','BLZBNB','4h','0.002050000000000','0.001960000000000','0.522427066965139','0.499491244513011','254.84247169031167','254.842471690311669','test'),('2019-06-07 15:59:59','2019-06-08 19:59:59','BLZBNB','4h','0.002070000000000','0.001960000000000','0.522427066965139','0.494665242150566','252.3802255870237','252.380225587023688','test'),('2019-06-08 23:59:59','2019-06-09 03:59:59','BLZBNB','4h','0.001970000000000','0.001980000000000','0.522427066965139','0.525078981010647','265.191404550832','265.191404550831976','test'),('2019-06-10 11:59:59','2019-06-11 07:59:59','BLZBNB','4h','0.002100000000000','0.001980000000000','0.522427066965139','0.492574091709988','248.77479379292333','248.774793792923333','test'),('2019-06-24 15:59:59','2019-06-25 15:59:59','BLZBNB','4h','0.002070000000000','0.001890000000000','0.522427066965139','0.476998626359475','252.3802255870237','252.380225587023688','test'),('2019-06-25 19:59:59','2019-06-26 03:59:59','BLZBNB','4h','0.001910000000000','0.001870000000000','0.522427066965139','0.511486185981576','273.522024589078','273.522024589078001','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  0:59:10
