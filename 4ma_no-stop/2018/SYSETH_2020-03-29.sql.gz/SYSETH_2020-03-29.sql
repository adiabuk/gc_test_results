-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-12 07:59:59','2018-09-13 07:59:59','SYSETH','4h','0.000426860000000','0.000420350000000','0.072144500000000','0.071044231305346','169.01208827250153','169.012088272501529','test'),('2018-09-25 11:59:59','2018-09-26 03:59:59','SYSETH','4h','0.000405090000000','0.000403870000000','0.072144500000000','0.071927224110691','178.09499123651534','178.094991236515341','test'),('2018-09-26 11:59:59','2018-09-28 03:59:59','SYSETH','4h','0.000403380000000','0.000394300000000','0.072144500000000','0.070520542292627','178.84996777232385','178.849967772323851','test'),('2018-09-28 07:59:59','2018-09-28 15:59:59','SYSETH','4h','0.000401470000000','0.000394170000000','0.072144500000000','0.070832683799537','179.7008493785339','179.700849378533889','test'),('2018-09-30 07:59:59','2018-09-30 11:59:59','SYSETH','4h','0.000405690000000','0.000395350000000','0.072144500000000','0.070305721301979','177.83159555325494','177.831595553254942','test'),('2018-10-01 11:59:59','2018-10-05 23:59:59','SYSETH','4h','0.000406520000000','0.000412470000000','0.072144500000000','0.073200437653744','177.4685132342812','177.468513234281204','test'),('2018-10-06 23:59:59','2018-10-07 23:59:59','SYSETH','4h','0.000424430000000','0.000417140000000','0.072144500000000','0.070905347713404','169.9797375303348','169.979737530334802','test'),('2018-10-08 15:59:59','2018-10-09 07:59:59','SYSETH','4h','0.000427330000000','0.000417400000000','0.072144500000000','0.070468055835069','168.82619989235485','168.826199892354850','test'),('2018-10-11 07:59:59','2018-10-15 07:59:59','SYSETH','4h','0.000425750000000','0.000440390000000','0.072144500000000','0.074625287974163','169.45273047563123','169.452730475631228','test'),('2018-10-15 11:59:59','2018-10-18 15:59:59','SYSETH','4h','0.000464850000000','0.000457750000000','0.072144500000000','0.071042583360224','155.1995267290524','155.199526729052394','test'),('2018-10-20 11:59:59','2018-10-22 19:59:59','SYSETH','4h','0.000472900000000','0.000473480000000','0.072144500000000','0.072232983421442','152.5576231761472','152.557623176147189','test'),('2018-10-24 03:59:59','2018-10-26 11:59:59','SYSETH','4h','0.000482490000000','0.000487280000000','0.072144500000000','0.072860726564281','149.52537876432672','149.525378764326717','test'),('2018-10-26 15:59:59','2018-10-27 03:59:59','SYSETH','4h','0.000492440000000','0.000486070000000','0.072144500000000','0.071211268611404','146.5041426366664','146.504142636666387','test'),('2018-11-01 19:59:59','2018-11-02 03:59:59','SYSETH','4h','0.000484300000000','0.000474660000000','0.072144500000000','0.070708462461284','148.96654965930207','148.966549659302075','test'),('2018-11-29 11:59:59','2018-11-30 11:59:59','SYSETH','4h','0.000358940000000','0.000337940000000','0.072144500000000','0.067923642753664','200.99320220649693','200.993202206496932','test'),('2018-11-30 15:59:59','2018-11-30 19:59:59','SYSETH','4h','0.000345450000000','0.000343910000000','0.072144500000000','0.071822883181358','208.84209002750035','208.842090027500348','test'),('2018-11-30 23:59:59','2018-12-06 03:59:59','SYSETH','4h','0.000356100000000','0.000360580000000','0.072144500000000','0.073052130890199','202.5961808480764','202.596180848076386','test'),('2018-12-07 11:59:59','2018-12-07 19:59:59','SYSETH','4h','0.000374650000000','0.000345520000000','0.072144500000000','0.066535079781129','192.56506072334176','192.565060723341759','test'),('2018-12-14 03:59:59','2018-12-18 07:59:59','SYSETH','4h','0.000490000000000','0.000484120000000','0.072144500000000','0.071278766000000','147.23367346938775','147.233673469387753','test'),('2019-01-11 19:59:59','2019-01-12 03:59:59','SYSETH','4h','0.000334620000000','0.000324380000000','0.072144500000000','0.069936742902397','215.60127906281753','215.601279062817525','test'),('2019-01-13 03:59:59','2019-01-13 23:59:59','SYSETH','4h','0.000338660000000','0.000328130000000','0.072144500000000','0.069901301556133','213.02929191519516','213.029291915195159','test'),('2019-01-14 03:59:59','2019-01-14 07:59:59','SYSETH','4h','0.000329610000000','0.000326230000000','0.072144500000000','0.071404691104639','218.87837140863445','218.878371408634450','test'),('2019-01-15 07:59:59','2019-01-15 15:59:59','SYSETH','4h','0.000370150000000','0.000339990000000','0.072144500000000','0.066266131446711','194.90611914088882','194.906119140888819','test'),('2019-01-15 23:59:59','2019-01-16 11:59:59','SYSETH','4h','0.000340880000000','0.000337370000000','0.072144500000000','0.071401636837010','211.6419267777517','211.641926777751706','test'),('2019-01-16 15:59:59','2019-01-16 19:59:59','SYSETH','4h','0.000341290000000','0.000335880000000','0.072144500000000','0.071000892671921','211.38767616982625','211.387676169826250','test'),('2019-01-17 03:59:59','2019-01-23 19:59:59','SYSETH','4h','0.000341460000000','0.000364350000000','0.072144500000000','0.076980754920049','211.282434252914','211.282434252913987','test'),('2019-01-24 15:59:59','2019-01-27 15:59:59','SYSETH','4h','0.000387030000000','0.000375320000000','0.072144500000000','0.069961692220241','186.40544660620623','186.405446606206226','test'),('2019-01-27 19:59:59','2019-01-30 15:59:59','SYSETH','4h','0.000395120000000','0.000388160000000','0.072144500000000','0.070873681716947','182.58883377201863','182.588833772018631','test'),('2019-01-30 19:59:59','2019-01-30 23:59:59','SYSETH','4h','0.000391230000000','0.000386840000000','0.072144500000000','0.071334965058917','184.40431459755132','184.404314597551320','test'),('2019-02-01 15:59:59','2019-02-02 19:59:59','SYSETH','4h','0.000392170000000','0.000384420000000','0.072144500000000','0.070718792079965','183.9623122625392','183.962312262539200','test'),('2019-02-03 23:59:59','2019-02-05 07:59:59','SYSETH','4h','0.000392700000000','0.000389590000000','0.072144500000000','0.071573149363382','183.71403106697224','183.714031066972240','test'),('2019-02-05 11:59:59','2019-02-05 19:59:59','SYSETH','4h','0.000393420000000','0.000391930000000','0.072144500000000','0.071871267055564','183.37781505769914','183.377815057699138','test'),('2019-02-20 23:59:59','2019-02-23 15:59:59','SYSETH','4h','0.000363850000000','0.000368600000000','0.072144500000000','0.073086334203655','198.2808849800742','198.280884980074205','test'),('2019-02-27 19:59:59','2019-02-28 11:59:59','SYSETH','4h','0.000370730000000','0.000362270000000','0.072144500000000','0.070498173913630','194.6011922423327','194.601192242332701','test'),('2019-02-28 15:59:59','2019-03-05 19:59:59','SYSETH','4h','0.000369510000000','0.000382160000000','0.072144500000000','0.074614332819139','195.24370111769642','195.243701117696418','test'),('2019-03-06 15:59:59','2019-03-11 11:59:59','SYSETH','4h','0.000392250000000','0.000395910000000','0.072144500000000','0.072817664741874','183.92479286169535','183.924792861695352','test'),('2019-03-13 07:59:59','2019-03-16 03:59:59','SYSETH','4h','0.000406660000000','0.000400240000000','0.072144500000000','0.071005544385974','177.40741651502483','177.407416515024835','test'),('2019-03-18 23:59:59','2019-03-21 15:59:59','SYSETH','4h','0.000416870000000','0.000426280000000','0.072144500000000','0.073773016671864','173.06234557535922','173.062345575359217','test'),('2019-03-21 19:59:59','2019-03-23 19:59:59','SYSETH','4h','0.000426780000000','0.000423440000000','0.072144500000000','0.071579893809457','169.04376962369372','169.043769623693720','test'),('2019-03-26 03:59:59','2019-03-30 03:59:59','SYSETH','4h','0.000442280000000','0.000436450000000','0.072144500000000','0.071193513215610','163.11951704802388','163.119517048023880','test'),('2019-03-30 07:59:59','2019-03-30 11:59:59','SYSETH','4h','0.000448340000000','0.000442830000000','0.072144500000000','0.071257859961190','160.91470758799127','160.914707587991273','test'),('2019-03-30 19:59:59','2019-03-31 03:59:59','SYSETH','4h','0.000456090000000','0.000432470000000','0.072144500000000','0.068408278881361','158.18040299063782','158.180402990637816','test'),('2019-04-01 23:59:59','2019-04-02 07:59:59','SYSETH','4h','0.000447950000000','0.000431960000000','0.072144500000000','0.069569233664471','161.0548052237973','161.054805223797302','test'),('2019-04-25 11:59:59','2019-04-26 03:59:59','SYSETH','4h','0.000361740000000','0.000352280000000','0.072144500000000','0.070257821805717','199.43744125615083','199.437441256150834','test'),('2019-05-02 15:59:59','2019-05-03 07:59:59','SYSETH','4h','0.000354950000000','0.000351160000000','0.072144500000000','0.071374172756726','203.25257078461757','203.252570784617575','test'),('2019-05-04 11:59:59','2019-05-07 03:59:59','SYSETH','4h','0.000375620000000','0.000346810000000','0.072144500000000','0.066611027221660','192.06778126830307','192.067781268303065','test'),('2019-05-08 11:59:59','2019-05-09 15:59:59','SYSETH','4h','0.000365310000000','0.000355770000000','0.072144500000000','0.070260460335058','197.48843448030442','197.488434480304420','test'),('2019-05-22 23:59:59','2019-05-23 03:59:59','SYSETH','4h','0.000299740000000','0.000299810000000','0.072144500000000','0.072161348318543','240.6902648962434','240.690264896243406','test'),('2019-05-23 11:59:59','2019-05-24 11:59:59','SYSETH','4h','0.000293930000000','0.000282060000000','0.072144500000000','0.069231033477359','245.44789575749326','245.447895757493256','test'),('2019-06-02 11:59:59','2019-06-03 07:59:59','SYSETH','4h','0.000281400000000','0.000273240000000','0.072144500000000','0.070052463326226','256.3770433546553','256.377043354655314','test'),('2019-06-03 11:59:59','2019-06-03 23:59:59','SYSETH','4h','0.000282720000000','0.000276530000000','0.072144500000000','0.070564935572298','255.1800367855122','255.180036785512186','test'),('2019-07-17 03:59:59','2019-07-21 23:59:59','SYSETH','4h','0.000139550000000','0.000144220000000','0.072144500000000','0.074558794625582','516.9795772124686','516.979577212468598','test'),('2019-07-22 11:59:59','2019-07-24 15:59:59','SYSETH','4h','0.000147750000000','0.000146660000000','0.072144500000000','0.071612266463621','488.28764805414545','488.287648054145450','test'),('2019-07-24 19:59:59','2019-07-24 23:59:59','SYSETH','4h','0.000149960000000','0.000147360000000','0.072144500000000','0.070893661776474','481.0916244331822','481.091624433182176','test'),('2019-07-26 15:59:59','2019-07-31 15:59:59','SYSETH','4h','0.000154940000000','0.000168950000000','0.072144500000000','0.078667957112431','465.62863043758875','465.628630437588754','test'),('2019-08-16 23:59:59','2019-08-18 19:59:59','SYSETH','4h','0.000151790000000','0.000134730000000','0.072144500000000','0.064036026648659','475.2915211805784','475.291521180578400','test'),('2019-08-21 23:59:59','2019-08-22 07:59:59','SYSETH','4h','0.000135000000000','0.000134320000000','0.072144500000000','0.071781105481481','534.4037037037037','534.403703703703741','test'),('2019-08-22 11:59:59','2019-08-23 15:59:59','SYSETH','4h','0.000136500000000','0.000133770000000','0.072144500000000','0.070701610000000','528.5311355311355','528.531135531135533','test'),('2019-08-24 11:59:59','2019-08-26 03:59:59','SYSETH','4h','0.000150260000000','0.000141790000000','0.072144500000000','0.068077789531479','480.13110608278987','480.131106082789870','test'),('2019-08-26 07:59:59','2019-08-31 19:59:59','SYSETH','4h','0.000146250000000','0.000151100000000','0.072144500000000','0.074536984273504','493.29572649572646','493.295726495726456','test'),('2019-09-01 15:59:59','2019-09-02 15:59:59','SYSETH','4h','0.000152880000000','0.000150950000000','0.072144500000000','0.071233727596808','471.90279958137097','471.902799581370971','test'),('2019-09-05 19:59:59','2019-09-05 23:59:59','SYSETH','4h','0.000152240000000','0.000149150000000','0.072144500000000','0.070680190324488','473.886626379401','473.886626379400980','test'),('2019-09-06 03:59:59','2019-09-06 07:59:59','SYSETH','4h','0.000149460000000','0.000148020000000','0.072144500000000','0.071449410477720','482.7010571390339','482.701057139033878','test'),('2019-09-06 15:59:59','2019-09-06 19:59:59','SYSETH','4h','0.000147060000000','0.000146380000000','0.072144500000000','0.071810906500748','490.57867537059707','490.578675370597068','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 10:49:43
