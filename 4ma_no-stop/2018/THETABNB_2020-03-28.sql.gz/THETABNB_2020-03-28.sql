-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-23 03:59:59','2018-11-28 07:59:59','THETABNB','4h','0.009920000000000','0.010120000000000','0.711908500000000','0.726261493951613','71.76496975806452','71.764969758064524','test'),('2018-11-30 07:59:59','2018-12-02 19:59:59','THETABNB','4h','0.011440000000000','0.012830000000000','0.715496748487903','0.802432105166066','62.54342207062092','62.543422070620920','test'),('2018-12-23 03:59:59','2018-12-23 11:59:59','THETABNB','4h','0.009500000000000','0.009180000000000','0.737230587657444','0.712397557336351','77.60321975341517','77.603219753415175','test'),('2018-12-23 19:59:59','2018-12-23 23:59:59','THETABNB','4h','0.009170000000000','0.009190000000000','0.737230587657444','0.738838506060187','80.39592013712586','80.395920137125856','test'),('2019-01-23 19:59:59','2019-01-27 15:59:59','THETABNB','4h','0.007940000000000','0.008020000000000','0.737230587657444','0.744658603653993','92.85019995685694','92.850199956856940','test'),('2019-01-29 11:59:59','2019-01-31 11:59:59','THETABNB','4h','0.008760000000000','0.008550000000000','0.737230587657444','0.719557251651957','84.15874288326985','84.158742883269852','test'),('2019-01-31 19:59:59','2019-01-31 23:59:59','THETABNB','4h','0.008440000000000','0.008470000000000','0.737230587657444','0.739851075528264','87.34959569400995','87.349595694009949','test'),('2019-02-01 23:59:59','2019-02-02 07:59:59','THETABNB','4h','0.008910000000000','0.008200000000000','0.737230587657444','0.678483818046133','82.74192903001617','82.741929030016166','test'),('2019-02-04 23:59:59','2019-02-06 07:59:59','THETABNB','4h','0.008550000000000','0.008420000000000','0.737230587657444','0.726021233693062','86.22579972601683','86.225799726016831','test'),('2019-02-06 11:59:59','2019-02-06 15:59:59','THETABNB','4h','0.008600000000000','0.008130000000000','0.737230587657444','0.696940078797095','85.72448693691209','85.724486936912086','test'),('2019-02-07 23:59:59','2019-02-08 07:59:59','THETABNB','4h','0.008850000000000','0.008560000000000','0.737230587657444','0.713072749191833','83.30289126072813','83.302891260728131','test'),('2019-02-09 23:59:59','2019-02-10 03:59:59','THETABNB','4h','0.008890000000000','0.008760000000000','0.737230587657444','0.726449937894174','82.92807510207469','82.928075102074686','test'),('2019-02-10 07:59:59','2019-02-12 03:59:59','THETABNB','4h','0.009460000000000','0.008710000000000','0.737230587657444','0.678782073836822','77.93135176082917','77.931351760829173','test'),('2019-02-13 03:59:59','2019-02-16 07:59:59','THETABNB','4h','0.009430000000000','0.009630000000000','0.737230587657444','0.752866443175099','78.17927758827615','78.179277588276150','test'),('2019-02-25 07:59:59','2019-03-01 23:59:59','THETABNB','4h','0.010710000000000','0.012410000000000','0.737230587657444','0.854251315857038','68.83572247034957','68.835722470349566','test'),('2019-03-10 19:59:59','2019-03-11 15:59:59','THETABNB','4h','0.013930000000000','0.011280000000000','0.737230587657444','0.596982126976021','52.92394742695219','52.923947426952189','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','THETABNB','4h','0.010490000000000','0.011160000000000','0.737230587657444','0.784317765324793','70.2793696527592','70.279369652759200','test'),('2019-04-09 07:59:59','2019-04-11 07:59:59','THETABNB','4h','0.006920000000000','0.006510000000000','0.737230587657444','0.693550740700861','106.53621208922601','106.536212089226012','test'),('2019-04-17 07:59:59','2019-04-18 07:59:59','THETABNB','4h','0.006750000000000','0.006060000000000','0.737230587657444','0.661869238696905','109.21934631962134','109.219346319621337','test'),('2019-05-10 19:59:59','2019-05-11 15:59:59','THETABNB','4h','0.004440000000000','0.004190000000000','0.737230587657444','0.695719856370426','166.04292514807295','166.042925148072953','test'),('2019-05-11 19:59:59','2019-05-12 03:59:59','THETABNB','4h','0.004240000000000','0.004280000000000','0.737230587657444','0.744185593201382','173.8751385984538','173.875138598453788','test'),('2019-05-15 23:59:59','2019-05-16 07:59:59','THETABNB','4h','0.004390000000000','0.004330000000000','0.737230587657444','0.727154543179210','167.934074637231','167.934074637230992','test'),('2019-05-16 15:59:59','2019-05-16 23:59:59','THETABNB','4h','0.004440000000000','0.004290000000000','0.737230587657444','0.712324148885233','166.04292514807295','166.042925148072953','test'),('2019-05-17 15:59:59','2019-05-18 11:59:59','THETABNB','4h','0.004520000000000','0.004320000000000','0.737230587657444','0.704609765194725','163.10411231359382','163.104112313593816','test'),('2019-05-18 19:59:59','2019-05-18 23:59:59','THETABNB','4h','0.004360000000000','0.004120000000000','0.737230587657444','0.696649087419420','169.0895843251018','169.089584325101811','test'),('2019-05-29 03:59:59','2019-05-29 11:59:59','THETABNB','4h','0.004100000000000','0.004630000000000','0.737230587657444','0.832531127037552','179.8123384530351','179.812338453035096','test'),('2019-05-29 19:59:59','2019-05-31 07:59:59','THETABNB','4h','0.004740000000000','0.004090000000000','0.737230587657444','0.636133566143237','155.5338792526253','155.533879252625297','test'),('2019-06-02 11:59:59','2019-06-04 03:59:59','THETABNB','4h','0.004270000000000','0.004200000000000','0.737230587657444','0.725144840318797','172.65353340923744','172.653533409237440','test'),('2019-06-05 03:59:59','2019-06-05 15:59:59','THETABNB','4h','0.004270000000000','0.004140000000000','0.737230587657444','0.714785628314243','172.65353340923744','172.653533409237440','test'),('2019-06-05 19:59:59','2019-06-06 03:59:59','THETABNB','4h','0.004260000000000','0.004330000000000','0.737230587657444','0.749344705295008','173.0588233937662','173.058823393766204','test'),('2019-06-06 19:59:59','2019-06-06 23:59:59','THETABNB','4h','0.004240000000000','0.004180000000000','0.737230587657444','0.726798079341537','173.8751385984538','173.875138598453788','test'),('2019-06-07 07:59:59','2019-06-08 11:59:59','THETABNB','4h','0.004250000000000','0.004200000000000','0.737230587657444','0.728557286626180','173.46602062528092','173.466020625280919','test'),('2019-06-08 19:59:59','2019-06-09 19:59:59','THETABNB','4h','0.004340000000000','0.004290000000000','0.737230587657444','0.728737147707474','169.86879899941104','169.868798999411041','test'),('2019-06-10 03:59:59','2019-06-12 03:59:59','THETABNB','4h','0.004340000000000','0.004260000000000','0.737230587657444','0.723641083737491','169.86879899941104','169.868798999411041','test'),('2019-07-02 03:59:59','2019-07-02 07:59:59','THETABNB','4h','0.003680000000000','0.003510000000000','0.737230587657444','0.703173739858051','200.33439881995758','200.334398819957585','test'),('2019-07-02 11:59:59','2019-07-02 19:59:59','THETABNB','4h','0.003590000000000','0.003610000000000','0.737230587657444','0.741337721850522','205.35670965388414','205.356709653884138','test'),('2019-07-03 07:59:59','2019-07-03 11:59:59','THETABNB','4h','0.003590000000000','0.003550000000000','0.737230587657444','0.729016319271289','205.35670965388414','205.356709653884138','test'),('2019-07-03 15:59:59','2019-07-04 11:59:59','THETABNB','4h','0.003630000000000','0.003480000000000','0.737230587657444','0.706766513787302','203.09382580094876','203.093825800948764','test'),('2019-07-06 19:59:59','2019-07-08 07:59:59','THETABNB','4h','0.003600000000000','0.003490000000000','0.737230587657444','0.714704097479022','204.78627434929','204.786274349290011','test'),('2019-07-09 23:59:59','2019-07-12 03:59:59','THETABNB','4h','0.003710000000000','0.003478000000000','0.737230587657444','0.691128836623340','198.71444411251858','198.714444112518578','test'),('2019-07-13 19:59:59','2019-07-13 23:59:59','THETABNB','4h','0.003739000000000','0.003656000000000','0.737230587657444','0.720865212215998','197.17319808971487','197.173198089714873','test'),('2019-07-16 15:59:59','2019-07-16 19:59:59','THETABNB','4h','0.003750000000000','0.003585000000000','0.737230587657444','0.704792441800516','196.5948233753184','196.594823375318413','test'),('2019-07-16 23:59:59','2019-07-18 15:59:59','THETABNB','4h','0.003658000000000','0.004029000000000','0.737230587657444','0.812001650539049','201.53925305014872','201.539253050148716','test'),('2019-07-18 19:59:59','2019-07-20 11:59:59','THETABNB','4h','0.004111000000000','0.003905000000000','0.737230587657444','0.700288359231895','179.3312059492688','179.331205949268792','test'),('2019-07-22 11:59:59','2019-07-23 23:59:59','THETABNB','4h','0.004150000000000','0.004035000000000','0.737230587657444','0.716801306312720','177.6459247367335','177.645924736733491','test'),('2019-07-24 03:59:59','2019-07-31 11:59:59','THETABNB','4h','0.004090000000000','0.004476000000000','0.737230587657444','0.806807850942474','180.25197742235795','180.251977422357953','test'),('2019-07-31 19:59:59','2019-08-02 11:59:59','THETABNB','4h','0.004649000000000','0.004625000000000','0.737230587657444','0.733424708091133','158.5783152629477','158.578315262947712','test'),('2019-08-18 19:59:59','2019-08-25 23:59:59','THETABNB','4h','0.004275000000000','0.004726000000000','0.737230587657444','0.815006259010311','172.45159945203366','172.451599452033662','test'),('2019-08-27 15:59:59','2019-09-02 11:59:59','THETABNB','4h','0.004867000000000','0.004979000000000','0.737230587657444','0.754195828219933','151.47536216507993','151.475362165079929','test'),('2019-09-04 23:59:59','2019-09-05 19:59:59','THETABNB','4h','0.005224000000000','0.004915000000000','0.737230587657444','0.693623341947997','141.1237725224816','141.123772522481602','test'),('2019-09-05 23:59:59','2019-09-06 07:59:59','THETABNB','4h','0.005099000000000','0.004956000000000','0.737230587657444','0.716555166195390','144.58336686751204','144.583366867512041','test'),('2019-09-11 03:59:59','2019-09-12 23:59:59','THETABNB','4h','0.005070000000000','0.005061000000000','0.737230587657444','0.735921894306573','145.41037231902249','145.410372319022485','test'),('2019-09-15 11:59:59','2019-09-16 07:59:59','THETABNB','4h','0.005104000000000','0.005055000000000','0.737230587657444','0.730152942909165','144.44172955670925','144.441729556709248','test'),('2019-09-16 11:59:59','2019-09-17 11:59:59','THETABNB','4h','0.005231000000000','0.004982000000000','0.737230587657444','0.702137791571284','140.93492404080365','140.934924040803651','test'),('2019-09-19 11:59:59','2019-09-19 23:59:59','THETABNB','4h','0.005253000000000','0.005054000000000','0.737230587657444','0.709301996958066','140.34467688129527','140.344676881295271','test'),('2019-09-20 03:59:59','2019-09-20 11:59:59','THETABNB','4h','0.005114000000000','0.005044000000000','0.737230587657444','0.727139437650400','144.15928581490888','144.159285814908884','test'),('2019-09-20 15:59:59','2019-09-21 07:59:59','THETABNB','4h','0.005071000000000','0.005128000000000','0.737230587657444','0.745517344410840','145.38169742801105','145.381697428011051','test'),('2019-09-21 15:59:59','2019-09-21 19:59:59','THETABNB','4h','0.005126000000000','0.005144000000000','0.737230587657444','0.739819380200915','143.82180797062892','143.821807970628925','test'),('2019-09-22 03:59:59','2019-09-22 07:59:59','THETABNB','4h','0.005131000000000','0.005015000000000','0.737230587657444','0.720563515319057','143.68165808954276','143.681658089542765','test'),('2019-09-23 03:59:59','2019-09-23 07:59:59','THETABNB','4h','0.005147000000000','0.005122000000000','0.737230587657444','0.733649712450248','143.2350082878267','143.235008287826702','test'),('2019-09-23 15:59:59','2019-09-24 19:59:59','THETABNB','4h','0.005270000000000','0.005059000000000','0.737230587657444','0.707713385760723','139.89195211716205','139.891952117162049','test'),('2019-09-24 23:59:59','2019-09-25 19:59:59','THETABNB','4h','0.005205000000000','0.005134000000000','0.737230587657444','0.727174224213894','141.63892174014293','141.638921740142933','test'),('2019-09-25 23:59:59','2019-09-29 03:59:59','THETABNB','4h','0.005209000000000','0.005297000000000','0.737230587657444','0.749685241470816','141.53015697013706','141.530156970137057','test'),('2019-10-03 19:59:59','2019-10-04 19:59:59','THETABNB','4h','0.005409000000000','0.005269000000000','0.737230587657444','0.718149004689790','136.2970211975308','136.297021197530796','test'),('2019-10-04 23:59:59','2019-10-07 07:59:59','THETABNB','4h','0.005331000000000','0.005276000000000','0.737230587657444','0.729624569589322','138.2912376022217','138.291237602221713','test'),('2019-10-08 15:59:59','2019-10-09 07:59:59','THETABNB','4h','0.005556000000000','0.005340000000000','0.491487058438296','0.472379570205274','88.46059367139956','88.460593671399565','test'),('2019-10-23 07:59:59','2019-10-25 15:59:59','THETABNB','4h','0.005300000000000','0.005200000000000','0.546633652512080','0.536319810011852','103.1384250022793','103.138425002279305','test'),('2019-10-25 19:59:59','2019-10-25 23:59:59','THETABNB','4h','0.005389000000000','0.005228000000000','0.546633652512080','0.530302604441112','101.43508118613472','101.435081186134724','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:41:10
