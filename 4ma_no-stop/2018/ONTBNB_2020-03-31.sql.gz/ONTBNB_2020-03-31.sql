-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-25 19:59:59','2018-08-29 15:59:59','ONTBNB','4h','0.235500000000000','0.232060000000000','0.711908500000000','0.701509496857750','3.022966029723992','3.022966029723992','test'),('2018-09-22 11:59:59','2018-09-24 11:59:59','ONTBNB','4h','0.203410000000000','0.192100000000000','0.711908500000000','0.672324973452633','3.4998697212526424','3.499869721252642','test'),('2018-09-28 07:59:59','2018-10-01 23:59:59','ONTBNB','4h','0.197030000000000','0.198450000000000','0.711908500000000','0.717039241866721','3.613198497690707','3.613198497690707','test'),('2018-10-02 03:59:59','2018-10-02 19:59:59','ONTBNB','4h','0.201600000000000','0.197100000000000','0.711908500000000','0.696017685267857','3.531292162698413','3.531292162698413','test'),('2018-10-09 07:59:59','2018-10-11 03:59:59','ONTBNB','4h','0.198660000000000','0.192340000000000','0.711908500000000','0.689260449461391','3.583552300412766','3.583552300412766','test'),('2018-10-21 15:59:59','2018-10-21 19:59:59','ONTBNB','4h','0.188500000000000','0.188250000000000','0.711908500000000','0.710964324270557','3.7767029177718836','3.776702917771884','test'),('2018-10-22 03:59:59','2018-10-22 07:59:59','ONTBNB','4h','0.186720000000000','0.186140000000000','0.711908500000000','0.709697130409169','3.8127061910882607','3.812706191088261','test'),('2018-11-17 19:59:59','2018-11-18 03:59:59','ONTBNB','4h','0.172650000000000','0.172300000000000','0.711908500000000','0.710465302924993','4.1234202143064005','4.123420214306400','test'),('2018-11-24 03:59:59','2018-11-25 11:59:59','ONTBNB','4h','0.178390000000000','0.171070000000000','0.711908500000000','0.682696267139414','3.990742194069175','3.990742194069175','test'),('2018-12-19 11:59:59','2018-12-19 23:59:59','ONTBNB','4h','0.122530000000000','0.113100000000000','0.711908500000000','0.657119491961152','5.8100750836529835','5.810075083652984','test'),('2018-12-20 03:59:59','2018-12-20 07:59:59','ONTBNB','4h','0.113350000000000','0.112100000000000','0.711908500000000','0.704057722540803','6.2806219673577415','6.280621967357741','test'),('2018-12-20 11:59:59','2018-12-20 15:59:59','ONTBNB','4h','0.115630000000000','0.114590000000000','0.711908500000000','0.705505448542766','6.156780247340656','6.156780247340656','test'),('2018-12-20 19:59:59','2018-12-24 07:59:59','ONTBNB','4h','0.115490000000000','0.121710000000000','0.711908500000000','0.750250095549398','6.164243657459521','6.164243657459521','test'),('2018-12-24 19:59:59','2018-12-25 03:59:59','ONTBNB','4h','0.126760000000000','0.115500000000000','0.711908500000000','0.648670177895235','5.616192016408962','5.616192016408962','test'),('2019-01-12 03:59:59','2019-01-12 07:59:59','ONTBNB','4h','0.106450000000000','0.103500000000000','0.711908500000000','0.692179706434946','6.6877266322217','6.687726632221700','test'),('2019-01-12 19:59:59','2019-01-13 03:59:59','ONTBNB','4h','0.104520000000000','0.104160000000000','0.711908500000000','0.709456461538462','6.811217948717949','6.811217948717949','test'),('2019-01-13 11:59:59','2019-01-13 15:59:59','ONTBNB','4h','0.102140000000000','0.100850000000000','0.711908500000000','0.702917292196985','6.969928529469357','6.969928529469357','test'),('2019-02-16 15:59:59','2019-02-18 03:59:59','ONTBNB','4h','0.070850000000000','0.068780000000000','0.711908500000000','0.691108915031757','10.048108680310516','10.048108680310516','test'),('2019-02-18 23:59:59','2019-02-19 15:59:59','ONTBNB','4h','0.070270000000000','0.066440000000000','0.711908500000000','0.673106599402305','10.13104454247901','10.131044542479010','test'),('2019-02-21 19:59:59','2019-02-27 07:59:59','ONTBNB','4h','0.069720000000000','0.092530000000000','0.711908500000000','0.944820618258749','10.21096528973035','10.210965289730350','test'),('2019-03-17 23:59:59','2019-03-18 11:59:59','ONTBNB','4h','0.071730000000000','0.069590000000000','0.711908500000000','0.690669350550676','9.92483619127283','9.924836191272830','test'),('2019-03-18 15:59:59','2019-03-19 11:59:59','ONTBNB','4h','0.070340000000000','0.069100000000000','0.711908500000000','0.699358506539664','10.120962468012511','10.120962468012511','test'),('2019-03-19 15:59:59','2019-03-23 23:59:59','ONTBNB','4h','0.071680000000000','0.083170000000000','0.711908500000000','0.826024413295201','9.931759207589288','9.931759207589288','test'),('2019-03-30 19:59:59','2019-03-31 03:59:59','ONTBNB','4h','0.078350000000000','0.074010000000000','0.714739542847146','0.675148354385670','9.122393654717877','9.122393654717877','test'),('2019-04-01 03:59:59','2019-04-01 07:59:59','ONTBNB','4h','0.078370000000000','0.076280000000000','0.714739542847146','0.695678605695806','9.120065622650836','9.120065622650836','test'),('2019-04-03 19:59:59','2019-04-07 11:59:59','ONTBNB','4h','0.085750000000000','0.081580000000000','0.714739542847146','0.679981946419477','8.33515501862561','8.335155018625610','test'),('2019-04-08 23:59:59','2019-04-09 11:59:59','ONTBNB','4h','0.083590000000000','0.079590000000000','0.714739542847146','0.680537387429170','8.550538854493912','8.550538854493912','test'),('2019-04-10 11:59:59','2019-04-11 03:59:59','ONTBNB','4h','0.082420000000000','0.078860000000000','0.714739542847146','0.683867512119946','8.67191874359556','8.671918743595560','test'),('2019-05-08 11:59:59','2019-05-08 19:59:59','ONTBNB','4h','0.051940000000000','0.049250000000000','0.714739542847146','0.677722804875278','13.760869134523412','13.760869134523412','test'),('2019-05-08 23:59:59','2019-05-13 07:59:59','ONTBNB','4h','0.050820000000000','0.052470000000000','0.714739542847146','0.737945372160365','14.064138977708502','14.064138977708502','test'),('2019-05-14 11:59:59','2019-05-15 15:59:59','ONTBNB','4h','0.056450000000000','0.056260000000000','0.714739542847146','0.712333865023568','12.661462229355998','12.661462229355998','test'),('2019-05-15 19:59:59','2019-05-16 11:59:59','ONTBNB','4h','0.058960000000000','0.055580000000000','0.714739542847146','0.673765668104552','12.122448148696506','12.122448148696506','test'),('2019-05-16 15:59:59','2019-05-16 23:59:59','ONTBNB','4h','0.058600000000000','0.054810000000000','0.714739542847146','0.668513214052083','12.19692052640181','12.196920526401810','test'),('2019-05-30 07:59:59','2019-06-01 07:59:59','ONTBNB','4h','0.046000000000000','0.045180000000000','0.714739542847146','0.701998533605088','15.537816148851','15.537816148851000','test'),('2019-06-01 11:59:59','2019-06-01 15:59:59','ONTBNB','4h','0.045200000000000','0.044520000000000','0.714739542847146','0.703986824060950','15.812821744405886','15.812821744405886','test'),('2019-06-03 03:59:59','2019-06-03 07:59:59','ONTBNB','4h','0.045880000000000','0.045050000000000','0.714739542847146','0.701809424700609','15.578455598237708','15.578455598237708','test'),('2019-06-10 15:59:59','2019-06-11 07:59:59','ONTBNB','4h','0.045330000000000','0.044010000000000','0.714739542847146','0.693926478727176','15.767472818158968','15.767472818158968','test'),('2019-06-11 11:59:59','2019-06-12 03:59:59','ONTBNB','4h','0.044530000000000','0.042850000000000','0.714739542847146','0.687774296227267','16.050742035642173','16.050742035642173','test'),('2019-06-15 23:59:59','2019-06-17 07:59:59','ONTBNB','4h','0.044000000000000','0.043060000000000','0.714739542847146','0.699470107159048','16.24408051925332','16.244080519253320','test'),('2019-06-17 11:59:59','2019-06-17 15:59:59','ONTBNB','4h','0.044570000000000','0.044210000000000','0.714739542847146','0.708966461504876','16.03633706186103','16.036337061861030','test'),('2019-06-17 19:59:59','2019-06-18 03:59:59','ONTBNB','4h','0.044490000000000','0.043650000000000','0.714739542847146','0.701244797601212','16.065172911826163','16.065172911826163','test'),('2019-06-25 03:59:59','2019-06-27 11:59:59','ONTBNB','4h','0.043870000000000','0.046120000000000','0.714739542847146','0.751397030228183','16.292216613794075','16.292216613794075','test'),('2019-06-30 07:59:59','2019-07-01 11:59:59','ONTBNB','4h','0.046680000000000','0.043830000000000','0.714739542847146','0.671101845822417','15.311472640255914','15.311472640255914','test'),('2019-07-25 11:59:59','2019-07-27 23:59:59','ONTBNB','4h','0.035410000000000','0.035140000000000','0.714739542847146','0.709289679063787','20.184680679106073','20.184680679106073','test'),('2019-07-29 11:59:59','2019-07-31 03:59:59','ONTBNB','4h','0.036240000000000','0.035400000000000','0.714739542847146','0.698172732251351','19.72239356642235','19.722393566422351','test'),('2019-07-31 11:59:59','2019-08-01 03:59:59','ONTBNB','4h','0.036200000000000','0.035490000000000','0.714739542847146','0.700721170597934','19.744186266495745','19.744186266495745','test'),('2019-08-04 07:59:59','2019-08-04 11:59:59','ONTBNB','4h','0.035360000000000','0.035140000000000','0.714739542847146','0.710292633926717','20.213222365586706','20.213222365586706','test'),('2019-08-04 15:59:59','2019-08-04 19:59:59','ONTBNB','4h','0.035350000000000','0.035290000000000','0.714739542847146','0.713526406423643','20.218940391715588','20.218940391715588','test'),('2019-08-05 03:59:59','2019-08-05 07:59:59','ONTBNB','4h','0.035290000000000','0.035220000000000','0.714739542847146','0.713321810685080','20.253316600939247','20.253316600939247','test'),('2019-08-05 11:59:59','2019-08-06 03:59:59','ONTBNB','4h','0.035550000000000','0.035410000000000','0.714739542847146','0.711924816096130','20.105191078682026','20.105191078682026','test'),('2019-08-06 15:59:59','2019-08-06 19:59:59','ONTBNB','4h','0.035300000000000','0.035030000000000','0.714739542847146','0.709272696485426','20.247579117482893','20.247579117482893','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31 10:01:41
