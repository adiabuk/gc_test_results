-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-05 07:59:59','2019-01-08 11:59:59','ARDRBNB','4h','0.009880000000000','0.009510000000000','0.711908500000000','0.685247959008097','72.05551619433199','72.055516194331986','test'),('2019-01-31 07:59:59','2019-01-31 15:59:59','ARDRBNB','4h','0.008520000000000','0.008390000000000','0.711908500000000','0.701046046361502','83.55733568075118','83.557335680751180','test'),('2019-02-27 03:59:59','2019-02-27 15:59:59','ARDRBNB','4h','0.006060000000000','0.005700000000000','0.711908500000000','0.669616905940594','117.47665016501651','117.476650165016508','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','ARDRBNB','4h','0.005730000000000','0.005780000000000','0.711908500000000','0.718120616055847','124.24232111692847','124.242321116928466','test'),('2019-03-20 15:59:59','2019-03-23 11:59:59','ARDRBNB','4h','0.004610000000000','0.004640000000000','0.711908500000000','0.716541310195228','154.42700650759218','154.427006507592182','test'),('2019-03-27 03:59:59','2019-03-30 07:59:59','ARDRBNB','4h','0.004710000000000','0.004720000000000','0.711908500000000','0.713419983014862','151.14830148619959','151.148301486199585','test'),('2019-04-07 03:59:59','2019-04-07 07:59:59','ARDRBNB','4h','0.004690000000000','0.004680000000000','0.711908500000000','0.710390571428572','151.79285714285717','151.792857142857173','test'),('2019-04-07 15:59:59','2019-04-08 15:59:59','ARDRBNB','4h','0.004730000000000','0.004810000000000','0.711908500000000','0.723949235729387','150.50919661733616','150.509196617336158','test'),('2019-04-08 23:59:59','2019-04-09 11:59:59','ARDRBNB','4h','0.004880000000000','0.004670000000000','0.711908500000000','0.681273093237705','145.8828893442623','145.882889344262310','test'),('2019-05-07 19:59:59','2019-05-13 03:59:59','ARDRBNB','4h','0.003250000000000','0.003360000000000','0.711908500000000','0.736003864615385','219.04876923076927','219.048769230769267','test'),('2019-06-02 15:59:59','2019-06-05 15:59:59','ARDRBNB','4h','0.002770000000000','0.002650000000000','0.711908500000000','0.681067698555957','257.006678700361','257.006678700361022','test'),('2019-06-07 07:59:59','2019-06-09 19:59:59','ARDRBNB','4h','0.003740000000000','0.003170000000000','0.711908500000000','0.603409076203209','190.34986631016045','190.349866310160451','test'),('2019-06-14 23:59:59','2019-06-15 07:59:59','ARDRBNB','4h','0.003200000000000','0.003050000000000','0.711908500000000','0.678537789062500','222.47140625','222.471406250000001','test'),('2019-06-15 15:59:59','2019-06-16 07:59:59','ARDRBNB','4h','0.003130000000000','0.003120000000000','0.711908500000000','0.709634031948882','227.4468051118211','227.446805111821106','test'),('2019-06-16 11:59:59','2019-06-17 15:59:59','ARDRBNB','4h','0.003140000000000','0.003070000000000','0.711908500000000','0.696037928343949','226.7224522292994','226.722452229299392','test'),('2019-06-17 19:59:59','2019-06-17 23:59:59','ARDRBNB','4h','0.003090000000000','0.003150000000000','0.711908500000000','0.725731966019417','230.3911003236246','230.391100323624613','test'),('2019-06-18 23:59:59','2019-06-20 11:59:59','ARDRBNB','4h','0.003190000000000','0.003250000000000','0.711908500000000','0.725298628526646','223.16880877742946','223.168808777429462','test'),('2019-06-20 15:59:59','2019-06-20 19:59:59','ARDRBNB','4h','0.003320000000000','0.003270000000000','0.711908500000000','0.701186986445783','214.43027108433736','214.430271084337363','test'),('2019-06-25 15:59:59','2019-06-26 07:59:59','ARDRBNB','4h','0.003320000000000','0.003240000000000','0.711908500000000','0.694754078313253','214.43027108433736','214.430271084337363','test'),('2019-06-26 11:59:59','2019-06-27 11:59:59','ARDRBNB','4h','0.003370000000000','0.003230000000000','0.711908500000000','0.682333666172107','211.24881305637982','211.248813056379817','test'),('2019-06-28 19:59:59','2019-06-29 19:59:59','ARDRBNB','4h','0.003450000000000','0.003290000000000','0.711908500000000','0.678892453623188','206.35028985507248','206.350289855072475','test'),('2019-06-29 23:59:59','2019-07-01 11:59:59','ARDRBNB','4h','0.003350000000000','0.003370000000000','0.711908500000000','0.716158700000000','212.51000000000002','212.510000000000019','test'),('2019-07-02 19:59:59','2019-07-04 11:59:59','ARDRBNB','4h','0.003680000000000','0.003350000000000','0.711908500000000','0.648068879076087','193.45339673913045','193.453396739130454','test'),('2019-07-04 15:59:59','2019-07-04 19:59:59','ARDRBNB','4h','0.003440000000000','0.003420000000000','0.711908500000000','0.707769497093023','206.95014534883722','206.950145348837225','test'),('2019-07-26 23:59:59','2019-07-31 07:59:59','ARDRBNB','4h','0.002427000000000','0.002505000000000','0.711908500000000','0.734788130407911','293.328594973218','293.328594973218003','test'),('2019-08-04 19:59:59','2019-08-05 07:59:59','ARDRBNB','4h','0.002652000000000','0.002444000000000','0.711908500000000','0.656072539215686','268.4421191553545','268.442119155354476','test'),('2019-08-22 07:59:59','2019-08-27 23:59:59','ARDRBNB','4h','0.002083000000000','0.002427000000000','0.711908500000000','0.829477642582813','341.77076332213153','341.770763322131529','test'),('2019-08-31 07:59:59','2019-09-03 07:59:59','ARDRBNB','4h','0.002446000000000','0.002458000000000','0.711908500000000','0.715401100981194','291.0500817661489','291.050081766148878','test'),('2019-09-03 19:59:59','2019-09-05 19:59:59','ARDRBNB','4h','0.002610000000000','0.002510000000000','0.711908500000000','0.684632312260537','272.76187739463603','272.761877394636031','test'),('2019-09-08 19:59:59','2019-09-10 23:59:59','ARDRBNB','4h','0.002629000000000','0.002729000000000','0.711908500000000','0.738987560479270','270.79060479269685','270.790604792696854','test'),('2019-09-11 07:59:59','2019-09-11 15:59:59','ARDRBNB','4h','0.002703000000000','0.002657000000000','0.711908500000000','0.699793150018498','263.3771735109138','263.377173510913792','test'),('2019-09-12 07:59:59','2019-09-12 23:59:59','ARDRBNB','4h','0.002760000000000','0.002659000000000','0.711908500000000','0.685856775905797','257.9378623188406','257.937862318840587','test'),('2019-09-14 07:59:59','2019-09-14 19:59:59','ARDRBNB','4h','0.002741000000000','0.002675000000000','0.711908500000000','0.694766595220722','259.7258299890551','259.725829989055114','test'),('2019-09-14 23:59:59','2019-09-15 11:59:59','ARDRBNB','4h','0.002720000000000','0.002675000000000','0.711908500000000','0.700130602022059','261.73106617647056','261.731066176470563','test'),('2019-09-15 15:59:59','2019-09-18 03:59:59','ARDRBNB','4h','0.002766000000000','0.002769000000000','0.711908500000000','0.712680635032538','257.3783441793204','257.378344179320379','test'),('2019-09-20 07:59:59','2019-09-29 23:59:59','ARDRBNB','4h','0.002868000000000','0.003364000000000','0.711908500000000','0.835027961645746','248.22472105997213','248.224721059972126','test'),('2019-09-30 03:59:59','2019-09-30 11:59:59','ARDRBNB','4h','0.003437000000000','0.003357000000000','0.711908500000000','0.695338037387256','207.1307826592959','207.130782659295903','test'),('2019-10-02 11:59:59','2019-10-07 11:59:59','ARDRBNB','4h','0.003476000000000','0.003584000000000','0.711908500000000','0.734027636363636','204.80681818181822','204.806818181818215','test'),('2019-10-07 15:59:59','2019-10-07 23:59:59','ARDRBNB','4h','0.003675000000000','0.003622000000000','0.711908500000000','0.701641520272109','193.7165986394558','193.716598639455810','test'),('2019-10-08 23:59:59','2019-10-09 07:59:59','ARDRBNB','4h','0.003746000000000','0.003521000000000','0.711908500000000','0.669148379204485','190.04498131340097','190.044981313400967','test'),('2019-11-03 23:59:59','2019-11-04 03:59:59','ARDRBNB','4h','0.002848000000000','0.002752000000000','0.711908500000000','0.687911584269663','249.96787219101128','249.967872191011281','test'),('2019-11-04 07:59:59','2019-11-04 15:59:59','ARDRBNB','4h','0.002764000000000','0.002748000000000','0.711908500000000','0.707787466714906','257.56458031837917','257.564580318379171','test'),('2019-11-04 19:59:59','2019-11-04 23:59:59','ARDRBNB','4h','0.002800000000000','0.002753000000000','0.711908500000000','0.699958607321429','254.25303571428574','254.253035714285744','test'),('2019-11-18 07:59:59','2019-11-19 07:59:59','ARDRBNB','4h','0.002703000000000','0.002703000000000','0.711908500000000','0.711908500000000','263.3771735109138','263.377173510913792','test'),('2019-11-19 11:59:59','2019-11-24 07:59:59','ARDRBNB','4h','0.002720000000000','0.002800000000000','0.711908500000000','0.732846985294118','261.73106617647056','261.731066176470563','test'),('2019-11-24 23:59:59','2019-12-03 03:59:59','ARDRBNB','4h','0.002880000000000','0.003273000000000','0.711908500000000','0.809054347395833','247.1904513888889','247.190451388888903','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:32:09
