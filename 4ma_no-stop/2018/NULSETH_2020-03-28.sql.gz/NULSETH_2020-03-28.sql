-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-27 03:59:59','2018-05-02 07:59:59','NULSETH','4h','0.004659610000000','0.005609710000000','0.072144500000000','0.086854849031357','15.482948143728768','15.482948143728768','test'),('2018-05-02 23:59:59','2018-05-03 03:59:59','NULSETH','4h','0.005815210000000','0.005577320000000','0.075822087257839','0.072720339197534','13.038581110198814','13.038581110198814','test'),('2018-05-10 07:59:59','2018-05-16 07:59:59','NULSETH','4h','0.005399990000000','0.006312400000000','0.075822087257839','0.088633375914841','14.041153272105873','14.041153272105873','test'),('2018-05-22 23:59:59','2018-05-23 11:59:59','NULSETH','4h','0.006429990000000','0.006293710000000','0.078249472407013','0.076591019112431','12.16945475918524','12.169454759185239','test'),('2018-05-23 19:59:59','2018-05-23 23:59:59','NULSETH','4h','0.006167180000000','0.006282800000000','0.078249472407013','0.079716464451951','12.688047439350399','12.688047439350399','test'),('2018-05-24 03:59:59','2018-05-24 07:59:59','NULSETH','4h','0.006291570000000','0.006095000000000','0.078249472407013','0.075804693315141','12.43719332487964','12.437193324879640','test'),('2018-05-25 19:59:59','2018-05-25 23:59:59','NULSETH','4h','0.006410340000000','0.006390410000000','0.078249472407013','0.078006191709722','12.206758519362936','12.206758519362936','test'),('2018-05-26 07:59:59','2018-05-27 03:59:59','NULSETH','4h','0.006331540000000','0.006264930000000','0.078249472407013','0.077426260778084','12.358679311354424','12.358679311354424','test'),('2018-05-27 07:59:59','2018-05-28 07:59:59','NULSETH','4h','0.006416650000000','0.006388300000000','0.078249472407013','0.077903751112765','12.1947546472089','12.194754647208899','test'),('2018-05-29 15:59:59','2018-05-29 19:59:59','NULSETH','4h','0.006532080000000','0.006382940000000','0.078249472407013','0.076462885850391','11.979258124060483','11.979258124060483','test'),('2018-05-30 03:59:59','2018-06-02 07:59:59','NULSETH','4h','0.006450390000000','0.006819000000000','0.078249472407013','0.082721068391744','12.130967648004694','12.130967648004694','test'),('2018-06-02 11:59:59','2018-06-02 15:59:59','NULSETH','4h','0.006899460000000','0.006792030000000','0.078249472407013','0.077031066789662','11.341390834501976','11.341390834501976','test'),('2018-07-02 03:59:59','2018-07-05 15:59:59','NULSETH','4h','0.004824600000000','0.004900000000000','0.078249472407013','0.079472373832932','16.218851802639183','16.218851802639183','test'),('2018-07-08 11:59:59','2018-07-11 07:59:59','NULSETH','4h','0.005000000000000','0.005129930000000','0.078249472407013','0.080282863196982','15.649894481402598','15.649894481402598','test'),('2018-07-11 11:59:59','2018-07-14 11:59:59','NULSETH','4h','0.005620120000000','0.005669330000000','0.078418082923179','0.079104714856421','13.953097607022451','13.953097607022451','test'),('2018-07-18 11:59:59','2018-07-18 19:59:59','NULSETH','4h','0.005820000000000','0.005565990000000','0.078589740906490','0.075159744327855','13.503391908331531','13.503391908331531','test'),('2018-07-29 03:59:59','2018-07-29 07:59:59','NULSETH','4h','0.005500820000000','0.005387870000000','0.078589740906490','0.076976033998177','14.286913752220578','14.286913752220578','test'),('2018-07-29 11:59:59','2018-07-29 15:59:59','NULSETH','4h','0.005417980000000','0.005433730000000','0.078589740906490','0.078818200298972','14.505358252797167','14.505358252797167','test'),('2018-07-29 19:59:59','2018-07-30 11:59:59','NULSETH','4h','0.005628920000000','0.005413750000000','0.078589740906490','0.075585584771592','13.961779685355273','13.961779685355273','test'),('2018-08-13 03:59:59','2018-08-15 15:59:59','NULSETH','4h','0.005248910000000','0.004680000000000','0.078589740906490','0.070071688682483','14.972583051812663','14.972583051812663','test'),('2018-08-16 15:59:59','2018-08-18 15:59:59','NULSETH','4h','0.005000010000000','0.004916620000000','0.078589740906490','0.077279023829086','15.717916745464509','15.717916745464509','test'),('2018-08-22 07:59:59','2018-08-22 19:59:59','NULSETH','4h','0.005500000000000','0.004991930000000','0.078589740906490','0.071329906422424','14.28904380118','14.289043801180000','test'),('2018-08-22 23:59:59','2018-08-29 15:59:59','NULSETH','4h','0.005174840000000','0.005497290000000','0.078589740906490','0.083486754525326','15.186892910020406','15.186892910020406','test'),('2018-08-30 11:59:59','2018-09-02 07:59:59','NULSETH','4h','0.006640380000000','0.006150000000000','0.078589740906490','0.072786031307683','11.83512704189971','11.835127041899710','test'),('2018-09-04 15:59:59','2018-09-05 11:59:59','NULSETH','4h','0.006270000000000','0.005981880000000','0.078589740906490','0.074978373099476','12.534248948403508','12.534248948403508','test'),('2018-09-05 15:59:59','2018-09-05 19:59:59','NULSETH','4h','0.006150100000000','0.006146140000000','0.078589740906490','0.078539137603456','12.778611877284922','12.778611877284922','test'),('2018-09-08 03:59:59','2018-09-08 07:59:59','NULSETH','4h','0.006149390000000','0.006203920000000','0.078589740906490','0.079286639065760','12.78008727800481','12.780087278004810','test'),('2018-09-08 15:59:59','2018-09-10 19:59:59','NULSETH','4h','0.006149940000000','0.006185640000000','0.078589740906490','0.079045949219150','12.778944332219503','12.778944332219503','test'),('2018-09-11 03:59:59','2018-09-12 07:59:59','NULSETH','4h','0.006340300000000','0.006331030000000','0.078589740906490','0.078474836738201','12.395271660093371','12.395271660093371','test'),('2018-09-12 15:59:59','2018-09-13 03:59:59','NULSETH','4h','0.006501890000000','0.006220660000000','0.078589740906490','0.075190453493887','12.087214780085484','12.087214780085484','test'),('2018-09-29 15:59:59','2018-09-29 19:59:59','NULSETH','4h','0.005294520000000','0.005195520000000','0.078589740906490','0.077120224434790','14.843600724237515','14.843600724237515','test'),('2018-10-04 23:59:59','2018-10-05 07:59:59','NULSETH','4h','0.005349240000000','0.005291550000000','0.078589740906490','0.077742173372991','14.691758250983318','14.691758250983318','test'),('2018-10-05 15:59:59','2018-10-05 23:59:59','NULSETH','4h','0.005291980000000','0.005238800000000','0.078589740906490','0.077799979338720','14.850725230724606','14.850725230724606','test'),('2018-10-07 23:59:59','2018-10-08 03:59:59','NULSETH','4h','0.005293110000000','0.005234310000000','0.078589740906490','0.077716704682927','14.84755482249377','14.847554822493770','test'),('2018-10-08 07:59:59','2018-10-08 19:59:59','NULSETH','4h','0.005250000000000','0.005260000000000','0.078589740906490','0.078739435651074','14.969474458379047','14.969474458379047','test'),('2018-10-08 23:59:59','2018-10-10 07:59:59','NULSETH','4h','0.005331860000000','0.005429400000000','0.078589740906490','0.080027446196580','14.739648247795328','14.739648247795328','test'),('2018-10-10 11:59:59','2018-10-12 19:59:59','NULSETH','4h','0.005568560000000','0.005545940000000','0.078589740906490','0.078270502191399','14.113117378009754','14.113117378009754','test'),('2018-10-13 15:59:59','2018-10-13 19:59:59','NULSETH','4h','0.005635800000000','0.005525440000000','0.078589740906490','0.077050799885439','13.94473560213102','13.944735602131020','test'),('2018-10-14 11:59:59','2018-10-15 07:59:59','NULSETH','4h','0.005608920000000','0.005330230000000','0.078589740906490','0.074684858167348','14.011563885113356','14.011563885113356','test'),('2018-10-18 11:59:59','2018-10-18 23:59:59','NULSETH','4h','0.005642450000000','0.005505400000000','0.078589740906490','0.076680867280453','13.928300810195925','13.928300810195925','test'),('2018-10-19 03:59:59','2018-10-19 05:59:59','NULSETH','4h','0.005531170000000','0.005536660000000','0.078589740906490','0.078667745682618','14.208520241918075','14.208520241918075','test'),('2018-10-19 15:59:59','2018-10-20 11:59:59','NULSETH','4h','0.005532300000000','0.005492440000000','0.078589740906490','0.078023504969803','14.205618080452975','14.205618080452975','test'),('2018-10-21 07:59:59','2018-10-21 15:59:59','NULSETH','4h','0.005559350000000','0.005529800000000','0.078589740906490','0.078172007386602','14.136498134942034','14.136498134942034','test'),('2018-10-21 23:59:59','2018-10-22 03:59:59','NULSETH','4h','0.005556770000000','0.005492440000000','0.078589740906490','0.077679917747980','14.143061689882792','14.143061689882792','test'),('2018-10-23 03:59:59','2018-10-25 07:59:59','NULSETH','4h','0.005643370000000','0.005643360000000','0.078589740906490','0.078589601646188','13.926030174610206','13.926030174610206','test'),('2018-10-25 19:59:59','2018-10-26 03:59:59','NULSETH','4h','0.005688080000000','0.005607060000000','0.078589740906490','0.077470322612752','13.81656743690138','13.816567436901380','test'),('2018-11-01 19:59:59','2018-11-03 03:59:59','NULSETH','4h','0.005853000000000','0.005643300000000','0.078589740906490','0.075774044909892','13.42725797138049','13.427257971380490','test'),('2018-11-03 11:59:59','2018-11-03 19:59:59','NULSETH','4h','0.005615670000000','0.005548970000000','0.078589740906490','0.077656292944188','13.99472207349969','13.994722073499689','test'),('2018-11-29 15:59:59','2018-11-30 11:59:59','NULSETH','4h','0.004578300000000','0.004409990000000','0.078589740906490','0.075700581329361','17.16570362503331','17.165703625033309','test'),('2018-12-01 07:59:59','2018-12-01 11:59:59','NULSETH','4h','0.004488580000000','0.004336420000000','0.078589740906490','0.075925598800004','17.508820363342082','17.508820363342082','test'),('2018-12-01 23:59:59','2018-12-02 15:59:59','NULSETH','4h','0.004473860000000','0.004450450000000','0.078589740906490','0.078178510820028','17.566428298268164','17.566428298268164','test'),('2018-12-02 19:59:59','2018-12-06 15:59:59','NULSETH','4h','0.004496890000000','0.004410800000000','0.078589740906490','0.077085192030569','17.476465047286013','17.476465047286013','test'),('2018-12-12 15:59:59','2018-12-16 07:59:59','NULSETH','4h','0.004607340000000','0.004608400000000','0.078589740906490','0.078607821865430','17.057508433605943','17.057508433605943','test'),('2019-01-11 15:59:59','2019-01-14 15:59:59','NULSETH','4h','0.003000000000000','0.003000090000000','0.078589740906490','0.078592098598717','26.196580302163333','26.196580302163333','test'),('2019-01-16 03:59:59','2019-01-27 19:59:59','NULSETH','4h','0.003154800000000','0.003830070000000','0.078589740906490','0.095411502774731','24.911164227998604','24.911164227998604','test'),('2019-03-01 11:59:59','2019-03-05 19:59:59','NULSETH','4h','0.003136450000000','0.003205520000000','0.078589740906490','0.080320421581907','25.05690857705049','25.056908577050489','test'),('2019-03-08 19:59:59','2019-03-12 01:59:59','NULSETH','4h','0.003252310000000','0.003588710000000','0.078589740906490','0.086718605879676','24.16428351125508','24.164283511255078','test'),('2019-03-12 11:59:59','2019-03-19 23:59:59','NULSETH','4h','0.003937400000000','0.004111970000000','0.078589740906490','0.082074124273698','19.959806193551582','19.959806193551582','test'),('2019-03-20 03:59:59','2019-03-21 15:59:59','NULSETH','4h','0.004221720000000','0.004101030000000','0.078589740906490','0.076343027285027','18.61557396191363','18.615573961913629','test'),('2019-03-22 07:59:59','2019-03-25 03:59:59','NULSETH','4h','0.004933570000000','0.004626920000000','0.078589740906490','0.073704932532640','15.929588696722657','15.929588696722657','test'),('2019-03-27 03:59:59','2019-04-03 11:59:59','NULSETH','4h','0.004775000000000','0.005877900000000','0.078589740906490','0.096741913732829','16.458584483034556','16.458584483034556','test'),('2019-04-17 03:59:59','2019-04-17 11:59:59','NULSETH','4h','0.005312600000000','0.005192210000000','0.078589740906490','0.076808801459189','14.793084536100968','14.793084536100968','test'),('2019-04-17 15:59:59','2019-04-18 15:59:59','NULSETH','4h','0.005311860000000','0.005081410000000','0.078589740906490','0.075180199655045','14.79514537402906','14.795145374029060','test'),('2019-04-23 23:59:59','2019-04-24 07:59:59','NULSETH','4h','0.005614880000000','0.005087380000000','0.078589740906490','0.071206486352844','13.996691096958438','13.996691096958438','test'),('2019-04-24 15:59:59','2019-04-24 19:59:59','NULSETH','4h','0.005093700000000','0.005053320000000','0.078589740906490','0.077966725468242','15.428812239921866','15.428812239921866','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:02:46
