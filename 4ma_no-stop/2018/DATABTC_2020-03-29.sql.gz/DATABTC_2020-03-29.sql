-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-12-02 03:59:59','2018-12-02 07:59:59','DATABTC','4h','0.000004940000000','0.000005090000000','0.001467500000000','0.001512059716599','297.06477732793525','297.064777327935246','test'),('2018-12-02 11:59:59','2018-12-03 19:59:59','DATABTC','4h','0.000005260000000','0.000004920000000','0.001478639929150','0.001383062443235','281.1102526900666','281.110252690066602','test'),('2018-12-05 11:59:59','2018-12-06 11:59:59','DATABTC','4h','0.000005280000000','0.000004900000000','0.001478639929150','0.001372222661522','280.04544112689393','280.045441126893934','test'),('2018-12-17 11:59:59','2018-12-17 23:59:59','DATABTC','4h','0.000005120000000','0.000004820000000','0.001478639929150','0.001392000870801','288.79686116210934','288.796861162109337','test'),('2018-12-23 19:59:59','2018-12-24 19:59:59','DATABTC','4h','0.000004780000000','0.000004760000000','0.001478639929150','0.001472453151204','309.33889731171547','309.338897311715471','test'),('2018-12-29 03:59:59','2018-12-29 15:59:59','DATABTC','4h','0.000004830000000','0.000004820000000','0.001478639929150','0.001475578562837','306.13663129399583','306.136631293995833','test'),('2018-12-29 23:59:59','2018-12-30 19:59:59','DATABTC','4h','0.000004840000000','0.000004730000000','0.001478639929150','0.001445034476215','305.50411759297515','305.504117592975149','test'),('2018-12-30 23:59:59','2018-12-31 03:59:59','DATABTC','4h','0.000004780000000','0.000004750000000','0.001478639929150','0.001469359762231','309.33889731171547','309.338897311715471','test'),('2018-12-31 07:59:59','2018-12-31 11:59:59','DATABTC','4h','0.000004770000000','0.000004680000000','0.001478639929150','0.001450741062562','309.9874065303983','309.987406530398289','test'),('2019-01-02 11:59:59','2019-01-02 15:59:59','DATABTC','4h','0.000004750000000','0.000004690000000','0.001478639929150','0.001459962372150','311.29261666315784','311.292616663157844','test'),('2019-01-03 03:59:59','2019-01-03 07:59:59','DATABTC','4h','0.000004770000000','0.000004720000000','0.001478639929150','0.001463140558823','309.9874065303983','309.987406530398289','test'),('2019-01-03 15:59:59','2019-01-03 19:59:59','DATABTC','4h','0.000004750000000','0.000004730000000','0.001478639929150','0.001472414076817','311.29261666315784','311.292616663157844','test'),('2019-01-03 23:59:59','2019-01-04 03:59:59','DATABTC','4h','0.000004780000000','0.000004770000000','0.001478639929150','0.001475546540177','309.33889731171547','309.338897311715471','test'),('2019-01-04 11:59:59','2019-01-05 15:59:59','DATABTC','4h','0.000004850000000','0.000004770000000','0.001478639929150','0.001454249992174','304.8742121958763','304.874212195876282','test'),('2019-01-05 19:59:59','2019-01-06 03:59:59','DATABTC','4h','0.000004830000000','0.000004790000000','0.001478639929150','0.001466394463898','306.13663129399583','306.136631293995833','test'),('2019-01-06 23:59:59','2019-01-08 07:59:59','DATABTC','4h','0.000005400000000','0.000004770000000','0.001478639929150','0.001306131937416','273.82220910185185','273.822209101851854','test'),('2019-01-13 15:59:59','2019-01-13 19:59:59','DATABTC','4h','0.000004870000000','0.000004700000000','0.001478639929150','0.001427024161603','303.62216204312114','303.622162043121136','test'),('2019-01-14 15:59:59','2019-01-14 19:59:59','DATABTC','4h','0.000004810000000','0.000004850000000','0.001478639929150','0.001490936311097','307.4095486798337','307.409548679833676','test'),('2019-01-14 23:59:59','2019-01-15 23:59:59','DATABTC','4h','0.000004860000000','0.000004910000000','0.001478639929150','0.001493852274100','304.2468990020576','304.246899002057603','test'),('2019-01-16 03:59:59','2019-01-16 19:59:59','DATABTC','4h','0.000004980000000','0.000004950000000','0.001478639929150','0.001469732459697','296.9156484236948','296.915648423694790','test'),('2019-01-16 23:59:59','2019-01-22 11:59:59','DATABTC','4h','0.000004970000000','0.000005300000000','0.001478639929150','0.001576819240341','297.51306421529176','297.513064215291763','test'),('2019-01-25 23:59:59','2019-01-27 11:59:59','DATABTC','4h','0.000005340000000','0.000005260000000','0.001478639929150','0.001456488020099','276.8988631367041','276.898863136704108','test'),('2019-02-05 03:59:59','2019-02-05 07:59:59','DATABTC','4h','0.000005180000000','0.000005160000000','0.001478639929150','0.001472930894675','285.4517237741312','285.451723774131210','test'),('2019-03-01 19:59:59','2019-03-02 03:59:59','DATABTC','4h','0.000005110000000','0.000004810000000','0.001478639929150','0.001391831322742','289.36202136007824','289.362021360078245','test'),('2019-03-02 15:59:59','2019-03-02 19:59:59','DATABTC','4h','0.000004760000000','0.000004760000000','0.001478639929150','0.001478639929150','310.63864057773105','310.638640577731053','test'),('2019-03-04 11:59:59','2019-03-04 15:59:59','DATABTC','4h','0.000004760000000','0.000004830000000','0.001478639929150','0.001500384633990','310.63864057773105','310.638640577731053','test'),('2019-03-04 19:59:59','2019-03-05 19:59:59','DATABTC','4h','0.000004880000000','0.000004860000000','0.001478639929150','0.001472579929440','302.99998548155736','302.999985481557360','test'),('2019-03-06 15:59:59','2019-03-06 23:59:59','DATABTC','4h','0.000004840000000','0.000004810000000','0.001478639929150','0.001469474805622','305.50411759297515','305.504117592975149','test'),('2019-03-07 03:59:59','2019-03-07 07:59:59','DATABTC','4h','0.000004820000000','0.000004800000000','0.001478639929150','0.001472504493759','306.771769533195','306.771769533195027','test'),('2019-03-07 11:59:59','2019-03-08 07:59:59','DATABTC','4h','0.000004880000000','0.000004800000000','0.001478639929150','0.001454399930311','302.99998548155736','302.999985481557360','test'),('2019-03-08 11:59:59','2019-03-08 23:59:59','DATABTC','4h','0.000004840000000','0.000004800000000','0.001478639929150','0.001466419764446','305.50411759297515','305.504117592975149','test'),('2019-03-09 11:59:59','2019-03-11 07:59:59','DATABTC','4h','0.000004840000000','0.000004850000000','0.001478639929150','0.001481694970326','305.50411759297515','305.504117592975149','test'),('2019-03-12 15:59:59','2019-03-17 07:59:59','DATABTC','4h','0.000005020000000','0.000005110000000','0.001478639929150','0.001505149409951','294.5497866832669','294.549786683266916','test'),('2019-03-19 11:59:59','2019-03-19 15:59:59','DATABTC','4h','0.000005220000000','0.000005090000000','0.001478639929150','0.001441815563098','283.264354243295','283.264354243294974','test'),('2019-03-25 19:59:59','2019-03-26 11:59:59','DATABTC','4h','0.000005530000000','0.000006020000000','0.001478639929150','0.001609658657049','267.3851589783001','267.385158978300126','test'),('2019-03-27 07:59:59','2019-03-30 11:59:59','DATABTC','4h','0.000005660000000','0.000005390000000','0.001478639929150','0.001408104102141','261.2438037367491','261.243803736749101','test'),('2019-03-30 23:59:59','2019-04-02 07:59:59','DATABTC','4h','0.000005700000000','0.000005360000000','0.001478639929150','0.001390440354429','259.4105138859649','259.410513885964917','test'),('2019-05-21 07:59:59','2019-05-21 15:59:59','DATABTC','4h','0.000003510000000','0.000002750000000','0.001478639929150','0.001158478576969','421.2649370797721','421.264937079772096','test'),('2019-05-22 11:59:59','2019-05-24 19:59:59','DATABTC','4h','0.000002750000000','0.000002800000000','0.001478639929150','0.001505524291498','537.6872469636363','537.687246963636312','test'),('2019-05-26 07:59:59','2019-05-26 19:59:59','DATABTC','4h','0.000003130000000','0.000002830000000','0.001478639929150','0.001336917252235','472.40892305111817','472.408923051118165','test'),('2019-05-28 11:59:59','2019-05-28 19:59:59','DATABTC','4h','0.000003000000000','0.000002850000000','0.001478639929150','0.001404707932692','492.8799763833333','492.879976383333315','test'),('2019-05-28 23:59:59','2019-05-29 11:59:59','DATABTC','4h','0.000002910000000','0.000002860000000','0.001478639929150','0.001453233744800','508.1236869931271','508.123686993127080','test'),('2019-05-29 15:59:59','2019-05-31 07:59:59','DATABTC','4h','0.000003100000000','0.000002910000000','0.001478639929150','0.001388013610912','476.9806223064516','476.980622306451608','test'),('2019-05-31 19:59:59','2019-06-04 03:59:59','DATABTC','4h','0.000003090000000','0.000003050000000','0.001478639929150','0.001459498959193','478.5242489158576','478.524248915857584','test'),('2019-06-08 15:59:59','2019-06-09 15:59:59','DATABTC','4h','0.000003220000000','0.000003120000000','0.001478639929150','0.001432719434456','459.20494694099375','459.204946940993750','test'),('2019-06-12 11:59:59','2019-06-12 15:59:59','DATABTC','4h','0.000003130000000','0.000003050000000','0.001478639929150','0.001440847215306','472.40892305111817','472.408923051118165','test'),('2019-06-13 07:59:59','2019-06-13 15:59:59','DATABTC','4h','0.000003190000000','0.000003110000000','0.001478639929150','0.001441558050049','463.52348876175546','463.523488761755459','test'),('2019-06-13 19:59:59','2019-06-13 23:59:59','DATABTC','4h','0.000003140000000','0.000003150000000','0.000985759952767','0.000988899315674','313.9362906900212','313.936290690021224','test'),('2019-06-14 03:59:59','2019-06-14 07:59:59','DATABTC','4h','0.000003450000000','0.000003140000000','0.001102733891711','0.001003647657963','319.63301209014526','319.633012090145257','test'),('2019-07-25 15:59:59','2019-07-26 11:59:59','DATABTC','4h','0.000001490000000','0.000001470000000','0.001102733891711','0.001087932094507','740.0898602087249','740.089860208724872','test'),('2019-07-26 15:59:59','2019-07-27 07:59:59','DATABTC','4h','0.000001510000000','0.000001460000000','0.001102733891711','0.001066219524436','730.2873455039736','730.287345503973597','test'),('2019-07-27 11:59:59','2019-07-30 19:59:59','DATABTC','4h','0.000001470000000','0.000001500000000','0.001102733891711','0.001125238665011','750.159110007483','750.159110007483036','test'),('2019-07-30 23:59:59','2019-07-31 15:59:59','DATABTC','4h','0.000001510000000','0.000001460000000','0.001102733891711','0.001066219524436','730.2873455039736','730.287345503973597','test'),('2019-08-16 07:59:59','2019-08-16 23:59:59','DATABTC','4h','0.000001290000000','0.000001050000000','0.001102733891711','0.000897574097904','854.8324741945737','854.832474194573706','test'),('2019-08-17 03:59:59','2019-08-17 07:59:59','DATABTC','4h','0.000001070000000','0.000001120000000','0.001102733891711','0.001154263512819','1030.5924221598132','1030.592422159813168','test'),('2019-08-17 15:59:59','2019-08-18 03:59:59','DATABTC','4h','0.000001120000000','0.000001060000000','0.001102733891711','0.001043658861798','984.5838318848214','984.583831884821393','test'),('2019-08-23 23:59:59','2019-08-28 19:59:59','DATABTC','4h','0.000001110000000','0.000001150000000','0.001102733891711','0.001142472049971','993.4539564963965','993.453956496396472','test'),('2019-08-30 03:59:59','2019-09-02 15:59:59','DATABTC','4h','0.000001210000000','0.000001220000000','0.001102733891711','0.001111847394948','911.3503237280992','911.350323728099170','test'),('2019-09-07 15:59:59','2019-09-09 07:59:59','DATABTC','4h','0.000001230000000','0.000001170000000','0.001102733891711','0.001048941994554','896.5316192772357','896.531619277235677','test'),('2019-09-09 11:59:59','2019-09-09 15:59:59','DATABTC','4h','0.000001180000000','0.000001190000000','0.001102733891711','0.001112079094183','934.520247212712','934.520247212711979','test'),('2019-09-16 23:59:59','2019-09-21 19:59:59','DATABTC','4h','0.000001190000000','0.000001300000000','0.001102733891711','0.001204667276659','926.6671358915967','926.667135891596672','test'),('2019-09-22 15:59:59','2019-09-24 03:59:59','DATABTC','4h','0.000001410000000','0.000001290000000','0.001102733891711','0.001008884198799','782.0807742631206','782.080774263120588','test'),('2019-09-29 07:59:59','2019-09-29 15:59:59','DATABTC','4h','0.000001300000000','0.000001250000000','0.001102733891711','0.001060321049722','848.2568397776923','848.256839777692335','test'),('2019-09-29 19:59:59','2019-09-29 23:59:59','DATABTC','4h','0.000001260000000','0.000001260000000','0.001102733891711','0.001102733891711','875.1856283420635','875.185628342063524','test'),('2019-10-01 11:59:59','2019-10-08 03:59:59','DATABTC','4h','0.000001320000000','0.000001480000000','0.001102733891711','0.001236398605858','835.4044634174243','835.404463417424267','test'),('2019-10-11 23:59:59','2019-10-13 15:59:59','DATABTC','4h','0.000001520000000','0.000001430000000','0.001102733891711','0.001037440437597','725.482823494079','725.482823494078957','test'),('2019-10-14 11:59:59','2019-10-16 15:59:59','DATABTC','4h','0.000001520000000','0.000001490000000','0.001102733891711','0.001080969407006','725.482823494079','725.482823494078957','test'),('2019-10-17 11:59:59','2019-10-18 11:59:59','DATABTC','4h','0.000001530000000','0.000001500000000','0.001102733891711','0.001081111658540','720.7411056934641','720.741105693464078','test'),('2019-10-18 15:59:59','2019-10-18 19:59:59','DATABTC','4h','0.000001510000000','0.000001490000000','0.001102733891711','0.001088128144801','730.2873455039736','730.287345503973597','test'),('2019-10-20 19:59:59','2019-10-23 07:59:59','DATABTC','4h','0.000001580000000','0.000001520000000','0.001102733891711','0.001060857921140','697.9328428550633','697.932842855063313','test'),('2019-10-24 19:59:59','2019-10-25 15:59:59','DATABTC','4h','0.000001600000000','0.000001530000000','0.001102733891711','0.001054489283949','689.208682319375','689.208682319375043','test'),('2019-11-12 03:59:59','2019-11-12 23:59:59','DATABTC','4h','0.000001430000000','0.000001380000000','0.001102733891711','0.001064176762630','771.1425816160839','771.142581616083930','test'),('2019-11-13 15:59:59','2019-11-13 23:59:59','DATABTC','4h','0.000001380000000','0.000001370000000','0.001102733891711','0.001094743066409','799.0825302253623','799.082530225362348','test'),('2019-11-15 23:59:59','2019-11-18 23:59:59','DATABTC','4h','0.000001390000000','0.000001390000000','0.001102733891711','0.001102733891711','793.3337350438849','793.333735043884872','test'),('2019-11-19 11:59:59','2019-11-21 11:59:59','DATABTC','4h','0.000001430000000','0.000001450000000','0.001102733891711','0.001118156743343','771.1425816160839','771.142581616083930','test'),('2019-11-22 03:59:59','2019-11-22 07:59:59','DATABTC','4h','0.000001460000000','0.000001440000000','0.001102733891711','0.001087627947989','755.2971861034247','755.297186103424679','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 21:39:52
