-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-30 19:59:59','2018-03-31 07:59:59','ENGBTC','4h','0.000211680000000','0.000209050000000','0.001467500000000','0.001449267172147','6.9326341647770215','6.932634164777022','test'),('2018-04-03 07:59:59','2018-04-03 15:59:59','ENGBTC','4h','0.000213520000000','0.000210010000000','0.001467500000000','0.001443376147433','6.872892469089547','6.872892469089547','test'),('2018-04-10 15:59:59','2018-04-11 15:59:59','ENGBTC','4h','0.000206440000000','0.000211560000000','0.001467500000000','0.001503896047278','7.108602983917845','7.108602983917845','test'),('2018-04-11 19:59:59','2018-04-24 03:59:59','ENGBTC','4h','0.000216740000000','0.000272250000000','0.001467500000000','0.001843346290486','6.770785272676941','6.770785272676941','test'),('2018-04-25 03:59:59','2018-04-25 07:59:59','ENGBTC','4h','0.000283970000000','0.000263300000000','0.001559971414336','0.001446422063579','5.493437385413952','5.493437385413952','test'),('2018-04-27 11:59:59','2018-04-28 07:59:59','ENGBTC','4h','0.000283630000000','0.000267690000000','0.001559971414336','0.001472301053850','5.500022615153545','5.500022615153545','test'),('2018-04-28 11:59:59','2018-04-28 23:59:59','ENGBTC','4h','0.000271140000000','0.000270950000000','0.001559971414336','0.001558878272163','5.753379856664454','5.753379856664454','test'),('2018-04-29 11:59:59','2018-05-04 11:59:59','ENGBTC','4h','0.000286690000000','0.000293580000000','0.001559971414336','0.001597462094321','5.441317849719209','5.441317849719209','test'),('2018-05-10 15:59:59','2018-05-10 19:59:59','ENGBTC','4h','0.000303310000000','0.000288300000000','0.001559971414336','0.001482772604771','5.143158531983779','5.143158531983779','test'),('2018-05-11 03:59:59','2018-05-11 07:59:59','ENGBTC','4h','0.000290250000000','0.000268430000000','0.001559971414336','0.001442698111112','5.374578516230836','5.374578516230836','test'),('2018-05-12 23:59:59','2018-05-15 23:59:59','ENGBTC','4h','0.000297840000000','0.000311730000000','0.001559971414336','0.001632721894275','5.237615546387322','5.237615546387322','test'),('2018-06-03 07:59:59','2018-06-03 11:59:59','ENGBTC','4h','0.000267280000000','0.000263210000000','0.001559971414336','0.001536216985810','5.836468925231967','5.836468925231967','test'),('2018-06-06 15:59:59','2018-06-08 07:59:59','ENGBTC','4h','0.000274430000000','0.000266110000000','0.001559971414336','0.001512677160183','5.684405547265241','5.684405547265241','test'),('2018-06-21 03:59:59','2018-06-22 23:59:59','ENGBTC','4h','0.000257470000000','0.000239180000000','0.001559971414336','0.001449155097219','6.05884730001942','6.058847300019420','test'),('2018-06-23 19:59:59','2018-06-24 11:59:59','ENGBTC','4h','0.000249870000000','0.000231910000000','0.001559971414336','0.001447844762071','6.2431320860287345','6.243132086028734','test'),('2018-06-25 19:59:59','2018-06-27 03:59:59','ENGBTC','4h','0.000243230000000','0.000233980000000','0.001559971414336','0.001500645938109','6.413564997475641','6.413564997475641','test'),('2018-07-02 15:59:59','2018-07-04 11:59:59','ENGBTC','4h','0.000245000000000','0.000239410000000','0.001559971414336','0.001524378597168','6.3672302625959185','6.367230262595919','test'),('2018-07-04 15:59:59','2018-07-04 23:59:59','ENGBTC','4h','0.000241940000000','0.000238440000000','0.001559971414336','0.001537404249129','6.447761487707696','6.447761487707696','test'),('2018-07-05 07:59:59','2018-07-05 11:59:59','ENGBTC','4h','0.000242010000000','0.000239530000000','0.001559971414336','0.001543985590992','6.445896509797116','6.445896509797116','test'),('2018-07-18 11:59:59','2018-07-18 23:59:59','ENGBTC','4h','0.000211110000000','0.000196860000000','0.001559971414336','0.001454672789665','7.389377169892473','7.389377169892473','test'),('2018-08-26 23:59:59','2018-08-29 15:59:59','ENGBTC','4h','0.000116250000000','0.000108990000000','0.001559971414336','0.001462548683428','13.419108940524731','13.419108940524731','test'),('2018-08-29 23:59:59','2018-08-31 07:59:59','ENGBTC','4h','0.000117710000000','0.000115070000000','0.001559971414336','0.001524984373865','13.252666845093875','13.252666845093875','test'),('2018-08-31 11:59:59','2018-09-02 23:59:59','ENGBTC','4h','0.000117170000000','0.000119210000000','0.001559971414336','0.001587131452616','13.31374425480925','13.313744254809251','test'),('2018-09-24 03:59:59','2018-09-24 07:59:59','ENGBTC','4h','0.000092050000000','0.000089360000000','0.001559971414336','0.001514383982456','16.947000698924498','16.947000698924498','test'),('2018-09-24 15:59:59','2018-09-24 19:59:59','ENGBTC','4h','0.000090340000000','0.000091070000000','0.001559971414336','0.001572576895103','17.267781872216073','17.267781872216073','test'),('2018-09-27 11:59:59','2018-09-28 15:59:59','ENGBTC','4h','0.000091550000000','0.000091440000000','0.001559971414336','0.001558097063101','17.039556683080285','17.039556683080285','test'),('2018-09-28 23:59:59','2018-10-03 07:59:59','ENGBTC','4h','0.000091730000000','0.000093350000000','0.001559971414336','0.001587521329208','17.00612029146408','17.006120291464079','test'),('2018-10-07 23:59:59','2018-10-11 03:59:59','ENGBTC','4h','0.000095920000000','0.000095710000000','0.001559971414336','0.001556556130798','16.263254945120934','16.263254945120934','test'),('2018-10-20 19:59:59','2018-10-29 15:59:59','ENGBTC','4h','0.000094870000000','0.000097020000000','0.001559971414336','0.001595324408336','16.443253023463686','16.443253023463686','test'),('2018-11-01 19:59:59','2018-11-03 03:59:59','ENGBTC','4h','0.000104280000000','0.000099440000000','0.001559971414336','0.001487567677806','14.959449696355966','14.959449696355966','test'),('2018-11-03 07:59:59','2018-11-03 11:59:59','ENGBTC','4h','0.000100800000000','0.000099180000000','0.001559971414336','0.001534900445177','15.475906888253968','15.475906888253968','test'),('2018-11-05 03:59:59','2018-11-06 11:59:59','ENGBTC','4h','0.000108300000000','0.000100820000000','0.001559971414336','0.001452228236319','14.404168184081255','14.404168184081255','test'),('2018-11-06 15:59:59','2018-11-07 03:59:59','ENGBTC','4h','0.000101470000000','0.000101000000000','0.001559971414336','0.001552745765723','15.373720452705234','15.373720452705234','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','ENGBTC','4h','0.000085380000000','0.000077940000000','0.001559971414336','0.001424035746467','18.270923100679315','18.270923100679315','test'),('2018-12-01 03:59:59','2018-12-01 07:59:59','ENGBTC','4h','0.000078070000000','0.000078090000000','0.001559971414336','0.001560371048360','19.981701221160495','19.981701221160495','test'),('2018-12-01 11:59:59','2018-12-02 11:59:59','ENGBTC','4h','0.000080140000000','0.000078400000000','0.001559971414336','0.001526101308759','19.465577917843774','19.465577917843774','test'),('2018-12-02 15:59:59','2018-12-03 03:59:59','ENGBTC','4h','0.000080110000000','0.000078250000000','0.001559971414336','0.001523751880811','19.47286748640619','19.472867486406191','test'),('2018-12-23 03:59:59','2018-12-25 07:59:59','ENGBTC','4h','0.000071340000000','0.000068720000000','0.001559971414336','0.001502680622276','21.86671452671713','21.866714526717129','test'),('2018-12-25 11:59:59','2018-12-25 15:59:59','ENGBTC','4h','0.000070150000000','0.000067780000000','0.001559971414336','0.001507268174821','22.237653803791876','22.237653803791876','test'),('2018-12-26 19:59:59','2018-12-27 23:59:59','ENGBTC','4h','0.000074270000000','0.000069730000000','0.001559971414336','0.001464612989385','21.00405835917598','21.004058359175978','test'),('2018-12-28 03:59:59','2018-12-30 07:59:59','ENGBTC','4h','0.000072570000000','0.000080790000000','0.001559971414336','0.001736669292603','21.49609224660328','21.496092246603279','test'),('2019-01-02 07:59:59','2019-01-02 19:59:59','ENGBTC','4h','0.000082570000000','0.000080050000000','0.001559971414336','0.001512361774465','18.89271423441928','18.892714234419280','test'),('2019-01-05 03:59:59','2019-01-10 11:59:59','ENGBTC','4h','0.000082420000000','0.000083650000000','0.001559971414336','0.001583251744834','18.927097965736472','18.927097965736472','test'),('2019-01-17 15:59:59','2019-01-18 15:59:59','ENGBTC','4h','0.000085700000000','0.000077660000000','0.001559971414336','0.001413621704053','18.202700283967328','18.202700283967328','test'),('2019-01-24 03:59:59','2019-01-26 23:59:59','ENGBTC','4h','0.000082540000000','0.000082590000000','0.001559971414336','0.001560916393385','18.899580982990063','18.899580982990063','test'),('2019-02-10 11:59:59','2019-02-15 19:59:59','ENGBTC','4h','0.000079950000000','0.000082420000000','0.001559971414336','0.001608165653153','19.51183757768605','19.511837577686052','test'),('2019-02-17 23:59:59','2019-02-18 19:59:59','ENGBTC','4h','0.000086430000000','0.000084370000000','0.001559971414336','0.001522790561466','18.04895770376027','18.048957703760269','test'),('2019-02-21 07:59:59','2019-02-24 03:59:59','ENGBTC','4h','0.000085340000000','0.000087540000000','0.001559971414336','0.001600186285575','18.27948692683384','18.279486926833840','test'),('2019-03-01 03:59:59','2019-03-02 07:59:59','ENGBTC','4h','0.000086890000000','0.000085860000000','0.001559971414336','0.001541479406547','17.953405620163426','17.953405620163426','test'),('2019-03-02 11:59:59','2019-03-02 15:59:59','ENGBTC','4h','0.000086310000000','0.000086510000000','0.001559971414336','0.001563586224704','18.074051840296605','18.074051840296605','test'),('2019-03-02 19:59:59','2019-03-04 03:59:59','ENGBTC','4h','0.000088760000000','0.000087000000000','0.001559971414336','0.001529039128518','17.575162396755296','17.575162396755296','test'),('2019-03-07 03:59:59','2019-03-12 01:59:59','ENGBTC','4h','0.000089020000000','0.000096700000000','0.001559971414336','0.001694554434580','17.52383076090766','17.523830760907661','test'),('2019-03-12 11:59:59','2019-03-16 07:59:59','ENGBTC','4h','0.000103520000000','0.000106680000000','0.001559971414336','0.001607590325361','15.06927564080371','15.069275640803710','test'),('2019-03-21 03:59:59','2019-03-21 15:59:59','ENGBTC','4h','0.000110700000000','0.000105320000000','0.001559971414336','0.001484157085437','14.091882694995485','14.091882694995485','test'),('2019-03-21 19:59:59','2019-03-21 23:59:59','ENGBTC','4h','0.000107300000000','0.000105070000000','0.001559971414336','0.001527550759593','14.53841019884436','14.538410198844360','test'),('2019-03-23 03:59:59','2019-03-24 11:59:59','ENGBTC','4h','0.000107680000000','0.000106750000000','0.001559971414336','0.001546498407136','14.487104516493314','14.487104516493314','test'),('2019-03-26 03:59:59','2019-03-30 15:59:59','ENGBTC','4h','0.000108490000000','0.000141920000000','0.001559971414336','0.002040659444396','14.378941970098627','14.378941970098627','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 12:56:09
