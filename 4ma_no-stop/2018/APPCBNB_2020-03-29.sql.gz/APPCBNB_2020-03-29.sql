-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-02 07:59:59','2018-07-06 07:59:59','APPCBNB','4h','0.013240000000000','0.014990000000000','0.711908500000000','0.806005167296073','53.769524169184294','53.769524169184294','test'),('2018-07-08 15:59:59','2018-07-11 07:59:59','APPCBNB','4h','0.016670000000000','0.015260000000000','0.735432666824018','0.673227504243222','44.11713658212467','44.117136582124672','test'),('2018-07-11 11:59:59','2018-07-11 23:59:59','APPCBNB','4h','0.016260000000000','0.015390000000000','0.735432666824018','0.696082948488415','45.22956130529016','45.229561305290161','test'),('2018-07-16 23:59:59','2018-07-17 15:59:59','APPCBNB','4h','0.016030000000000','0.016330000000000','0.735432666824018','0.749196222659776','45.878519452527634','45.878519452527634','test'),('2018-07-17 19:59:59','2018-07-19 19:59:59','APPCBNB','4h','0.016550000000000','0.016190000000000','0.735432666824018','0.719435339932378','44.4370191434452','44.437019143445198','test'),('2018-08-19 15:59:59','2018-08-20 23:59:59','APPCBNB','4h','0.008580000000000','0.008140000000000','0.735432666824018','0.697718171089453','85.71476303310232','85.714763033102315','test'),('2018-08-21 19:59:59','2018-08-21 23:59:59','APPCBNB','4h','0.008470000000000','0.008310000000000','0.735432666824018','0.721540196140211','86.82794177379196','86.827941773791963','test'),('2018-08-22 03:59:59','2018-08-22 23:59:59','APPCBNB','4h','0.008560000000000','0.008440000000000','0.735432666824018','0.725122863083494','85.91503117103014','85.915031171030137','test'),('2018-08-24 03:59:59','2018-08-24 23:59:59','APPCBNB','4h','0.008680000000000','0.008270000000000','0.735432666824018','0.700694487861132','84.7272657631357','84.727265763135705','test'),('2018-08-25 03:59:59','2018-08-30 03:59:59','APPCBNB','4h','0.008770000000000','0.009110000000000','0.735432666824018','0.763944309551517','83.8577727279382','83.857772727938197','test'),('2018-08-31 07:59:59','2018-09-01 07:59:59','APPCBNB','4h','0.009610000000000','0.009030000000000','0.735432666824018','0.691046512114556','76.52785294734838','76.527852947348379','test'),('2018-09-01 19:59:59','2018-09-02 11:59:59','APPCBNB','4h','0.009750000000000','0.009210000000000','0.735432666824018','0.694701011430688','75.42899146913005','75.428991469130054','test'),('2018-09-04 23:59:59','2018-09-05 11:59:59','APPCBNB','4h','0.009370000000000','0.008420000000000','0.735432666824018','0.660869055993408','78.48801140064226','78.488011400642264','test'),('2018-09-17 03:59:59','2018-09-21 19:59:59','APPCBNB','4h','0.008560000000000','0.009650000000000','0.735432666824018','0.829080050800441','85.91503117103014','85.915031171030137','test'),('2018-09-22 23:59:59','2018-09-25 03:59:59','APPCBNB','4h','0.011620000000000','0.010000000000000','0.735432666824018','0.632902467146315','63.29024671463149','63.290246714631493','test'),('2018-09-26 19:59:59','2018-10-02 19:59:59','APPCBNB','4h','0.011350000000000','0.011850000000000','0.735432666824018','0.767830581662080','64.79582967612492','64.795829676124924','test'),('2018-10-16 15:59:59','2018-10-18 11:59:59','APPCBNB','4h','0.011200000000000','0.010590000000000','0.735432666824018','0.695377851934496','65.66363096643018','65.663630966430176','test'),('2018-10-20 15:59:59','2018-10-25 19:59:59','APPCBNB','4h','0.010780000000000','0.011420000000000','0.735432666824018','0.779094717544553','68.22195425083655','68.221954250836546','test'),('2018-10-27 23:59:59','2018-10-29 15:59:59','APPCBNB','4h','0.013010000000000','0.011160000000000','0.735432666824018','0.630855385223370','56.528260324674704','56.528260324674704','test'),('2018-10-29 23:59:59','2018-10-30 11:59:59','APPCBNB','4h','0.012230000000000','0.011520000000000','0.735432666824018','0.692737884040285','60.13349687849698','60.133496878496977','test'),('2018-10-30 15:59:59','2018-11-03 11:59:59','APPCBNB','4h','0.012360000000000','0.012780000000000','0.735432666824018','0.760423097250077','59.50102482394968','59.501024823949678','test'),('2018-11-29 03:59:59','2018-12-01 03:59:59','APPCBNB','4h','0.009800000000000','0.009320000000000','0.735432666824018','0.699411474979576','75.04414967592021','75.044149675920210','test'),('2018-12-01 07:59:59','2018-12-03 07:59:59','APPCBNB','4h','0.009660000000000','0.009500000000000','0.735432666824018','0.723251587456332','76.13174604803498','76.131746048034984','test'),('2018-12-22 11:59:59','2018-12-22 15:59:59','APPCBNB','4h','0.008420000000000','0.008010000000000','0.735432666824018','0.699621812501233','87.34354712874323','87.343547128743225','test'),('2018-12-22 19:59:59','2018-12-23 11:59:59','APPCBNB','4h','0.008040000000000','0.007750000000000','0.735432666824018','0.708905866652505','91.47172472935547','91.471724729355472','test'),('2019-01-04 23:59:59','2019-01-06 07:59:59','APPCBNB','4h','0.007760000000000','0.008280000000000','0.735432666824018','0.784714237281297','94.77225087938376','94.772250879383762','test'),('2019-01-06 11:59:59','2019-01-08 03:59:59','APPCBNB','4h','0.008470000000000','0.007310000000000','0.735432666824018','0.634712254366419','86.82794177379196','86.827941773791963','test'),('2019-01-16 03:59:59','2019-01-17 19:59:59','APPCBNB','4h','0.007280000000000','0.007340000000000','0.735432666824018','0.741493925067073','101.02097071758489','101.020970717584888','test'),('2019-01-18 15:59:59','2019-01-18 19:59:59','APPCBNB','4h','0.008050000000000','0.007330000000000','0.735432666824018','0.669654838238516','91.35809525764199','91.358095257641992','test'),('2019-01-19 03:59:59','2019-01-20 03:59:59','APPCBNB','4h','0.007560000000000','0.007350000000000','0.735432666824018','0.715003981634462','97.27945328360026','97.279453283600262','test'),('2019-01-20 07:59:59','2019-01-20 15:59:59','APPCBNB','4h','0.007410000000000','0.007170000000000','0.735432666824018','0.711612985307451','99.24867298569744','99.248672985697439','test'),('2019-01-21 07:59:59','2019-01-21 19:59:59','APPCBNB','4h','0.007640000000000','0.007310000000000','0.735432666824018','0.703666596136593','96.26082026492382','96.260820264923822','test'),('2019-01-24 11:59:59','2019-01-25 11:59:59','APPCBNB','4h','0.007620000000000','0.007270000000000','0.735432666824018','0.701652951156248','96.5134733364853','96.513473336485305','test'),('2019-01-25 15:59:59','2019-01-25 19:59:59','APPCBNB','4h','0.007320000000000','0.007160000000000','0.490288444549345','0.479571757236791','66.97929570346248','66.979295703462483','test'),('2019-02-14 07:59:59','2019-02-18 03:59:59','APPCBNB','4h','0.005920000000000','0.006650000000000','0.543187952645629','0.610168899509026','91.75472173068056','91.754721730680558','test'),('2019-02-27 03:59:59','2019-02-27 15:59:59','APPCBNB','4h','0.006850000000000','0.005810000000000','0.559933189361478','0.474921435064261','81.74207143963184','81.742071439631843','test'),('2019-03-02 23:59:59','2019-03-04 07:59:59','APPCBNB','4h','0.006530000000000','0.005860000000000','0.559933189361478','0.502482157681204','85.74780847802113','85.747808478021128','test'),('2019-03-04 11:59:59','2019-03-04 15:59:59','APPCBNB','4h','0.005900000000000','0.006010000000000','0.559933189361478','0.570372621705506','94.9039304002505','94.903930400250502','test'),('2019-03-09 07:59:59','2019-03-10 07:59:59','APPCBNB','4h','0.005750000000000','0.005990000000000','0.559933189361478','0.583304313787000','97.379685106344','97.379685106343999','test'),('2019-03-10 15:59:59','2019-03-10 23:59:59','APPCBNB','4h','0.006110000000000','0.005680000000000','0.559933189361478','0.520527089291849','91.6420931851846','91.642093185184606','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','APPCBNB','4h','0.005380000000000','0.005090000000000','0.559933189361478','0.529750917072476','104.07680099655724','104.076800996557239','test'),('2019-03-21 19:59:59','2019-03-21 23:59:59','APPCBNB','4h','0.005170000000000','0.005240000000000','0.559933189361478','0.567514489797707','108.30429194612726','108.304291946127265','test'),('2019-03-29 07:59:59','2019-04-01 03:59:59','APPCBNB','4h','0.005500000000000','0.005110000000000','0.559933189361478','0.520228835934028','101.80603442935963','101.806034429359627','test'),('2019-04-07 19:59:59','2019-04-08 15:59:59','APPCBNB','4h','0.005090000000000','0.004910000000000','0.559933189361478','0.540132015670895','110.00652050323733','110.006520503237326','test'),('2019-04-08 19:59:59','2019-04-09 07:59:59','APPCBNB','4h','0.005020000000000','0.004840000000000','0.559933189361478','0.539855903687162','111.5404759684219','111.540475968421902','test'),('2019-05-07 11:59:59','2019-05-09 07:59:59','APPCBNB','4h','0.003120000000000','0.003020000000000','0.559933189361478','0.541986612779379','179.46576582098652','179.465765820986519','test'),('2019-05-09 11:59:59','2019-05-09 15:59:59','APPCBNB','4h','0.003130000000000','0.003100000000000','0.559933189361478','0.554566417578461','178.89239276724535','178.892392767245354','test'),('2019-05-09 19:59:59','2019-05-10 03:59:59','APPCBNB','4h','0.003130000000000','0.003130000000000','0.559933189361478','0.559933189361478','178.89239276724535','178.892392767245354','test'),('2019-05-10 07:59:59','2019-05-11 15:59:59','APPCBNB','4h','0.003160000000000','0.003180000000000','0.559933189361478','0.563477070306804','177.19404726629048','177.194047266290482','test'),('2019-05-11 19:59:59','2019-05-11 23:59:59','APPCBNB','4h','0.003190000000000','0.003290000000000','0.559933189361478','0.577485953918264','175.5276455678614','175.527645567861413','test'),('2019-05-12 11:59:59','2019-05-12 15:59:59','APPCBNB','4h','0.003210000000000','0.003110000000000','0.559933189361478','0.542489787823737','174.43401537740746','174.434015377407462','test'),('2019-05-25 03:59:59','2019-05-25 07:59:59','APPCBNB','4h','0.002800000000000','0.002740000000000','0.559933189361478','0.547934621018018','199.9761390576707','199.976139057670707','test'),('2019-05-26 15:59:59','2019-05-26 23:59:59','APPCBNB','4h','0.002990000000000','0.002880000000000','0.559933189361478','0.539333640588982','187.26862520450769','187.268625204507686','test'),('2019-05-28 11:59:59','2019-05-29 07:59:59','APPCBNB','4h','0.003070000000000','0.002920000000000','0.559933189361478','0.532574890207008','182.3886610297974','182.388661029797390','test'),('2019-05-29 11:59:59','2019-05-30 03:59:59','APPCBNB','4h','0.002960000000000','0.002860000000000','0.559933189361478','0.541016527558725','189.16661802752634','189.166618027526340','test'),('2019-05-30 07:59:59','2019-05-30 19:59:59','APPCBNB','4h','0.002890000000000','0.002940000000000','0.559933189361478','0.569620614782957','193.74850842957713','193.748508429577129','test'),('2019-05-31 11:59:59','2019-06-01 03:59:59','APPCBNB','4h','0.002980000000000','0.002850000000000','0.559933189361478','0.535506573718192','187.89704340989192','187.897043409891921','test'),('2019-06-02 03:59:59','2019-06-03 23:59:59','APPCBNB','4h','0.002980000000000','0.002980000000000','0.559933189361478','0.559933189361478','187.89704340989192','187.897043409891921','test'),('2019-06-08 11:59:59','2019-06-09 19:59:59','APPCBNB','4h','0.003100000000000','0.002920000000000','0.559933189361478','0.527420939656618','180.6236094714445','180.623609471444496','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','APPCBNB','4h','0.003100000000000','0.002980000000000','0.559933189361478','0.538258356224905','180.6236094714445','180.623609471444496','test'),('2019-06-10 15:59:59','2019-06-12 03:59:59','APPCBNB','4h','0.003080000000000','0.002910000000000','0.559933189361478','0.529027786052565','181.7964900524279','181.796490052427913','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 16:44:10
