-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-15 15:59:59','2018-06-15 23:59:59','ICXETH','4h','0.004347000000000','0.004080000000000','0.072144500000000','0.067713264320221','16.596388313779617','16.596388313779617','test'),('2018-07-03 03:59:59','2018-07-03 19:59:59','ICXETH','4h','0.003750000000000','0.003646000000000','0.072144500000000','0.070143692533333','19.238533333333333','19.238533333333333','test'),('2018-07-04 11:59:59','2018-07-05 15:59:59','ICXETH','4h','0.003660000000000','0.003604000000000','0.072144500000000','0.071040649726776','19.711612021857924','19.711612021857924','test'),('2018-08-18 11:59:59','2018-08-18 15:59:59','ICXETH','4h','0.002180000000000','0.002086000000000','0.072144500000000','0.069033682110092','33.09380733944954','33.093807339449540','test'),('2018-08-18 19:59:59','2018-08-18 23:59:59','ICXETH','4h','0.002126000000000','0.002131000000000','0.072144500000000','0.072314171919097','33.93438381937912','33.934383819379121','test'),('2018-08-19 07:59:59','2018-08-21 11:59:59','ICXETH','4h','0.002137000000000','0.002236000000000','0.072144500000000','0.075486711277492','33.75970987365466','33.759709873654657','test'),('2018-08-21 15:59:59','2018-08-22 11:59:59','ICXETH','4h','0.002273000000000','0.002272000000000','0.072144500000000','0.072112760228773','31.739771227452707','31.739771227452707','test'),('2018-08-23 19:59:59','2018-08-29 15:59:59','ICXETH','4h','0.002271000000000','0.002936000000000','0.072144500000000','0.093270036107442','31.767723469837076','31.767723469837076','test'),('2018-08-31 07:59:59','2018-09-02 19:59:59','ICXETH','4h','0.003203000000000','0.003169000000000','0.075634242055807','0.074831380916282','23.613562927195286','23.613562927195286','test'),('2018-09-04 07:59:59','2018-09-05 19:59:59','ICXETH','4h','0.003314000000000','0.003181000000000','0.075634242055807','0.072598830410236','22.82264395166174','22.822643951661739','test'),('2018-09-07 03:59:59','2018-09-08 19:59:59','ICXETH','4h','0.003226000000000','0.003186000000000','0.075634242055807','0.074696433722815','23.44520832480068','23.445208324800682','test'),('2018-09-08 23:59:59','2018-09-10 03:59:59','ICXETH','4h','0.003222000000000','0.003192000000000','0.075634242055807','0.074930012613947','23.474314728680014','23.474314728680014','test'),('2018-09-10 07:59:59','2018-09-10 15:59:59','ICXETH','4h','0.003230000000000','0.003180000000000','0.075634242055807','0.074463433355253','23.41617401108576','23.416174011085761','test'),('2018-09-13 07:59:59','2018-09-13 15:59:59','ICXETH','4h','0.003197000000000','0.003139000000000','0.075634242055807','0.074262085021326','23.657879904850486','23.657879904850486','test'),('2018-09-26 03:59:59','2018-09-28 03:59:59','ICXETH','4h','0.002943000000000','0.002952000000000','0.075634242055807','0.075865539432124','25.699708479716957','25.699708479716957','test'),('2018-09-28 07:59:59','2018-09-28 11:59:59','ICXETH','4h','0.002981000000000','0.002918000000000','0.075634242055807','0.074035799503135','25.372104010669908','25.372104010669908','test'),('2018-10-02 19:59:59','2018-10-05 15:59:59','ICXETH','4h','0.003099000000000','0.002982000000000','0.075634242055807','0.072778738241503','24.40601550687544','24.406015506875441','test'),('2018-10-08 07:59:59','2018-10-10 07:59:59','ICXETH','4h','0.002999000000000','0.003024000000000','0.075634242055807','0.076264737571444','25.219820625477492','25.219820625477492','test'),('2018-10-10 11:59:59','2018-10-11 07:59:59','ICXETH','4h','0.003059000000000','0.003089000000000','0.075634242055807','0.076375996636282','24.725152682512913','24.725152682512913','test'),('2018-10-11 11:59:59','2018-10-12 19:59:59','ICXETH','4h','0.003121000000000','0.003061000000000','0.075634242055807','0.074180203438906','24.23397694835213','24.233976948352129','test'),('2018-10-14 07:59:59','2018-10-15 07:59:59','ICXETH','4h','0.003114000000000','0.003002000000000','0.075634242055807','0.072913935340890','24.28845281175562','24.288452811755619','test'),('2018-10-15 19:59:59','2018-10-21 03:59:59','ICXETH','4h','0.003258000000000','0.003390000000000','0.075634242055807','0.078698612820499','23.21493003554543','23.214930035545429','test'),('2018-11-29 15:59:59','2018-11-30 11:59:59','ICXETH','4h','0.002465000000000','0.002241000000000','0.075634242055807','0.068761191256415','30.683262497284787','30.683262497284787','test'),('2018-11-30 15:59:59','2018-11-30 19:59:59','ICXETH','4h','0.002246000000000','0.002248000000000','0.075634242055807','0.075701592226827','33.675085510154496','33.675085510154496','test'),('2018-11-30 23:59:59','2018-12-01 03:59:59','ICXETH','4h','0.002291000000000','0.002262000000000','0.075634242055807','0.074676846586746','33.013636864167175','33.013636864167175','test'),('2018-12-01 11:59:59','2018-12-03 03:59:59','ICXETH','4h','0.002323000000000','0.002310000000000','0.075634242055807','0.075210976818301','32.5588644235071','32.558864423507103','test'),('2018-12-05 11:59:59','2018-12-05 19:59:59','ICXETH','4h','0.002320000000000','0.002272000000000','0.075634242055807','0.074069395668445','32.600966403365085','32.600966403365085','test'),('2018-12-07 03:59:59','2018-12-07 19:59:59','ICXETH','4h','0.002380000000000','0.002281000000000','0.075634242055807','0.072488111819032','31.779093300759243','31.779093300759243','test'),('2018-12-08 15:59:59','2018-12-08 23:59:59','ICXETH','4h','0.002340000000000','0.002280000000000','0.075634242055807','0.073694902515915','32.32232566487479','32.322325664874789','test'),('2018-12-09 07:59:59','2018-12-09 15:59:59','ICXETH','4h','0.002323000000000','0.002307000000000','0.075634242055807','0.075113300225031','32.5588644235071','32.558864423507103','test'),('2018-12-09 23:59:59','2018-12-10 07:59:59','ICXETH','4h','0.002336000000000','0.002312000000000','0.075634242055807','0.074857177925097','32.37767211293108','32.377672112931080','test'),('2019-01-08 07:59:59','2019-01-11 07:59:59','ICXETH','4h','0.001811000000000','0.001862000000000','0.075634242055807','0.077764195863011','41.7638001412518','41.763800141251799','test'),('2019-01-11 11:59:59','2019-01-12 15:59:59','ICXETH','4h','0.001893000000000','0.001877000000000','0.075634242055807','0.074994966898441','39.95469733534443','39.954697335344427','test'),('2019-01-12 23:59:59','2019-01-13 07:59:59','ICXETH','4h','0.001908000000000','0.001888000000000','0.075634242055807','0.074841430294216','39.64058807956342','39.640588079563422','test'),('2019-01-13 11:59:59','2019-01-13 15:59:59','ICXETH','4h','0.001906000000000','0.001856000000000','0.075634242055807','0.073650132872811','39.68218365991973','39.682183659919730','test'),('2019-01-16 19:59:59','2019-01-20 15:59:59','ICXETH','4h','0.001893000000000','0.001945000000000','0.075634242055807','0.077711886317245','39.95469733534443','39.954697335344427','test'),('2019-01-20 23:59:59','2019-01-22 07:59:59','ICXETH','4h','0.001954000000000','0.001915000000000','0.075634242055807','0.074124653805973','38.7073910213956','38.707391021395601','test'),('2019-01-23 11:59:59','2019-01-23 23:59:59','ICXETH','4h','0.001971000000000','0.001948000000000','0.075634242055807','0.074751650697469','38.373537319029424','38.373537319029424','test'),('2019-01-24 03:59:59','2019-01-25 11:59:59','ICXETH','4h','0.001958000000000','0.001946000000000','0.075634242055807','0.075170702267927','38.62831565669408','38.628315656694078','test'),('2019-01-26 07:59:59','2019-01-26 15:59:59','ICXETH','4h','0.001970000000000','0.001952000000000','0.075634242055807','0.074943167762911','38.39301627198325','38.393016271983250','test'),('2019-02-07 23:59:59','2019-02-08 19:59:59','ICXETH','4h','0.002013000000000','0.001884000000000','0.075634242055807','0.070787338317506','37.572897196128665','37.572897196128665','test'),('2019-02-12 11:59:59','2019-02-12 23:59:59','ICXETH','4h','0.001900000000000','0.001858000000000','0.075634242055807','0.073962327231415','39.807495818845794','39.807495818845794','test'),('2019-02-13 03:59:59','2019-02-13 07:59:59','ICXETH','4h','0.001882000000000','0.001846000000000','0.075634242055807','0.074187465905962','40.18822638459458','40.188226384594579','test'),('2019-02-25 23:59:59','2019-03-04 07:59:59','ICXETH','4h','0.001795000000000','0.002090000000000','0.075634242055807','0.088064382115118','42.13606799766407','42.136067997664071','test'),('2019-03-07 15:59:59','2019-03-11 15:59:59','ICXETH','4h','0.002302000000000','0.002429000000000','0.075634242055807','0.079806939163143','32.855882734929196','32.855882734929196','test'),('2019-03-12 23:59:59','2019-03-14 07:59:59','ICXETH','4h','0.002550000000000','0.002460000000000','0.075634242055807','0.072964798218543','29.660487080708627','29.660487080708627','test'),('2019-03-19 19:59:59','2019-03-20 07:59:59','ICXETH','4h','0.002502000000000','0.002425000000000','0.075634242055807','0.073306569538502','30.2295132117534','30.229513211753400','test'),('2019-03-20 19:59:59','2019-03-20 23:59:59','ICXETH','4h','0.002431000000000','0.002415000000000','0.075634242055807','0.075136443671236','31.11239903570835','31.112399035708350','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','ICXETH','4h','0.002458000000000','0.002363000000000','0.075634242055807','0.072711030910444','30.770643635397477','30.770643635397477','test'),('2019-03-25 07:59:59','2019-03-25 15:59:59','ICXETH','4h','0.002483000000000','0.002389000000000','0.075634242055807','0.072770923991673','30.460830469515507','30.460830469515507','test'),('2019-03-25 23:59:59','2019-03-26 03:59:59','ICXETH','4h','0.002375000000000','0.002335000000000','0.075634242055807','0.074360402189604','31.845996655076632','31.845996655076632','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','ICXETH','4h','0.002457000000000','0.002514000000000','0.075634242055807','0.077388882591900','30.78316729988075','30.783167299880748','test'),('2019-04-03 11:59:59','2019-04-03 23:59:59','ICXETH','4h','0.002599000000000','0.002510000000000','0.075634242055807','0.073044227610649','29.10128590065679','29.101285900656791','test'),('2019-04-04 07:59:59','2019-04-07 23:59:59','ICXETH','4h','0.002643000000000','0.002499000000000','0.075634242055807','0.071513420695218','28.616815004088917','28.616815004088917','test'),('2019-04-23 03:59:59','2019-04-23 23:59:59','ICXETH','4h','0.002410000000000','0.002232000000000','0.075634242055807','0.070047978534673','31.383502927720752','31.383502927720752','test'),('2019-04-24 03:59:59','2019-04-24 07:59:59','ICXETH','4h','0.002236000000000','0.002208000000000','0.075634242055807','0.074687122745627','33.82568964928757','33.825689649287568','test'),('2019-04-24 23:59:59','2019-04-25 23:59:59','ICXETH','4h','0.002353000000000','0.002307000000000','0.075634242055807','0.074155629588928','32.143749279985975','32.143749279985975','test'),('2019-04-26 11:59:59','2019-04-26 19:59:59','ICXETH','4h','0.002337000000000','0.002262000000000','0.075634242055807','0.073206955725390','32.363817738899016','32.363817738899016','test'),('2019-06-03 15:59:59','2019-06-04 03:59:59','ICXETH','4h','0.001556000000000','0.001565000000000','0.075634242055807','0.076071715178238','48.60812471452892','48.608124714528920','test'),('2019-06-04 11:59:59','2019-06-04 15:59:59','ICXETH','4h','0.001536000000000','0.001532000000000','0.075634242055807','0.075437277883787','49.24104300508268','49.241043005082680','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 19:49:05
