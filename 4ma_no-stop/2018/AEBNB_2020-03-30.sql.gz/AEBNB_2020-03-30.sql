-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-19 07:59:59','2018-08-20 23:59:59','AEBNB','4h','0.106770000000000','0.102120000000000','0.711908500000000','0.680903774655802','6.667682869719959','6.667682869719959','test'),('2018-08-29 11:59:59','2018-08-29 15:59:59','AEBNB','4h','0.107810000000000','0.102230000000000','0.711908500000000','0.675061737825805','6.603362396809202','6.603362396809202','test'),('2018-08-29 23:59:59','2018-08-30 03:59:59','AEBNB','4h','0.102520000000000','0.101780000000000','0.711908500000000','0.706769870561842','6.944093835349201','6.944093835349201','test'),('2018-08-30 19:59:59','2018-08-30 23:59:59','AEBNB','4h','0.104650000000000','0.101470000000000','0.711908500000000','0.690275733349260','6.802756808408982','6.802756808408982','test'),('2018-08-31 07:59:59','2018-08-31 15:59:59','AEBNB','4h','0.104830000000000','0.105190000000000','0.711908500000000','0.714353287370028','6.791076027854622','6.791076027854622','test'),('2018-08-31 19:59:59','2018-09-01 03:59:59','AEBNB','4h','0.106130000000000','0.105180000000000','0.711908500000000','0.705536003297842','6.707891265429191','6.707891265429191','test'),('2018-09-01 15:59:59','2018-09-02 11:59:59','AEBNB','4h','0.105700000000000','0.104300000000000','0.711908500000000','0.702479248344371','6.735179754020814','6.735179754020814','test'),('2018-09-02 15:59:59','2018-09-02 23:59:59','AEBNB','4h','0.105570000000000','0.103430000000000','0.711908500000000','0.697477466657194','6.743473524675571','6.743473524675571','test'),('2018-09-04 11:59:59','2018-09-04 15:59:59','AEBNB','4h','0.107160000000000','0.103890000000000','0.711908500000000','0.690184528415454','6.6434163867114595','6.643416386711460','test'),('2018-09-15 23:59:59','2018-09-17 07:59:59','AEBNB','4h','0.101130000000000','0.097850000000000','0.711908500000000','0.688818814644517','7.039538218135075','7.039538218135075','test'),('2018-09-17 11:59:59','2018-09-17 15:59:59','AEBNB','4h','0.098070000000000','0.098080000000000','0.711908500000000','0.711981091873152','7.259187315183032','7.259187315183032','test'),('2018-09-18 19:59:59','2018-09-18 23:59:59','AEBNB','4h','0.101350000000000','0.100660000000000','0.711908500000000','0.707061762308831','7.024257523433647','7.024257523433647','test'),('2018-09-21 11:59:59','2018-09-21 15:59:59','AEBNB','4h','0.099750000000000','0.096800000000000','0.711908500000000','0.690854564411028','7.136927318295739','7.136927318295739','test'),('2018-09-21 19:59:59','2018-09-22 11:59:59','AEBNB','4h','0.100530000000000','0.100410000000000','0.711908500000000','0.711058713667562','7.08155277031732','7.081552770317320','test'),('2018-09-22 23:59:59','2018-09-23 03:59:59','AEBNB','4h','0.097770000000000','0.098060000000000','0.711908500000000','0.714020123862126','7.28146159353585','7.281461593535850','test'),('2018-09-23 11:59:59','2018-09-23 19:59:59','AEBNB','4h','0.100440000000000','0.097810000000000','0.711908500000000','0.693267327608522','7.0878982477100765','7.087898247710076','test'),('2018-09-23 23:59:59','2018-09-24 11:59:59','AEBNB','4h','0.099460000000000','0.096430000000000','0.711908500000000','0.690220557560828','7.157736778604464','7.157736778604464','test'),('2018-09-26 07:59:59','2018-09-27 07:59:59','AEBNB','4h','0.099970000000000','0.099200000000000','0.711908500000000','0.706425159547864','7.121221366409923','7.121221366409923','test'),('2018-09-27 11:59:59','2018-09-28 03:59:59','AEBNB','4h','0.099500000000000','0.100040000000000','0.711908500000000','0.715772124020100','7.154859296482412','7.154859296482412','test'),('2018-09-28 07:59:59','2018-10-02 03:59:59','AEBNB','4h','0.100710000000000','0.109690000000000','0.711908500000000','0.775387184639063','7.068895839539272','7.068895839539272','test'),('2018-10-02 11:59:59','2018-10-02 23:59:59','AEBNB','4h','0.109500000000000','0.101740000000000','0.711908500000000','0.661457267488584','6.501447488584476','6.501447488584476','test'),('2018-10-09 15:59:59','2018-10-13 15:59:59','AEBNB','4h','0.105340000000000','0.114880000000000','0.711908500000000','0.776381701917600','6.758197265995824','6.758197265995824','test'),('2018-10-14 11:59:59','2018-10-15 07:59:59','AEBNB','4h','0.118780000000000','0.118540000000000','0.711908500000000','0.710470058848291','5.993504798787676','5.993504798787676','test'),('2018-10-15 11:59:59','2018-10-15 19:59:59','AEBNB','4h','0.118850000000000','0.113090000000000','0.711908500000000','0.677406245393353','5.989974758098444','5.989974758098444','test'),('2018-10-16 23:59:59','2018-10-22 11:59:59','AEBNB','4h','0.119720000000000','0.134830000000000','0.711908500000000','0.801759297151687','5.946445873705313','5.946445873705313','test'),('2018-11-25 07:59:59','2018-11-25 23:59:59','AEBNB','4h','0.118540000000000','0.112600000000000','0.711908500000000','0.676235001687194','6.005639446600304','6.005639446600304','test'),('2018-11-26 07:59:59','2018-11-26 15:59:59','AEBNB','4h','0.113600000000000','0.110610000000000','0.711908500000000','0.693170767473592','6.266800176056338','6.266800176056338','test'),('2018-11-28 03:59:59','2018-11-29 03:59:59','AEBNB','4h','0.119500000000000','0.113330000000000','0.711908500000000','0.675151383305439','5.957393305439331','5.957393305439331','test'),('2018-11-29 07:59:59','2018-11-29 11:59:59','AEBNB','4h','0.116050000000000','0.110150000000000','0.711908500000000','0.675714961439035','6.134498061180526','6.134498061180526','test'),('2018-12-22 07:59:59','2018-12-22 15:59:59','AEBNB','4h','0.079630000000000','0.075930000000000','0.711908500000000','0.678829742622127','8.940204696722342','8.940204696722342','test'),('2018-12-22 23:59:59','2018-12-23 11:59:59','AEBNB','4h','0.077210000000000','0.078800000000000','0.711908500000000','0.726568965159953','9.220418339593317','9.220418339593317','test'),('2018-12-24 15:59:59','2018-12-24 19:59:59','AEBNB','4h','0.078480000000000','0.078920000000000','0.711908500000000','0.715899832059123','9.071209225280327','9.071209225280327','test'),('2019-01-16 03:59:59','2019-01-18 07:59:59','AEBNB','4h','0.071810000000000','0.069660000000000','0.711908500000000','0.690593874251497','9.913779417908371','9.913779417908371','test'),('2019-02-19 07:59:59','2019-02-19 15:59:59','AEBNB','4h','0.046370000000000','0.042210000000000','0.711908500000000','0.648040927000216','15.352781971102006','15.352781971102006','test'),('2019-02-25 23:59:59','2019-02-27 15:59:59','AEBNB','4h','0.044370000000000','0.043560000000000','0.711908500000000','0.698912198782962','16.04481631733153','16.044816317331531','test'),('2019-02-27 19:59:59','2019-02-28 11:59:59','AEBNB','4h','0.045610000000000','0.043220000000000','0.711908500000000','0.674603932690200','15.608605568954179','15.608605568954179','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','AEBNB','4h','0.044660000000000','0.044310000000000','0.711908500000000','0.706329279780564','15.940629198387821','15.940629198387821','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','AEBNB','4h','0.044980000000000','0.044030000000000','0.711908500000000','0.696872637950200','15.827223210315697','15.827223210315697','test'),('2019-03-21 07:59:59','2019-03-24 11:59:59','AEBNB','4h','0.032310000000000','0.028090000000000','0.711908500000000','0.618926331321572','22.033689260290934','22.033689260290934','test'),('2019-03-31 07:59:59','2019-04-01 11:59:59','AEBNB','4h','0.030390000000000','0.029200000000000','0.711908500000000','0.684031859164199','23.425748601513657','23.425748601513657','test'),('2019-04-01 15:59:59','2019-04-01 19:59:59','AEBNB','4h','0.029510000000000','0.029580000000000','0.711908500000000','0.713597201965436','24.124313791934938','24.124313791934938','test'),('2019-04-03 03:59:59','2019-04-09 15:59:59','AEBNB','4h','0.031340000000000','0.034100000000000','0.711908500000000','0.774603696553925','22.715650925335037','22.715650925335037','test'),('2019-05-06 23:59:59','2019-05-09 15:59:59','AEBNB','4h','0.022660000000000','0.022810000000000','0.711908500000000','0.716621045233892','31.41696822594881','31.416968225948811','test'),('2019-05-09 19:59:59','2019-05-10 11:59:59','AEBNB','4h','0.022850000000000','0.022580000000000','0.711908500000000','0.703496452078775','31.155733041575495','31.155733041575495','test'),('2019-05-10 15:59:59','2019-05-11 15:59:59','AEBNB','4h','0.023220000000000','0.021790000000000','0.711908500000000','0.668065728466839','30.65928079242033','30.659280792420329','test'),('2019-06-16 15:59:59','2019-06-17 07:59:59','AEBNB','4h','0.016350000000000','0.015860000000000','0.711908500000000','0.690573015902141','43.54180428134557','43.541804281345570','test'),('2019-06-17 11:59:59','2019-06-17 15:59:59','AEBNB','4h','0.016120000000000','0.015650000000000','0.711908500000000','0.691151862593052','44.163058312655096','44.163058312655096','test'),('2019-06-24 23:59:59','2019-06-25 11:59:59','AEBNB','4h','0.016210000000000','0.014930000000000','0.711908500000000','0.655693640037014','43.91785934608267','43.917859346082672','test'),('2019-06-25 15:59:59','2019-06-26 11:59:59','AEBNB','4h','0.015330000000000','0.014950000000000','0.711908500000000','0.694261713959556','46.43891063274625','46.438910632746250','test'),('2019-06-26 15:59:59','2019-06-26 23:59:59','AEBNB','4h','0.015530000000000','0.015210000000000','0.711908500000000','0.697239425949775','45.84085640695429','45.840856406954288','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 22:41:53
