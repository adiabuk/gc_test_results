-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-26 11:59:59','2018-07-26 15:59:59','AEETH','4h','0.004098000000000','0.004075000000000','0.072144500000000','0.071739589433870','17.60480722303563','17.604807223035628','test'),('2018-07-27 07:59:59','2018-07-27 15:59:59','AEETH','4h','0.004249000000000','0.004200000000000','0.072144500000000','0.071312520593081','16.979171569781123','16.979171569781123','test'),('2018-07-27 19:59:59','2018-07-29 15:59:59','AEETH','4h','0.004203000000000','0.004586000000000','0.072144500000000','0.078718695455627','17.165001189626455','17.165001189626455','test'),('2018-07-30 03:59:59','2018-07-31 11:59:59','AEETH','4h','0.004464000000000','0.004272000000000','0.073478826370644','0.070318446741799','16.46031056690065','16.460310566900649','test'),('2018-07-31 19:59:59','2018-08-01 03:59:59','AEETH','4h','0.004361000000000','0.004250000000000','0.073478826370644','0.071608578783590','16.84907736084476','16.849077360844760','test'),('2018-08-19 19:59:59','2018-08-20 19:59:59','AEETH','4h','0.003695000000000','0.003618000000000','0.073478826370644','0.071947603195938','19.886015255925305','19.886015255925305','test'),('2018-08-21 07:59:59','2018-08-21 11:59:59','AEETH','4h','0.003626000000000','0.003598000000000','0.073478826370644','0.072911422306006','20.264430879934913','20.264430879934913','test'),('2018-08-24 11:59:59','2018-08-24 15:59:59','AEETH','4h','0.003637000000000','0.003626000000000','0.073478826370644','0.073256591811921','20.203141702129226','20.203141702129226','test'),('2018-08-24 23:59:59','2018-08-30 15:59:59','AEETH','4h','0.003680000000000','0.003874000000000','0.073478826370644','0.077352438413009','19.967072383327174','19.967072383327174','test'),('2018-08-31 07:59:59','2018-09-02 23:59:59','AEETH','4h','0.004017000000000','0.003977000000000','0.073478826370644','0.072747147741113','18.29196573827334','18.291965738273340','test'),('2018-09-03 15:59:59','2018-09-11 15:59:59','AEETH','4h','0.004141000000000','0.004696000000000','0.073478826370644','0.083326869991921','17.744222741039362','17.744222741039362','test'),('2018-09-11 19:59:59','2018-09-12 03:59:59','AEETH','4h','0.004756000000000','0.004817000000000','0.074888448375681','0.075848960434326','15.746099322052306','15.746099322052306','test'),('2018-09-12 15:59:59','2018-09-13 15:59:59','AEETH','4h','0.004862000000000','0.004507000000000','0.075128576390342','0.069643046851352','15.452195884480052','15.452195884480052','test'),('2018-09-26 11:59:59','2018-09-27 19:59:59','AEETH','4h','0.004508000000000','0.004391000000000','0.075128576390342','0.073178699851373','16.665611444175244','16.665611444175244','test'),('2018-09-27 23:59:59','2018-09-28 03:59:59','AEETH','4h','0.004422000000000','0.004381000000000','0.075128576390342','0.074431997549997','16.989727813284034','16.989727813284034','test'),('2018-09-28 19:59:59','2018-09-29 11:59:59','AEETH','4h','0.004548000000000','0.004347000000000','0.075128576390342','0.071808250125070','16.519036145633684','16.519036145633684','test'),('2018-09-29 23:59:59','2018-09-30 19:59:59','AEETH','4h','0.004747000000000','0.004542000000000','0.075128576390342','0.071884136078562','15.826538106244364','15.826538106244364','test'),('2018-09-30 23:59:59','2018-10-01 19:59:59','AEETH','4h','0.004651000000000','0.004497000000000','0.075128576390342','0.072640982160260','16.15320928624855','16.153209286248551','test'),('2018-10-01 23:59:59','2018-10-06 03:59:59','AEETH','4h','0.004636000000000','0.004692000000000','0.075128576390342','0.076036082921373','16.20547376840854','16.205473768408542','test'),('2018-10-09 23:59:59','2018-10-15 07:59:59','AEETH','4h','0.004783000000000','0.005567000000000','0.075128576390342','0.087443191462478','15.707417183847376','15.707417183847376','test'),('2018-10-15 11:59:59','2018-10-15 15:59:59','AEETH','4h','0.005591000000000','0.005618000000000','0.075128576390342','0.075491386542826','13.437413054970847','13.437413054970847','test'),('2018-10-15 19:59:59','2018-10-15 23:59:59','AEETH','4h','0.005713000000000','0.005651000000000','0.075128576390342','0.074313247887594','13.150459721747243','13.150459721747243','test'),('2018-10-16 23:59:59','2018-10-22 07:59:59','AEETH','4h','0.005731000000000','0.006550000000000','0.075128576390342','0.085864975633701','13.109156585297853','13.109156585297853','test'),('2018-11-27 03:59:59','2018-11-27 15:59:59','AEETH','4h','0.005057000000000','0.005032000000000','0.076708990583048','0.076329768758928','15.168872964810761','15.168872964810761','test'),('2018-11-28 03:59:59','2018-11-28 19:59:59','AEETH','4h','0.005402000000000','0.005018000000000','0.076708990583048','0.071256148601580','14.200109326739728','14.200109326739728','test'),('2018-11-28 23:59:59','2018-11-29 03:59:59','AEETH','4h','0.005040000000000','0.005092000000000','0.076708990583048','0.077500432549381','15.220037814096825','15.220037814096825','test'),('2018-11-29 07:59:59','2018-11-29 11:59:59','AEETH','4h','0.005094000000000','0.005024000000000','0.076708990583048','0.075654881957054','15.058694657056932','15.058694657056932','test'),('2018-11-29 23:59:59','2018-11-30 07:59:59','AEETH','4h','0.005130000000000','0.005054000000000','0.076708990583048','0.075572561092929','14.953019606831969','14.953019606831969','test'),('2019-01-11 11:59:59','2019-01-14 15:59:59','AEETH','4h','0.002934000000000','0.002854000000000','0.076708990583048','0.074617402564424','26.144850232804362','26.144850232804362','test'),('2019-01-15 15:59:59','2019-01-18 15:59:59','AEETH','4h','0.003031000000000','0.003488000000000','0.076708990583048','0.088274813313649','25.308146018821514','25.308146018821514','test'),('2019-01-21 23:59:59','2019-01-22 07:59:59','AEETH','4h','0.003640000000000','0.003501000000000','0.077269759272200','0.074319073409882','21.22795584401106','21.227955844011060','test'),('2019-01-25 15:59:59','2019-01-26 15:59:59','AEETH','4h','0.003595000000000','0.003535000000000','0.077269759272200','0.075980138811468','21.493674345535467','21.493674345535467','test'),('2019-01-30 03:59:59','2019-01-30 15:59:59','AEETH','4h','0.003577000000000','0.003474000000000','0.077269759272200','0.075044770397434','21.601833735588485','21.601833735588485','test'),('2019-02-07 15:59:59','2019-02-07 19:59:59','AEETH','4h','0.003502000000000','0.003485000000000','0.077269759272200','0.076894663353403','22.064465811593376','22.064465811593376','test'),('2019-02-26 15:59:59','2019-03-04 07:59:59','AEETH','4h','0.003180000000000','0.003275000000000','0.077269759272200','0.079578132583791','24.298666437798744','24.298666437798744','test'),('2019-03-11 15:59:59','2019-03-11 19:59:59','AEETH','4h','0.003235000000000','0.003197000000000','0.077269759272200','0.076362108313207','23.885551552457496','23.885551552457496','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','AEETH','4h','0.003226000000000','0.003187000000000','0.077269759272200','0.076335623930720','23.952188243087416','23.952188243087416','test'),('2019-03-12 11:59:59','2019-03-16 07:59:59','AEETH','4h','0.003260000000000','0.003309000000000','0.077269759272200','0.078431175899297','23.70238014484663','23.702380144846629','test'),('2019-03-20 07:59:59','2019-03-21 15:59:59','AEETH','4h','0.003393000000000','0.003425000000000','0.077269759272200','0.077998504423014','22.773285962923666','22.773285962923666','test'),('2019-03-21 23:59:59','2019-03-25 03:59:59','AEETH','4h','0.003461000000000','0.003467000000000','0.077269759272200','0.077403714359063','22.325847810517192','22.325847810517192','test'),('2019-03-30 15:59:59','2019-04-02 19:59:59','AEETH','4h','0.003561000000000','0.003524000000000','0.077269759272200','0.076466900217701','21.69889336484134','21.698893364841339','test'),('2019-04-03 11:59:59','2019-04-08 03:59:59','AEETH','4h','0.003860000000000','0.003666000000000','0.077269759272200','0.073386253236240','20.01807235031088','20.018072350310881','test'),('2019-05-25 11:59:59','2019-05-26 19:59:59','AEETH','4h','0.002388000000000','0.002166000000000','0.077269759272200','0.070086389691619','32.357520633249585','32.357520633249585','test'),('2019-06-10 07:59:59','2019-06-11 11:59:59','AEETH','4h','0.002189000000000','0.002082000000000','0.077269759272200','0.073492754136464','35.29911341809046','35.299113418090457','test'),('2019-06-11 15:59:59','2019-06-11 19:59:59','AEETH','4h','0.002088000000000','0.002073000000000','0.077269759272200','0.076714660426854','37.00658968975096','37.006589689750960','test'),('2019-07-23 03:59:59','2019-07-23 19:59:59','AEETH','4h','0.001438000000000','0.001381000000000','0.077269759272200','0.074206910677961','53.73418586383867','53.734185863838668','test'),('2019-07-24 11:59:59','2019-07-24 23:59:59','AEETH','4h','0.001424000000000','0.001394000000000','0.077269759272200','0.075641885130230','54.26247139901686','54.262471399016860','test'),('2019-07-25 03:59:59','2019-07-25 07:59:59','AEETH','4h','0.001396000000000','0.001365000000000','0.077269759272200','0.075553883529049','55.350830424212035','55.350830424212035','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 20:07:10
