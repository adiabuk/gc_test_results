-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-22 23:59:59','2018-05-26 07:59:59','ARNETH','4h','0.002020350000000','0.002167450000000','0.072144500000000','0.077397280929047','35.70891182220902','35.708911822209018','test'),('2018-05-31 23:59:59','2018-06-01 03:59:59','ARNETH','4h','0.002142140000000','0.002093610000000','0.073457695232262','0.071793517377583','34.29173407539272','34.291734075392718','test'),('2018-06-02 11:59:59','2018-06-03 23:59:59','ARNETH','4h','0.002227820000000','0.002113080000000','0.073457695232262','0.069674384214788','32.97290410906716','32.972904109067159','test'),('2018-06-04 03:59:59','2018-06-04 11:59:59','ARNETH','4h','0.002129680000000','0.002086800000000','0.073457695232262','0.071978662714908','34.4923628114374','34.492362811437403','test'),('2018-06-04 15:59:59','2018-06-04 19:59:59','ARNETH','4h','0.002175910000000','0.002127000000000','0.073457695232262','0.071806516702906','33.75952830414034','33.759528304140339','test'),('2018-06-04 23:59:59','2018-06-05 03:59:59','ARNETH','4h','0.002179380000000','0.002077730000000','0.073457695232262','0.070031503048999','33.705776520047905','33.705776520047905','test'),('2018-06-30 19:59:59','2018-07-03 23:59:59','ARNETH','4h','0.001474030000000','0.001502070000000','0.073457695232262','0.074855057412348','49.834599860424824','49.834599860424824','test'),('2018-07-05 15:59:59','2018-07-05 19:59:59','ARNETH','4h','0.001588130000000','0.001515180000000','0.073457695232262','0.070083450764118','46.254207925208895','46.254207925208895','test'),('2018-07-18 11:59:59','2018-07-20 07:59:59','ARNETH','4h','0.001505710000000','0.001407570000000','0.073457695232262','0.068669828903358','48.78608445999695','48.786084459996950','test'),('2018-07-20 11:59:59','2018-07-20 15:59:59','ARNETH','4h','0.001447670000000','0.001418220000000','0.073457695232262','0.071963342842152','50.74201664209523','50.742016642095230','test'),('2018-08-23 23:59:59','2018-08-30 15:59:59','ARNETH','4h','0.000958610000000','0.001107620000000','0.073457695232262','0.084876239965323','76.62938549802527','76.629385498025272','test'),('2018-08-31 07:59:59','2018-09-02 15:59:59','ARNETH','4h','0.001171490000000','0.001135710000000','0.073457695232262','0.071214128206158','62.70450045007811','62.704500450078108','test'),('2018-09-03 23:59:59','2018-09-06 11:59:59','ARNETH','4h','0.001156580000000','0.001178960000000','0.073457695232262','0.074879112876781','63.51285274884747','63.512852748847472','test'),('2018-09-09 07:59:59','2018-09-13 15:59:59','ARNETH','4h','0.001245400000000','0.001233440000000','0.073457695232262','0.072752255987860','58.98321441485627','58.983214414856270','test'),('2018-09-16 23:59:59','2018-09-19 15:59:59','ARNETH','4h','0.001448810000000','0.001379530000000','0.073457695232262','0.069945054426572','50.7020901514084','50.702090151408399','test'),('2018-09-20 11:59:59','2018-09-21 15:59:59','ARNETH','4h','0.001448960000000','0.001380660000000','0.073457695232262','0.069995100968539','50.696841342937006','50.696841342937006','test'),('2018-09-24 07:59:59','2018-09-25 03:59:59','ARNETH','4h','0.001467330000000','0.001396420000000','0.073457695232262','0.069907788143250','50.062150458494','50.062150458494003','test'),('2018-09-25 07:59:59','2018-09-29 11:59:59','ARNETH','4h','0.001405550000000','0.001593030000000','0.073457695232262','0.083255887187116','52.26259843638576','52.262598436385758','test'),('2018-09-29 15:59:59','2018-09-30 11:59:59','ARNETH','4h','0.001631700000000','0.001551450000000','0.073457695232262','0.069844910993499','45.019118240033094','45.019118240033094','test'),('2018-10-01 19:59:59','2018-10-13 19:59:59','ARNETH','4h','0.001637120000000','0.003490570000000','0.073457695232262','0.156622133531370','44.87007380782228','44.870073807822280','test'),('2018-10-16 23:59:59','2018-10-19 03:59:59','ARNETH','4h','0.003923210000000','0.003557090000000','0.090570861945924','0.082118649605610','23.08590718975641','23.085907189756409','test'),('2018-10-21 19:59:59','2018-10-28 03:59:59','ARNETH','4h','0.003793330000000','0.004082490000000','0.090570861945924','0.097474946336231','23.87634662576786','23.876346625767859','test'),('2018-11-29 03:59:59','2018-12-01 03:59:59','ARNETH','4h','0.002603490000000','0.002899000000000','0.090570861945924','0.100851137811643','34.78825036620997','34.788250366209972','test'),('2019-01-12 19:59:59','2019-01-14 15:59:59','ARNETH','4h','0.002028740000000','0.001926760000000','0.092753898924852','0.088091378043735','45.719953727363894','45.719953727363894','test'),('2019-01-15 15:59:59','2019-01-19 19:59:59','ARNETH','4h','0.002118450000000','0.002344950000000','0.092753898924852','0.102670941152178','43.78385089327197','43.783850893271968','test'),('2019-01-20 19:59:59','2019-01-22 19:59:59','ARNETH','4h','0.002550030000000','0.002439910000000','0.094067529261404','0.090005335356914','36.888793175533024','36.888793175533024','test'),('2019-01-23 07:59:59','2019-01-24 07:59:59','ARNETH','4h','0.002498730000000','0.002466630000000','0.094067529261404','0.092859088297678','37.646135941619946','37.646135941619946','test'),('2019-01-24 11:59:59','2019-01-24 15:59:59','ARNETH','4h','0.002504700000000','0.002442200000000','0.094067529261404','0.091720253907534','37.556405661917196','37.556405661917196','test'),('2019-01-26 23:59:59','2019-01-28 03:59:59','ARNETH','4h','0.002482480000000','0.002433370000000','0.094067529261404','0.092206625503054','37.89256278455577','37.892562784555771','test'),('2019-01-30 07:59:59','2019-02-01 07:59:59','ARNETH','4h','0.002486740000000','0.002429620000000','0.094067529261404','0.091906813918662','37.827649557816265','37.827649557816265','test'),('2019-02-02 19:59:59','2019-02-02 23:59:59','ARNETH','4h','0.002541030000000','0.002451130000000','0.094067529261404','0.090739480839858','37.01944851552481','37.019448515524807','test'),('2019-02-26 23:59:59','2019-02-27 15:59:59','ARNETH','4h','0.002214240000000','0.002115230000000','0.094067529261404','0.089861288712876','42.48298705714105','42.482987057141052','test'),('2019-02-27 19:59:59','2019-02-28 11:59:59','ARNETH','4h','0.002145170000000','0.002094750000000','0.094067529261404','0.091856569372276','43.850850637200786','43.850850637200786','test'),('2019-03-01 15:59:59','2019-03-06 11:59:59','ARNETH','4h','0.002179980000000','0.002214270000000','0.094067529261404','0.095547164660983','43.150638657879426','43.150638657879426','test'),('2019-03-06 19:59:59','2019-03-09 11:59:59','ARNETH','4h','0.002281100000000','0.002301250000000','0.094067529261404','0.094898470787254','41.23779284617247','41.237792846172468','test'),('2019-03-09 15:59:59','2019-03-16 11:59:59','ARNETH','4h','0.002370000000000','0.002998730000000','0.094067529261404','0.119022414355295','39.69094061662616','39.690940616626158','test'),('2019-03-16 23:59:59','2019-03-17 23:59:59','ARNETH','4h','0.003273050000000','0.003104240000000','0.095537700220639','0.090610271927687','29.189196688299738','29.189196688299738','test'),('2019-03-26 03:59:59','2019-03-29 11:59:59','ARNETH','4h','0.003136360000000','0.003228750000000','0.095537700220639','0.098352022595425','30.461331040007842','30.461331040007842','test'),('2019-03-29 15:59:59','2019-03-29 19:59:59','ARNETH','4h','0.003321020000000','0.003251500000000','0.095537700220639','0.093537778233015','28.767577497467343','28.767577497467343','test'),('2019-03-31 03:59:59','2019-04-02 07:59:59','ARNETH','4h','0.003362980000000','0.003348890000000','0.095537700220639','0.095137422432454','28.408643590101338','28.408643590101338','test'),('2019-04-17 11:59:59','2019-04-18 11:59:59','ARNETH','4h','0.002963350000000','0.002812470000000','0.095537700220639','0.090673364853811','32.23976250548838','32.239762505488379','test'),('2019-04-18 19:59:59','2019-04-18 23:59:59','ARNETH','4h','0.002793650000000','0.002777350000000','0.095537700220639','0.094980270151161','34.198163771638896','34.198163771638896','test'),('2019-04-19 11:59:59','2019-04-21 07:59:59','ARNETH','4h','0.002879660000000','0.002773950000000','0.095537700220639','0.092030588169104','33.1767292738167','33.176729273816697','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  6:21:24
