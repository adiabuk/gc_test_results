-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-08 19:59:59','2018-05-08 23:59:59','QSPETH','4h','0.000295890000000','0.000293740000000','0.072144500000000','0.071620282638818','243.82202845652102','243.822028456521025','test'),('2018-05-18 23:59:59','2018-05-22 07:59:59','QSPETH','4h','0.000326450000000','0.000301730000000','0.072144500000000','0.066681451937510','220.9970899065707','220.997089906570693','test'),('2018-05-24 11:59:59','2018-05-26 03:59:59','QSPETH','4h','0.000315550000000','0.000304490000000','0.072144500000000','0.069615841562351','228.63096181270797','228.630961812707966','test'),('2018-05-26 07:59:59','2018-05-26 15:59:59','QSPETH','4h','0.000309000000000','0.000304370000000','0.072144500000000','0.071063499886731','233.47734627831719','233.477346278317185','test'),('2018-07-01 19:59:59','2018-07-05 07:59:59','QSPETH','4h','0.000170510000000','0.000168600000000','0.072144500000000','0.071336359744297','423.11008152014546','423.110081520145457','test'),('2018-07-08 03:59:59','2018-07-09 07:59:59','QSPETH','4h','0.000174430000000','0.000162050000000','0.072144500000000','0.067024114114545','413.6014447056126','413.601444705612607','test'),('2018-07-09 11:59:59','2018-07-09 15:59:59','QSPETH','4h','0.000162500000000','0.000166530000000','0.072144500000000','0.073933683600000','443.9661538461539','443.966153846153873','test'),('2018-07-18 03:59:59','2018-07-19 19:59:59','QSPETH','4h','0.000163560000000','0.000161120000000','0.072144500000000','0.071068243091220','441.08889704084123','441.088897040841232','test'),('2018-08-17 15:59:59','2018-08-18 07:59:59','QSPETH','4h','0.000127530000000','0.000121230000000','0.072144500000000','0.068580551517290','565.7061083666589','565.706108366658896','test'),('2018-08-18 15:59:59','2018-08-18 19:59:59','QSPETH','4h','0.000121310000000','0.000122870000000','0.072144500000000','0.073072250556426','594.7118951446706','594.711895144670621','test'),('2018-08-20 19:59:59','2018-08-22 23:59:59','QSPETH','4h','0.000125000000000','0.000127900000000','0.072144500000000','0.073818252400000','577.156','577.155999999999949','test'),('2018-08-23 15:59:59','2018-08-29 15:59:59','QSPETH','4h','0.000129860000000','0.000150000000000','0.072144500000000','0.083333397505005','555.5559833667025','555.555983366702549','test'),('2018-08-31 23:59:59','2018-09-02 19:59:59','QSPETH','4h','0.000153990000000','0.000150420000000','0.072144500000000','0.070471950711085','468.50120137671274','468.501201376712743','test'),('2018-09-03 23:59:59','2018-09-04 03:59:59','QSPETH','4h','0.000152820000000','0.000150780000000','0.072144500000000','0.071181440321947','472.0880774767701','472.088077476770081','test'),('2018-09-04 11:59:59','2018-09-05 11:59:59','QSPETH','4h','0.000153200000000','0.000145670000000','0.072144500000000','0.068598494223238','470.9171018276762','470.917101827676220','test'),('2018-09-07 19:59:59','2018-09-09 11:59:59','QSPETH','4h','0.000151910000000','0.000155790000000','0.072144500000000','0.073987174346653','474.9160687249029','474.916068724902914','test'),('2018-09-09 19:59:59','2018-09-11 11:59:59','QSPETH','4h','0.000157220000000','0.000154160000000','0.072144500000000','0.070740339142603','458.87609718865286','458.876097188652864','test'),('2018-09-18 07:59:59','2018-09-18 11:59:59','QSPETH','4h','0.000153950000000','0.000148110000000','0.072144500000000','0.069407742091588','468.62292952257224','468.622929522572235','test'),('2018-09-18 15:59:59','2018-09-21 19:59:59','QSPETH','4h','0.000156910000000','0.000150130000000','0.072144500000000','0.069027173443375','459.7826779682621','459.782677968262078','test'),('2018-09-26 03:59:59','2018-09-26 19:59:59','QSPETH','4h','0.000160000000000','0.000163080000000','0.072144500000000','0.073533281625000','450.903125','450.903124999999989','test'),('2018-09-26 23:59:59','2018-09-29 11:59:59','QSPETH','4h','0.000166150000000','0.000156350000000','0.072144500000000','0.067889212007222','434.2130604875113','434.213060487511314','test'),('2018-10-02 07:59:59','2018-10-07 19:59:59','QSPETH','4h','0.000167780000000','0.000168870000000','0.072144500000000','0.072613194153058','429.994635832638','429.994635832637982','test'),('2018-10-08 03:59:59','2018-10-10 03:59:59','QSPETH','4h','0.000167730000000','0.000167080000000','0.072144500000000','0.071864920169320','430.12281643116916','430.122816431169156','test'),('2018-10-10 15:59:59','2018-10-11 03:59:59','QSPETH','4h','0.000175020000000','0.000167890000000','0.072144500000000','0.069205462832819','412.207176322706','412.207176322706005','test'),('2018-10-11 07:59:59','2018-10-11 11:59:59','QSPETH','4h','0.000168290000000','0.000170860000000','0.072144500000000','0.073246237269000','428.69154435795355','428.691544357953546','test'),('2018-10-11 15:59:59','2018-10-12 03:59:59','QSPETH','4h','0.000170880000000','0.000165620000000','0.072144500000000','0.069923759889981','422.1939372659176','422.193937265917612','test'),('2018-10-14 11:59:59','2018-10-17 19:59:59','QSPETH','4h','0.000172190000000','0.000202830000000','0.072144500000000','0.084982106597363','418.981938556246','418.981938556246007','test'),('2018-10-19 23:59:59','2018-10-21 11:59:59','QSPETH','4h','0.000208580000000','0.000203570000000','0.072144500000000','0.070411620792981','345.88407325726337','345.884073257263367','test'),('2018-10-22 23:59:59','2018-10-27 11:59:59','QSPETH','4h','0.000210710000000','0.000210010000000','0.072144500000000','0.071904828650752','342.38764178254473','342.387641782544733','test'),('2018-10-29 15:59:59','2018-10-31 15:59:59','QSPETH','4h','0.000233560000000','0.000219480000000','0.072144500000000','0.067795319660901','308.89064908374723','308.890649083747235','test'),('2018-10-31 19:59:59','2018-11-01 07:59:59','QSPETH','4h','0.000222490000000','0.000219720000000','0.072144500000000','0.071246301137130','324.2595172816756','324.259517281675585','test'),('2018-11-01 19:59:59','2018-11-03 03:59:59','QSPETH','4h','0.000226470000000','0.000219290000000','0.072144500000000','0.069857232326577','318.5609573011878','318.560957301187784','test'),('2018-11-03 19:59:59','2018-11-04 11:59:59','QSPETH','4h','0.000226850000000','0.000217940000000','0.072144500000000','0.069310876482257','318.0273308353537','318.027330835353723','test'),('2018-11-29 07:59:59','2018-11-30 11:59:59','QSPETH','4h','0.000161820000000','0.000155710000000','0.072144500000000','0.069420467772834','445.83178840687185','445.831788406871851','test'),('2018-11-30 15:59:59','2018-11-30 19:59:59','QSPETH','4h','0.000156880000000','0.000156370000000','0.072144500000000','0.071909965993116','459.8706017338093','459.870601733809281','test'),('2018-12-01 11:59:59','2018-12-02 07:59:59','QSPETH','4h','0.000168500000000','0.000160920000000','0.072144500000000','0.068899067893175','428.1572700296736','428.157270029673612','test'),('2018-12-02 11:59:59','2018-12-02 23:59:59','QSPETH','4h','0.000162200000000','0.000160910000000','0.072144500000000','0.071570724383477','444.7872996300863','444.787299630086295','test'),('2019-01-11 11:59:59','2019-01-14 19:59:59','QSPETH','4h','0.000113010000000','0.000112410000000','0.072144500000000','0.071761465755243','638.3904079285019','638.390407928501872','test'),('2019-01-15 15:59:59','2019-01-23 23:59:59','QSPETH','4h','0.000114890000000','0.000139050000000','0.072144500000000','0.087315629950387','627.9441204630516','627.944120463051604','test'),('2019-01-25 23:59:59','2019-01-27 11:59:59','QSPETH','4h','0.000142200000000','0.000138350000000','0.072144500000000','0.070191220639944','507.34528832630104','507.345288326301045','test'),('2019-02-26 23:59:59','2019-03-05 19:59:59','QSPETH','4h','0.000122030000000','0.000121760000000','0.072144500000000','0.071984875194624','591.202982873064','591.202982873064002','test'),('2019-03-08 11:59:59','2019-03-12 01:59:59','QSPETH','4h','0.000129890000000','0.000130790000000','0.072144500000000','0.072644384902610','555.4276695665563','555.427669566556347','test'),('2019-03-12 11:59:59','2019-03-16 07:59:59','QSPETH','4h','0.000139980000000','0.000140060000000','0.072144500000000','0.072185731318760','515.3914844977854','515.391484497785427','test'),('2019-03-16 15:59:59','2019-03-21 15:59:59','QSPETH','4h','0.000145500000000','0.000150420000000','0.072144500000000','0.074584025360825','495.8384879725086','495.838487972508574','test'),('2019-03-24 15:59:59','2019-03-25 03:59:59','QSPETH','4h','0.000154470000000','0.000152490000000','0.072144500000000','0.071219750145659','467.04538098012557','467.045380980125572','test'),('2019-03-25 15:59:59','2019-03-31 07:59:59','QSPETH','4h','0.000157180000000','0.000173260000000','0.072144500000000','0.079525105420537','458.9928744115027','458.992874411502726','test'),('2019-03-31 11:59:59','2019-04-02 07:59:59','QSPETH','4h','0.000180760000000','0.000179600000000','0.072144500000000','0.071681523567161','399.11761451648596','399.117614516485958','test'),('2019-04-02 11:59:59','2019-04-02 19:59:59','QSPETH','4h','0.000186770000000','0.000178670000000','0.072144500000000','0.069015676045403','386.27456229587193','386.274562295871931','test'),('2019-04-04 15:59:59','2019-04-06 19:59:59','QSPETH','4h','0.000187110000000','0.000176410000000','0.072144500000000','0.068018872561595','385.57265779488006','385.572657794880058','test'),('2019-04-15 19:59:59','2019-04-16 11:59:59','QSPETH','4h','0.000176100000000','0.000167570000000','0.072144500000000','0.068649936768881','409.67915956842705','409.679159568427053','test'),('2019-04-16 19:59:59','2019-04-16 23:59:59','QSPETH','4h','0.000168260000000','0.000168200000000','0.072144500000000','0.072118773921312','428.767978129086','428.767978129085975','test'),('2019-04-17 03:59:59','2019-04-17 07:59:59','QSPETH','4h','0.000169290000000','0.000168640000000','0.072144500000000','0.071867496485321','426.1592533522358','426.159253352235794','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  9:20:38
