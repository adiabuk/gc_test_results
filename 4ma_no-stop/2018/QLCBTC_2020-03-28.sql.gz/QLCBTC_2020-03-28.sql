-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-14 19:59:59','2018-09-17 11:59:59','QLCBTC','4h','0.000008650000000','0.000008560000000','0.001467500000000','0.001452231213873','169.65317919075144','169.653179190751445','test'),('2018-09-18 23:59:59','2018-09-19 11:59:59','QLCBTC','4h','0.000008660000000','0.000008110000000','0.001467500000000','0.001374298498845','169.45727482678984','169.457274826789842','test'),('2018-09-20 11:59:59','2018-09-22 11:59:59','QLCBTC','4h','0.000008740000000','0.000008510000000','0.001467500000000','0.001428881578947','167.90617848970254','167.906178489702540','test'),('2018-09-23 07:59:59','2018-09-24 03:59:59','QLCBTC','4h','0.000009120000000','0.000009140000000','0.001467500000000','0.001470718201754','160.91008771929825','160.910087719298247','test'),('2018-09-24 15:59:59','2018-09-25 03:59:59','QLCBTC','4h','0.000009000000000','0.000008880000000','0.001467500000000','0.001447933333333','163.05555555555557','163.055555555555571','test'),('2018-10-08 19:59:59','2018-10-11 03:59:59','QLCBTC','4h','0.000008770000000','0.000008280000000','0.001467500000000','0.001385507411631','167.33181299885973','167.331812998859732','test'),('2018-10-26 03:59:59','2018-10-27 19:59:59','QLCBTC','4h','0.000008090000000','0.000008020000000','0.001467500000000','0.001454802224969','181.39678615574783','181.396786155747833','test'),('2018-10-27 23:59:59','2018-10-29 15:59:59','QLCBTC','4h','0.000008280000000','0.000008550000000','0.001467500000000','0.001515353260870','177.2342995169082','177.234299516908209','test'),('2018-10-29 23:59:59','2018-10-31 15:59:59','QLCBTC','4h','0.000008510000000','0.000008470000000','0.001467500000000','0.001460602232667','172.44418331374854','172.444183313748539','test'),('2018-10-31 19:59:59','2018-10-31 23:59:59','QLCBTC','4h','0.000008580000000','0.000008480000000','0.001467500000000','0.001450396270396','171.03729603729607','171.037296037296073','test'),('2018-11-03 07:59:59','2018-11-03 11:59:59','QLCBTC','4h','0.000008500000000','0.000008400000000','0.001467500000000','0.001450235294118','172.64705882352942','172.647058823529420','test'),('2018-11-07 19:59:59','2018-11-09 11:59:59','QLCBTC','4h','0.000008830000000','0.000008350000000','0.001467500000000','0.001387726500566','166.19479048697622','166.194790486976217','test'),('2018-11-30 03:59:59','2018-11-30 15:59:59','QLCBTC','4h','0.000007620000000','0.000007200000000','0.001467500000000','0.001386614173228','192.58530183727035','192.585301837270350','test'),('2018-11-30 19:59:59','2018-12-03 19:59:59','QLCBTC','4h','0.000007960000000','0.000007230000000','0.001467500000000','0.001332917713568','184.35929648241208','184.359296482412077','test'),('2018-12-17 19:59:59','2018-12-19 23:59:59','QLCBTC','4h','0.000005950000000','0.000005700000000','0.001467500000000','0.001405840336134','246.6386554621849','246.638655462184886','test'),('2018-12-21 07:59:59','2018-12-25 07:59:59','QLCBTC','4h','0.000006010000000','0.000006510000000','0.001467500000000','0.001589588186356','244.17637271214642','244.176372712146417','test'),('2018-12-25 11:59:59','2018-12-30 19:59:59','QLCBTC','4h','0.000006740000000','0.000006610000000','0.001467500000000','0.001439195103858','217.7299703264095','217.729970326409500','test'),('2019-01-02 15:59:59','2019-01-04 11:59:59','QLCBTC','4h','0.000006810000000','0.000006790000000','0.001467500000000','0.001463190161527','215.49192364170338','215.491923641703380','test'),('2019-01-04 15:59:59','2019-01-08 19:59:59','QLCBTC','4h','0.000006820000000','0.000007200000000','0.001467500000000','0.001549266862170','215.1759530791789','215.175953079178896','test'),('2019-01-09 11:59:59','2019-01-10 07:59:59','QLCBTC','4h','0.000007510000000','0.000007220000000','0.001467500000000','0.001410832223702','195.40612516644475','195.406125166444752','test'),('2019-01-14 23:59:59','2019-01-15 23:59:59','QLCBTC','4h','0.000008960000000','0.000007280000000','0.001467500000000','0.001192343750000','163.78348214285714','163.783482142857139','test'),('2019-01-21 19:59:59','2019-01-21 23:59:59','QLCBTC','4h','0.000007400000000','0.000007290000000','0.001467500000000','0.001445685810811','198.3108108108108','198.310810810810807','test'),('2019-01-22 07:59:59','2019-01-22 11:59:59','QLCBTC','4h','0.000007220000000','0.000007140000000','0.001467500000000','0.001451239612188','203.25484764542935','203.254847645429351','test'),('2019-01-22 15:59:59','2019-01-22 19:59:59','QLCBTC','4h','0.000007210000000','0.000007230000000','0.001467500000000','0.001471570735090','203.5367545076283','203.536754507628302','test'),('2019-01-23 03:59:59','2019-01-23 15:59:59','QLCBTC','4h','0.000007210000000','0.000007230000000','0.001467500000000','0.001471570735090','203.5367545076283','203.536754507628302','test'),('2019-02-15 19:59:59','2019-02-15 23:59:59','QLCBTC','4h','0.000006380000000','0.000006310000000','0.001467500000000','0.001451398902821','230.01567398119124','230.015673981191242','test'),('2019-02-17 15:59:59','2019-02-18 19:59:59','QLCBTC','4h','0.000006510000000','0.000006440000000','0.001467500000000','0.001451720430108','225.42242703533026','225.422427035330259','test'),('2019-02-20 07:59:59','2019-02-21 11:59:59','QLCBTC','4h','0.000006500000000','0.000006400000000','0.001467500000000','0.001444923076923','225.7692307692308','225.769230769230802','test'),('2019-02-22 11:59:59','2019-02-24 15:59:59','QLCBTC','4h','0.000006580000000','0.000006410000000','0.001467500000000','0.001429585866261','223.0243161094225','223.024316109422500','test'),('2019-02-26 15:59:59','2019-02-27 23:59:59','QLCBTC','4h','0.000006780000000','0.000006600000000','0.001467500000000','0.001428539823009','216.44542772861357','216.445427728613566','test'),('2019-02-28 03:59:59','2019-02-28 11:59:59','QLCBTC','4h','0.000006650000000','0.000006700000000','0.001467500000000','0.001478533834586','220.67669172932332','220.676691729323323','test'),('2019-02-28 15:59:59','2019-03-08 15:59:59','QLCBTC','4h','0.000006950000000','0.000008030000000','0.001467500000000','0.001695543165468','211.15107913669064','211.151079136690640','test'),('2019-03-10 03:59:59','2019-03-11 07:59:59','QLCBTC','4h','0.000008240000000','0.000008110000000','0.001467500000000','0.001444347694175','178.09466019417474','178.094660194174736','test'),('2019-03-11 15:59:59','2019-03-12 01:59:59','QLCBTC','4h','0.000008370000000','0.000008150000000','0.001467500000000','0.001428927718041','175.32855436081243','175.328554360812433','test'),('2019-03-12 11:59:59','2019-03-14 03:59:59','QLCBTC','4h','0.000008430000000','0.000008380000000','0.001467500000000','0.001458795966785','174.08066429418741','174.080664294187414','test'),('2019-03-14 11:59:59','2019-03-17 15:59:59','QLCBTC','4h','0.000008780000000','0.000008740000000','0.001467500000000','0.001460814350797','167.14123006833714','167.141230068337137','test'),('2019-03-20 15:59:59','2019-03-24 07:59:59','QLCBTC','4h','0.000009480000000','0.000009020000000','0.001467500000000','0.001396292194093','154.79957805907173','154.799578059071735','test'),('2019-03-26 03:59:59','2019-03-31 11:59:59','QLCBTC','4h','0.000010500000000','0.000011030000000','0.001467500000000','0.001541573809524','139.7619047619048','139.761904761904788','test'),('2019-03-31 15:59:59','2019-03-31 19:59:59','QLCBTC','4h','0.000011760000000','0.000010960000000','0.001467500000000','0.001367670068027','124.78741496598641','124.787414965986414','test'),('2019-05-20 23:59:59','2019-05-25 11:59:59','QLCBTC','4h','0.000004930000000','0.000005510000000','0.001467500000000','0.001640147058824','297.66734279918865','297.667342799188646','test'),('2019-06-04 23:59:59','2019-06-07 11:59:59','QLCBTC','4h','0.000005060000000','0.000005040000000','0.001467500000000','0.001461699604743','290.0197628458498','290.019762845849812','test'),('2019-06-07 15:59:59','2019-06-07 19:59:59','QLCBTC','4h','0.000005050000000','0.000005020000000','0.001467500000000','0.001458782178218','290.5940594059406','290.594059405940584','test'),('2019-06-11 03:59:59','2019-06-12 15:59:59','QLCBTC','4h','0.000005220000000','0.000005030000000','0.001467500000000','0.001414085249042','281.13026819923374','281.130268199233740','test'),('2019-07-26 19:59:59','2019-07-29 03:59:59','QLCBTC','4h','0.000002280000000','0.000002270000000','0.001467500000000','0.001461063596491','643.640350877193','643.640350877192986','test'),('2019-08-22 03:59:59','2019-08-28 07:59:59','QLCBTC','4h','0.000001400000000','0.000001590000000','0.001467500000000','0.001666660714286','1048.2142857142858','1048.214285714285779','test'),('2019-08-31 03:59:59','2019-08-31 15:59:59','QLCBTC','4h','0.000001590000000','0.000001550000000','0.001467500000000','0.001430581761006','922.9559748427673','922.955974842767318','test'),('2019-08-31 19:59:59','2019-09-01 03:59:59','QLCBTC','4h','0.000001560000000','0.000001520000000','0.001467500000000','0.001429871794872','940.7051282051282','940.705128205128176','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:25:13
