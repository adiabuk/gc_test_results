-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-04 23:59:59','2018-06-06 15:59:59','DGDETH','4h','0.288900000000000','0.252580000000000','0.072144500000000','0.063074620318449','0.2497213568708896','0.249721356870890','test'),('2018-06-06 19:59:59','2018-06-09 07:59:59','DGDETH','4h','0.267280000000000','0.260390000000000','0.072144500000000','0.070284743920233','0.26992105656988924','0.269921056569889','test'),('2018-06-09 11:59:59','2018-06-09 15:59:59','DGDETH','4h','0.262000000000000','0.259500000000000','0.072144500000000','0.071456098282443','0.27536068702290073','0.275360687022901','test'),('2018-07-02 07:59:59','2018-07-02 15:59:59','DGDETH','4h','0.221670000000000','0.228300000000000','0.072144500000000','0.074302293273785','0.32545901565389995','0.325459015653900','test'),('2018-07-02 19:59:59','2018-07-04 11:59:59','DGDETH','4h','0.229340000000000','0.221500000000000','0.072144500000000','0.069678236461149','0.31457443097584376','0.314574430975844','test'),('2018-07-04 15:59:59','2018-07-05 11:59:59','DGDETH','4h','0.224740000000000','0.218370000000000','0.072144500000000','0.070099646102163','0.32101317077511793','0.321013170775118','test'),('2018-07-18 03:59:59','2018-07-19 03:59:59','DGDETH','4h','0.216870000000000','0.212430000000000','0.072144500000000','0.070667478835247','0.33266242449393646','0.332662424493936','test'),('2018-07-19 11:59:59','2018-07-19 15:59:59','DGDETH','4h','0.214590000000000','0.213030000000000','0.072144500000000','0.071620032783448','0.3361969336874971','0.336196933687497','test'),('2018-08-19 11:59:59','2018-08-23 23:59:59','DGDETH','4h','0.206530000000000','0.193050000000000','0.072144500000000','0.067435702924515','0.3493172904662761','0.349317290466276','test'),('2018-08-25 07:59:59','2018-08-26 15:59:59','DGDETH','4h','0.196180000000000','0.192520000000000','0.072144500000000','0.070798547966154','0.3677464573351004','0.367746457335100','test'),('2018-08-26 23:59:59','2018-08-27 07:59:59','DGDETH','4h','0.196530000000000','0.197650000000000','0.072144500000000','0.072555642522770','0.367091538187554','0.367091538187554','test'),('2018-08-27 11:59:59','2018-08-29 03:59:59','DGDETH','4h','0.199290000000000','0.195840000000000','0.072144500000000','0.070895573686587','0.3620076270761202','0.362007627076120','test'),('2018-09-07 15:59:59','2018-09-08 23:59:59','DGDETH','4h','0.192590000000000','0.188080000000000','0.072144500000000','0.070455047302560','0.37460148501999063','0.374601485019991','test'),('2018-09-09 03:59:59','2018-09-09 11:59:59','DGDETH','4h','0.191080000000000','0.187420000000000','0.072144500000000','0.070762623979485','0.3775617542390622','0.377561754239062','test'),('2018-09-09 15:59:59','2018-09-11 07:59:59','DGDETH','4h','0.192800000000000','0.191940000000000','0.072144500000000','0.071822693620332','0.37419346473029047','0.374193464730290','test'),('2018-09-27 07:59:59','2018-09-27 19:59:59','DGDETH','4h','0.169500000000000','0.163970000000000','0.072144500000000','0.069790759085546','0.42563126843657817','0.425631268436578','test'),('2018-09-28 11:59:59','2018-09-29 07:59:59','DGDETH','4h','0.169100000000000','0.165420000000000','0.072144500000000','0.070574471850976','0.4266380839739799','0.426638083973980','test'),('2018-10-01 15:59:59','2018-10-01 19:59:59','DGDETH','4h','0.168050000000000','0.169000000000000','0.072144500000000','0.072552338589705','0.42930377863731034','0.429303778637310','test'),('2018-10-02 03:59:59','2018-10-02 11:59:59','DGDETH','4h','0.167360000000000','0.167050000000000','0.072144500000000','0.072010867142686','0.43107373326959847','0.431073733269598','test'),('2018-10-02 15:59:59','2018-10-02 23:59:59','DGDETH','4h','0.170080000000000','0.167070000000000','0.072144500000000','0.070867718808796','0.4241797977422389','0.424179797742239','test'),('2018-10-03 03:59:59','2018-10-04 07:59:59','DGDETH','4h','0.169900000000000','0.168000000000000','0.072144500000000','0.071337704532078','0.42462919364331964','0.424629193643320','test'),('2018-10-04 11:59:59','2018-10-05 11:59:59','DGDETH','4h','0.170590000000000','0.171920000000000','0.072144500000000','0.072706972507181','0.42291165953455656','0.422911659534557','test'),('2018-10-05 15:59:59','2018-10-08 19:59:59','DGDETH','4h','0.172440000000000','0.180360000000000','0.072144500000000','0.075458026096033','0.4183745070749246','0.418374507074925','test'),('2018-10-11 03:59:59','2018-10-11 07:59:59','DGDETH','4h','0.183590000000000','0.177800000000000','0.072144500000000','0.069869230894929','0.392965303121085','0.392965303121085','test'),('2018-10-12 11:59:59','2018-10-15 07:59:59','DGDETH','4h','0.201460000000000','0.189140000000000','0.072144500000000','0.067732605628909','0.3581083093418048','0.358108309341805','test'),('2018-10-15 11:59:59','2018-10-18 03:59:59','DGDETH','4h','0.189740000000000','0.206630000000000','0.072144500000000','0.078566554416570','0.3802282070201328','0.380228207020133','test'),('2018-10-19 03:59:59','2018-10-22 07:59:59','DGDETH','4h','0.213970000000000','0.214240000000000','0.072144500000000','0.072235536196663','0.3371710987521615','0.337171098752162','test'),('2018-11-02 19:59:59','2018-11-02 23:59:59','DGDETH','4h','0.208900000000000','0.202170000000000','0.072144500000000','0.069820265988511','0.34535423647678315','0.345354236476783','test'),('2018-11-03 03:59:59','2018-11-03 07:59:59','DGDETH','4h','0.205290000000000','0.202480000000000','0.072144500000000','0.071156989429587','0.3514272492571484','0.351427249257148','test'),('2018-11-03 11:59:59','2018-11-04 11:59:59','DGDETH','4h','0.206330000000000','0.203610000000000','0.072144500000000','0.071193435976349','0.3496558910483206','0.349655891048321','test'),('2018-12-02 19:59:59','2018-12-02 23:59:59','DGDETH','4h','0.159490000000000','0.158170000000000','0.072144500000000','0.071547404633519','0.4523449746065584','0.452344974606558','test'),('2019-01-07 19:59:59','2019-01-08 15:59:59','DGDETH','4h','0.138840000000000','0.136820000000000','0.072144500000000','0.071094860919044','0.5196233074042064','0.519623307404206','test'),('2019-01-08 23:59:59','2019-01-09 11:59:59','DGDETH','4h','0.136850000000000','0.136800000000000','0.072144500000000','0.072118141030325','0.5271793934965291','0.527179393496529','test'),('2019-01-10 19:59:59','2019-01-10 23:59:59','DGDETH','4h','0.137900000000000','0.139690000000000','0.072144500000000','0.073080965953590','0.5231653372008702','0.523165337200870','test'),('2019-01-11 07:59:59','2019-01-14 15:59:59','DGDETH','4h','0.139010000000000','0.133510000000000','0.072144500000000','0.069290066865693','0.5189878426012517','0.518987842601252','test'),('2019-01-16 15:59:59','2019-01-27 23:59:59','DGDETH','4h','0.147240000000000','0.157990000000000','0.072144500000000','0.077411773668840','0.4899789459386036','0.489978945938604','test'),('2019-02-28 07:59:59','2019-02-28 15:59:59','DGDETH','4h','0.117830000000000','0.114180000000000','0.072144500000000','0.069909692013918','0.6122761605703132','0.612276160570313','test'),('2019-02-28 23:59:59','2019-03-01 07:59:59','DGDETH','4h','0.114140000000000','0.114180000000000','0.072144500000000','0.072169782810583','0.6320702645873488','0.632070264587349','test'),('2019-03-01 11:59:59','2019-03-03 23:59:59','DGDETH','4h','0.114520000000000','0.118980000000000','0.072144500000000','0.074954179269997','0.6299729304924904','0.629972930492490','test'),('2019-03-04 03:59:59','2019-03-04 11:59:59','DGDETH','4h','0.124730000000000','0.120400000000000','0.072144500000000','0.069640004810390','0.578405355568027','0.578405355568027','test'),('2019-03-04 15:59:59','2019-03-05 07:59:59','DGDETH','4h','0.120850000000000','0.117590000000000','0.072144500000000','0.070198359577989','0.5969755895738519','0.596975589573852','test'),('2019-03-10 23:59:59','2019-03-16 07:59:59','DGDETH','4h','0.117050000000000','0.121530000000000','0.072144500000000','0.074905776035882','0.6163562580093976','0.616356258009398','test'),('2019-03-20 19:59:59','2019-03-21 11:59:59','DGDETH','4h','0.128840000000000','0.122290000000000','0.072144500000000','0.068476799945669','0.5599542067680844','0.559954206768084','test'),('2019-03-21 15:59:59','2019-03-26 11:59:59','DGDETH','4h','0.123240000000000','0.131800000000000','0.072144500000000','0.077155510386238','0.5853984096072704','0.585398409607270','test'),('2019-03-27 11:59:59','2019-03-30 11:59:59','DGDETH','4h','0.137400000000000','0.137610000000000','0.072144500000000','0.072254764519651','0.5250691411935954','0.525069141193595','test'),('2019-04-19 03:59:59','2019-04-24 23:59:59','DGDETH','4h','0.143830000000000','0.174590000000000','0.072144500000000','0.087573581693666','0.5015956337342696','0.501595633734270','test'),('2019-04-26 15:59:59','2019-04-29 19:59:59','DGDETH','4h','0.198300000000000','0.184810000000000','0.072144500000000','0.067236636636409','0.36381492687846695','0.363814926878467','test'),('2019-05-04 03:59:59','2019-05-06 03:59:59','DGDETH','4h','0.187270000000000','0.183360000000000','0.072144500000000','0.070638198964063','0.38524323169754904','0.385243231697549','test'),('2019-05-08 19:59:59','2019-05-11 03:59:59','DGDETH','4h','0.194560000000000','0.190790000000000','0.072144500000000','0.070746551989104','0.37080849095394736','0.370808490953947','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  7:35:13
