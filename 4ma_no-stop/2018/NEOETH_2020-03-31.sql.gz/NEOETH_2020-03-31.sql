-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-20 11:59:59','2018-03-23 03:59:59','NEOETH','4h','0.130670000000000','0.127199000000000','0.072144500000000','0.070228118584985','0.5521121910155353','0.552112191015535','test'),('2018-03-28 19:59:59','2018-03-31 03:59:59','NEOETH','4h','0.127351000000000','0.126602000000000','0.072144500000000','0.071720190567801','0.566501244591719','0.566501244591719','test'),('2018-04-03 07:59:59','2018-04-04 03:59:59','NEOETH','4h','0.130604000000000','0.127494000000000','0.072144500000000','0.070426563374782','0.5523911978193624','0.552391197819362','test'),('2018-04-04 11:59:59','2018-04-04 15:59:59','NEOETH','4h','0.127309000000000','0.125720000000000','0.072144500000000','0.071244032550723','0.5666881367381724','0.566688136738172','test'),('2018-04-09 23:59:59','2018-04-10 11:59:59','NEOETH','4h','0.132510000000000','0.126206000000000','0.072144500000000','0.068712314293261','0.544445702211154','0.544445702211154','test'),('2018-04-10 15:59:59','2018-04-11 03:59:59','NEOETH','4h','0.126990000000000','0.129430000000000','0.072144500000000','0.073530692456099','0.568111662335617','0.568111662335617','test'),('2018-04-11 07:59:59','2018-04-13 11:59:59','NEOETH','4h','0.129967000000000','0.130199000000000','0.072144500000000','0.072273282875653','0.5550986019528034','0.555098601952803','test'),('2018-04-15 19:59:59','2018-04-16 15:59:59','NEOETH','4h','0.132489000000000','0.129224000000000','0.072144500000000','0.070366603023647','0.5445319988829261','0.544531998882926','test'),('2018-04-16 23:59:59','2018-04-19 19:59:59','NEOETH','4h','0.130434000000000','0.131250000000000','0.072144500000000','0.072595838700032','0.5531111520002454','0.553111152000245','test'),('2018-04-30 11:59:59','2018-05-02 23:59:59','NEOETH','4h','0.127538000000000','0.123010000000000','0.072144500000000','0.069583143416080','0.5656706236572628','0.565670623657263','test'),('2018-05-25 19:59:59','2018-05-25 23:59:59','NEOETH','4h','0.090067000000000','0.090200000000000','0.072144500000000','0.072251034230073','0.8010092486704343','0.801009248670434','test'),('2018-05-27 19:59:59','2018-05-31 03:59:59','NEOETH','4h','0.092615000000000','0.091967000000000','0.072144500000000','0.071639726086487','0.7789720887545214','0.778972088754521','test'),('2018-05-31 07:59:59','2018-05-31 11:59:59','NEOETH','4h','0.093000000000000','0.092024000000000','0.072144500000000','0.071387370623656','0.775747311827957','0.775747311827957','test'),('2018-05-31 15:59:59','2018-05-31 23:59:59','NEOETH','4h','0.093019000000000','0.091654000000000','0.072144500000000','0.071085821208570','0.7755888581902621','0.775588858190262','test'),('2018-06-01 03:59:59','2018-06-03 11:59:59','NEOETH','4h','0.092678000000000','0.092600000000000','0.072144500000000','0.072083781479963','0.7784425645784329','0.778442564578433','test'),('2018-07-02 19:59:59','2018-07-06 19:59:59','NEOETH','4h','0.076561000000000','0.079554000000000','0.072144500000000','0.074964845717794','0.9423139718655712','0.942313971865571','test'),('2018-07-17 23:59:59','2018-07-19 19:59:59','NEOETH','4h','0.078643000000000','0.076732000000000','0.072144500000000','0.070391411492441','0.9173670892514273','0.917367089251427','test'),('2018-08-18 11:59:59','2018-08-22 19:59:59','NEOETH','4h','0.062812000000000','0.061703000000000','0.072144500000000','0.070870726668471','1.1485782971406737','1.148578297140674','test'),('2018-08-24 07:59:59','2018-08-25 23:59:59','NEOETH','4h','0.063882000000000','0.063471000000000','0.072144500000000','0.071680341246360','1.1293400331861871','1.129340033186187','test'),('2018-08-26 07:59:59','2018-08-26 11:59:59','NEOETH','4h','0.063196000000000','0.063274000000000','0.072144500000000','0.072233544733844','1.1415991518450535','1.141599151845053','test'),('2018-08-26 19:59:59','2018-08-30 07:59:59','NEOETH','4h','0.063654000000000','0.068372000000000','0.072144500000000','0.077491811260879','1.1333851761083356','1.133385176108336','test'),('2018-08-31 11:59:59','2018-09-13 15:59:59','NEOETH','4h','0.070581000000000','0.089318000000000','0.072144500000000','0.091296559286494','1.0221518538983578','1.022151853898358','test'),('2018-09-27 03:59:59','2018-09-27 11:59:59','NEOETH','4h','0.083085000000000','0.083055000000000','0.074864188469524','0.074837156807322','0.9010554067463891','0.901055406746389','test'),('2018-09-27 15:59:59','2018-09-27 23:59:59','NEOETH','4h','0.084933000000000','0.083110000000000','0.074864188469524','0.073257305213546','0.8814499484243346','0.881449948424335','test'),('2018-09-28 03:59:59','2018-09-29 11:59:59','NEOETH','4h','0.087223000000000','0.082054000000000','0.074864188469524','0.070427595022853','0.8583078828924023','0.858307882892402','test'),('2018-10-18 11:59:59','2018-10-21 07:59:59','NEOETH','4h','0.084035000000000','0.080962000000000','0.074864188469524','0.072126547591713','0.8908691434464687','0.890869143446469','test'),('2018-10-21 11:59:59','2018-10-21 23:59:59','NEOETH','4h','0.081450000000000','0.080802000000000','0.074864188469524','0.074268583876175','0.919142890970215','0.919142890970215','test'),('2018-10-22 15:59:59','2018-10-24 11:59:59','NEOETH','4h','0.083270000000000','0.081900000000000','0.074864188469524','0.073632485116537','0.8990535423264562','0.899053542326456','test'),('2018-10-24 15:59:59','2018-10-25 19:59:59','NEOETH','4h','0.082282000000000','0.081768000000000','0.074864188469524','0.074396526126930','0.9098489155529035','0.909848915552903','test'),('2018-11-03 19:59:59','2018-11-04 07:59:59','NEOETH','4h','0.080233000000000','0.080180000000000','0.074864188469524','0.074814734977957','0.9330847465447385','0.933084746544738','test'),('2018-11-04 11:59:59','2018-11-04 19:59:59','NEOETH','4h','0.082104000000000','0.078572000000000','0.074864188469524','0.071643635102156','0.9118214516896133','0.911821451689613','test'),('2018-11-04 23:59:59','2018-11-05 03:59:59','NEOETH','4h','0.079510000000000','0.079239000000000','0.074864188469524','0.074609023143461','0.9415694688658534','0.941569468865853','test'),('2018-11-29 19:59:59','2018-11-30 11:59:59','NEOETH','4h','0.070563000000000','0.067248000000000','0.074864188469524','0.071347121667142','1.0609552948361607','1.060955294836161','test'),('2018-11-30 15:59:59','2018-11-30 23:59:59','NEOETH','4h','0.068734000000000','0.068295000000000','0.074864188469524','0.074386035317691','1.089187134016993','1.089187134016993','test'),('2018-12-02 03:59:59','2018-12-02 11:59:59','NEOETH','4h','0.069911000000000','0.068938000000000','0.074864188469524','0.073822251501367','1.0708499158862554','1.070849915886255','test'),('2018-12-02 19:59:59','2018-12-02 23:59:59','NEOETH','4h','0.069300000000000','0.068643000000000','0.074864188469524','0.074154437072345','1.0802913199065511','1.080291319906551','test'),('2018-12-04 23:59:59','2018-12-05 03:59:59','NEOETH','4h','0.069398000000000','0.067413000000000','0.074864188469524','0.072722838371365','1.078765792523185','1.078765792523185','test'),('2018-12-17 07:59:59','2018-12-18 15:59:59','NEOETH','4h','0.069519000000000','0.068757000000000','0.074864188469524','0.074043599686403','1.0768881668252421','1.076888166825242','test'),('2018-12-18 19:59:59','2018-12-18 23:59:59','NEOETH','4h','0.068981000000000','0.067159000000000','0.074864188469524','0.072886795399092','1.0852870858573231','1.085287085857323','test'),('2018-12-19 03:59:59','2018-12-19 07:59:59','NEOETH','4h','0.068080000000000','0.068097000000000','0.074864188469524','0.074882882523637','1.0996502419142773','1.099650241914277','test'),('2019-01-08 11:59:59','2019-01-12 19:59:59','NEOETH','4h','0.060018000000000','0.061041000000000','0.074864188469524','0.076140240067450','1.247362265812323','1.247362265812323','test'),('2019-01-14 07:59:59','2019-01-14 15:59:59','NEOETH','4h','0.062180000000000','0.060630000000000','0.074864188469524','0.072998001719319','1.20399145174532','1.203991451745320','test'),('2019-01-16 07:59:59','2019-01-26 19:59:59','NEOETH','4h','0.061926000000000','0.064400000000000','0.074864188469524','0.077855080861631','1.2089298270439557','1.208929827043956','test'),('2019-01-27 19:59:59','2019-01-30 15:59:59','NEOETH','4h','0.065865000000000','0.064989000000000','0.074864188469524','0.073868499877718','1.1366308125639413','1.136630812563941','test'),('2019-02-02 11:59:59','2019-02-03 03:59:59','NEOETH','4h','0.065786000000000','0.064701000000000','0.074864188469524','0.073629463079784','1.137995750912413','1.137995750912413','test'),('2019-02-03 07:59:59','2019-02-03 19:59:59','NEOETH','4h','0.065220000000000','0.065636000000000','0.074864188469524','0.075341703072457','1.1478716416670347','1.147871641667035','test'),('2019-02-04 07:59:59','2019-02-04 23:59:59','NEOETH','4h','0.065472000000000','0.065574000000000','0.074864188469524','0.074980820727953','1.1434535140139908','1.143453514013991','test'),('2019-02-05 03:59:59','2019-02-05 15:59:59','NEOETH','4h','0.065846000000000','0.065455000000000','0.074864188469524','0.074419637582734','1.1369587897446163','1.136958789744616','test'),('2019-02-05 19:59:59','2019-02-05 23:59:59','NEOETH','4h','0.065470000000000','0.065144000000000','0.074864188469524','0.074491411236577','1.1434884446238582','1.143488444623858','test'),('2019-02-06 03:59:59','2019-02-06 19:59:59','NEOETH','4h','0.065760000000000','0.065665000000000','0.074864188469524','0.074756036129126','1.1384456884051704','1.138445688405170','test'),('2019-02-06 23:59:59','2019-02-07 03:59:59','NEOETH','4h','0.065744000000000','0.065463000000000','0.074864188469524','0.074544207376802','1.1387227499014967','1.138722749901497','test'),('2019-02-07 11:59:59','2019-02-08 07:59:59','NEOETH','4h','0.065836000000000','0.065477000000000','0.074864188469524','0.074455958266283','1.137131485350325','1.137131485350325','test'),('2019-02-08 15:59:59','2019-02-08 19:59:59','NEOETH','4h','0.066111000000000','0.063684000000000','0.074864188469524','0.072115850289561','1.1324013926506027','1.132401392650603','test'),('2019-02-11 23:59:59','2019-02-14 03:59:59','NEOETH','4h','0.067300000000000','0.065188000000000','0.074864188469524','0.072514810073571','1.112395073841367','1.112395073841367','test'),('2019-02-15 23:59:59','2019-02-16 11:59:59','NEOETH','4h','0.066809000000000','0.065380000000000','0.074864188469524','0.073262893354750','1.1205704092191773','1.120570409219177','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','NEOETH','4h','0.069361000000000','0.065851000000000','0.074864188469524','0.071075700680593','1.0793412504076354','1.079341250407635','test'),('2019-02-25 15:59:59','2019-02-28 11:59:59','NEOETH','4h','0.065229000000000','0.065151000000000','0.074864188469524','0.074774666834965','1.1477132635717857','1.147713263571786','test'),('2019-03-01 23:59:59','2019-03-03 11:59:59','NEOETH','4h','0.066129000000000','0.065462000000000','0.074864188469524','0.074109082332895','1.1320931583650744','1.132093158365074','test'),('2019-03-03 15:59:59','2019-03-04 07:59:59','NEOETH','4h','0.066136000000000','0.065534000000000','0.074864188469524','0.074182740521982','1.1319733347877707','1.131973334787771','test'),('2019-03-08 15:59:59','2019-03-10 07:59:59','NEOETH','4h','0.066041000000000','0.064946000000000','0.074864188469524','0.073622894631240','1.1336016787983827','1.133601678798383','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','NEOETH','4h','0.065758000000000','0.064940000000000','0.074864188469524','0.073932911572902','1.138480313718848','1.138480313718848','test'),('2019-03-12 11:59:59','2019-03-12 23:59:59','NEOETH','4h','0.065990000000000','0.066138000000000','0.074864188469524','0.075032091180442','1.1344777764740719','1.134477776474072','test'),('2019-03-13 03:59:59','2019-03-15 03:59:59','NEOETH','4h','0.066897000000000','0.068776000000000','0.074864188469524','0.076966970509589','1.1190963491565242','1.119096349156524','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  9:02:27
