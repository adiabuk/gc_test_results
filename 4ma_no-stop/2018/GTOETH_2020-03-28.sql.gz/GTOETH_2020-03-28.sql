-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-30 11:59:59','2018-07-05 19:59:59','GTOETH','4h','0.000333690000000','0.000332100000000','0.072144500000000','0.071800738559741','216.20216368485723','216.202163684857226','test'),('2018-07-11 07:59:59','2018-07-12 03:59:59','GTOETH','4h','0.000347990000000','0.000326350000000','0.072144500000000','0.067658144127705','207.31773901548894','207.317739015488939','test'),('2018-07-12 11:59:59','2018-07-12 15:59:59','GTOETH','4h','0.000327100000000','0.000323850000000','0.072144500000000','0.071427686716600','220.55793335371447','220.557933353714475','test'),('2018-07-12 19:59:59','2018-07-12 23:59:59','GTOETH','4h','0.000334160000000','0.000338960000000','0.072144500000000','0.073180810749342','215.8980727795068','215.898072779506805','test'),('2018-07-13 07:59:59','2018-07-13 23:59:59','GTOETH','4h','0.000337090000000','0.000335010000000','0.072144500000000','0.071699335325877','214.0214779435759','214.021477943575889','test'),('2018-07-14 03:59:59','2018-07-19 23:59:59','GTOETH','4h','0.000345360000000','0.000392480000000','0.072144500000000','0.081987703729442','208.89651378271947','208.896513782719467','test'),('2018-08-19 07:59:59','2018-08-22 19:59:59','GTOETH','4h','0.000285870000000','0.000282460000000','0.073366354802177','0.072491204314629','256.6423717150339','256.642371715033903','test'),('2018-08-24 03:59:59','2018-08-29 15:59:59','GTOETH','4h','0.000297400000000','0.000305350000000','0.073366354802177','0.075327560318913','246.69251782843642','246.692517828436422','test'),('2018-09-02 07:59:59','2018-09-02 11:59:59','GTOETH','4h','0.000310540000000','0.000303530000000','0.073637868559474','0.071975598131826','237.12844902258567','237.128449022585670','test'),('2018-09-03 23:59:59','2018-09-05 11:59:59','GTOETH','4h','0.000307950000000','0.000299160000000','0.073637868559474','0.071535979081839','239.1228074670369','239.122807467036893','test'),('2018-09-05 15:59:59','2018-09-05 19:59:59','GTOETH','4h','0.000305670000000','0.000310710000000','0.073637868559474','0.074852036968345','240.90643033164523','240.906430331645225','test'),('2018-09-05 23:59:59','2018-09-06 03:59:59','GTOETH','4h','0.000313870000000','0.000302780000000','0.073637868559474','0.071036014408633','234.6126375871348','234.612637587134799','test'),('2018-09-07 03:59:59','2018-09-10 03:59:59','GTOETH','4h','0.000311290000000','0.000316000000000','0.073637868559474','0.074752052635143','236.55712859222592','236.557128592225922','test'),('2018-09-10 07:59:59','2018-09-10 23:59:59','GTOETH','4h','0.000320610000000','0.000312580000000','0.073637868559474','0.071793534057953','229.680510774692','229.680510774692010','test'),('2018-09-11 07:59:59','2018-09-11 15:59:59','GTOETH','4h','0.000319250000000','0.000312000000000','0.073637868559474','0.071965591199862','230.65894615340332','230.658946153403321','test'),('2018-09-25 19:59:59','2018-09-29 11:59:59','GTOETH','4h','0.000304260000000','0.000295910000000','0.073637868559474','0.071616977865753','242.0228375713995','242.022837571399492','test'),('2018-10-03 07:59:59','2018-10-03 11:59:59','GTOETH','4h','0.000296190000000','0.000296280000000','0.073637868559474','0.073660244089270','248.6169977361626','248.616997736162602','test'),('2018-10-03 15:59:59','2018-10-03 19:59:59','GTOETH','4h','0.000297450000000','0.000297740000000','0.073637868559474','0.073709662077316','247.56385462926207','247.563854629262067','test'),('2018-10-04 03:59:59','2018-10-04 07:59:59','GTOETH','4h','0.000295500000000','0.000296940000000','0.073637868559474','0.073996712995094','249.1975247359526','249.197524735952612','test'),('2018-10-04 15:59:59','2018-10-05 11:59:59','GTOETH','4h','0.000297970000000','0.000294850000000','0.073637868559474','0.072866817279461','247.13182051707892','247.131820517078921','test'),('2018-10-05 15:59:59','2018-10-05 23:59:59','GTOETH','4h','0.000297900000000','0.000297060000000','0.073637868559474','0.073430229050948','247.18989110263178','247.189891102631776','test'),('2018-10-06 03:59:59','2018-10-07 15:59:59','GTOETH','4h','0.000302690000000','0.000299800000000','0.073637868559474','0.072934794655028','243.27816762851103','243.278167628511028','test'),('2018-10-07 19:59:59','2018-10-08 07:59:59','GTOETH','4h','0.000302010000000','0.000299620000000','0.073637868559474','0.073055124591204','243.8259281463329','243.825928146332899','test'),('2018-10-08 11:59:59','2018-10-08 15:59:59','GTOETH','4h','0.000301900000000','0.000303040000000','0.073637868559474','0.073915931395373','243.9147683321431','243.914768332143097','test'),('2018-10-08 23:59:59','2018-10-13 11:59:59','GTOETH','4h','0.000301260000000','0.000317860000000','0.073637868559474','0.077695455421611','244.43294350220407','244.432943502204068','test'),('2018-10-13 19:59:59','2018-10-14 15:59:59','GTOETH','4h','0.000326490000000','0.000320130000000','0.073637868559474','0.072203408563645','225.5440245014365','225.544024501436496','test'),('2018-10-14 19:59:59','2018-10-15 07:59:59','GTOETH','4h','0.000321820000000','0.000310130000000','0.073637868559474','0.070962998497140','228.81694288569386','228.816942885693862','test'),('2018-10-15 23:59:59','2018-10-20 11:59:59','GTOETH','4h','0.000341050000000','0.000344290000000','0.073637868559474','0.074337433708668','215.91516950439524','215.915169504395237','test'),('2018-10-20 19:59:59','2018-10-23 19:59:59','GTOETH','4h','0.000352560000000','0.000355750000000','0.073637868559474','0.074304151747314','208.8662030845076','208.866203084507589','test'),('2018-11-28 23:59:59','2018-11-30 11:59:59','GTOETH','4h','0.000269170000000','0.000258210000000','0.073637868559474','0.070639499352609','273.5738327431512','273.573832743151172','test'),('2018-11-30 15:59:59','2018-11-30 19:59:59','GTOETH','4h','0.000258840000000','0.000262820000000','0.073637868559474','0.074770146093343','284.49184268070627','284.491842680706270','test'),('2018-11-30 23:59:59','2018-12-03 15:59:59','GTOETH','4h','0.000267110000000','0.000271110000000','0.073637868559474','0.074740603291374','275.68368297508147','275.683682975081467','test'),('2018-12-05 07:59:59','2018-12-06 15:59:59','GTOETH','4h','0.000294050000000','0.000265410000000','0.073637868559474','0.066465657862166','250.42635116297907','250.426351162979074','test'),('2019-01-10 03:59:59','2019-01-11 03:59:59','GTOETH','4h','0.000181780000000','0.000180500000000','0.073637868559474','0.073119349075724','405.09334667990976','405.093346679909757','test'),('2019-01-11 11:59:59','2019-01-14 15:59:59','GTOETH','4h','0.000188000000000','0.000180230000000','0.073637868559474','0.070594431119543','391.69079020996816','391.690790209968156','test'),('2019-01-15 03:59:59','2019-01-18 11:59:59','GTOETH','4h','0.000203220000000','0.000233080000000','0.073637868559474','0.084457801416407','362.35542052688714','362.355420526887144','test'),('2019-01-22 07:59:59','2019-01-23 23:59:59','GTOETH','4h','0.000244840000000','0.000233570000000','0.073637868559474','0.070248313018446','300.75914294834996','300.759142948349961','test'),('2019-01-25 03:59:59','2019-01-27 03:59:59','GTOETH','4h','0.000253530000000','0.000240590000000','0.073637868559474','0.069879441473293','290.45031577909515','290.450315779095149','test'),('2019-02-08 07:59:59','2019-02-08 19:59:59','GTOETH','4h','0.000276340000000','0.000234440000000','0.073637868559474','0.062472540729113','266.4756045432222','266.475604543222175','test'),('2019-02-09 07:59:59','2019-02-10 07:59:59','GTOETH','4h','0.000233680000000','0.000228960000000','0.073637868559474','0.072150489495794','315.1226829830281','315.122682983028085','test'),('2019-02-10 11:59:59','2019-02-10 19:59:59','GTOETH','4h','0.000239690000000','0.000230900000000','0.073637868559474','0.070937393509878','307.22127981757274','307.221279817572736','test'),('2019-02-27 11:59:59','2019-03-04 07:59:59','GTOETH','4h','0.000220240000000','0.000226940000000','0.073637868559474','0.075878032559422','334.35283581308573','334.352835813085733','test'),('2019-03-04 15:59:59','2019-03-05 03:59:59','GTOETH','4h','0.000227880000000','0.000226280000000','0.073637868559474','0.073120839466552','323.1431830765052','323.143183076505181','test'),('2019-03-08 11:59:59','2019-03-08 23:59:59','GTOETH','4h','0.000224930000000','0.000225080000000','0.073637868559474','0.073686975749639','327.3812677698573','327.381267769857288','test'),('2019-03-09 03:59:59','2019-03-15 15:59:59','GTOETH','4h','0.000225880000000','0.000263550000000','0.073637868559474','0.085918453421504','326.00437648075973','326.004376480759731','test'),('2019-03-19 07:59:59','2019-03-21 15:59:59','GTOETH','4h','0.000268170000000','0.000250300000000','0.073637868559474','0.068730874074044','274.5939835159563','274.593983515956324','test'),('2019-03-25 19:59:59','2019-03-26 03:59:59','GTOETH','4h','0.000257000000000','0.000254690000000','0.073637868559474','0.072975987328453','286.528671437642','286.528671437642004','test'),('2019-03-29 15:59:59','2019-03-29 23:59:59','GTOETH','4h','0.000257580000000','0.000254670000000','0.073637868559474','0.072805947612552','285.88348691464404','285.883486914644038','test'),('2019-03-31 11:59:59','2019-04-02 07:59:59','GTOETH','4h','0.000262240000000','0.000253830000000','0.073637868559474','0.071276312448335','280.80334258493747','280.803342584937468','test'),('2019-04-19 19:59:59','2019-04-21 03:59:59','GTOETH','4h','0.000238400000000','0.000214420000000','0.073637868559474','0.066230837988769','308.88367684343126','308.883676843431260','test'),('2019-04-24 03:59:59','2019-04-24 11:59:59','GTOETH','4h','0.000219130000000','0.000217920000000','0.073637868559474','0.073231252299916','336.046495502551','336.046495502551011','test'),('2019-05-22 03:59:59','2019-05-22 11:59:59','GTOETH','4h','0.000136650000000','0.000125170000000','0.073637868559474','0.067451533169333','538.8793893851007','538.879389385100694','test'),('2019-05-22 15:59:59','2019-05-23 03:59:59','GTOETH','4h','0.000127800000000','0.000130730000000','0.073637868559474','0.075326123292489','576.1961546124727','576.196154612472696','test'),('2019-05-23 07:59:59','2019-05-24 19:59:59','GTOETH','4h','0.000131320000000','0.000129150000000','0.073637868559474','0.072421038108864','560.751359727947','560.751359727947033','test'),('2019-05-25 15:59:59','2019-05-27 03:59:59','GTOETH','4h','0.000137160000000','0.000134820000000','0.073637868559474','0.072381579463315','536.875682119233','536.875682119233034','test'),('2019-05-27 07:59:59','2019-05-27 15:59:59','GTOETH','4h','0.000138480000000','0.000130170000000','0.073637868559474','0.069218958336126','531.7581496206963','531.758149620696258','test'),('2019-05-28 03:59:59','2019-05-30 03:59:59','GTOETH','4h','0.000144250000000','0.000133510000000','0.073637868559474','0.068155229333625','510.48782363586827','510.487823635868267','test'),('2019-05-30 11:59:59','2019-06-01 11:59:59','GTOETH','4h','0.000160640000000','0.000144090000000','0.073637868559474','0.066051297813338','458.4030662317854','458.403066231785374','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 21:44:42
