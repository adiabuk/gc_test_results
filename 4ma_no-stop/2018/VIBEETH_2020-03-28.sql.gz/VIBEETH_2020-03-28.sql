-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-02 03:59:59','2018-07-02 07:59:59','VIBEETH','4h','0.000181600000000','0.000174300000000','0.072144500000000','0.069244418226872','397.2714757709251','397.271475770925122','test'),('2018-07-02 15:59:59','2018-07-03 23:59:59','VIBEETH','4h','0.000181900000000','0.000172100000000','0.072144500000000','0.068257660527763','396.6162726772952','396.616272677295228','test'),('2018-07-04 15:59:59','2018-07-05 11:59:59','VIBEETH','4h','0.000177000000000','0.000175000000000','0.072144500000000','0.071329307909605','407.5960451977401','407.596045197740125','test'),('2018-07-18 11:59:59','2018-07-19 19:59:59','VIBEETH','4h','0.000173400000000','0.000164500000000','0.072144500000000','0.068441581603230','416.058246828143','416.058246828143012','test'),('2018-08-18 23:59:59','2018-08-19 03:59:59','VIBEETH','4h','0.000105200000000','0.000103700000000','0.072144500000000','0.071115823669202','685.7842205323194','685.784220532319409','test'),('2018-08-19 15:59:59','2018-08-20 23:59:59','VIBEETH','4h','0.000106000000000','0.000105700000000','0.072144500000000','0.071940317452830','680.6084905660377','680.608490566037744','test'),('2018-08-22 07:59:59','2018-08-22 15:59:59','VIBEETH','4h','0.000108500000000','0.000105500000000','0.072144500000000','0.070149721198157','664.926267281106','664.926267281105993','test'),('2018-08-24 07:59:59','2018-09-02 15:59:59','VIBEETH','4h','0.000107700000000','0.000130300000000','0.072144500000000','0.087283457288765','669.8653667595172','669.865366759517201','test'),('2018-09-04 03:59:59','2018-09-05 11:59:59','VIBEETH','4h','0.000133500000000','0.000129800000000','0.072296071969106','0.070292360611161','541.5436102554756','541.543610255475642','test'),('2018-09-05 15:59:59','2018-09-05 19:59:59','VIBEETH','4h','0.000133100000000','0.000132900000000','0.072296071969106','0.072187437751271','543.1710891743501','543.171089174350072','test'),('2018-09-08 15:59:59','2018-09-09 11:59:59','VIBEETH','4h','0.000135000000000','0.000134200000000','0.072296071969106','0.071867650801882','535.5264590304148','535.526459030414799','test'),('2018-09-09 15:59:59','2018-09-12 03:59:59','VIBEETH','4h','0.000136400000000','0.000147100000000','0.072296071969106','0.077967391397768','530.0298531459383','530.029853145938318','test'),('2018-09-12 07:59:59','2018-09-13 15:59:59','VIBEETH','4h','0.000152200000000','0.000146900000000','0.073078710140521','0.070533919314340','480.1492124869941','480.149212486994088','test'),('2018-09-15 11:59:59','2018-09-15 19:59:59','VIBEETH','4h','0.000154200000000','0.000154000000000','0.073078710140521','0.072983925821273','473.9215962420298','473.921596242029807','test'),('2018-09-15 23:59:59','2018-09-18 19:59:59','VIBEETH','4h','0.000292200000000','0.000281800000000','0.073078710140521','0.070477688287470','250.09825510103013','250.098255101030134','test'),('2018-09-20 15:59:59','2018-09-21 19:59:59','VIBEETH','4h','0.000400000000000','0.000313300000000','0.073078710140521','0.057238899717563','182.6967753513025','182.696775351302506','test'),('2018-09-22 07:59:59','2018-09-22 15:59:59','VIBEETH','4h','0.000318500000000','0.000447100000000','0.073078710140521','0.102585529996317','229.4464996562669','229.446499656266894','test'),('2018-09-22 23:59:59','2018-09-26 19:59:59','VIBEETH','4h','0.000410600000000','0.000390200000000','0.075185313249110','0.071449851996597','183.11084571142231','183.110845711422314','test'),('2018-10-10 23:59:59','2018-10-11 03:59:59','VIBEETH','4h','0.000350400000000','0.000358100000000','0.075185313249110','0.076837501924961','214.5699579027112','214.569957902711195','test'),('2018-10-11 11:59:59','2018-10-11 15:59:59','VIBEETH','4h','0.000340200000000','0.000343300000000','0.075185313249110','0.075870423393355','221.00327233718403','221.003272337184029','test'),('2018-10-12 07:59:59','2018-10-12 11:59:59','VIBEETH','4h','0.000350100000000','0.000337700000000','0.075185313249110','0.072522365850398','214.7538224767495','214.753822476749491','test'),('2018-10-14 15:59:59','2018-10-15 07:59:59','VIBEETH','4h','0.000362000000000','0.000337300000000','0.075185313249110','0.070055265632389','207.694235494779','207.694235494779008','test'),('2018-10-15 11:59:59','2018-10-15 19:59:59','VIBEETH','4h','0.000349100000000','0.000342900000000','0.075185313249110','0.073850025531710','215.36898667748497','215.368986677484969','test'),('2018-10-16 11:59:59','2018-10-16 15:59:59','VIBEETH','4h','0.000348600000000','0.000350000000000','0.075185313249110','0.075487262298303','215.6778922808663','215.677892280866303','test'),('2018-10-17 07:59:59','2018-10-18 19:59:59','VIBEETH','4h','0.000349600000000','0.000350000000000','0.075185313249110','0.075271337634979','215.0609646713673','215.060964671367287','test'),('2018-10-19 03:59:59','2018-10-19 15:59:59','VIBEETH','4h','0.000353100000000','0.000349800000000','0.075185313249110','0.074482646770146','212.92923604958935','212.929236049589349','test'),('2018-10-19 23:59:59','2018-10-20 03:59:59','VIBEETH','4h','0.000353000000000','0.000350200000000','0.075185313249110','0.074588942492460','212.98955594648723','212.989555946487229','test'),('2018-10-20 11:59:59','2018-10-21 23:59:59','VIBEETH','4h','0.000354500000000','0.000362900000000','0.075185313249110','0.076966855227368','212.08833074502115','212.088330745021153','test'),('2018-10-22 07:59:59','2018-10-22 15:59:59','VIBEETH','4h','0.000364700000000','0.000358600000000','0.075185313249110','0.073927757968552','206.1566033701947','206.156603370194688','test'),('2018-10-22 23:59:59','2018-10-23 03:59:59','VIBEETH','4h','0.000369100000000','0.000360600000000','0.075185313249110','0.073453871464722','203.6990334573557','203.699033457355711','test'),('2018-10-23 11:59:59','2018-10-25 19:59:59','VIBEETH','4h','0.000366500000000','0.000367300000000','0.075185313249110','0.075349428530418','205.1441016346794','205.144101634679402','test'),('2018-11-28 11:59:59','2018-11-30 11:59:59','VIBEETH','4h','0.000246300000000','0.000242000000000','0.075185313249110','0.073872699172897','305.2590874913114','305.259087491311391','test'),('2018-11-30 15:59:59','2018-12-04 03:59:59','VIBEETH','4h','0.000250200000000','0.000278000000000','0.075185313249110','0.083539236943456','300.5008523145883','300.500852314588315','test'),('2018-12-07 03:59:59','2018-12-07 19:59:59','VIBEETH','4h','0.000283700000000','0.000259000000000','0.075185313249110','0.068639394189353','265.0169659820585','265.016965982058480','test'),('2018-12-18 19:59:59','2018-12-19 23:59:59','VIBEETH','4h','0.000268400000000','0.000268300000000','0.075185313249110','0.075157300837318','280.12411791769745','280.124117917697447','test'),('2018-12-20 07:59:59','2018-12-20 19:59:59','VIBEETH','4h','0.000265000000000','0.000270600000000','0.075185313249110','0.076774134963053','283.71816320418867','283.718163204188670','test'),('2018-12-21 03:59:59','2018-12-21 15:59:59','VIBEETH','4h','0.000265900000000','0.000264300000000','0.075185313249110','0.074732900683489','282.7578535130124','282.757853513012378','test'),('2019-01-06 19:59:59','2019-01-07 03:59:59','VIBEETH','4h','0.000215900000000','0.000210600000000','0.075185313249110','0.073339633952119','348.24137679069014','348.241376790690140','test'),('2019-01-07 15:59:59','2019-01-08 11:59:59','VIBEETH','4h','0.000212200000000','0.000218400000000','0.075185313249110','0.077382056614541','354.31344603727615','354.313446037276151','test'),('2019-01-08 15:59:59','2019-01-10 19:59:59','VIBEETH','4h','0.000229000000000','0.000218400000000','0.075185313249110','0.071705119710068','328.3201451926201','328.320145192620089','test'),('2019-01-11 11:59:59','2019-01-18 15:59:59','VIBEETH','4h','0.000228200000000','0.000325800000000','0.075185313249110','0.107341696128659','329.4711360609553','329.471136060955303','test'),('2019-01-20 23:59:59','2019-01-21 03:59:59','VIBEETH','4h','0.000345700000000','0.000327000000000','0.079722861232278','0.075410400992059','230.61284707051706','230.612847070517063','test'),('2019-01-21 11:59:59','2019-01-27 11:59:59','VIBEETH','4h','0.000339000000000','0.000343500000000','0.079722861232278','0.080781129301733','235.17068210111503','235.170682101115034','test'),('2019-02-28 03:59:59','2019-02-28 11:59:59','VIBEETH','4h','0.000275000000000','0.000266300000000','0.079722861232278','0.077200719804202','289.90131357191996','289.901313571919957','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','VIBEETH','4h','0.000269900000000','0.000269600000000','0.079722861232278','0.079634247455436','295.37925614034083','295.379256140340829','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','VIBEETH','4h','0.000270000000000','0.000268800000000','0.079722861232278','0.079368537404579','295.2698564158444','295.269856415844401','test'),('2019-03-01 07:59:59','2019-03-01 11:59:59','VIBEETH','4h','0.000269700000000','0.000267400000000','0.079722861232278','0.079042985144646','295.5982989702558','295.598298970255826','test'),('2019-03-01 15:59:59','2019-03-05 15:59:59','VIBEETH','4h','0.000272500000000','0.000290200000000','0.079722861232278','0.084901190200393','292.5609586505614','292.560958650561417','test'),('2019-03-06 03:59:59','2019-03-06 23:59:59','VIBEETH','4h','0.000288900000000','0.000282800000000','0.079722861232278','0.078039547097571','275.9531368372378','275.953136837237821','test'),('2019-03-08 23:59:59','2019-03-16 03:59:59','VIBEETH','4h','0.000285900000000','0.000307200000000','0.079722861232278','0.085662339876026','278.84876261727175','278.848762617271746','test'),('2019-03-17 19:59:59','2019-03-18 11:59:59','VIBEETH','4h','0.000316900000000','0.000321000000000','0.080356697778814','0.081396339498262','253.57115108492744','253.571151084927436','test'),('2019-03-18 15:59:59','2019-03-21 15:59:59','VIBEETH','4h','0.000328300000000','0.000312300000000','0.080616608208675','0.076687684263080','245.55774659968168','245.557746599681678','test'),('2019-03-26 19:59:59','2019-03-30 03:59:59','VIBEETH','4h','0.000328400000000','0.000324000000000','0.080616608208675','0.079536483129143','245.48297262081303','245.482972620813030','test'),('2019-03-30 23:59:59','2019-04-02 07:59:59','VIBEETH','4h','0.000336500000000','0.000329000000000','0.080616608208675','0.078819804162419','239.57387283410105','239.573872834101053','test'),('2019-04-02 11:59:59','2019-04-02 15:59:59','VIBEETH','4h','0.000355700000000','0.000335400000000','0.080616608208675','0.076015772823136','226.64213721865335','226.642137218653346','test'),('2019-05-05 07:59:59','2019-05-06 15:59:59','VIBEETH','4h','0.000240900000000','0.000238200000000','0.080616608208675','0.079713059673335','334.64760568150683','334.647605681506832','test'),('2019-05-23 11:59:59','2019-05-24 19:59:59','VIBEETH','4h','0.000203900000000','0.000189000000000','0.080616608208675','0.074725546598527','395.37326242606673','395.373262426066731','test'),('2019-05-29 19:59:59','2019-05-30 07:59:59','VIBEETH','4h','0.000189700000000','0.000184900000000','0.080616608208675','0.078576757289320','424.96894153228783','424.968941532287829','test'),('2019-05-30 11:59:59','2019-05-30 15:59:59','VIBEETH','4h','0.000187400000000','0.000176200000000','0.080616608208675','0.075798539841881','430.1846756065902','430.184675606590190','test'),('2019-05-30 19:59:59','2019-05-30 23:59:59','VIBEETH','4h','0.000185600000000','0.000184300000000','0.080616608208675','0.080051944465834','434.3567252622575','434.356725262257498','test'),('2019-05-31 07:59:59','2019-06-01 07:59:59','VIBEETH','4h','0.000186100000000','0.000184100000000','0.080616608208675','0.079750228754525','433.189727075094','433.189727075094027','test'),('2019-06-01 11:59:59','2019-06-04 03:59:59','VIBEETH','4h','0.000191100000000','0.000189400000000','0.080616608208675','0.079899453661554','421.8556159532967','421.855615953296706','test'),('2019-06-08 03:59:59','2019-06-09 23:59:59','VIBEETH','4h','0.000194000000000','0.000191000000000','0.080616608208675','0.079369959628128','415.54952684884023','415.549526848840230','test'),('2019-06-10 03:59:59','2019-06-12 11:59:59','VIBEETH','4h','0.000191500000000','0.000198900000000','0.080616608208675','0.083731819178619','420.9744553977807','420.974455397780673','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 20:40:02
