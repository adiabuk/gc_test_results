-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-15 19:59:59','2018-02-18 11:59:59','MCOETH','4h','0.009633000000000','0.009503000000000','0.072144500000000','0.071170890013495','7.489307588497873','7.489307588497873','test'),('2018-02-18 15:59:59','2018-02-18 19:59:59','MCOETH','4h','0.009559000000000','0.009652000000000','0.072144500000000','0.072846397531123','7.547285280887122','7.547285280887122','test'),('2018-02-19 11:59:59','2018-02-20 11:59:59','MCOETH','4h','0.010049000000000','0.009583000000000','0.072144500000000','0.068798959448701','7.179271569310378','7.179271569310378','test'),('2018-02-28 19:59:59','2018-02-28 23:59:59','MCOETH','4h','0.009038000000000','0.008700000000000','0.072144500000000','0.069446464925869','7.98235229032972','7.982352290329720','test'),('2018-03-01 11:59:59','2018-03-06 11:59:59','MCOETH','4h','0.009317000000000','0.010373000000000','0.072144500000000','0.080321444510035','7.743318664806267','7.743318664806267','test'),('2018-03-11 15:59:59','2018-03-14 15:59:59','MCOETH','4h','0.010850000000000','0.011564000000000','0.072609914107306','0.077388114906625','6.692157982240161','6.692157982240161','test'),('2018-03-19 11:59:59','2018-03-23 23:59:59','MCOETH','4h','0.011111000000000','0.011593000000000','0.073804464307135','0.077006133985475','6.642468212324318','6.642468212324318','test'),('2018-03-24 15:59:59','2018-03-25 11:59:59','MCOETH','4h','0.011919000000000','0.011754000000000','0.074604881726721','0.073572093280970','6.2593239136438035','6.259323913643803','test'),('2018-03-25 15:59:59','2018-03-29 15:59:59','MCOETH','4h','0.012071000000000','0.012215000000000','0.074604881726721','0.075494874516767','6.180505486432027','6.180505486432027','test'),('2018-04-03 07:59:59','2018-04-05 19:59:59','MCOETH','4h','0.013230000000000','0.012741000000000','0.074604881726721','0.071847377027978','5.639068913584354','5.639068913584354','test'),('2018-04-07 07:59:59','2018-04-09 03:59:59','MCOETH','4h','0.013137000000000','0.012899000000000','0.074604881726721','0.073253282286136','5.678989246153688','5.678989246153688','test'),('2018-04-11 23:59:59','2018-04-12 03:59:59','MCOETH','4h','0.012951000000000','0.012600000000000','0.074604881726721','0.072582928712585','5.760549897824183','5.760549897824183','test'),('2018-04-13 07:59:59','2018-04-21 11:59:59','MCOETH','4h','0.013277000000000','0.020613000000000','0.074604881726721','0.115826649622121','5.61910685597055','5.619106855970550','test'),('2018-05-16 07:59:59','2018-05-16 11:59:59','MCOETH','4h','0.015309000000000','0.014437000000000','0.083341860498278','0.078594711608442','5.443978084674261','5.443978084674261','test'),('2018-06-24 15:59:59','2018-07-08 07:59:59','MCOETH','4h','0.010508000000000','0.017251000000000','0.083341860498278','0.136822462452969','7.931277169611534','7.931277169611534','test'),('2018-07-09 07:59:59','2018-07-11 03:59:59','MCOETH','4h','0.018376000000000','0.017233000000000','0.095525223764492','0.089583488307221','5.198368729021115','5.198368729021115','test'),('2018-07-18 19:59:59','2018-07-18 23:59:59','MCOETH','4h','0.016394000000000','0.016337000000000','0.095525223764492','0.095193093853880','5.8268405370557526','5.826840537055753','test'),('2018-07-22 23:59:59','2018-07-24 03:59:59','MCOETH','4h','0.017505000000000','0.016018000000000','0.095525223764492','0.087410627492695','5.45702506509523','5.457025065095230','test'),('2018-07-30 07:59:59','2018-07-30 19:59:59','MCOETH','4h','0.016694000000000','0.016503000000000','0.095525223764492','0.094432297099881','5.722129134089613','5.722129134089613','test'),('2018-07-30 23:59:59','2018-07-31 15:59:59','MCOETH','4h','0.016533000000000','0.016188000000000','0.095525223764492','0.093531864894429','5.777851797283736','5.777851797283736','test'),('2018-08-01 15:59:59','2018-08-03 03:59:59','MCOETH','4h','0.016454000000000','0.016343000000000','0.095525223764492','0.094880802964817','5.805592789868239','5.805592789868239','test'),('2018-08-12 07:59:59','2018-08-14 23:59:59','MCOETH','4h','0.016389000000000','0.016617000000000','0.095525223764492','0.096854148715270','5.828618205167612','5.828618205167612','test'),('2018-08-27 15:59:59','2018-08-29 03:59:59','MCOETH','4h','0.016658000000000','0.015843000000000','0.095525223764492','0.090851610043273','5.734495363458519','5.734495363458519','test'),('2018-09-04 03:59:59','2018-09-13 15:59:59','MCOETH','4h','0.016441000000000','0.022026000000000','0.095525223764492','0.127975097538878','5.810183307857916','5.810183307857916','test'),('2018-09-26 15:59:59','2018-09-27 19:59:59','MCOETH','4h','0.020345000000000','0.019700000000000','0.098271728021971','0.095156207521889','4.830264341212632','4.830264341212632','test'),('2018-09-29 03:59:59','2018-09-29 11:59:59','MCOETH','4h','0.020267000000000','0.019280000000000','0.098271728021971','0.093485908928978','4.848854197561109','4.848854197561109','test'),('2018-10-02 19:59:59','2018-10-05 11:59:59','MCOETH','4h','0.020188000000000','0.020060000000000','0.098271728021971','0.097648645934255','4.8678288102819','4.867828810281900','test'),('2018-10-10 03:59:59','2018-10-15 07:59:59','MCOETH','4h','0.020441000000000','0.020349000000000','0.098271728021971','0.097829430728393','4.807579278018247','4.807579278018247','test'),('2018-10-18 07:59:59','2018-10-19 11:59:59','MCOETH','4h','0.021371000000000','0.021922000000000','0.098271728021971','0.100805428931620','4.5983682570759905','4.598368257075991','test'),('2018-10-19 19:59:59','2018-10-24 23:59:59','MCOETH','4h','0.021846000000000','0.024041000000000','0.098271728021971','0.108145684032601','4.498385426255195','4.498385426255195','test'),('2018-10-26 07:59:59','2018-10-26 11:59:59','MCOETH','4h','0.024710000000000','0.023843000000000','0.099131962508448','0.095653718417196','4.011815560843727','4.011815560843727','test'),('2018-11-16 23:59:59','2018-11-17 11:59:59','MCOETH','4h','0.021652000000000','0.020576000000000','0.099131962508448','0.094205581958887','4.578420585093663','4.578420585093663','test'),('2018-11-17 15:59:59','2018-11-17 19:59:59','MCOETH','4h','0.020874000000000','0.020814000000000','0.099131962508448','0.098847018666803','4.749064027423972','4.749064027423972','test'),('2018-11-18 07:59:59','2018-11-18 19:59:59','MCOETH','4h','0.021008000000000','0.020864000000000','0.099131962508448','0.098452459338169','4.718772015824829','4.718772015824829','test'),('2018-11-19 03:59:59','2018-11-19 11:59:59','MCOETH','4h','0.021616000000000','0.021145000000000','0.099131962508448','0.096971935013006','4.586045637881569','4.586045637881569','test'),('2018-12-01 03:59:59','2018-12-07 07:59:59','MCOETH','4h','0.020809000000000','0.022635000000000','0.099131962508448','0.107830841048523','4.763898433776154','4.763898433776154','test'),('2018-12-12 03:59:59','2018-12-12 07:59:59','MCOETH','4h','0.021604000000000','0.021100000000000','0.099131962508448','0.096819311651928','4.5885929692856875','4.588592969285687','test'),('2019-01-07 11:59:59','2019-01-10 19:59:59','MCOETH','4h','0.017415000000000','0.017081000000000','0.099131962508448','0.097230723606477','5.692332041828768','5.692332041828768','test'),('2019-01-11 11:59:59','2019-01-14 15:59:59','MCOETH','4h','0.018092000000000','0.017550000000000','0.099131962508448','0.096162167920808','5.47932580745346','5.479325807453460','test'),('2019-01-16 03:59:59','2019-01-16 15:59:59','MCOETH','4h','0.018607000000000','0.018306000000000','0.099131962508448','0.097528333728148','5.327670366445316','5.327670366445316','test'),('2019-01-17 03:59:59','2019-01-22 15:59:59','MCOETH','4h','0.018184000000000','0.018887000000000','0.099131962508448','0.102964439941545','5.451603745515178','5.451603745515178','test'),('2019-01-23 19:59:59','2019-01-24 07:59:59','MCOETH','4h','0.019292000000000','0.018816000000000','0.099131962508448','0.096686036002434','5.13850106305453','5.138501063054530','test'),('2019-01-24 11:59:59','2019-01-28 03:59:59','MCOETH','4h','0.019006000000000','0.018618000000000','0.099131962508448','0.097108222560364','5.215824608463012','5.215824608463012','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 12:09:19
