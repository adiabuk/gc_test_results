-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-02 15:59:59','2018-07-06 07:59:59','NEBLBNB','4h','0.293950000000000','0.291720000000000','0.711908500000000','0.706507731314849','2.421869365538357','2.421869365538357','test'),('2018-07-08 15:59:59','2018-07-09 03:59:59','NEBLBNB','4h','0.301320000000000','0.292280000000000','0.711908500000000','0.690550299946900','2.3626327492366923','2.362632749236692','test'),('2018-07-09 19:59:59','2018-07-09 23:59:59','NEBLBNB','4h','0.300640000000000','0.290760000000000','0.711908500000000','0.688512890699840','2.367976649813731','2.367976649813731','test'),('2018-07-13 07:59:59','2018-07-13 11:59:59','NEBLBNB','4h','0.296690000000000','0.294690000000000','0.711908500000000','0.707109494303819','2.3995028480905995','2.399502848090600','test'),('2018-07-13 15:59:59','2018-07-13 23:59:59','NEBLBNB','4h','0.295680000000000','0.293400000000000','0.711908500000000','0.706418945819805','2.407699201839827','2.407699201839827','test'),('2018-07-14 07:59:59','2018-07-14 11:59:59','NEBLBNB','4h','0.291880000000000','0.292100000000000','0.711908500000000','0.712445089934220','2.4390451555433743','2.439045155543374','test'),('2018-07-14 15:59:59','2018-07-15 19:59:59','NEBLBNB','4h','0.296590000000000','0.292460000000000','0.711908500000000','0.701995211942412','2.400311878350585','2.400311878350585','test'),('2018-07-15 23:59:59','2018-07-16 07:59:59','NEBLBNB','4h','0.299320000000000','0.275530000000000','0.711908500000000','0.655325902061339','2.3784194173459845','2.378419417345984','test'),('2018-07-17 03:59:59','2018-07-17 15:59:59','NEBLBNB','4h','0.304450000000000','0.305600000000000','0.711908500000000','0.714597594350468','2.3383429134504845','2.338342913450485','test'),('2018-07-17 19:59:59','2018-07-19 19:59:59','NEBLBNB','4h','0.314340000000000','0.313860000000000','0.711908500000000','0.710821409333842','2.2647722211617993','2.264772221161799','test'),('2018-08-17 15:59:59','2018-08-20 23:59:59','NEBLBNB','4h','0.203580000000000','0.185000000000000','0.711908500000000','0.646935222025739','3.4969471460850774','3.496947146085077','test'),('2018-08-21 19:59:59','2018-08-22 15:59:59','NEBLBNB','4h','0.197470000000000','0.189300000000000','0.711908500000000','0.682454443966172','3.605147617359599','3.605147617359599','test'),('2018-08-22 19:59:59','2018-08-23 03:59:59','NEBLBNB','4h','0.191900000000000','0.193380000000000','0.711908500000000','0.717398987649818','3.709788952579469','3.709788952579469','test'),('2018-08-23 07:59:59','2018-08-23 19:59:59','NEBLBNB','4h','0.193730000000000','0.195450000000000','0.711908500000000','0.718229062741961','3.67474578020957','3.674745780209570','test'),('2018-08-23 23:59:59','2018-08-24 19:59:59','NEBLBNB','4h','0.197300000000000','0.197180000000000','0.711908500000000','0.711475509528637','3.6082539280283834','3.608253928028383','test'),('2018-08-25 15:59:59','2018-08-25 19:59:59','NEBLBNB','4h','0.196890000000000','0.196890000000000','0.711908500000000','0.711908500000000','3.615767687541267','3.615767687541267','test'),('2018-08-28 11:59:59','2018-08-30 11:59:59','NEBLBNB','4h','0.207600000000000','0.197670000000000','0.711908500000000','0.677856229263006','3.429231695568401','3.429231695568401','test'),('2018-08-31 19:59:59','2018-09-04 07:59:59','NEBLBNB','4h','0.221360000000000','0.220230000000000','0.711908500000000','0.708274344755150','3.216066588362848','3.216066588362848','test'),('2018-09-22 03:59:59','2018-09-24 15:59:59','NEBLBNB','4h','0.204090000000000','0.191300000000000','0.711908500000000','0.667294311578225','3.488208633446029','3.488208633446029','test'),('2018-09-24 19:59:59','2018-09-24 23:59:59','NEBLBNB','4h','0.192020000000000','0.191670000000000','0.711908500000000','0.710610885298407','3.707470575981669','3.707470575981669','test'),('2018-09-27 19:59:59','2018-09-27 23:59:59','NEBLBNB','4h','0.193140000000000','0.182610000000000','0.711908500000000','0.673095222041006','3.68597131614373','3.685971316143730','test'),('2018-09-28 15:59:59','2018-09-29 03:59:59','NEBLBNB','4h','0.190100000000000','0.183160000000000','0.711908500000000','0.685918784113624','3.7449158337716995','3.744915833771699','test'),('2018-09-29 19:59:59','2018-10-01 23:59:59','NEBLBNB','4h','0.190540000000000','0.192630000000000','0.711908500000000','0.719717300068227','3.7362679752282992','3.736267975228299','test'),('2018-10-02 03:59:59','2018-10-02 23:59:59','NEBLBNB','4h','0.194760000000000','0.185890000000000','0.711908500000000','0.679485885525775','3.655311665639762','3.655311665639762','test'),('2018-10-05 03:59:59','2018-10-07 19:59:59','NEBLBNB','4h','0.192380000000000','0.192230000000000','0.711908500000000','0.711353420080050','3.7005327996673256','3.700532799667326','test'),('2018-10-08 15:59:59','2018-10-11 03:59:59','NEBLBNB','4h','0.198270000000000','0.192340000000000','0.711908500000000','0.690616234881727','3.590601200383316','3.590601200383316','test'),('2018-10-17 15:59:59','2018-10-17 19:59:59','NEBLBNB','4h','0.197660000000000','0.205000000000000','0.711908500000000','0.738344847212385','3.601682181523829','3.601682181523829','test'),('2018-10-18 07:59:59','2018-10-18 23:59:59','NEBLBNB','4h','0.208530000000000','0.195080000000000','0.711908500000000','0.665991033328538','3.413938042487892','3.413938042487892','test'),('2018-10-19 03:59:59','2018-10-19 15:59:59','NEBLBNB','4h','0.198430000000000','0.201200000000000','0.711908500000000','0.721846445597944','3.5877059920374945','3.587705992037495','test'),('2018-10-19 19:59:59','2018-10-25 11:59:59','NEBLBNB','4h','0.201720000000000','0.227140000000000','0.711908500000000','0.801620546747968','3.529191453499901','3.529191453499901','test'),('2018-10-25 15:59:59','2018-10-29 23:59:59','NEBLBNB','4h','0.260850000000000','0.275300000000000','0.711908500000000','0.751345256085873','2.729187272378762','2.729187272378762','test'),('2018-10-30 03:59:59','2018-10-31 07:59:59','NEBLBNB','4h','0.293760000000000','0.276580000000000','0.711908500000000','0.670273872991558','2.423435797930283','2.423435797930283','test'),('2018-10-31 15:59:59','2018-10-31 23:59:59','NEBLBNB','4h','0.301920000000000','0.265660000000000','0.711908500000000','0.626409685049020','2.3579375331213566','2.357937533121357','test'),('2018-11-28 15:59:59','2018-11-30 11:59:59','NEBLBNB','4h','0.202300000000000','0.202320000000000','0.711908500000000','0.711978881463174','3.519073158675235','3.519073158675235','test'),('2018-12-01 07:59:59','2018-12-03 03:59:59','NEBLBNB','4h','0.212740000000000','0.206070000000000','0.711908500000000','0.689588157351697','3.3463782081413935','3.346378208141394','test'),('2018-12-09 03:59:59','2018-12-10 15:59:59','NEBLBNB','4h','0.202830000000000','0.194710000000000','0.711908500000000','0.683408292831435','3.5098777301188187','3.509877730118819','test'),('2018-12-15 15:59:59','2018-12-17 07:59:59','NEBLBNB','4h','0.196690000000000','0.193090000000000','0.711908500000000','0.698878500508414','3.6194443032182626','3.619444303218263','test'),('2018-12-17 11:59:59','2018-12-17 15:59:59','NEBLBNB','4h','0.198180000000000','0.198180000000000','0.711908500000000','0.711908500000000','3.592231809466142','3.592231809466142','test'),('2018-12-18 07:59:59','2018-12-18 19:59:59','NEBLBNB','4h','0.203680000000000','0.195030000000000','0.711908500000000','0.681674758223684','3.495230263157895','3.495230263157895','test'),('2018-12-19 11:59:59','2018-12-19 23:59:59','NEBLBNB','4h','0.200620000000000','0.199310000000000','0.711908500000000','0.707259909954142','3.54854201973881','3.548542019738810','test'),('2018-12-20 03:59:59','2018-12-23 11:59:59','NEBLBNB','4h','0.201720000000000','0.209610000000000','0.711908500000000','0.739753820568114','3.529191453499901','3.529191453499901','test'),('2018-12-23 15:59:59','2018-12-25 03:59:59','NEBLBNB','4h','0.225520000000000','0.215670000000000','0.711908500000000','0.680814589371231','3.1567421958141186','3.156742195814119','test'),('2018-12-30 11:59:59','2018-12-30 23:59:59','NEBLBNB','4h','0.217630000000000','0.222350000000000','0.711908500000000','0.727348504227358','3.2711873363047377','3.271187336304738','test'),('2019-01-02 11:59:59','2019-01-04 19:59:59','NEBLBNB','4h','0.219420000000000','0.221220000000000','0.711908500000000','0.717748602543068','3.244501412815605','3.244501412815605','test'),('2019-01-04 23:59:59','2019-01-06 23:59:59','NEBLBNB','4h','0.224100000000000','0.220450000000000','0.711908500000000','0.700313381637662','3.176744756804998','3.176744756804998','test'),('2019-01-07 03:59:59','2019-01-07 11:59:59','NEBLBNB','4h','0.225880000000000','0.216430000000000','0.711908500000000','0.682124830241721','3.151711085532141','3.151711085532141','test'),('2019-02-26 23:59:59','2019-02-27 07:59:59','NEBLBNB','4h','0.118270000000000','0.115060000000000','0.711908500000000','0.692586387164962','6.019349792846876','6.019349792846876','test'),('2019-02-27 11:59:59','2019-02-27 15:59:59','NEBLBNB','4h','0.115080000000000','0.111580000000000','0.711908500000000','0.690256781630170','6.186205248522767','6.186205248522767','test'),('2019-02-27 19:59:59','2019-02-28 11:59:59','NEBLBNB','4h','0.119480000000000','0.112450000000000','0.711908500000000','0.670021014604955','5.958390525610981','5.958390525610981','test'),('2019-03-15 19:59:59','2019-03-18 07:59:59','NEBLBNB','4h','0.098150000000000','0.095120000000000','0.711908500000000','0.689931090371880','7.253270504330107','7.253270504330107','test'),('2019-03-19 19:59:59','2019-03-21 15:59:59','NEBLBNB','4h','0.098580000000000','0.097250000000000','0.711908500000000','0.702303729204707','7.221632176912153','7.221632176912153','test'),('2019-03-21 23:59:59','2019-03-22 07:59:59','NEBLBNB','4h','0.100360000000000','0.098080000000000','0.711908500000000','0.695735210043842','7.093548226385014','7.093548226385014','test'),('2019-03-30 03:59:59','2019-03-30 23:59:59','NEBLBNB','4h','0.095330000000000','0.090370000000000','0.711908500000000','0.674868049354873','7.467832791356342','7.467832791356342','test'),('2019-04-07 11:59:59','2019-04-07 19:59:59','NEBLBNB','4h','0.091510000000000','0.093590000000000','0.711908500000000','0.728090006720577','7.779570538738937','7.779570538738937','test'),('2019-04-08 03:59:59','2019-04-10 23:59:59','NEBLBNB','4h','0.092700000000000','0.092640000000000','0.711908500000000','0.711447717799353','7.67970334412082','7.679703344120820','test'),('2019-05-08 23:59:59','2019-05-09 07:59:59','NEBLBNB','4h','0.062530000000000','0.059910000000000','0.711908500000000','0.682079613545498','11.385071165840397','11.385071165840397','test'),('2019-05-09 15:59:59','2019-05-09 19:59:59','NEBLBNB','4h','0.061320000000000','0.059920000000000','0.474605666666667','0.463769920852360','7.739818438791042','7.739818438791042','test'),('2019-05-09 23:59:59','2019-05-10 03:59:59','NEBLBNB','4h','0.060950000000000','0.060850000000000','0.530695795946628','0.529825089144419','8.707068022093976','8.707068022093976','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','NEBLBNB','4h','0.063040000000000','0.061000000000000','0.530695795946628','0.513522264478812','8.41839777834118','8.418397778341181','test'),('2019-05-10 15:59:59','2019-05-10 19:59:59','NEBLBNB','4h','0.062280000000000','0.060570000000000','0.530695795946628','0.516124668601272','8.521127102547013','8.521127102547013','test'),('2019-06-01 15:59:59','2019-06-01 23:59:59','NEBLBNB','4h','0.042850000000000','0.041400000000000','0.530695795946628','0.512737595150301','12.384966066432392','12.384966066432392','test'),('2019-06-02 07:59:59','2019-06-02 11:59:59','NEBLBNB','4h','0.041740000000000','0.042010000000000','0.530695795946628','0.534128662858597','12.714321896181792','12.714321896181792','test'),('2019-06-02 19:59:59','2019-06-02 23:59:59','NEBLBNB','4h','0.041780000000000','0.042300000000000','0.530695795946628','0.537300913560133','12.702149256740737','12.702149256740737','test'),('2019-06-03 03:59:59','2019-06-03 07:59:59','NEBLBNB','4h','0.042630000000000','0.042000000000000','0.530695795946628','0.522853000932638','12.448880974586627','12.448880974586627','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:03:18
