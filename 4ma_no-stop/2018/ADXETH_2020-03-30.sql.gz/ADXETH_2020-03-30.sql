-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-27 23:59:59','2018-06-29 15:59:59','ADXETH','4h','0.000849600000000','0.000818600000000','0.072144500000000','0.069512108874765','84.91584274952919','84.915842749529190','test'),('2018-06-29 23:59:59','2018-07-01 15:59:59','ADXETH','4h','0.000850700000000','0.000836600000000','0.072144500000000','0.070948734806630','84.80604208299047','84.806042082990473','test'),('2018-07-01 23:59:59','2018-07-04 11:59:59','ADXETH','4h','0.000877700000000','0.000883700000000','0.072144500000000','0.072637683320041','82.19722000683605','82.197220006836048','test'),('2018-07-04 15:59:59','2018-07-05 19:59:59','ADXETH','4h','0.000919800000000','0.000873300000000','0.072144500000000','0.068497273157208','78.43498586649271','78.434985866492710','test'),('2018-07-18 11:59:59','2018-07-20 15:59:59','ADXETH','4h','0.000881100000000','0.000854200000000','0.072144500000000','0.069941927023039','81.88003631823857','81.880036318238567','test'),('2018-07-23 11:59:59','2018-07-25 03:59:59','ADXETH','4h','0.001244600000000','0.000932100000000','0.072144500000000','0.054030120882211','57.966013176924314','57.966013176924314','test'),('2018-08-24 03:59:59','2018-08-30 19:59:59','ADXETH','4h','0.000653700000000','0.000700600000000','0.072144500000000','0.077320539544133','110.36331650604252','110.363316506042523','test'),('2018-08-30 23:59:59','2018-09-02 23:59:59','ADXETH','4h','0.000734700000000','0.000730000000000','0.072144500000000','0.071682979447393','98.1958622567034','98.195862256703407','test'),('2018-09-03 07:59:59','2018-09-03 11:59:59','ADXETH','4h','0.000753400000000','0.000735100000000','0.072144500000000','0.070392118330236','95.75856118927528','95.758561189275284','test'),('2018-09-03 15:59:59','2018-09-05 15:59:59','ADXETH','4h','0.000753700000000','0.000751200000000','0.072144500000000','0.071905198885498','95.72044580071646','95.720445800716462','test'),('2018-09-05 19:59:59','2018-09-05 23:59:59','ADXETH','4h','0.000754800000000','0.000747000000000','0.072144500000000','0.071398968600954','95.58094859565448','95.580948595654476','test'),('2018-09-07 07:59:59','2018-09-13 03:59:59','ADXETH','4h','0.000767100000000','0.000829800000000','0.072144500000000','0.078041332420806','94.04836396819188','94.048363968191879','test'),('2018-09-16 15:59:59','2018-09-19 07:59:59','ADXETH','4h','0.000849500000000','0.000843300000000','0.072144500000000','0.071617959799882','84.92583872866392','84.925838728663919','test'),('2018-09-19 11:59:59','2018-09-19 15:59:59','ADXETH','4h','0.000857000000000','0.000838300000000','0.072144500000000','0.070570285122520','84.18261376896149','84.182613768961488','test'),('2018-09-25 15:59:59','2018-09-28 11:59:59','ADXETH','4h','0.000988000000000','0.000877800000000','0.072144500000000','0.064097613461538','73.02074898785426','73.020748987854262','test'),('2018-09-28 23:59:59','2018-09-29 07:59:59','ADXETH','4h','0.000906400000000','0.000885500000000','0.072144500000000','0.070480973907767','79.59454986760812','79.594549867608123','test'),('2018-09-30 03:59:59','2018-09-30 15:59:59','ADXETH','4h','0.000913600000000','0.000880300000000','0.072144500000000','0.069514889831436','78.96727232924694','78.967272329246939','test'),('2018-10-05 03:59:59','2018-10-06 19:59:59','ADXETH','4h','0.000908200000000','0.000890700000000','0.072144500000000','0.070754356033913','79.43679806210086','79.436798062100863','test'),('2018-10-07 23:59:59','2018-10-10 07:59:59','ADXETH','4h','0.000953500000000','0.000909500000000','0.072144500000000','0.068815335867855','75.6628211851075','75.662821185107504','test'),('2018-10-10 11:59:59','2018-10-12 23:59:59','ADXETH','4h','0.000924800000000','0.000970500000000','0.072144500000000','0.075709599102509','78.01092128027682','78.010921280276818','test'),('2018-10-13 11:59:59','2018-10-15 07:59:59','ADXETH','4h','0.001022500000000','0.000946200000000','0.072144500000000','0.066761003325183','70.55696821515893','70.556968215158932','test'),('2018-10-16 07:59:59','2018-10-22 11:59:59','ADXETH','4h','0.001053400000000','0.001170500000000','0.072144500000000','0.080164360404405','68.48727928612114','68.487279286121137','test'),('2018-10-31 19:59:59','2018-11-01 07:59:59','ADXETH','4h','0.001139900000000','0.001132300000000','0.072144500000000','0.071663494473199','63.29020089481534','63.290200894815342','test'),('2018-11-01 11:59:59','2018-11-02 23:59:59','ADXETH','4h','0.001150200000000','0.001152200000000','0.072144500000000','0.072269946878804','62.72343940184315','62.723439401843152','test'),('2018-11-28 15:59:59','2018-11-30 11:59:59','ADXETH','4h','0.000901100000000','0.000814700000000','0.072144500000000','0.065227082621241','80.06270114304739','80.062701143047391','test'),('2018-12-01 03:59:59','2018-12-03 03:59:59','ADXETH','4h','0.001218300000000','0.000970000000000','0.072144500000000','0.057440831486498','59.21735204793565','59.217352047935648','test'),('2018-12-04 03:59:59','2018-12-05 07:59:59','ADXETH','4h','0.001140100000000','0.001012500000000','0.072144500000000','0.064070087053767','63.27909832470836','63.279098324708357','test'),('2018-12-05 19:59:59','2018-12-06 03:59:59','ADXETH','4h','0.001062200000000','0.001005700000000','0.072144500000000','0.068307026595745','67.9198832611561','67.919883261156102','test'),('2018-12-10 07:59:59','2018-12-11 07:59:59','ADXETH','4h','0.001072200000000','0.000998600000000','0.072144500000000','0.067192219455326','67.28642044394702','67.286420443947023','test'),('2018-12-11 11:59:59','2018-12-12 03:59:59','ADXETH','4h','0.001009900000000','0.000994000000000','0.072144500000000','0.071008647390831','71.43727101693237','71.437271016932371','test'),('2018-12-13 07:59:59','2018-12-14 19:59:59','ADXETH','4h','0.001038600000000','0.001009800000000','0.048096333333333','0.046762639514731','46.30881314590153','46.308813145901532','test'),('2018-12-17 03:59:59','2018-12-17 19:59:59','ADXETH','4h','0.001126000000000','0.000996000000000','0.053721001071683','0.047518754056302','47.709592426006','47.709592426005997','test'),('2018-12-17 23:59:59','2018-12-18 03:59:59','ADXETH','4h','0.001014500000000','0.001003500000000','0.053721001071683','0.053138516092098','52.95317996223066','52.953179962230656','test'),('2019-01-13 19:59:59','2019-01-14 15:59:59','ADXETH','4h','0.000755300000000','0.000721000000000','0.053721001071683','0.051281400466945','71.12538206233681','71.125382062336811','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','ADXETH','4h','0.000721700000000','0.000725900000000','0.053721001071683','0.054033635413516','74.4367480555397','74.436748055539695','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','ADXETH','4h','0.000744100000000','0.000738500000000','0.053721001071683','0.053316703791746','72.19594284596559','72.195942845965590','test'),('2019-01-15 15:59:59','2019-01-25 15:59:59','ADXETH','4h','0.000762800000000','0.000905500000000','0.053721001071683','0.063770800302057','70.42606328222732','70.426063282227318','test'),('2019-02-06 11:59:59','2019-02-09 03:59:59','ADXETH','4h','0.000882900000000','0.000938500000000','0.053904451994824','0.057299046547902','61.05385886830249','61.053858868302491','test'),('2019-02-09 07:59:59','2019-02-09 11:59:59','ADXETH','4h','0.000962300000000','0.000947200000000','0.054753100633094','0.053893938397243','56.89816131465631','56.898161314656313','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','ADXETH','4h','0.000963000000000','0.000913300000000','0.054753100633094','0.051927317557845','56.856802318893045','56.856802318893045','test'),('2019-02-17 15:59:59','2019-02-17 23:59:59','ADXETH','4h','0.000982200000000','0.000930000000000','0.054753100633094','0.051843192413742','55.74536818681939','55.745368186819391','test'),('2019-02-26 19:59:59','2019-02-27 15:59:59','ADXETH','4h','0.000907400000000','0.000853000000000','0.054753100633094','0.051470569583457','60.34064429479171','60.340644294791709','test'),('2019-02-27 19:59:59','2019-03-04 07:59:59','ADXETH','4h','0.000878200000000','0.000911000000000','0.054753100633094','0.056798080934581','62.34696041117513','62.346960411175132','test'),('2019-03-07 15:59:59','2019-03-16 03:59:59','ADXETH','4h','0.000966900000000','0.001050900000000','0.054753100633094','0.059509808103546','56.627469886331575','56.627469886331575','test'),('2019-03-24 23:59:59','2019-03-25 07:59:59','ADXETH','4h','0.001042500000000','0.001051500000000','0.054753100633094','0.055225789271653','52.52095983989832','52.520959839898318','test'),('2019-03-25 15:59:59','2019-03-26 03:59:59','ADXETH','4h','0.001043200000000','0.001033100000000','0.054753100633094','0.054222994885017','52.4857176314168','52.485717631416797','test'),('2019-03-26 07:59:59','2019-03-26 11:59:59','ADXETH','4h','0.001037800000000','0.001030900000000','0.054753100633094','0.054389064793464','52.75881733772789','52.758817337727891','test'),('2019-03-26 15:59:59','2019-03-29 03:59:59','ADXETH','4h','0.001420000000000','0.001171500000000','0.054753100633094','0.045171308022303','38.55852157260141','38.558521572601407','test'),('2019-04-01 19:59:59','2019-04-02 07:59:59','ADXETH','4h','0.001151900000000','0.001146200000000','0.054753100633094','0.054482163335057','47.532859304708744','47.532859304708744','test'),('2019-04-21 03:59:59','2019-04-21 11:59:59','ADXETH','4h','0.001062600000000','0.000996300000000','0.054753100633094','0.051336828685066','51.52748036240731','51.527480362407310','test'),('2019-04-21 23:59:59','2019-04-22 15:59:59','ADXETH','4h','0.001042500000000','0.001020000000000','0.054753100633094','0.053571379036696','52.52095983989832','52.520959839898318','test'),('2019-04-22 19:59:59','2019-04-23 07:59:59','ADXETH','4h','0.001045800000000','0.001009800000000','0.054753100633094','0.052868312315259','52.355231050960036','52.355231050960036','test'),('2019-04-23 11:59:59','2019-04-23 15:59:59','ADXETH','4h','0.001041000000000','0.001034800000000','0.054753100633094','0.054427001474664','52.59663845638232','52.596638456382323','test'),('2019-04-23 23:59:59','2019-04-24 03:59:59','ADXETH','4h','0.001029600000000','0.000981900000000','0.054753100633094','0.052216462229638','53.17900216889471','53.179002168894712','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 23:06:02
