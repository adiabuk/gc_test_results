-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-02 15:59:59','2018-07-05 15:59:59','CNDBNB','4h','0.002464000000000','0.002427000000000','0.711908500000000','0.701218315543831','288.92390422077926','288.923904220779264','test'),('2018-07-09 19:59:59','2018-07-10 03:59:59','CNDBNB','4h','0.002452000000000','0.002290000000000','0.711908500000000','0.664873762234910','290.3378874388255','290.337887438825476','test'),('2018-07-13 03:59:59','2018-07-13 07:59:59','CNDBNB','4h','0.002381000000000','0.002373000000000','0.711908500000000','0.709516535279295','298.9955900881983','298.995590088198298','test'),('2018-07-13 15:59:59','2018-07-14 03:59:59','CNDBNB','4h','0.002383000000000','0.002413000000000','0.711908500000000','0.720870839488040','298.74464960134287','298.744649601342871','test'),('2018-07-14 07:59:59','2018-07-15 07:59:59','CNDBNB','4h','0.002419000000000','0.002367000000000','0.711908500000000','0.696604968788756','294.2986771393138','294.298677139313781','test'),('2018-07-15 11:59:59','2018-07-16 07:59:59','CNDBNB','4h','0.002428000000000','0.002326000000000','0.711908500000000','0.682001306013180','293.207784184514','293.207784184514026','test'),('2018-07-16 19:59:59','2018-07-20 03:59:59','CNDBNB','4h','0.002436000000000','0.002511000000000','0.711908500000000','0.733826865147784','292.2448686371101','292.244868637110073','test'),('2018-07-20 07:59:59','2018-07-20 15:59:59','CNDBNB','4h','0.002597000000000','0.002544000000000','0.711908500000000','0.697379755102041','274.127262225645','274.127262225644984','test'),('2018-07-21 15:59:59','2018-07-22 07:59:59','CNDBNB','4h','0.002631000000000','0.002530000000000','0.711908500000000','0.684579439376663','270.58475864690234','270.584758646902344','test'),('2018-07-22 19:59:59','2018-07-23 07:59:59','CNDBNB','4h','0.002615000000000','0.002527000000000','0.711908500000000','0.687951349713193','272.24034416826004','272.240344168260037','test'),('2018-08-18 11:59:59','2018-08-18 15:59:59','CNDBNB','4h','0.001661000000000','0.001586000000000','0.711908500000000','0.679763323901264','428.60234798314275','428.602347983142749','test'),('2018-08-20 19:59:59','2018-08-22 23:59:59','CNDBNB','4h','0.001749000000000','0.001744000000000','0.711908500000000','0.709873312750143','407.0374499714123','407.037449971412286','test'),('2018-08-23 03:59:59','2018-08-23 11:59:59','CNDBNB','4h','0.001766000000000','0.001753000000000','0.711908500000000','0.706667950453001','403.11919592298983','403.119195922989832','test'),('2018-08-24 03:59:59','2018-08-24 15:59:59','CNDBNB','4h','0.001834000000000','0.001737000000000','0.711908500000000','0.674255760359869','388.17257360959655','388.172573609596554','test'),('2018-08-28 11:59:59','2018-08-30 19:59:59','CNDBNB','4h','0.001906000000000','0.001745000000000','0.711908500000000','0.651773521773347','373.5091815320042','373.509181532004220','test'),('2018-08-31 07:59:59','2018-09-01 03:59:59','CNDBNB','4h','0.001793000000000','0.001756000000000','0.711908500000000','0.697217694366983','397.04880089235917','397.048800892359168','test'),('2018-09-02 07:59:59','2018-09-02 11:59:59','CNDBNB','4h','0.001809000000000','0.001759000000000','0.711908500000000','0.692231648148148','393.53703703703707','393.537037037037067','test'),('2018-09-02 19:59:59','2018-09-02 23:59:59','CNDBNB','4h','0.001811000000000','0.001760000000000','0.711908500000000','0.691860276090558','393.1024295969078','393.102429596907825','test'),('2018-09-04 15:59:59','2018-09-05 11:59:59','CNDBNB','4h','0.001827000000000','0.001721000000000','0.711908500000000','0.670604558565955','389.65982484948006','389.659824849480060','test'),('2018-09-13 19:59:59','2018-09-17 15:59:59','CNDBNB','4h','0.001840000000000','0.002136000000000','0.711908500000000','0.826432910869565','386.9067934782609','386.906793478260909','test'),('2018-09-20 19:59:59','2018-09-24 11:59:59','CNDBNB','4h','0.002365000000000','0.002270000000000','0.711908500000000','0.683311752642706','301.0183932346723','301.018393234672317','test'),('2018-10-08 15:59:59','2018-10-09 07:59:59','CNDBNB','4h','0.002208000000000','0.002161000000000','0.711908500000000','0.696754650588768','322.42232789855075','322.422327898550748','test'),('2018-10-09 11:59:59','2018-10-09 15:59:59','CNDBNB','4h','0.002162000000000','0.002189000000000','0.711908500000000','0.720799124190564','329.28237742830714','329.282377428307143','test'),('2018-10-09 23:59:59','2018-10-10 03:59:59','CNDBNB','4h','0.002229000000000','0.002203000000000','0.711908500000000','0.703604497756842','319.3847016599372','319.384701659937207','test'),('2018-10-10 11:59:59','2018-10-10 15:59:59','CNDBNB','4h','0.002182000000000','0.002174000000000','0.711908500000000','0.709298386342805','326.2642071494042','326.264207149404228','test'),('2018-10-10 23:59:59','2018-10-11 03:59:59','CNDBNB','4h','0.002190000000000','0.002075000000000','0.711908500000000','0.674525176940639','325.07237442922377','325.072374429223771','test'),('2018-10-16 19:59:59','2018-10-23 03:59:59','CNDBNB','4h','0.002200000000000','0.002604000000000','0.711908500000000','0.842640788181818','323.59477272727275','323.594772727272755','test'),('2018-10-28 15:59:59','2018-10-29 15:59:59','CNDBNB','4h','0.002736000000000','0.002615000000000','0.711908500000000','0.680424242507310','260.2004751461988','260.200475146198812','test'),('2018-10-31 07:59:59','2018-11-03 03:59:59','CNDBNB','4h','0.002685000000000','0.002741000000000','0.711908500000000','0.726756498510242','265.14283054003727','265.142830540037266','test'),('2018-11-10 07:59:59','2018-11-10 23:59:59','CNDBNB','4h','0.002786000000000','0.002547000000000','0.711908500000000','0.650836665290739','255.53068916008618','255.530689160086183','test'),('2018-11-11 03:59:59','2018-11-11 07:59:59','CNDBNB','4h','0.002565000000000','0.002589000000000','0.711908500000000','0.718569632163743','277.54717348927875','277.547173489278748','test'),('2018-11-28 19:59:59','2018-11-30 03:59:59','CNDBNB','4h','0.002500000000000','0.002315000000000','0.711908500000000','0.659227271000000','284.7634','284.763399999999990','test'),('2018-11-30 07:59:59','2018-11-30 11:59:59','CNDBNB','4h','0.002399000000000','0.002350000000000','0.711908500000000','0.697367642767820','296.7521884118383','296.752188411838290','test'),('2018-11-30 15:59:59','2018-11-30 19:59:59','CNDBNB','4h','0.002372000000000','0.002321000000000','0.711908500000000','0.696601866989882','300.1300590219225','300.130059021922477','test'),('2018-12-01 11:59:59','2018-12-03 03:59:59','CNDBNB','4h','0.002397000000000','0.002407000000000','0.711908500000000','0.714878497914059','296.9997914059241','296.999791405924100','test'),('2018-12-21 15:59:59','2018-12-22 19:59:59','CNDBNB','4h','0.002124000000000','0.001990000000000','0.711908500000000','0.666995251883239','335.1734934086629','335.173493408662921','test'),('2018-12-23 03:59:59','2018-12-23 07:59:59','CNDBNB','4h','0.001960000000000','0.001960000000000','0.711908500000000','0.711908500000000','363.21862244897966','363.218622448979659','test'),('2019-01-07 15:59:59','2019-01-07 19:59:59','CNDBNB','4h','0.001729000000000','0.001710000000000','0.711908500000000','0.704085329670330','411.7458068247542','411.745806824754197','test'),('2019-01-08 03:59:59','2019-01-08 07:59:59','CNDBNB','4h','0.001718000000000','0.001670000000000','0.711908500000000','0.692018157741560','414.3821303841677','414.382130384167681','test'),('2019-01-15 15:59:59','2019-01-17 07:59:59','CNDBNB','4h','0.001777000000000','0.001711000000000','0.711908500000000','0.685467328925155','400.62380416432194','400.623804164321939','test'),('2019-01-22 19:59:59','2019-01-23 23:59:59','CNDBNB','4h','0.001810000000000','0.001754000000000','0.711908500000000','0.689882601657459','393.31961325966853','393.319613259668529','test'),('2019-02-26 07:59:59','2019-02-28 11:59:59','CNDBNB','4h','0.001361000000000','0.001220000000000','0.711908500000000','0.638154570168993','523.0775165319618','523.077516531961805','test'),('2019-03-15 19:59:59','2019-03-16 03:59:59','CNDBNB','4h','0.001019000000000','0.001000000000000','0.711908500000000','0.698634445534838','698.6344455348382','698.634445534838164','test'),('2019-03-20 15:59:59','2019-03-22 23:59:59','CNDBNB','4h','0.001033000000000','0.001007000000000','0.711908500000000','0.693990183446273','689.1660212971926','689.166021297192628','test'),('2019-03-29 19:59:59','2019-03-31 03:59:59','CNDBNB','4h','0.001015000000000','0.000972000000000','0.711908500000000','0.681748829556650','701.3876847290641','701.387684729064063','test'),('2019-03-31 15:59:59','2019-04-01 07:59:59','CNDBNB','4h','0.001013000000000','0.001005000000000','0.711908500000000','0.706286320335637','702.7724580454097','702.772458045409735','test'),('2019-04-01 23:59:59','2019-04-02 15:59:59','CNDBNB','4h','0.001001000000000','0.001063000000000','0.711908500000000','0.756002732767233','711.1973026973028','711.197302697302803','test'),('2019-04-02 23:59:59','2019-04-04 03:59:59','CNDBNB','4h','0.001024000000000','0.000991000000000','0.711908500000000','0.688966136230469','695.2231445312501','695.223144531250114','test'),('2019-04-04 07:59:59','2019-04-04 11:59:59','CNDBNB','4h','0.001029000000000','0.001008000000000','0.711908500000000','0.697379755102041','691.8449951409136','691.844995140913625','test'),('2019-04-05 11:59:59','2019-04-05 23:59:59','CNDBNB','4h','0.001046000000000','0.001018000000000','0.711908500000000','0.692851675908222','680.6008604206501','680.600860420650065','test'),('2019-04-06 19:59:59','2019-04-06 23:59:59','CNDBNB','4h','0.001042000000000','0.001017000000000','0.711908500000000','0.694828161708253','683.2135316698657','683.213531669865688','test'),('2019-04-07 03:59:59','2019-04-09 11:59:59','CNDBNB','4h','0.001035000000000','0.001011000000000','0.711908500000000','0.695400476811594','687.8342995169083','687.834299516908345','test'),('2019-04-16 19:59:59','2019-04-18 07:59:59','CNDBNB','4h','0.001057000000000','0.001032000000000','0.711908500000000','0.695070550614948','673.5179754020814','673.517975402081447','test'),('2019-05-12 15:59:59','2019-05-12 19:59:59','CNDBNB','4h','0.000730000000000','0.000720000000000','0.711908500000000','0.702156328767123','975.2171232876714','975.217123287671370','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:49:06
