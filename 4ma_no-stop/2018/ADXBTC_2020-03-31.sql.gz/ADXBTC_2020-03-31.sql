-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-30 15:59:59','2018-07-01 11:59:59','ADXBTC','4h','0.000063190000000','0.000060330000000','0.001467500000000','0.001401080471594','23.22361133090679','23.223611330906792','test'),('2018-07-01 23:59:59','2018-07-04 11:59:59','ADXBTC','4h','0.000062140000000','0.000063000000000','0.001467500000000','0.001487809784358','23.616028323141297','23.616028323141297','test'),('2018-07-04 15:59:59','2018-07-05 15:59:59','ADXBTC','4h','0.000065080000000','0.000062880000000','0.001467500000000','0.001417891825446','22.549170251997545','22.549170251997545','test'),('2018-07-23 23:59:59','2018-07-24 19:59:59','ADXBTC','4h','0.000065480000000','0.000057380000000','0.001467500000000','0.001285967470984','22.411423335369577','22.411423335369577','test'),('2018-08-28 07:59:59','2018-08-29 03:59:59','ADXBTC','4h','0.000030290000000','0.000028840000000','0.001467500000000','0.001397249917465','48.44833278309673','48.448332783096731','test'),('2018-08-29 11:59:59','2018-08-29 19:59:59','ADXBTC','4h','0.000029080000000','0.000029230000000','0.001467500000000','0.001475069635488','50.46423658872077','50.464236588720773','test'),('2018-08-29 23:59:59','2018-08-30 11:59:59','ADXBTC','4h','0.000030280000000','0.000028140000000','0.001467500000000','0.001363786327609','48.46433289299868','48.464332892998677','test'),('2018-08-31 07:59:59','2018-09-02 15:59:59','ADXBTC','4h','0.000029480000000','0.000029670000000','0.001467500000000','0.001476958107191','49.77951153324288','49.779511533242882','test'),('2018-09-16 11:59:59','2018-09-18 03:59:59','ADXBTC','4h','0.000027930000000','0.000027290000000','0.001467500000000','0.001433873075546','52.5420694593627','52.542069459362700','test'),('2018-09-18 15:59:59','2018-09-19 19:59:59','ADXBTC','4h','0.000028600000000','0.000027370000000','0.001467500000000','0.001404387237762','51.31118881118881','51.311188811188813','test'),('2018-09-21 07:59:59','2018-09-24 15:59:59','ADXBTC','4h','0.000027900000000','0.000028360000000','0.001467500000000','0.001491695340502','52.598566308243726','52.598566308243726','test'),('2018-09-25 15:59:59','2018-09-28 11:59:59','ADXBTC','4h','0.000032510000000','0.000029500000000','0.001467500000000','0.001331628729622','45.13995693632729','45.139956936327287','test'),('2018-09-29 15:59:59','2018-10-01 15:59:59','ADXBTC','4h','0.000030730000000','0.000030280000000','0.001467500000000','0.001446010413277','47.75463716238204','47.754637162382039','test'),('2018-10-02 03:59:59','2018-10-02 07:59:59','ADXBTC','4h','0.000030940000000','0.000030640000000','0.001467500000000','0.001453270846800','47.43051066580479','47.430510665804789','test'),('2018-10-02 11:59:59','2018-10-02 15:59:59','ADXBTC','4h','0.000030720000000','0.000030580000000','0.001467500000000','0.001460812174479','47.77018229166667','47.770182291666671','test'),('2018-10-05 07:59:59','2018-10-06 19:59:59','ADXBTC','4h','0.000032090000000','0.000030420000000','0.001467500000000','0.001391129635400','45.730757245247744','45.730757245247744','test'),('2018-10-07 23:59:59','2018-10-10 07:59:59','ADXBTC','4h','0.000032440000000','0.000031090000000','0.001467500000000','0.001406429562269','45.237361282367445','45.237361282367445','test'),('2018-10-10 11:59:59','2018-10-11 07:59:59','ADXBTC','4h','0.000031760000000','0.000030900000000','0.001467500000000','0.001427762909320','46.205919395466','46.205919395465997','test'),('2018-10-11 11:59:59','2018-10-11 23:59:59','ADXBTC','4h','0.000035170000000','0.000030270000000','0.001467500000000','0.001263043076486','41.72590275803242','41.725902758032419','test'),('2018-10-14 07:59:59','2018-10-14 23:59:59','ADXBTC','4h','0.000031900000000','0.000031930000000','0.001467500000000','0.001468880094044','46.00313479623824','46.003134796238243','test'),('2018-10-16 15:59:59','2018-10-17 11:59:59','ADXBTC','4h','0.000033900000000','0.000032910000000','0.001467500000000','0.001424643805310','43.28908554572272','43.289085545722720','test'),('2018-10-17 15:59:59','2018-10-19 11:59:59','ADXBTC','4h','0.000033100000000','0.000032910000000','0.001467500000000','0.001459076283988','44.33534743202417','44.335347432024172','test'),('2018-10-19 15:59:59','2018-10-22 11:59:59','ADXBTC','4h','0.000033770000000','0.000036810000000','0.001467500000000','0.001599605419011','43.45572993781463','43.455729937814631','test'),('2018-11-01 15:59:59','2018-11-03 03:59:59','ADXBTC','4h','0.000035980000000','0.000035450000000','0.001467500000000','0.001445883129516','40.78654808226793','40.786548082267927','test'),('2018-11-29 11:59:59','2018-11-30 03:59:59','ADXBTC','4h','0.000024410000000','0.000023780000000','0.001467500000000','0.001429625153626','60.11880376894716','60.118803768947160','test'),('2018-11-30 07:59:59','2018-11-30 11:59:59','ADXBTC','4h','0.000023900000000','0.000022990000000','0.001467500000000','0.001411624476987','61.40167364016736','61.401673640167360','test'),('2018-12-01 03:59:59','2018-12-03 07:59:59','ADXBTC','4h','0.000034210000000','0.000027400000000','0.001467500000000','0.001175372698042','42.896813797135344','42.896813797135344','test'),('2018-12-04 03:59:59','2018-12-05 07:59:59','ADXBTC','4h','0.000031880000000','0.000028290000000','0.001467500000000','0.001302245138018','46.03199498117942','46.031994981179423','test'),('2018-12-10 23:59:59','2018-12-11 03:59:59','ADXBTC','4h','0.000029250000000','0.000026700000000','0.000978333333333','0.000893042735042','33.447293447293454','33.447293447293454','test'),('2018-12-11 11:59:59','2018-12-11 15:59:59','ADXBTC','4h','0.000026130000000','0.000026400000000','0.001056880535462','0.001067801229858','40.44701628252008','40.447016282520082','test'),('2018-12-11 23:59:59','2018-12-12 03:59:59','ADXBTC','4h','0.000027080000000','0.000025860000000','0.001059610709061','0.001011873446688','39.128903584241115','39.128903584241115','test'),('2018-12-13 15:59:59','2018-12-13 23:59:59','ADXBTC','4h','0.000027250000000','0.000026660000000','0.001059610709061','0.001036668679030','38.884796662788986','38.884796662788986','test'),('2018-12-14 03:59:59','2018-12-14 11:59:59','ADXBTC','4h','0.000027480000000','0.000026860000000','0.001059610709061','0.001035703917226','38.55934166888646','38.559341668886461','test'),('2018-12-17 23:59:59','2018-12-18 03:59:59','ADXBTC','4h','0.000027200000000','0.000026950000000','0.001059610709061','0.001049871640044','38.956276068419115','38.956276068419115','test'),('2018-12-18 07:59:59','2018-12-18 11:59:59','ADXBTC','4h','0.000026960000000','0.000026320000000','0.001059610709061','0.001034456745641','39.3030678435089','39.303067843508899','test'),('2018-12-19 03:59:59','2018-12-19 07:59:59','ADXBTC','4h','0.000027510000000','0.000026660000000','0.001059610709061','0.001026871010671','38.51729222322791','38.517292223227912','test'),('2018-12-19 23:59:59','2018-12-20 03:59:59','ADXBTC','4h','0.000027320000000','0.000026620000000','0.001059610709061','0.001032461093529','38.785165046156656','38.785165046156656','test'),('2018-12-23 11:59:59','2018-12-25 03:59:59','ADXBTC','4h','0.000027460000000','0.000026590000000','0.001059610709061','0.001026039648723','38.58742567592862','38.587425675928621','test'),('2019-01-02 03:59:59','2019-01-06 07:59:59','ADXBTC','4h','0.000028000000000','0.000027660000000','0.001059610709061','0.001046744007594','37.84323960932143','37.843239609321429','test'),('2019-01-06 15:59:59','2019-01-06 19:59:59','ADXBTC','4h','0.000028240000000','0.000027330000000','0.001059610709061','0.001025466029697','37.52162567496458','37.521625674964582','test'),('2019-01-17 03:59:59','2019-01-18 15:59:59','ADXBTC','4h','0.000027360000000','0.000026390000000','0.001059610709061','0.001022044101320','38.72846158848684','38.728461588486837','test'),('2019-01-18 19:59:59','2019-01-21 15:59:59','ADXBTC','4h','0.000026850000000','0.000027990000000','0.001059610709061','0.001104599767099','39.46408599854748','39.464085998547482','test'),('2019-01-21 23:59:59','2019-01-22 07:59:59','ADXBTC','4h','0.000028920000000','0.000028420000000','0.001059610709061','0.001041291021837','36.639374448858916','36.639374448858916','test'),('2019-01-22 15:59:59','2019-01-23 23:59:59','ADXBTC','4h','0.000029900000000','0.000029880000000','0.001059610709061','0.001058901939356','35.438485252876255','35.438485252876255','test'),('2019-01-24 07:59:59','2019-01-25 11:59:59','ADXBTC','4h','0.000029830000000','0.000029200000000','0.001059610709061','0.001037232071893','35.52164629772041','35.521646297720409','test'),('2019-02-07 11:59:59','2019-02-09 19:59:59','ADXBTC','4h','0.000028470000000','0.000030000000000','0.001059610709061','0.001116555014817','37.2185004938883','37.218500493888300','test'),('2019-02-11 19:59:59','2019-02-12 15:59:59','ADXBTC','4h','0.000031420000000','0.000030190000000','0.001059610709061','0.001018130086141','33.724083674761296','33.724083674761296','test'),('2019-02-12 23:59:59','2019-02-13 07:59:59','ADXBTC','4h','0.000031080000000','0.000030170000000','0.001059610709061','0.001028586071183','34.093008657046326','34.093008657046326','test'),('2019-02-16 19:59:59','2019-02-18 19:59:59','ADXBTC','4h','0.000031100000000','0.000030950000000','0.001059610709061','0.001054500046477','34.07108389263666','34.071083892636658','test'),('2019-02-20 23:59:59','2019-02-21 07:59:59','ADXBTC','4h','0.000031520000000','0.000030380000000','0.001059610709061','0.001021287225294','33.61709102350888','33.617091023508877','test'),('2019-02-26 11:59:59','2019-02-27 15:59:59','ADXBTC','4h','0.000032150000000','0.000030710000000','0.001059610709061','0.001012150695965','32.95834242802488','32.958342428024878','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','ADXBTC','4h','0.000031230000000','0.000030860000000','0.001059610709061','0.001047056883818','33.9292574146974','33.929257414697403','test'),('2019-02-28 03:59:59','2019-03-03 15:59:59','ADXBTC','4h','0.000031140000000','0.000032060000000','0.001059610709061','0.001090915842405','34.02731885231214','34.027318852312142','test'),('2019-03-06 07:59:59','2019-03-06 23:59:59','ADXBTC','4h','0.000032850000000','0.000032140000000','0.001059610709061','0.001036708925090','32.256033761369864','32.256033761369864','test'),('2019-03-07 07:59:59','2019-03-11 15:59:59','ADXBTC','4h','0.000032320000000','0.000035100000000','0.001059610709061','0.001150752966833','32.78498481005569','32.784984810055690','test'),('2019-03-11 19:59:59','2019-03-16 11:59:59','ADXBTC','4h','0.000037020000000','0.000035930000000','0.001059610709061','0.001028412014494','28.622655566207452','28.622655566207452','test'),('2019-03-17 19:59:59','2019-03-18 11:59:59','ADXBTC','4h','0.000037050000000','0.000035770000000','0.001059610709061','0.001023003375523','28.59947932688259','28.599479326882591','test'),('2019-03-26 15:59:59','2019-03-29 03:59:59','ADXBTC','4h','0.000048050000000','0.000040200000000','0.001059610709061','0.000886500530786','22.05225200959417','22.052252009594170','test'),('2019-04-01 03:59:59','2019-04-02 03:59:59','ADXBTC','4h','0.000040730000000','0.000039140000000','0.001059610709061','0.001018246087715','26.015485123029706','26.015485123029706','test'),('2019-04-21 03:59:59','2019-04-21 11:59:59','ADXBTC','4h','0.000034530000000','0.000032020000000','0.001059610709061','0.000982587167800','30.686669825108595','30.686669825108595','test'),('2019-04-22 03:59:59','2019-04-22 07:59:59','ADXBTC','4h','0.000033720000000','0.000032890000000','0.001059610709061','0.001033528950801','31.423805132295367','31.423805132295367','test'),('2019-04-22 19:59:59','2019-04-23 03:59:59','ADXBTC','4h','0.000033710000000','0.000032600000000','0.001059610709061','0.001024719938160','31.43312693743696','31.433126937436960','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  5:57:02
