-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-29 07:59:59','2018-11-30 11:59:59','NXSETH','4h','0.003013000000000','0.002517000000000','0.072144500000000','0.060268073846664','23.94440756720876','23.944407567208760','test'),('2018-12-05 03:59:59','2018-12-05 07:59:59','NXSETH','4h','0.002564000000000','0.002669000000000','0.072144500000000','0.075098935452418','28.137480499219972','28.137480499219972','test'),('2018-12-05 15:59:59','2018-12-06 19:59:59','NXSETH','4h','0.002697000000000','0.002624000000000','0.072144500000000','0.070191756766778','26.749907304412307','26.749907304412307','test'),('2018-12-06 23:59:59','2018-12-07 19:59:59','NXSETH','4h','0.002675000000000','0.002583000000000','0.072144500000000','0.069663268598131','26.969906542056076','26.969906542056076','test'),('2018-12-07 23:59:59','2018-12-08 03:59:59','NXSETH','4h','0.002596000000000','0.002599000000000','0.072144500000000','0.072227871918336','27.790639445300464','27.790639445300464','test'),('2018-12-08 07:59:59','2018-12-11 03:59:59','NXSETH','4h','0.002644000000000','0.002654000000000','0.072144500000000','0.072417361195159','27.286119515885023','27.286119515885023','test'),('2018-12-13 07:59:59','2018-12-13 11:59:59','NXSETH','4h','0.002735000000000','0.002645000000000','0.072144500000000','0.069770457952468','26.378244972577697','26.378244972577697','test'),('2018-12-13 19:59:59','2018-12-16 11:59:59','NXSETH','4h','0.002747000000000','0.002758000000000','0.072144500000000','0.072433393156170','26.263014197306152','26.263014197306152','test'),('2018-12-16 23:59:59','2018-12-20 19:59:59','NXSETH','4h','0.002807000000000','0.002788000000000','0.072144500000000','0.071656168863555','25.70163876024225','25.701638760242250','test'),('2018-12-21 15:59:59','2018-12-22 23:59:59','NXSETH','4h','0.002985000000000','0.002925000000000','0.072144500000000','0.070694359296482','24.169011725293135','24.169011725293135','test'),('2019-01-07 07:59:59','2019-01-12 03:59:59','NXSETH','4h','0.002549000000000','0.002613000000000','0.072144500000000','0.073955895841506','28.30306002353864','28.303060023538642','test'),('2019-01-13 15:59:59','2019-01-13 23:59:59','NXSETH','4h','0.002692000000000','0.002573000000000','0.072144500000000','0.068955348625557','26.799591381872215','26.799591381872215','test'),('2019-01-15 03:59:59','2019-01-15 11:59:59','NXSETH','4h','0.002756000000000','0.002636000000000','0.072144500000000','0.069003230043541','26.177249637155295','26.177249637155295','test'),('2019-01-15 23:59:59','2019-01-25 19:59:59','NXSETH','4h','0.002715000000000','0.003173000000000','0.072144500000000','0.084314732412523','26.57255985267035','26.572559852670349','test'),('2019-01-25 23:59:59','2019-01-26 23:59:59','NXSETH','4h','0.003242000000000','0.003140000000000','0.072144500000000','0.069874685379395','22.25308451573103','22.253084515731029','test'),('2019-01-27 07:59:59','2019-01-27 15:59:59','NXSETH','4h','0.003218000000000','0.003117000000000','0.072144500000000','0.069880176041019','22.419049098819144','22.419049098819144','test'),('2019-01-27 19:59:59','2019-01-28 03:59:59','NXSETH','4h','0.003270000000000','0.003087000000000','0.072144500000000','0.068107055504587','22.062538226299694','22.062538226299694','test'),('2019-01-28 07:59:59','2019-01-28 19:59:59','NXSETH','4h','0.003212000000000','0.003141000000000','0.072144500000000','0.070549774128269','22.46092777085928','22.460927770859278','test'),('2019-01-29 03:59:59','2019-01-30 03:59:59','NXSETH','4h','0.003275000000000','0.003194000000000','0.072144500000000','0.070360162748092','22.02885496183206','22.028854961832060','test'),('2019-01-30 07:59:59','2019-01-30 15:59:59','NXSETH','4h','0.003236000000000','0.003141000000000','0.072144500000000','0.070026537237330','22.294344870210136','22.294344870210136','test'),('2019-03-02 19:59:59','2019-03-05 19:59:59','NXSETH','4h','0.002242000000000','0.002305000000000','0.072144500000000','0.074171754014273','32.17863514719001','32.178635147190008','test'),('2019-03-05 23:59:59','2019-03-07 23:59:59','NXSETH','4h','0.002339000000000','0.002347000000000','0.072144500000000','0.072391253313382','30.84416417272339','30.844164172723389','test'),('2019-03-08 03:59:59','2019-03-14 07:59:59','NXSETH','4h','0.002432000000000','0.002938000000000','0.072144500000000','0.087154827713816','29.664679276315788','29.664679276315788','test'),('2019-03-15 07:59:59','2019-03-16 07:59:59','NXSETH','4h','0.003104000000000','0.002894000000000','0.072144500000000','0.067263589884021','23.24242912371134','23.242429123711339','test'),('2019-03-17 15:59:59','2019-03-19 11:59:59','NXSETH','4h','0.003086000000000','0.002959000000000','0.072144500000000','0.069175494329229','23.377997407647438','23.377997407647438','test'),('2019-03-20 23:59:59','2019-03-21 23:59:59','NXSETH','4h','0.003046000000000','0.003029000000000','0.072144500000000','0.071741855055811','23.68499671700591','23.684996717005909','test'),('2019-03-24 19:59:59','2019-03-25 07:59:59','NXSETH','4h','0.003092000000000','0.002910000000000','0.072144500000000','0.067897960866753','23.33263260025873','23.332632600258730','test'),('2019-05-23 15:59:59','2019-05-24 15:59:59','NXSETH','4h','0.001648000000000','0.001536000000000','0.072144500000000','0.067241475728155','43.77700242718447','43.777002427184470','test'),('2019-05-24 19:59:59','2019-05-24 23:59:59','NXSETH','4h','0.001542000000000','0.001508000000000','0.072144500000000','0.070553765239948','46.78631647211414','46.786316472114137','test'),('2019-06-06 07:59:59','2019-06-07 03:59:59','NXSETH','4h','0.001450000000000','0.001481000000000','0.072144500000000','0.073686899655172','49.7548275862069','49.754827586206900','test'),('2019-06-07 15:59:59','2019-06-11 03:59:59','NXSETH','4h','0.001479000000000','0.001509000000000','0.072144500000000','0.073607877281947','48.77924273157539','48.779242731575387','test'),('2019-07-14 07:59:59','2019-07-15 07:59:59','NXSETH','4h','0.001066000000000','0.001050000000000','0.072144500000000','0.071061655722326','67.67776735459661','67.677767354596611','test'),('2019-07-15 15:59:59','2019-07-15 23:59:59','NXSETH','4h','0.001060000000000','0.001044000000000','0.072144500000000','0.071055526415094','68.06084905660377','68.060849056603772','test'),('2019-07-16 11:59:59','2019-07-17 11:59:59','NXSETH','4h','0.001074000000000','0.001053000000000','0.072144500000000','0.070733853351955','67.17364990689012','67.173649906890120','test'),('2019-07-19 19:59:59','2019-07-20 07:59:59','NXSETH','4h','0.001064000000000','0.001080000000000','0.072144500000000','0.073229379699248','67.80498120300751','67.804981203007515','test'),('2019-07-20 15:59:59','2019-07-22 23:59:59','NXSETH','4h','0.001084000000000','0.001069000000000','0.072144500000000','0.071146190498155','66.5539667896679','66.553966789667896','test'),('2019-07-23 03:59:59','2019-07-23 19:59:59','NXSETH','4h','0.001097000000000','0.001137000000000','0.072144500000000','0.074775110756609','65.76526891522333','65.765268915223331','test'),('2019-07-24 03:59:59','2019-07-27 11:59:59','NXSETH','4h','0.001146000000000','0.001107000000000','0.072144500000000','0.069689320680628','62.95331588132635','62.953315881326347','test'),('2019-07-27 15:59:59','2019-07-30 15:59:59','NXSETH','4h','0.001139000000000','0.001221000000000','0.072144500000000','0.077338397278314','63.34021071115013','63.340210711150128','test'),('2019-08-01 03:59:59','2019-08-02 15:59:59','NXSETH','4h','0.001301000000000','0.001275000000000','0.072144500000000','0.070702719062260','55.45311299000768','55.453112990007682','test'),('2019-08-03 23:59:59','2019-08-04 03:59:59','NXSETH','4h','0.001352000000000','0.001258000000000','0.072144500000000','0.067128536242604','53.36131656804734','53.361316568047343','test'),('2019-08-16 03:59:59','2019-08-19 07:59:59','NXSETH','4h','0.001169000000000','0.001136000000000','0.072144500000000','0.070107914456801','61.714713430282295','61.714713430282295','test'),('2019-08-22 23:59:59','2019-08-25 11:59:59','NXSETH','4h','0.001210000000000','0.001244000000000','0.072144500000000','0.074171700826446','59.62355371900827','59.623553719008271','test'),('2019-08-25 23:59:59','2019-08-26 03:59:59','NXSETH','4h','0.001225000000000','0.001217000000000','0.072144500000000','0.071673352244898','58.893469387755104','58.893469387755104','test'),('2019-08-26 07:59:59','2019-08-28 11:59:59','NXSETH','4h','0.001314000000000','0.001261000000000','0.072144500000000','0.069234562024353','54.9044901065449','54.904490106544898','test'),('2019-08-29 03:59:59','2019-09-01 23:59:59','NXSETH','4h','0.001319000000000','0.001321000000000','0.072144500000000','0.072253892721759','54.696360879454126','54.696360879454126','test'),('2019-09-04 07:59:59','2019-09-04 15:59:59','NXSETH','4h','0.001339000000000','0.001305000000000','0.072144500000000','0.070312600821509','53.879387602688574','53.879387602688574','test'),('2019-09-04 23:59:59','2019-09-05 11:59:59','NXSETH','4h','0.001330000000000','0.001267000000000','0.072144500000000','0.068727128947368','54.24398496240602','54.243984962406017','test'),('2019-10-02 07:59:59','2019-10-03 03:59:59','NXSETH','4h','0.001106000000000','0.001080000000000','0.072144500000000','0.070448517179024','65.23010849909583','65.230108499095834','test'),('2019-10-03 07:59:59','2019-10-06 11:59:59','NXSETH','4h','0.001110000000000','0.001110000000000','0.072144500000000','0.072144500000000','64.99504504504505','64.995045045045046','test'),('2019-10-08 19:59:59','2019-10-09 15:59:59','NXSETH','4h','0.001195000000000','0.001024000000000','0.072144500000000','0.061820893723849','60.37196652719665','60.371966527196648','test'),('2019-10-17 11:59:59','2019-10-21 11:59:59','NXSETH','4h','0.001166000000000','0.001380000000000','0.072144500000000','0.085385428816467','61.87349914236707','61.873499142367073','test'),('2019-10-22 07:59:59','2019-10-24 07:59:59','NXSETH','4h','0.001472000000000','0.001482000000000','0.072144500000000','0.072634612092391','49.01120923913044','49.011209239130437','test'),('2019-10-24 11:59:59','2019-10-25 19:59:59','NXSETH','4h','0.001548000000000','0.001517000000000','0.072144500000000','0.070699745801034','46.60497416020672','46.604974160206723','test'),('2019-10-25 23:59:59','2019-10-26 03:59:59','NXSETH','4h','0.001537000000000','0.001527000000000','0.072144500000000','0.071675114834092','46.938516590761225','46.938516590761225','test'),('2019-10-26 07:59:59','2019-11-04 11:59:59','NXSETH','4h','0.001558000000000','0.001852000000000','0.072144500000000','0.085758417201540','46.305840821566115','46.305840821566115','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:40:25
