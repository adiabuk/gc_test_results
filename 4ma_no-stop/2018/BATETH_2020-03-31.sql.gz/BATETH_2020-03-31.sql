-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-30 19:59:59','2018-05-03 07:59:59','BATETH','4h','0.000744550000000','0.000696630000000','0.072144500000000','0.067501206144651','96.8967832919213','96.896783291921295','test'),('2018-05-17 03:59:59','2018-05-17 19:59:59','BATETH','4h','0.000591110000000','0.000539590000000','0.072144500000000','0.065856525443657','122.0491955811947','122.049195581194695','test'),('2018-06-16 03:59:59','2018-06-18 03:59:59','BATETH','4h','0.000507150000000','0.000469230000000','0.072144500000000','0.066750199615498','142.25475697525385','142.254756975253855','test'),('2018-06-18 07:59:59','2018-06-19 19:59:59','BATETH','4h','0.000489140000000','0.000467440000000','0.072144500000000','0.068943911927056','147.49253792370283','147.492537923702827','test'),('2018-06-20 23:59:59','2018-06-25 23:59:59','BATETH','4h','0.000496150000000','0.000548410000000','0.072144500000000','0.079743555870201','145.40864657865566','145.408646578655663','test'),('2018-07-01 07:59:59','2018-07-03 23:59:59','BATETH','4h','0.000542230000000','0.000545690000000','0.072144500000000','0.072604858095273','133.05147262231895','133.051472622318954','test'),('2018-07-07 11:59:59','2018-07-08 07:59:59','BATETH','4h','0.000573800000000','0.000547490000000','0.072144500000000','0.068836514996514','125.73109097246429','125.731090972464287','test'),('2018-07-08 15:59:59','2018-07-10 03:59:59','BATETH','4h','0.000570030000000','0.000546970000000','0.072144500000000','0.069225965589530','126.56263705419013','126.562637054190134','test'),('2018-07-10 19:59:59','2018-07-18 11:59:59','BATETH','4h','0.000569700000000','0.000724050000000','0.072144500000000','0.091690758688784','126.63594874495348','126.635948744953481','test'),('2018-07-18 15:59:59','2018-07-19 23:59:59','BATETH','4h','0.000768120000000','0.000725570000000','0.072607749092791','0.068585643531292','94.52657018797974','94.526570187979743','test'),('2018-07-23 11:59:59','2018-07-24 15:59:59','BATETH','4h','0.000832730000000','0.000733840000000','0.072607749092791','0.063985290063110','87.19242622793823','87.192426227938228','test'),('2018-07-24 19:59:59','2018-07-24 23:59:59','BATETH','4h','0.000735900000000','0.000731800000000','0.072607749092791','0.072203221614492','98.66523860958145','98.665238609581451','test'),('2018-08-07 15:59:59','2018-08-08 11:59:59','BATETH','4h','0.000740010000000','0.000657600000000','0.072607749092791','0.064521906195078','98.11725394628586','98.117253946285857','test'),('2018-08-10 07:59:59','2018-08-10 11:59:59','BATETH','4h','0.000675970000000','0.000648670000000','0.072607749092791','0.069675382937143','107.41267969405594','107.412679694055939','test'),('2018-08-11 03:59:59','2018-08-11 07:59:59','BATETH','4h','0.000672420000000','0.000643900000000','0.072607749092791','0.069528166385366','107.9797583248431','107.979758324843104','test'),('2018-08-11 15:59:59','2018-08-12 03:59:59','BATETH','4h','0.000674950000000','0.000665040000000','0.072607749092791','0.071541680801052','107.5750042118542','107.575004211854207','test'),('2018-08-12 07:59:59','2018-08-12 15:59:59','BATETH','4h','0.000667440000000','0.000662780000000','0.072607749092791','0.072100808977167','108.78543253744306','108.785432537443057','test'),('2018-08-13 03:59:59','2018-08-13 19:59:59','BATETH','4h','0.000672310000000','0.000693070000000','0.072607749092791','0.074849775644778','107.99742543289703','107.997425432897032','test'),('2018-08-14 23:59:59','2018-08-15 19:59:59','BATETH','4h','0.000688000000000','0.000691030000000','0.072607749092791','0.072927518685453','105.53451903021947','105.534519030219471','test'),('2018-08-16 19:59:59','2018-08-18 15:59:59','BATETH','4h','0.000695000000000','0.000694910000000','0.072607749092791','0.072598346650462','104.47158142847626','104.471581428476256','test'),('2018-08-18 19:59:59','2018-08-21 11:59:59','BATETH','4h','0.000703860000000','0.000713000000000','0.072607749092791','0.073550599697610','103.15652131502144','103.156521315021436','test'),('2018-08-21 15:59:59','2018-08-23 11:59:59','BATETH','4h','0.000753500000000','0.000735710000000','0.072607749092791','0.070893493145398','96.36064909461312','96.360649094613123','test'),('2018-08-23 15:59:59','2018-08-29 11:59:59','BATETH','4h','0.000740910000000','0.000762410000000','0.072607749092791','0.074714707570197','97.99806871656611','97.998068716566110','test'),('2018-08-30 07:59:59','2018-08-30 15:59:59','BATETH','4h','0.000787350000000','0.000770000000000','0.072607749092791','0.071007768846700','92.21788161909062','92.217881619090619','test'),('2018-08-31 11:59:59','2018-09-01 03:59:59','BATETH','4h','0.000788620000000','0.000769940000000','0.072607749092791','0.070887893201420','92.06937319975526','92.069373199755262','test'),('2018-09-01 07:59:59','2018-09-01 23:59:59','BATETH','4h','0.000786160000000','0.000772930000000','0.072607749092791','0.071385859756654','92.35747060749846','92.357470607498456','test'),('2018-09-02 07:59:59','2018-09-05 19:59:59','BATETH','4h','0.000779690000000','0.000795700000000','0.072607749092791','0.074098662228750','93.12386857955212','93.123868579552123','test'),('2018-09-07 15:59:59','2018-09-08 03:59:59','BATETH','4h','0.000820000000000','0.000791990000000','0.072607749092791','0.070127574639024','88.54603547901341','88.546035479013412','test'),('2018-09-08 07:59:59','2018-09-08 11:59:59','BATETH','4h','0.000809000000000','0.000797550000000','0.072607749092791','0.071580111605631','89.74999887860444','89.749998878604444','test'),('2018-09-08 23:59:59','2018-09-09 03:59:59','BATETH','4h','0.000809600000000','0.000798980000000','0.072607749092791','0.071655310486855','89.68348455137229','89.683484551372288','test'),('2018-09-09 07:59:59','2018-09-09 11:59:59','BATETH','4h','0.000806940000000','0.000807310000000','0.072607749092791','0.072641041366274','89.97911752148981','89.979117521489812','test'),('2018-09-12 03:59:59','2018-09-12 07:59:59','BATETH','4h','0.000805210000000','0.000784080000000','0.072607749092791','0.070702405470220','90.17243836116168','90.172438361161682','test'),('2018-09-12 23:59:59','2018-09-13 03:59:59','BATETH','4h','0.000804020000000','0.000792000000000','0.072607749092791','0.071522272184138','90.3058992223962','90.305899222396206','test'),('2018-09-13 07:59:59','2018-09-13 11:59:59','BATETH','4h','0.000792410000000','0.000790160000000','0.072607749092791','0.072401583805302','91.62901666156534','91.629016661565345','test'),('2018-09-26 11:59:59','2018-09-28 15:59:59','BATETH','4h','0.000759860000000','0.000754370000000','0.072607749092791','0.072083157006723','95.55411403783722','95.554114037837223','test'),('2018-09-28 19:59:59','2018-09-29 03:59:59','BATETH','4h','0.000756830000000','0.000750200000000','0.072607749092791','0.071971688978254','95.93666885930922','95.936668859309222','test'),('2018-10-02 03:59:59','2018-10-06 19:59:59','BATETH','4h','0.000757580000000','0.000763050000000','0.072607749092791','0.073132003148518','95.84169208900842','95.841692089008419','test'),('2018-10-06 23:59:59','2018-10-07 03:59:59','BATETH','4h','0.000774000000000','0.000777650000000','0.072607749092791','0.072950149976756','93.8084613601951','93.808461360195096','test'),('2018-10-09 11:59:59','2018-10-10 07:59:59','BATETH','4h','0.000786770000000','0.000774510000000','0.072607749092791','0.071476324402122','92.28586383923002','92.285863839230018','test'),('2018-10-10 11:59:59','2018-10-11 07:59:59','BATETH','4h','0.000785950000000','0.000794640000000','0.072607749092791','0.073410549957498','92.38214783738277','92.382147837382774','test'),('2018-10-11 11:59:59','2018-10-15 07:59:59','BATETH','4h','0.000806820000000','0.000833000000000','0.072607749092791','0.074963752750669','89.99250030092338','89.992500300923382','test'),('2018-10-16 03:59:59','2018-10-26 23:59:59','BATETH','4h','0.000892420000000','0.001310000000000','0.072607749092791','0.106582272149387','81.36051309113533','81.360513091135331','test'),('2018-10-31 07:59:59','2018-11-01 07:59:59','BATETH','4h','0.001261080000000','0.001237700000000','0.072658050042139','0.071310994177336','57.61573416606284','57.615734166062843','test'),('2018-11-01 11:59:59','2018-11-07 03:59:59','BATETH','4h','0.001255430000000','0.001420980000000','0.072658050042139','0.082239261407549','57.87503089948384','57.875030899483839','test'),('2018-11-07 11:59:59','2018-11-08 23:59:59','BATETH','4h','0.001467250000000','0.001442080000000','0.074716588917290','0.073434860143701','50.92287539089472','50.922875390894717','test'),('2018-11-09 03:59:59','2018-11-09 07:59:59','BATETH','4h','0.001490360000000','0.001374940000000','0.074716588917290','0.068930209322539','50.133248958164465','50.133248958164465','test'),('2018-11-22 07:59:59','2018-11-24 23:59:59','BATETH','4h','0.001345600000000','0.001298070000000','0.074716588917290','0.072077409762089','55.5265969956079','55.526596995607903','test'),('2018-11-27 23:59:59','2018-12-05 03:59:59','BATETH','4h','0.001293000000000','0.001455370000000','0.074716588917290','0.084099212693392','57.78545159883217','57.785451598832168','test'),('2018-12-08 03:59:59','2018-12-13 11:59:59','BATETH','4h','0.001476250000000','0.001526130000000','0.074716588917290','0.077241136558404','50.61242263660626','50.612422636606262','test'),('2018-12-14 23:59:59','2018-12-15 11:59:59','BATETH','4h','0.001566100000000','0.001525130000000','0.075266559890709','0.073297547082636','48.05986839327567','48.059868393275671','test'),('2019-01-11 11:59:59','2019-01-14 15:59:59','BATETH','4h','0.001002130000000','0.000973690000000','0.075266559890709','0.073130528673909','75.10658286919761','75.106582869197609','test'),('2019-01-16 15:59:59','2019-01-21 11:59:59','BATETH','4h','0.001030120000000','0.001023530000000','0.075266559890709','0.074785056153591','73.06581746855609','73.065817468556091','test'),('2019-01-21 23:59:59','2019-01-22 03:59:59','BATETH','4h','0.001047590000000','0.001028500000000','0.075266559890709','0.073894994079358','71.84734475387224','71.847344753872235','test'),('2019-01-22 11:59:59','2019-01-28 19:59:59','BATETH','4h','0.001054860000000','0.001072210000000','0.075266559890709','0.076504520202128','71.3521793325266','71.352179332526603','test'),('2019-01-30 03:59:59','2019-01-30 15:59:59','BATETH','4h','0.001093090000000','0.001067940000000','0.075266559890709','0.073534814122976','68.85669056592688','68.856690565926883','test'),('2019-02-07 15:59:59','2019-02-08 11:59:59','BATETH','4h','0.001179210000000','0.001045980000000','0.075266559890709','0.066762761776515','63.82795251966063','63.827952519660627','test'),('2019-02-08 15:59:59','2019-02-08 19:59:59','BATETH','4h','0.001055970000000','0.001015260000000','0.075266559890709','0.072364866042256','71.2771763314384','71.277176331438397','test'),('2019-02-15 11:59:59','2019-02-17 15:59:59','BATETH','4h','0.001072710000000','0.001036360000000','0.075266559890709','0.072716066791896','70.16487204436335','70.164872044363349','test'),('2019-02-17 19:59:59','2019-02-17 23:59:59','BATETH','4h','0.001080600000000','0.001032970000000','0.075266559890709','0.071949008301227','69.6525632895697','69.652563289569699','test'),('2019-02-18 03:59:59','2019-02-18 07:59:59','BATETH','4h','0.001038390000000','0.001046280000000','0.075266559890709','0.075838457884274','72.4839028599168','72.483902859916796','test'),('2019-02-26 07:59:59','2019-03-05 23:59:59','BATETH','4h','0.001325730000000','0.001285300000000','0.075266559890709','0.072971200340588','56.77367178136499','56.773671781364989','test'),('2019-03-08 03:59:59','2019-03-11 23:59:59','BATETH','4h','0.001388110000000','0.001440060000000','0.075266559890709','0.078083409986395','54.22233100453783','54.222331004537828','test'),('2019-03-13 03:59:59','2019-03-13 15:59:59','BATETH','4h','0.001467460000000','0.001441140000000','0.075266559890709','0.073916597468344','51.29036559136808','51.290365591368079','test'),('2019-03-21 19:59:59','2019-04-02 19:59:59','BATETH','4h','0.001435230000000','0.001914350000000','0.075266559890709','0.100392647120516','52.44215902030267','52.442159020302668','test'),('2019-04-13 19:59:59','2019-04-16 03:59:59','BATETH','4h','0.001887920000000','0.001819180000000','0.075552579307203','0.072801676566845','40.01895170727707','40.018951707277068','test'),('2019-04-16 11:59:59','2019-04-22 23:59:59','BATETH','4h','0.001920310000000','0.002337200000000','0.075552579307203','0.091954678336724','39.343949314018566','39.343949314018566','test'),('2019-04-24 03:59:59','2019-04-26 07:59:59','BATETH','4h','0.002529660000000','0.002389190000000','0.078965378379493','0.074580493967767','31.215807017343547','31.215807017343547','test'),('2019-04-28 03:59:59','2019-04-29 19:59:59','BATETH','4h','0.002596570000000','0.002455330000000','0.078965378379493','0.074670069551955','30.41141905648336','30.411419056483361','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  2:40:28
