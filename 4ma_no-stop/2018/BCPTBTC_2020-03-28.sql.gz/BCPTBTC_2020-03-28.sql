-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-01 23:59:59','2018-05-03 19:59:59','BCPTBTC','4h','0.000067400000000','0.000067270000000','0.001467500000000','0.001464669510386','21.77299703264095','21.772997032640951','test'),('2018-07-02 15:59:59','2018-07-03 23:59:59','BCPTBTC','4h','0.000028860000000','0.000026180000000','0.001467500000000','0.001331224878725','50.848925848925845','50.848925848925845','test'),('2018-07-04 11:59:59','2018-07-06 07:59:59','BCPTBTC','4h','0.000027190000000','0.000025800000000','0.001467500000000','0.001392478852519','53.97204854726002','53.972048547260023','test'),('2018-07-08 15:59:59','2018-07-09 03:59:59','BCPTBTC','4h','0.000028410000000','0.000026900000000','0.001467500000000','0.001389501935938','51.654347060894054','51.654347060894054','test'),('2018-07-09 07:59:59','2018-07-09 11:59:59','BCPTBTC','4h','0.000027710000000','0.000027170000000','0.001467500000000','0.001438902020931','52.959220498015156','52.959220498015156','test'),('2018-07-16 23:59:59','2018-07-17 19:59:59','BCPTBTC','4h','0.000028740000000','0.000026870000000','0.001467500000000','0.001372015483646','51.06123869171886','51.061238691718863','test'),('2018-07-17 23:59:59','2018-07-18 23:59:59','BCPTBTC','4h','0.000027210000000','0.000026250000000','0.001467500000000','0.001415724917310','53.93237780227858','53.932377802278580','test'),('2018-08-28 07:59:59','2018-08-29 15:59:59','BCPTBTC','4h','0.000013680000000','0.000013340000000','0.001467500000000','0.001431027046784','107.27339181286551','107.273391812865512','test'),('2018-08-29 19:59:59','2018-08-29 23:59:59','BCPTBTC','4h','0.000013390000000','0.000013660000000','0.001467500000000','0.001497091112771','109.596713965646','109.596713965646003','test'),('2018-08-31 23:59:59','2018-09-02 11:59:59','BCPTBTC','4h','0.000013480000000','0.000013750000000','0.001467500000000','0.001496893545994','108.86498516320475','108.864985163204750','test'),('2018-09-02 15:59:59','2018-09-05 11:59:59','BCPTBTC','4h','0.000014430000000','0.000012640000000','0.001467500000000','0.001285460845461','101.69785169785169','101.697851697851689','test'),('2018-09-16 03:59:59','2018-09-20 07:59:59','BCPTBTC','4h','0.000012220000000','0.000012770000000','0.001467500000000','0.001533549509002','120.09001636661212','120.090016366612119','test'),('2018-09-20 15:59:59','2018-09-21 15:59:59','BCPTBTC','4h','0.000013410000000','0.000012510000000','0.001467500000000','0.001369010067114','109.43325876211783','109.433258762117831','test'),('2018-09-21 19:59:59','2018-09-22 11:59:59','BCPTBTC','4h','0.000013030000000','0.000012710000000','0.001467500000000','0.001431460092095','112.62471220260936','112.624712202609359','test'),('2018-09-22 19:59:59','2018-09-22 23:59:59','BCPTBTC','4h','0.000013300000000','0.000013290000000','0.001467500000000','0.001466396616541','110.33834586466166','110.338345864661662','test'),('2018-09-23 03:59:59','2018-09-24 07:59:59','BCPTBTC','4h','0.000013470000000','0.000012680000000','0.001467500000000','0.001381432813660','108.94580549368969','108.945805493689690','test'),('2018-09-27 11:59:59','2018-09-28 11:59:59','BCPTBTC','4h','0.000013060000000','0.000013270000000','0.001467500000000','0.001491096860643','112.36600306278714','112.366003062787144','test'),('2018-09-28 15:59:59','2018-10-01 03:59:59','BCPTBTC','4h','0.000013720000000','0.000014240000000','0.001467500000000','0.001523119533528','106.96064139941691','106.960641399416915','test'),('2018-10-04 23:59:59','2018-10-06 11:59:59','BCPTBTC','4h','0.000014740000000','0.000013890000000','0.001467500000000','0.001382874830393','99.55902306648576','99.559023066485764','test'),('2018-10-08 03:59:59','2018-10-09 11:59:59','BCPTBTC','4h','0.000014360000000','0.000014160000000','0.001467500000000','0.001447061281337','102.19359331476323','102.193593314763234','test'),('2018-10-09 19:59:59','2018-10-09 23:59:59','BCPTBTC','4h','0.000014310000000','0.000014340000000','0.001467500000000','0.001470576519916','102.55066387141859','102.550663871418593','test'),('2018-10-10 11:59:59','2018-10-11 03:59:59','BCPTBTC','4h','0.000015150000000','0.000014430000000','0.001467500000000','0.001397757425743','96.86468646864687','96.864686468646866','test'),('2018-10-11 11:59:59','2018-10-15 07:59:59','BCPTBTC','4h','0.000015050000000','0.000015560000000','0.001467500000000','0.001517229235880','97.50830564784053','97.508305647840530','test'),('2018-10-17 07:59:59','2018-10-18 19:59:59','BCPTBTC','4h','0.000017900000000','0.000016220000000','0.001467500000000','0.001329768156425','81.98324022346368','81.983240223463682','test'),('2018-10-20 15:59:59','2018-10-21 23:59:59','BCPTBTC','4h','0.000017310000000','0.000016350000000','0.001467500000000','0.001386113518198','84.77758521086078','84.777585210860778','test'),('2018-10-22 07:59:59','2018-10-22 23:59:59','BCPTBTC','4h','0.000017110000000','0.000017050000000','0.001467500000000','0.001462353886616','85.76855639976623','85.768556399766226','test'),('2018-10-23 23:59:59','2018-10-26 11:59:59','BCPTBTC','4h','0.000017060000000','0.000017120000000','0.001467500000000','0.001472661195780','86.01992966002345','86.019929660023450','test'),('2018-10-29 19:59:59','2018-11-03 03:59:59','BCPTBTC','4h','0.000018560000000','0.000018260000000','0.001467500000000','0.001443779633621','79.06788793103449','79.067887931034491','test'),('2018-11-05 03:59:59','2018-11-05 07:59:59','BCPTBTC','4h','0.000018770000000','0.000018110000000','0.001467500000000','0.001415899041023','78.18327117741076','78.183271177410759','test'),('2018-12-02 15:59:59','2018-12-03 15:59:59','BCPTBTC','4h','0.000010170000000','0.000009710000000','0.001467500000000','0.001401123402163','144.29695181907573','144.296951819075730','test'),('2018-12-04 15:59:59','2018-12-05 19:59:59','BCPTBTC','4h','0.000010380000000','0.000009930000000','0.001467500000000','0.001403880057803','141.3776493256262','141.377649325626209','test'),('2018-12-05 23:59:59','2018-12-06 03:59:59','BCPTBTC','4h','0.000009990000000','0.000010140000000','0.001467500000000','0.001489534534535','146.89689689689692','146.896896896896919','test'),('2018-12-17 15:59:59','2018-12-18 07:59:59','BCPTBTC','4h','0.000009130000000','0.000009130000000','0.001467500000000','0.001467500000000','160.7338444687842','160.733844468784213','test'),('2018-12-18 15:59:59','2018-12-19 07:59:59','BCPTBTC','4h','0.000009410000000','0.000009270000000','0.001467500000000','0.001445666843783','155.95111583421894','155.951115834218939','test'),('2018-12-19 11:59:59','2018-12-19 15:59:59','BCPTBTC','4h','0.000009320000000','0.000009080000000','0.001467500000000','0.001429710300429','157.45708154506437','157.457081545064369','test'),('2018-12-19 19:59:59','2018-12-19 23:59:59','BCPTBTC','4h','0.000009180000000','0.000009020000000','0.001467500000000','0.001441922657952','159.85838779956427','159.858387799564269','test'),('2018-12-24 11:59:59','2018-12-24 19:59:59','BCPTBTC','4h','0.000009150000000','0.000009080000000','0.001467500000000','0.001456273224044','160.38251366120218','160.382513661202182','test'),('2018-12-24 23:59:59','2018-12-25 03:59:59','BCPTBTC','4h','0.000009100000000','0.000008540000000','0.001467500000000','0.001377192307692','161.2637362637363','161.263736263736291','test'),('2019-01-02 07:59:59','2019-01-03 15:59:59','BCPTBTC','4h','0.000009090000000','0.000008660000000','0.001467500000000','0.001398080308031','161.44114411441146','161.441144114411458','test'),('2019-01-06 11:59:59','2019-01-06 23:59:59','BCPTBTC','4h','0.000008970000000','0.000008630000000','0.000978333333333','0.000941250464511','109.0672612411743','109.067261241174293','test'),('2019-01-07 03:59:59','2019-01-07 07:59:59','BCPTBTC','4h','0.000008880000000','0.000008580000000','0.001087107783897','0.001050381169576','122.42204773620492','122.422047736204917','test'),('2019-01-17 15:59:59','2019-01-20 15:59:59','BCPTBTC','4h','0.000008970000000','0.000009190000000','0.001087107783897','0.001113770405130','121.19373287591972','121.193732875919721','test'),('2019-01-20 19:59:59','2019-01-20 23:59:59','BCPTBTC','4h','0.000009450000000','0.000009260000000','0.001087107783897','0.001065250590358','115.03786072984127','115.037860729841270','test'),('2019-01-23 03:59:59','2019-01-23 23:59:59','BCPTBTC','4h','0.000009800000000','0.000009140000000','0.001087107783897','0.001013894402533','110.92936570377552','110.929365703775517','test'),('2019-01-26 11:59:59','2019-01-27 03:59:59','BCPTBTC','4h','0.000009470000000','0.000009210000000','0.001087107783897','0.001057261107676','114.79490854244983','114.794908542449832','test'),('2019-01-27 07:59:59','2019-01-27 11:59:59','BCPTBTC','4h','0.000009260000000','0.000009160000000','0.001087107783897','0.001075367959017','117.39824880097193','117.398248800971928','test'),('2019-02-09 23:59:59','2019-02-10 07:59:59','BCPTBTC','4h','0.000008680000000','0.000008510000000','0.001087107783897','0.001065816502415','125.24283224619815','125.242832246198148','test'),('2019-02-10 11:59:59','2019-02-10 15:59:59','BCPTBTC','4h','0.000008580000000','0.000008530000000','0.001087107783897','0.001080772656951','126.70253891573428','126.702538915734280','test'),('2019-02-10 19:59:59','2019-02-10 23:59:59','BCPTBTC','4h','0.000008590000000','0.000008540000000','0.001087107783897','0.001080780031953','126.55503887043072','126.555038870430721','test'),('2019-02-13 11:59:59','2019-02-14 03:59:59','BCPTBTC','4h','0.000008630000000','0.000008560000000','0.001087107783897','0.001078289991907','125.96845699849362','125.968456998493622','test'),('2019-02-14 07:59:59','2019-02-14 11:59:59','BCPTBTC','4h','0.000008600000000','0.000008500000000','0.001087107783897','0.001074466995712','126.40788184848836','126.407881848488358','test'),('2019-02-14 15:59:59','2019-02-14 19:59:59','BCPTBTC','4h','0.000008610000000','0.000008520000000','0.001087107783897','0.001075744287898','126.26106665470382','126.261066654703825','test'),('2019-02-14 23:59:59','2019-02-15 03:59:59','BCPTBTC','4h','0.000008560000000','0.000008580000000','0.001087107783897','0.001089647755355','126.99857288516355','126.998572885163554','test'),('2019-02-15 07:59:59','2019-02-15 11:59:59','BCPTBTC','4h','0.000008620000000','0.000008510000000','0.001087107783897','0.001073235178766','126.11459209941994','126.114592099419937','test'),('2019-02-17 19:59:59','2019-02-18 11:59:59','BCPTBTC','4h','0.000008790000000','0.000008680000000','0.001087107783897','0.001073503477159','123.67551580170647','123.675515801706467','test'),('2019-02-20 23:59:59','2019-02-22 03:59:59','BCPTBTC','4h','0.000009200000000','0.000008670000000','0.001087107783897','0.001024480922433','118.16388955402174','118.163889554021736','test'),('2019-02-28 11:59:59','2019-03-04 19:59:59','BCPTBTC','4h','0.000008750000000','0.000009490000000','0.001087107783897','0.001179046042192','124.24088958822858','124.240889588228583','test'),('2019-03-05 15:59:59','2019-03-09 07:59:59','BCPTBTC','4h','0.000010200000000','0.000012050000000','0.001087107783897','0.001284279293721','106.57919449970588','106.579194499705878','test'),('2019-03-15 19:59:59','2019-03-16 07:59:59','BCPTBTC','4h','0.000012290000000','0.000011990000000','0.001087107783897','0.001060571385592','88.45466101684296','88.454661016842962','test'),('2019-03-16 19:59:59','2019-03-17 03:59:59','BCPTBTC','4h','0.000012140000000','0.000011690000000','0.001087107783897','0.001046811366866','89.54759340172981','89.547593401729813','test'),('2019-03-28 11:59:59','2019-04-02 07:59:59','BCPTBTC','4h','0.000011930000000','0.000011530000000','0.001087107783897','0.001050658235401','91.12387124031852','91.123871240318522','test'),('2019-04-07 15:59:59','2019-04-07 23:59:59','BCPTBTC','4h','0.000012600000000','0.000011830000000','0.001087107783897','0.001020673419326','86.27839554738095','86.278395547380953','test'),('2019-04-10 03:59:59','2019-04-10 15:59:59','BCPTBTC','4h','0.000012120000000','0.000011830000000','0.001087107783897','0.001061096129002','89.69536170767327','89.695361707673271','test'),('2019-04-19 23:59:59','2019-04-21 07:59:59','BCPTBTC','4h','0.000012060000000','0.000011220000000','0.001087107783897','0.001011388833775','90.14160728830845','90.141607288308450','test'),('2019-04-22 23:59:59','2019-04-23 07:59:59','BCPTBTC','4h','0.000011340000000','0.000012200000000','0.001087107783897','0.001169551584087','95.86488394153439','95.864883941534387','test'),('2019-04-23 15:59:59','2019-04-24 07:59:59','BCPTBTC','4h','0.000013840000000','0.000010400000000','0.001087107783897','0.000816901802928','78.54825028157515','78.548250281575150','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:44:03
