-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-19 11:59:59','2018-08-30 11:59:59','ZILETH','4h','0.000124770000000','0.000149960000000','0.072144500000000','0.086709859902220','578.2199246613769','578.219924661376922','test'),('2018-08-30 23:59:59','2018-09-02 11:59:59','ZILETH','4h','0.000160250000000','0.000154240000000','0.075785839975555','0.072943575399873','472.92255834979716','472.922558349797157','test'),('2018-09-04 07:59:59','2018-09-06 11:59:59','ZILETH','4h','0.000163120000000','0.000157110000000','0.075785839975555','0.072993583365372','464.6017654214996','464.601765421499579','test'),('2018-09-06 19:59:59','2018-09-13 07:59:59','ZILETH','4h','0.000164760000000','0.000172390000000','0.075785839975555','0.079295465849635','459.9771787785568','459.977178778556777','test'),('2018-09-26 23:59:59','2018-09-27 19:59:59','ZILETH','4h','0.000158780000000','0.000155000000000','0.075785839975555','0.073981642500384','477.3009193573184','477.300919357318378','test'),('2018-09-28 23:59:59','2018-09-29 11:59:59','ZILETH','4h','0.000157810000000','0.000150550000000','0.075785839975555','0.072299335962992','480.2347124742095','480.234712474209516','test'),('2018-10-01 23:59:59','2018-10-05 07:59:59','ZILETH','4h','0.000159220000000','0.000162960000000','0.075785839975555','0.077566012325188','475.9819116665934','475.981911666593419','test'),('2018-10-09 15:59:59','2018-10-11 07:59:59','ZILETH','4h','0.000164930000000','0.000165420000000','0.075785839975555','0.076010996475816','459.50306175683625','459.503061756836246','test'),('2018-10-14 19:59:59','2018-10-15 07:59:59','ZILETH','4h','0.000171100000000','0.000161310000000','0.075785839975555','0.071449525695247','442.93302148191117','442.933021481911169','test'),('2018-10-15 15:59:59','2018-10-15 19:59:59','ZILETH','4h','0.000166150000000','0.000165140000000','0.075785839975555','0.075325149645279','456.1290398769486','456.129039876948582','test'),('2018-10-17 07:59:59','2018-10-18 19:59:59','ZILETH','4h','0.000167990000000','0.000165810000000','0.075785839975555','0.074802369940751','451.13304348803507','451.133043488035071','test'),('2018-10-18 23:59:59','2018-10-19 03:59:59','ZILETH','4h','0.000166000000000','0.000166330000000','0.075785839975555','0.075936498573097','456.5412046720181','456.541204672018125','test'),('2018-10-19 05:59:59','2018-10-20 03:59:59','ZILETH','4h','0.000168000000000','0.000166630000000','0.075785839975555','0.075167824494802','451.10619033068457','451.106190330684569','test'),('2018-10-20 15:59:59','2018-10-22 11:59:59','ZILETH','4h','0.000168010000000','0.000166690000000','0.075785839975555','0.075190415246267','451.0793403699482','451.079340369948227','test'),('2018-10-22 19:59:59','2018-10-25 11:59:59','ZILETH','4h','0.000169370000000','0.000169170000000','0.075785839975555','0.075696348519009','447.4572827274901','447.457282727490110','test'),('2018-10-25 15:59:59','2018-10-29 11:59:59','ZILETH','4h','0.000170050000000','0.000172230000000','0.075785839975555','0.076757396171654','445.6679798621288','445.667979862128789','test'),('2018-10-31 03:59:59','2018-10-31 15:59:59','ZILETH','4h','0.000176500000000','0.000174000000000','0.075785839975555','0.074712386151539','429.38152960654395','429.381529606543950','test'),('2018-10-31 19:59:59','2018-11-01 15:59:59','ZILETH','4h','0.000175510000000','0.000172780000000','0.075785839975555','0.074607016300931','431.80354381832944','431.803543818329445','test'),('2018-11-01 19:59:59','2018-11-03 11:59:59','ZILETH','4h','0.000181220000000','0.000175340000000','0.075785839975555','0.073326835786965','418.19799125678736','418.197991256787361','test'),('2018-11-28 07:59:59','2018-11-30 11:59:59','ZILETH','4h','0.000157720000000','0.000145690000000','0.075785839975555','0.070005319718733','480.5087495279927','480.508749527992677','test'),('2018-12-07 11:59:59','2018-12-07 19:59:59','ZILETH','4h','0.000154500000000','0.000149200000000','0.075785839975555','0.073186066824290','490.5232360877347','490.523236087734688','test'),('2018-12-08 11:59:59','2018-12-08 15:59:59','ZILETH','4h','0.000152950000000','0.000149480000000','0.075785839975555','0.074066475054240','495.4942136355345','495.494213635534493','test'),('2018-12-08 19:59:59','2018-12-08 23:59:59','ZILETH','4h','0.000153510000000','0.000149220000000','0.075785839975555','0.073667924181827','493.6866652045795','493.686665204579526','test'),('2018-12-11 15:59:59','2018-12-11 23:59:59','ZILETH','4h','0.000152100000000','0.000151880000000','0.075785839975555','0.075676222061060','498.2632477025312','498.263247702531203','test'),('2018-12-12 11:59:59','2018-12-14 03:59:59','ZILETH','4h','0.000155290000000','0.000150310000000','0.075785839975555','0.073355461438120','488.0278187620259','488.027818762025902','test'),('2018-12-16 23:59:59','2018-12-17 07:59:59','ZILETH','4h','0.000153450000000','0.000152000000000','0.075785839975555','0.075069714410455','493.8797000687847','493.879700068784700','test'),('2018-12-17 11:59:59','2018-12-17 15:59:59','ZILETH','4h','0.000153000000000','0.000153090000000','0.075785839975555','0.075830419881423','495.33228742192813','495.332287421928129','test'),('2018-12-18 19:59:59','2018-12-19 23:59:59','ZILETH','4h','0.000168960000000','0.000153730000000','0.075785839975555','0.068954528760902','448.5430869765329','448.543086976532891','test'),('2018-12-20 03:59:59','2018-12-20 07:59:59','ZILETH','4h','0.000154150000000','0.000155250000000','0.075785839975555','0.076326640650048','491.636976811904','491.636976811903992','test'),('2018-12-20 11:59:59','2018-12-20 19:59:59','ZILETH','4h','0.000157140000000','0.000151440000000','0.075785839975555','0.073036830889004','482.28229588618433','482.282295886184329','test'),('2018-12-21 19:59:59','2018-12-23 03:59:59','ZILETH','4h','0.000158400000000','0.000146120000000','0.075785839975555','0.069910523593612','478.4459594416351','478.445959441635125','test'),('2018-12-29 19:59:59','2018-12-30 23:59:59','ZILETH','4h','0.000156940000000','0.000149660000000','0.075785839975555','0.072270350520846','482.8969031193769','482.896903119376873','test'),('2019-01-08 07:59:59','2019-01-13 23:59:59','ZILETH','4h','0.000151340000000','0.000157680000000','0.075785839975555','0.078960692793350','500.76542867421045','500.765428674210455','test'),('2019-01-14 07:59:59','2019-01-14 11:59:59','ZILETH','4h','0.000161590000000','0.000157580000000','0.075785839975555','0.073905146750096','469.00080435395137','469.000804353951366','test'),('2019-01-15 19:59:59','2019-01-19 23:59:59','ZILETH','4h','0.000164690000000','0.000180260000000','0.075785839975555','0.082950728726659','460.17268793220603','460.172687932206031','test'),('2019-01-20 03:59:59','2019-01-20 07:59:59','ZILETH','4h','0.000181590000000','0.000179200000000','0.075785839975555','0.074788383300950','417.34588895619254','417.345888956192539','test'),('2019-01-22 03:59:59','2019-01-25 11:59:59','ZILETH','4h','0.000185570000000','0.000184740000000','0.075785839975555','0.075446872215789','408.3948912839091','408.394891283909089','test'),('2019-01-25 15:59:59','2019-01-28 07:59:59','ZILETH','4h','0.000188350000000','0.000203000000000','0.075785839975555','0.081680517733144','402.36708242928063','402.367082429280629','test'),('2019-01-28 23:59:59','2019-01-29 07:59:59','ZILETH','4h','0.000197650000000','0.000188250000000','0.075785839975555','0.072181555150004','383.43455590971416','383.434555909714163','test'),('2019-03-04 03:59:59','2019-03-04 07:59:59','ZILETH','4h','0.000129360000000','0.000127930000000','0.075785839975555','0.074948071336369','585.8521952346553','585.852195234655255','test'),('2019-03-04 11:59:59','2019-03-04 15:59:59','ZILETH','4h','0.000128480000000','0.000127410000000','0.075785839975555','0.075154684552346','589.8648815033858','589.864881503385845','test'),('2019-03-04 19:59:59','2019-03-04 23:59:59','ZILETH','4h','0.000128420000000','0.000128820000000','0.075785839975555','0.076021896166103','590.1404763709314','590.140476370931424','test'),('2019-03-09 07:59:59','2019-03-15 15:59:59','ZILETH','4h','0.000132260000000','0.000134220000000','0.075785839975555','0.076908932719787','573.0065021590428','573.006502159042839','test'),('2019-03-20 03:59:59','2019-03-21 15:59:59','ZILETH','4h','0.000136270000000','0.000134110000000','0.075785839975555','0.074584567396505','556.1447125233361','556.144712523336125','test'),('2019-03-21 19:59:59','2019-03-25 15:59:59','ZILETH','4h','0.000136560000000','0.000138890000000','0.075785839975555','0.077078905347136','554.9636787899458','554.963678789945789','test'),('2019-03-31 15:59:59','2019-04-01 23:59:59','ZILETH','4h','0.000145120000000','0.000145820000000','0.075785839975555','0.076151400118767','522.2287760167793','522.228776016779307','test'),('2019-04-04 15:59:59','2019-04-07 23:59:59','ZILETH','4h','0.000145050000000','0.000141670000000','0.075785839975555','0.074019854873057','522.480799555705','522.480799555704948','test'),('2019-05-22 15:59:59','2019-05-23 23:59:59','ZILETH','4h','0.000088760000000','0.000082970000000','0.075785839975555','0.070842171504865','853.828751414545','853.828751414544968','test'),('2019-05-24 07:59:59','2019-05-24 15:59:59','ZILETH','4h','0.000082860000000','0.000079160000000','0.075785839975555','0.072401726918476','914.6251505618513','914.625150561851342','test'),('2019-06-03 15:59:59','2019-06-09 19:59:59','ZILETH','4h','0.000081090000000','0.000096070000000','0.075785839975555','0.089785986514386','934.5892215508078','934.589221550807792','test'),('2019-06-11 07:59:59','2019-06-11 15:59:59','ZILETH','4h','0.000099360000000','0.000095860000000','0.075785839975555','0.073116250201859','762.7399353417372','762.739935341737237','test'),('2019-06-17 19:59:59','2019-06-18 11:59:59','ZILETH','4h','0.000094980000000','0.000086980000000','0.075785839975555','0.069402530649334','797.9136657775848','797.913665777584811','test'),('2019-07-31 11:59:59','2019-07-31 15:59:59','ZILETH','4h','0.000052500000000','0.000049900000000','0.075785839975555','0.072032636472004','1443.5398090581905','1443.539809058190485','test'),('2019-07-31 19:59:59','2019-07-31 23:59:59','ZILETH','4h','0.000050760000000','0.000050190000000','0.075785839975555','0.074934816949825','1493.022852158294','1493.022852158293972','test'),('2019-08-01 03:59:59','2019-08-01 07:59:59','ZILETH','4h','0.000050510000000','0.000049300000000','0.075785839975555','0.073970340740346','1500.412591082063','1500.412591082063045','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  2:04:39
