-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-08 19:59:59','2018-05-08 23:59:59','QSPBTC','4h','0.000024100000000','0.000023980000000','0.001467500000000','0.001460192946058','60.892116182572614','60.892116182572614','test'),('2018-05-18 15:59:59','2018-05-21 23:59:59','QSPBTC','4h','0.000025200000000','0.000026230000000','0.001467500000000','0.001527481150794','58.23412698412699','58.234126984126988','test'),('2018-05-25 11:59:59','2018-05-25 15:59:59','QSPBTC','4h','0.000024980000000','0.000025230000000','0.001480668524213','0.001495487064287','59.2741602967574','59.274160296757401','test'),('2018-05-25 19:59:59','2018-05-26 03:59:59','QSPBTC','4h','0.000025730000000','0.000024030000000','0.001484373159232','0.001386299534254','57.690367634337356','57.690367634337356','test'),('2018-05-26 07:59:59','2018-05-26 11:59:59','QSPBTC','4h','0.000024540000000','0.000024790000000','0.001484373159232','0.001499495135182','60.487903799185005','60.487903799185005','test'),('2018-07-02 15:59:59','2018-07-05 03:59:59','QSPBTC','4h','0.000012600000000','0.000012020000000','0.001484373159232','0.001416044870950','117.80739358984127','117.807393589841269','test'),('2018-07-08 07:59:59','2018-07-09 07:59:59','QSPBTC','4h','0.000012470000000','0.000011760000000','0.001484373159232','0.001399857927231','119.0355380298316','119.035538029831599','test'),('2018-07-09 15:59:59','2018-07-09 19:59:59','QSPBTC','4h','0.000011900000000','0.000011650000000','0.001484373159232','0.001453188849164','124.73724027159665','124.737240271596647','test'),('2018-07-18 15:59:59','2018-07-18 19:59:59','QSPBTC','4h','0.000011090000000','0.000010830000000','0.001484373159232','0.001449572706446','133.8478953320108','133.847895332010808','test'),('2018-07-18 23:59:59','2018-07-19 03:59:59','QSPBTC','4h','0.000010960000000','0.000010720000000','0.001484373159232','0.001451868637497','135.43550722919707','135.435507229197071','test'),('2018-07-19 07:59:59','2018-07-19 11:59:59','QSPBTC','4h','0.000010730000000','0.000010830000000','0.001484373159232','0.001498207019057','138.33859825088535','138.338598250885354','test'),('2018-08-26 07:59:59','2018-08-29 15:59:59','QSPBTC','4h','0.000006140000000','0.000006210000000','0.001484373159232','0.001501295980266','241.7545861941368','241.754586194136806','test'),('2018-09-01 15:59:59','2018-09-02 11:59:59','QSPBTC','4h','0.000006290000000','0.000006050000000','0.001484373159232','0.001427735709595','235.98937348680445','235.989373486804453','test'),('2018-09-02 15:59:59','2018-09-02 19:59:59','QSPBTC','4h','0.000006080000000','0.000006020000000','0.001484373159232','0.001469724739897','244.14032224210524','244.140322242105242','test'),('2018-09-18 15:59:59','2018-09-22 11:59:59','QSPBTC','4h','0.000005190000000','0.000005290000000','0.001484373159232','0.001512973798138','286.0063890620424','286.006389062042388','test'),('2018-09-22 19:59:59','2018-09-22 23:59:59','QSPBTC','4h','0.000005410000000','0.000005330000000','0.001484373159232','0.001462423094031','274.3758150151571','274.375815015157116','test'),('2018-09-26 15:59:59','2018-10-01 07:59:59','QSPBTC','4h','0.000005580000000','0.000005440000000','0.001484373159232','0.001447130821904','266.01669520286737','266.016695202867368','test'),('2018-10-02 07:59:59','2018-10-03 23:59:59','QSPBTC','4h','0.000005830000000','0.000005530000000','0.001484373159232','0.001407990320850','254.6094612747856','254.609461274785588','test'),('2018-10-04 19:59:59','2018-10-05 03:59:59','QSPBTC','4h','0.000005680000000','0.000005580000000','0.001484373159232','0.001458239828964','261.33330268169016','261.333302681690157','test'),('2018-10-05 07:59:59','2018-10-10 03:59:59','QSPBTC','4h','0.000005730000000','0.000005710000000','0.001484373159232','0.001479192101085','259.0529073703316','259.052907370331582','test'),('2018-10-10 15:59:59','2018-10-11 03:59:59','QSPBTC','4h','0.000006010000000','0.000005470000000','0.001484373159232','0.001351001860399','246.98388672745423','246.983886727454234','test'),('2018-10-15 03:59:59','2018-10-17 19:59:59','QSPBTC','4h','0.000006930000000','0.000006410000000','0.001484373159232','0.001372991623474','214.19526107243868','214.195261072438683','test'),('2018-10-19 23:59:59','2018-10-21 15:59:59','QSPBTC','4h','0.000006560000000','0.000006360000000','0.001484373159232','0.001439117879987','226.27639622439025','226.276396224390254','test'),('2018-10-22 23:59:59','2018-10-23 11:59:59','QSPBTC','4h','0.000006620000000','0.000006520000000','0.001484373159232','0.001461950603957','224.22555275407854','224.225552754078535','test'),('2018-10-23 19:59:59','2018-10-24 07:59:59','QSPBTC','4h','0.000006530000000','0.000006450000000','0.001484373159232','0.001466187883162','227.3159508777948','227.315950877794791','test'),('2018-10-24 15:59:59','2018-10-27 11:59:59','QSPBTC','4h','0.000006650000000','0.000006600000000','0.001484373159232','0.001473212458787','223.21400890706767','223.214008907067665','test'),('2018-10-29 15:59:59','2018-10-31 15:59:59','QSPBTC','4h','0.000007200000000','0.000006810000000','0.001484373159232','0.001403969613107','206.16293878222223','206.162938782222227','test'),('2018-10-31 19:59:59','2018-11-01 07:59:59','QSPBTC','4h','0.000006910000000','0.000006810000000','0.001484373159232','0.001462891637391','214.81521841273516','214.815218412735163','test'),('2018-11-01 19:59:59','2018-11-04 11:59:59','QSPBTC','4h','0.000007060000000','0.000006890000000','0.001484373159232','0.001448630462763','210.25115569858357','210.251155698583574','test'),('2018-12-01 11:59:59','2018-12-02 07:59:59','QSPBTC','4h','0.000004800000000','0.000004520000000','0.001484373159232','0.001397784724943','309.24440817333334','309.244408173333341','test'),('2018-12-02 15:59:59','2018-12-02 23:59:59','QSPBTC','4h','0.000004560000000','0.000004480000000','0.001484373159232','0.001458331524860','325.5204296561403','325.520429656140323','test'),('2018-12-19 03:59:59','2018-12-20 03:59:59','QSPBTC','4h','0.000004180000000','0.000004030000000','0.001484373159232','0.001431106179834','355.11319598851674','355.113195988516736','test'),('2018-12-20 11:59:59','2018-12-20 15:59:59','QSPBTC','4h','0.000004040000000','0.000004000000000','0.001484373159232','0.001469676395279','367.41909881980195','367.419098819801945','test'),('2018-12-22 11:59:59','2018-12-22 15:59:59','QSPBTC','4h','0.000004060000000','0.000004020000000','0.001484373159232','0.001469748793131','365.60915252019703','365.609152520197028','test'),('2018-12-22 19:59:59','2018-12-22 23:59:59','QSPBTC','4h','0.000004040000000','0.000004030000000','0.001484373159232','0.001480698968244','367.41909881980195','367.419098819801945','test'),('2018-12-23 03:59:59','2018-12-24 19:59:59','QSPBTC','4h','0.000004070000000','0.000004160000000','0.001484373159232','0.001517197135726','364.71084993415235','364.710849934152350','test'),('2018-12-24 23:59:59','2018-12-25 03:59:59','QSPBTC','4h','0.000004230000000','0.000003940000000','0.001484373159232','0.001382607623493','350.9156404803782','350.915640480378215','test'),('2019-01-03 15:59:59','2019-01-06 07:59:59','QSPBTC','4h','0.000004150000000','0.000004100000000','0.001484373159232','0.001466489145265','357.68027933301204','357.680279333012038','test'),('2019-01-06 11:59:59','2019-01-06 23:59:59','QSPBTC','4h','0.000004230000000','0.000004090000000','0.001484373159232','0.001435244969565','350.9156404803782','350.915640480378215','test'),('2019-01-15 23:59:59','2019-01-18 15:59:59','QSPBTC','4h','0.000004250000000','0.000004140000000','0.001484373159232','0.001445954089228','349.2642727604706','349.264272760470590','test'),('2019-01-18 19:59:59','2019-01-23 19:59:59','QSPBTC','4h','0.000004200000000','0.000004580000000','0.001484373159232','0.001618673587924','353.42218076952383','353.422180769523834','test'),('2019-01-26 23:59:59','2019-01-27 07:59:59','QSPBTC','4h','0.000004660000000','0.000004520000000','0.001484373159232','0.001439778257452','318.5350127107296','318.535012710729575','test'),('2019-02-13 19:59:59','2019-02-15 03:59:59','QSPBTC','4h','0.000004220000000','0.000004120000000','0.001484373159232','0.001449198439819','351.74719413080567','351.747194130805667','test'),('2019-02-26 19:59:59','2019-02-28 11:59:59','QSPBTC','4h','0.000004210000000','0.000004140000000','0.001484373159232','0.001459692370361','352.5826981548693','352.582698154869320','test'),('2019-02-28 15:59:59','2019-03-04 07:59:59','QSPBTC','4h','0.000004150000000','0.000004200000000','0.001484373159232','0.001502257173199','357.68027933301204','357.680279333012038','test'),('2019-03-05 11:59:59','2019-03-08 03:59:59','QSPBTC','4h','0.000004300000000','0.000004300000000','0.001484373159232','0.001484373159232','345.2030602865116','345.203060286511572','test'),('2019-03-08 11:59:59','2019-03-12 01:59:59','QSPBTC','4h','0.000004530000000','0.000004560000000','0.001484373159232','0.001494203445055','327.67619409094925','327.676194090949252','test'),('2019-03-12 11:59:59','2019-03-21 15:59:59','QSPBTC','4h','0.000004830000000','0.000005090000000','0.001484373159232','0.001564277304449','307.3236354517598','307.323635451759799','test'),('2019-03-26 03:59:59','2019-03-31 07:59:59','QSPBTC','4h','0.000005360000000','0.000005920000000','0.001484373159232','0.001639456922137','276.9352909014925','276.935290901492522','test'),('2019-03-31 11:59:59','2019-04-02 07:59:59','QSPBTC','4h','0.000006210000000','0.000005790000000','0.001484373159232','0.001383980771651','239.02949424025766','239.029494240257662','test'),('2019-04-05 11:59:59','2019-04-06 19:59:59','QSPBTC','4h','0.000006080000000','0.000005810000000','0.001484373159232','0.001418455272227','244.14032224210524','244.140322242105242','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:02:43
