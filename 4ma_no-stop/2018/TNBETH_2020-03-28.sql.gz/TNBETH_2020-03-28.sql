-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-02 03:59:59','2018-06-03 11:59:59','TNBETH','4h','0.000067190000000','0.000064120000000','0.072144500000000','0.068848122339634','1073.7386515850574','1073.738651585057369','test'),('2018-06-03 15:59:59','2018-06-04 03:59:59','TNBETH','4h','0.000064830000000','0.000063890000000','0.072144500000000','0.071098443698905','1112.8258522289063','1112.825852228906342','test'),('2018-07-01 23:59:59','2018-07-05 15:59:59','TNBETH','4h','0.000054210000000','0.000055690000000','0.072144500000000','0.074114134015864','1330.8337945028593','1330.833794502859291','test'),('2018-08-06 19:59:59','2018-08-08 03:59:59','TNBETH','4h','0.000045090000000','0.000043280000000','0.072144500000000','0.069248479929031','1600.0110889332448','1600.011088933244764','test'),('2018-08-09 07:59:59','2018-08-10 11:59:59','TNBETH','4h','0.000044710000000','0.000043150000000','0.072144500000000','0.069627268508164','1613.6099306642811','1613.609930664281137','test'),('2018-08-10 15:59:59','2018-08-11 07:59:59','TNBETH','4h','0.000044160000000','0.000041980000000','0.072144500000000','0.068583018795290','1633.7069746376812','1633.706974637681242','test'),('2018-08-21 23:59:59','2018-08-22 03:59:59','TNBETH','4h','0.000040270000000','0.000039790000000','0.072144500000000','0.071284570523963','1791.5197417432332','1791.519741743233226','test'),('2018-08-22 07:59:59','2018-08-22 11:59:59','TNBETH','4h','0.000040020000000','0.000040780000000','0.072144500000000','0.073514560469765','1802.7111444277862','1802.711144427786166','test'),('2018-08-24 03:59:59','2018-08-24 11:59:59','TNBETH','4h','0.000040530000000','0.000040190000000','0.072144500000000','0.071539290772267','1780.0271403898348','1780.027140389834813','test'),('2018-08-24 15:59:59','2018-08-26 15:59:59','TNBETH','4h','0.000040900000000','0.000043310000000','0.072144500000000','0.076395557334963','1763.9242053789733','1763.924205378973284','test'),('2018-08-26 19:59:59','2018-08-27 03:59:59','TNBETH','4h','0.000043340000000','0.000043100000000','0.072144500000000','0.071744991924319','1664.6169820027687','1664.616982002768736','test'),('2018-08-27 15:59:59','2018-08-29 07:59:59','TNBETH','4h','0.000044390000000','0.000043490000000','0.072144500000000','0.070681782045506','1625.242171660284','1625.242171660283930','test'),('2018-09-04 07:59:59','2018-09-05 11:59:59','TNBETH','4h','0.000043470000000','0.000042950000000','0.072144500000000','0.071281487807683','1659.6388313779617','1659.638831377961651','test'),('2018-09-05 15:59:59','2018-09-05 19:59:59','TNBETH','4h','0.000043150000000','0.000042970000000','0.072144500000000','0.071843549594438','1671.946697566628','1671.946697566628018','test'),('2018-09-05 23:59:59','2018-09-06 03:59:59','TNBETH','4h','0.000043770000000','0.000039650000000','0.072144500000000','0.065353653758282','1648.2636509024444','1648.263650902444397','test'),('2018-09-18 03:59:59','2018-09-19 11:59:59','TNBETH','4h','0.000041520000000','0.000040410000000','0.072144500000000','0.070215781430636','1737.58429672447','1737.584296724470050','test'),('2018-09-19 15:59:59','2018-09-20 23:59:59','TNBETH','4h','0.000040680000000','0.000041120000000','0.072144500000000','0.072924823992134','1773.4636184857425','1773.463618485742472','test'),('2018-09-21 07:59:59','2018-09-21 11:59:59','TNBETH','4h','0.000040700000000','0.000041240000000','0.072144500000000','0.073101699754300','1772.5921375921375','1772.592137592137533','test'),('2018-09-26 03:59:59','2018-09-27 19:59:59','TNBETH','4h','0.000043520000000','0.000041120000000','0.072144500000000','0.068165943014706','1657.7320772058824','1657.732077205882433','test'),('2018-09-30 03:59:59','2018-09-30 15:59:59','TNBETH','4h','0.000043330000000','0.000040590000000','0.072144500000000','0.067582396838218','1665.001153934918','1665.001153934917966','test'),('2018-10-03 11:59:59','2018-10-03 15:59:59','TNBETH','4h','0.000041570000000','0.000041560000000','0.072144500000000','0.072127145056531','1735.4943468847728','1735.494346884772767','test'),('2018-10-03 19:59:59','2018-10-04 07:59:59','TNBETH','4h','0.000041940000000','0.000041890000000','0.072144500000000','0.072058490820219','1720.1835956127802','1720.183595612780209','test'),('2018-10-04 15:59:59','2018-10-07 23:59:59','TNBETH','4h','0.000041980000000','0.000043410000000','0.072144500000000','0.074602018699381','1718.5445450214388','1718.544545021438807','test'),('2018-10-08 03:59:59','2018-10-11 07:59:59','TNBETH','4h','0.000043940000000','0.000044180000000','0.072144500000000','0.072538552799272','1641.8866636322257','1641.886663632225691','test'),('2018-10-11 11:59:59','2018-10-11 19:59:59','TNBETH','4h','0.000045020000000','0.000044700000000','0.072144500000000','0.071631700355398','1602.4988893824966','1602.498889382496600','test'),('2018-10-14 19:59:59','2018-10-15 07:59:59','TNBETH','4h','0.000047910000000','0.000044850000000','0.072144500000000','0.067536648403256','1505.8338551450636','1505.833855145063580','test'),('2018-10-15 11:59:59','2018-10-21 23:59:59','TNBETH','4h','0.000047210000000','0.000048770000000','0.072144500000000','0.074528431794111','1528.1614064816777','1528.161406481677659','test'),('2018-10-22 15:59:59','2018-10-25 03:59:59','TNBETH','4h','0.000053580000000','0.000051750000000','0.072144500000000','0.069680438129899','1346.4818962299366','1346.481896229936638','test'),('2018-10-25 07:59:59','2018-10-25 11:59:59','TNBETH','4h','0.000052640000000','0.000052510000000','0.072144500000000','0.071966331591945','1370.526215805471','1370.526215805471111','test'),('2018-10-25 19:59:59','2018-10-26 15:59:59','TNBETH','4h','0.000054140000000','0.000052460000000','0.072144500000000','0.069905808459549','1332.554488363502','1332.554488363502060','test'),('2018-10-28 15:59:59','2018-10-29 15:59:59','TNBETH','4h','0.000057380000000','0.000054640000000','0.072144500000000','0.068699468107354','1257.3109097246427','1257.310909724642670','test'),('2018-10-30 03:59:59','2018-10-31 15:59:59','TNBETH','4h','0.000054940000000','0.000055200000000','0.072144500000000','0.072485919184565','1313.1507098653076','1313.150709865307590','test'),('2018-10-31 19:59:59','2018-11-02 15:59:59','TNBETH','4h','0.000056070000000','0.000055380000000','0.072144500000000','0.071256686463349','1286.6862850008918','1286.686285000891758','test'),('2018-11-02 19:59:59','2018-11-02 23:59:59','TNBETH','4h','0.000055720000000','0.000054420000000','0.072144500000000','0.070461300969131','1294.7684852835607','1294.768485283560722','test'),('2019-01-11 11:59:59','2019-01-14 15:59:59','TNBETH','4h','0.000022750000000','0.000022090000000','0.072144500000000','0.070051516703297','3171.186813186813','3171.186813186813197','test'),('2019-01-16 07:59:59','2019-01-18 11:59:59','TNBETH','4h','0.000023320000000','0.000024740000000','0.072144500000000','0.076537518439108','3093.674957118353','3093.674957118353177','test'),('2019-01-18 15:59:59','2019-01-20 19:59:59','TNBETH','4h','0.000024860000000','0.000024220000000','0.072144500000000','0.070287199919549','2902.031375703942','2902.031375703942103','test'),('2019-01-22 19:59:59','2019-01-23 23:59:59','TNBETH','4h','0.000025430000000','0.000024970000000','0.072144500000000','0.070839487416437','2836.983877310264','2836.983877310263779','test'),('2019-01-24 03:59:59','2019-01-27 15:59:59','TNBETH','4h','0.000025130000000','0.000025200000000','0.072144500000000','0.072345459610028','2870.851571826502','2870.851571826502095','test'),('2019-01-27 19:59:59','2019-01-28 11:59:59','TNBETH','4h','0.000026680000000','0.000026020000000','0.072144500000000','0.070359815967017','2704.0667166416792','2704.066716641679250','test'),('2019-01-28 19:59:59','2019-01-28 23:59:59','TNBETH','4h','0.000026080000000','0.000025730000000','0.072144500000000','0.071176303105828','2766.2768404907974','2766.276840490797440','test'),('2019-01-29 19:59:59','2019-01-30 23:59:59','TNBETH','4h','0.000026890000000','0.000026400000000','0.072144500000000','0.070829854964671','2682.949051692079','2682.949051692079138','test'),('2019-03-03 11:59:59','2019-03-06 15:59:59','TNBETH','4h','0.000020070000000','0.000021920000000','0.072144500000000','0.078794590931739','3594.6437468858994','3594.643746885899418','test'),('2019-03-09 11:59:59','2019-03-14 11:59:59','TNBETH','4h','0.000022500000000','0.000023770000000','0.072144500000000','0.076216656222222','3206.422222222222','3206.422222222221990','test'),('2019-03-14 15:59:59','2019-03-14 19:59:59','TNBETH','4h','0.000024080000000','0.000024020000000','0.072144500000000','0.071964737956811','2996.034053156146','2996.034053156146001','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','TNBETH','4h','0.000023930000000','0.000023320000000','0.072144500000000','0.070305463435019','3014.814040952779','3014.814040952779123','test'),('2019-03-21 19:59:59','2019-03-21 23:59:59','TNBETH','4h','0.000023440000000','0.000023640000000','0.072144500000000','0.072760067406143','3077.837030716724','3077.837030716723802','test'),('2019-03-22 07:59:59','2019-03-22 11:59:59','TNBETH','4h','0.000023320000000','0.000023370000000','0.072144500000000','0.072299183747856','3093.674957118353','3093.674957118353177','test'),('2019-03-22 15:59:59','2019-03-22 19:59:59','TNBETH','4h','0.000023460000000','0.000023310000000','0.072144500000000','0.071683218030691','3075.213128729753','3075.213128729752952','test'),('2019-03-22 23:59:59','2019-03-23 03:59:59','TNBETH','4h','0.000023600000000','0.000023420000000','0.072144500000000','0.071594245338983','3056.9703389830506','3056.970338983050624','test'),('2019-03-23 07:59:59','2019-03-23 11:59:59','TNBETH','4h','0.000023430000000','0.000023600000000','0.072144500000000','0.072667955612463','3079.1506615450276','3079.150661545027560','test'),('2019-03-23 15:59:59','2019-03-24 15:59:59','TNBETH','4h','0.000023610000000','0.000023830000000','0.072144500000000','0.072816748623465','3055.67556120288','3055.675561202880090','test'),('2019-03-24 19:59:59','2019-03-26 15:59:59','TNBETH','4h','0.000024100000000','0.000024060000000','0.072144500000000','0.072024758091286','2993.547717842324','2993.547717842323891','test'),('2019-03-26 19:59:59','2019-03-30 11:59:59','TNBETH','4h','0.000024390000000','0.000027470000000','0.072144500000000','0.081254998564986','2957.9540795407956','2957.954079540795647','test'),('2019-03-31 03:59:59','2019-04-03 03:59:59','TNBETH','4h','0.000028120000000','0.000026930000000','0.072144500000000','0.069091443278805','2565.5938833570412','2565.593883357041250','test'),('2019-04-06 15:59:59','2019-04-09 23:59:59','TNBETH','4h','0.000030450000000','0.000035460000000','0.072144500000000','0.084014580295567','2369.2775041050904','2369.277504105090429','test'),('2019-04-13 07:59:59','2019-04-14 07:59:59','TNBETH','4h','0.000038340000000','0.000034850000000','0.072144500000000','0.065577355894627','1881.7031820552945','1881.703182055294519','test'),('2019-04-14 11:59:59','2019-04-14 23:59:59','TNBETH','4h','0.000035400000000','0.000033660000000','0.072144500000000','0.068598414406780','2037.9802259887006','2037.980225988700568','test'),('2019-04-18 19:59:59','2019-04-18 23:59:59','TNBETH','4h','0.000033970000000','0.000034080000000','0.072144500000000','0.072378114807183','2123.770974389167','2123.770974389166895','test'),('2019-04-21 07:59:59','2019-04-23 19:59:59','TNBETH','4h','0.000035670000000','0.000034920000000','0.072144500000000','0.070627584524811','2022.5539669189793','2022.553966918979313','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:10:18
