-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-18 23:59:59','2018-04-20 03:59:59','DASHETH','4h','0.803380000000000','0.760820000000000','0.072144500000000','0.068322560295253','0.08980121486718615','0.089801214867186','test'),('2018-04-20 07:59:59','2018-04-20 15:59:59','DASHETH','4h','0.764090000000000','0.747650000000000','0.072144500000000','0.070592254086560','0.09441885118245233','0.094418851182452','test'),('2018-04-23 15:59:59','2018-04-24 15:59:59','DASHETH','4h','0.811960000000000','0.764220000000000','0.072144500000000','0.067902691992216','0.0888522833637125','0.088852283363712','test'),('2018-04-26 23:59:59','2018-04-27 07:59:59','DASHETH','4h','0.763350000000000','0.744360000000000','0.072144500000000','0.070349747848300','0.09451038186939151','0.094510381869392','test'),('2018-06-14 07:59:59','2018-06-14 19:59:59','DASHETH','4h','0.531950000000000','0.518890000000000','0.072144500000000','0.070373267421750','0.1356227089012125','0.135622708901213','test'),('2018-06-16 19:59:59','2018-06-18 03:59:59','DASHETH','4h','0.531340000000000','0.522350000000000','0.072144500000000','0.070923852100350','0.13577840930477658','0.135778409304777','test'),('2018-06-24 11:59:59','2018-06-27 23:59:59','DASHETH','4h','0.533110000000000','0.519270000000000','0.072144500000000','0.070271565933860','0.13532760593498527','0.135327605934985','test'),('2018-06-29 11:59:59','2018-06-30 19:59:59','DASHETH','4h','0.533230000000000','0.532410000000000','0.072144500000000','0.072033556335915','0.13529715132306885','0.135297151323069','test'),('2018-07-02 11:59:59','2018-07-02 15:59:59','DASHETH','4h','0.534090000000000','0.530210000000000','0.072144500000000','0.071620392340242','0.13507929375198938','0.135079293751989','test'),('2018-07-03 03:59:59','2018-07-03 23:59:59','DASHETH','4h','0.534810000000000','0.524670000000000','0.072144500000000','0.070776639956246','0.13489744021241187','0.134897440212412','test'),('2018-07-15 19:59:59','2018-07-16 07:59:59','DASHETH','4h','0.518280000000000','0.506880000000000','0.072144500000000','0.070557621671683','0.13919985336111756','0.139199853361118','test'),('2018-07-16 11:59:59','2018-07-16 15:59:59','DASHETH','4h','0.509750000000000','0.522530000000000','0.072144500000000','0.073953242932810','0.14152918097106423','0.141529180971064','test'),('2018-07-16 23:59:59','2018-07-21 03:59:59','DASHETH','4h','0.514600000000000','0.547900000000000','0.072144500000000','0.076813003400700','0.1401952973183055','0.140195297318305','test'),('2018-08-11 07:59:59','2018-08-12 07:59:59','DASHETH','4h','0.525000000000000','0.513650000000000','0.072144500000000','0.070584804619048','0.13741809523809523','0.137418095238095','test'),('2018-08-12 11:59:59','2018-08-13 15:59:59','DASHETH','4h','0.521070000000000','0.520510000000000','0.072144500000000','0.072066965465293','0.13845452626326596','0.138454526263266','test'),('2018-08-14 03:59:59','2018-08-14 07:59:59','DASHETH','4h','0.526460000000000','0.516000000000000','0.072144500000000','0.070711092960529','0.13703700186148995','0.137037001861490','test'),('2018-08-14 11:59:59','2018-08-14 15:59:59','DASHETH','4h','0.524270000000000','0.519630000000000','0.072144500000000','0.071505992208213','0.13760943788505922','0.137609437885059','test'),('2018-08-14 19:59:59','2018-08-14 23:59:59','DASHETH','4h','0.526500000000000','0.498570000000000','0.072144500000000','0.068317347321937','0.13702659069325737','0.137026590693257','test'),('2018-08-15 03:59:59','2018-08-16 23:59:59','DASHETH','4h','0.528780000000000','0.526230000000000','0.072144500000000','0.071796588817656','0.13643575778206438','0.136435757782064','test'),('2018-08-17 03:59:59','2018-08-17 07:59:59','DASHETH','4h','0.528460000000000','0.524920000000000','0.072144500000000','0.071661224955531','0.1365183741437384','0.136518374143738','test'),('2018-08-17 15:59:59','2018-08-17 23:59:59','DASHETH','4h','0.538210000000000','0.529250000000000','0.072144500000000','0.070943454460155','0.13404526114341986','0.134045261143420','test'),('2018-08-18 03:59:59','2018-08-18 07:59:59','DASHETH','4h','0.534550000000000','0.524300000000000','0.072144500000000','0.070761128706389','0.13496305303526332','0.134963053035263','test'),('2018-08-27 07:59:59','2018-09-06 07:59:59','DASHETH','4h','0.527320000000000','0.733690000000000','0.072144500000000','0.100378704022226','0.1368135098232572','0.136813509823257','test'),('2018-09-06 11:59:59','2018-09-13 03:59:59','DASHETH','4h','0.757510000000000','0.967570000000000','0.073118049963215','0.093393924308468','0.09652420425237355','0.096524204252374','test'),('2018-09-18 11:59:59','2018-09-18 15:59:59','DASHETH','4h','0.919100000000000','0.887280000000000','0.078187018549529','0.075480119484959','0.08506910950878985','0.085069109508790','test'),('2018-09-18 19:59:59','2018-09-18 23:59:59','DASHETH','4h','0.902390000000000','0.910470000000000','0.078187018549529','0.078887105108423','0.08664437610072032','0.086644376100720','test'),('2018-09-19 07:59:59','2018-09-19 11:59:59','DASHETH','4h','0.915560000000000','0.905130000000000','0.078187018549529','0.077296317117103','0.08539802803697082','0.085398028036971','test'),('2018-09-19 19:59:59','2018-09-20 11:59:59','DASHETH','4h','0.918520000000000','0.911940000000000','0.078187018549529','0.077626910351497','0.08512282644855747','0.085122826448557','test'),('2018-09-20 19:59:59','2018-09-20 23:59:59','DASHETH','4h','0.905100000000000','0.887840000000000','0.078187018549529','0.076696014306722','0.08638495033645896','0.086384950336459','test'),('2018-09-21 03:59:59','2018-09-21 15:59:59','DASHETH','4h','0.925960000000000','0.901880000000000','0.078187018549529','0.076153730495323','0.08443887268297659','0.084438872682977','test'),('2018-10-30 11:59:59','2018-10-31 19:59:59','DASHETH','4h','0.780290000000000','0.769160000000000','0.078187018549529','0.077071764584393','0.10020251259086878','0.100202512590869','test'),('2018-10-31 23:59:59','2018-11-01 03:59:59','DASHETH','4h','0.771400000000000','0.770300000000000','0.078187018549529','0.078075525523337','0.10135729653815012','0.101357296538150','test'),('2018-11-03 11:59:59','2018-11-04 07:59:59','DASHETH','4h','0.776900000000000','0.772410000000000','0.078187018549529','0.077735146090670','0.10063974584828034','0.100639745848280','test'),('2018-11-04 11:59:59','2018-11-05 03:59:59','DASHETH','4h','0.778640000000000','0.782330000000000','0.078187018549529','0.078557549344823','0.1004148496731853','0.100414849673185','test'),('2018-11-05 07:59:59','2018-11-06 11:59:59','DASHETH','4h','0.800830000000000','0.788960000000000','0.078187018549529','0.077028121017989','0.09763247948944095','0.097632479489441','test'),('2018-11-06 19:59:59','2018-11-06 23:59:59','DASHETH','4h','0.788080000000000','0.782150000000000','0.078187018549529','0.077598691196978','0.09921203247072506','0.099212032470725','test'),('2018-11-14 11:59:59','2018-11-14 19:59:59','DASHETH','4h','0.779500000000000','0.802470000000000','0.078187018549529','0.080491002919103','0.10030406484865813','0.100304064848658','test'),('2018-11-16 23:59:59','2018-11-17 11:59:59','DASHETH','4h','0.787980000000000','0.765090000000000','0.078187018549529','0.075915766925632','0.09922462314973604','0.099224623149736','test'),('2018-11-21 07:59:59','2018-11-25 11:59:59','DASHETH','4h','0.807670000000000','0.797130000000000','0.078187018549529','0.077166687008786','0.09680564902686617','0.096805649026866','test'),('2018-11-27 03:59:59','2018-11-27 23:59:59','DASHETH','4h','0.840070000000000','0.813030000000000','0.078187018549529','0.075670350912809','0.09307202798520244','0.093072027985202','test'),('2018-11-28 11:59:59','2018-11-29 07:59:59','DASHETH','4h','0.817280000000000','0.809880000000000','0.078187018549529','0.077479080098488','0.0956673582487385','0.095667358248738','test'),('2018-11-29 23:59:59','2018-11-30 07:59:59','DASHETH','4h','0.821000000000000','0.809050000000000','0.078187018549529','0.077048973638851','0.09523388373876858','0.095233883738769','test'),('2018-12-18 07:59:59','2018-12-18 11:59:59','DASHETH','4h','0.749490000000000','0.732640000000000','0.078187018549529','0.076429221564166','0.1043202958672284','0.104320295867228','test'),('2018-12-18 15:59:59','2018-12-18 19:59:59','DASHETH','4h','0.741500000000000','0.740730000000000','0.078187018549529','0.078105826365735','0.10544439453746325','0.105444394537463','test'),('2018-12-19 03:59:59','2018-12-19 07:59:59','DASHETH','4h','0.739300000000000','0.738890000000000','0.078187018549529','0.078143657697905','0.1057581746916394','0.105758174691639','test'),('2018-12-19 11:59:59','2018-12-19 15:59:59','DASHETH','4h','0.762560000000000','0.725860000000000','0.078187018549529','0.074424083723722','0.10253228408194634','0.102532284081946','test'),('2018-12-19 19:59:59','2018-12-19 23:59:59','DASHETH','4h','0.749170000000000','0.729450000000000','0.078187018549529','0.076128943605529','0.1043648551724295','0.104364855172429','test'),('2018-12-20 19:59:59','2018-12-22 23:59:59','DASHETH','4h','0.762810000000000','0.745500000000000','0.078187018549529','0.076412766388319','0.10249868060136731','0.102498680601367','test'),('2019-01-11 11:59:59','2019-01-14 15:59:59','DASHETH','4h','0.584910000000000','0.556990000000000','0.078187018549529','0.074454851963383','0.13367358832902326','0.133673588329023','test'),('2019-01-16 19:59:59','2019-01-20 15:59:59','DASHETH','4h','0.580370000000000','0.585920000000000','0.078187018549529','0.078934710458053','0.13471926279705876','0.134719262797059','test'),('2019-01-21 07:59:59','2019-01-27 19:59:59','DASHETH','4h','0.587700000000000','0.620830000000000','0.078187018549529','0.082594600520851','0.13303899702148886','0.133038997021489','test'),('2019-01-28 03:59:59','2019-01-28 07:59:59','DASHETH','4h','0.629360000000000','0.624240000000000','0.078187018549529','0.077550947723653','0.12423258317898976','0.124232583178990','test'),('2019-01-28 11:59:59','2019-01-30 19:59:59','DASHETH','4h','0.637850000000000','0.627800000000000','0.078187018549529','0.076955099545966','0.12257900532966842','0.122579005329668','test'),('2019-02-05 15:59:59','2019-02-06 19:59:59','DASHETH','4h','0.638750000000000','0.634100000000000','0.078187018549529','0.077617829295118','0.12240629127127828','0.122406291271278','test'),('2019-02-07 03:59:59','2019-02-08 11:59:59','DASHETH','4h','0.627790000000000','0.630500000000000','0.078187018549529','0.078524530807241','0.12454326852853503','0.124543268528535','test'),('2019-02-11 11:59:59','2019-02-14 03:59:59','DASHETH','4h','0.653980000000000','0.650980000000000','0.078187018549529','0.077828351532726','0.11955567226754488','0.119555672267545','test'),('2019-02-28 23:59:59','2019-03-05 15:59:59','DASHETH','4h','0.602880000000000','0.608220000000000','0.078187018549529','0.078879558821315','0.12968918947307756','0.129689189473078','test'),('2019-03-11 11:59:59','2019-03-11 15:59:59','DASHETH','4h','0.608920000000000','0.608000000000000','0.078187018549529','0.078068887995326','0.12840277630810124','0.128402776308101','test'),('2019-03-11 19:59:59','2019-03-15 19:59:59','DASHETH','4h','0.622010000000000','0.658600000000000','0.078187018549529','0.082786402817832','0.12570058125999423','0.125700581259994','test'),('2019-03-18 03:59:59','2019-03-19 23:59:59','DASHETH','4h','0.671450000000000','0.654430000000000','0.078187018549529','0.076205124058930','0.11644503470031872','0.116445034700319','test'),('2019-03-20 11:59:59','2019-03-22 15:59:59','DASHETH','4h','0.671480000000000','0.661920000000000','0.078187018549529','0.077073853753357','0.11643983223555282','0.116439832235553','test'),('2019-03-23 03:59:59','2019-03-23 07:59:59','DASHETH','4h','0.665230000000000','0.662580000000000','0.078187018549529','0.077875553944571','0.11753381319172167','0.117533813191722','test'),('2019-03-23 11:59:59','2019-03-25 19:59:59','DASHETH','4h','0.664120000000000','0.666780000000000','0.078187018549529','0.078500181034233','0.1177302574075905','0.117730257407590','test'),('2019-03-27 19:59:59','2019-03-30 03:59:59','DASHETH','4h','0.677110000000000','0.671620000000000','0.078187018549529','0.077553079113046','0.11547166420452955','0.115471664204530','test'),('2019-03-30 07:59:59','2019-04-06 15:59:59','DASHETH','4h','0.680630000000000','0.800080000000000','0.078187018549529','0.091908775400889','0.11487448180293112','0.114874481802931','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:15:00
