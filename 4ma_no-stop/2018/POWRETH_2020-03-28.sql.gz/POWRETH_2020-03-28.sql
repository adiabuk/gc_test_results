-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-18 19:59:59','2018-04-19 23:59:59','POWRETH','4h','0.000892760000000','0.000835010000000','0.072144500000000','0.067477685990636','80.810632196783','80.810632196783004','test'),('2018-04-25 07:59:59','2018-04-25 11:59:59','POWRETH','4h','0.000837100000000','0.000835770000000','0.072144500000000','0.072029875480827','86.18384900250867','86.183849002508666','test'),('2018-04-26 03:59:59','2018-04-26 07:59:59','POWRETH','4h','0.000839800000000','0.000814300000000','0.072144500000000','0.069953877530364','85.90676351512265','85.906763515122648','test'),('2018-04-26 23:59:59','2018-04-27 03:59:59','POWRETH','4h','0.000840000000000','0.000818120000000','0.072144500000000','0.070265307547619','85.88630952380952','85.886309523809516','test'),('2018-04-27 07:59:59','2018-04-27 11:59:59','POWRETH','4h','0.000839740000000','0.000806820000000','0.072144500000000','0.069316247278920','85.91290161240384','85.912901612403843','test'),('2018-04-29 19:59:59','2018-04-30 07:59:59','POWRETH','4h','0.000869690000000','0.000808710000000','0.072144500000000','0.067085948550633','82.95427106210259','82.954271062102592','test'),('2018-04-30 11:59:59','2018-04-30 15:59:59','POWRETH','4h','0.000817990000000','0.000831400000000','0.072144500000000','0.073327225638455','88.19728847540924','88.197288475409238','test'),('2018-04-30 19:59:59','2018-04-30 23:59:59','POWRETH','4h','0.000843800000000','0.000829270000000','0.072144500000000','0.070902191887888','85.49952595401754','85.499525954017543','test'),('2018-05-02 03:59:59','2018-05-02 07:59:59','POWRETH','4h','0.000833120000000','0.000824810000000','0.072144500000000','0.071424890826051','86.59556846552718','86.595568465527180','test'),('2018-05-02 11:59:59','2018-05-02 15:59:59','POWRETH','4h','0.000837300000000','0.000822300000000','0.072144500000000','0.070852051056969','86.16326286874477','86.163262868744766','test'),('2018-05-02 19:59:59','2018-05-02 23:59:59','POWRETH','4h','0.000826060000000','0.000828100000000','0.072144500000000','0.072322664758008','87.33566569014357','87.335665690143571','test'),('2018-05-16 03:59:59','2018-05-16 15:59:59','POWRETH','4h','0.000735770000000','0.000659560000000','0.072144500000000','0.064671876292863','98.05306005952949','98.053060059529486','test'),('2018-06-30 03:59:59','2018-07-03 23:59:59','POWRETH','4h','0.000560480000000','0.000607110000000','0.072144500000000','0.078146673199757','128.71913359977162','128.719133599771624','test'),('2018-07-10 03:59:59','2018-07-10 11:59:59','POWRETH','4h','0.000604220000000','0.000584890000000','0.072144500000000','0.069836477781272','119.40104597663102','119.401045976631025','test'),('2018-07-10 15:59:59','2018-07-10 19:59:59','POWRETH','4h','0.000585180000000','0.000587320000000','0.072144500000000','0.072408332034588','123.28599747086366','123.285997470863663','test'),('2018-07-11 07:59:59','2018-07-13 23:59:59','POWRETH','4h','0.000665580000000','0.000613610000000','0.072144500000000','0.066511293375702','108.3934312930076','108.393431293007595','test'),('2018-07-14 07:59:59','2018-07-21 03:59:59','POWRETH','4h','0.000623710000000','0.000765510000000','0.072144500000000','0.088546497883632','115.66994276186048','115.669942761860483','test'),('2018-07-22 11:59:59','2018-07-22 15:59:59','POWRETH','4h','0.000803990000000','0.000787180000000','0.072144500000000','0.070636086904066','89.73308125722957','89.733081257229571','test'),('2018-08-13 03:59:59','2018-08-14 03:59:59','POWRETH','4h','0.000632100000000','0.000596990000000','0.072144500000000','0.068137233119760','114.13463059642461','114.134630596424614','test'),('2018-08-14 19:59:59','2018-08-18 11:59:59','POWRETH','4h','0.000617050000000','0.000644070000000','0.072144500000000','0.075303635224050','116.91840207438621','116.918402074386208','test'),('2018-08-20 11:59:59','2018-08-23 11:59:59','POWRETH','4h','0.000659950000000','0.000678090000000','0.072144500000000','0.074127530881127','109.31813016137586','109.318130161375862','test'),('2018-08-24 07:59:59','2018-08-24 11:59:59','POWRETH','4h','0.000685120000000','0.000682610000000','0.072144500000000','0.071880192002861','105.30199089210649','105.301990892106488','test'),('2018-08-25 15:59:59','2018-08-29 23:59:59','POWRETH','4h','0.000689580000000','0.000713140000000','0.072144500000000','0.074609369079730','104.62092868122626','104.620928681226260','test'),('2018-08-30 03:59:59','2018-08-30 11:59:59','POWRETH','4h','0.000715150000000','0.000688880000000','0.072144500000000','0.069494376228763','100.88023491575194','100.880234915751942','test'),('2018-09-04 15:59:59','2018-09-05 11:59:59','POWRETH','4h','0.000705230000000','0.000708090000000','0.072144500000000','0.072437075854686','102.29924989010676','102.299249890106765','test'),('2018-09-05 15:59:59','2018-09-06 15:59:59','POWRETH','4h','0.000708210000000','0.000723810000000','0.072144500000000','0.073733653217266','101.86879597859392','101.868795978593923','test'),('2018-09-06 19:59:59','2018-09-09 19:59:59','POWRETH','4h','0.000732200000000','0.000735460000000','0.072144500000000','0.072465711513248','98.53113903305108','98.531139033051076','test'),('2018-09-09 23:59:59','2018-09-10 07:59:59','POWRETH','4h','0.000750730000000','0.000749900000000','0.072144500000000','0.072064737721951','96.09913017995817','96.099130179958166','test'),('2018-09-10 15:59:59','2018-09-11 07:59:59','POWRETH','4h','0.000763540000000','0.000745920000000','0.072144500000000','0.070479641459518','94.48686381852947','94.486863818529471','test'),('2018-09-18 11:59:59','2018-09-18 15:59:59','POWRETH','4h','0.000726430000000','0.000707530000000','0.072144500000000','0.070267469797503','99.31376732789118','99.313767327891185','test'),('2018-09-18 19:59:59','2018-09-18 23:59:59','POWRETH','4h','0.000711430000000','0.000727880000000','0.072144500000000','0.073812657127195','101.40772809693154','101.407728096931535','test'),('2018-09-19 15:59:59','2018-09-20 23:59:59','POWRETH','4h','0.000715630000000','0.000707010000000','0.072144500000000','0.071275495640205','100.81257074186382','100.812570741863823','test'),('2018-09-21 03:59:59','2018-09-21 07:59:59','POWRETH','4h','0.000714270000000','0.000730520000000','0.072144500000000','0.073785823484117','101.00452209948618','101.004522099486181','test'),('2018-09-21 15:59:59','2018-09-21 19:59:59','POWRETH','4h','0.000792810000000','0.000726180000000','0.072144500000000','0.066081271691830','90.99847378312585','90.998473783125846','test'),('2018-09-22 03:59:59','2018-09-24 11:59:59','POWRETH','4h','0.000793430000000','0.000727700000000','0.072144500000000','0.066167844233266','90.92736599321931','90.927365993219311','test'),('2018-09-25 15:59:59','2018-09-27 19:59:59','POWRETH','4h','0.000763120000000','0.000745550000000','0.072144500000000','0.070483452111070','94.53886675752175','94.538866757521745','test'),('2018-10-08 11:59:59','2018-10-13 11:59:59','POWRETH','4h','0.000763490000000','0.000809010000000','0.072144500000000','0.076445823710854','94.49305164442232','94.493051644422323','test'),('2018-10-13 15:59:59','2018-10-15 07:59:59','POWRETH','4h','0.000821210000000','0.000793650000000','0.072144500000000','0.069723313677379','87.85146308496','87.851463084960002','test'),('2018-10-17 03:59:59','2018-10-21 23:59:59','POWRETH','4h','0.000819860000000','0.000881960000000','0.072144500000000','0.077609059132047','87.99612128900057','87.996121289000570','test'),('2018-11-13 23:59:59','2018-11-14 11:59:59','POWRETH','4h','0.000808380000000','0.000769360000000','0.072144500000000','0.068662129839927','89.24577550162053','89.245775501620528','test'),('2018-11-14 15:59:59','2018-11-14 19:59:59','POWRETH','4h','0.000778260000000','0.000733920000000','0.072144500000000','0.068034193508596','92.69974044663736','92.699740446637364','test'),('2018-11-24 11:59:59','2018-11-24 23:59:59','POWRETH','4h','0.000735770000000','0.000680000000000','0.072144500000000','0.066676080840480','98.05306005952949','98.053060059529486','test'),('2018-11-29 07:59:59','2018-11-30 11:59:59','POWRETH','4h','0.000752000000000','0.000720320000000','0.072144500000000','0.069105221063830','95.93683510638299','95.936835106382986','test'),('2018-11-30 15:59:59','2018-12-06 15:59:59','POWRETH','4h','0.000739970000000','0.000755940000000','0.072144500000000','0.073701519426463','97.49652012919444','97.496520129194437','test'),('2019-01-12 23:59:59','2019-01-22 03:59:59','POWRETH','4h','0.000575050000000','0.000890090000000','0.072144500000000','0.111668720989479','125.45778627945396','125.457786279453956','test'),('2019-02-17 15:59:59','2019-02-18 03:59:59','POWRETH','4h','0.000736430000000','0.000683070000000','0.074005984148863','0.068643683164135','100.49289701514434','100.492897015144337','test'),('2019-02-18 07:59:59','2019-02-18 11:59:59','POWRETH','4h','0.000688810000000','0.000704410000000','0.074005984148863','0.075682053533341','107.44034515884351','107.440345158843513','test'),('2019-02-27 23:59:59','2019-02-28 11:59:59','POWRETH','4h','0.000687230000000','0.000660700000000','0.074005984148863','0.071149038498252','107.6873596159408','107.687359615940807','test'),('2019-02-28 15:59:59','2019-03-04 07:59:59','POWRETH','4h','0.000663100000000','0.000702000000000','0.074005984148863','0.078347460220935','111.60606869079022','111.606068690790224','test'),('2019-03-04 19:59:59','2019-03-05 03:59:59','POWRETH','4h','0.000725450000000','0.000713120000000','0.074005984148863','0.072748152755169','102.01390054292233','102.013900542922329','test'),('2019-03-08 03:59:59','2019-03-08 07:59:59','POWRETH','4h','0.000711420000000','0.000704740000000','0.074005984148863','0.073311092278921','104.02572903328975','104.025729033289750','test'),('2019-03-08 15:59:59','2019-03-15 15:59:59','POWRETH','4h','0.000711860000000','0.000796970000000','0.074005984148863','0.082854141526591','103.96143082749839','103.961430827498390','test'),('2019-03-20 19:59:59','2019-03-21 03:59:59','POWRETH','4h','0.000786430000000','0.000772560000000','0.075179417382688','0.073853503418193','95.5958157530721','95.595815753072102','test'),('2019-03-21 07:59:59','2019-03-21 15:59:59','POWRETH','4h','0.000773640000000','0.000759980000000','0.075179417382688','0.073851990101979','97.1762284559847','97.176228455984699','test'),('2019-03-23 07:59:59','2019-03-23 15:59:59','POWRETH','4h','0.000775080000000','0.000769900000000','0.075179417382688','0.074676979722005','96.99568739057646','96.995687390576464','test'),('2019-03-23 23:59:59','2019-03-24 03:59:59','POWRETH','4h','0.000772770000000','0.000771030000000','0.075179417382688','0.075010140384039','97.285631407389','97.285631407389005','test'),('2019-03-24 07:59:59','2019-03-26 11:59:59','POWRETH','4h','0.000780040000000','0.000795450000000','0.075179417382688','0.076664616631274','96.37892593032153','96.378925930321529','test'),('2019-03-26 23:59:59','2019-03-27 11:59:59','POWRETH','4h','0.000820000000000','0.000817010000000','0.075179417382688','0.074905287555890','91.68221632035123','91.682216320351230','test'),('2019-03-27 15:59:59','2019-03-30 07:59:59','POWRETH','4h','0.000825920000000','0.000836890000000','0.075179417382688','0.076177962288597','91.02505979112748','91.025059791127475','test'),('2019-03-31 23:59:59','2019-04-02 07:59:59','POWRETH','4h','0.000869760000000','0.000843810000000','0.075179417382688','0.072936378060253','86.43696810923474','86.436968109234741','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:30:53
