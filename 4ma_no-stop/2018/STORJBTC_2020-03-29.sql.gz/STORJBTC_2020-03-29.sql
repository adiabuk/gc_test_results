-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-22 15:59:59','2018-04-24 23:59:59','STORJBTC','4h','0.000126220000000','0.000124060000000','0.001467500000000','0.001442386705752','11.626525114878785','11.626525114878785','test'),('2018-04-28 19:59:59','2018-04-28 23:59:59','STORJBTC','4h','0.000124240000000','0.000124210000000','0.001467500000000','0.001467145645525','11.81181584030908','11.811815840309080','test'),('2018-04-29 07:59:59','2018-04-29 11:59:59','STORJBTC','4h','0.000124400000000','0.000119850000000','0.001467500000000','0.001413825361736','11.79662379421222','11.796623794212220','test'),('2018-04-30 07:59:59','2018-04-30 11:59:59','STORJBTC','4h','0.000123710000000','0.000126760000000','0.001467500000000','0.001503680381537','11.862420176218578','11.862420176218578','test'),('2018-04-30 19:59:59','2018-05-01 03:59:59','STORJBTC','4h','0.000127780000000','0.000122660000000','0.001467500000000','0.001408698935671','11.484582876819534','11.484582876819534','test'),('2018-05-02 03:59:59','2018-05-04 07:59:59','STORJBTC','4h','0.000126560000000','0.000126280000000','0.001467500000000','0.001464253318584','11.595290771175726','11.595290771175726','test'),('2018-06-01 03:59:59','2018-06-04 07:59:59','STORJBTC','4h','0.000114560000000','0.000104570000000','0.001467500000000','0.001339529285964','12.809881284916202','12.809881284916202','test'),('2018-07-03 03:59:59','2018-07-05 15:59:59','STORJBTC','4h','0.000082400000000','0.000077990000000','0.001467500000000','0.001388960254854','17.809466019417478','17.809466019417478','test'),('2018-08-06 07:59:59','2018-08-09 07:59:59','STORJBTC','4h','0.000063440000000','0.000065640000000','0.001467500000000','0.001518390605296','23.132093316519548','23.132093316519548','test'),('2018-08-09 11:59:59','2018-08-09 19:59:59','STORJBTC','4h','0.000067650000000','0.000066160000000','0.001467500000000','0.001435178122690','21.692535107169252','21.692535107169252','test'),('2018-08-30 07:59:59','2018-09-02 11:59:59','STORJBTC','4h','0.000046290000000','0.000046090000000','0.001467500000000','0.001461159537697','31.702311514365956','31.702311514365956','test'),('2018-09-16 15:59:59','2018-09-18 03:59:59','STORJBTC','4h','0.000046160000000','0.000039500000000','0.001467500000000','0.001255767980936','31.791594454072793','31.791594454072793','test'),('2018-09-19 03:59:59','2018-09-22 23:59:59','STORJBTC','4h','0.000042980000000','0.000044000000000','0.001467500000000','0.001502326663564','34.14378780828292','34.143787808282923','test'),('2018-09-23 07:59:59','2018-09-23 23:59:59','STORJBTC','4h','0.000044830000000','0.000044310000000','0.001467500000000','0.001450477916574','32.73477581976355','32.734775819763549','test'),('2018-09-24 03:59:59','2018-09-24 15:59:59','STORJBTC','4h','0.000046600000000','0.000042490000000','0.001467500000000','0.001338070278970','31.491416309012877','31.491416309012877','test'),('2018-10-08 19:59:59','2018-10-12 23:59:59','STORJBTC','4h','0.000042780000000','0.000045200000000','0.001467500000000','0.001550514259000','34.30341280972417','34.303412809724172','test'),('2018-10-13 07:59:59','2018-10-17 11:59:59','STORJBTC','4h','0.000048660000000','0.000053570000000','0.001467500000000','0.001615576962598','30.158240854911632','30.158240854911632','test'),('2018-10-21 19:59:59','2018-10-23 15:59:59','STORJBTC','4h','0.000054360000000','0.000052820000000','0.001467500000000','0.001425926232524','26.995952906548933','26.995952906548933','test'),('2018-11-01 11:59:59','2018-11-01 23:59:59','STORJBTC','4h','0.000053750000000','0.000052030000000','0.001467500000000','0.001420540000000','27.30232558139535','27.302325581395351','test'),('2018-11-02 03:59:59','2018-11-03 03:59:59','STORJBTC','4h','0.000052300000000','0.000051180000000','0.001467500000000','0.001436073613767','28.059273422562143','28.059273422562143','test'),('2018-11-28 23:59:59','2018-12-03 15:59:59','STORJBTC','4h','0.000040100000000','0.000041890000000','0.001467500000000','0.001533006857855','36.596009975062344','36.596009975062344','test'),('2018-12-23 07:59:59','2018-12-24 19:59:59','STORJBTC','4h','0.000039210000000','0.000038380000000','0.001467500000000','0.001436435858199','37.42667686814588','37.426676868145883','test'),('2018-12-24 23:59:59','2018-12-25 03:59:59','STORJBTC','4h','0.000038590000000','0.000037190000000','0.001467500000000','0.001414260818865','38.027986525006476','38.027986525006476','test'),('2018-12-31 07:59:59','2019-01-01 03:59:59','STORJBTC','4h','0.000038430000000','0.000037620000000','0.001467500000000','0.001436569086651','38.18631277647671','38.186312776476711','test'),('2019-01-01 15:59:59','2019-01-01 23:59:59','STORJBTC','4h','0.000038270000000','0.000038090000000','0.001467500000000','0.001460597726679','38.34596289521819','38.345962895218193','test'),('2019-01-02 03:59:59','2019-01-02 15:59:59','STORJBTC','4h','0.000038320000000','0.000037880000000','0.001467500000000','0.001450649791232','38.295929018789145','38.295929018789145','test'),('2019-01-02 19:59:59','2019-01-02 23:59:59','STORJBTC','4h','0.000038350000000','0.000037930000000','0.001467500000000','0.001451428292047','38.26597131681878','38.265971316818778','test'),('2019-01-03 03:59:59','2019-01-03 07:59:59','STORJBTC','4h','0.000038010000000','0.000038360000000','0.001467500000000','0.001481012891344','38.608260983951595','38.608260983951595','test'),('2019-01-03 11:59:59','2019-01-04 11:59:59','STORJBTC','4h','0.000038410000000','0.000038240000000','0.001467500000000','0.001461004946628','38.206196303046084','38.206196303046084','test'),('2019-01-05 23:59:59','2019-01-07 03:59:59','STORJBTC','4h','0.000038510000000','0.000037990000000','0.001467500000000','0.001447684367697','38.1069851986497','38.106985198649703','test'),('2019-01-07 15:59:59','2019-01-08 15:59:59','STORJBTC','4h','0.000038500000000','0.000038120000000','0.001467500000000','0.001453015584416','38.116883116883116','38.116883116883116','test'),('2019-01-08 19:59:59','2019-01-08 23:59:59','STORJBTC','4h','0.000038380000000','0.000038320000000','0.001467500000000','0.001465205836373','38.23606044815008','38.236060448150077','test'),('2019-01-17 07:59:59','2019-01-18 11:59:59','STORJBTC','4h','0.000037450000000','0.000036320000000','0.001467500000000','0.001423220293725','39.18558077436582','39.185580774365818','test'),('2019-01-19 03:59:59','2019-01-22 07:59:59','STORJBTC','4h','0.000037450000000','0.000038530000000','0.001467500000000','0.001509820427236','39.18558077436582','39.185580774365818','test'),('2019-01-22 19:59:59','2019-01-25 11:59:59','STORJBTC','4h','0.000039730000000','0.000039170000000','0.001467500000000','0.001446815378807','36.93682355902341','36.936823559023409','test'),('2019-02-04 15:59:59','2019-02-05 07:59:59','STORJBTC','4h','0.000039270000000','0.000041500000000','0.001467500000000','0.001550833969952','37.369493251846194','37.369493251846194','test'),('2019-02-05 15:59:59','2019-02-06 03:59:59','STORJBTC','4h','0.000041290000000','0.000037960000000','0.001467500000000','0.001349147493340','35.54129329135384','35.541293291353838','test'),('2019-02-07 11:59:59','2019-02-08 11:59:59','STORJBTC','4h','0.000044370000000','0.000040760000000','0.001467500000000','0.001348102321388','33.074149199909854','33.074149199909854','test'),('2019-02-11 19:59:59','2019-02-12 07:59:59','STORJBTC','4h','0.000040180000000','0.000040000000000','0.001467500000000','0.001460925833748','36.52314584370334','36.523145843703340','test'),('2019-02-12 15:59:59','2019-02-12 19:59:59','STORJBTC','4h','0.000039950000000','0.000039180000000','0.001467500000000','0.001439215269086','36.73341677096371','36.733416770963707','test'),('2019-02-16 11:59:59','2019-02-19 03:59:59','STORJBTC','4h','0.000055830000000','0.000055320000000','0.001467500000000','0.001454094572810','26.28515135231954','26.285151352319541','test'),('2019-02-20 03:59:59','2019-02-21 19:59:59','STORJBTC','4h','0.000064110000000','0.000059100000000','0.001467500000000','0.001352819372953','22.890344720012482','22.890344720012482','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','STORJBTC','4h','0.000062030000000','0.000059220000000','0.001467500000000','0.001401021280026','23.65790746413026','23.657907464130261','test'),('2019-02-27 11:59:59','2019-02-28 03:59:59','STORJBTC','4h','0.000061350000000','0.000058800000000','0.001467500000000','0.001406503667482','23.920130399348004','23.920130399348004','test'),('2019-03-01 23:59:59','2019-03-02 23:59:59','STORJBTC','4h','0.000060170000000','0.000059490000000','0.001467500000000','0.001450915323251','24.389230513544955','24.389230513544955','test'),('2019-03-03 11:59:59','2019-03-03 15:59:59','STORJBTC','4h','0.000058950000000','0.000058640000000','0.001467500000000','0.001459782866836','24.893977947413063','24.893977947413063','test'),('2019-03-10 11:59:59','2019-03-13 15:59:59','STORJBTC','4h','0.000061420000000','0.000063990000000','0.001467500000000','0.001528904672745','23.892868772386844','23.892868772386844','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','STORJBTC','4h','0.000069260000000','0.000064010000000','0.001467500000000','0.001356261550679','21.1882760612186','21.188276061218598','test'),('2019-03-15 07:59:59','2019-03-16 07:59:59','STORJBTC','4h','0.000068260000000','0.000064400000000','0.001467500000000','0.001384515089364','21.498681511866394','21.498681511866394','test'),('2019-03-17 11:59:59','2019-03-18 07:59:59','STORJBTC','4h','0.000066930000000','0.000064770000000','0.001467500000000','0.001420140071717','21.925892723741224','21.925892723741224','test'),('2019-03-19 15:59:59','2019-03-20 11:59:59','STORJBTC','4h','0.000066280000000','0.000065920000000','0.001467500000000','0.001459529269765','22.140917320458662','22.140917320458662','test'),('2019-03-20 19:59:59','2019-03-21 15:59:59','STORJBTC','4h','0.000065890000000','0.000065250000000','0.001467500000000','0.001453245940203','22.271968432235546','22.271968432235546','test'),('2019-03-21 23:59:59','2019-03-23 19:59:59','STORJBTC','4h','0.000067710000000','0.000066540000000','0.001467500000000','0.001442142224191','21.673312656919215','21.673312656919215','test'),('2019-03-24 03:59:59','2019-03-25 07:59:59','STORJBTC','4h','0.000067730000000','0.000066730000000','0.001467500000000','0.001445833087258','21.666912741768787','21.666912741768787','test'),('2019-03-26 19:59:59','2019-04-02 07:59:59','STORJBTC','4h','0.000069700000000','0.000070460000000','0.001467500000000','0.001483501434720','21.0545193687231','21.054519368723099','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 12:16:25
