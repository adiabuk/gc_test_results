-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-19 07:59:59','2018-09-19 15:59:59','GRSBTC','4h','0.000086960000000','0.000085030000000','0.001467500000000','0.001434930140294','16.875574977000923','16.875574977000923','test'),('2018-09-19 19:59:59','2018-09-22 15:59:59','GRSBTC','4h','0.000085520000000','0.000085700000000','0.001467500000000','0.001470588751169','17.15972871842844','17.159728718428440','test'),('2018-09-23 11:59:59','2018-09-24 11:59:59','GRSBTC','4h','0.000089770000000','0.000085080000000','0.001467500000000','0.001390831012588','16.34733207084772','16.347332070847720','test'),('2018-10-02 19:59:59','2018-10-03 03:59:59','GRSBTC','4h','0.000086130000000','0.000084070000000','0.001467500000000','0.001432401311970','17.03819807268083','17.038198072680832','test'),('2018-10-10 15:59:59','2018-10-11 03:59:59','GRSBTC','4h','0.000088000000000','0.000085740000000','0.001467500000000','0.001429811931818','16.676136363636363','16.676136363636363','test'),('2018-10-11 11:59:59','2018-10-11 15:59:59','GRSBTC','4h','0.000088010000000','0.000087060000000','0.001467500000000','0.001451659470515','16.674241563458697','16.674241563458697','test'),('2018-10-13 19:59:59','2018-10-14 07:59:59','GRSBTC','4h','0.000086210000000','0.000085760000000','0.001467500000000','0.001459839925763','17.022387194061015','17.022387194061015','test'),('2018-10-14 15:59:59','2018-10-14 23:59:59','GRSBTC','4h','0.000086950000000','0.000085110000000','0.001467500000000','0.001436445370903','16.877515813686028','16.877515813686028','test'),('2018-10-21 03:59:59','2018-10-21 07:59:59','GRSBTC','4h','0.000085070000000','0.000084330000000','0.001467500000000','0.001454734630304','17.250499588574115','17.250499588574115','test'),('2018-10-21 11:59:59','2018-10-21 15:59:59','GRSBTC','4h','0.000084350000000','0.000084580000000','0.001467500000000','0.001471501481921','17.39774748073503','17.397747480735031','test'),('2018-10-24 19:59:59','2018-10-25 03:59:59','GRSBTC','4h','0.000088000000000','0.000084940000000','0.001467500000000','0.001416471022727','16.676136363636363','16.676136363636363','test'),('2018-10-25 07:59:59','2018-10-25 11:59:59','GRSBTC','4h','0.000085520000000','0.000084630000000','0.001467500000000','0.001452227841441','17.15972871842844','17.159728718428440','test'),('2018-10-25 15:59:59','2018-10-25 19:59:59','GRSBTC','4h','0.000084970000000','0.000085280000000','0.001467500000000','0.001472853948452','17.270801459338593','17.270801459338593','test'),('2018-11-28 23:59:59','2018-11-29 23:59:59','GRSBTC','4h','0.000071650000000','0.000069450000000','0.001467500000000','0.001422440683880','20.481507327285417','20.481507327285417','test'),('2018-11-30 03:59:59','2018-11-30 11:59:59','GRSBTC','4h','0.000070910000000','0.000065590000000','0.001467500000000','0.001357401283317','20.695247496826966','20.695247496826966','test'),('2018-11-30 23:59:59','2018-12-05 07:59:59','GRSBTC','4h','0.000071000000000','0.000071500000000','0.001467500000000','0.001477834507042','20.66901408450704','20.669014084507040','test'),('2018-12-23 23:59:59','2018-12-25 03:59:59','GRSBTC','4h','0.000068550000000','0.000063050000000','0.001467500000000','0.001349757476295','21.407731582786287','21.407731582786287','test'),('2018-12-25 07:59:59','2018-12-25 11:59:59','GRSBTC','4h','0.000063120000000','0.000063250000000','0.001467500000000','0.001470522417617','23.24936628643853','23.249366286438530','test'),('2019-01-05 07:59:59','2019-01-06 03:59:59','GRSBTC','4h','0.000063040000000','0.000062210000000','0.001467500000000','0.001448178537437','23.278870558375633','23.278870558375633','test'),('2019-01-06 07:59:59','2019-01-06 11:59:59','GRSBTC','4h','0.000062320000000','0.000062000000000','0.001467500000000','0.001459964698331','23.547817715019256','23.547817715019256','test'),('2019-01-17 07:59:59','2019-01-18 11:59:59','GRSBTC','4h','0.000060970000000','0.000058850000000','0.001467500000000','0.001416473265540','24.06921436772183','24.069214367721830','test'),('2019-01-18 15:59:59','2019-01-18 19:59:59','GRSBTC','4h','0.000059200000000','0.000058500000000','0.001467500000000','0.001450147804054','24.78885135135135','24.788851351351351','test'),('2019-01-19 03:59:59','2019-01-20 15:59:59','GRSBTC','4h','0.000061590000000','0.000058750000000','0.001467500000000','0.001399831547329','23.826919954538077','23.826919954538077','test'),('2019-01-23 19:59:59','2019-01-23 23:59:59','GRSBTC','4h','0.000061020000000','0.000059520000000','0.001467500000000','0.001431425762045','24.049491969845953','24.049491969845953','test'),('2019-01-24 03:59:59','2019-01-25 23:59:59','GRSBTC','4h','0.000063350000000','0.000061900000000','0.001467500000000','0.001433910812944','23.16495659037096','23.164956590370959','test'),('2019-02-07 11:59:59','2019-02-08 07:59:59','GRSBTC','4h','0.000083500000000','0.000066350000000','0.001467500000000','0.001166091317365','17.5748502994012','17.574850299401199','test'),('2019-02-08 23:59:59','2019-02-09 03:59:59','GRSBTC','4h','0.000063000000000','0.000060410000000','0.001467500000000','0.001407169444444','23.293650793650794','23.293650793650794','test'),('2019-02-16 11:59:59','2019-02-18 19:59:59','GRSBTC','4h','0.000064620000000','0.000062140000000','0.001467500000000','0.001411179975240','22.709687403280718','22.709687403280718','test'),('2019-03-02 11:59:59','2019-03-02 15:59:59','GRSBTC','4h','0.000060700000000','0.000060850000000','0.001467500000000','0.001471126441516','24.176276771004943','24.176276771004943','test'),('2019-03-02 19:59:59','2019-03-03 15:59:59','GRSBTC','4h','0.000061000000000','0.000060800000000','0.001467500000000','0.001462688524590','24.057377049180328','24.057377049180328','test'),('2019-03-03 19:59:59','2019-03-03 23:59:59','GRSBTC','4h','0.000061030000000','0.000060640000000','0.001467500000000','0.001458122234966','24.045551368179584','24.045551368179584','test'),('2019-03-05 07:59:59','2019-03-07 07:59:59','GRSBTC','4h','0.000061000000000','0.000061330000000','0.001467500000000','0.001475438934426','24.057377049180328','24.057377049180328','test'),('2019-03-07 11:59:59','2019-03-08 07:59:59','GRSBTC','4h','0.000062870000000','0.000061090000000','0.001467500000000','0.001425951566725','23.341816446635917','23.341816446635917','test'),('2019-03-09 23:59:59','2019-03-11 07:59:59','GRSBTC','4h','0.000062230000000','0.000062390000000','0.001467500000000','0.001471273099791','23.581873694359633','23.581873694359633','test'),('2019-03-11 15:59:59','2019-03-14 03:59:59','GRSBTC','4h','0.000107320000000','0.000099720000000','0.001467500000000','0.001363577152441','13.67405888930302','13.674058889303019','test'),('2019-03-15 15:59:59','2019-03-16 07:59:59','GRSBTC','4h','0.000114890000000','0.000102550000000','0.001467500000000','0.001309880102707','12.77308730089651','12.773087300896510','test'),('2019-03-18 11:59:59','2019-03-20 07:59:59','GRSBTC','4h','0.000111110000000','0.000105800000000','0.000978333333333','0.000931578315783','8.80508805088051','8.805088050880510','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','GRSBTC','4h','0.000111750000000','0.000110620000000','0.001076982353089','0.001066092061733','9.63742597842729','9.637425978427290','test'),('2019-03-21 19:59:59','2019-03-24 03:59:59','GRSBTC','4h','0.000113010000000','0.000115690000000','0.001076982353089','0.001102522683204','9.529973923449253','9.529973923449253','test'),('2019-05-22 19:59:59','2019-05-23 07:59:59','GRSBTC','4h','0.000056250000000','0.000052810000000','0.001080644862779','0.001014557425837','19.211464227182216','19.211464227182216','test'),('2019-05-23 15:59:59','2019-05-24 19:59:59','GRSBTC','4h','0.000053910000000','0.000056190000000','0.001080644862779','0.001126348262652','20.045350821350397','20.045350821350397','test'),('2019-05-25 03:59:59','2019-05-26 19:59:59','GRSBTC','4h','0.000054780000000','0.000051060000000','0.001080644862779','0.001007260436172','19.726996399762687','19.726996399762687','test'),('2019-06-07 07:59:59','2019-06-07 23:59:59','GRSBTC','4h','0.000052350000000','0.000052120000000','0.001080644862779','0.001075897043898','20.642690788519577','20.642690788519577','test'),('2019-06-08 03:59:59','2019-06-13 07:59:59','GRSBTC','4h','0.000052710000000','0.000054570000000','0.001080644862779','0.001118778033805','20.50170485257067','20.501704852570668','test'),('2019-07-22 23:59:59','2019-07-25 23:59:59','GRSBTC','4h','0.000027510000000','0.000026780000000','0.001080644862779','0.001051969081251','39.28189250378044','39.281892503780441','test'),('2019-07-26 03:59:59','2019-07-27 15:59:59','GRSBTC','4h','0.000027990000000','0.000027290000000','0.001080644862779','0.001053619089148','38.60824804498034','38.608248044980343','test'),('2019-07-29 11:59:59','2019-07-31 07:59:59','GRSBTC','4h','0.000038040000000','0.000030380000000','0.001080644862779','0.000863038668013','28.408119421109355','28.408119421109355','test'),('2019-08-22 23:59:59','2019-08-26 03:59:59','GRSBTC','4h','0.000022350000000','0.000023090000000','0.001080644862779','0.001116424603202','48.35100057176733','48.351000571767329','test'),('2019-09-10 03:59:59','2019-09-12 03:59:59','GRSBTC','4h','0.000021720000000','0.000021080000000','0.001080644862779','0.001048802656878','49.75344672094843','49.753446720948432','test'),('2019-09-18 03:59:59','2019-09-19 03:59:59','GRSBTC','4h','0.000022030000000','0.000023200000000','0.001080644862779','0.001138037259032','49.053330130685424','49.053330130685424','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  7:35:07
