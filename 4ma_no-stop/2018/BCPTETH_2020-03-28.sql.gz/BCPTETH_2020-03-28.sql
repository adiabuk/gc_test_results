-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-01 23:59:59','2018-05-02 03:59:59','BCPTETH','4h','0.000909230000000','0.000921870000000','0.072144500000000','0.073147443677617','79.34680993807947','79.346809938079474','test'),('2018-05-02 11:59:59','2018-05-03 03:59:59','BCPTETH','4h','0.000919400000000','0.000897500000000','0.072395235919404','0.070670789903921','78.74182719099875','78.741827190998748','test'),('2018-07-01 19:59:59','2018-07-05 23:59:59','BCPTETH','4h','0.000384580000000','0.000386710000000','0.072395235919404','0.072796197624403','188.24493192418743','188.244931924187426','test'),('2018-07-06 03:59:59','2018-07-06 07:59:59','BCPTETH','4h','0.000389990000000','0.000366040000000','0.072395235919404','0.067949311920661','185.6335698848791','185.633569884879108','test'),('2018-07-12 07:59:59','2018-07-12 23:59:59','BCPTETH','4h','0.000396650000000','0.000381210000000','0.072395235919404','0.069577178582720','182.51666688366066','182.516666883660662','test'),('2018-07-13 03:59:59','2018-07-13 07:59:59','BCPTETH','4h','0.000383400000000','0.000373710000000','0.072395235919404','0.070565528470111','188.82429817267607','188.824298172676066','test'),('2018-07-13 11:59:59','2018-07-13 15:59:59','BCPTETH','4h','0.000374000000000','0.000381570000000','0.072395235919404','0.073860561951249','193.570149517123','193.570149517123014','test'),('2018-07-13 23:59:59','2018-07-14 07:59:59','BCPTETH','4h','0.000383230000000','0.000378550000000','0.072395235919404','0.071511146197559','188.908060223375','188.908060223375003','test'),('2018-07-16 23:59:59','2018-07-17 07:59:59','BCPTETH','4h','0.000405080000000','0.000384370000000','0.072395235919404','0.068693978548290','178.7183665434087','178.718366543408706','test'),('2018-07-17 15:59:59','2018-07-20 03:59:59','BCPTETH','4h','0.000391790000000','0.000384060000000','0.072395235919404','0.070966881000552','184.78071395238265','184.780713952382655','test'),('2018-07-20 11:59:59','2018-07-20 23:59:59','BCPTETH','4h','0.000422170000000','0.000395850000000','0.072395235919404','0.067881787286392','171.48361067675108','171.483610676751084','test'),('2018-07-21 11:59:59','2018-07-21 19:59:59','BCPTETH','4h','0.000404410000000','0.000394820000000','0.072395235919404','0.070678487291855','179.01445542742266','179.014455427422661','test'),('2018-07-30 07:59:59','2018-07-30 11:59:59','BCPTETH','4h','0.000386200000000','0.000381460000000','0.072395235919404','0.071506697808948','187.4552975644847','187.455297564484709','test'),('2018-08-24 07:59:59','2018-08-30 03:59:59','BCPTETH','4h','0.000304510000000','0.000328160000000','0.072395235919404','0.078017866800143','237.74337762110932','237.743377621109317','test'),('2018-08-31 07:59:59','2018-09-05 11:59:59','BCPTETH','4h','0.000340120000000','0.000341640000000','0.072395235919404','0.072718771020537','212.8520402193461','212.852040219346094','test'),('2018-09-06 19:59:59','2018-09-08 23:59:59','BCPTETH','4h','0.000366900000000','0.000357940000000','0.072395235919404','0.070627284668824','197.31598778796405','197.315987787964048','test'),('2018-09-09 03:59:59','2018-09-09 11:59:59','BCPTETH','4h','0.000362970000000','0.000360950000000','0.072395235919404','0.071992342080913','199.45239529273493','199.452395292734934','test'),('2018-09-09 19:59:59','2018-09-10 23:59:59','BCPTETH','4h','0.000362210000000','0.000354840000000','0.072395235919404','0.070922187442758','199.87089235361805','199.870892353618046','test'),('2018-09-11 23:59:59','2018-09-13 07:59:59','BCPTETH','4h','0.000361720000000','0.000367300000000','0.072395235919404','0.073512026299892','200.1416452488223','200.141645248822300','test'),('2018-09-14 23:59:59','2018-09-15 15:59:59','BCPTETH','4h','0.000380000000000','0.000357150000000','0.072395235919404','0.068041996075303','190.51377873527366','190.513778735273661','test'),('2018-09-16 07:59:59','2018-09-16 11:59:59','BCPTETH','4h','0.000378000000000','0.000363150000000','0.072395235919404','0.069551137365427','191.52178814657142','191.521788146571424','test'),('2018-09-16 23:59:59','2018-09-20 11:59:59','BCPTETH','4h','0.000379150000000','0.000380000000000','0.072395235919404','0.072557535670245','190.9408833427509','190.940883342750908','test'),('2018-09-20 15:59:59','2018-09-20 23:59:59','BCPTETH','4h','0.000411470000000','0.000383170000000','0.072395235919404','0.067416051102724','175.9429263844363','175.942926384436305','test'),('2018-09-25 15:59:59','2018-09-27 23:59:59','BCPTETH','4h','0.000405730000000','0.000385750000000','0.072395235919404','0.068830163546965','178.43205067262465','178.432050672624655','test'),('2018-09-28 07:59:59','2018-09-30 23:59:59','BCPTETH','4h','0.000390220000000','0.000413200000000','0.072395235919404','0.076658581010450','185.52415539799088','185.524155397990882','test'),('2018-10-04 15:59:59','2018-10-05 23:59:59','BCPTETH','4h','0.000437130000000','0.000413850000000','0.072395235919404','0.068539721330600','165.61488783520693','165.614887835206929','test'),('2018-10-08 03:59:59','2018-10-09 11:59:59','BCPTETH','4h','0.000420850000000','0.000411290000000','0.072395235919404','0.070750710660073','172.02147064133064','172.021470641330637','test'),('2018-10-10 11:59:59','2018-10-15 07:59:59','BCPTETH','4h','0.000445000000000','0.000491580000000','0.072395235919404','0.079973146232046','162.68592341439103','162.685923414391027','test'),('2018-10-17 07:59:59','2018-10-18 23:59:59','BCPTETH','4h','0.000565330000000','0.000513830000000','0.072395235919404','0.065800230082372','128.05836576761186','128.058365767611861','test'),('2018-10-20 07:59:59','2018-10-21 23:59:59','BCPTETH','4h','0.000546300000000','0.000520580000000','0.072395235919404','0.068986842238556','132.51919443420098','132.519194434200983','test'),('2018-10-22 15:59:59','2018-10-26 11:59:59','BCPTETH','4h','0.000546250000000','0.000547770000000','0.072395235919404','0.072596683532397','132.5313243375817','132.531324337581708','test'),('2018-10-29 19:59:59','2018-11-02 23:59:59','BCPTETH','4h','0.000594500000000','0.000585470000000','0.072395235919404','0.071295607693412','121.77499734130194','121.774997341301940','test'),('2018-12-01 11:59:59','2018-12-03 15:59:59','BCPTETH','4h','0.000361660000000','0.000351250000000','0.072395235919404','0.070311415740449','200.1748490831278','200.174849083127810','test'),('2018-12-04 07:59:59','2018-12-04 11:59:59','BCPTETH','4h','0.000360490000000','0.000348010000000','0.072395235919404','0.069888945746933','200.82453305058115','200.824533050581152','test'),('2018-12-04 15:59:59','2018-12-06 11:59:59','BCPTETH','4h','0.000370500000000','0.000354600000000','0.072395235919404','0.069288395835413','195.3987474207935','195.398747420793512','test'),('2018-12-15 07:59:59','2018-12-15 15:59:59','BCPTETH','4h','0.000360580000000','0.000342700000000','0.072395235919404','0.068805389510177','200.77440767486826','200.774407674868257','test'),('2018-12-15 19:59:59','2018-12-16 03:59:59','BCPTETH','4h','0.000352010000000','0.000343370000000','0.072395235919404','0.070618312427618','205.66244117895516','205.662441178955163','test'),('2018-12-16 07:59:59','2018-12-16 11:59:59','BCPTETH','4h','0.000354880000000','0.000345110000000','0.072395235919404','0.070402163740266','203.99919950237825','203.999199502378247','test'),('2018-12-16 19:59:59','2018-12-17 07:59:59','BCPTETH','4h','0.000350310000000','0.000346250000000','0.072395235919404','0.071556194333858','206.6604890508521','206.660489050852107','test'),('2018-12-17 11:59:59','2018-12-17 15:59:59','BCPTETH','4h','0.000346370000000','0.000346530000000','0.072395235919404','0.072428677723680','209.01127672547855','209.011276725478552','test'),('2018-12-18 19:59:59','2018-12-18 23:59:59','BCPTETH','4h','0.000351690000000','0.000342060000000','0.072395235919404','0.070412904542612','205.84957183714067','205.849571837140672','test'),('2019-01-13 11:59:59','2019-01-14 15:59:59','BCPTETH','4h','0.000232560000000','0.000223970000000','0.072395235919404','0.069721194482580','311.29702407724454','311.297024077244544','test'),('2019-01-14 23:59:59','2019-01-15 11:59:59','BCPTETH','4h','0.000239680000000','0.000228800000000','0.072395235919404','0.069108936825599','302.0495490629339','302.049549062933920','test'),('2019-01-15 15:59:59','2019-01-15 19:59:59','BCPTETH','4h','0.000230100000000','0.000231830000000','0.072395235919404','0.072939537345482','314.6251017792438','314.625101779243778','test'),('2019-01-15 23:59:59','2019-01-16 15:59:59','BCPTETH','4h','0.000232600000000','0.000241050000000','0.072395235919404','0.075025243415186','311.2434906251247','311.243490625124707','test'),('2019-01-17 03:59:59','2019-01-21 07:59:59','BCPTETH','4h','0.000241910000000','0.000281000000000','0.072395235919404','0.084093511195703','299.26516439751975','299.265164397519754','test'),('2019-01-21 19:59:59','2019-01-22 03:59:59','BCPTETH','4h','0.000286390000000','0.000279000000000','0.072395235919404','0.070527151162798','252.78548803870248','252.785488038702482','test'),('2019-01-22 19:59:59','2019-01-23 23:59:59','BCPTETH','4h','0.000292150000000','0.000280000000000','0.072395235919404','0.069384446542643','247.80159479515316','247.801594795153164','test'),('2019-01-25 15:59:59','2019-01-27 15:59:59','BCPTETH','4h','0.000284880000000','0.000280030000000','0.072395235919404','0.071162727866157','254.12537180358046','254.125371803580464','test'),('2019-02-28 07:59:59','2019-03-09 07:59:59','BCPTETH','4h','0.000245000000000','0.000341980000000','0.072395235919404','0.101051929713134','295.49075885471024','295.490758854710236','test'),('2019-03-13 07:59:59','2019-03-14 07:59:59','BCPTETH','4h','0.000363730000000','0.000345000000000','0.072395235919404','0.068667298249235','199.03564709923296','199.035647099232960','test'),('2019-03-27 15:59:59','2019-03-28 07:59:59','BCPTETH','4h','0.000356210000000','0.000329870000000','0.072395235919404','0.067041959722450','203.23751696865332','203.237516968653324','test'),('2019-03-28 11:59:59','2019-03-30 03:59:59','BCPTETH','4h','0.000350100000000','0.000334000000000','0.072395235919404','0.069066006275581','206.78444992688947','206.784449926889465','test'),('2019-03-31 03:59:59','2019-04-02 07:59:59','BCPTETH','4h','0.000348410000000','0.000357190000000','0.072395235919404','0.074219609994122','207.78748003617577','207.787480036175765','test'),('2019-04-07 07:59:59','2019-04-07 23:59:59','BCPTETH','4h','0.000376200000000','0.000353950000000','0.072395235919404','0.068113486851869','192.43816033866028','192.438160338660282','test'),('2019-04-19 23:59:59','2019-04-21 11:59:59','BCPTETH','4h','0.000366650000000','0.000342230000000','0.072395235919404','0.067573494037086','197.45052753144415','197.450527531444152','test'),('2019-04-22 11:59:59','2019-04-24 07:59:59','BCPTETH','4h','0.000358400000000','0.000347340000000','0.072395235919404','0.070161164185954','201.99563593583707','201.995635935837072','test'),('2019-04-24 11:59:59','2019-04-24 15:59:59','BCPTETH','4h','0.000357630000000','0.000370620000000','0.072395235919404','0.075024808702988','202.43054531052763','202.430545310527634','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:48:07
