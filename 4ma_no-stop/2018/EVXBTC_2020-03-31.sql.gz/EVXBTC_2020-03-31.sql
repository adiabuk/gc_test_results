-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-12 23:59:59','2018-04-16 07:59:59','EVXBTC','4h','0.000151370000000','0.000152980000000','0.001467500000000','0.001483108608047','9.694787606527052','9.694787606527052','test'),('2018-04-18 03:59:59','2018-04-24 23:59:59','EVXBTC','4h','0.000156270000000','0.000189000000000','0.001471402152012','0.001779580256801','9.415768554500225','9.415768554500225','test'),('2018-04-29 03:59:59','2018-04-29 11:59:59','EVXBTC','4h','0.000184610000000','0.000179110000000','0.001548446678209','0.001502314525400','8.387664147169708','8.387664147169708','test'),('2018-04-29 15:59:59','2018-05-01 03:59:59','EVXBTC','4h','0.000180040000000','0.000181810000000','0.001548446678209','0.001563669687654','8.600570307759387','8.600570307759387','test'),('2018-05-01 07:59:59','2018-05-03 19:59:59','EVXBTC','4h','0.000185480000000','0.000189800000000','0.001548446678209','0.001584511427238','8.348321534445763','8.348321534445763','test'),('2018-05-05 19:59:59','2018-05-05 23:59:59','EVXBTC','4h','0.000213000000000','0.000185810000000','0.001549735579625','0.001351907831221','7.275753894954226','7.275753894954226','test'),('2018-06-04 03:59:59','2018-06-04 07:59:59','EVXBTC','4h','0.000148160000000','0.000142700000000','0.001549735579625','0.001492624643713','10.459878372198974','10.459878372198974','test'),('2018-07-03 03:59:59','2018-07-04 00:22:26','EVXBTC','4h','0.000137770000000','0.000110050000000','0.001549735579625','0.001237921176873','11.248715828010452','11.248715828010452','test'),('2018-07-04 11:59:59','2018-07-05 19:59:59','EVXBTC','4h','0.000113110000000','0.000111220000000','0.001549735579625','0.001523840431137','13.701136766201042','13.701136766201042','test'),('2018-07-07 11:59:59','2018-07-07 23:59:59','EVXBTC','4h','0.000117620000000','0.000107610000000','0.001549735579625','0.001417845993228','13.17578285686958','13.175782856869580','test'),('2018-07-18 07:59:59','2018-07-18 11:59:59','EVXBTC','4h','0.000108210000000','0.000103910000000','0.001549735579625','0.001488152888632','14.321556044958877','14.321556044958877','test'),('2018-08-09 03:59:59','2018-08-10 19:59:59','EVXBTC','4h','0.000081870000000','0.000076440000000','0.001549735579625','0.001446949892592','18.929224131244656','18.929224131244656','test'),('2018-09-01 11:59:59','2018-09-02 03:59:59','EVXBTC','4h','0.000067130000000','0.000067190000000','0.001549735579625','0.001551120714956','23.08558885185461','23.085588851854610','test'),('2018-09-02 15:59:59','2018-09-02 19:59:59','EVXBTC','4h','0.000065900000000','0.000065010000000','0.001549735579625','0.001528805918534','23.51647313543247','23.516473135432470','test'),('2018-09-03 07:59:59','2018-09-03 19:59:59','EVXBTC','4h','0.000067700000000','0.000065850000000','0.001549735579625','0.001507386823018','22.89121978766617','22.891219787666170','test'),('2018-09-05 03:59:59','2018-09-05 11:59:59','EVXBTC','4h','0.000066470000000','0.000062360000000','0.001549735579625','0.001453911700698','23.314812390928235','23.314812390928235','test'),('2018-09-18 15:59:59','2018-09-24 07:59:59','EVXBTC','4h','0.000062140000000','0.000063020000000','0.001549735579625','0.001571682269520','24.93942033513035','24.939420335130350','test'),('2018-09-27 03:59:59','2018-10-02 11:59:59','EVXBTC','4h','0.000065890000000','0.000068750000000','0.001549735579625','0.001617002900277','23.520042185840037','23.520042185840037','test'),('2018-10-05 03:59:59','2018-10-09 07:59:59','EVXBTC','4h','0.000069610000000','0.000076060000000','0.001549735579625','0.001693332684762','22.263117075492023','22.263117075492023','test'),('2018-10-10 19:59:59','2018-10-12 03:59:59','EVXBTC','4h','0.000095950000000','0.000077120000000','0.001549735579625','0.001245603000528','16.151491189421574','16.151491189421574','test'),('2018-10-13 15:59:59','2018-10-15 03:59:59','EVXBTC','4h','0.000094000000000','0.000079320000000','0.001549735579625','0.001307713044424','16.486548719414895','16.486548719414895','test'),('2018-10-15 15:59:59','2018-10-15 19:59:59','EVXBTC','4h','0.000084450000000','0.000080900000000','0.001549735579625','0.001484589797415','18.350924566311424','18.350924566311424','test'),('2018-10-15 23:59:59','2018-10-18 19:59:59','EVXBTC','4h','0.000085680000000','0.000082630000000','0.001549735579625','0.001494568755187','18.087483422327264','18.087483422327264','test'),('2018-10-21 03:59:59','2018-10-21 23:59:59','EVXBTC','4h','0.000085630000000','0.000083620000000','0.001549735579625','0.001513358509497','18.098044839717385','18.098044839717385','test'),('2018-10-24 07:59:59','2018-10-25 15:59:59','EVXBTC','4h','0.000087960000000','0.000083920000000','0.001549735579625','0.001478556273785','17.618640059401997','17.618640059401997','test'),('2018-10-27 03:59:59','2018-10-27 11:59:59','EVXBTC','4h','0.000086180000000','0.000085330000000','0.001033157053083','0.001022966945226','11.988362184768313','11.988362184768313','test'),('2018-11-01 19:59:59','2018-11-01 23:59:59','EVXBTC','4h','0.000083860000000','0.000084530000000','0.001150228967035','0.001159418728637','13.716062092001557','13.716062092001557','test'),('2018-11-02 03:59:59','2018-11-02 07:59:59','EVXBTC','4h','0.000084870000000','0.000083820000000','0.001152526407436','0.001138267508793','13.579903469255926','13.579903469255926','test'),('2018-11-02 11:59:59','2018-11-02 15:59:59','EVXBTC','4h','0.000084140000000','0.000085180000000','0.001152526407436','0.001166772039285','13.697722931257427','13.697722931257427','test'),('2018-11-30 03:59:59','2018-12-03 03:59:59','EVXBTC','4h','0.000065540000000','0.000066770000000','0.001152526407436','0.001174156060795','17.58508403167531','17.585084031675311','test'),('2018-12-22 23:59:59','2018-12-25 03:59:59','EVXBTC','4h','0.000061090000000','0.000059300000000','0.001157930504077','0.001124001946174','18.954501621820278','18.954501621820278','test'),('2019-01-01 07:59:59','2019-01-02 07:59:59','EVXBTC','4h','0.000063950000000','0.000060200000000','0.001157930504077','0.001090029966309','18.10681007157154','18.106810071571541','test'),('2019-01-02 11:59:59','2019-01-03 11:59:59','EVXBTC','4h','0.000060250000000','0.000059760000000','0.001157930504077','0.001148513309936','19.218763553145227','19.218763553145227','test'),('2019-01-03 15:59:59','2019-01-06 19:59:59','EVXBTC','4h','0.000060530000000','0.000061660000000','0.001157930504077','0.001179547247338','19.129861293193457','19.129861293193457','test'),('2019-01-16 15:59:59','2019-01-18 11:59:59','EVXBTC','4h','0.000062180000000','0.000061090000000','0.001157930504077','0.001137632269123','18.622233902814408','18.622233902814408','test'),('2019-01-18 15:59:59','2019-01-21 07:59:59','EVXBTC','4h','0.000064610000000','0.000065000000000','0.001157930504077','0.001164920024222','17.921846526497443','17.921846526497443','test'),('2019-01-21 23:59:59','2019-01-29 03:59:59','EVXBTC','4h','0.000075590000000','0.000081530000000','0.001157930504077','0.001248922793986','15.318567324738721','15.318567324738721','test'),('2019-01-30 11:59:59','2019-01-31 23:59:59','EVXBTC','4h','0.000092650000000','0.000084460000000','0.001157930504077','0.001055572696971','12.497900745569346','12.497900745569346','test'),('2019-03-01 15:59:59','2019-03-02 11:59:59','EVXBTC','4h','0.000071440000000','0.000068310000000','0.001157930504077','0.001107198106572','16.208433707684772','16.208433707684772','test'),('2019-03-02 15:59:59','2019-03-04 07:59:59','EVXBTC','4h','0.000069420000000','0.000070060000000','0.001157930504077','0.001168605749289','16.680070643575338','16.680070643575338','test'),('2019-03-04 15:59:59','2019-03-04 23:59:59','EVXBTC','4h','0.000070080000000','0.000070150000000','0.001157930504077','0.001159087112743','16.522980937171802','16.522980937171802','test'),('2019-03-05 03:59:59','2019-03-10 03:59:59','EVXBTC','4h','0.000071010000000','0.000074500000000','0.001157930504077','0.001214840480971','16.306583637191945','16.306583637191945','test'),('2019-03-13 07:59:59','2019-03-13 11:59:59','EVXBTC','4h','0.000074860000000','0.000074140000000','0.001157930504077','0.001146793582317','15.467946888551962','15.467946888551962','test'),('2019-03-13 15:59:59','2019-03-13 23:59:59','EVXBTC','4h','0.000074620000000','0.000074720000000','0.001157930504077','0.001159482273715','15.517696382699008','15.517696382699008','test'),('2019-03-14 03:59:59','2019-03-17 11:59:59','EVXBTC','4h','0.000075340000000','0.000077760000000','0.001157930504077','0.001195124449124','15.36939877989116','15.369398779891160','test'),('2019-03-20 11:59:59','2019-03-21 15:59:59','EVXBTC','4h','0.000077700000000','0.000073850000000','0.001157930504077','0.001100555569190','14.902580490051479','14.902580490051479','test'),('2019-03-25 15:59:59','2019-03-26 03:59:59','EVXBTC','4h','0.000229540000000','0.000162480000000','0.001157930504077','0.000819641667258','5.044569591692079','5.044569591692079','test'),('2019-03-26 07:59:59','2019-03-28 23:59:59','EVXBTC','4h','0.000208590000000','0.000219980000000','0.001157930504077','0.001221158983110','5.551227307526727','5.551227307526727','test'),('2019-03-29 03:59:59','2019-03-31 03:59:59','EVXBTC','4h','0.000269250000000','0.000233910000000','0.001157930504077','0.001005948093625','4.300577545318477','4.300577545318477','test'),('2019-04-01 07:59:59','2019-04-02 23:59:59','EVXBTC','4h','0.000311570000000','0.000236100000000','0.001157930504077','0.000877450948463','3.7164377317360464','3.716437731736046','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  6:15:14
