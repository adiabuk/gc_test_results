-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-26 01:59:59','2018-07-08 11:59:59','MCOBNB','4h','0.343000000000000','0.594370000000000','0.711908500000000','1.233635729285714','2.0755349854227405','2.075534985422741','test'),('2018-07-08 23:59:59','2018-07-10 23:59:59','MCOBNB','4h','0.624400000000000','0.613500000000000','0.842340307321429','0.827635776011686','1.349039569701199','1.349039569701199','test'),('2018-07-17 03:59:59','2018-07-17 15:59:59','MCOBNB','4h','0.620940000000000','0.585000000000000','0.842340307321429','0.793585660100873','1.3565566839331158','1.356556683933116','test'),('2018-07-17 19:59:59','2018-07-19 07:59:59','MCOBNB','4h','0.590250000000000','0.589950000000000','0.842340307321429','0.841912180100427','1.427090736673323','1.427090736673323','test'),('2018-07-21 15:59:59','2018-07-24 19:59:59','MCOBNB','4h','0.612830000000000','0.618490000000000','0.842340307321429','0.850120027862916','1.374508929591288','1.374508929591288','test'),('2018-08-14 11:59:59','2018-08-15 03:59:59','MCOBNB','4h','0.511970000000000','0.474930000000000','0.842340307321429','0.781398679915163','1.6452923165838407','1.645292316583841','test'),('2018-08-15 07:59:59','2018-08-15 11:59:59','MCOBNB','4h','0.475600000000000','0.468310000000000','0.842340307321429','0.829428909423251','1.7711108227952668','1.771110822795267','test'),('2018-09-04 23:59:59','2018-09-05 11:59:59','MCOBNB','4h','0.457140000000000','0.426270000000000','0.842340307321429','0.785458290243482','1.8426309387089927','1.842630938708993','test'),('2018-09-05 19:59:59','2018-09-06 03:59:59','MCOBNB','4h','0.430310000000000','0.423300000000000','0.842340307321429','0.828618094139483','1.9575197121178427','1.957519712117843','test'),('2018-09-06 07:59:59','2018-09-08 15:59:59','MCOBNB','4h','0.424000000000000','0.440340000000000','0.842340307321429','0.874802195579995','1.9866516682109174','1.986651668210917','test'),('2018-09-08 19:59:59','2018-09-08 23:59:59','MCOBNB','4h','0.467670000000000','0.430880000000000','0.842340307321429','0.776076275191176','1.801142487911196','1.801142487911196','test'),('2018-09-10 11:59:59','2018-09-11 15:59:59','MCOBNB','4h','0.466010000000000','0.447960000000000','0.842340307321429','0.809713877529897','1.8075584372039848','1.807558437203985','test'),('2018-09-11 19:59:59','2018-09-12 03:59:59','MCOBNB','4h','0.450580000000000','0.441980000000000','0.842340307321429','0.826262970016257','1.8694578261827621','1.869457826182762','test'),('2018-09-12 15:59:59','2018-09-13 07:59:59','MCOBNB','4h','0.470190000000000','0.454780000000000','0.842340307321429','0.814733458737190','1.7914892007942087','1.791489200794209','test'),('2018-09-13 11:59:59','2018-09-14 11:59:59','MCOBNB','4h','0.468850000000000','0.443000000000000','0.842340307321429','0.795897954875532','1.7966093789515387','1.796609378951539','test'),('2018-09-26 07:59:59','2018-09-27 15:59:59','MCOBNB','4h','0.450320000000000','0.441880000000000','0.842340307321429','0.826552973439317','1.8705371898237453','1.870537189823745','test'),('2018-09-27 19:59:59','2018-09-27 23:59:59','MCOBNB','4h','0.454790000000000','0.454360000000000','0.842340307321429','0.841543881867597','1.8521522182137446','1.852152218213745','test'),('2018-09-29 15:59:59','2018-09-30 11:59:59','MCOBNB','4h','0.455460000000000','0.443500000000000','0.842340307321429','0.820221152893896','1.8494276277201709','1.849427627720171','test'),('2018-09-30 15:59:59','2018-09-30 19:59:59','MCOBNB','4h','0.450980000000000','0.448460000000000','0.842340307321429','0.837633452085166','1.8677996969298616','1.867799696929862','test'),('2018-10-01 07:59:59','2018-10-01 15:59:59','MCOBNB','4h','0.454800000000000','0.445000000000000','0.842340307321429','0.824189614683456','1.8521114936706882','1.852111493670688','test'),('2018-10-02 07:59:59','2018-10-02 23:59:59','MCOBNB','4h','0.456430000000000','0.445050000000000','0.842340307321429','0.821338548678663','1.845497244531317','1.845497244531317','test'),('2018-10-04 03:59:59','2018-10-04 19:59:59','MCOBNB','4h','0.462600000000000','0.457300000000000','0.842340307321429','0.832689629351685','1.8208826358007544','1.820882635800754','test'),('2018-10-10 15:59:59','2018-10-11 03:59:59','MCOBNB','4h','0.461990000000000','0.441060000000000','0.842340307321429','0.804178912849173','1.8232868835287104','1.823286883528710','test'),('2018-10-11 07:59:59','2018-10-11 15:59:59','MCOBNB','4h','0.446940000000000','0.442570000000000','0.842340307321429','0.834104241757831','1.8846831953314291','1.884683195331429','test'),('2018-10-11 19:59:59','2018-10-12 03:59:59','MCOBNB','4h','0.445280000000000','0.436050000000000','0.842340307321429','0.824879830685207','1.8917092780305178','1.891709278030518','test'),('2018-10-12 07:59:59','2018-10-12 11:59:59','MCOBNB','4h','0.449850000000000','0.433100000000000','0.842340307321429','0.810976074471292','1.872491513440989','1.872491513440989','test'),('2018-10-14 03:59:59','2018-10-14 07:59:59','MCOBNB','4h','0.448630000000000','0.450000000000000','0.842340307321429','0.844912596782745','1.8775835484061008','1.877583548406101','test'),('2018-10-14 15:59:59','2018-10-14 23:59:59','MCOBNB','4h','0.441380000000000','0.437410000000000','0.842340307321429','0.834763862942286','1.90842427686218','1.908424276862180','test'),('2018-10-18 19:59:59','2018-10-24 23:59:59','MCOBNB','4h','0.465970000000000','0.498420000000000','0.842340307321429','0.901000613720082','1.8077136024238234','1.807713602423823','test'),('2018-10-26 07:59:59','2018-10-26 23:59:59','MCOBNB','4h','0.519600000000000','0.494320000000000','0.842340307321429','0.801358084517184','1.6211322311805794','1.621132231180579','test'),('2018-11-16 15:59:59','2018-11-18 19:59:59','MCOBNB','4h','0.484300000000000','0.462220000000000','0.842340307321429','0.803936685628971','1.7392944607091243','1.739294460709124','test'),('2018-11-19 03:59:59','2018-11-19 11:59:59','MCOBNB','4h','0.483700000000000','0.461890000000000','0.842340307321429','0.804359240332220','1.7414519481526336','1.741451948152634','test'),('2018-12-01 03:59:59','2018-12-04 03:59:59','MCOBNB','4h','0.460000000000000','0.438690000000000','0.842340307321429','0.803317976997473','1.8311745811335411','1.831174581133541','test'),('2018-12-25 03:59:59','2018-12-27 03:59:59','MCOBNB','4h','0.493090000000000','0.398620000000000','0.842340307321429','0.680958229338393','1.708289170985883','1.708289170985883','test'),('2019-01-04 23:59:59','2019-01-08 11:59:59','MCOBNB','4h','0.399080000000000','0.403850000000000','0.842340307321429','0.852408372035078','2.1107053907021873','2.110705390702187','test'),('2019-02-15 23:59:59','2019-02-19 15:59:59','MCOBNB','4h','0.283050000000000','0.269360000000000','0.842340307321429','0.801599665006536','2.975941732278498','2.975941732278498','test'),('2019-02-20 19:59:59','2019-02-22 07:59:59','MCOBNB','4h','0.297040000000000','0.276730000000000','0.842340307321429','0.784745600744206','2.835780727583588','2.835780727583588','test'),('2019-02-26 15:59:59','2019-02-27 07:59:59','MCOBNB','4h','0.292170000000000','0.279970000000000','0.561560204880953','0.538111409660542','1.922032395115695','1.922032395115695','test'),('2019-02-27 11:59:59','2019-02-27 15:59:59','MCOBNB','4h','0.291750000000000','0.279940000000000','0.612243740257411','0.587460197592664','2.098521817506123','2.098521817506123','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','MCOBNB','4h','0.282320000000000','0.274560000000000','0.612243740257411','0.595415278142090','2.1686162519743943','2.168616251974394','test'),('2019-03-15 15:59:59','2019-03-16 15:59:59','MCOBNB','4h','0.222930000000000','0.204080000000000','0.612243740257411','0.560475048274043','2.74634970734047','2.746349707340470','test'),('2019-03-16 19:59:59','2019-03-16 23:59:59','MCOBNB','4h','0.207690000000000','0.203040000000000','0.612243740257411','0.598536130877099','2.947872985013294','2.947872985013294','test'),('2019-03-17 19:59:59','2019-03-18 11:59:59','MCOBNB','4h','0.215810000000000','0.210900000000000','0.612243740257411','0.598314280247847','2.836957232090316','2.836957232090316','test'),('2019-03-19 03:59:59','2019-03-19 11:59:59','MCOBNB','4h','0.216090000000000','0.210950000000000','0.612243740257411','0.597680674752653','2.8332812266065575','2.833281226606557','test'),('2019-03-19 15:59:59','2019-03-22 15:59:59','MCOBNB','4h','0.214090000000000','0.214220000000000','0.612243740257411','0.612615507674074','2.8597493589490917','2.859749358949092','test'),('2019-03-28 23:59:59','2019-03-30 19:59:59','MCOBNB','4h','0.219280000000000','0.206590000000000','0.612243740257411','0.576812451202930','2.7920637552782335','2.792063755278233','test'),('2019-04-08 11:59:59','2019-04-13 11:59:59','MCOBNB','4h','0.215600000000000','0.221420000000000','0.612243740257411','0.628770913579759','2.839720502121572','2.839720502121572','test'),('2019-04-17 11:59:59','2019-04-18 07:59:59','MCOBNB','4h','0.219070000000000','0.214340000000000','0.612243740257411','0.599024619011154','2.7947402211960153','2.794740221196015','test'),('2019-04-18 11:59:59','2019-04-18 15:59:59','MCOBNB','4h','0.217860000000000','0.209160000000000','0.612243740257411','0.587794458423942','2.810262279709038','2.810262279709038','test'),('2019-04-19 07:59:59','2019-04-19 11:59:59','MCOBNB','4h','0.219910000000000','0.213080000000000','0.612243740257411','0.593228576117726','2.7840650277723205','2.784065027772320','test'),('2019-04-30 07:59:59','2019-05-02 11:59:59','MCOBNB','4h','0.216840000000000','0.209100000000000','0.612243740257411','0.590389993026308','2.8234815544060643','2.823481554406064','test'),('2019-05-04 15:59:59','2019-05-11 15:59:59','MCOBNB','4h','0.216000000000000','0.228180000000000','0.612243740257411','0.646767484499704','2.834461760450977','2.834461760450977','test'),('2019-05-27 15:59:59','2019-05-30 07:59:59','MCOBNB','4h','0.215570000000000','0.193610000000000','0.612243740257411','0.549874799606798','2.84011569447238','2.840115694472380','test'),('2019-05-30 11:59:59','2019-06-01 07:59:59','MCOBNB','4h','0.200260000000000','0.197930000000000','0.612243740257411','0.605120361076348','3.0572442837182217','3.057244283718222','test'),('2019-06-02 15:59:59','2019-06-03 23:59:59','MCOBNB','4h','0.205250000000000','0.198170000000000','0.612243740257411','0.591124687000298','2.9829171267108943','2.982917126710894','test'),('2019-06-11 07:59:59','2019-06-11 23:59:59','MCOBNB','4h','0.201020000000000','0.208790000000000','0.612243740257411','0.635908718179011','3.045685704195657','3.045685704195657','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 10:05:13
