-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-17 11:59:59','2018-05-17 19:59:59','ADXBNB','4h','0.067840000000000','0.063210000000000','0.711908500000000','0.663321584389741','10.493934257075473','10.493934257075473','test'),('2018-06-28 15:59:59','2018-06-28 23:59:59','ADXBNB','4h','0.027150000000000','0.024450000000000','0.711908500000000','0.641110969613260','26.221307550644568','26.221307550644568','test'),('2018-06-30 07:59:59','2018-06-30 15:59:59','ADXBNB','4h','0.027310000000000','0.027560000000000','0.711908500000000','0.718425421457342','26.067685829366532','26.067685829366532','test'),('2018-06-30 19:59:59','2018-07-06 11:59:59','ADXBNB','4h','0.027620000000000','0.030260000000000','0.711908500000000','0.779954786748733','25.775108616944248','25.775108616944248','test'),('2018-07-11 03:59:59','2018-07-12 07:59:59','ADXBNB','4h','0.030290000000000','0.028700000000000','0.711908500000000','0.674538591944536','23.503086827335757','23.503086827335757','test'),('2018-07-12 11:59:59','2018-07-12 15:59:59','ADXBNB','4h','0.029380000000000','0.028930000000000','0.711908500000000','0.701004523655548','24.231058543226688','24.231058543226688','test'),('2018-07-12 19:59:59','2018-07-12 23:59:59','ADXBNB','4h','0.029080000000000','0.028980000000000','0.711908500000000','0.709460396492435','24.48103507565337','24.481035075653370','test'),('2018-07-13 03:59:59','2018-07-13 07:59:59','ADXBNB','4h','0.029510000000000','0.028700000000000','0.711908500000000','0.692367805828533','24.124313791934938','24.124313791934938','test'),('2018-07-15 11:59:59','2018-07-16 07:59:59','ADXBNB','4h','0.029400000000000','0.027860000000000','0.711908500000000','0.674618054761905','24.214574829931976','24.214574829931976','test'),('2018-07-16 23:59:59','2018-07-17 11:59:59','ADXBNB','4h','0.029760000000000','0.029390000000000','0.711908500000000','0.703057487063172','23.921656586021506','23.921656586021506','test'),('2018-07-17 19:59:59','2018-07-20 23:59:59','ADXBNB','4h','0.030030000000000','0.030850000000000','0.711908500000000','0.731347892940393','23.70657675657676','23.706576756576759','test'),('2018-07-23 07:59:59','2018-07-25 07:59:59','ADXBNB','4h','0.031810000000000','0.033290000000000','0.711908500000000','0.745030932568375','22.380022005658603','22.380022005658603','test'),('2018-08-26 03:59:59','2018-08-26 15:59:59','ADXBNB','4h','0.018900000000000','0.018250000000000','0.711908500000000','0.687424874338624','37.667116402116406','37.667116402116406','test'),('2018-08-26 23:59:59','2018-08-27 03:59:59','ADXBNB','4h','0.018410000000000','0.018030000000000','0.711908500000000','0.697214027973927','38.66966322650734','38.669663226507339','test'),('2018-08-28 11:59:59','2018-08-28 23:59:59','ADXBNB','4h','0.018830000000000','0.018530000000000','0.711908500000000','0.700566357142857','37.807142857142864','37.807142857142864','test'),('2018-08-29 07:59:59','2018-08-29 11:59:59','ADXBNB','4h','0.018510000000000','0.018220000000000','0.711908500000000','0.700754882225824','38.4607509454349','38.460750945434903','test'),('2018-08-29 15:59:59','2018-08-29 19:59:59','ADXBNB','4h','0.018840000000000','0.018530000000000','0.711908500000000','0.700194506634820','37.787075371549896','37.787075371549896','test'),('2018-08-29 23:59:59','2018-08-30 11:59:59','ADXBNB','4h','0.019460000000000','0.018260000000000','0.711908500000000','0.668008695272353','36.58317060637204','36.583170606372043','test'),('2018-08-30 15:59:59','2018-08-30 19:59:59','ADXBNB','4h','0.018580000000000','0.018390000000000','0.711908500000000','0.704628488428418','38.3158503767492','38.315850376749196','test'),('2018-08-30 23:59:59','2018-09-01 03:59:59','ADXBNB','4h','0.019470000000000','0.018600000000000','0.711908500000000','0.680097488443760','36.56438109912686','36.564381099126862','test'),('2018-09-01 07:59:59','2018-09-02 23:59:59','ADXBNB','4h','0.020200000000000','0.019110000000000','0.711908500000000','0.673493635396040','35.242995049504955','35.242995049504955','test'),('2018-09-03 11:59:59','2018-09-04 11:59:59','ADXBNB','4h','0.019470000000000','0.019100000000000','0.711908500000000','0.698379678993323','36.56438109912686','36.564381099126862','test'),('2018-09-04 15:59:59','2018-09-05 07:59:59','ADXBNB','4h','0.019450000000000','0.019080000000000','0.711908500000000','0.698365767609255','36.60197943444731','36.601979434447308','test'),('2018-09-16 15:59:59','2018-09-19 15:59:59','ADXBNB','4h','0.018880000000000','0.018410000000000','0.711908500000000','0.694186201536017','37.70701800847458','37.707018008474577','test'),('2018-09-21 15:59:59','2018-09-24 15:59:59','ADXBNB','4h','0.018730000000000','0.018700000000000','0.711908500000000','0.710768230112120','38.00899626268019','38.008996262680192','test'),('2018-09-25 15:59:59','2018-09-28 15:59:59','ADXBNB','4h','0.021780000000000','0.019310000000000','0.711908500000000','0.631173238521579','32.6863406795225','32.686340679522502','test'),('2018-09-28 23:59:59','2018-09-29 03:59:59','ADXBNB','4h','0.020220000000000','0.019650000000000','0.711908500000000','0.691839862759644','35.20813550939664','35.208135509396641','test'),('2018-09-29 11:59:59','2018-10-01 15:59:59','ADXBNB','4h','0.020220000000000','0.020070000000000','0.711908500000000','0.706627279673591','35.20813550939664','35.208135509396641','test'),('2018-10-02 03:59:59','2018-10-02 11:59:59','ADXBNB','4h','0.020640000000000','0.020290000000000','0.711908500000000','0.699836408187985','34.49169089147287','34.491690891472871','test'),('2018-10-08 19:59:59','2018-10-09 15:59:59','ADXBNB','4h','0.019830000000000','0.020220000000000','0.711908500000000','0.725909726172466','35.9005799293999','35.900579929399903','test'),('2018-10-09 23:59:59','2018-10-12 03:59:59','ADXBNB','4h','0.020380000000000','0.020590000000000','0.711908500000000','0.719244161678116','34.93172227674191','34.931722276741908','test'),('2018-10-13 15:59:59','2018-10-15 03:59:59','ADXBNB','4h','0.021970000000000','0.020780000000000','0.711908500000000','0.673348139736004','32.4036640873919','32.403664087391903','test'),('2018-10-16 15:59:59','2018-10-22 11:59:59','ADXBNB','4h','0.022330000000000','0.024590000000000','0.711908500000000','0.783960143976713','31.881258396775642','31.881258396775642','test'),('2018-10-29 07:59:59','2018-10-29 15:59:59','ADXBNB','4h','0.024000000000000','0.023030000000000','0.711908500000000','0.683135531458333','29.66285416666667','29.662854166666669','test'),('2018-10-31 19:59:59','2018-11-03 03:59:59','ADXBNB','4h','0.023940000000000','0.023950000000000','0.711908500000000','0.712205871971596','29.737197159565582','29.737197159565582','test'),('2018-11-28 11:59:59','2018-11-30 11:59:59','ADXBNB','4h','0.019500000000000','0.018060000000000','0.711908500000000','0.659336795384615','36.50812820512821','36.508128205128209','test'),('2018-12-01 03:59:59','2018-12-03 03:59:59','ADXBNB','4h','0.026560000000000','0.021580000000000','0.711908500000000','0.578425656250000','26.80378388554217','26.803783885542170','test'),('2018-12-10 23:59:59','2018-12-11 03:59:59','ADXBNB','4h','0.021540000000000','0.019830000000000','0.711908500000000','0.655392087047354','33.0505338904364','33.050533890436398','test'),('2018-12-11 15:59:59','2018-12-11 19:59:59','ADXBNB','4h','0.019590000000000','0.019530000000000','0.711908500000000','0.709728075803982','36.34040326697295','36.340403266972949','test'),('2019-01-03 23:59:59','2019-01-06 07:59:59','ADXBNB','4h','0.018180000000000','0.017480000000000','0.711908500000000','0.684497281628163','39.158883388338836','39.158883388338836','test'),('2019-01-19 23:59:59','2019-01-20 11:59:59','ADXBNB','4h','0.017010000000000','0.015880000000000','0.474605666666667','0.443076895159710','27.90156770527141','27.901567705271411','test'),('2019-01-20 15:59:59','2019-01-20 19:59:59','ADXBNB','4h','0.015900000000000','0.015850000000000','0.525686692578623','0.524033589771772','33.06205613702032','33.062056137020321','test'),('2019-01-20 23:59:59','2019-01-21 03:59:59','ADXBNB','4h','0.016150000000000','0.015760000000000','0.525686692578623','0.512992091333690','32.55025960239151','32.550259602391513','test'),('2019-01-23 03:59:59','2019-01-23 23:59:59','ADXBNB','4h','0.016320000000000','0.016390000000000','0.525686692578623','0.527941476186497','32.211194398199936','32.211194398199936','test'),('2019-01-24 03:59:59','2019-01-24 07:59:59','ADXBNB','4h','0.016410000000000','0.016300000000000','0.525686692578623','0.522162893908078','32.03453336859372','32.034533368593721','test'),('2019-01-24 11:59:59','2019-01-25 07:59:59','ADXBNB','4h','0.016410000000000','0.016140000000000','0.525686692578623','0.517037368569103','32.03453336859372','32.034533368593721','test'),('2019-02-17 15:59:59','2019-02-18 03:59:59','ADXBNB','4h','0.013790000000000','0.012620000000000','0.525686692578623','0.481085283563613','38.12086240599152','38.120862405991517','test'),('2019-02-18 15:59:59','2019-02-18 19:59:59','ADXBNB','4h','0.012850000000000','0.012450000000000','0.525686692578623','0.509322904482790','40.90947023958155','40.909470239581552','test'),('2019-02-18 23:59:59','2019-02-19 03:59:59','ADXBNB','4h','0.012630000000000','0.012180000000000','0.525686692578623','0.506956762914301','41.622065920714405','41.622065920714405','test'),('2019-02-26 11:59:59','2019-02-27 15:59:59','ADXBNB','4h','0.012780000000000','0.011880000000000','0.525686692578623','0.488666502960410','41.13354402023654','41.133544020236542','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','ADXBNB','4h','0.012070000000000','0.011890000000000','0.525686692578623','0.517847123012413','43.55316425672104','43.553164256721040','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','ADXBNB','4h','0.012870000000000','0.012030000000000','0.525686692578623','0.491376139216848','40.845896859255866','40.845896859255866','test'),('2019-03-22 15:59:59','2019-03-22 19:59:59','ADXBNB','4h','0.009740000000000','0.009450000000000','0.525686692578623','0.510034830068582','53.97193968979702','53.971939689797019','test'),('2019-03-23 03:59:59','2019-03-23 07:59:59','ADXBNB','4h','0.009420000000000','0.009260000000000','0.525686692578623','0.516757831558179','55.805381377773145','55.805381377773145','test'),('2019-03-26 23:59:59','2019-03-28 23:59:59','ADXBNB','4h','0.011320000000000','0.009800000000000','0.525686692578623','0.455099786861352','46.438753761362456','46.438753761362456','test'),('2019-03-29 19:59:59','2019-03-30 03:59:59','ADXBNB','4h','0.010070000000000','0.009740000000000','0.525686692578623','0.508459621223018','52.203246532137335','52.203246532137335','test'),('2019-04-07 19:59:59','2019-04-09 07:59:59','ADXBNB','4h','0.009530000000000','0.009310000000000','0.525686692578623','0.513551218038508','55.16124790961416','55.161247909614161','test'),('2019-04-10 15:59:59','2019-04-11 11:59:59','ADXBNB','4h','0.009680000000000','0.009470000000000','0.525686692578623','0.514282332512351','54.3064765060561','54.306476506056100','test'),('2019-04-11 15:59:59','2019-04-11 23:59:59','ADXBNB','4h','0.009600000000000','0.009370000000000','0.525686692578623','0.513092115568927','54.7590304769399','54.759030476939898','test'),('2019-04-12 03:59:59','2019-04-12 07:59:59','ADXBNB','4h','0.009450000000000','0.009540000000000','0.525686692578623','0.530693232507943','55.62822143689132','55.628221436891323','test'),('2019-05-11 03:59:59','2019-05-11 07:59:59','ADXBNB','4h','0.006380000000000','0.006290000000000','0.525686692578623','0.518271049579865','82.39603331953339','82.396033319533387','test'),('2019-05-11 11:59:59','2019-05-11 15:59:59','ADXBNB','4h','0.006510000000000','0.006070000000000','0.525686692578623','0.490156409209254','80.75064402129385','80.750644021293851','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:01:15
