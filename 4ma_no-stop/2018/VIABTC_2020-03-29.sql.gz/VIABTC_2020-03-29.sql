-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-28 19:59:59','2018-07-30 11:59:59','VIABTC','4h','0.000178600000000','0.000166200000000','0.001467500000000','0.001365613101904','8.216685330347145','8.216685330347145','test'),('2018-08-28 15:59:59','2018-08-30 07:59:59','VIABTC','4h','0.000138200000000','0.000131500000000','0.001467500000000','0.001396354920405','10.618668596237338','10.618668596237338','test'),('2018-09-02 07:59:59','2018-09-02 11:59:59','VIABTC','4h','0.000134700000000','0.000130500000000','0.001467500000000','0.001421742761693','10.89458054936897','10.894580549368969','test'),('2018-09-29 11:59:59','2018-09-29 19:59:59','VIABTC','4h','0.000094600000000','0.000094000000000','0.001467500000000','0.001458192389006','15.512684989429177','15.512684989429177','test'),('2018-09-29 23:59:59','2018-09-30 11:59:59','VIABTC','4h','0.000097600000000','0.000094000000000','0.001467500000000','0.001413370901639','15.035860655737705','15.035860655737705','test'),('2018-09-30 19:59:59','2018-10-02 11:59:59','VIABTC','4h','0.000114600000000','0.000097500000000','0.001467500000000','0.001248527486911','12.80541012216405','12.805410122164050','test'),('2018-10-10 23:59:59','2018-10-11 03:59:59','VIABTC','4h','0.000098100000000','0.000095800000000','0.001467500000000','0.001433093781855','14.959225280326198','14.959225280326198','test'),('2018-10-14 07:59:59','2018-10-15 07:59:59','VIABTC','4h','0.000099500000000','0.000096000000000','0.001467500000000','0.001415879396985','14.748743718592964','14.748743718592964','test'),('2018-10-15 15:59:59','2018-10-15 19:59:59','VIABTC','4h','0.000095400000000','0.000095600000000','0.001467500000000','0.001470576519916','15.382599580712789','15.382599580712789','test'),('2018-10-16 07:59:59','2018-10-18 19:59:59','VIABTC','4h','0.000101900000000','0.000097400000000','0.001467500000000','0.001402693817468','14.401373895976448','14.401373895976448','test'),('2018-10-19 15:59:59','2018-10-22 03:59:59','VIABTC','4h','0.000104200000000','0.000101000000000','0.001467500000000','0.001422432821497','14.083493282149712','14.083493282149712','test'),('2018-10-23 11:59:59','2018-10-29 19:59:59','VIABTC','4h','0.000104000000000','0.000113200000000','0.001467500000000','0.001597317307692','14.110576923076925','14.110576923076925','test'),('2018-10-31 03:59:59','2018-11-03 03:59:59','VIABTC','4h','0.000119500000000','0.000124100000000','0.001467500000000','0.001523989539749','12.280334728033473','12.280334728033473','test'),('2018-11-11 23:59:59','2018-11-13 07:59:59','VIABTC','4h','0.000121700000000','0.000119800000000','0.001467500000000','0.001444589153657','12.058340180772392','12.058340180772392','test'),('2018-12-02 15:59:59','2018-12-03 03:59:59','VIABTC','4h','0.000092600000000','0.000084800000000','0.001467500000000','0.001343887688985','15.847732181425487','15.847732181425487','test'),('2018-12-03 11:59:59','2018-12-03 15:59:59','VIABTC','4h','0.000085200000000','0.000084000000000','0.001467500000000','0.001446830985915','17.224178403755868','17.224178403755868','test'),('2018-12-03 19:59:59','2018-12-04 07:59:59','VIABTC','4h','0.000087900000000','0.000085900000000','0.001467500000000','0.001434109783845','16.69510807736064','16.695108077360640','test'),('2018-12-04 11:59:59','2018-12-04 19:59:59','VIABTC','4h','0.000087000000000','0.000086700000000','0.001467500000000','0.001462439655172','16.867816091954023','16.867816091954023','test'),('2018-12-05 03:59:59','2018-12-05 19:59:59','VIABTC','4h','0.000087500000000','0.000085800000000','0.001467500000000','0.001438988571429','16.771428571428572','16.771428571428572','test'),('2018-12-05 23:59:59','2018-12-06 07:59:59','VIABTC','4h','0.000087800000000','0.000086600000000','0.001467500000000','0.001447443052392','16.714123006833713','16.714123006833713','test'),('2018-12-20 15:59:59','2018-12-20 23:59:59','VIABTC','4h','0.000084600000000','0.000081500000000','0.001467500000000','0.001413726359338','17.346335697399528','17.346335697399528','test'),('2018-12-21 03:59:59','2018-12-21 19:59:59','VIABTC','4h','0.000082000000000','0.000081900000000','0.001467500000000','0.001465710365854','17.896341463414636','17.896341463414636','test'),('2018-12-22 03:59:59','2018-12-22 07:59:59','VIABTC','4h','0.000082700000000','0.000082700000000','0.001467500000000','0.001467500000000','17.744860943168078','17.744860943168078','test'),('2018-12-22 11:59:59','2018-12-25 07:59:59','VIABTC','4h','0.000084200000000','0.000083200000000','0.001467500000000','0.001450071258907','17.42874109263658','17.428741092636582','test'),('2019-01-05 23:59:59','2019-01-06 19:59:59','VIABTC','4h','0.000093700000000','0.000082700000000','0.001467500000000','0.001295221451441','15.661686232657418','15.661686232657418','test'),('2019-01-06 23:59:59','2019-01-07 03:59:59','VIABTC','4h','0.000083100000000','0.000083000000000','0.001467500000000','0.001465734055355','17.65944645006017','17.659446450060170','test'),('2019-01-16 11:59:59','2019-01-22 07:59:59','VIABTC','4h','0.000083700000000','0.000085800000000','0.001467500000000','0.001504318996416','17.532855436081242','17.532855436081242','test'),('2019-01-22 15:59:59','2019-01-23 19:59:59','VIABTC','4h','0.000088400000000','0.000085800000000','0.001467500000000','0.001424338235294','16.600678733031675','16.600678733031675','test'),('2019-01-25 15:59:59','2019-01-27 03:59:59','VIABTC','4h','0.000091700000000','0.000087400000000','0.001467500000000','0.001398685932388','16.00327153762268','16.003271537622680','test'),('2019-02-05 11:59:59','2019-02-05 15:59:59','VIABTC','4h','0.000084900000000','0.000083500000000','0.001467500000000','0.001443300942285','17.285041224970552','17.285041224970552','test'),('2019-02-10 03:59:59','2019-02-10 07:59:59','VIABTC','4h','0.000083600000000','0.000083000000000','0.001467500000000','0.001456967703349','17.553827751196174','17.553827751196174','test'),('2019-02-10 11:59:59','2019-02-10 15:59:59','VIABTC','4h','0.000083400000000','0.000083200000000','0.001467500000000','0.001463980815348','17.59592326139089','17.595923261390890','test'),('2019-02-11 19:59:59','2019-02-11 23:59:59','VIABTC','4h','0.000084000000000','0.000083700000000','0.001467500000000','0.001462258928571','17.4702380952381','17.470238095238098','test'),('2019-02-12 03:59:59','2019-02-12 11:59:59','VIABTC','4h','0.000083900000000','0.000083400000000','0.001467500000000','0.001458754469607','17.491060786650774','17.491060786650774','test'),('2019-02-12 15:59:59','2019-02-12 19:59:59','VIABTC','4h','0.000084300000000','0.000084400000000','0.001467500000000','0.001469240806643','17.408066429418742','17.408066429418742','test'),('2019-02-12 23:59:59','2019-02-18 07:59:59','VIABTC','4h','0.000084900000000','0.000086400000000','0.001467500000000','0.001493427561837','17.285041224970552','17.285041224970552','test'),('2019-02-18 11:59:59','2019-02-18 15:59:59','VIABTC','4h','0.000086900000000','0.000085000000000','0.001467500000000','0.001435414269275','16.88722669735328','16.887226697353281','test'),('2019-02-21 15:59:59','2019-02-23 23:59:59','VIABTC','4h','0.000087100000000','0.000087200000000','0.001467500000000','0.001469184845006','16.84845005740528','16.848450057405280','test'),('2019-02-26 19:59:59','2019-02-27 23:59:59','VIABTC','4h','0.000089300000000','0.000087600000000','0.001467500000000','0.001439563269877','16.43337066069429','16.433370660694290','test'),('2019-03-01 19:59:59','2019-03-02 07:59:59','VIABTC','4h','0.000088800000000','0.000088100000000','0.001467500000000','0.001455931869369','16.5259009009009','16.525900900900901','test'),('2019-03-02 11:59:59','2019-03-04 07:59:59','VIABTC','4h','0.000088300000000','0.000088400000000','0.001467500000000','0.001469161947905','16.61947904869762','16.619479048697620','test'),('2019-03-04 23:59:59','2019-03-05 19:59:59','VIABTC','4h','0.000092300000000','0.000090800000000','0.001467500000000','0.001443651137595','15.899241603466956','15.899241603466956','test'),('2019-03-06 07:59:59','2019-03-09 03:59:59','VIABTC','4h','0.000091000000000','0.000092500000000','0.001467500000000','0.001491689560440','16.126373626373628','16.126373626373628','test'),('2019-03-09 07:59:59','2019-03-11 23:59:59','VIABTC','4h','0.000093700000000','0.000198000000000','0.001467500000000','0.003101013874066','15.661686232657418','15.661686232657418','test'),('2019-03-12 11:59:59','2019-03-12 19:59:59','VIABTC','4h','0.000174300000000','0.000132600000000','0.001581730573570','0.001203313104162','9.074759458234363','9.074759458234363','test'),('2019-03-12 23:59:59','2019-03-14 07:59:59','VIABTC','4h','0.000133300000000','0.000112900000000','0.001581730573570','0.001339665279490','11.865945788222056','11.865945788222056','test'),('2019-03-14 19:59:59','2019-03-16 23:59:59','VIABTC','4h','0.000132300000000','0.000123000000000','0.001581730573570','0.001470543163637','11.955635476719578','11.955635476719578','test'),('2019-03-21 07:59:59','2019-03-21 15:59:59','VIABTC','4h','0.000122800000000','0.000120600000000','0.001581730573570','0.001553393380884','12.880542130048859','12.880542130048859','test'),('2019-03-21 23:59:59','2019-03-25 19:59:59','VIABTC','4h','0.000121300000000','0.000127500000000','0.001581730573570','0.001662577478402','13.03982336001649','13.039823360016490','test'),('2019-03-25 23:59:59','2019-03-26 03:59:59','VIABTC','4h','0.000128000000000','0.000127300000000','0.001581730573570','0.001573080484496','12.357270106015626','12.357270106015626','test'),('2019-03-27 11:59:59','2019-03-28 19:59:59','VIABTC','4h','0.000133900000000','0.000130600000000','0.001581730573570','0.001542748416044','11.812775007991037','11.812775007991037','test'),('2019-03-28 23:59:59','2019-03-29 15:59:59','VIABTC','4h','0.000131600000000','0.000129200000000','0.001581730573570','0.001552884423292','12.019229282446808','12.019229282446808','test'),('2019-03-30 11:59:59','2019-04-02 07:59:59','VIABTC','4h','0.000145000000000','0.000131800000000','0.001581730573570','0.001437738548942','10.908486714275861','10.908486714275861','test'),('2019-05-02 19:59:59','2019-05-08 03:59:59','VIABTC','4h','0.000099600000000','0.000103500000000','0.001581730573570','0.001643665806872','15.880829051907632','15.880829051907632','test'),('2019-05-09 03:59:59','2019-05-10 03:59:59','VIABTC','4h','0.000106200000000','0.000097700000000','0.001581730573570','0.001455132552145','14.89388487354049','14.893884873540490','test'),('2019-05-22 07:59:59','2019-05-22 11:59:59','VIABTC','4h','0.000096800000000','0.000092700000000','0.001581730573570','0.001514735786880','16.340191875723143','16.340191875723143','test'),('2019-06-10 15:59:59','2019-06-11 11:59:59','VIABTC','4h','0.000075700000000','0.000071400000000','0.001581730573570','0.001491883262258','20.894723561030386','20.894723561030386','test'),('2019-06-11 15:59:59','2019-06-12 11:59:59','VIABTC','4h','0.000072200000000','0.000071300000000','0.001581730573570','0.001562013710465','21.90762567271468','21.907625672714680','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 13:46:18
