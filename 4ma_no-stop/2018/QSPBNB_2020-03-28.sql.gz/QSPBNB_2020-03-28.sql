-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-08 19:59:59','2018-05-08 23:59:59','QSPBNB','4h','0.016560000000000','0.016280000000000','0.711908500000000','0.699871399758454','42.98964371980677','42.989643719806772','test'),('2018-05-20 03:59:59','2018-05-21 19:59:59','QSPBNB','4h','0.015810000000000','0.015360000000000','0.711908500000000','0.691645449715370','45.02900063251107','45.029000632511071','test'),('2018-07-01 23:59:59','2018-07-05 19:59:59','QSPBNB','4h','0.005361000000000','0.005337000000000','0.711908500000000','0.708721444599888','132.7939750046633','132.793975004663309','test'),('2018-07-08 03:59:59','2018-07-10 03:59:59','QSPBNB','4h','0.006031000000000','0.005312000000000','0.711908500000000','0.627036636047090','118.04153540043112','118.041535400431115','test'),('2018-07-17 03:59:59','2018-07-17 11:59:59','QSPBNB','4h','0.005648000000000','0.005600000000000','0.711908500000000','0.705858286118980','126.04612252124646','126.046122521246460','test'),('2018-07-17 19:59:59','2018-07-20 03:59:59','QSPBNB','4h','0.005777000000000','0.005640000000000','0.711908500000000','0.695025781547516','123.23152155097803','123.231521550978030','test'),('2018-07-21 23:59:59','2018-07-23 11:59:59','QSPBNB','4h','0.005904000000000','0.005801000000000','0.711908500000000','0.699488687076558','120.58070799457995','120.580707994579953','test'),('2018-08-17 15:59:59','2018-08-18 15:59:59','QSPBNB','4h','0.003753000000000','0.003604000000000','0.711908500000000','0.683644613375966','189.69051425526249','189.690514255262485','test'),('2018-08-18 23:59:59','2018-08-19 11:59:59','QSPBNB','4h','0.003689000000000','0.003532000000000','0.711908500000000','0.681610415288696','192.9814312821903','192.981431282190300','test'),('2018-08-21 11:59:59','2018-08-22 19:59:59','QSPBNB','4h','0.003843000000000','0.003618000000000','0.711908500000000','0.670227674473068','185.2481134530315','185.248113453031493','test'),('2018-08-23 23:59:59','2018-08-27 19:59:59','QSPBNB','4h','0.003779000000000','0.003933000000000','0.711908500000000','0.740919854591162','188.38541942312784','188.385419423127843','test'),('2018-08-27 23:59:59','2018-08-28 23:59:59','QSPBNB','4h','0.003954000000000','0.003928000000000','0.711908500000000','0.707227260495701','180.0476732422863','180.047673242286294','test'),('2018-09-02 03:59:59','2018-09-02 07:59:59','QSPBNB','4h','0.004031000000000','0.003994000000000','0.711908500000000','0.705373988836517','176.60840982386506','176.608409823865060','test'),('2018-09-02 15:59:59','2018-09-02 19:59:59','QSPBNB','4h','0.003935000000000','0.003960000000000','0.711908500000000','0.716431425667090','180.91702668360864','180.917026683608640','test'),('2018-09-18 15:59:59','2018-09-22 15:59:59','QSPBNB','4h','0.003455000000000','0.003417000000000','0.711908500000000','0.704078536758321','206.05166425470333','206.051664254703326','test'),('2018-09-26 15:59:59','2018-09-30 23:59:59','QSPBNB','4h','0.003679000000000','0.003650000000000','0.711908500000000','0.706296826583311','193.50597988583857','193.505979885838570','test'),('2018-10-01 03:59:59','2018-10-01 11:59:59','QSPBNB','4h','0.003719000000000','0.003575000000000','0.711908500000000','0.684343341624093','191.4247109438021','191.424710943802097','test'),('2018-10-02 07:59:59','2018-10-02 23:59:59','QSPBNB','4h','0.003887000000000','0.003678000000000','0.711908500000000','0.673629910728068','183.1511448417803','183.151144841780308','test'),('2018-10-06 15:59:59','2018-10-06 19:59:59','QSPBNB','4h','0.003693000000000','0.003666000000000','0.711908500000000','0.706703645004062','192.77240725697266','192.772407256972656','test'),('2018-10-07 03:59:59','2018-10-07 15:59:59','QSPBNB','4h','0.003650000000000','0.003600000000000','0.711908500000000','0.702156328767123','195.04342465753427','195.043424657534274','test'),('2018-10-07 19:59:59','2018-10-07 23:59:59','QSPBNB','4h','0.003601000000000','0.003569000000000','0.711908500000000','0.705582181755068','197.69744515412387','197.697445154123869','test'),('2018-10-08 19:59:59','2018-10-09 03:59:59','QSPBNB','4h','0.003700000000000','0.003650000000000','0.711908500000000','0.702288114864865','192.40770270270272','192.407702702702721','test'),('2018-10-09 07:59:59','2018-10-10 03:59:59','QSPBNB','4h','0.003682000000000','0.003729000000000','0.711908500000000','0.720995870858229','193.3483161325367','193.348316132536695','test'),('2018-10-10 11:59:59','2018-10-10 15:59:59','QSPBNB','4h','0.003662000000000','0.003800000000000','0.711908500000000','0.738736291643911','194.40428727471328','194.404287274713283','test'),('2018-10-10 19:59:59','2018-10-11 03:59:59','QSPBNB','4h','0.003854000000000','0.003531000000000','0.711908500000000','0.652244139465490','184.71938245978208','184.719382459782082','test'),('2018-10-15 03:59:59','2018-10-18 03:59:59','QSPBNB','4h','0.004665000000000','0.004271000000000','0.711908500000000','0.651781608467310','152.6063236870311','152.606323687031107','test'),('2018-10-19 23:59:59','2018-10-21 15:59:59','QSPBNB','4h','0.004336000000000','0.004235000000000','0.711908500000000','0.695325760493543','164.1855396678967','164.185539667896705','test'),('2018-10-22 23:59:59','2018-10-23 15:59:59','QSPBNB','4h','0.004386000000000','0.004284000000000','0.711908500000000','0.695352488372093','162.3138394892841','162.313839489284106','test'),('2018-10-23 19:59:59','2018-10-23 23:59:59','QSPBNB','4h','0.004303000000000','0.004332000000000','0.711908500000000','0.716706396002789','165.44468975133628','165.444689751336284','test'),('2018-10-24 11:59:59','2018-10-27 11:59:59','QSPBNB','4h','0.004357000000000','0.004446000000000','0.711908500000000','0.726450583199449','163.3941932522378','163.394193252237812','test'),('2018-10-29 11:59:59','2018-10-29 15:59:59','QSPBNB','4h','0.004678000000000','0.004875000000000','0.711908500000000','0.741888400491663','152.18223599828988','152.182235998289883','test'),('2018-10-30 03:59:59','2018-10-31 15:59:59','QSPBNB','4h','0.004697000000000','0.004618000000000','0.711908500000000','0.699934735575900','151.56663827975305','151.566638279753050','test'),('2018-10-31 19:59:59','2018-11-01 07:59:59','QSPBNB','4h','0.004672000000000','0.004535000000000','0.711908500000000','0.691032758454623','152.37767551369865','152.377675513698648','test'),('2018-11-01 23:59:59','2018-11-04 11:59:59','QSPBNB','4h','0.004730000000000','0.004587000000000','0.711908500000000','0.690385684883721','150.50919661733616','150.509196617336158','test'),('2018-11-29 11:59:59','2018-11-30 11:59:59','QSPBNB','4h','0.003707000000000','0.003568000000000','0.711908500000000','0.685214331804694','192.04437550579988','192.044375505799877','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','QSPBNB','4h','0.003505000000000','0.003593000000000','0.711908500000000','0.729782379600571','203.11226818830244','203.112268188302437','test'),('2018-12-01 03:59:59','2018-12-01 07:59:59','QSPBNB','4h','0.003696000000000','0.003505000000000','0.711908500000000','0.675118856195887','192.61593614718615','192.615936147186147','test'),('2018-12-01 11:59:59','2018-12-02 07:59:59','QSPBNB','4h','0.003741000000000','0.003610000000000','0.711908500000000','0.686979333066025','190.29898422881584','190.298984228815840','test'),('2019-01-04 11:59:59','2019-01-05 07:59:59','QSPBNB','4h','0.002732000000000','0.002610000000000','0.711908500000000','0.680117564055637','260.5814421669107','260.581442166910676','test'),('2019-01-05 11:59:59','2019-01-05 15:59:59','QSPBNB','4h','0.002650000000000','0.002574000000000','0.711908500000000','0.691491501509434','268.6447169811321','268.644716981132092','test'),('2019-01-05 19:59:59','2019-01-05 23:59:59','QSPBNB','4h','0.002637000000000','0.002614000000000','0.711908500000000','0.705699210845658','269.9690936670459','269.969093667045911','test'),('2019-01-06 15:59:59','2019-01-06 23:59:59','QSPBNB','4h','0.002666000000000','0.002655000000000','0.711908500000000','0.708971143098275','267.03244561140286','267.032445611402864','test'),('2019-01-07 19:59:59','2019-01-07 23:59:59','QSPBNB','4h','0.002748000000000','0.002605000000000','0.711908500000000','0.674862315320233','259.0642285298399','259.064228529839909','test'),('2019-01-19 11:59:59','2019-01-20 11:59:59','QSPBNB','4h','0.002687000000000','0.002529000000000','0.711908500000000','0.670047114439896','264.9454782285076','264.945478228507625','test'),('2019-01-20 15:59:59','2019-01-20 19:59:59','QSPBNB','4h','0.002585000000000','0.002503000000000','0.711908500000000','0.689325715860735','275.39980657640234','275.399806576402341','test'),('2019-01-20 23:59:59','2019-01-21 07:59:59','QSPBNB','4h','0.002609000000000','0.002540000000000','0.711908500000000','0.693080716749712','272.86642391720966','272.866423917209659','test'),('2019-01-21 11:59:59','2019-01-21 15:59:59','QSPBNB','4h','0.002711000000000','0.002640000000000','0.474605666666667','0.462175935079307','175.0666420754949','175.066642075494912','test'),('2019-01-22 23:59:59','2019-01-23 15:59:59','QSPBNB','4h','0.002623000000000','0.002637000000000','0.529274993136271','0.532099945444280','201.78230771493355','201.782307714933552','test'),('2019-02-26 19:59:59','2019-02-28 11:59:59','QSPBNB','4h','0.001688000000000','0.001547000000000','0.529981231213273','0.485711471970932','313.9699237045455','313.969923704545522','test'),('2019-03-16 23:59:59','2019-03-21 15:59:59','QSPBNB','4h','0.001338000000000','0.001399000000000','0.529981231213273','0.554143305282040','396.09957489781243','396.099574897812431','test'),('2019-03-21 23:59:59','2019-03-22 11:59:59','QSPBNB','4h','0.001416000000000','0.001399000000000','0.529981231213273','0.523618462194470','374.2805305178482','374.280530517848206','test'),('2019-03-27 23:59:59','2019-03-31 03:59:59','QSPBNB','4h','0.001399000000000','0.001422000000000','0.529981231213273','0.538694289339010','378.8286141624539','378.828614162453903','test'),('2019-04-03 19:59:59','2019-04-04 03:59:59','QSPBNB','4h','0.001511000000000','0.001435000000000','0.529981231213273','0.503324332753836','350.7486639399557','350.748663939955691','test'),('2019-04-04 07:59:59','2019-04-09 11:59:59','QSPBNB','4h','0.001492000000000','0.001531000000000','0.529981231213273','0.543834628007722','355.21530242176476','355.215302421764761','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 13:01:26
