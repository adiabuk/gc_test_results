-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-28 11:59:59','2018-05-03 23:59:59','AMBETH','4h','0.000977030000000','0.001062340000000','0.072144500000000','0.078443843208499','73.8406190188633','73.840619018863293','test'),('2018-05-04 03:59:59','2018-05-04 15:59:59','AMBETH','4h','0.001155820000000','0.001050850000000','0.073719335802125','0.067024246013794','63.78098302687681','63.780983026876811','test'),('2018-05-31 19:59:59','2018-06-04 03:59:59','AMBETH','4h','0.000692370000000','0.000684640000000','0.073719335802125','0.072896292536602','106.47390239629823','106.473902396298229','test'),('2018-06-28 19:59:59','2018-07-04 11:59:59','AMBETH','4h','0.000644130000000','0.000660940000000','0.073719335802125','0.075643205261448','114.44791548619844','114.447915486198440','test'),('2018-07-05 07:59:59','2018-07-06 11:59:59','AMBETH','4h','0.000692010000000','0.000675720000000','0.073719335802125','0.071983973624965','106.52929264335054','106.529292643350544','test'),('2018-07-07 07:59:59','2018-07-08 15:59:59','AMBETH','4h','0.000694840000000','0.000679740000000','0.073719335802125','0.072117295086835','106.09541160860775','106.095411608607748','test'),('2018-07-08 19:59:59','2018-07-08 23:59:59','AMBETH','4h','0.000681890000000','0.000670020000000','0.073719335802125','0.072436066483069','108.11030489100149','108.110304891001491','test'),('2018-07-09 19:59:59','2018-07-10 03:59:59','AMBETH','4h','0.000725430000000','0.000695750000000','0.073719335802125','0.070703207593191','101.62157038187696','101.621570381876964','test'),('2018-07-18 19:59:59','2018-07-19 03:59:59','AMBETH','4h','0.000688940000000','0.000667210000000','0.073719335802125','0.071394138880796','107.00400006114467','107.004000061144666','test'),('2018-07-19 07:59:59','2018-07-19 11:59:59','AMBETH','4h','0.000667490000000','0.000654450000000','0.073719335802125','0.072279164205757','110.44260708343946','110.442607083439455','test'),('2018-08-18 23:59:59','2018-08-19 03:59:59','AMBETH','4h','0.000458050000000','0.000426500000000','0.073719335802125','0.068641625847847','160.94167842402578','160.941678424025781','test'),('2018-08-19 11:59:59','2018-08-21 03:59:59','AMBETH','4h','0.000435100000000','0.000438780000000','0.073719335802125','0.074342841101486','169.4307878697426','169.430787869742602','test'),('2018-08-21 07:59:59','2018-08-22 07:59:59','AMBETH','4h','0.000448590000000','0.000444400000000','0.073719335802125','0.073030769367272','164.3356646428253','164.335664642825293','test'),('2018-08-23 15:59:59','2018-09-02 15:59:59','AMBETH','4h','0.000460990000000','0.000580000000000','0.073719335802125','0.092750850919179','159.9152602054817','159.915260205481701','test'),('2018-09-03 15:59:59','2018-09-05 23:59:59','AMBETH','4h','0.000623700000000','0.000589050000000','0.073719335802125','0.069623817146451','118.19678659952702','118.196786599527016','test'),('2018-09-06 15:59:59','2018-09-09 15:59:59','AMBETH','4h','0.000617050000000','0.000641070000000','0.073719335802125','0.076589019694787','119.47060335811524','119.470603358115241','test'),('2018-09-19 23:59:59','2018-09-20 23:59:59','AMBETH','4h','0.000619500000000','0.000588320000000','0.073719335802125','0.070008974397266','118.99812074596448','118.998120745964485','test'),('2018-09-21 03:59:59','2018-09-21 15:59:59','AMBETH','4h','0.000608210000000','0.000589940000000','0.073719335802125','0.071504883121135','121.20704329446245','121.207043294462451','test'),('2018-09-23 03:59:59','2018-09-23 11:59:59','AMBETH','4h','0.000617580000000','0.000600880000000','0.073719335802125','0.071725888948445','119.36807507063864','119.368075070638639','test'),('2018-09-23 15:59:59','2018-09-25 23:59:59','AMBETH','4h','0.000640000000000','0.000630460000000','0.073719335802125','0.072620456952825','115.18646219082031','115.186462190820308','test'),('2018-09-26 03:59:59','2018-09-27 19:59:59','AMBETH','4h','0.000646730000000','0.000615030000000','0.073719335802125','0.070105922252533','113.98780913538108','113.987809135381085','test'),('2018-09-28 19:59:59','2018-09-29 15:59:59','AMBETH','4h','0.000670090000000','0.000659870000000','0.073719335802125','0.072594991890266','110.01408139522303','110.014081395223030','test'),('2018-09-30 03:59:59','2018-09-30 11:59:59','AMBETH','4h','0.000652320000000','0.000634570000000','0.073719335802125','0.071713390544448','113.0110004324948','113.011000432494797','test'),('2018-10-05 19:59:59','2018-10-06 11:59:59','AMBETH','4h','0.000662390000000','0.000642930000000','0.073719335802125','0.071553575034738','111.292947964379','111.292947964378996','test'),('2018-10-06 19:59:59','2018-10-07 11:59:59','AMBETH','4h','0.000643760000000','0.000651700000000','0.073719335802125','0.074628574534368','114.5136942371769','114.513694237176907','test'),('2018-10-07 15:59:59','2018-10-13 11:59:59','AMBETH','4h','0.000653480000000','0.000765510000000','0.073719335802125','0.086357484161542','112.81039328231162','112.810393282311622','test'),('2018-10-14 03:59:59','2018-10-15 07:59:59','AMBETH','4h','0.000802180000000','0.000790330000000','0.073719335802125','0.072630335665927','91.89874567070359','91.898745670703590','test'),('2018-10-15 15:59:59','2018-10-16 07:59:59','AMBETH','4h','0.000816020000000','0.000794230000000','0.073719335802125','0.071750824825521','90.34010906855838','90.340109068558377','test'),('2018-10-16 19:59:59','2018-10-22 15:59:59','AMBETH','4h','0.000806550000000','0.000940000000000','0.073719335802125','0.085916775964289','91.40082549392474','91.400825493924742','test'),('2018-10-22 19:59:59','2018-10-24 11:59:59','AMBETH','4h','0.001026490000000','0.000967280000000','0.073826133201445','0.069567693911381','71.92094730727551','71.920947307275512','test'),('2018-10-31 11:59:59','2018-11-01 15:59:59','AMBETH','4h','0.001018890000000','0.000954890000000','0.073826133201445','0.069188858790181','72.45741267599546','72.457412675995457','test'),('2018-11-12 15:59:59','2018-11-14 01:59:59','AMBETH','4h','0.000943440000000','0.000912070000000','0.073826133201445','0.071371365756213','78.2520702974699','78.252070297469899','test'),('2018-11-30 15:59:59','2018-11-30 19:59:59','AMBETH','4h','0.000695000000000','0.000697310000000','0.073826133201445','0.074071512147769','106.22465208841008','106.224652088410082','test'),('2018-11-30 23:59:59','2018-12-01 03:59:59','AMBETH','4h','0.000705280000000','0.000709180000000','0.073826133201445','0.074234370950262','104.6763458505062','104.676345850506195','test'),('2018-12-01 07:59:59','2018-12-02 07:59:59','AMBETH','4h','0.000732950000000','0.000710590000000','0.073826133201445','0.071573929997428','100.72465134244491','100.724651342444915','test'),('2018-12-04 23:59:59','2018-12-05 15:59:59','AMBETH','4h','0.000731090000000','0.000692490000000','0.073826133201445','0.069928270090780','100.98090960270966','100.980909602709659','test'),('2018-12-15 23:59:59','2018-12-16 15:59:59','AMBETH','4h','0.000674680000000','0.000645350000000','0.073826133201445','0.070616729503694','109.42392423288818','109.423924232888183','test'),('2018-12-16 19:59:59','2018-12-16 23:59:59','AMBETH','4h','0.000648270000000','0.000650660000000','0.073826133201445','0.074098310624974','113.88176716714486','113.881767167144858','test'),('2018-12-17 03:59:59','2018-12-18 23:59:59','AMBETH','4h','0.000654750000000','0.000655380000000','0.073826133201445','0.073897168656072','112.75468988384117','112.754689883841166','test'),('2018-12-19 03:59:59','2018-12-19 07:59:59','AMBETH','4h','0.000655840000000','0.000649970000000','0.073826133201445','0.073165363193680','112.56729263455264','112.567292634552643','test'),('2019-01-09 19:59:59','2019-01-14 15:59:59','AMBETH','4h','0.000508640000000','0.000507000000000','0.073826133201445','0.073588096754350','145.14417505788967','145.144175057889669','test'),('2019-01-15 19:59:59','2019-01-20 11:59:59','AMBETH','4h','0.000540790000000','0.000552230000000','0.073826133201445','0.075387868743568','136.51534459114444','136.515344591144441','test'),('2019-01-22 15:59:59','2019-01-23 19:59:59','AMBETH','4h','0.000579710000000','0.000560410000000','0.073826133201445','0.071368276047372','127.35011161002053','127.350111610020534','test'),('2019-01-25 03:59:59','2019-01-27 07:59:59','AMBETH','4h','0.000593440000000','0.000579780000000','0.073826133201445','0.072126778625529','124.40370248288791','124.403702482887908','test'),('2019-03-02 07:59:59','2019-03-05 19:59:59','AMBETH','4h','0.000399790000000','0.000401440000000','0.073826133201445','0.074130825964602','184.66228070098052','184.662280700980517','test'),('2019-03-09 03:59:59','2019-03-10 07:59:59','AMBETH','4h','0.000415440000000','0.000398430000000','0.073826133201445','0.070803356083795','177.70588581129647','177.705885811296469','test'),('2019-03-10 11:59:59','2019-03-11 07:59:59','AMBETH','4h','0.000409080000000','0.000403410000000','0.073826133201445','0.072802875708406','180.46869365758533','180.468693657585334','test'),('2019-03-11 15:59:59','2019-03-11 19:59:59','AMBETH','4h','0.000411980000000','0.000406160000000','0.073826133201445','0.072783198847271','179.19834264149958','179.198342641499579','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','AMBETH','4h','0.000417270000000','0.000408690000000','0.073826133201445','0.072308103573462','176.92653006792963','176.926530067929633','test'),('2019-03-12 11:59:59','2019-03-16 07:59:59','AMBETH','4h','0.000424500000000','0.000432230000000','0.073826133201445','0.075170481869636','173.91315241800942','173.913152418009417','test'),('2019-03-21 03:59:59','2019-03-21 15:59:59','AMBETH','4h','0.000433940000000','0.000407180000000','0.073826133201445','0.069273459273089','170.12981795051158','170.129817950511580','test'),('2019-03-26 19:59:59','2019-04-02 07:59:59','AMBETH','4h','0.000429080000000','0.000469970000000','0.073826133201445','0.080861535892335','172.0568033966743','172.056803396674297','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 23:40:36
