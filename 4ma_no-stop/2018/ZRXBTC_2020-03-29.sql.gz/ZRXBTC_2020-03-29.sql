-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-22 11:59:59','2018-03-23 03:59:59','ZRXBTC','4h','0.000071730000000','0.000062200000000','0.001467500000000','0.001272528927924','20.458664436079744','20.458664436079744','test'),('2018-03-23 11:59:59','2018-03-23 15:59:59','ZRXBTC','4h','0.000064510000000','0.000064360000000','0.001467500000000','0.001464087738335','22.748411099054408','22.748411099054408','test'),('2018-03-24 15:59:59','2018-03-26 15:59:59','ZRXBTC','4h','0.000066070000000','0.000065000000000','0.001467500000000','0.001443733918571','22.211291054941732','22.211291054941732','test'),('2018-03-26 19:59:59','2018-03-29 11:59:59','ZRXBTC','4h','0.000093190000000','0.000073290000000','0.001467500000000','0.001154126783990','15.74739778946239','15.747397789462390','test'),('2018-03-31 19:59:59','2018-04-01 15:59:59','ZRXBTC','4h','0.000079520000000','0.000073480000000','0.001467500000000','0.001356034959759','18.454476861167002','18.454476861167002','test'),('2018-04-03 11:59:59','2018-04-04 11:59:59','ZRXBTC','4h','0.000081370000000','0.000075100000000','0.001467500000000','0.001354421162591','18.034902298144278','18.034902298144278','test'),('2018-04-05 19:59:59','2018-04-06 07:59:59','ZRXBTC','4h','0.000099400000000','0.000077640000000','0.001467500000000','0.001146244466801','14.763581488933601','14.763581488933601','test'),('2018-04-06 11:59:59','2018-04-06 15:59:59','ZRXBTC','4h','0.000077750000000','0.000078450000000','0.001467500000000','0.001480712218650','18.874598070739548','18.874598070739548','test'),('2018-04-08 11:59:59','2018-04-21 07:59:59','ZRXBTC','4h','0.000080010000000','0.000104710000000','0.001467500000000','0.001920533995751','18.34145731783527','18.341457317835271','test'),('2018-04-22 15:59:59','2018-04-25 07:59:59','ZRXBTC','4h','0.000113350000000','0.000112640000000','0.001467500000000','0.001458307895898','12.946625496250551','12.946625496250551','test'),('2018-04-26 03:59:59','2018-05-01 07:59:59','ZRXBTC','4h','0.000118990000000','0.000127580000000','0.001467500000000','0.001573440205059','12.332969157072023','12.332969157072023','test'),('2018-05-01 11:59:59','2018-05-01 15:59:59','ZRXBTC','4h','0.000130080000000','0.000127680000000','0.001467500000000','0.001440424354244','11.281519065190652','11.281519065190652','test'),('2018-05-01 23:59:59','2018-05-06 11:59:59','ZRXBTC','4h','0.000132640000000','0.000151990000000','0.001467500000000','0.001681584175211','11.063781664656213','11.063781664656213','test'),('2018-05-06 23:59:59','2018-05-13 03:59:59','ZRXBTC','4h','0.000166890000000','0.000193740000000','0.001467500000000','0.001703597878842','8.793217089100606','8.793217089100606','test'),('2018-05-13 23:59:59','2018-05-14 07:59:59','ZRXBTC','4h','0.000201610000000','0.000192640000000','0.001467500000000','0.001402208223798','7.278904816229354','7.278904816229354','test'),('2018-05-14 11:59:59','2018-05-14 15:59:59','ZRXBTC','4h','0.000195830000000','0.000190590000000','0.001467500000000','0.001428232778430','7.493744574375734','7.493744574375734','test'),('2018-05-25 11:59:59','2018-05-26 07:59:59','ZRXBTC','4h','0.000181660000000','0.000171000000000','0.001467500000000','0.001381385555433','8.078278101948696','8.078278101948696','test'),('2018-05-26 11:59:59','2018-05-26 15:59:59','ZRXBTC','4h','0.000172640000000','0.000167890000000','0.001467500000000','0.001427123349166','8.500347544022244','8.500347544022244','test'),('2018-05-30 23:59:59','2018-05-31 03:59:59','ZRXBTC','4h','0.000166610000000','0.000164770000000','0.001467500000000','0.001451293289719','8.80799471820419','8.807994718204190','test'),('2018-05-31 07:59:59','2018-06-01 15:59:59','ZRXBTC','4h','0.000174250000000','0.000167720000000','0.001467500000000','0.001412505595409','8.42180774748924','8.421807747489240','test'),('2018-06-01 19:59:59','2018-06-01 23:59:59','ZRXBTC','4h','0.000168390000000','0.000167050000000','0.001467500000000','0.001455822050003','8.714888057485599','8.714888057485599','test'),('2018-06-02 03:59:59','2018-06-02 11:59:59','ZRXBTC','4h','0.000171950000000','0.000165990000000','0.001467500000000','0.001416634632161','8.5344576911893','8.534457691189299','test'),('2018-06-03 11:59:59','2018-06-04 07:59:59','ZRXBTC','4h','0.000170710000000','0.000168280000000','0.001467500000000','0.001446610626208','8.596450120086697','8.596450120086697','test'),('2018-06-06 23:59:59','2018-06-07 23:59:59','ZRXBTC','4h','0.000175000000000','0.000169000000000','0.001467500000000','0.001417185714286','8.385714285714286','8.385714285714286','test'),('2018-06-08 03:59:59','2018-06-08 07:59:59','ZRXBTC','4h','0.000169950000000','0.000167670000000','0.001467500000000','0.001447812444837','8.63489261547514','8.634892615475140','test'),('2018-07-01 23:59:59','2018-07-07 15:59:59','ZRXBTC','4h','0.000125940000000','0.000142290000000','0.001467500000000','0.001658016317294','11.65237414641893','11.652374146418930','test'),('2018-07-14 11:59:59','2018-07-18 23:59:59','ZRXBTC','4h','0.000153020000000','0.000163810000000','0.001467500000000','0.001570978793622','9.59024964056986','9.590249640569860','test'),('2018-08-10 15:59:59','2018-08-10 19:59:59','ZRXBTC','4h','0.000139380000000','0.000137780000000','0.001467500000000','0.001450653967571','10.528770268331181','10.528770268331181','test'),('2018-08-10 23:59:59','2018-08-11 07:59:59','ZRXBTC','4h','0.000140730000000','0.000135420000000','0.001467500000000','0.001412128544020','10.427769487671428','10.427769487671428','test'),('2018-08-11 11:59:59','2018-08-11 15:59:59','ZRXBTC','4h','0.000138920000000','0.000137490000000','0.001467500000000','0.001452394003743','10.563633746040887','10.563633746040887','test'),('2018-08-12 15:59:59','2018-08-12 19:59:59','ZRXBTC','4h','0.000138710000000','0.000136830000000','0.001467500000000','0.001447610302069','10.579626559008002','10.579626559008002','test'),('2018-08-29 07:59:59','2018-08-29 15:59:59','ZRXBTC','4h','0.000114330000000','0.000112290000000','0.001467500000000','0.001441315271582','12.83565118516575','12.835651185165750','test'),('2018-08-29 19:59:59','2018-08-30 07:59:59','ZRXBTC','4h','0.000114230000000','0.000111510000000','0.001467500000000','0.001432556465027','12.846887857830694','12.846887857830694','test'),('2018-09-02 03:59:59','2018-09-02 11:59:59','ZRXBTC','4h','0.000113170000000','0.000108790000000','0.001467500000000','0.001410703587523','12.967217460457718','12.967217460457718','test'),('2018-09-21 19:59:59','2018-09-28 23:59:59','ZRXBTC','4h','0.000095250000000','0.000098280000000','0.001467500000000','0.001514182677165','15.406824146981629','15.406824146981629','test'),('2018-10-06 03:59:59','2018-10-06 15:59:59','ZRXBTC','4h','0.000098280000000','0.000096690000000','0.001467500000000','0.001443758394383','14.931827431827433','14.931827431827433','test'),('2018-10-06 19:59:59','2018-10-11 07:59:59','ZRXBTC','4h','0.000096750000000','0.000105040000000','0.001467500000000','0.001593242377261','15.16795865633075','15.167958656330750','test'),('2018-10-11 19:59:59','2018-10-13 23:59:59','ZRXBTC','4h','0.000129550000000','0.000116570000000','0.001467500000000','0.001320466808182','11.327672713238131','11.327672713238131','test'),('2018-10-14 07:59:59','2018-10-14 15:59:59','ZRXBTC','4h','0.000120750000000','0.000116920000000','0.001467500000000','0.001420953209110','12.15320910973085','12.153209109730851','test'),('2018-10-16 19:59:59','2018-10-21 19:59:59','ZRXBTC','4h','0.000129300000000','0.000136070000000','0.001467500000000','0.001544336620263','11.349574632637278','11.349574632637278','test'),('2018-10-22 19:59:59','2018-10-23 19:59:59','ZRXBTC','4h','0.000139140000000','0.000137080000000','0.001467500000000','0.001445773321834','10.546931148483543','10.546931148483543','test'),('2018-11-29 07:59:59','2018-11-29 23:59:59','ZRXBTC','4h','0.000103760000000','0.000102350000000','0.001467500000000','0.001447558066692','14.143215111796454','14.143215111796454','test'),('2018-11-30 15:59:59','2018-11-30 23:59:59','ZRXBTC','4h','0.000098570000000','0.000097230000000','0.001467500000000','0.001447550218119','14.887896926042407','14.887896926042407','test'),('2018-12-01 11:59:59','2018-12-02 11:59:59','ZRXBTC','4h','0.000101520000000','0.000098090000000','0.001467500000000','0.001417918390465','14.45527974783294','14.455279747832940','test'),('2018-12-24 15:59:59','2018-12-25 03:59:59','ZRXBTC','4h','0.000088890000000','0.000085780000000','0.001467500000000','0.001416156485544','16.509168635392058','16.509168635392058','test'),('2018-12-25 07:59:59','2018-12-25 11:59:59','ZRXBTC','4h','0.000085800000000','0.000085510000000','0.001467500000000','0.001462539918415','17.103729603729604','17.103729603729604','test'),('2018-12-26 03:59:59','2018-12-26 11:59:59','ZRXBTC','4h','0.000086750000000','0.000085710000000','0.001467500000000','0.001449906916427','16.9164265129683','16.916426512968300','test'),('2018-12-26 15:59:59','2018-12-26 19:59:59','ZRXBTC','4h','0.000086990000000','0.000087520000000','0.001467500000000','0.001476440970226','16.869755144269455','16.869755144269455','test'),('2018-12-26 23:59:59','2018-12-27 23:59:59','ZRXBTC','4h','0.000089950000000','0.000086010000000','0.001467500000000','0.001403220400222','16.31461923290717','16.314619232907170','test'),('2019-01-17 07:59:59','2019-01-18 23:59:59','ZRXBTC','4h','0.000082530000000','0.000080080000000','0.001467500000000','0.001423935538592','17.78141281958076','17.781412819580758','test'),('2019-01-23 15:59:59','2019-01-23 23:59:59','ZRXBTC','4h','0.000083780000000','0.000083820000000','0.001467500000000','0.001468200644545','17.51611363093817','17.516113630938172','test'),('2019-01-24 03:59:59','2019-01-25 07:59:59','ZRXBTC','4h','0.000087890000000','0.000081450000000','0.001467500000000','0.001359971270907','16.69700762316532','16.697007623165320','test'),('2019-02-27 11:59:59','2019-02-28 11:59:59','ZRXBTC','4h','0.000070890000000','0.000064870000000','0.001467500000000','0.001342879461137','20.701086189871635','20.701086189871635','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 20:48:44
