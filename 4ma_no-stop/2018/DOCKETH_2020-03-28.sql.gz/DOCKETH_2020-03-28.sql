-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 19:59:59','2019-01-14 19:59:59','DOCKETH','4h','0.000067210000000','0.000064440000000','0.072144500000000','0.069171128998661','1073.4191340574318','1073.419134057431847','test'),('2019-01-14 23:59:59','2019-01-20 03:59:59','DOCKETH','4h','0.000068310000000','0.000079870000000','0.072144500000000','0.084353406748646','1056.1338017859757','1056.133801785975720','test'),('2019-01-21 19:59:59','2019-01-22 15:59:59','DOCKETH','4h','0.000084520000000','0.000082750000000','0.074453383936827','0.072894196885618','880.8966391011211','880.896639101121082','test'),('2019-01-23 03:59:59','2019-01-25 15:59:59','DOCKETH','4h','0.000087030000000','0.000086850000000','0.074453383936827','0.074299395552263','855.4910253570838','855.491025357083799','test'),('2019-03-01 07:59:59','2019-03-05 19:59:59','DOCKETH','4h','0.000066500000000','0.000073530000000','0.074453383936827','0.082324170238720','1119.5997584485262','1119.599758448526245','test'),('2019-03-08 07:59:59','2019-03-09 15:59:59','DOCKETH','4h','0.000079320000000','0.000073520000000','0.075992786653357','0.070436077593984','958.053286098799','958.053286098799049','test'),('2019-03-10 11:59:59','2019-03-11 15:59:59','DOCKETH','4h','0.000077100000000','0.000073550000000','0.075992786653357','0.072493767293831','985.6392562043709','985.639256204370895','test'),('2019-03-12 19:59:59','2019-03-16 07:59:59','DOCKETH','4h','0.000078400000000','0.000078530000000','0.075992786653357','0.076118795100614','969.2957481295537','969.295748129553658','test'),('2019-03-18 07:59:59','2019-03-18 11:59:59','DOCKETH','4h','0.000080020000000','0.000078520000000','0.075992786653357','0.074568278030762','949.6724150631967','949.672415063196695','test'),('2019-03-19 03:59:59','2019-03-21 15:59:59','DOCKETH','4h','0.000080870000000','0.000084820000000','0.075992786653357','0.079704564905870','939.69069683884','939.690696838840040','test'),('2019-03-21 19:59:59','2019-03-23 19:59:59','DOCKETH','4h','0.000085660000000','0.000083000000000','0.075992786653357','0.073632982631667','887.1443690562339','887.144369056233927','test'),('2019-03-26 23:59:59','2019-03-30 07:59:59','DOCKETH','4h','0.000085030000000','0.000095550000000','0.075992786653357','0.085394693222724','893.7173545026108','893.717354502610760','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','DOCKETH','4h','0.000098950000000','0.000097610000000','0.076092699704845','0.075062237677513','769.0015129342597','769.001512934259722','test'),('2019-04-05 19:59:59','2019-04-06 15:59:59','DOCKETH','4h','0.000098960000000','0.000093660000000','0.076092699704845','0.072017403540378','768.9238046164612','768.923804616461211','test'),('2019-04-07 03:59:59','2019-04-08 03:59:59','DOCKETH','4h','0.000095660000000','0.000095320000000','0.076092699704845','0.075822246872944','795.449505591104','795.449505591103957','test'),('2019-04-19 23:59:59','2019-04-20 07:59:59','DOCKETH','4h','0.000089660000000','0.000086250000000','0.076092699704845','0.073198698968803','848.6805677542382','848.680567754238155','test'),('2019-04-20 11:59:59','2019-04-20 23:59:59','DOCKETH','4h','0.000087140000000','0.000086020000000','0.076092699704845','0.075114689334528','873.2235449259239','873.223544925923875','test'),('2019-04-23 23:59:59','2019-04-24 23:59:59','DOCKETH','4h','0.000089740000000','0.000086110000000','0.076092699704845','0.073014735587076','847.9239993853911','847.923999385391085','test'),('2019-04-25 07:59:59','2019-04-25 11:59:59','DOCKETH','4h','0.000086710000000','0.000088010000000','0.076092699704845','0.077233519790375','877.5539119460847','877.553911946084668','test'),('2019-04-25 19:59:59','2019-04-25 23:59:59','DOCKETH','4h','0.000088630000000','0.000085960000000','0.076092699704845','0.073800388882190','858.543379271635','858.543379271634990','test'),('2019-05-23 07:59:59','2019-05-24 15:59:59','DOCKETH','4h','0.000065150000000','0.000059400000000','0.076092699704845','0.069376920375561','1167.9616224841905','1167.961622484190457','test'),('2019-05-24 19:59:59','2019-05-24 23:59:59','DOCKETH','4h','0.000060440000000','0.000059000000000','0.076092699704845','0.074279769731732','1258.9791479954501','1258.979147995450148','test'),('2019-06-07 15:59:59','2019-06-09 19:59:59','DOCKETH','4h','0.000056690000000','0.000055440000000','0.076092699704845','0.074414875139118','1342.2596525814959','1342.259652581495857','test'),('2019-06-10 23:59:59','2019-06-12 15:59:59','DOCKETH','4h','0.000055920000000','0.000055230000000','0.076092699704845','0.075153787637671','1360.74212633843','1360.742126338429898','test'),('2019-06-15 23:59:59','2019-06-17 11:59:59','DOCKETH','4h','0.000058780000000','0.000056680000000','0.076092699704845','0.073374178619779','1294.5338500313883','1294.533850031388283','test'),('2019-06-20 07:59:59','2019-06-20 15:59:59','DOCKETH','4h','0.000059630000000','0.000055490000000','0.076092699704845','0.070809725081701','1276.0808268463022','1276.080826846302216','test'),('2019-07-03 11:59:59','2019-07-03 23:59:59','DOCKETH','4h','0.000047460000000','0.000044730000000','0.076092699704845','0.071715686005009','1603.3017215517277','1603.301721551727724','test'),('2019-07-14 11:59:59','2019-07-15 19:59:59','DOCKETH','4h','0.000043000000000','0.000040980000000','0.076092699704845','0.072518112416385','1769.5976675545348','1769.597667554534837','test'),('2019-07-16 19:59:59','2019-07-16 23:59:59','DOCKETH','4h','0.000042620000000','0.000041630000000','0.076092699704845','0.074325178055202','1785.3754036800797','1785.375403680079671','test'),('2019-07-18 03:59:59','2019-07-18 07:59:59','DOCKETH','4h','0.000043130000000','0.000042330000000','0.076092699704845','0.074681288627547','1764.2638466228843','1764.263846622884330','test'),('2019-07-18 11:59:59','2019-07-18 15:59:59','DOCKETH','4h','0.000042530000000','0.000041650000000','0.076092699704845','0.074518244596915','1789.1535317386551','1789.153531738655147','test'),('2019-07-18 19:59:59','2019-07-18 23:59:59','DOCKETH','4h','0.000042510000000','0.000042410000000','0.076092699704845','0.075913700176017','1789.9952882814632','1789.995288281463218','test'),('2019-07-19 03:59:59','2019-07-19 07:59:59','DOCKETH','4h','0.000042420000000','0.000041570000000','0.076092699704845','0.074567975641924','1793.7930152014383','1793.793015201438266','test'),('2019-07-21 11:59:59','2019-07-21 15:59:59','DOCKETH','4h','0.000043130000000','0.000042300000000','0.076092699704845','0.074628360712148','1764.2638466228843','1764.263846622884330','test'),('2019-07-22 07:59:59','2019-07-24 03:59:59','DOCKETH','4h','0.000043170000000','0.000043430000000','0.076092699704845','0.076550983279625','1762.6291337698633','1762.629133769863301','test'),('2019-07-24 07:59:59','2019-07-24 15:59:59','DOCKETH','4h','0.000043640000000','0.000042490000000','0.076092699704845','0.074087507114089','1743.6457310917735','1743.645731091773541','test'),('2019-07-29 15:59:59','2019-07-29 19:59:59','DOCKETH','4h','0.000043270000000','0.000042670000000','0.076092699704845','0.075037566360197','1758.5555744128728','1758.555574412872829','test'),('2019-07-30 03:59:59','2019-07-30 07:59:59','DOCKETH','4h','0.000042430000000','0.000042340000000','0.076092699704845','0.075931296382351','1793.3702499374265','1793.370249937426479','test'),('2019-08-22 23:59:59','2019-08-24 03:59:59','DOCKETH','4h','0.000030160000000','0.000029770000000','0.076092699704845','0.075108742381075','2522.9674968449935','2522.967496844993548','test'),('2019-08-24 07:59:59','2019-08-28 15:59:59','DOCKETH','4h','0.000033490000000','0.000040840000000','0.076092699704845','0.092792650222331','2272.102111222604','2272.102111222603980','test'),('2019-09-10 19:59:59','2019-09-11 15:59:59','DOCKETH','4h','0.000050000000000','0.000039870000000','0.076092699704845','0.060676318744643','1521.8539940969','1521.853994096899896','test'),('2019-09-11 19:59:59','2019-09-12 03:59:59','DOCKETH','4h','0.000040190000000','0.000037600000000','0.076092699704845','0.071188990019959','1893.3242026584971','1893.324202658497143','test'),('2019-09-12 07:59:59','2019-09-12 11:59:59','DOCKETH','4h','0.000039380000000','0.000039000000000','0.076092699704845','0.075358438001243','1932.2676410575166','1932.267641057516585','test'),('2019-09-13 11:59:59','2019-09-15 19:59:59','DOCKETH','4h','0.000044890000000','0.000042500000000','0.076092699704845','0.072041428769345','1695.0924416316552','1695.092441631655220','test'),('2019-09-16 19:59:59','2019-09-19 19:59:59','DOCKETH','4h','0.000045710000000','0.000050460000000','0.076092699704845','0.083999948088087','1664.6838701563115','1664.683870156311514','test'),('2019-09-24 11:59:59','2019-09-24 19:59:59','DOCKETH','4h','0.000061230000000','0.000052010000000','0.076092699704845','0.064634677635946','1242.7355823100606','1242.735582310060636','test'),('2019-09-24 23:59:59','2019-09-30 03:59:59','DOCKETH','4h','0.000054220000000','0.000064530000000','0.076092699704845','0.090561820581956','1403.4064866256917','1403.406486625691741','test'),('2019-10-03 19:59:59','2019-10-06 03:59:59','DOCKETH','4h','0.000070340000000','0.000065860000000','0.076092699704845','0.071246306547641','1081.7841868758176','1081.784186875817568','test'),('2019-10-15 15:59:59','2019-10-19 11:59:59','DOCKETH','4h','0.000071390000000','0.000069090000000','0.076092699704845','0.073641190959627','1065.8733674862726','1065.873367486272628','test'),('2019-10-20 15:59:59','2019-10-22 23:59:59','DOCKETH','4h','0.000074240000000','0.000069540000000','0.076092699704845','0.071275408640557','1024.9555455932787','1024.955545593278657','test'),('2019-11-16 19:59:59','2019-11-17 15:59:59','DOCKETH','4h','0.000058750000000','0.000055990000000','0.076092699704845','0.072517961812328','1295.1948885931065','1295.194888593106498','test'),('2019-11-17 19:59:59','2019-11-17 23:59:59','DOCKETH','4h','0.000056130000000','0.000056180000000','0.076092699704845','0.076160482262929','1355.6511616754856','1355.651161675485582','test'),('2019-11-25 19:59:59','2019-11-27 19:59:59','DOCKETH','4h','0.000057210000000','0.000055590000000','0.076092699704845','0.073938003436328','1330.0594250104002','1330.059425010400219','test'),('2019-11-27 23:59:59','2019-11-28 07:59:59','DOCKETH','4h','0.000055750000000','0.000055910000000','0.076092699704845','0.076311082340769','1364.8914745263678','1364.891474526367801','test'),('2019-11-28 11:59:59','2019-11-30 15:59:59','DOCKETH','4h','0.000057290000000','0.000056390000000','0.076092699704845','0.074897317792917','1328.2021243645488','1328.202124364548808','test'),('2019-12-02 19:59:59','2019-12-06 07:59:59','DOCKETH','4h','0.000058990000000','0.000061320000000','0.076092699704845','0.079098225901019','1289.9254060831497','1289.925406083149710','test'),('2019-12-06 15:59:59','2019-12-10 03:59:59','DOCKETH','4h','0.000065920000000','0.000059790000000','0.076092699704845','0.069016725050860','1154.3188668817506','1154.318866881750637','test'),('2019-12-21 11:59:59','2019-12-22 11:59:59','DOCKETH','4h','0.000061190000000','0.000058990000000','0.076092699704845','0.073356894191678','1243.5479605302337','1243.547960530233695','test'),('2020-01-01 15:59:59','2020-01-02 07:59:59','DOCKETH','4h','0.000060790000000','0.000056980000000','0.076092699704845','0.071323606336274','1251.7305429321434','1251.730542932143408','test'),('2020-01-02 11:59:59','2020-01-02 15:59:59','DOCKETH','4h','0.000057520000000','0.000057390000000','0.050728466469897','0.050613815902423','881.9274421052968','881.927442105296791','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 13:28:20
