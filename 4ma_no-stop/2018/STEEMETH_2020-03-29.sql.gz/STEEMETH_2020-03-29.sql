-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-26 19:59:59','2018-07-26 23:59:59','STEEMETH','4h','0.003295000000000','0.003097000000000','0.072144500000000','0.067809261456753','21.89514415781487','21.895144157814869','test'),('2018-07-27 03:59:59','2018-07-27 07:59:59','STEEMETH','4h','0.003110000000000','0.003088000000000','0.072144500000000','0.071634153054662','23.1975884244373','23.197588424437299','test'),('2018-07-27 15:59:59','2018-07-27 23:59:59','STEEMETH','4h','0.003111000000000','0.003104000000000','0.072144500000000','0.071982169077467','23.190131790421088','23.190131790421088','test'),('2018-07-28 03:59:59','2018-07-28 07:59:59','STEEMETH','4h','0.003124000000000','0.003113000000000','0.072144500000000','0.071890470070423','23.09362996158771','23.093629961587709','test'),('2018-07-28 11:59:59','2018-07-28 15:59:59','STEEMETH','4h','0.003124000000000','0.003084000000000','0.072144500000000','0.071220754801536','23.09362996158771','23.093629961587709','test'),('2018-08-11 11:59:59','2018-08-15 03:59:59','STEEMETH','4h','0.003017000000000','0.003083000000000','0.072144500000000','0.073722735664567','23.91266158435532','23.912661584355320','test'),('2018-08-17 15:59:59','2018-08-18 07:59:59','STEEMETH','4h','0.003164000000000','0.003000000000000','0.072144500000000','0.068405025284450','22.801675094816687','22.801675094816687','test'),('2018-08-18 11:59:59','2018-08-18 15:59:59','STEEMETH','4h','0.003034000000000','0.003018000000000','0.072144500000000','0.071764041199736','23.778675016479895','23.778675016479895','test'),('2018-08-18 19:59:59','2018-08-18 23:59:59','STEEMETH','4h','0.003135000000000','0.003062000000000','0.072144500000000','0.070464580223285','23.01259968102073','23.012599681020731','test'),('2018-08-19 03:59:59','2018-08-19 07:59:59','STEEMETH','4h','0.003070000000000','0.003040000000000','0.072144500000000','0.071439504885993','23.49983713355049','23.499837133550489','test'),('2018-08-19 11:59:59','2018-08-19 15:59:59','STEEMETH','4h','0.003056000000000','0.003043000000000','0.072144500000000','0.071837602585079','23.60749345549738','23.607493455497380','test'),('2018-08-19 19:59:59','2018-08-19 23:59:59','STEEMETH','4h','0.003074000000000','0.003101000000000','0.072144500000000','0.072778169973975','23.469258295380612','23.469258295380612','test'),('2018-08-20 11:59:59','2018-08-20 19:59:59','STEEMETH','4h','0.003080000000000','0.003044000000000','0.072144500000000','0.071301252597403','23.42353896103896','23.423538961038961','test'),('2018-08-20 23:59:59','2018-08-21 19:59:59','STEEMETH','4h','0.003118000000000','0.003052000000000','0.072144500000000','0.070617387427838','23.138069275176395','23.138069275176395','test'),('2018-08-22 07:59:59','2018-08-24 23:59:59','STEEMETH','4h','0.003113000000000','0.003154000000000','0.072144500000000','0.073094684548667','23.175232894314167','23.175232894314167','test'),('2018-08-25 03:59:59','2018-08-30 07:59:59','STEEMETH','4h','0.003177000000000','0.003292000000000','0.072144500000000','0.074755962858042','22.708372678627637','22.708372678627637','test'),('2018-08-31 19:59:59','2018-09-03 11:59:59','STEEMETH','4h','0.003398000000000','0.003327000000000','0.072144500000000','0.070637066362566','21.23145968216598','21.231459682165980','test'),('2018-09-03 19:59:59','2018-09-12 19:59:59','STEEMETH','4h','0.003445000000000','0.003832000000000','0.072144500000000','0.080248976487663','20.941799709724236','20.941799709724236','test'),('2018-09-18 11:59:59','2018-09-19 19:59:59','STEEMETH','4h','0.004223000000000','0.003758000000000','0.072144500000000','0.064200575657116','17.08370826426711','17.083708264267109','test'),('2018-09-19 23:59:59','2018-09-21 03:59:59','STEEMETH','4h','0.003851000000000','0.003727000000000','0.072144500000000','0.069821488314723','18.73396520384316','18.733965203843159','test'),('2018-09-24 15:59:59','2018-09-27 23:59:59','STEEMETH','4h','0.004368000000000','0.004043000000000','0.072144500000000','0.066776605654762','16.516597985347985','16.516597985347985','test'),('2018-10-06 19:59:59','2018-10-08 23:59:59','STEEMETH','4h','0.004147000000000','0.003975000000000','0.072144500000000','0.069152251627683','17.396792862310104','17.396792862310104','test'),('2018-10-11 03:59:59','2018-10-11 07:59:59','STEEMETH','4h','0.004064000000000','0.003972000000000','0.072144500000000','0.070511307578740','17.75209153543307','17.752091535433070','test'),('2018-10-11 11:59:59','2018-10-11 15:59:59','STEEMETH','4h','0.004079000000000','0.003947000000000','0.072144500000000','0.069809841014955','17.686810492767833','17.686810492767833','test'),('2018-10-12 07:59:59','2018-10-12 11:59:59','STEEMETH','4h','0.004039000000000','0.003970000000000','0.072144500000000','0.070912024015845','17.861970784847735','17.861970784847735','test'),('2018-10-12 15:59:59','2018-10-15 07:59:59','STEEMETH','4h','0.003995000000000','0.003953000000000','0.072144500000000','0.071386034668335','18.058698372966205','18.058698372966205','test'),('2018-10-31 19:59:59','2018-11-02 15:59:59','STEEMETH','4h','0.004040000000000','0.004028000000000','0.072144500000000','0.071930209405941','17.857549504950494','17.857549504950494','test'),('2019-01-09 07:59:59','2019-01-11 07:59:59','STEEMETH','4h','0.002080000000000','0.002028000000000','0.072144500000000','0.070340887500000','34.68485576923077','34.684855769230772','test'),('2019-01-11 11:59:59','2019-01-12 03:59:59','STEEMETH','4h','0.002088000000000','0.002040000000000','0.072144500000000','0.070486005747126','34.55196360153257','34.551963601532570','test'),('2019-01-12 19:59:59','2019-01-14 15:59:59','STEEMETH','4h','0.002104000000000','0.002043000000000','0.072144500000000','0.070052858127376','34.28921102661597','34.289211026615973','test'),('2019-01-15 23:59:59','2019-01-24 07:59:59','STEEMETH','4h','0.002197000000000','0.003254000000000','0.072144500000000','0.106853984069185','32.83773327264451','32.837733272644513','test'),('2019-02-16 15:59:59','2019-02-17 11:59:59','STEEMETH','4h','0.002617000000000','0.002494000000000','0.072484092985473','0.069077312917757','27.697398924521593','27.697398924521593','test'),('2019-02-17 15:59:59','2019-02-17 19:59:59','STEEMETH','4h','0.002520000000000','0.002483000000000','0.072484092985473','0.071419842413861','28.763528962489282','28.763528962489282','test'),('2019-02-26 11:59:59','2019-03-05 19:59:59','STEEMETH','4h','0.002585000000000','0.002914000000000','0.072484092985473','0.081709341183624','28.04026807948665','28.040268079486651','test'),('2019-03-06 23:59:59','2019-03-14 07:59:59','STEEMETH','4h','0.003028000000000','0.003710000000000','0.073672647375179','0.090266024359945','24.330464787047145','24.330464787047145','test'),('2019-03-24 15:59:59','2019-03-25 03:59:59','STEEMETH','4h','0.003546000000000','0.003457000000000','0.077820991621370','0.075867785683891','21.94613412898202','21.946134128982020','test'),('2019-05-26 03:59:59','2019-05-26 11:59:59','STEEMETH','4h','0.001588000000000','0.001549000000000','0.077820991621370','0.075909770794397','49.00566223008187','49.005662230081867','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','STEEMETH','4h','0.001567000000000','0.001515000000000','0.077820991621370','0.075238546462269','49.66240690578813','49.662406905788131','test'),('2019-05-27 11:59:59','2019-05-27 15:59:59','STEEMETH','4h','0.001571000000000','0.001560000000000','0.077820991621370','0.077276096072143','49.535959020604714','49.535959020604714','test'),('2019-05-28 03:59:59','2019-05-28 07:59:59','STEEMETH','4h','0.001560000000000','0.001537000000000','0.077820991621370','0.076673630847465','49.88525103933975','49.885251039339749','test'),('2019-05-28 23:59:59','2019-05-29 07:59:59','STEEMETH','4h','0.001577000000000','0.001563000000000','0.077820991621370','0.077130126762334','49.347489931116044','49.347489931116044','test'),('2019-06-08 11:59:59','2019-06-12 23:59:59','STEEMETH','4h','0.001596000000000','0.001625000000000','0.077820991621370','0.079235032195944','48.76001981288847','48.760019812888473','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  4:01:58
