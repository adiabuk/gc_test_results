-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-02-26 19:59:59','2019-02-27 15:59:59','GOBNB','4h','0.002093000000000','0.001922000000000','0.711908500000000','0.653744929288103','340.13784042044915','340.137840420449152','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','GOBNB','4h','0.001924000000000','0.001928000000000','0.711908500000000','0.713388559251559','370.01481288981296','370.014812889812958','test'),('2019-02-28 03:59:59','2019-02-28 11:59:59','GOBNB','4h','0.001950000000000','0.001940000000000','0.711908500000000','0.708257687179487','365.0812820512821','365.081282051282074','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','GOBNB','4h','0.001961000000000','0.001891000000000','0.711908500000000','0.686496161907190','363.0334013258542','363.033401325854186','test'),('2019-03-02 15:59:59','2019-03-02 23:59:59','GOBNB','4h','0.002088000000000','0.001922000000000','0.711908500000000','0.655310410440613','340.95234674329504','340.952346743295038','test'),('2019-03-03 03:59:59','2019-03-03 07:59:59','GOBNB','4h','0.001970000000000','0.001863000000000','0.711908500000000','0.673241388578680','361.3748730964467','361.374873096446720','test'),('2019-03-17 15:59:59','2019-03-19 07:59:59','GOBNB','4h','0.001729000000000','0.001648000000000','0.711908500000000','0.678557089647195','411.7458068247542','411.745806824754197','test'),('2019-03-20 19:59:59','2019-03-22 15:59:59','GOBNB','4h','0.001700000000000','0.001720000000000','0.711908500000000','0.720283894117647','418.769705882353','418.769705882352980','test'),('2019-03-23 07:59:59','2019-03-23 19:59:59','GOBNB','4h','0.001737000000000','0.001703000000000','0.711908500000000','0.697973618595279','409.84945308002307','409.849453080023068','test'),('2019-03-23 23:59:59','2019-03-24 11:59:59','GOBNB','4h','0.001756000000000','0.001497000000000','0.711908500000000','0.606906050398633','405.4148633257404','405.414863325740384','test'),('2019-03-31 23:59:59','2019-04-03 03:59:59','GOBNB','4h','0.001930000000000','0.001661000000000','0.711908500000000','0.612683947409326','368.8645077720207','368.864507772020715','test'),('2019-04-03 07:59:59','2019-04-03 19:59:59','GOBNB','4h','0.001690000000000','0.001718000000000','0.711908500000000','0.723703433727811','421.2476331360947','421.247633136094692','test'),('2019-04-06 07:59:59','2019-04-07 23:59:59','GOBNB','4h','0.001745000000000','0.001673000000000','0.711908500000000','0.682534624928367','407.97048710601723','407.970487106017231','test'),('2019-04-08 15:59:59','2019-04-09 03:59:59','GOBNB','4h','0.001751000000000','0.001689000000000','0.711908500000000','0.686701003141062','406.57252998286697','406.572529982866968','test'),('2019-06-03 03:59:59','2019-06-05 03:59:59','GOBNB','4h','0.000790000000000','0.000753000000000','0.711908500000000','0.678565950000000','901.1500000000001','901.150000000000091','test'),('2019-06-07 23:59:59','2019-06-08 11:59:59','GOBNB','4h','0.000783000000000','0.000775000000000','0.711908500000000','0.704634849936143','909.2062579821202','909.206257982120178','test'),('2019-06-08 15:59:59','2019-06-09 15:59:59','GOBNB','4h','0.000780000000000','0.000769000000000','0.711908500000000','0.701868764743590','912.7032051282052','912.703205128205241','test'),('2019-06-30 11:59:59','2019-06-30 15:59:59','GOBNB','4h','0.000569000000000','0.000553000000000','0.711908500000000','0.691889983304042','1251.157293497364','1251.157293497363980','test'),('2019-07-01 07:59:59','2019-07-01 11:59:59','GOBNB','4h','0.000585000000000','0.000569000000000','0.711908500000000','0.692437498290598','1216.9376068376068','1216.937606837606836','test'),('2019-07-01 19:59:59','2019-07-02 07:59:59','GOBNB','4h','0.000564000000000','0.000562000000000','0.711908500000000','0.709384001773050','1262.2491134751772','1262.249113475177182','test'),('2019-07-02 11:59:59','2019-07-02 19:59:59','GOBNB','4h','0.000577000000000','0.000551000000000','0.711908500000000','0.679829434142114','1233.810225303293','1233.810225303293009','test'),('2019-07-22 03:59:59','2019-07-23 15:59:59','GOBNB','4h','0.000496700000000','0.000435400000000','0.711908500000000','0.624048642842762','1433.276625729817','1433.276625729816942','test'),('2019-07-25 11:59:59','2019-07-25 15:59:59','GOBNB','4h','0.000455200000000','0.000438100000000','0.711908500000000','0.685165012851494','1563.946616871705','1563.946616871704919','test'),('2019-07-25 19:59:59','2019-07-25 23:59:59','GOBNB','4h','0.000441000000000','0.000428100000000','0.711908500000000','0.691083965646259','1614.3049886621318','1614.304988662131791','test'),('2019-07-27 03:59:59','2019-07-29 03:59:59','GOBNB','4h','0.000453000000000','0.000446600000000','0.474605666666667','0.467900421044886','1047.6946284032376','1047.694628403237630','test'),('2019-07-29 07:59:59','2019-07-29 15:59:59','GOBNB','4h','0.000456800000000','0.000455000000000','0.528453914129805','0.526371565081132','1156.8605825958964','1156.860582595896403','test'),('2019-07-30 19:59:59','2019-07-30 23:59:59','GOBNB','4h','0.000460000000000','0.000451900000000','0.528453914129805','0.519148529989693','1148.812856803924','1148.812856803923978','test'),('2019-08-06 19:59:59','2019-08-07 03:59:59','GOBNB','4h','0.000443500000000','0.000428400000000','0.528453914129805','0.510461458428880','1191.5533576771252','1191.553357677125177','test'),('2019-08-07 07:59:59','2019-08-07 15:59:59','GOBNB','4h','0.000449200000000','0.000409500000000','0.528453914129805','0.481749505423320','1176.433468677215','1176.433468677214933','test'),('2019-08-16 15:59:59','2019-08-16 23:59:59','GOBNB','4h','0.000430900000000','0.000384200000000','0.528453914129805','0.471181234181181','1226.3957162446159','1226.395716244615869','test'),('2019-08-17 03:59:59','2019-08-17 07:59:59','GOBNB','4h','0.000391000000000','0.000385200000000','0.528453914129805','0.520614955812790','1351.544537416381','1351.544537416380990','test'),('2019-08-17 15:59:59','2019-08-18 03:59:59','GOBNB','4h','0.000407600000000','0.000385000000000','0.528453914129805','0.499152985623098','1296.5012613586973','1296.501261358697320','test'),('2019-08-18 11:59:59','2019-08-18 19:59:59','GOBNB','4h','0.000398100000000','0.000388900000000','0.528453914129805','0.516241464971317','1327.4401259226452','1327.440125922645166','test'),('2019-08-18 23:59:59','2019-08-19 11:59:59','GOBNB','4h','0.000391500000000','0.000393600000000','0.528453914129805','0.531288532826287','1349.8184268960538','1349.818426896053779','test'),('2019-08-19 19:59:59','2019-08-20 19:59:59','GOBNB','4h','0.000393600000000','0.000404200000000','0.528453914129805','0.542685650638382','1342.6166517525533','1342.616651752553253','test'),('2019-08-21 07:59:59','2019-08-21 11:59:59','GOBNB','4h','0.000393600000000','0.000391500000000','0.528453914129805','0.525634419161125','1342.6166517525533','1342.616651752553253','test'),('2019-08-22 11:59:59','2019-08-23 11:59:59','GOBNB','4h','0.000398500000000','0.000406800000000','0.528453914129805','0.539460607949824','1326.1076891588584','1326.107689158858420','test'),('2019-08-23 19:59:59','2019-08-28 19:59:59','GOBNB','4h','0.000400700000000','0.000464000000000','0.528453914129805','0.611935652997828','1318.8268383573873','1318.826838357387260','test'),('2019-08-29 03:59:59','2019-08-29 07:59:59','GOBNB','4h','0.000498000000000','0.000464700000000','0.528453914129805','0.493117537944017','1061.1524380116568','1061.152438011656841','test'),('2019-08-31 11:59:59','2019-09-01 15:59:59','GOBNB','4h','0.000485300000000','0.000468800000000','0.528453914129805','0.510486698833819','1088.922139150639','1088.922139150638941','test'),('2019-09-10 23:59:59','2019-09-12 07:59:59','GOBNB','4h','0.000480200000000','0.000448900000000','0.528453914129805','0.494008667332090','1100.4871181378696','1100.487118137869629','test'),('2019-09-16 23:59:59','2019-09-17 03:59:59','GOBNB','4h','0.000479400000000','0.000452900000000','0.528453914129805','0.499242339819334','1102.323558885701','1102.323558885701004','test'),('2019-09-17 11:59:59','2019-09-17 15:59:59','GOBNB','4h','0.000463500000000','0.000451000000000','0.528453914129805','0.514202190447771','1140.1378945626861','1140.137894562686142','test'),('2019-09-17 23:59:59','2019-09-18 07:59:59','GOBNB','4h','0.000457800000000','0.000451400000000','0.528453914129805','0.521066179200948','1154.333582633912','1154.333582633912101','test'),('2019-09-18 11:59:59','2019-09-18 15:59:59','GOBNB','4h','0.000454700000000','0.000470000000000','0.528453914129805','0.546235627097005','1162.2034619085223','1162.203461908522286','test'),('2019-09-18 19:59:59','2019-09-19 03:59:59','GOBNB','4h','0.000474800000000','0.000445100000000','0.528453914129805','0.495397719416968','1113.0031889844252','1113.003188984425151','test'),('2019-09-19 07:59:59','2019-09-19 11:59:59','GOBNB','4h','0.000465500000000','0.000475400000000','0.528453914129805','0.539692783624725','1135.2393429211709','1135.239342921170874','test'),('2019-09-19 15:59:59','2019-09-24 19:59:59','GOBNB','4h','0.000483400000000','0.000502800000000','0.528453914129805','0.549662035631911','1093.2021392838333','1093.202139283833276','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','GOBNB','4h','0.000567300000000','0.000524400000000','0.528453914129805','0.488491508143257','931.5246150710472','931.524615071047151','test'),('2019-09-26 19:59:59','2019-09-29 15:59:59','GOBNB','4h','0.000550000000000','0.000558200000000','0.528453914129805','0.536332681576831','960.8252984178273','960.825298417827298','test'),('2019-09-29 19:59:59','2019-09-29 23:59:59','GOBNB','4h','0.000574800000000','0.000562300000000','0.528453914129805','0.516961788300608','919.3700663357778','919.370066335777778','test'),('2019-09-30 19:59:59','2019-10-05 23:59:59','GOBNB','4h','0.000600000000000','0.000630100000000','0.528453914129805','0.554964685488650','880.7565235496751','880.756523549675080','test'),('2019-10-07 11:59:59','2019-10-09 07:59:59','GOBNB','4h','0.000664300000000','0.000638000000000','0.528453914129805','0.507532134901122','795.5049136381228','795.504913638122844','test'),('2019-11-16 03:59:59','2019-11-16 23:59:59','GOBNB','4h','0.000448100000000','0.000440000000000','0.528453914129805','0.518901410883986','1179.321388372696','1179.321388372695992','test'),('2019-11-17 03:59:59','2019-11-18 19:59:59','GOBNB','4h','0.000456200000000','0.000475900000000','0.528453914129805','0.551274041504547','1158.382100240695','1158.382100240695081','test'),('2019-11-19 03:59:59','2019-11-21 07:59:59','GOBNB','4h','0.000476700000000','0.000466400000000','0.528453914129805','0.517035673484668','1108.5670529259598','1108.567052925959842','test'),('2019-11-22 03:59:59','2019-11-30 19:59:59','GOBNB','4h','0.000507500000000','0.000586500000000','0.528453914129805','0.610715705688927','1041.2885007483842','1041.288500748384195','test'),('2019-12-05 07:59:59','2019-12-12 23:59:59','GOBNB','4h','0.000608000000000','0.000920100000000','0.528453914129805','0.799721128932292','869.1676219240213','869.167621924021319','test'),('2019-12-14 11:59:59','2019-12-15 15:59:59','GOBNB','4h','0.001052000000000','0.000969200000000','0.558951397893497','0.514957884827355','531.3226215717655','531.322621571765467','test'),('2019-12-16 15:59:59','2019-12-20 23:59:59','GOBNB','4h','0.001035500000000','0.001103400000000','0.558951397893497','0.595603063675215','539.7888922196978','539.788892219697800','test'),('2020-01-02 11:59:59','2020-01-13 03:59:59','GOBNB','4h','0.001039100000000','0.001451300000000','0.558951397893497','0.780681516468898','537.9187738364902','537.918773836490232','test'),('2020-01-25 19:59:59','2020-01-26 11:59:59','GOBNB','4h','0.001169700000000','0.001178000000000','0.612548465716241','0.616895009501352','523.6799741098072','523.679974109807176','test'),('2020-01-29 15:59:59','2020-01-30 11:59:59','GOBNB','4h','0.001235400000000','0.001176000000000','0.613635101662519','0.584130548449994','496.7096500425119','496.709650042511896','test'),('2020-01-30 23:59:59','2020-01-31 03:59:59','GOBNB','4h','0.001178000000000','0.001144600000000','0.613635101662519','0.596236619153582','520.9126499681826','520.912649968182563','test'),('2020-01-31 23:59:59','2020-02-02 23:59:59','GOBNB','4h','0.001202400000000','0.001205000000000','0.613635101662519','0.614961990604903','510.341900916932','510.341900916931991','test'),('2020-02-03 03:59:59','2020-02-04 03:59:59','GOBNB','4h','0.001206000000000','0.001210000000000','0.613635101662519','0.615670375631549','508.8184922574784','508.818492257478397','test'),('2020-02-04 23:59:59','2020-02-05 03:59:59','GOBNB','4h','0.001257600000000','0.001200000000000','0.613635101662519','0.585529677158892','487.94139763241014','487.941397632410144','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 20:37:18
