-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-10 23:59:59','2018-02-11 04:00:00','QTUMETH','4h','0.033776000000000','0.031795000000000','0.072144500000000','0.067913144762553','2.1359693273330174','2.135969327333017','test'),('2018-02-11 11:59:59','2018-02-11 15:59:59','QTUMETH','4h','0.032587000000000','0.033324000000000','0.072144500000000','0.073776147482125','2.2139043176726916','2.213904317672692','test'),('2018-02-12 03:59:59','2018-02-15 23:59:59','QTUMETH','4h','0.033398000000000','0.034024000000000','0.072144500000000','0.073496750344332','2.160144320019163','2.160144320019163','test'),('2018-03-19 19:59:59','2018-03-23 23:59:59','QTUMETH','4h','0.034118000000000','0.034023000000000','0.072144500000000','0.071943616961721','2.1145582976727826','2.114558297672783','test'),('2018-03-25 15:59:59','2018-03-25 23:59:59','QTUMETH','4h','0.034734000000000','0.034262000000000','0.072144500000000','0.071164129066621','2.077057062244487','2.077057062244487','test'),('2018-03-28 19:59:59','2018-04-01 15:59:59','QTUMETH','4h','0.034262000000000','0.035121000000000','0.072144500000000','0.073953271393964','2.105671005778997','2.105671005778997','test'),('2018-04-02 03:59:59','2018-04-04 03:59:59','QTUMETH','4h','0.037300000000000','0.035894000000000','0.072144500000000','0.069425058525469','1.9341689008042895','1.934168900804289','test'),('2018-04-20 03:59:59','2018-04-20 07:59:59','QTUMETH','4h','0.032959000000000','0.032671000000000','0.072144500000000','0.071514092038593','2.188916532661792','2.188916532661792','test'),('2018-04-20 19:59:59','2018-04-20 23:59:59','QTUMETH','4h','0.033550000000000','0.032912000000000','0.072144500000000','0.070772571803279','2.1503576751117732','2.150357675111773','test'),('2018-04-29 23:59:59','2018-05-01 07:59:59','QTUMETH','4h','0.033381000000000','0.032332000000000','0.072144500000000','0.069877354602918','2.1612444204787153','2.161244420478715','test'),('2018-05-01 11:59:59','2018-05-01 19:59:59','QTUMETH','4h','0.032722000000000','0.032215000000000','0.072144500000000','0.071026681361164','2.2047704908012955','2.204770490801296','test'),('2018-05-29 07:59:59','2018-05-29 15:59:59','QTUMETH','4h','0.023553000000000','0.023292000000000','0.072144500000000','0.071345038593810','3.0630705218018934','3.063070521801893','test'),('2018-05-29 19:59:59','2018-05-30 03:59:59','QTUMETH','4h','0.023472000000000','0.023161000000000','0.072144500000000','0.071188597669564','3.073640933878664','3.073640933878664','test'),('2018-05-30 07:59:59','2018-05-31 03:59:59','QTUMETH','4h','0.023350000000000','0.023177000000000','0.072144500000000','0.071609981862955','3.0897002141327623','3.089700214132762','test'),('2018-05-31 07:59:59','2018-05-31 11:59:59','QTUMETH','4h','0.023220000000000','0.023100000000000','0.072144500000000','0.071771660206718','3.1069982773471145','3.106998277347115','test'),('2018-06-01 11:59:59','2018-06-03 11:59:59','QTUMETH','4h','0.023755000000000','0.023563000000000','0.072144500000000','0.071561391433382','3.0370237844664283','3.037023784466428','test'),('2018-06-03 15:59:59','2018-06-03 19:59:59','QTUMETH','4h','0.023686000000000','0.023601000000000','0.072144500000000','0.071885600966816','3.04587097863717','3.045870978637170','test'),('2018-07-04 19:59:59','2018-07-04 23:59:59','QTUMETH','4h','0.019279000000000','0.019130000000000','0.072144500000000','0.071586922817574','3.742128741117278','3.742128741117278','test'),('2018-07-05 03:59:59','2018-07-05 07:59:59','QTUMETH','4h','0.019332000000000','0.019140000000000','0.072144500000000','0.071427981067660','3.7318694392716742','3.731869439271674','test'),('2018-07-05 11:59:59','2018-07-05 15:59:59','QTUMETH','4h','0.019173000000000','0.018639000000000','0.072144500000000','0.070135155452981','3.7628175037813594','3.762817503781359','test'),('2018-08-15 19:59:59','2018-08-16 11:59:59','QTUMETH','4h','0.015795000000000','0.015171000000000','0.072144500000000','0.069294346913580','4.567553023108578','4.567553023108578','test'),('2018-08-16 19:59:59','2018-08-16 23:59:59','QTUMETH','4h','0.015121000000000','0.015237000000000','0.072144500000000','0.072697952946234','4.771146088221678','4.771146088221678','test'),('2018-08-17 07:59:59','2018-08-17 11:59:59','QTUMETH','4h','0.015323000000000','0.015598000000000','0.072144500000000','0.073439268485284','4.708249037394766','4.708249037394766','test'),('2018-08-17 15:59:59','2018-08-18 07:59:59','QTUMETH','4h','0.015882000000000','0.015102000000000','0.072144500000000','0.068601324707216','4.542532426646518','4.542532426646518','test'),('2018-08-18 11:59:59','2018-08-18 15:59:59','QTUMETH','4h','0.015368000000000','0.015271000000000','0.072144500000000','0.071689137135606','4.694462519521083','4.694462519521083','test'),('2018-08-20 15:59:59','2018-08-20 23:59:59','QTUMETH','4h','0.015510000000000','0.015111000000000','0.072144500000000','0.070288558317215','4.651482914248872','4.651482914248872','test'),('2018-08-27 15:59:59','2018-09-02 11:59:59','QTUMETH','4h','0.015576000000000','0.016160000000000','0.072144500000000','0.074849455572676','4.631773240883411','4.631773240883411','test'),('2018-09-04 07:59:59','2018-09-05 11:59:59','QTUMETH','4h','0.016664000000000','0.016400000000000','0.072144500000000','0.071001548247720','4.329362698031685','4.329362698031685','test'),('2018-09-05 15:59:59','2018-09-13 03:59:59','QTUMETH','4h','0.016648000000000','0.017917000000000','0.072144500000000','0.077643741380346','4.333523546371937','4.333523546371937','test'),('2018-09-23 23:59:59','2018-09-24 11:59:59','QTUMETH','4h','0.016977000000000','0.016300000000000','0.072144500000000','0.069267559050480','4.249543500029452','4.249543500029452','test'),('2018-09-24 15:59:59','2018-09-25 03:59:59','QTUMETH','4h','0.016437000000000','0.016530000000000','0.072144500000000','0.072552691184523','4.389152521749711','4.389152521749711','test'),('2018-09-25 07:59:59','2018-09-29 11:59:59','QTUMETH','4h','0.016869000000000','0.016500000000000','0.072144500000000','0.070566379157034','4.276750251941431','4.276750251941431','test'),('2018-10-02 15:59:59','2018-10-02 23:59:59','QTUMETH','4h','0.017058000000000','0.016900000000000','0.072144500000000','0.071476260405675','4.229364521045843','4.229364521045843','test'),('2018-10-03 03:59:59','2018-10-05 11:59:59','QTUMETH','4h','0.016952000000000','0.016820000000000','0.072144500000000','0.071582733010854','4.255810523831997','4.255810523831997','test'),('2018-10-07 19:59:59','2018-10-08 11:59:59','QTUMETH','4h','0.017000000000000','0.017039000000000','0.072144500000000','0.072310007970588','4.243794117647059','4.243794117647059','test'),('2018-10-08 15:59:59','2018-10-09 03:59:59','QTUMETH','4h','0.017057000000000','0.016965000000000','0.072144500000000','0.071755375652225','4.2296124758163804','4.229612475816380','test'),('2018-10-10 15:59:59','2018-10-13 15:59:59','QTUMETH','4h','0.017408000000000','0.017339000000000','0.072144500000000','0.071858541216682','4.144330193014706','4.144330193014706','test'),('2018-10-14 19:59:59','2018-10-15 07:59:59','QTUMETH','4h','0.017565000000000','0.017013000000000','0.072144500000000','0.069877277455167','4.107287218901224','4.107287218901224','test'),('2018-10-17 15:59:59','2018-10-23 23:59:59','QTUMETH','4h','0.019497000000000','0.020386000000000','0.072144500000000','0.075434055341847','3.700287223675437','3.700287223675437','test'),('2018-11-22 03:59:59','2018-11-25 03:59:59','QTUMETH','4h','0.018169000000000','0.017917000000000','0.072144500000000','0.071143871787110','3.970746876547966','3.970746876547966','test'),('2018-11-29 19:59:59','2018-11-29 23:59:59','QTUMETH','4h','0.018082000000000','0.018118000000000','0.072144500000000','0.072288134664307','3.9898517863068244','3.989851786306824','test'),('2018-12-02 19:59:59','2018-12-03 03:59:59','QTUMETH','4h','0.018278000000000','0.017920000000000','0.072144500000000','0.070731449830397','3.9470675128569868','3.947067512856987','test'),('2018-12-07 07:59:59','2018-12-07 15:59:59','QTUMETH','4h','0.018634000000000','0.018070000000000','0.072144500000000','0.069960884136525','3.8716593324031336','3.871659332403134','test'),('2018-12-11 19:59:59','2018-12-20 19:59:59','QTUMETH','4h','0.018933000000000','0.020934000000000','0.072144500000000','0.079769342576454','3.8105160302118','3.810516030211800','test'),('2019-01-10 07:59:59','2019-01-10 23:59:59','QTUMETH','4h','0.016867000000000','0.016608000000000','0.072144500000000','0.071036690342088','4.277257366455208','4.277257366455208','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  5:04:31
