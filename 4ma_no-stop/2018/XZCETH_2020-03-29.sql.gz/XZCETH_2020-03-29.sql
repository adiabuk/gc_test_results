-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-24 11:59:59','2018-05-25 07:59:59','XZCETH','4h','0.054571000000000','0.052617000000000','0.072144500000000','0.069561253348848','1.3220300159425336','1.322030015942534','test'),('2018-07-04 15:59:59','2018-07-04 19:59:59','XZCETH','4h','0.035465000000000','0.036476000000000','0.072144500000000','0.074201121725645','2.0342450303115744','2.034245030311574','test'),('2018-07-04 23:59:59','2018-07-06 07:59:59','XZCETH','4h','0.037296000000000','0.035665000000000','0.072144500000000','0.068989532188438','1.9343763406263406','1.934376340626341','test'),('2018-07-06 11:59:59','2018-07-06 15:59:59','XZCETH','4h','0.036101000000000','0.034501000000000','0.072144500000000','0.068947048405861','1.9984072463366664','1.998407246336666','test'),('2018-07-07 19:59:59','2018-07-08 07:59:59','XZCETH','4h','0.036451000000000','0.036853000000000','0.072144500000000','0.072940145908206','1.9792186771281997','1.979218677128200','test'),('2018-07-08 11:59:59','2018-07-11 11:59:59','XZCETH','4h','0.037620000000000','0.037736000000000','0.072144500000000','0.072366955130250','1.9177166400850612','1.917716640085061','test'),('2018-07-20 11:59:59','2018-07-21 03:59:59','XZCETH','4h','0.038999000000000','0.036047000000000','0.072144500000000','0.066683576284007','1.8499064078566119','1.849906407856612','test'),('2018-07-22 19:59:59','2018-07-23 03:59:59','XZCETH','4h','0.037747000000000','0.036926000000000','0.072144500000000','0.070575351869023','1.9112644713487164','1.911264471348716','test'),('2018-07-23 07:59:59','2018-07-23 11:59:59','XZCETH','4h','0.038346000000000','0.036621000000000','0.072144500000000','0.068899069902989','1.8814087518906797','1.881408751890680','test'),('2018-07-23 15:59:59','2018-07-24 03:59:59','XZCETH','4h','0.037138000000000','0.036601000000000','0.072144500000000','0.071101320601540','1.9426059561634985','1.942605956163499','test'),('2018-08-07 19:59:59','2018-08-18 03:59:59','XZCETH','4h','0.037072000000000','0.046647000000000','0.072144500000000','0.090778066775464','1.9460644151920587','1.946064415192059','test'),('2018-08-20 03:59:59','2018-08-22 03:59:59','XZCETH','4h','0.047843000000000','0.046577000000000','0.072507985535068','0.070589311754423','1.5155401110939477','1.515540111093948','test'),('2018-08-25 07:59:59','2018-08-25 19:59:59','XZCETH','4h','0.047830000000000','0.046773000000000','0.072507985535068','0.070905624240680','1.5159520287490698','1.515952028749070','test'),('2018-08-25 23:59:59','2018-08-27 03:59:59','XZCETH','4h','0.046905000000000','0.045763000000000','0.072507985535068','0.070742627481960','1.545847682231489','1.545847682231489','test'),('2018-09-04 19:59:59','2018-09-06 11:59:59','XZCETH','4h','0.046240000000000','0.046552000000000','0.072507985535068','0.072997226267917','1.5680792719521626','1.568079271952163','test'),('2018-09-06 15:59:59','2018-09-12 03:59:59','XZCETH','4h','0.047672000000000','0.051635000000000','0.072507985535068','0.078535614891409','1.5209763705124182','1.520976370512418','test'),('2018-09-12 15:59:59','2018-09-12 19:59:59','XZCETH','4h','0.051754000000000','0.050711000000000','0.072815604775330','0.071348149587699','1.4069560763483016','1.406956076348302','test'),('2018-09-29 03:59:59','2018-09-29 11:59:59','XZCETH','4h','0.046274000000000','0.042339000000000','0.072815604775330','0.066623587556353','1.5735748968174352','1.573574896817435','test'),('2018-09-29 15:59:59','2018-09-30 11:59:59','XZCETH','4h','0.042729000000000','0.042313000000000','0.072815604775330','0.072106688311417','1.7041261151754077','1.704126115175408','test'),('2018-10-01 07:59:59','2018-10-03 23:59:59','XZCETH','4h','0.043817000000000','0.043418000000000','0.072815604775330','0.072152541893221','1.661811734608257','1.661811734608257','test'),('2018-10-05 19:59:59','2018-10-05 23:59:59','XZCETH','4h','0.044150000000000','0.043080000000000','0.072815604775330','0.071050877773980','1.6492775713551528','1.649277571355153','test'),('2018-10-07 11:59:59','2018-10-07 19:59:59','XZCETH','4h','0.044567000000000','0.044637000000000','0.072815604775330','0.072929973979770','1.6338457777128816','1.633845777712882','test'),('2018-10-08 03:59:59','2018-10-09 11:59:59','XZCETH','4h','0.044884000000000','0.044062000000000','0.072815604775330','0.071482068835456','1.6223064961975313','1.622306496197531','test'),('2018-10-10 03:59:59','2018-10-10 07:59:59','XZCETH','4h','0.044191000000000','0.043425000000000','0.072815604775330','0.071553430276950','1.6477473869188295','1.647747386918829','test'),('2018-10-10 11:59:59','2018-10-13 19:59:59','XZCETH','4h','0.046198000000000','0.045200000000000','0.072815604775330','0.071242593528831','1.5761635736466946','1.576163573646695','test'),('2018-10-16 11:59:59','2018-10-18 19:59:59','XZCETH','4h','0.046580000000000','0.046875000000000','0.072815604775330','0.073276759850657','1.5632375434806782','1.563237543480678','test'),('2018-10-18 23:59:59','2018-10-19 03:59:59','XZCETH','4h','0.047116000000000','0.047021000000000','0.072815604775330','0.072668786657203','1.545453875017616','1.545453875017616','test'),('2018-10-20 23:59:59','2018-10-22 03:59:59','XZCETH','4h','0.050452000000000','0.047483000000000','0.072815604775330','0.068530551049453','1.443264980086617','1.443264980086617','test'),('2018-10-22 19:59:59','2018-10-23 19:59:59','XZCETH','4h','0.049491000000000','0.047142000000000','0.072815604775330','0.069359544974210','1.4712898259346143','1.471289825934614','test'),('2018-10-24 19:59:59','2018-10-29 23:59:59','XZCETH','4h','0.048990000000000','0.053463000000000','0.072815604775330','0.079463986080904','1.4863360844117168','1.486336084411717','test'),('2018-11-11 23:59:59','2018-11-12 07:59:59','XZCETH','4h','0.050600000000000','0.049747000000000','0.072815604775330','0.071588100607872','1.4390435726349802','1.439043572634980','test'),('2018-11-12 15:59:59','2018-11-12 19:59:59','XZCETH','4h','0.049290000000000','0.049412000000000','0.072815604775330','0.072995834107499','1.4772896079393385','1.477289607939339','test'),('2018-11-13 15:59:59','2018-11-13 19:59:59','XZCETH','4h','0.050096000000000','0.050021000000000','0.072815604775330','0.072706590675239','1.453521334544275','1.453521334544275','test'),('2018-11-14 15:59:59','2018-11-14 19:59:59','XZCETH','4h','0.050862000000000','0.049418000000000','0.072815604775330','0.070748329927790','1.4316307808448352','1.431630780844835','test'),('2018-11-22 15:59:59','2018-11-23 07:59:59','XZCETH','4h','0.049175000000000','0.048056000000000','0.072815604775330','0.071158651816640','1.4807443777392983','1.480744377739298','test'),('2018-11-23 11:59:59','2018-11-23 23:59:59','XZCETH','4h','0.048079000000000','0.047687000000000','0.072815604775330','0.072221921107368','1.5144991529634562','1.514499152963456','test'),('2018-11-27 19:59:59','2018-11-27 23:59:59','XZCETH','4h','0.048580000000000','0.047808000000000','0.072815604775330','0.071658469186887','1.498880295910457','1.498880295910457','test'),('2018-11-28 03:59:59','2018-11-30 23:59:59','XZCETH','4h','0.048200000000000','0.050687000000000','0.072815604775330','0.076572708698074','1.5106971945089211','1.510697194508921','test'),('2018-12-01 03:59:59','2018-12-06 03:59:59','XZCETH','4h','0.050700000000000','0.056659000000000','0.072815604775330','0.081373951695570','1.4362052223930966','1.436205222393097','test'),('2018-12-09 11:59:59','2018-12-10 11:59:59','XZCETH','4h','0.057134000000000','0.058397000000000','0.072815604775330','0.074425261176619','1.274470626515385','1.274470626515385','test'),('2019-01-10 11:59:59','2019-01-14 15:59:59','XZCETH','4h','0.039893000000000','0.038478000000000','0.072815604775330','0.070232843870984','1.8252727239197355','1.825272723919735','test'),('2019-01-16 07:59:59','2019-01-20 23:59:59','XZCETH','4h','0.040394000000000','0.042505000000000','0.072815604775330','0.076620965514071','1.8026341727813537','1.802634172781354','test'),('2019-01-21 07:59:59','2019-01-24 11:59:59','XZCETH','4h','0.044296000000000','0.043699000000000','0.072815604775330','0.071834231377035','1.6438415381824543','1.643841538182454','test'),('2019-01-28 19:59:59','2019-01-28 23:59:59','XZCETH','4h','0.044135000000000','0.043227000000000','0.072815604775330','0.071317551775761','1.6498381052527473','1.649838105252747','test'),('2019-01-29 03:59:59','2019-01-29 07:59:59','XZCETH','4h','0.043487000000000','0.042891000000000','0.072815604775330','0.071817649054170','1.674422350940051','1.674422350940051','test'),('2019-01-29 23:59:59','2019-01-30 19:59:59','XZCETH','4h','0.044490000000000','0.043670000000000','0.072815604775330','0.071473532491316','1.6366735170899078','1.636673517089908','test'),('2019-01-31 03:59:59','2019-01-31 07:59:59','XZCETH','4h','0.043331000000000','0.042090000000000','0.072815604775330','0.070730165585692','1.6804505960012461','1.680450596001246','test'),('2019-02-01 23:59:59','2019-02-02 15:59:59','XZCETH','4h','0.044084000000000','0.043410000000000','0.072815604775330','0.071702327449802','1.6517467737802831','1.651746773780283','test'),('2019-02-02 19:59:59','2019-02-02 23:59:59','XZCETH','4h','0.043439000000000','0.042685000000000','0.072815604775330','0.071551695247012','1.6762725839759203','1.676272583975920','test'),('2019-02-03 19:59:59','2019-02-04 19:59:59','XZCETH','4h','0.044352000000000','0.043543000000000','0.072815604775330','0.071487416096956','1.641765980684749','1.641765980684749','test'),('2019-02-05 03:59:59','2019-02-05 07:59:59','XZCETH','4h','0.043828000000000','0.043057000000000','0.072815604775330','0.071534669499210','1.6613946512578717','1.661394651257872','test'),('2019-02-05 19:59:59','2019-02-06 07:59:59','XZCETH','4h','0.043961000000000','0.043837000000000','0.072815604775330','0.072610215111943','1.6563682531182184','1.656368253118218','test'),('2019-02-06 15:59:59','2019-02-06 19:59:59','XZCETH','4h','0.043655000000000','0.043837000000000','0.072815604775330','0.073119176876329','1.6679785769174207','1.667978576917421','test'),('2019-02-26 19:59:59','2019-03-05 19:59:59','XZCETH','4h','0.040223000000000','0.041028000000000','0.072815604775330','0.074272894431600','1.8102977096519404','1.810297709651940','test'),('2019-03-07 11:59:59','2019-03-09 19:59:59','XZCETH','4h','0.042211000000000','0.041893000000000','0.072815604775330','0.072267042497285','1.7250386102042123','1.725038610204212','test'),('2019-03-10 07:59:59','2019-03-14 15:59:59','XZCETH','4h','0.042630000000000','0.047676000000000','0.072815604775330','0.081434594728328','1.7080836212838377','1.708083621283838','test'),('2019-03-20 19:59:59','2019-03-21 15:59:59','XZCETH','4h','0.048890000000000','0.047826000000000','0.072815604775330','0.071230908447227','1.4893762482170176','1.489376248217018','test'),('2019-03-22 15:59:59','2019-03-25 07:59:59','XZCETH','4h','0.050179000000000','0.049364000000000','0.072815604775330','0.071632944341844','1.4511170963018394','1.451117096301839','test'),('2019-03-26 11:59:59','2019-03-29 15:59:59','XZCETH','4h','0.050799000000000','0.051300000000000','0.072815604775330','0.073533741313302','1.4334062634171933','1.433406263417193','test'),('2019-03-31 15:59:59','2019-04-02 15:59:59','XZCETH','4h','0.053167000000000','0.051737000000000','0.072815604775330','0.070857128374015','1.3695639170035925','1.369563917003592','test'),('2019-04-04 15:59:59','2019-04-05 07:59:59','XZCETH','4h','0.053961000000000','0.052308000000000','0.072815604775330','0.070585027234261','1.349411700586164','1.349411700586164','test'),('2019-04-05 11:59:59','2019-04-06 03:59:59','XZCETH','4h','0.052705000000000','0.052369000000000','0.072815604775330','0.072351397523561','1.3815692016949055','1.381569201694905','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 14:07:31
