-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-23 23:59:59','2018-04-24 07:59:59','YOYOBNB','4h','0.009610000000000','0.009400000000000','0.711908500000000','0.696351706555671','74.07996878251821','74.079968782518208','test'),('2018-04-30 03:59:59','2018-05-05 15:59:59','YOYOBNB','4h','0.009690000000000','0.012830000000000','0.711908500000000','0.942599180082559','73.46836945304437','73.468369453044374','test'),('2018-07-03 07:59:59','2018-07-06 03:59:59','YOYOBNB','4h','0.004598000000000','0.004500000000000','0.765691971659558','0.749372308061768','166.5271795692818','166.527179569281799','test'),('2018-07-06 23:59:59','2018-07-07 03:59:59','YOYOBNB','4h','0.004784000000000','0.004610000000000','0.765691971659558','0.737842807138496','160.05266966127886','160.052669661278856','test'),('2018-07-08 19:59:59','2018-07-09 07:59:59','YOYOBNB','4h','0.004774000000000','0.004799000000000','0.765691971659558','0.769701669877298','160.38792870958486','160.387928709584855','test'),('2018-07-09 15:59:59','2018-07-10 03:59:59','YOYOBNB','4h','0.004830000000000','0.004619000000000','0.765691971659558','0.732242488011490','158.52835852164762','158.528358521647618','test'),('2018-07-17 23:59:59','2018-07-20 19:59:59','YOYOBNB','4h','0.004686000000000','0.004417000000000','0.765691971659558','0.721737396248457','163.399908591455','163.399908591454988','test'),('2018-07-20 23:59:59','2018-07-21 03:59:59','YOYOBNB','4h','0.004710000000000','0.004443000000000','0.765691971659558','0.722286503202424','162.56729759226286','162.567297592262861','test'),('2018-08-17 19:59:59','2018-08-24 03:59:59','YOYOBNB','4h','0.002505000000000','0.002930000000000','0.765691971659558','0.895599791202597','305.66545774832656','305.665457748326560','test'),('2018-09-16 23:59:59','2018-09-21 15:59:59','YOYOBNB','4h','0.002427000000000','0.002400000000000','0.765691971659558','0.757173766783246','315.4890694930194','315.489069493019372','test'),('2018-09-21 19:59:59','2018-09-22 07:59:59','YOYOBNB','4h','0.002475000000000','0.002406000000000','0.765691971659558','0.744345407601170','309.37049359982143','309.370493599821430','test'),('2018-09-22 19:59:59','2018-09-25 07:59:59','YOYOBNB','4h','0.002512000000000','0.002443000000000','0.765691971659558','0.744659827533559','304.81368298549285','304.813682985492846','test'),('2018-09-26 23:59:59','2018-09-29 03:59:59','YOYOBNB','4h','0.002620000000000','0.002682000000000','0.765691971659558','0.783811399996540','292.2488441448695','292.248844144869508','test'),('2018-09-30 07:59:59','2018-09-30 19:59:59','YOYOBNB','4h','0.002800000000000','0.002670000000000','0.765691971659558','0.730141987261079','273.46141844984214','273.461418449842142','test'),('2018-10-01 11:59:59','2018-10-02 23:59:59','YOYOBNB','4h','0.002729000000000','0.002698000000000','0.765691971659558','0.756994114890981','280.5760247928025','280.576024792802514','test'),('2018-10-03 03:59:59','2018-10-03 15:59:59','YOYOBNB','4h','0.002729000000000','0.002705000000000','0.765691971659558','0.758958147064531','280.5760247928025','280.576024792802514','test'),('2018-10-03 19:59:59','2018-10-10 07:59:59','YOYOBNB','4h','0.002928000000000','0.003198000000000','0.765691971659558','0.836298813308493','261.5068209219802','261.506820921980193','test'),('2018-10-10 11:59:59','2018-10-10 15:59:59','YOYOBNB','4h','0.003288000000000','0.003207000000000','0.765691971659558','0.746829121992762','232.8746872443911','232.874687244391112','test'),('2018-10-14 03:59:59','2018-10-14 23:59:59','YOYOBNB','4h','0.003237000000000','0.002967000000000','0.765691971659558','0.701825171428455','236.54370455964104','236.543704559641043','test'),('2018-10-15 03:59:59','2018-10-15 07:59:59','YOYOBNB','4h','0.003026000000000','0.002949000000000','0.765691971659558','0.746208071521493','253.03766413071978','253.037664130719776','test'),('2018-10-17 15:59:59','2018-10-18 23:59:59','YOYOBNB','4h','0.003197000000000','0.003049000000000','0.765691971659558','0.730245486890833','239.50327546435972','239.503275464359717','test'),('2018-10-19 03:59:59','2018-10-19 05:59:59','YOYOBNB','4h','0.003063000000000','0.003051000000000','0.765691971659558','0.762692198998796','249.98105506351877','249.981055063518767','test'),('2018-10-20 15:59:59','2018-10-27 23:59:59','YOYOBNB','4h','0.003249000000000','0.003359000000000','0.765691971659558','0.791615676455665','235.670043600972','235.670043600972008','test'),('2018-10-28 15:59:59','2018-10-29 15:59:59','YOYOBNB','4h','0.003560000000000','0.003528000000000','0.765691971659558','0.758809347195203','215.08201451111182','215.082014511111822','test'),('2018-10-29 19:59:59','2018-10-29 23:59:59','YOYOBNB','4h','0.003547000000000','0.003468000000000','0.765691971659558','0.748638217568466','215.87030495053796','215.870304950537957','test'),('2018-10-30 19:59:59','2018-11-04 03:59:59','YOYOBNB','4h','0.003722000000000','0.004039000000000','0.765691971659558','0.830905393211433','205.72057271884955','205.720572718849553','test'),('2018-11-19 11:59:59','2018-11-19 23:59:59','YOYOBNB','4h','0.003781000000000','0.003549000000000','0.765691971659558','0.718709549701077','202.51043947621213','202.510439476212127','test'),('2018-11-20 15:59:59','2018-11-20 19:59:59','YOYOBNB','4h','0.003650000000000','0.003474000000000','0.765691971659558','0.728770934122001','209.77862237248166','209.778622372481664','test'),('2018-11-28 19:59:59','2018-11-30 11:59:59','YOYOBNB','4h','0.003559000000000','0.003286000000000','0.765691971659558','0.706958083414810','215.14244778296094','215.142447782960943','test'),('2018-12-01 15:59:59','2018-12-02 19:59:59','YOYOBNB','4h','0.003546000000000','0.003422000000000','0.765691971659558','0.738916505081502','215.93118208109362','215.931182081093624','test'),('2018-12-02 23:59:59','2018-12-03 15:59:59','YOYOBNB','4h','0.003477000000000','0.003395000000000','0.765691971659558','0.747634237499051','220.2162702500886','220.216270250088598','test'),('2019-01-07 19:59:59','2019-01-07 23:59:59','YOYOBNB','4h','0.002420000000000','0.002367000000000','0.765691971659558','0.748922684676931','316.40164118163557','316.401641181635569','test'),('2019-01-08 03:59:59','2019-01-08 07:59:59','YOYOBNB','4h','0.002373000000000','0.002320000000000','0.765691971659558','0.748590549620807','322.66834035379605','322.668340353796054','test'),('2019-01-15 23:59:59','2019-01-17 07:59:59','YOYOBNB','4h','0.002563000000000','0.002319000000000','0.765691971659558','0.692797378961574','298.74833072944125','298.748330729441250','test'),('2019-01-17 15:59:59','2019-01-17 23:59:59','YOYOBNB','4h','0.002444000000000','0.002315000000000','0.765691971659558','0.725276969882110','313.29458742207777','313.294587422077768','test'),('2019-01-19 07:59:59','2019-01-19 19:59:59','YOYOBNB','4h','0.002444000000000','0.002262000000000','0.765691971659558','0.708672356748740','313.29458742207777','313.294587422077768','test'),('2019-01-22 07:59:59','2019-01-24 23:59:59','YOYOBNB','4h','0.002459000000000','0.002525000000000','0.765691971659558','0.786243281187631','311.3834776980716','311.383477698071601','test'),('2019-02-20 15:59:59','2019-02-21 23:59:59','YOYOBNB','4h','0.001900000000000','0.001688000000000','0.765691971659558','0.680256867453334','402.9957745576621','402.995774557662116','test'),('2019-02-26 23:59:59','2019-02-27 15:59:59','YOYOBNB','4h','0.001730000000000','0.001611000000000','0.765691971659558','0.713022986325750','442.59651541014915','442.596515410149152','test'),('2019-03-16 15:59:59','2019-03-17 03:59:59','YOYOBNB','4h','0.001374000000000','0.001301000000000','0.765691971659558','0.725011102714036','557.2721773359228','557.272177335922834','test'),('2019-03-17 19:59:59','2019-03-18 07:59:59','YOYOBNB','4h','0.001338000000000','0.001315000000000','0.765691971659558','0.752529852565261','572.266047578145','572.266047578145049','test'),('2019-03-27 19:59:59','2019-03-30 11:59:59','YOYOBNB','4h','0.001441000000000','0.001294000000000','0.765691971659558','0.687581826042657','531.3615348088535','531.361534808853548','test'),('2019-03-30 15:59:59','2019-03-31 03:59:59','YOYOBNB','4h','0.001319000000000','0.001269000000000','0.765691971659558','0.736666498890052','580.5094553901122','580.509455390112180','test'),('2019-04-01 07:59:59','2019-04-01 15:59:59','YOYOBNB','4h','0.001340000000000','0.001303000000000','0.510461314439705','0.496366487100698','380.9412794326159','380.941279432615886','test'),('2019-04-01 19:59:59','2019-04-02 07:59:59','YOYOBNB','4h','0.001328000000000','0.001297000000000','0.565199749897476','0.552006081036918','425.6022213083401','425.602221308340120','test'),('2019-04-02 11:59:59','2019-04-02 15:59:59','YOYOBNB','4h','0.001315000000000','0.001291000000000','0.565199749897476','0.554884317199727','429.80969573952547','429.809695739525466','test'),('2019-04-03 19:59:59','2019-04-03 23:59:59','YOYOBNB','4h','0.001346000000000','0.001299000000000','0.565199749897476','0.545463948823790','419.9106611422556','419.910661142255606','test'),('2019-04-05 07:59:59','2019-04-06 23:59:59','YOYOBNB','4h','0.001348000000000','0.001334000000000','0.565199749897476','0.559329722821389','419.2876482918961','419.287648291896119','test'),('2019-04-07 03:59:59','2019-04-09 19:59:59','YOYOBNB','4h','0.001371000000000','0.001373000000000','0.565199749897476','0.566024257191273','412.2536468982319','412.253646898231921','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  7:54:07
