-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-23 07:59:59','2019-01-23 15:59:59','VETBNB','4h','0.000680000000000','0.000670000000000','0.711908500000000','0.701439257352941','1046.9242647058823','1046.924264705882251','test'),('2019-01-23 23:59:59','2019-01-24 11:59:59','VETBNB','4h','0.000680000000000','0.000660000000000','0.711908500000000','0.690970014705882','1046.9242647058823','1046.924264705882251','test'),('2019-01-24 15:59:59','2019-01-25 11:59:59','VETBNB','4h','0.000690000000000','0.000660000000000','0.711908500000000','0.680955956521739','1031.7514492753623','1031.751449275362347','test'),('2019-02-23 19:59:59','2019-02-24 11:59:59','VETBNB','4h','0.000460000000000','0.000440000000000','0.711908500000000','0.680955956521739','1547.6271739130436','1547.627173913043634','test'),('2019-02-24 15:59:59','2019-02-24 19:59:59','VETBNB','4h','0.000450000000000','0.000440000000000','0.711908500000000','0.696088311111111','1582.018888888889','1582.018888888889023','test'),('2019-02-25 03:59:59','2019-02-25 07:59:59','VETBNB','4h','0.000450000000000','0.000440000000000','0.711908500000000','0.696088311111111','1582.018888888889','1582.018888888889023','test'),('2019-02-25 11:59:59','2019-02-25 15:59:59','VETBNB','4h','0.000450000000000','0.000460000000000','0.711908500000000','0.727728688888889','1582.018888888889','1582.018888888889023','test'),('2019-02-25 23:59:59','2019-02-27 07:59:59','VETBNB','4h','0.000470000000000','0.000460000000000','0.711908500000000','0.696761510638298','1514.6989361702128','1514.698936170212846','test'),('2019-02-27 11:59:59','2019-02-27 15:59:59','VETBNB','4h','0.000480000000000','0.000450000000000','0.711908500000000','0.667414218750000','1483.1427083333333','1483.142708333333303','test'),('2019-03-15 19:59:59','2019-03-16 11:59:59','VETBNB','4h','0.000360000000000','0.000340000000000','0.711908500000000','0.672358027777778','1977.5236111111112','1977.523611111111222','test'),('2019-03-20 07:59:59','2019-03-24 11:59:59','VETBNB','4h','0.000360000000000','0.000330000000000','0.711908500000000','0.652582791666667','1977.5236111111112','1977.523611111111222','test'),('2019-04-01 07:59:59','2019-04-01 11:59:59','VETBNB','4h','0.000360000000000','0.000350000000000','0.711908500000000','0.692133263888889','1977.5236111111112','1977.523611111111222','test'),('2019-04-02 03:59:59','2019-04-02 07:59:59','VETBNB','4h','0.000370000000000','0.000360000000000','0.711908500000000','0.692667729729730','1924.0770270270273','1924.077027027027270','test'),('2019-04-02 15:59:59','2019-04-02 19:59:59','VETBNB','4h','0.000370000000000','0.000360000000000','0.711908500000000','0.692667729729730','1924.0770270270273','1924.077027027027270','test'),('2019-04-02 23:59:59','2019-04-04 23:59:59','VETBNB','4h','0.000370000000000','0.000370000000000','0.711908500000000','0.711908500000000','1924.0770270270273','1924.077027027027270','test'),('2019-04-05 03:59:59','2019-04-08 11:59:59','VETBNB','4h','0.000380000000000','0.000380000000000','0.711908500000000','0.711908500000000','1873.4434210526317','1873.443421052631720','test'),('2019-04-08 15:59:59','2019-04-09 15:59:59','VETBNB','4h','0.000400000000000','0.000400000000000','0.711908500000000','0.711908500000000','1779.77125','1779.771250000000009','test'),('2019-05-07 23:59:59','2019-05-08 03:59:59','VETBNB','4h','0.000300000000000','0.000290000000000','0.711908500000000','0.688178216666667','2373.0283333333336','2373.028333333333649','test'),('2019-05-08 11:59:59','2019-05-11 15:59:59','VETBNB','4h','0.000300000000000','0.000300000000000','0.711908500000000','0.711908500000000','2373.0283333333336','2373.028333333333649','test'),('2019-05-16 19:59:59','2019-05-16 23:59:59','VETBNB','4h','0.000305000000000','0.000310200000000','0.711908500000000','0.724045956393443','2334.126229508197','2334.126229508196957','test'),('2019-05-17 15:59:59','2019-05-17 19:59:59','VETBNB','4h','0.000296900000000','0.000291600000000','0.711908500000000','0.699200130010104','2397.8056584708656','2397.805658470865637','test'),('2019-06-04 19:59:59','2019-06-07 11:59:59','VETBNB','4h','0.000245500000000','0.000243800000000','0.711908500000000','0.706978787372709','2899.8309572301428','2899.830957230142758','test'),('2019-06-25 15:59:59','2019-06-27 15:59:59','VETBNB','4h','0.000253100000000','0.000220200000000','0.711908500000000','0.619368833267483','2812.7558277360727','2812.755827736072661','test'),('2019-06-28 19:59:59','2019-07-01 23:59:59','VETBNB','4h','0.000238200000000','0.000243200000000','0.711908500000000','0.726852003358522','2988.7006717044505','2988.700671704450542','test'),('2019-07-25 23:59:59','2019-07-28 23:59:59','VETBNB','4h','0.000203100000000','0.000203500000000','0.711908500000000','0.713310584687346','3505.2117183653377','3505.211718365337674','test'),('2019-07-29 03:59:59','2019-07-31 03:59:59','VETBNB','4h','0.000205000000000','0.000201800000000','0.711908500000000','0.700795781951220','3472.7243902439027','3472.724390243902690','test'),('2019-08-23 19:59:59','2019-08-26 07:59:59','VETBNB','4h','0.000169900000000','0.000167600000000','0.711908500000000','0.702271127722190','4190.161859917599','4190.161859917599031','test'),('2019-08-27 03:59:59','2019-09-03 23:59:59','VETBNB','4h','0.000178900000000','0.000189300000000','0.711908500000000','0.753293901900503','3979.3655673560647','3979.365567356064730','test'),('2019-09-04 07:59:59','2019-09-05 03:59:59','VETBNB','4h','0.000194900000000','0.000190700000000','0.711908500000000','0.696567218830169','3652.6859928168296','3652.685992816829639','test'),('2019-09-16 11:59:59','2019-09-18 11:59:59','VETBNB','4h','0.000203300000000','0.000190000000000','0.711908500000000','0.665335046728972','3501.7634038366946','3501.763403836694579','test'),('2019-09-18 15:59:59','2019-09-19 11:59:59','VETBNB','4h','0.000197600000000','0.000193800000000','0.711908500000000','0.698217951923077','3602.7758097165993','3602.775809716599269','test'),('2019-09-19 15:59:59','2019-10-01 23:59:59','VETBNB','4h','0.000197100000000','0.000216500000000','0.711908500000000','0.781979656265855','3611.9152714358197','3611.915271435819704','test'),('2019-10-03 03:59:59','2019-10-05 03:59:59','VETBNB','4h','0.000219900000000','0.000218200000000','0.711908500000000','0.706404887221464','3237.4192814915873','3237.419281491587299','test'),('2019-10-06 11:59:59','2019-10-07 11:59:59','VETBNB','4h','0.000221900000000','0.000217500000000','0.711908500000000','0.697792243127535','3208.240198287517','3208.240198287517160','test'),('2019-10-08 11:59:59','2019-10-09 07:59:59','VETBNB','4h','0.000220300000000','0.000218300000000','0.711908500000000','0.705445417839310','3231.5410803449845','3231.541080344984493','test'),('2019-10-12 11:59:59','2019-10-12 15:59:59','VETBNB','4h','0.000221500000000','0.000213800000000','0.711908500000000','0.687160439277652','3214.0338600451473','3214.033860045147321','test'),('2019-10-27 23:59:59','2019-10-29 03:59:59','VETBNB','4h','0.000212800000000','0.000188900000000','0.711908500000000','0.631952611137218','3345.4346804511283','3345.434680451128315','test'),('2019-10-29 07:59:59','2019-11-01 19:59:59','VETBNB','4h','0.000197900000000','0.000201100000000','0.711908500000000','0.723419905760485','3597.314300151592','3597.314300151591851','test'),('2019-11-02 19:59:59','2019-11-09 23:59:59','VETBNB','4h','0.000211400000000','0.000260100000000','0.711908500000000','0.875910127010407','3367.5898770104072','3367.589877010407236','test'),('2019-11-10 15:59:59','2019-11-20 03:59:59','VETBNB','4h','0.000269400000000','0.000361600000000','0.711908500000000','0.955553502598367','2642.5705270972535','2642.570527097253489','test'),('2019-11-24 11:59:59','2019-11-25 03:59:59','VETBNB','4h','0.000367300000000','0.000353000000000','0.711908500000000','0.684191942553771','1938.2208004356114','1938.220800435611409','test'),('2019-11-25 07:59:59','2019-11-29 15:59:59','VETBNB','4h','0.000374100000000','0.000397900000000','0.711908500000000','0.757199658246458','1902.9898422881586','1902.989842288158570','test'),('2019-12-01 11:59:59','2019-12-05 03:59:59','VETBNB','4h','0.000425700000000','0.000440900000000','0.711908500000000','0.737327830984261','1672.3244068592908','1672.324406859290775','test'),('2019-12-08 23:59:59','2019-12-10 03:59:59','VETBNB','4h','0.000456900000000','0.000415600000000','0.711908500000000','0.647557830159772','1558.1275990369886','1558.127599036988613','test'),('2019-12-22 11:59:59','2019-12-23 03:59:59','VETBNB','4h','0.000402000000000','0.000396200000000','0.711908500000000','0.701637183333333','1770.9166666666667','1770.916666666666742','test'),('2019-12-23 07:59:59','2019-12-26 07:59:59','VETBNB','4h','0.000400900000000','0.000426500000000','0.711908500000000','0.757368359316538','1775.7757545522577','1775.775754552257695','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  8:20:51
