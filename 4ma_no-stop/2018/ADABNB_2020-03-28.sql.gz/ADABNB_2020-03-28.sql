-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-10-09 15:59:59','2018-10-11 03:59:59','ADABNB','4h','0.008320000000000','0.007920000000000','0.711908500000000','0.677682129807692','85.56592548076925','85.565925480769252','test'),('2018-10-20 11:59:59','2018-10-21 23:59:59','ADABNB','4h','0.007890000000000','0.007780000000000','0.711908500000000','0.701983286438530','90.22921419518379','90.229214195183786','test'),('2018-10-22 07:59:59','2018-10-22 11:59:59','ADABNB','4h','0.007800000000000','0.007810000000000','0.711908500000000','0.712821203205128','91.27032051282052','91.270320512820518','test'),('2018-11-04 15:59:59','2018-11-08 03:59:59','ADABNB','4h','0.007850000000000','0.007840000000000','0.711908500000000','0.711001610191083','90.68898089171977','90.688980891719766','test'),('2018-11-11 11:59:59','2018-11-13 23:59:59','ADABNB','4h','0.008050000000000','0.007940000000000','0.711908500000000','0.702180557763975','88.43583850931678','88.435838509316781','test'),('2018-11-29 15:59:59','2018-11-30 11:59:59','ADABNB','4h','0.007900000000000','0.007610000000000','0.711908500000000','0.685775150000000','90.115','90.114999999999995','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','ADABNB','4h','0.007650000000000','0.007670000000000','0.711908500000000','0.713769698692810','93.05993464052288','93.059934640522883','test'),('2018-12-01 15:59:59','2018-12-02 19:59:59','ADABNB','4h','0.007750000000000','0.007870000000000','0.711908500000000','0.722931599354839','91.85916129032259','91.859161290322589','test'),('2018-12-02 23:59:59','2018-12-03 15:59:59','ADABNB','4h','0.007940000000000','0.007630000000000','0.711908500000000','0.684113583753149','89.66102015113351','89.661020151133513','test'),('2018-12-19 11:59:59','2018-12-19 15:59:59','ADABNB','4h','0.006620000000000','0.006410000000000','0.711908500000000','0.689325299848943','107.53904833836859','107.539048338368588','test'),('2018-12-20 15:59:59','2018-12-25 15:59:59','ADABNB','4h','0.006500000000000','0.007130000000000','0.711908500000000','0.780908862307692','109.52438461538463','109.524384615384633','test'),('2018-12-25 19:59:59','2018-12-26 15:59:59','ADABNB','4h','0.007410000000000','0.007210000000000','0.711908500000000','0.692693695681512','96.07402159244265','96.074021592442648','test'),('2018-12-30 15:59:59','2018-12-31 03:59:59','ADABNB','4h','0.007320000000000','0.006950000000000','0.711908500000000','0.675924053961749','97.25525956284153','97.255259562841530','test'),('2019-01-02 19:59:59','2019-01-04 15:59:59','ADABNB','4h','0.007330000000000','0.007080000000000','0.711908500000000','0.687627855388813','97.12257844474762','97.122578444747617','test'),('2019-01-04 23:59:59','2019-01-05 07:59:59','ADABNB','4h','0.007270000000000','0.007150000000000','0.711908500000000','0.700157603163686','97.92414030261348','97.924140302613480','test'),('2019-01-05 15:59:59','2019-01-08 11:59:59','ADABNB','4h','0.007250000000000','0.007500000000000','0.711908500000000','0.736457068965517','98.19427586206896','98.194275862068963','test'),('2019-01-09 15:59:59','2019-01-10 15:59:59','ADABNB','4h','0.007910000000000','0.007430000000000','0.711908500000000','0.668707984197219','90.00107458912768','90.001074589127683','test'),('2019-03-19 19:59:59','2019-03-24 11:59:59','ADABNB','4h','0.003410000000000','0.003600000000000','0.711908500000000','0.751574956011730','208.77082111436954','208.770821114369539','test'),('2019-03-24 15:59:59','2019-03-24 19:59:59','ADABNB','4h','0.003660000000000','0.003550000000000','0.711908500000000','0.690512342896175','194.51051912568306','194.510519125683061','test'),('2019-03-26 23:59:59','2019-03-31 11:59:59','ADABNB','4h','0.003810000000000','0.004090000000000','0.711908500000000','0.764227234908136','186.85262467191603','186.852624671916033','test'),('2019-04-02 15:59:59','2019-04-09 11:59:59','ADABNB','4h','0.004240000000000','0.004620000000000','0.711908500000000','0.775711620283019','167.90294811320757','167.902948113207572','test'),('2019-04-10 15:59:59','2019-04-12 07:59:59','ADABNB','4h','0.004800000000000','0.004670000000000','0.711908500000000','0.692627644791667','148.31427083333335','148.314270833333353','test'),('2019-05-09 15:59:59','2019-05-13 07:59:59','ADABNB','4h','0.003160000000000','0.003150000000000','0.711908500000000','0.709655625000000','225.28750000000002','225.287500000000023','test'),('2019-05-14 19:59:59','2019-05-15 02:59:59','ADABNB','4h','0.003420000000000','0.003370000000000','0.711908500000000','0.701500480994152','208.1603801169591','208.160380116959089','test'),('2019-05-15 19:59:59','2019-05-16 23:59:59','ADABNB','4h','0.003390000000000','0.003350000000000','0.711908500000000','0.703508399705015','210.0025073746313','210.002507374631307','test'),('2019-05-17 03:59:59','2019-05-17 07:59:59','ADABNB','4h','0.003360000000000','0.003230000000000','0.711908500000000','0.684364421130952','211.87752976190478','211.877529761904782','test'),('2019-05-30 07:59:59','2019-05-30 23:59:59','ADABNB','4h','0.002790000000000','0.002660000000000','0.711908500000000','0.678737136200717','255.16433691756274','255.164336917562736','test'),('2019-05-31 03:59:59','2019-05-31 07:59:59','ADABNB','4h','0.002670000000000','0.002650000000000','0.711908500000000','0.706575852059925','266.6323970037453','266.632397003745325','test'),('2019-06-02 03:59:59','2019-06-04 11:59:59','ADABNB','4h','0.002820000000000','0.002770000000000','0.711908500000000','0.699286008865248','252.44982269503546','252.449822695035465','test'),('2019-06-12 23:59:59','2019-06-13 03:59:59','ADABNB','4h','0.002770000000000','0.002690000000000','0.711908500000000','0.691347965703971','257.006678700361','257.006678700361022','test'),('2019-06-14 23:59:59','2019-06-15 11:59:59','ADABNB','4h','0.002780000000000','0.002710000000000','0.711908500000000','0.693982746402878','256.08219424460435','256.082194244604352','test'),('2019-06-15 15:59:59','2019-06-17 07:59:59','ADABNB','4h','0.002780000000000','0.002730000000000','0.711908500000000','0.699104390287770','256.08219424460435','256.082194244604352','test'),('2019-06-17 11:59:59','2019-06-17 15:59:59','ADABNB','4h','0.002790000000000','0.002720000000000','0.711908500000000','0.694046996415771','255.16433691756274','255.164336917562736','test'),('2019-06-25 15:59:59','2019-06-27 11:59:59','ADABNB','4h','0.002620000000000','0.002680000000000','0.711908500000000','0.728211748091603','271.7208015267176','271.720801526717594','test'),('2019-07-26 19:59:59','2019-07-31 15:59:59','ADABNB','4h','0.002158000000000','0.002174000000000','0.711908500000000','0.717186783595922','329.8927247451344','329.892724745134387','test'),('2019-08-22 15:59:59','2019-08-26 07:59:59','ADABNB','4h','0.001837000000000','0.001833000000000','0.711908500000000','0.710358345400109','387.53864997278174','387.538649972781741','test'),('2019-08-26 15:59:59','2019-08-28 19:59:59','ADABNB','4h','0.001920000000000','0.001953000000000','0.711908500000000','0.724144427343750','370.7856770833333','370.785677083333326','test'),('2019-08-28 23:59:59','2019-09-02 15:59:59','ADABNB','4h','0.001961000000000','0.002005000000000','0.711908500000000','0.727881969658338','363.0334013258542','363.033401325854186','test'),('2019-09-03 23:59:59','2019-09-05 15:59:59','ADABNB','4h','0.002088000000000','0.002020000000000','0.711908500000000','0.688723740421456','340.95234674329504','340.952346743295038','test'),('2019-09-08 03:59:59','2019-09-18 11:59:59','ADABNB','4h','0.002083000000000','0.002256000000000','0.711908500000000','0.771034842054729','341.77076332213153','341.770763322131529','test'),('2019-09-18 15:59:59','2019-09-22 11:59:59','ADABNB','4h','0.002479000000000','0.002371000000000','0.711908500000000','0.680893527027027','287.17567567567573','287.175675675675734','test'),('2019-09-23 15:59:59','2019-09-24 03:59:59','ADABNB','4h','0.002479000000000','0.002406000000000','0.711908500000000','0.690944675675676','287.17567567567573','287.175675675675734','test'),('2019-09-25 23:59:59','2019-09-28 23:59:59','ADABNB','4h','0.002443000000000','0.002457000000000','0.711908500000000','0.715988204871060','291.40749079001233','291.407490790012332','test'),('2019-09-30 11:59:59','2019-10-01 03:59:59','ADABNB','4h','0.002519000000000','0.002442000000000','0.711908500000000','0.690147104803494','282.61552203255263','282.615522032552633','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:10:21
