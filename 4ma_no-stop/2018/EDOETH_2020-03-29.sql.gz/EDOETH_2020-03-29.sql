-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 07:59:59','2018-07-04 11:59:59','EDOETH','4h','0.002080000000000','0.002107000000000','0.072144500000000','0.073080991105769','34.68485576923077','34.684855769230772','test'),('2018-07-05 03:59:59','2018-07-05 23:59:59','EDOETH','4h','0.002171000000000','0.002108000000000','0.072378622776442','0.070278275823464','33.338840523464874','33.338840523464874','test'),('2018-07-17 07:59:59','2018-07-20 11:59:59','EDOETH','4h','0.002081000000000','0.002125000000000','0.072378622776442','0.073908973282047','34.78069330919846','34.780693309198462','test'),('2018-08-11 15:59:59','2018-08-16 07:59:59','EDOETH','4h','0.002112000000000','0.002162000000000','0.072378622776442','0.074092131838384','34.27018123884564','34.270181238845637','test'),('2018-08-17 15:59:59','2018-08-22 23:59:59','EDOETH','4h','0.002315000000000','0.002850000000000','0.072664500930085','0.089457376954964','31.388553317531105','31.388553317531105','test'),('2018-08-23 19:59:59','2018-08-29 15:59:59','EDOETH','4h','0.002985000000000','0.003098000000000','0.076862719936304','0.079772430942268','25.749654920034928','25.749654920034928','test'),('2018-08-31 03:59:59','2018-09-01 03:59:59','EDOETH','4h','0.003269000000000','0.003185000000000','0.077590147687795','0.075596396569479','23.735132360904025','23.735132360904025','test'),('2018-09-05 23:59:59','2018-09-06 03:59:59','EDOETH','4h','0.003268000000000','0.003128000000000','0.077590147687795','0.074266212352333','23.742395253303243','23.742395253303243','test'),('2018-09-06 07:59:59','2018-09-13 15:59:59','EDOETH','4h','0.003167000000000','0.003636000000000','0.077590147687795','0.089080447424320','24.499572998988','24.499572998988000','test'),('2018-09-18 11:59:59','2018-09-18 15:59:59','EDOETH','4h','0.003549000000000','0.003511000000000','0.079133301008482','0.078286001645754','22.29735165074162','22.297351650741621','test'),('2018-09-19 03:59:59','2018-09-21 19:59:59','EDOETH','4h','0.003892000000000','0.003573000000000','0.079133301008482','0.072647298176595','20.332297278643882','20.332297278643882','test'),('2018-09-21 23:59:59','2018-09-23 07:59:59','EDOETH','4h','0.003846000000000','0.003822000000000','0.079133301008482','0.078639489457727','20.57548128145658','20.575481281456579','test'),('2018-09-25 07:59:59','2018-09-27 19:59:59','EDOETH','4h','0.003991000000000','0.003751000000000','0.079133301008482','0.074374595861392','19.827938112874467','19.827938112874467','test'),('2018-09-28 19:59:59','2018-09-29 11:59:59','EDOETH','4h','0.004021000000000','0.003735000000000','0.079133301008482','0.073504819514220','19.68000522469087','19.680005224690870','test'),('2018-10-01 19:59:59','2018-10-01 23:59:59','EDOETH','4h','0.004186000000000','0.003818000000000','0.079133301008482','0.072176527293451','18.904276399541807','18.904276399541807','test'),('2018-10-02 03:59:59','2018-10-02 07:59:59','EDOETH','4h','0.003854000000000','0.003842000000000','0.079133301008482','0.078886907751580','20.532771408531914','20.532771408531914','test'),('2018-10-02 15:59:59','2018-10-08 03:59:59','EDOETH','4h','0.003946000000000','0.004618000000000','0.079133301008482','0.092609625964818','20.05405499454688','20.054054994546881','test'),('2018-10-08 15:59:59','2018-10-10 11:59:59','EDOETH','4h','0.004976000000000','0.004877000000000','0.079133301008482','0.077558904545492','15.902994575659564','15.902994575659564','test'),('2018-10-10 15:59:59','2018-10-11 11:59:59','EDOETH','4h','0.004958000000000','0.004739000000000','0.079133301008482','0.075637901064783','15.960730336523195','15.960730336523195','test'),('2018-10-11 23:59:59','2018-10-12 19:59:59','EDOETH','4h','0.005106000000000','0.004836000000000','0.079133301008482','0.074948813881124','15.498100471696434','15.498100471696434','test'),('2018-10-13 15:59:59','2018-10-15 07:59:59','EDOETH','4h','0.005215000000000','0.004800000000000','0.079133301008482','0.072836020103684','15.174170854934227','15.174170854934227','test'),('2018-10-17 23:59:59','2018-10-25 11:59:59','EDOETH','4h','0.005209000000000','0.005959000000000','0.079133301008482','0.090527037955374','15.19164926252294','15.191649262522940','test'),('2018-10-27 23:59:59','2018-10-28 11:59:59','EDOETH','4h','0.006107000000000','0.005904000000000','0.079133301008482','0.076502867063055','12.957802686831833','12.957802686831833','test'),('2018-10-31 19:59:59','2018-11-05 11:59:59','EDOETH','4h','0.006111000000000','0.006070000000000','0.079133301008482','0.078602378844949','12.949321061770904','12.949321061770904','test'),('2018-11-07 19:59:59','2018-11-08 07:59:59','EDOETH','4h','0.006529000000000','0.006365000000000','0.079133301008482','0.077145575267114','12.120278910779904','12.120278910779904','test'),('2018-11-08 15:59:59','2018-11-08 19:59:59','EDOETH','4h','0.006400000000000','0.006287000000000','0.079133301008482','0.077736103662551','12.36457828257531','12.364578282575311','test'),('2018-11-09 03:59:59','2018-11-09 07:59:59','EDOETH','4h','0.006381000000000','0.006308000000000','0.079133301008482','0.078227999179048','12.401394923755209','12.401394923755209','test'),('2018-11-09 23:59:59','2018-11-10 03:59:59','EDOETH','4h','0.006397000000000','0.006384000000000','0.079133301008482','0.078972486108824','12.370376896745661','12.370376896745661','test'),('2018-11-11 03:59:59','2018-11-11 07:59:59','EDOETH','4h','0.006407000000000','0.006370000000000','0.079133301008482','0.078676311444362','12.35106930052786','12.351069300527859','test'),('2018-11-11 15:59:59','2018-11-11 19:59:59','EDOETH','4h','0.006409000000000','0.006293000000000','0.079133301008482','0.077701024067152','12.347215011465439','12.347215011465439','test'),('2018-11-14 11:59:59','2018-11-14 19:59:59','EDOETH','4h','0.006440000000000','0.005852000000000','0.079133301008482','0.071908086568577','12.287779659702172','12.287779659702172','test'),('2018-11-22 07:59:59','2018-11-23 23:59:59','EDOETH','4h','0.006162000000000','0.006221000000000','0.079133301008482','0.079890987597171','12.842145570996754','12.842145570996754','test'),('2018-11-24 07:59:59','2018-11-24 19:59:59','EDOETH','4h','0.006188000000000','0.006208000000000','0.079133301008482','0.079389064748005','12.788186976160633','12.788186976160633','test'),('2018-11-24 23:59:59','2018-11-27 23:59:59','EDOETH','4h','0.006404000000000','0.006400000000000','0.079133301008482','0.079083873587490','12.356855248045283','12.356855248045283','test'),('2018-11-29 03:59:59','2018-12-02 03:59:59','EDOETH','4h','0.006653000000000','0.006683000000000','0.079133301008482','0.079490132367306','11.89437862745859','11.894378627458590','test'),('2018-12-03 19:59:59','2018-12-07 19:59:59','EDOETH','4h','0.006781000000000','0.006706000000000','0.079133301008482','0.078258061725834','11.669857101973456','11.669857101973456','test'),('2018-12-07 23:59:59','2018-12-08 03:59:59','EDOETH','4h','0.006929000000000','0.006905000000000','0.079133301008482','0.078859206734531','11.420594747940827','11.420594747940827','test'),('2018-12-09 23:59:59','2018-12-12 11:59:59','EDOETH','4h','0.007261000000000','0.007235000000000','0.079133301008482','0.078849942541849','10.898402562798788','10.898402562798788','test'),('2018-12-12 19:59:59','2018-12-16 19:59:59','EDOETH','4h','0.007800000000000','0.007925000000000','0.079133301008482','0.080401462883618','10.145295001087435','10.145295001087435','test'),('2018-12-16 23:59:59','2018-12-17 07:59:59','EDOETH','4h','0.008034000000000','0.007808000000000','0.079133301008482','0.076907245988826','9.84980097192955','9.849800971929550','test'),('2018-12-18 19:59:59','2018-12-18 23:59:59','EDOETH','4h','0.007948000000000','0.007493000000000','0.079133301008482','0.074603148522465','9.9563790901462','9.956379090146200','test'),('2019-01-07 23:59:59','2019-01-14 11:59:59','EDOETH','4h','0.006034000000000','0.006471000000000','0.079133301008482','0.084864367057654','13.114567618243619','13.114567618243619','test'),('2019-01-16 15:59:59','2019-01-22 11:59:59','EDOETH','4h','0.006598000000000','0.006847000000000','0.079133301008482','0.082119689603679','11.993528494768414','11.993528494768414','test'),('2019-02-27 07:59:59','2019-02-27 15:59:59','EDOETH','4h','0.005638000000000','0.005722000000000','0.079133301008482','0.080312300172142','14.035704329280241','14.035704329280241','test'),('2019-02-27 19:59:59','2019-02-28 03:59:59','EDOETH','4h','0.005766000000000','0.005625000000000','0.079133301008482','0.077198199474976','13.724124351106832','13.724124351106832','test'),('2019-02-28 11:59:59','2019-02-28 15:59:59','EDOETH','4h','0.005493000000000','0.005527000000000','0.079133301008482','0.079623112083357','14.406208084558893','14.406208084558893','test'),('2019-02-28 19:59:59','2019-03-05 15:59:59','EDOETH','4h','0.005617000000000','0.005766000000000','0.079133301008482','0.081232439667956','14.088178922642337','14.088178922642337','test'),('2019-03-09 03:59:59','2019-03-09 07:59:59','EDOETH','4h','0.005869000000000','0.005795000000000','0.079133301008482','0.078135539162405','13.483268190233769','13.483268190233769','test'),('2019-03-09 15:59:59','2019-03-11 23:59:59','EDOETH','4h','0.005821000000000','0.006283000000000','0.079133301008482','0.085413937508382','13.59445129848514','13.594451298485140','test'),('2019-03-12 11:59:59','2019-03-15 07:59:59','EDOETH','4h','0.006082000000000','0.006039000000000','0.079133301008482','0.078573825187475','13.011065604814535','13.011065604814535','test'),('2019-05-04 07:59:59','2019-05-06 15:59:59','EDOETH','4h','0.003583000000000','0.003491000000000','0.079133301008482','0.077101410499752','22.085766399241418','22.085766399241418','test'),('2019-05-23 11:59:59','2019-05-27 03:59:59','EDOETH','4h','0.002924000000000','0.003083000000000','0.079133301008482','0.083436377226111','27.06337243792134','27.063372437921341','test'),('2019-05-27 11:59:59','2019-05-30 07:59:59','EDOETH','4h','0.003363000000000','0.003280000000000','0.079133301008482','0.077180263844133','23.53056824516265','23.530568245162652','test'),('2019-05-31 15:59:59','2019-05-31 19:59:59','EDOETH','4h','0.003422000000000','0.003364000000000','0.079133301008482','0.077792058618508','23.124868792659846','23.124868792659846','test'),('2019-06-08 15:59:59','2019-06-11 07:59:59','EDOETH','4h','0.003383000000000','0.003362000000000','0.079133301008482','0.078642080399207','23.391457584535026','23.391457584535026','test'),('2019-06-11 15:59:59','2019-06-11 23:59:59','EDOETH','4h','0.003498000000000','0.003491000000000','0.079133301008482','0.078974943916698','22.622441683385365','22.622441683385365','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  4:53:31
