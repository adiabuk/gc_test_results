-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-02 11:59:59','2018-07-05 15:59:59','LUNBTC','4h','0.001192400000000','0.001174600000000','0.001467500000000','0.001445593341161','1.2307111707480713','1.230711170748071','test'),('2018-07-07 23:59:59','2018-07-10 03:59:59','LUNBTC','4h','0.001241200000000','0.001189600000000','0.001467500000000','0.001406492104415','1.1823235578472446','1.182323557847245','test'),('2018-08-29 07:59:59','2018-08-30 11:59:59','LUNBTC','4h','0.000515400000000','0.000494800000000','0.001467500000000','0.001408845556849','2.847303065580132','2.847303065580132','test'),('2018-08-31 03:59:59','2018-08-31 15:59:59','LUNBTC','4h','0.000525400000000','0.000500800000000','0.001467500000000','0.001398789493719','2.793110011419871','2.793110011419871','test'),('2018-08-31 19:59:59','2018-08-31 23:59:59','LUNBTC','4h','0.000504000000000','0.000501200000000','0.001467500000000','0.001459347222222','2.9117063492063493','2.911706349206349','test'),('2018-09-01 03:59:59','2018-09-02 11:59:59','LUNBTC','4h','0.000511800000000','0.000503100000000','0.001467500000000','0.001442554220399','2.8673309886674483','2.867330988667448','test'),('2018-09-02 15:59:59','2018-09-02 19:59:59','LUNBTC','4h','0.000506500000000','0.000514000000000','0.001467500000000','0.001489230009872','2.897334649555775','2.897334649555775','test'),('2018-09-04 19:59:59','2018-09-05 11:59:59','LUNBTC','4h','0.000516700000000','0.000463300000000','0.001467500000000','0.001315836558932','2.840139345848655','2.840139345848655','test'),('2018-09-17 23:59:59','2018-09-23 23:59:59','LUNBTC','4h','0.000424400000000','0.000459200000000','0.001467500000000','0.001587832233742','3.457822808671065','3.457822808671065','test'),('2018-09-26 15:59:59','2018-10-03 03:59:59','LUNBTC','4h','0.000477600000000','0.000507700000000','0.001467500000000','0.001559986913735','3.0726549413735342','3.072654941373534','test'),('2018-10-04 23:59:59','2018-10-11 07:59:59','LUNBTC','4h','0.000534900000000','0.000560000000000','0.001467500000000','0.001536361936811','2.7435034585903906','2.743503458590391','test'),('2018-10-13 19:59:59','2018-10-15 07:59:59','LUNBTC','4h','0.000601100000000','0.000581300000000','0.001467500000000','0.001419161121278','2.4413575112294126','2.441357511229413','test'),('2018-10-16 11:59:59','2018-10-24 11:59:59','LUNBTC','4h','0.000616900000000','0.000744900000000','0.001467500000000','0.001771990192900','2.3788296320311235','2.378829632031124','test'),('2018-11-02 03:59:59','2018-11-03 11:59:59','LUNBTC','4h','0.000708300000000','0.000671500000000','0.001508630226509','0.001430248760555','2.129931140066003','2.129931140066003','test'),('2018-11-29 11:59:59','2018-11-30 11:59:59','LUNBTC','4h','0.000468000000000','0.000425300000000','0.001508630226509','0.001370983836184','3.223568860061966','3.223568860061966','test'),('2018-12-04 07:59:59','2018-12-05 03:59:59','LUNBTC','4h','0.000456400000000','0.000437100000000','0.001508630226509','0.001444834075388','3.3055000580828224','3.305500058082822','test'),('2018-12-05 07:59:59','2018-12-05 11:59:59','LUNBTC','4h','0.000445100000000','0.000448000000000','0.001508630226509','0.001518459540499','3.389418617184903','3.389418617184903','test'),('2018-12-05 15:59:59','2018-12-05 19:59:59','LUNBTC','4h','0.000448400000000','0.000436300000000','0.001508630226509','0.001467920088818','3.364474189359947','3.364474189359947','test'),('2018-12-18 03:59:59','2018-12-19 23:59:59','LUNBTC','4h','0.000414200000000','0.000406700000000','0.001508630226509','0.001481313165430','3.642274810499759','3.642274810499759','test'),('2018-12-21 23:59:59','2018-12-25 03:59:59','LUNBTC','4h','0.000420500000000','0.000408600000000','0.001508630226509','0.001465936529255','3.5877056516266355','3.587705651626635','test'),('2018-12-27 07:59:59','2018-12-27 15:59:59','LUNBTC','4h','0.000450000000000','0.000420800000000','0.001508630226509','0.001410736887367','3.352511614464445','3.352511614464445','test'),('2019-01-09 03:59:59','2019-01-09 07:59:59','LUNBTC','4h','0.000416900000000','0.000416500000000','0.001508630226509','0.001507182752077','3.6186860794171265','3.618686079417126','test'),('2019-01-09 19:59:59','2019-01-09 23:59:59','LUNBTC','4h','0.000414100000000','0.000411000000000','0.001508630226509','0.001497336447948','3.643154374568945','3.643154374568945','test'),('2019-01-10 03:59:59','2019-01-10 07:59:59','LUNBTC','4h','0.000414000000000','0.000405100000000','0.001508630226509','0.001476198320673','3.6440343635483097','3.644034363548310','test'),('2019-01-17 11:59:59','2019-01-20 23:59:59','LUNBTC','4h','0.000413400000000','0.000445700000000','0.001508630226509','0.001626503367090','3.649323237805999','3.649323237805999','test'),('2019-01-21 15:59:59','2019-01-25 07:59:59','LUNBTC','4h','0.000480900000000','0.000602700000000','0.001508630226509','0.001890728711826','3.137097580596798','3.137097580596798','test'),('2019-02-11 07:59:59','2019-02-12 03:59:59','LUNBTC','4h','0.000492800000000','0.000474000000000','0.001508630226509','0.001451076962998','3.0613438037926133','3.061343803792613','test'),('2019-02-12 07:59:59','2019-02-12 11:59:59','LUNBTC','4h','0.000477000000000','0.000472900000000','0.001508630226509','0.001495662964604','3.1627468060985326','3.162746806098533','test'),('2019-02-17 19:59:59','2019-02-18 03:59:59','LUNBTC','4h','0.000533200000000','0.000472900000000','0.001508630226509','0.001338018068485','2.8293890219598654','2.829389021959865','test'),('2019-02-18 07:59:59','2019-02-18 11:59:59','LUNBTC','4h','0.000474900000000','0.000481200000000','0.001508630226509','0.001528643640758','3.1767324205285323','3.176732420528532','test'),('2019-02-19 19:59:59','2019-02-19 23:59:59','LUNBTC','4h','0.000484100000000','0.000473400000000','0.001508630226509','0.001475285166762','3.1163607240425533','3.116360724042553','test'),('2019-02-20 11:59:59','2019-02-21 11:59:59','LUNBTC','4h','0.000482400000000','0.000469200000000','0.001508630226509','0.001467349299913','3.1273429239407133','3.127342923940713','test'),('2019-02-22 15:59:59','2019-02-24 15:59:59','LUNBTC','4h','0.000482400000000','0.000490200000000','0.001508630226509','0.001533023501316','3.1273429239407133','3.127342923940713','test'),('2019-02-26 11:59:59','2019-02-28 11:59:59','LUNBTC','4h','0.000591500000000','0.000519900000000','0.001508630226509','0.001326013279395','2.550516021147929','2.550516021147929','test'),('2019-03-01 15:59:59','2019-03-02 11:59:59','LUNBTC','4h','0.000582200000000','0.000539200000000','0.001508630226509','0.001397206145884','2.5912576889539682','2.591257688953968','test'),('2019-03-06 07:59:59','2019-03-06 11:59:59','LUNBTC','4h','0.000539100000000','0.000533500000000','0.001508630226509','0.001492959053687','2.7984237182507883','2.798423718250788','test'),('2019-03-06 15:59:59','2019-03-08 23:59:59','LUNBTC','4h','0.000544500000000','0.000543900000000','0.001508630226509','0.001506967824056','2.7706707557557397','2.770670755755740','test'),('2019-03-09 23:59:59','2019-03-12 01:59:59','LUNBTC','4h','0.000570300000000','0.000573800000000','0.001508630226509','0.001517888872472','2.6453274180413815','2.645327418041381','test'),('2019-03-12 11:59:59','2019-03-16 03:59:59','LUNBTC','4h','0.000640900000000','0.000635200000000','0.001508630226509','0.001495212856730','2.353924522560462','2.353924522560462','test'),('2019-03-21 03:59:59','2019-03-21 15:59:59','LUNBTC','4h','0.000686500000000','0.000624100000000','0.001508630226509','0.001371502001987','2.1975677006686087','2.197567700668609','test'),('2019-03-21 19:59:59','2019-03-21 23:59:59','LUNBTC','4h','0.000627400000000','0.000639000000000','0.001508630226509','0.001536523294133','2.404574795200829','2.404574795200829','test'),('2019-03-22 07:59:59','2019-03-22 11:59:59','LUNBTC','4h','0.000627300000000','0.000630100000000','0.001508630226509','0.001515364109235','2.4049581165455125','2.404958116545513','test'),('2019-03-22 15:59:59','2019-03-24 07:59:59','LUNBTC','4h','0.000640500000000','0.000628000000000','0.001508630226509','0.001479187794298','2.355394576907104','2.355394576907104','test'),('2019-03-26 11:59:59','2019-04-01 19:59:59','LUNBTC','4h','0.000670800000000','0.000713900000000','0.001508630226509','0.001605562192464','2.24900153027579','2.249001530275790','test'),('2019-05-22 15:59:59','2019-05-24 15:59:59','LUNBTC','4h','0.000391700000000','0.000344600000000','0.001508630226509','0.001327224855897','3.851494068187389','3.851494068187389','test'),('2019-06-06 11:59:59','2019-06-06 19:59:59','LUNBTC','4h','0.000319200000000','0.000315700000000','0.001508630226509','0.001492088228411','4.726285170767544','4.726285170767544','test'),('2019-06-07 15:59:59','2019-06-09 23:59:59','LUNBTC','4h','0.000314700000000','0.000315900000000','0.001508630226509','0.001514382867983','4.793867894849063','4.793867894849063','test'),('2019-06-10 03:59:59','2019-06-11 11:59:59','LUNBTC','4h','0.000318900000000','0.000317300000000','0.001508630226509','0.001501061056354','4.730731346845406','4.730731346845406','test'),('2019-06-11 15:59:59','2019-06-13 19:59:59','LUNBTC','4h','0.000322400000000','0.000325200000000','0.001508630226509','0.001521732474134','4.679374151702854','4.679374151702854','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  4:35:22
