-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-03 11:59:59','2018-06-04 03:59:59','TNTBTC','4h','0.000010790000000','0.000010380000000','0.001467500000000','0.001411737720111','136.0055607043559','136.005560704355901','test'),('2018-07-03 15:59:59','2018-07-03 23:59:59','TNTBTC','4h','0.000007470000000','0.000007140000000','0.001467500000000','0.001402670682731','196.45247657295852','196.452476572958517','test'),('2018-07-04 00:22:27','2018-07-04 11:59:59','TNTBTC','4h','0.000007170000000','0.000007370000000','0.001467500000000','0.001508434449093','204.67224546722454','204.672245467224542','test'),('2018-07-04 15:59:59','2018-07-06 07:59:59','TNTBTC','4h','0.000007650000000','0.000006880000000','0.001467500000000','0.001319790849673','191.83006535947715','191.830065359477146','test'),('2018-08-28 15:59:59','2018-09-02 11:59:59','TNTBTC','4h','0.000003110000000','0.000003110000000','0.001467500000000','0.001467500000000','471.86495176848877','471.864951768488766','test'),('2018-09-02 19:59:59','2018-09-02 23:59:59','TNTBTC','4h','0.000003330000000','0.000003260000000','0.001467500000000','0.001436651651652','440.6906906906907','440.690690690690701','test'),('2018-09-15 23:59:59','2018-09-18 19:59:59','TNTBTC','4h','0.000003660000000','0.000003860000000','0.001467500000000','0.001547691256831','400.95628415300547','400.956284153005470','test'),('2018-09-21 03:59:59','2018-09-22 03:59:59','TNTBTC','4h','0.000004310000000','0.000003790000000','0.001467500000000','0.001290446635731','340.48723897911833','340.487238979118331','test'),('2018-09-22 15:59:59','2018-09-24 11:59:59','TNTBTC','4h','0.000004300000000','0.000003950000000','0.001467500000000','0.001348052325581','341.27906976744185','341.279069767441854','test'),('2018-09-24 19:59:59','2018-09-24 23:59:59','TNTBTC','4h','0.000004230000000','0.000004090000000','0.001467500000000','0.001418930260047','346.92671394799055','346.926713947990550','test'),('2018-09-28 07:59:59','2018-09-29 03:59:59','TNTBTC','4h','0.000004300000000','0.000003980000000','0.001467500000000','0.001358290697674','341.27906976744185','341.279069767441854','test'),('2018-09-29 11:59:59','2018-10-07 15:59:59','TNTBTC','4h','0.000004030000000','0.000004440000000','0.001467500000000','0.001616799007444','364.1439205955335','364.143920595533473','test'),('2018-10-08 23:59:59','2018-10-09 11:59:59','TNTBTC','4h','0.000004590000000','0.000004430000000','0.001467500000000','0.001416345315904','319.71677559912854','319.716775599128539','test'),('2018-10-10 23:59:59','2018-10-11 03:59:59','TNTBTC','4h','0.000004630000000','0.000004360000000','0.001467500000000','0.001381922246220','316.95464362850976','316.954643628509757','test'),('2018-10-15 03:59:59','2018-10-15 07:59:59','TNTBTC','4h','0.000004350000000','0.000004300000000','0.001467500000000','0.001450632183908','337.35632183908046','337.356321839080465','test'),('2018-10-15 11:59:59','2018-10-15 19:59:59','TNTBTC','4h','0.000004380000000','0.000004270000000','0.001467500000000','0.001430644977169','335.0456621004566','335.045662100456582','test'),('2018-10-15 23:59:59','2018-10-16 03:59:59','TNTBTC','4h','0.000004410000000','0.000004350000000','0.001467500000000','0.001447534013605','332.76643990929705','332.766439909297048','test'),('2018-10-16 07:59:59','2018-10-18 23:59:59','TNTBTC','4h','0.000004550000000','0.000004640000000','0.001467500000000','0.001496527472527','322.5274725274726','322.527472527472582','test'),('2018-10-20 15:59:59','2018-10-22 07:59:59','TNTBTC','4h','0.000004910000000','0.000004680000000','0.001467500000000','0.001398757637475','298.8798370672098','298.879837067209792','test'),('2018-10-23 03:59:59','2018-10-27 07:59:59','TNTBTC','4h','0.000004870000000','0.000005390000000','0.001467500000000','0.001624194045175','301.3347022587269','301.334702258726907','test'),('2018-10-30 19:59:59','2018-10-31 07:59:59','TNTBTC','4h','0.000005870000000','0.000005350000000','0.001467500000000','0.001337500000000','250.00000000000003','250.000000000000028','test'),('2018-10-31 11:59:59','2018-10-31 15:59:59','TNTBTC','4h','0.000005360000000','0.000005370000000','0.001467500000000','0.001470237873134','273.7873134328358','273.787313432835788','test'),('2018-10-31 19:59:59','2018-11-01 11:59:59','TNTBTC','4h','0.000005440000000','0.000005390000000','0.001467500000000','0.001454011948529','269.76102941176475','269.761029411764753','test'),('2018-11-01 15:59:59','2018-11-04 07:59:59','TNTBTC','4h','0.000005430000000','0.000005380000000','0.001467500000000','0.001453987108656','270.25782688766117','270.257826887661167','test'),('2018-11-10 07:59:59','2018-11-11 19:59:59','TNTBTC','4h','0.000005550000000','0.000005430000000','0.001467500000000','0.001435770270270','264.4144144144144','264.414414414414409','test'),('2018-11-30 07:59:59','2018-12-03 03:59:59','TNTBTC','4h','0.000003990000000','0.000003950000000','0.001467500000000','0.001452788220551','367.7944862155389','367.794486215538882','test'),('2018-12-14 03:59:59','2018-12-15 03:59:59','TNTBTC','4h','0.000003790000000','0.000003560000000','0.001467500000000','0.001378443271768','387.2031662269129','387.203166226912913','test'),('2018-12-15 07:59:59','2018-12-15 11:59:59','TNTBTC','4h','0.000003740000000','0.000003690000000','0.001467500000000','0.001447881016043','392.379679144385','392.379679144385022','test'),('2018-12-17 15:59:59','2018-12-17 19:59:59','TNTBTC','4h','0.000003860000000','0.000003720000000','0.001467500000000','0.001414274611399','380.18134715025906','380.181347150259057','test'),('2019-01-06 19:59:59','2019-01-07 23:59:59','TNTBTC','4h','0.000003360000000','0.000003180000000','0.001467500000000','0.001388883928571','436.7559523809524','436.755952380952408','test'),('2019-01-09 11:59:59','2019-01-10 07:59:59','TNTBTC','4h','0.000003410000000','0.000003160000000','0.001467500000000','0.001359912023460','430.3519061583578','430.351906158357792','test'),('2019-01-12 23:59:59','2019-01-13 19:59:59','TNTBTC','4h','0.000003410000000','0.000003140000000','0.001467500000000','0.001351304985337','430.3519061583578','430.351906158357792','test'),('2019-01-13 23:59:59','2019-01-14 03:59:59','TNTBTC','4h','0.000003190000000','0.000003230000000','0.001467500000000','0.001485901253918','460.0313479623825','460.031347962382483','test'),('2019-01-14 19:59:59','2019-01-18 11:59:59','TNTBTC','4h','0.000003300000000','0.000004550000000','0.001467500000000','0.002023371212121','444.6969696969697','444.696969696969688','test'),('2019-01-21 19:59:59','2019-01-22 23:59:59','TNTBTC','4h','0.000004900000000','0.000004430000000','0.001467500000000','0.001326739795918','299.4897959183674','299.489795918367406','test'),('2019-01-25 15:59:59','2019-01-27 03:59:59','TNTBTC','4h','0.000004540000000','0.000004320000000','0.001467500000000','0.001396387665198','323.2378854625551','323.237885462555084','test'),('2019-02-10 19:59:59','2019-02-11 19:59:59','TNTBTC','4h','0.000004110000000','0.000004050000000','0.001467500000000','0.001446076642336','357.05596107055965','357.055961070559647','test'),('2019-02-20 11:59:59','2019-02-20 15:59:59','TNTBTC','4h','0.000003930000000','0.000003940000000','0.001467500000000','0.001471234096692','373.409669211196','373.409669211195990','test'),('2019-02-20 23:59:59','2019-02-21 11:59:59','TNTBTC','4h','0.000004070000000','0.000003930000000','0.001467500000000','0.001417020884521','360.56511056511056','360.565110565110558','test'),('2019-02-21 15:59:59','2019-02-21 23:59:59','TNTBTC','4h','0.000003960000000','0.000004020000000','0.001467500000000','0.001489734848485','370.5808080808081','370.580808080808083','test'),('2019-02-22 07:59:59','2019-02-24 03:59:59','TNTBTC','4h','0.000004060000000','0.000004130000000','0.001467500000000','0.001492801724138','361.45320197044333','361.453201970443331','test'),('2019-02-26 15:59:59','2019-02-27 15:59:59','TNTBTC','4h','0.000004190000000','0.000004000000000','0.001467500000000','0.001400954653938','350.2386634844869','350.238663484486892','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','TNTBTC','4h','0.000004040000000','0.000004050000000','0.001467500000000','0.001471132425743','363.24257425742576','363.242574257425758','test'),('2019-03-01 11:59:59','2019-03-01 15:59:59','TNTBTC','4h','0.000004100000000','0.000004020000000','0.001467500000000','0.001438865853659','357.92682926829275','357.926829268292749','test'),('2019-03-04 15:59:59','2019-03-04 23:59:59','TNTBTC','4h','0.000004190000000','0.000004290000000','0.001467500000000','0.001502523866348','350.2386634844869','350.238663484486892','test'),('2019-03-05 11:59:59','2019-03-05 19:59:59','TNTBTC','4h','0.000004250000000','0.000004210000000','0.001467500000000','0.001453688235294','345.29411764705884','345.294117647058840','test'),('2019-03-06 11:59:59','2019-03-06 15:59:59','TNTBTC','4h','0.000004120000000','0.000004150000000','0.001467500000000','0.001478185679612','356.1893203883495','356.189320388349472','test'),('2019-03-07 23:59:59','2019-03-08 03:59:59','TNTBTC','4h','0.000004160000000','0.000004150000000','0.001467500000000','0.001463972355769','352.7644230769231','352.764423076923094','test'),('2019-03-08 07:59:59','2019-03-11 15:59:59','TNTBTC','4h','0.000004210000000','0.000004270000000','0.001467500000000','0.001488414489311','348.5748218527316','348.574821852731588','test'),('2019-03-11 19:59:59','2019-03-11 23:59:59','TNTBTC','4h','0.000004280000000','0.000004710000000','0.001467500000000','0.001614935747664','342.873831775701','342.873831775700978','test'),('2019-03-12 11:59:59','2019-03-16 11:59:59','TNTBTC','4h','0.000004610000000','0.000004850000000','0.001467500000000','0.001543899132321','318.3297180043384','318.329718004338417','test'),('2019-03-20 11:59:59','2019-03-21 07:59:59','TNTBTC','4h','0.000004890000000','0.000004840000000','0.001467500000000','0.001452494887526','300.1022494887526','300.102249488752591','test'),('2019-03-26 23:59:59','2019-04-01 19:59:59','TNTBTC','4h','0.000005120000000','0.000005210000000','0.001467500000000','0.001493295898438','286.62109375','286.621093750000000','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:07:25
