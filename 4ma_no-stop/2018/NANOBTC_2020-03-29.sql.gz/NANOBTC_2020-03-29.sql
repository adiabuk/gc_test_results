-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-17 07:59:59','2018-08-29 03:59:59','NANOBTC','4h','0.000250300000000','0.000435500000000','0.001467500000000','0.002553321014782','5.8629644426687975','5.862964442668797','test'),('2018-08-31 19:59:59','2018-09-02 11:59:59','NANOBTC','4h','0.000442000000000','0.000414900000000','0.001738955253696','0.001632336051490','3.9342879042884618','3.934287904288462','test'),('2018-09-15 07:59:59','2018-09-17 15:59:59','NANOBTC','4h','0.000402800000000','0.000354000000000','0.001738955253696','0.001528277457320','4.317167958530288','4.317167958530288','test'),('2018-09-20 11:59:59','2018-09-20 23:59:59','NANOBTC','4h','0.000384200000000','0.000395800000000','0.001738955253696','0.001791458848029','4.526171925288912','4.526171925288912','test'),('2018-09-21 07:59:59','2018-09-22 03:59:59','NANOBTC','4h','0.000395900000000','0.000368200000000','0.001738955253696','0.001617285487272','4.39241034022733','4.392410340227330','test'),('2018-10-19 15:59:59','2018-10-20 03:59:59','NANOBTC','4h','0.000314700000000','0.000308300000000','0.001738955253696','0.001703590418540','5.525755493155386','5.525755493155386','test'),('2018-10-20 07:59:59','2018-10-22 03:59:59','NANOBTC','4h','0.000314400000000','0.000308200000000','0.001738955253696','0.001704662879100','5.531028160610687','5.531028160610687','test'),('2018-10-23 11:59:59','2018-10-23 23:59:59','NANOBTC','4h','0.000316900000000','0.000309500000000','0.001738955253696','0.001698348535875','5.487394300082045','5.487394300082045','test'),('2018-10-26 19:59:59','2018-10-27 15:59:59','NANOBTC','4h','0.000317900000000','0.000314600000000','0.001738955253696','0.001720903815076','5.470132915055049','5.470132915055049','test'),('2018-11-28 11:59:59','2018-11-28 19:59:59','NANOBTC','4h','0.000261900000000','0.000254700000000','0.001738955253696','0.001691148923697','6.639768055349369','6.639768055349369','test'),('2018-11-28 23:59:59','2018-11-29 03:59:59','NANOBTC','4h','0.000255000000000','0.000254800000000','0.001738955253696','0.001737591367223','6.819432367435293','6.819432367435293','test'),('2018-11-29 07:59:59','2018-11-30 11:59:59','NANOBTC','4h','0.000255500000000','0.000247400000000','0.001738955253696','0.001683825948197','6.806087098614482','6.806087098614482','test'),('2018-12-01 23:59:59','2018-12-02 07:59:59','NANOBTC','4h','0.000256500000000','0.000254300000000','0.001738955253696','0.001724040237875','6.7795526459883035','6.779552645988304','test'),('2018-12-19 03:59:59','2018-12-20 19:59:59','NANOBTC','4h','0.000258400000000','0.000249600000000','0.001738955253696','0.001679733867347','6.729702994179567','6.729702994179567','test'),('2018-12-20 23:59:59','2018-12-24 19:59:59','NANOBTC','4h','0.000251600000000','0.000263600000000','0.001738955253696','0.001821894296003','6.911586858887122','6.911586858887122','test'),('2018-12-24 23:59:59','2018-12-25 03:59:59','NANOBTC','4h','0.000263800000000','0.000253500000000','0.001738955253696','0.001671058213844','6.591945616739954','6.591945616739954','test'),('2019-01-09 23:59:59','2019-01-10 11:59:59','NANOBTC','4h','0.000256900000000','0.000241700000000','0.001738955253696','0.001636066503769','6.7689967057065','6.768996705706500','test'),('2019-01-10 15:59:59','2019-01-10 19:59:59','NANOBTC','4h','0.000244800000000','0.000243300000000','0.001738955253696','0.001728299890622','7.103575382745098','7.103575382745098','test'),('2019-01-20 11:59:59','2019-01-20 15:59:59','NANOBTC','4h','0.000243800000000','0.000244100000000','0.001738955253696','0.001741095067380','7.13271227931091','7.132712279310910','test'),('2019-01-21 03:59:59','2019-01-21 15:59:59','NANOBTC','4h','0.000246300000000','0.000247300000000','0.001738955253696','0.001746015567353','7.060313656906211','7.060313656906211','test'),('2019-01-21 19:59:59','2019-01-22 15:59:59','NANOBTC','4h','0.000248400000000','0.000246100000000','0.001738955253696','0.001722853816162','7.000625014879226','7.000625014879226','test'),('2019-01-22 19:59:59','2019-01-27 11:59:59','NANOBTC','4h','0.000250700000000','0.000268900000000','0.001738955253696','0.001865197717267','6.936399097311527','6.936399097311527','test'),('2019-02-13 23:59:59','2019-02-14 11:59:59','NANOBTC','4h','0.000236900000000','0.000232800000000','0.001738955253696','0.001708859362855','7.340461180650062','7.340461180650062','test'),('2019-02-18 03:59:59','2019-02-18 11:59:59','NANOBTC','4h','0.000236500000000','0.000232500000000','0.001738955253696','0.001709543748348','7.352876336980972','7.352876336980972','test'),('2019-02-18 15:59:59','2019-02-18 19:59:59','NANOBTC','4h','0.000234600000000','0.000235600000000','0.001738955253696','0.001746367680182','7.41242648634271','7.412426486342710','test'),('2019-02-24 07:59:59','2019-02-24 15:59:59','NANOBTC','4h','0.000238900000000','0.000230500000000','0.001738955253696','0.001677811577970','7.279009015052322','7.279009015052322','test'),('2019-03-02 11:59:59','2019-03-03 23:59:59','NANOBTC','4h','0.000233600000000','0.000231700000000','0.001738955253696','0.001724811353944','7.444157764109589','7.444157764109589','test'),('2019-03-10 07:59:59','2019-03-11 23:59:59','NANOBTC','4h','0.000241500000000','0.000232200000000','0.001738955253696','0.001671989274982','7.2006428724472045','7.200642872447204','test'),('2019-03-12 01:59:59','2019-03-12 11:59:59','NANOBTC','4h','0.000234100000000','0.000244200000000','0.001738955253696','0.001813980661908','7.428258238769756','7.428258238769756','test'),('2019-03-12 19:59:59','2019-03-16 11:59:59','NANOBTC','4h','0.000249000000000','0.000252500000000','0.001738955253696','0.001763398399832','6.9837560389397595','6.983756038939759','test'),('2019-03-17 23:59:59','2019-03-18 11:59:59','NANOBTC','4h','0.000257600000000','0.000250100000000','0.001738955253696','0.001688325733499','6.750602692919255','6.750602692919255','test'),('2019-03-28 15:59:59','2019-03-31 11:59:59','NANOBTC','4h','0.000252700000000','0.000258600000000','0.001738955253696','0.001779556108452','6.881500806078353','6.881500806078353','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','NANOBTC','4h','0.000268500000000','0.000264900000000','0.001738955253696','0.001715639652529','6.47655587968715','6.476555879687150','test'),('2019-04-02 11:59:59','2019-04-03 23:59:59','NANOBTC','4h','0.000283900000000','0.000273100000000','0.001738955253696','0.001672802676239','6.125238653384994','6.125238653384994','test'),('2019-04-04 03:59:59','2019-04-04 11:59:59','NANOBTC','4h','0.000274100000000','0.000279000000000','0.001738955253696','0.001770042013065','6.344236605968624','6.344236605968624','test'),('2019-04-05 15:59:59','2019-04-06 19:59:59','NANOBTC','4h','0.000286800000000','0.000275000000000','0.001738955253696','0.001667408280218','6.063302837154811','6.063302837154811','test'),('2019-04-08 07:59:59','2019-04-11 03:59:59','NANOBTC','4h','0.000313700000000','0.000293600000000','0.001738955253696','0.001627533511269','5.543370269990437','5.543370269990437','test'),('2019-04-12 23:59:59','2019-04-13 19:59:59','NANOBTC','4h','0.000322900000000','0.000306300000000','0.001738955253696','0.001649557120493','5.385429711043667','5.385429711043667','test'),('2019-04-15 07:59:59','2019-04-15 15:59:59','NANOBTC','4h','0.000312300000000','0.000305700000000','0.001738955253696','0.001702204998575','5.568220472929875','5.568220472929875','test'),('2019-04-17 23:59:59','2019-04-21 11:59:59','NANOBTC','4h','0.000309300000000','0.000306000000000','0.001738955253696','0.001720401899874','5.622228430960233','5.622228430960233','test'),('2019-04-22 03:59:59','2019-04-24 11:59:59','NANOBTC','4h','0.000319100000000','0.000316900000000','0.001738955253696','0.001726966217162','5.4495620610968345','5.449562061096834','test'),('2019-06-13 23:59:59','2019-06-14 11:59:59','NANOBTC','4h','0.000214000000000','0.000195000000000','0.001738955253696','0.001584562030237','8.12595912942056','8.125959129420560','test'),('2019-07-18 11:59:59','2019-07-18 19:59:59','NANOBTC','4h','0.000116300000000','0.000104400000000','0.001738955253696','0.001561022600910','14.952323763508168','14.952323763508168','test'),('2019-07-19 11:59:59','2019-07-19 15:59:59','NANOBTC','4h','0.000103500000000','0.000104400000000','0.001738955253696','0.001754076603728','16.801500035710145','16.801500035710145','test'),('2019-07-19 19:59:59','2019-07-19 23:59:59','NANOBTC','4h','0.000105800000000','0.000105000000000','0.001738955253696','0.001725806253668','16.43625003493384','16.436250034933838','test'),('2019-07-20 03:59:59','2019-07-20 11:59:59','NANOBTC','4h','0.000106400000000','0.000104700000000','0.001738955253696','0.001711171194191','16.343564414436088','16.343564414436088','test'),('2019-07-20 23:59:59','2019-07-21 11:59:59','NANOBTC','4h','0.000110800000000','0.000114500000000','0.001738955253696','0.001797025059099','15.694542000866425','15.694542000866425','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 18:15:52
