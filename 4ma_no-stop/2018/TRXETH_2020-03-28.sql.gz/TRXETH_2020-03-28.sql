-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-19 03:59:59','2018-04-19 23:59:59','TRXETH','4h','0.000093260000000','0.000086140000000','0.072144500000000','0.066636577632425','773.584602187433','773.584602187433006','test'),('2018-04-20 03:59:59','2018-04-20 07:59:59','TRXETH','4h','0.000087940000000','0.000086740000000','0.072144500000000','0.071160040141005','820.3832158289742','820.383215828974244','test'),('2018-04-20 15:59:59','2018-04-20 23:59:59','TRXETH','4h','0.000088260000000','0.000087490000000','0.072144500000000','0.071515095230002','817.4087922048493','817.408792204849306','test'),('2018-04-21 03:59:59','2018-04-21 11:59:59','TRXETH','4h','0.000091810000000','0.000086360000000','0.072144500000000','0.067861878008931','785.802200196057','785.802200196057015','test'),('2018-04-21 15:59:59','2018-04-21 19:59:59','TRXETH','4h','0.000087150000000','0.000085460000000','0.072144500000000','0.070745484452094','827.819850831899','827.819850831898975','test'),('2018-04-24 11:59:59','2018-05-03 03:59:59','TRXETH','4h','0.000093700000000','0.000125650000000','0.072144500000000','0.096744465581644','769.9519743863394','769.951974386339430','test'),('2018-05-20 23:59:59','2018-05-28 15:59:59','TRXETH','4h','0.000107680000000','0.000119400000000','0.075093635261525','0.083266902398088','697.3777420275376','697.377742027537579','test'),('2018-06-20 23:59:59','2018-06-21 15:59:59','TRXETH','4h','0.000092830000000','0.000090960000000','0.077136952045666','0.075583078294450','830.9485300621135','830.948530062113491','test'),('2018-06-21 19:59:59','2018-06-24 07:59:59','TRXETH','4h','0.000091900000000','0.000090590000000','0.077136952045666','0.076037393752088','839.3574760137758','839.357476013775795','test'),('2018-06-25 07:59:59','2018-06-25 15:59:59','TRXETH','4h','0.000092390000000','0.000090980000000','0.077136952045666','0.075959734788556','834.9058561063534','834.905856106353440','test'),('2018-07-17 19:59:59','2018-07-20 07:59:59','TRXETH','4h','0.000079840000000','0.000079590000000','0.077136952045666','0.076895415998429','966.1441889487224','966.144188948722444','test'),('2018-07-26 03:59:59','2018-07-26 23:59:59','TRXETH','4h','0.000078910000000','0.000077700000000','0.077136952045666','0.075954139829530','977.530757136814','977.530757136814032','test'),('2018-07-27 07:59:59','2018-07-27 11:59:59','TRXETH','4h','0.000077940000000','0.000077960000000','0.077136952045666','0.077156745977420','989.6965877042082','989.696587704208241','test'),('2018-07-27 19:59:59','2018-07-27 23:59:59','TRXETH','4h','0.000078720000000','0.000077690000000','0.077136952045666','0.076127665198524','979.8901428565293','979.890142856529337','test'),('2018-07-28 23:59:59','2018-07-30 11:59:59','TRXETH','4h','0.000078700000000','0.000079450000000','0.077136952045666','0.077872056417130','980.1391619525539','980.139161952553877','test'),('2018-07-30 19:59:59','2018-07-30 23:59:59','TRXETH','4h','0.000079840000000','0.000079620000000','0.077136952045666','0.076924400324097','966.1441889487224','966.144188948722444','test'),('2018-08-18 11:59:59','2018-08-22 19:59:59','TRXETH','4h','0.000072580000000','0.000072400000000','0.077136952045666','0.076945650704136','1062.7852307201156','1062.785230720115578','test'),('2018-08-23 23:59:59','2018-08-30 11:59:59','TRXETH','4h','0.000074740000000','0.000085350000000','0.077136952045666','0.088087220458892','1032.0705384755952','1032.070538475595185','test'),('2018-08-31 07:59:59','2018-09-02 11:59:59','TRXETH','4h','0.000089390000000','0.000086870000000','0.078396209355898','0.076186136108590','877.013193376189','877.013193376188951','test'),('2018-09-04 19:59:59','2018-09-13 15:59:59','TRXETH','4h','0.000089550000000','0.000098030000000','0.078396209355898','0.085819993335105','875.4462239631268','875.446223963126840','test'),('2018-09-20 11:59:59','2018-09-20 23:59:59','TRXETH','4h','0.000097020000000','0.000095040000000','0.079699637038872','0.078073113833997','821.4763660984567','821.476366098456651','test'),('2018-09-21 03:59:59','2018-09-21 19:59:59','TRXETH','4h','0.000100010000000','0.000098460000000','0.079699637038872','0.078464416186855','796.916678720848','796.916678720848040','test'),('2018-09-21 23:59:59','2018-09-22 03:59:59','TRXETH','4h','0.000100940000000','0.000096030000000','0.079699637038872','0.075822826875796','789.5743712985139','789.574371298513938','test'),('2018-09-22 11:59:59','2018-09-22 15:59:59','TRXETH','4h','0.000095890000000','0.000095290000000','0.079699637038872','0.079200942886997','831.1569197921785','831.156919792178542','test'),('2018-09-23 07:59:59','2018-09-24 07:59:59','TRXETH','4h','0.000099760000000','0.000096400000000','0.079699637038872','0.077015286793778','798.9137634209303','798.913763420930309','test'),('2018-09-25 11:59:59','2018-09-25 15:59:59','TRXETH','4h','0.000097990000000','0.000096420000000','0.079699637038872','0.078422686021921','813.3445967840801','813.344596784080068','test'),('2018-09-25 19:59:59','2018-09-28 11:59:59','TRXETH','4h','0.000097860000000','0.000095590000000','0.079699637038872','0.077850892137194','814.4250668186389','814.425066818638925','test'),('2018-09-28 19:59:59','2018-09-29 11:59:59','TRXETH','4h','0.000099830000000','0.000095000000000','0.079699637038872','0.075843589288719','798.3535714602024','798.353571460202375','test'),('2018-10-03 07:59:59','2018-10-10 07:59:59','TRXETH','4h','0.000098220000000','0.000110920000000','0.079699637038872','0.090004925069759','811.4400024320098','811.440002432009805','test'),('2018-10-12 15:59:59','2018-10-15 07:59:59','TRXETH','4h','0.000116640000000','0.000117130000000','0.079699637038872','0.080034452043579','683.2959279738684','683.295927973868402','test'),('2018-10-15 11:59:59','2018-10-16 07:59:59','TRXETH','4h','0.000118490000000','0.000117460000000','0.079699637038872','0.079006830674200','672.6275385169382','672.627538516938216','test'),('2018-10-18 11:59:59','2018-10-20 11:59:59','TRXETH','4h','0.000121060000000','0.000118230000000','0.079699637038872','0.077836511540607','658.3482326026103','658.348232602610324','test'),('2018-11-22 19:59:59','2018-11-24 23:59:59','TRXETH','4h','0.000109350000000','0.000110060000000','0.079699637038872','0.080217119821658','728.8489898387929','728.848989838792932','test'),('2018-11-25 07:59:59','2018-11-25 11:59:59','TRXETH','4h','0.000110910000000','0.000107550000000','0.079699637038872','0.077285149792901','718.5973946341359','718.597394634135867','test'),('2018-11-28 03:59:59','2018-11-28 07:59:59','TRXETH','4h','0.000109220000000','0.000108780000000','0.079699637038872','0.079378561775211','729.7165083214796','729.716508321479637','test'),('2018-11-28 11:59:59','2018-12-04 03:59:59','TRXETH','4h','0.000109880000000','0.000126380000000','0.079699637038872','0.091667638596402','725.3334277290863','725.333427729086338','test'),('2018-12-04 07:59:59','2018-12-10 03:59:59','TRXETH','4h','0.000128170000000','0.000143530000000','0.079932324718278','0.089511481367047','623.6430109875771','623.643010987577100','test'),('2018-12-10 15:59:59','2018-12-17 19:59:59','TRXETH','4h','0.000145180000000','0.000149870000000','0.082327113880470','0.084986668668315','567.0692511397575','567.069251139757512','test'),('2018-12-19 03:59:59','2018-12-20 19:59:59','TRXETH','4h','0.000157030000000','0.000151840000000','0.082992002577431','0.080249033123334','528.5104921189024','528.510492118902448','test'),('2018-12-21 03:59:59','2018-12-23 03:59:59','TRXETH','4h','0.000159600000000','0.000160760000000','0.082992002577431','0.083595202596164','520.000016149317','520.000016149317048','test'),('2019-01-07 07:59:59','2019-01-12 11:59:59','TRXETH','4h','0.000149340000000','0.000185960000000','0.082992002577431','0.103342659697998','555.7252080985068','555.725208098506755','test'),('2019-01-14 07:59:59','2019-01-19 11:59:59','TRXETH','4h','0.000204000000000','0.000200340000000','0.087544724498732','0.085974069147431','429.14080636633327','429.140806366333265','test'),('2019-01-21 07:59:59','2019-01-30 23:59:59','TRXETH','4h','0.000203610000000','0.000250850000000','0.087544724498732','0.107856166890167','429.9627940608614','429.962794060861427','test'),('2019-02-05 07:59:59','2019-02-05 23:59:59','TRXETH','4h','0.000250800000000','0.000243990000000','0.092229921258765','0.089725592057121','367.7429077303249','367.742907730324873','test'),('2019-02-06 03:59:59','2019-02-06 19:59:59','TRXETH','4h','0.000247180000000','0.000246360000000','0.092229921258765','0.091923955826966','373.12857536517924','373.128575365179245','test'),('2019-02-07 03:59:59','2019-02-07 07:59:59','TRXETH','4h','0.000248060000000','0.000245140000000','0.092229921258765','0.091144250977077','371.80489098913574','371.804890989135743','test'),('2019-03-23 19:59:59','2019-03-25 07:59:59','TRXETH','4h','0.000176460000000','0.000167970000000','0.092229921258765','0.087792473500140','522.6675805211663','522.667580521166315','test'),('2019-03-29 07:59:59','2019-03-29 11:59:59','TRXETH','4h','0.000169910000000','0.000163120000000','0.092229921258765','0.088544198432875','542.8163219278736','542.816321927873560','test'),('2019-04-02 03:59:59','2019-04-02 15:59:59','TRXETH','4h','0.000181630000000','0.000167140000000','0.092229921258765','0.084872042279304','507.7901297074547','507.790129707454696','test'),('2019-04-09 07:59:59','2019-04-10 07:59:59','TRXETH','4h','0.000168200000000','0.000166050000000','0.092229921258765','0.091051001337800','548.3348469605529','548.334846960552909','test'),('2019-04-10 11:59:59','2019-04-10 19:59:59','TRXETH','4h','0.000167780000000','0.000168300000000','0.092229921258765','0.092515769149184','549.7074815756646','549.707481575664588','test'),('2019-04-10 23:59:59','2019-04-11 03:59:59','TRXETH','4h','0.000169270000000','0.000161020000000','0.092229921258765','0.087734754658748','544.8686787898919','544.868678789891874','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 22:33:37
