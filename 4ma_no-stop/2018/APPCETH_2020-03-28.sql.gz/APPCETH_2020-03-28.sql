-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 23:59:59','2018-07-06 03:59:59','APPCETH','4h','0.000406200000000','0.000438500000000','0.072144500000000','0.077881248769079','177.60832102412604','177.608321024126042','test'),('2018-07-09 11:59:59','2018-07-11 07:59:59','APPCETH','4h','0.000447000000000','0.000437500000000','0.073578687192270','0.072014934332479','164.60556418852292','164.605564188522919','test'),('2018-07-11 11:59:59','2018-07-11 23:59:59','APPCETH','4h','0.000468400000000','0.000442200000000','0.073578687192270','0.069463056098253','157.0851562601836','157.085156260183595','test'),('2018-07-17 23:59:59','2018-07-19 15:59:59','APPCETH','4h','0.000466300000000','0.000443600000000','0.073578687192270','0.069996795278771','157.7925953083208','157.792595308320813','test'),('2018-08-20 07:59:59','2018-08-23 03:59:59','APPCETH','4h','0.000296600000000','0.000285700000000','0.073578687192270','0.070874682841644','248.07379363543492','248.073793635434924','test'),('2018-08-23 15:59:59','2018-08-23 19:59:59','APPCETH','4h','0.000293900000000','0.000289800000000','0.073578687192270','0.072552240722422','250.35279752388567','250.352797523885670','test'),('2018-08-23 23:59:59','2018-08-30 07:59:59','APPCETH','4h','0.000299100000000','0.000348900000000','0.073578687192270','0.085829501709739','246.00029151544632','246.000291515446321','test'),('2018-08-31 23:59:59','2018-09-02 11:59:59','APPCETH','4h','0.000362300000000','0.000350300000000','0.073578687192270','0.071141634345714','203.08773721300025','203.087737213000253','test'),('2018-09-04 23:59:59','2018-09-05 11:59:59','APPCETH','4h','0.000372500000000','0.000341100000000','0.073578687192270','0.067376349533646','197.52667702622819','197.526677026228185','test'),('2018-09-09 15:59:59','2018-09-10 03:59:59','APPCETH','4h','0.000364400000000','0.000356500000000','0.073578687192270','0.071983540022075','201.91736331577934','201.917363315779340','test'),('2018-09-10 11:59:59','2018-09-10 23:59:59','APPCETH','4h','0.000359300000000','0.000358400000000','0.073578687192270','0.073394382103283','204.78343220782074','204.783432207820738','test'),('2018-09-11 03:59:59','2018-09-12 19:59:59','APPCETH','4h','0.000370400000000','0.000363500000000','0.073578687192270','0.072208025902781','198.64656369403346','198.646563694033460','test'),('2018-09-16 19:59:59','2018-09-21 15:59:59','APPCETH','4h','0.000373100000000','0.000421100000000','0.073578687192270','0.083044720387738','197.2090249055749','197.209024905574893','test'),('2018-09-22 23:59:59','2018-09-26 15:59:59','APPCETH','4h','0.000497900000000','0.000451300000000','0.073578687192270','0.066692230427539','147.7780421616188','147.778042161618799','test'),('2018-09-26 19:59:59','2018-09-30 07:59:59','APPCETH','4h','0.000495400000000','0.000473200000000','0.073578687192270','0.070281458981393','148.5237932827412','148.523793282741195','test'),('2018-09-30 15:59:59','2018-10-02 19:59:59','APPCETH','4h','0.000503900000000','0.000524100000000','0.073578687192270','0.076528259490908','146.01843062565982','146.018430625659818','test'),('2018-10-03 03:59:59','2018-10-04 19:59:59','APPCETH','4h','0.000521500000000','0.000503200000000','0.073578687192270','0.070996731342570','141.09048359016296','141.090483590162961','test'),('2018-10-15 11:59:59','2018-10-15 15:59:59','APPCETH','4h','0.000481100000000','0.000499700000000','0.073578687192270','0.076423342319637','152.93844770789855','152.938447707898547','test'),('2018-10-15 19:59:59','2018-10-18 15:59:59','APPCETH','4h','0.000507400000000','0.000496200000000','0.073578687192270','0.071954561657084','145.01120849875838','145.011208498758378','test'),('2018-10-20 19:59:59','2018-10-20 23:59:59','APPCETH','4h','0.000514000000000','0.000526500000000','0.073578687192270','0.075368052153171','143.1491968721206','143.149196872120598','test'),('2018-10-21 11:59:59','2018-10-25 23:59:59','APPCETH','4h','0.000522600000000','0.000548700000000','0.073578687192270','0.077253397746649','140.793507830597','140.793507830597008','test'),('2018-10-27 23:59:59','2018-10-28 23:59:59','APPCETH','4h','0.000622300000000','0.000557200000000','0.073578687192270','0.065881479195778','118.23668197375864','118.236681973758635','test'),('2018-10-29 03:59:59','2018-10-29 11:59:59','APPCETH','4h','0.000559200000000','0.000541500000000','0.073578687192270','0.071249748059038','131.57848210348712','131.578482103487119','test'),('2018-10-29 23:59:59','2018-11-03 07:59:59','APPCETH','4h','0.000580000000000','0.000609400000000','0.073578687192270','0.077308365474085','126.85980550391379','126.859805503913790','test'),('2018-11-29 03:59:59','2018-11-30 15:59:59','APPCETH','4h','0.000439600000000','0.000415000000000','0.073578687192270','0.069461226535014','167.37644948196086','167.376449481960861','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','APPCETH','4h','0.000416000000000','0.000418800000000','0.073578687192270','0.074073928356064','176.8718442121875','176.871844212187511','test'),('2018-12-01 03:59:59','2018-12-03 11:59:59','APPCETH','4h','0.000424800000000','0.000426700000000','0.073578687192270','0.073907782073780','173.20783237351694','173.207832373516936','test'),('2018-12-03 15:59:59','2018-12-06 07:59:59','APPCETH','4h','0.000444500000000','0.000457400000000','0.073578687192270','0.075714041668716','165.53135476326207','165.531354763262073','test'),('2019-01-11 23:59:59','2019-01-12 11:59:59','APPCETH','4h','0.000317200000000','0.000315400000000','0.073578687192270','0.073161153658392','231.96307437663933','231.963074376639327','test'),('2019-01-12 15:59:59','2019-01-14 19:59:59','APPCETH','4h','0.000332400000000','0.000325300000000','0.073578687192270','0.072007060600618','221.3558579791516','221.355857979151608','test'),('2019-01-14 23:59:59','2019-01-22 11:59:59','APPCETH','4h','0.000333300000000','0.000393800000000','0.073578687192270','0.086934554504398','220.75813739054902','220.758137390549024','test'),('2019-01-24 03:59:59','2019-01-27 15:59:59','APPCETH','4h','0.000410600000000','0.000403100000000','0.073578687192270','0.072234702404296','179.19797172983436','179.197971729834364','test'),('2019-02-02 19:59:59','2019-02-03 03:59:59','APPCETH','4h','0.000413900000000','0.000388600000000','0.073578687192270','0.069081125496294','177.76923699509544','177.769236995095440','test'),('2019-02-03 11:59:59','2019-02-03 15:59:59','APPCETH','4h','0.000397900000000','0.000392200000000','0.073578687192270','0.072524657242544','184.91753503963307','184.917535039633066','test'),('2019-02-11 23:59:59','2019-02-17 19:59:59','APPCETH','4h','0.000422300000000','0.000485000000000','0.073578687192270','0.084503109846675','174.23321617871179','174.233216178711785','test'),('2019-02-27 19:59:59','2019-02-28 07:59:59','APPCETH','4h','0.000418900000000','0.000406400000000','0.074015054186272','0.071806440728816','176.68907659649508','176.689076596495084','test'),('2019-03-01 15:59:59','2019-03-06 07:59:59','APPCETH','4h','0.000411800000000','0.000519600000000','0.074015054186272','0.093390534616773','179.73543998609034','179.735439986090341','test'),('2019-03-06 19:59:59','2019-03-09 19:59:59','APPCETH','4h','0.000558300000000','0.000648000000000','0.078306770929533','0.090888030740350','140.259306698071','140.259306698070986','test'),('2019-03-09 23:59:59','2019-03-11 03:59:59','APPCETH','4h','0.000652300000000','0.000582600000000','0.081452085882237','0.072748712609216','124.86905700174351','124.869057001743514','test'),('2019-03-19 19:59:59','2019-03-19 23:59:59','APPCETH','4h','0.000569100000000','0.000558900000000','0.081452085882237','0.079992217184295','143.1243821511808','143.124382151180811','test'),('2019-03-20 07:59:59','2019-03-20 15:59:59','APPCETH','4h','0.000568200000000','0.000561000000000','0.081452085882237','0.080419958078027','143.35108391805173','143.351083918051728','test'),('2019-03-20 19:59:59','2019-03-21 15:59:59','APPCETH','4h','0.000574500000000','0.000549100000000','0.081452085882237','0.077850897054719','141.77908769754046','141.779087697540461','test'),('2019-03-27 11:59:59','2019-04-01 19:59:59','APPCETH','4h','0.000578600000000','0.000617900000000','0.081452085882237','0.086984521027712','140.77443118257347','140.774431182573466','test'),('2019-04-01 23:59:59','2019-04-02 07:59:59','APPCETH','4h','0.000630800000000','0.000602500000000','0.081452085882237','0.077797846772428','129.12505688369848','129.125056883698477','test'),('2019-05-23 15:59:59','2019-05-25 11:59:59','APPCETH','4h','0.000372500000000','0.000354800000000','0.081452085882237','0.077581745157094','218.66331780466308','218.663317804663080','test'),('2019-05-26 07:59:59','2019-05-26 23:59:59','APPCETH','4h','0.000391700000000','0.000361600000000','0.081452085882237','0.075192939124373','207.94507501209344','207.945075012093440','test'),('2019-06-01 23:59:59','2019-06-02 07:59:59','APPCETH','4h','0.000368300000000','0.000359200000000','0.081452085882237','0.079439558101818','221.15689894715447','221.156898947154474','test'),('2019-06-02 11:59:59','2019-06-03 23:59:59','APPCETH','4h','0.000371600000000','0.000366800000000','0.081452085882237','0.080399959907440','219.19291141613834','219.192911416138344','test'),('2019-06-08 03:59:59','2019-06-12 15:59:59','APPCETH','4h','0.000377300000000','0.000389800000000','0.081452085882237','0.084150604497471','215.88148921875694','215.881489218756940','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 19:20:25
