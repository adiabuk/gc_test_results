-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-01-01 19:59:59','2018-01-02 19:59:59','BNBBTC','4h','0.000613980000000','0.000602640000000','0.033333333333333','0.032717678100264','54.290584926762','54.290584926762001','test','test','0.0'),('2018-01-04 11:59:59','2018-01-10 15:59:59','BNBBTC','4h','0.000616890000000','0.001122400000000','0.033196521059318','0.060399382769989','53.81270738594886','53.812707385948862','test','test','2.30'),('2018-01-11 07:59:59','2018-01-14 19:59:59','BNBBTC','4h','0.001233700000000','0.001516400000000','0.039241601439467','0.048233739501344','31.808058230904688','31.808058230904688','test','test','9.02'),('2018-01-15 03:59:59','2018-01-15 15:59:59','BNBBTC','4h','0.001635000000000','0.001493700000000','0.041239854342106','0.037675822893458','25.223152502817396','25.223152502817396','test','test','7.70'),('2018-02-10 15:59:59','2018-02-10 23:59:59','BNBBTC','4h','0.001108400000000','0.001083900000000','0.040447847353518','0.039553790821435','36.492103350341026','36.492103350341026','test','test','0.0'),('2018-02-15 07:59:59','2018-02-15 23:59:59','BNBBTC','4h','0.001114800000000','0.001085700000000','0.040249168124166','0.039198530527814','36.10438475436511','36.104384754365107','test','test','2.80'),('2018-02-16 11:59:59','2018-02-16 23:59:59','BNBBTC','4h','0.001082600000000','0.001103900000000','0.040015693102755','0.040802996135351','36.962583689963665','36.962583689963665','test','test','0.0'),('2018-02-17 03:59:59','2018-02-17 11:59:59','BNBBTC','4h','0.001104500000000','0.001080600000000','0.040190649332220','0.039320973896240','36.38809355565455','36.388093555654550','test','test','2.14'),('2018-02-27 19:59:59','2018-03-01 15:59:59','BNBBTC','4h','0.001014300000000','0.000973800000000','0.039997388124225','0.038400331810480','39.433489228260754','39.433489228260754','test','test','0.0'),('2018-03-13 19:59:59','2018-03-18 15:59:59','BNBBTC','4h','0.001091500000000','0.001079400000000','0.039642486721170','0.039203023515191','36.319273221411315','36.319273221411315','test','test','10.7'),('2018-03-21 23:59:59','2018-03-27 07:59:59','BNBBTC','4h','0.001119900000000','0.001420300000000','0.039544828230953','0.050152263181018','35.31103512005794','35.311035120057937','test','test','3.61'),('2018-03-27 11:59:59','2018-03-29 15:59:59','BNBBTC','4h','0.001471900000000','0.001448500000000','0.041902035997634','0.041235885007523','28.46799103039201','28.467991030392010','test','test','26.5'),('2018-03-30 19:59:59','2018-04-07 15:59:59','BNBBTC','4h','0.001478800000000','0.001787700000000','0.041754002444276','0.050475811583468','28.235057103243168','28.235057103243168','test','test','26.7'),('2018-04-26 07:59:59','2018-04-29 11:59:59','BNBBTC','4h','0.001613700000000','0.001587900000000','0.043692182252985','0.042993627191866','27.075777562734913','27.075777562734913','test','test','7.43'),('2018-04-29 19:59:59','2018-04-30 03:59:59','BNBBTC','4h','0.001589500000000','0.001576000000000','0.043536947794959','0.043167178184873','27.39034148786341','27.390341487863409','test','test','4.59'),('2018-05-10 15:59:59','2018-05-11 07:59:59','BNBBTC','4h','0.001538200000000','0.001506700000000','0.043454776770495','0.042564888935187','28.250407470091883','28.250407470091883','test','test','0.0'),('2018-05-11 23:59:59','2018-05-12 03:59:59','BNBBTC','4h','0.001547500000000','0.001499700000000','0.043257023918205','0.041920878042089','27.952842596578133','27.952842596578133','test','test','2.63'),('2018-05-12 11:59:59','2018-05-12 15:59:59','BNBBTC','4h','0.001524200000000','0.001508000000000','0.042960102612401','0.042503500025916','28.185344844771752','28.185344844771752','test','test','1.60'),('2018-05-12 19:59:59','2018-05-12 23:59:59','BNBBTC','4h','0.001518500000000','0.001530900000000','0.042858635370960','0.043208616983472','28.224323589700358','28.224323589700358','test','test','0.69'),('2018-05-13 03:59:59','2018-05-13 19:59:59','BNBBTC','4h','0.001536000000000','0.001499500000000','0.042936409062629','0.041916110279565','27.953391316815967','27.953391316815967','test','test','0.33'),('2018-05-13 23:59:59','2018-05-14 03:59:59','BNBBTC','4h','0.001517500000000','0.001484700000000','0.042709675999726','0.041786527813373','28.14476177906176','28.144761779061760','test','test','1.18'),('2018-05-18 03:59:59','2018-05-20 15:59:59','BNBBTC','4h','0.001537200000000','0.001648500000000','0.042504531958314','0.045582045884258','27.650619280714576','27.650619280714576','test','test','3.41'),('2018-05-21 23:59:59','2018-05-23 07:59:59','BNBBTC','4h','0.001751100000000','0.001652500000000','0.043188423941858','0.040756593320724','24.663596563221724','24.663596563221724','test','test','9.99'),('2018-05-24 23:59:59','2018-05-27 19:59:59','BNBBTC','4h','0.001717700000000','0.001697400000000','0.042648017137161','0.042143997373591','24.8285597817786','24.828559781778601','test','test','3.79'),('2018-05-31 07:59:59','2018-06-04 07:59:59','BNBBTC','4h','0.001835400000000','0.001848100000000','0.042536012745257','0.042830339519728','23.175336572549124','23.175336572549124','test','test','7.51'),('2018-06-05 03:59:59','2018-06-10 03:59:59','BNBBTC','4h','0.001933800000000','0.002104900000000','0.042601418695139','0.046370734414830','22.02989900462256','22.029899004622560','test','test','4.43'),('2018-06-11 11:59:59','2018-06-14 11:59:59','BNBBTC','4h','0.002211200000000','0.002223800000000','0.043439044410626','0.043686571526931','19.6450092305653','19.645009230565300','test','test','4.80'),('2018-06-15 15:59:59','2018-06-19 11:59:59','BNBBTC','4h','0.002345100000000','0.002455800000000','0.043494050436472','0.045547178824736','18.546778575101936','18.546778575101936','test','test','5.17'),('2018-06-21 23:59:59','2018-06-24 03:59:59','BNBBTC','4h','0.002542600000000','0.002412200000000','0.043950301189419','0.041696262302020','17.28557428986829','17.285574289868290','test','test','3.41'),('2018-07-28 15:59:59','2018-07-29 15:59:59','BNBBTC','4h','0.001834000000000','0.001672500000000','0.043449403658886','0.039623297502446','23.6910597921952','23.691059792195201','test','test','0.0'),('2018-07-29 19:59:59','2018-07-29 23:59:59','BNBBTC','4h','0.001711700000000','0.001700700000000','0.042599157846344','0.042325400332580','24.88704670581514','24.887046705815141','test','test','2.29'),('2018-07-31 23:59:59','2018-08-08 07:59:59','BNBBTC','4h','0.001789800000000','0.001918700000000','0.042538322843285','0.045601899675612','23.767081709288806','23.767081709288806','test','test','4.97'),('2018-08-09 11:59:59','2018-08-11 11:59:59','BNBBTC','4h','0.001969500000000','0.001922000000000','0.043219117694913','0.042176767813975','21.944208019757976','21.944208019757976','test','test','2.57'),('2018-08-28 07:59:59','2018-08-29 03:59:59','BNBBTC','4h','0.001599500000000','0.001557300000000','0.042987484388038','0.041853335065640','26.875576360136435','26.875576360136435','test','test','0.0'),('2018-08-29 07:59:59','2018-08-29 15:59:59','BNBBTC','4h','0.001567100000000','0.001554600000000','0.042735451205283','0.042394571146534','27.270404699944553','27.270404699944553','test','test','0.62'),('2018-08-29 19:59:59','2018-08-30 07:59:59','BNBBTC','4h','0.001570400000000','0.001559600000000','0.042659700081117','0.042366319566041','27.164862507078873','27.164862507078873','test','test','1.00'),('2018-09-01 03:59:59','2018-09-02 03:59:59','BNBBTC','4h','0.001600800000000','0.001583100000000','0.042594504411100','0.042123538189163','26.608261126374174','26.608261126374174','test','test','2.57'),('2018-09-15 19:59:59','2018-09-16 07:59:59','BNBBTC','4h','0.001555700000000','0.001527000000000','0.042489845250669','0.041705980393245','27.312364370167344','27.312364370167344','test','test','0.0'),('2018-09-16 11:59:59','2018-09-16 19:59:59','BNBBTC','4h','0.001529300000000','0.001515200000000','0.042315653060131','0.041925506778729','27.669949035591884','27.669949035591884','test','test','0.18'),('2018-09-16 23:59:59','2018-09-17 15:59:59','BNBBTC','4h','0.001528700000000','0.001510900000000','0.042228953886486','0.041737244997116','27.624094908409617','27.624094908409617','test','test','0.88'),('2018-09-20 23:59:59','2018-09-21 11:59:59','BNBBTC','4h','0.001546200000000','0.001528100000000','0.042119685244404','0.041626627229319','27.240774314062584','27.240774314062584','test','test','2.28'),('2018-09-21 19:59:59','2018-09-22 03:59:59','BNBBTC','4h','0.001534800000000','0.001531500000000','0.042010116796607','0.041919790118585','27.371720612853064','27.371720612853064','test','test','0.50'),('2018-09-22 07:59:59','2018-09-22 11:59:59','BNBBTC','4h','0.001531900000000','0.001507700000000','0.041990044201491','0.041326711693053','27.410434232972705','27.410434232972705','test','test','0.02'),('2018-09-22 15:59:59','2018-09-22 19:59:59','BNBBTC','4h','0.001531900000000','0.001523400000000','0.041842636977394','0.041610466199727','27.31420913727629','27.314209137276290','test','test','1.57'),('2018-09-22 23:59:59','2018-09-23 07:59:59','BNBBTC','4h','0.001529600000000','0.001517400000000','0.041791043471245','0.041457720556529','27.321550386535908','27.321550386535908','test','test','0.40'),('2018-09-23 11:59:59','2018-09-23 15:59:59','BNBBTC','4h','0.001534500000000','0.001523500000000','0.041716971712420','0.041417925320216','27.186035654884034','27.186035654884034','test','test','1.11'),('2018-09-23 19:59:59','2018-09-24 07:59:59','BNBBTC','4h','0.001528500000000','0.001518500000000','0.041650516958596','0.041378024207804','27.249275079225676','27.249275079225676','test','test','0.32'),('2018-10-02 23:59:59','2018-10-07 07:59:59','BNBBTC','4h','0.001580000000000','0.001580200000000','0.041589963013976','0.041595227566256','26.322761401250634','26.322761401250634','test','test','3.89'),('2018-10-07 15:59:59','2018-10-09 07:59:59','BNBBTC','4h','0.001588200000000','0.001582200000000','0.041591132914483','0.041434007365127','26.187591559301516','26.187591559301516','test','test','0.50'),('2018-11-04 11:59:59','2018-11-04 15:59:59','BNBBTC','4h','0.001503300000000','0.001497100000000','0.041556216125737','0.041384827487422','27.64332876055138','27.643328760551380','test','test','0.0'),('2018-11-04 19:59:59','2018-11-06 03:59:59','BNBBTC','4h','0.001515800000000','0.001503300000000','0.041518129761667','0.041175751728931','27.390242618859276','27.390242618859276','test','test','1.23'),('2018-11-06 07:59:59','2018-11-06 19:59:59','BNBBTC','4h','0.001506600000000','0.001501600000000','0.041442045754392','0.041304510755871','27.506999704229536','27.506999704229536','test','test','0.21'),('2018-11-06 23:59:59','2018-11-07 03:59:59','BNBBTC','4h','0.001513300000000','0.001510900000000','0.041411482421388','0.041345806377106','27.365018450662497','27.365018450662497','test','test','0.77'),('2018-11-07 11:59:59','2018-11-07 15:59:59','BNBBTC','4h','0.001503400000000','0.001501200000000','0.041396887744880','0.041336309619937','27.535511337555175','27.535511337555175','test','test','0.0'),('2018-12-04 03:59:59','2018-12-06 15:59:59','BNBBTC','4h','0.001363400000000','0.001427200000000','0.041383425939338','0.043319954159178','30.35310689404251','30.353106894042511','test','test','0.0'),('2018-12-11 23:59:59','2018-12-13 23:59:59','BNBBTC','4h','0.001449500000000','0.001406100000000','0.041813765543746','0.040561804574723','28.847026936009964','28.847026936009964','test','test','2.94'),('2018-12-14 11:59:59','2018-12-14 19:59:59','BNBBTC','4h','0.001413000000000','0.001391500000000','0.041535551995075','0.040903553150139','29.39529511328709','29.395295113287091','test','test','0.48'),('2018-12-15 11:59:59','2018-12-15 15:59:59','BNBBTC','4h','0.001420400000000','0.001407600000000','0.041395107807311','0.041022073887335','29.14327499810695','29.143274998106950','test','test','2.03'),('2018-12-15 19:59:59','2018-12-20 11:59:59','BNBBTC','4h','0.001412100000000','0.001429100000000','0.041312211380650','0.041809561138791','29.255868125947014','29.255868125947014','test','test','0.31'),('2018-12-22 19:59:59','2018-12-25 03:59:59','BNBBTC','4h','0.001493700000000','0.001445500000000','0.041422733549126','0.040086069053533','27.73162853928202','27.731628539282021','test','test','4.45'),('2018-12-25 07:59:59','2018-12-25 11:59:59','BNBBTC','4h','0.001473800000000','0.001460900000000','0.041125696994549','0.040765728551592','27.904530461765056','27.904530461765056','test','test','1.92'),('2018-12-28 19:59:59','2019-01-02 07:59:59','BNBBTC','4h','0.001513200000000','0.001563700000000','0.041045704007226','0.042415521646907','27.12510177585617','27.125101775856169','test','test','3.45');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 10:37:08
