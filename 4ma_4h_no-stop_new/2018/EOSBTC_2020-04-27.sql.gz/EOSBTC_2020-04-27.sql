-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-28 19:59:59','2018-04-01 15:59:59','EOSBTC','4h','0.000783890000000','0.000814000000000','0.033333333333333','0.034613700051452','42.5229730361828','42.522973036182798','test','test','0.0'),('2018-04-05 03:59:59','2018-04-07 19:59:59','EOSBTC','4h','0.000834780000000','0.000848500000000','0.033617859270693','0.034170384521890','40.27151976651706','40.271519766517059','test','test','6.53'),('2018-04-09 15:59:59','2018-04-14 11:59:59','EOSBTC','4h','0.000866230000000','0.001049000000000','0.033740642659848','0.040859741812429','38.95113614149591','38.951136141495908','test','test','2.04'),('2018-04-17 15:59:59','2018-04-30 19:59:59','EOSBTC','4h','0.001088500000000','0.001959200000000','0.035322664693755','0.063577551371617','32.45077142283407','32.450771422834073','test','test','3.62'),('2018-05-02 03:59:59','2018-05-03 07:59:59','EOSBTC','4h','0.002074400000000','0.001913700000000','0.041601528399946','0.038378733561018','20.054728306954512','20.054728306954512','test','test','5.55'),('2018-05-07 23:59:59','2018-05-11 07:59:59','EOSBTC','4h','0.001897800000000','0.001751100000000','0.040885351769074','0.037724912784711','21.54355135898069','21.543551358980690','test','test','0.0'),('2018-05-26 07:59:59','2018-05-28 15:59:59','EOSBTC','4h','0.001666700000000','0.001658700000000','0.040183031994771','0.039990157298690','24.1093370101222','24.109337010122200','test','test','0.0'),('2018-05-28 19:59:59','2018-05-28 23:59:59','EOSBTC','4h','0.001679700000000','0.001617400000000','0.040140170951197','0.038651373755115','23.897226261354476','23.897226261354476','test','test','2.22'),('2018-06-01 03:59:59','2018-06-01 07:59:59','EOSBTC','4h','0.001643500000000','0.001618100000000','0.039809327129846','0.039194081064073','24.222286054058745','24.222286054058745','test','test','1.58'),('2018-06-02 07:59:59','2018-06-04 23:59:59','EOSBTC','4h','0.001665500000000','0.001798300000000','0.039672605781896','0.042835933339888','23.820237635482435','23.820237635482435','test','test','2.84'),('2018-06-05 23:59:59','2018-06-06 23:59:59','EOSBTC','4h','0.001861600000000','0.001816400000000','0.040375567461450','0.039395241049086','21.688637441689824','21.688637441689824','test','test','5.93'),('2018-06-07 19:59:59','2018-06-08 07:59:59','EOSBTC','4h','0.001871700000000','0.001830200000000','0.040157717147591','0.039267325919496','21.45521031553727','21.455210315537268','test','test','2.95'),('2018-06-08 11:59:59','2018-06-10 03:59:59','EOSBTC','4h','0.001834700000000','0.001805000000000','0.039959852430237','0.039312985031110','21.780047108648095','21.780047108648095','test','test','0.24'),('2018-07-05 03:59:59','2018-07-05 19:59:59','EOSBTC','4h','0.001362400000000','0.001337900000000','0.039816104119320','0.039100092264561','29.22497366362269','29.224973663622691','test','test','0.0'),('2018-07-05 23:59:59','2018-07-06 07:59:59','EOSBTC','4h','0.001353100000000','0.001295100000000','0.039656990373818','0.037957111989603','29.30824800370819','29.308248003708190','test','test','1.12'),('2018-08-06 19:59:59','2018-08-07 19:59:59','EOSBTC','4h','0.001008000000000','0.000993300000000','0.039279239621770','0.038706417377286','38.967499624771605','38.967499624771605','test','test','0.0'),('2018-08-28 19:59:59','2018-09-03 03:59:59','EOSBTC','4h','0.000823500000000','0.000893900000000','0.039151945789662','0.042498997378724','47.54334643553397','47.543346435533969','test','test','0.0'),('2018-09-15 11:59:59','2018-09-17 15:59:59','EOSBTC','4h','0.000831800000000','0.000786700000000','0.039895735031676','0.037732597679033','47.9631342049483','47.963134204948297','test','test','0.0'),('2018-09-20 07:59:59','2018-09-24 11:59:59','EOSBTC','4h','0.000817800000000','0.000857200000000','0.039415037842200','0.041313977058369','48.19642680630933','48.196426806309333','test','test','3.80'),('2018-09-27 19:59:59','2018-09-29 03:59:59','EOSBTC','4h','0.000882400000000','0.000861400000000','0.039837024334682','0.038888953719283','45.1462197809177','45.146219780917697','test','test','2.85'),('2018-09-29 11:59:59','2018-09-30 07:59:59','EOSBTC','4h','0.000871800000000','0.000870500000000','0.039626341975704','0.039567252454520','45.453477834026394','45.453477834026394','test','test','1.19'),('2018-09-30 11:59:59','2018-09-30 23:59:59','EOSBTC','4h','0.000878800000000','0.000863200000000','0.039613210970997','0.038910017876837','45.07648039485282','45.076480394852823','test','test','1.72'),('2018-10-04 19:59:59','2018-10-05 03:59:59','EOSBTC','4h','0.000880800000000','0.000870000000000','0.039456945838961','0.038973141325949','44.79671416775784','44.796714167757841','test','test','1.99'),('2018-10-05 11:59:59','2018-10-06 15:59:59','EOSBTC','4h','0.000870500000000','0.000868800000000','0.039349433724958','0.039272588190975','45.20325528427161','45.203255284271613','test','test','0.18'),('2018-10-06 23:59:59','2018-10-07 11:59:59','EOSBTC','4h','0.000869100000000','0.000862600000000','0.039332356939629','0.039038190192295','45.256422666699905','45.256422666699905','test','test','0.03'),('2018-10-08 11:59:59','2018-10-11 03:59:59','EOSBTC','4h','0.000873600000000','0.000858400000000','0.039266986551332','0.038583769752362','44.94847361645197','44.948473616451970','test','test','1.25'),('2018-10-28 15:59:59','2018-10-29 07:59:59','EOSBTC','4h','0.000836800000000','0.000835100000000','0.039115160596006','0.039035696240111','46.74373876195719','46.743738761957189','test','test','0.0'),('2018-10-29 11:59:59','2018-10-29 15:59:59','EOSBTC','4h','0.000837500000000','0.000811400000000','0.039097501850251','0.037879060300052','46.68358429880755','46.683584298807553','test','test','0.28'),('2018-11-03 07:59:59','2018-11-03 23:59:59','EOSBTC','4h','0.000838000000000','0.000834600000000','0.038826737061318','0.038669206147227','46.332621791549194','46.332621791549194','test','test','3.17'),('2018-11-04 07:59:59','2018-11-08 03:59:59','EOSBTC','4h','0.000847600000000','0.000849900000000','0.038791730191520','0.038896993263064','45.76655284511588','45.766552845115882','test','test','1.53'),('2018-11-22 11:59:59','2018-11-22 15:59:59','EOSBTC','4h','0.000832100000000','0.000824400000000','0.038815121985197','0.038455938666742','46.64718421487402','46.647184214874017','test','test','0.0'),('2018-11-22 19:59:59','2018-11-22 23:59:59','EOSBTC','4h','0.000830100000000','0.000808900000000','0.038735303469984','0.037746039003578','46.663418226700934','46.663418226700934','test','test','0.68'),('2018-11-23 03:59:59','2018-11-23 07:59:59','EOSBTC','4h','0.000833900000000','0.000838400000000','0.038515466921894','0.038723309110584','46.18715304220436','46.187153042204358','test','test','2.99'),('2018-11-24 07:59:59','2018-11-24 11:59:59','EOSBTC','4h','0.000828900000000','0.000825000000000','0.038561654074936','0.038380220306216','46.52147915904987','46.521479159049868','test','test','0.0'),('2018-11-24 15:59:59','2018-11-24 19:59:59','EOSBTC','4h','0.000833700000000','0.000818900000000','0.038521335459665','0.037837497430634','46.205272231816394','46.205272231816394','test','test','1.04'),('2018-11-24 23:59:59','2018-11-25 03:59:59','EOSBTC','4h','0.000840300000000','0.000835900000000','0.038369371453214','0.038168460785126','45.661515474490066','45.661515474490066','test','test','2.54'),('2018-11-25 11:59:59','2018-11-25 23:59:59','EOSBTC','4h','0.000845000000000','0.000833300000000','0.038324724638083','0.037794074604633','45.354703713708076','45.354703713708076','test','test','1.07'),('2018-11-26 07:59:59','2018-11-26 15:59:59','EOSBTC','4h','0.000834400000000','0.000846500000000','0.038206802408428','0.038760855990813','45.789552263216414','45.789552263216414','test','test','0.25'),('2018-11-26 23:59:59','2018-11-27 03:59:59','EOSBTC','4h','0.000842200000000','0.000828100000000','0.038329925426736','0.037688210930753','45.51166638178052','45.511666381780522','test','test','1.05'),('2018-12-17 03:59:59','2018-12-20 11:59:59','EOSBTC','4h','0.000594900000000','0.000657200000000','0.038187322205406','0.042186431590844','64.19116188503278','64.191161885032784','test','test','0.0'),('2018-12-23 07:59:59','2018-12-25 11:59:59','EOSBTC','4h','0.000676800000000','0.000658700000000','0.039076013179948','0.038030983867659','57.73642609330346','57.736426093303457','test','test','2.89'),('2018-12-29 07:59:59','2018-12-31 11:59:59','EOSBTC','4h','0.000685900000000','0.000671800000000','0.038843784443884','0.038045275389126','56.63184785520273','56.631847855202729','test','test','3.96'),('2018-12-31 15:59:59','2019-01-03 19:59:59','EOSBTC','4h','0.000685300000000','0.000691000000000','0.038666337987271','0.038987946226768','56.422498157406494','56.422498157406494','test','test','1.96'),('2019-01-03 23:59:59','2019-01-04 15:59:59','EOSBTC','4h','0.000699700000000','0.000702500000000','0.038737806484937','0.038892824147018','55.36345074308513','55.363450743085131','test','test','1.24'),('2019-01-04 19:59:59','2019-01-05 07:59:59','EOSBTC','4h','0.000705300000000','0.000699800000000','0.038772254854288','0.038469904929861','54.97271353223877','54.972713532238771','test','test','0.39'),('2019-01-05 11:59:59','2019-01-06 03:59:59','EOSBTC','4h','0.000707900000000','0.000698200000000','0.038705065982193','0.038174709801903','54.67589487525513','54.675894875255132','test','test','1.14'),('2019-01-06 15:59:59','2019-01-07 03:59:59','EOSBTC','4h','0.000715100000000','0.000694000000000','0.038587209053240','0.037448640865541','53.96057761605339','53.960577616053392','test','test','2.36'),('2019-01-09 23:59:59','2019-01-10 11:59:59','EOSBTC','4h','0.000721200000000','0.000677800000000','0.038334193900418','0.036027338637969','53.15334706103408','53.153347061034083','test','test','3.77'),('2019-01-18 07:59:59','2019-01-18 11:59:59','EOSBTC','4h','0.000686700000000','0.000676900000000','0.037821559397651','0.037281802178928','55.07726721661763','55.077267216617628','test','test','1.29'),('2019-01-18 23:59:59','2019-01-19 07:59:59','EOSBTC','4h','0.000675700000000','0.000672400000000','0.037701613349046','0.037517485298059','55.79637908694128','55.796379086941279','test','test','0.0'),('2019-01-23 11:59:59','2019-01-26 07:59:59','EOSBTC','4h','0.000682600000000','0.000676200000000','0.037660696004382','0.037307592496576','55.172423094612434','55.172423094612434','test','test','1.49'),('2019-01-26 11:59:59','2019-01-26 19:59:59','EOSBTC','4h','0.000678100000000','0.000677800000000','0.037582228558203','0.037565601705869','55.42284111223025','55.422841112230252','test','test','0.28'),('2019-02-01 15:59:59','2019-02-02 23:59:59','EOSBTC','4h','0.000672400000000','0.000695900000000','0.037578533702129','0.038891882217893','55.88717088359475','55.887170883594749','test','test','0.0'),('2019-02-03 23:59:59','2019-02-06 03:59:59','EOSBTC','4h','0.000685600000000','0.000679200000000','0.037870388927854','0.037516873045214','55.236856662564826','55.236856662564826','test','test','2.21'),('2019-02-07 03:59:59','2019-02-14 11:59:59','EOSBTC','4h','0.000693000000000','0.000761100000000','0.037791829842823','0.041505572429109','54.53366499685906','54.533664996859059','test','test','2.32'),('2019-02-16 15:59:59','2019-02-24 19:59:59','EOSBTC','4h','0.000781100000000','0.000941900000000','0.038617105973109','0.046566959564808','49.439388008077216','49.439388008077216','test','test','2.56'),('2019-03-06 07:59:59','2019-03-08 23:59:59','EOSBTC','4h','0.000971300000000','0.000928400000000','0.040383740104598','0.038600086804395','41.57700000473363','41.577000004733627','test','test','14.7'),('2019-03-16 23:59:59','2019-03-18 03:59:59','EOSBTC','4h','0.000947900000000','0.000935700000000','0.039987372704553','0.039472712986233','42.18522281311601','42.185222813116013','test','test','11.5'),('2019-03-26 23:59:59','2019-03-28 15:59:59','EOSBTC','4h','0.000948800000000','0.001065800000000','0.039873003878259','0.044789889896130','42.02466681941329','42.024666819413291','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27  9:05:05
