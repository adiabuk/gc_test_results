-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-08 07:59:59','2018-06-09 23:59:59','WAVESETH','4h','0.007719000000000','0.007292000000000','1.297777777777778','1.225987246476947','168.12770796447438','168.127707964474382','test','test','5.53'),('2018-07-02 03:59:59','2018-07-05 07:59:59','WAVESETH','4h','0.006539000000000','0.006379000000000','1.281824326377593','1.250459914048427','196.02757705728598','196.027577057285981','test','test','2.44'),('2018-07-18 15:59:59','2018-07-19 03:59:59','WAVESETH','4h','0.006382000000000','0.006279000000000','1.274854456971112','1.254279400708495','199.75782779240237','199.757827792402367','test','test','1.61'),('2018-07-19 11:59:59','2018-07-19 23:59:59','WAVESETH','4h','0.006355000000000','0.006166000000000','1.270282222246086','1.232503569216265','199.88705306783407','199.887053067834074','test','test','2.97'),('2018-07-20 11:59:59','2018-07-21 03:59:59','WAVESETH','4h','0.006569000000000','0.006270000000000','1.261886966017237','1.204449882315128','192.09726990671894','192.097269906718935','test','test','4.55'),('2018-07-21 11:59:59','2018-07-21 15:59:59','WAVESETH','4h','0.006275000000000','0.006243000000000','1.249123169638990','1.242753139132464','199.06345332892272','199.063453328922719','test','test','0.50'),('2018-07-21 23:59:59','2018-07-22 03:59:59','WAVESETH','4h','0.006380000000000','0.006295000000000','1.247707607304207','1.231084543570530','195.5654556903145','195.565455690314508','test','test','1.33'),('2018-07-22 07:59:59','2018-07-22 15:59:59','WAVESETH','4h','0.006359000000000','0.006224000000000','1.244013593141167','1.217603491698478','195.6303810569535','195.630381056953496','test','test','2.12'),('2018-08-11 03:59:59','2018-08-16 19:59:59','WAVESETH','4h','0.005474000000000','0.006715000000000','1.238144681709459','1.518842078494523','226.18645993961613','226.186459939616128','test','test','0.0'),('2018-08-16 23:59:59','2018-08-17 07:59:59','WAVESETH','4h','0.006845000000000','0.006725000000000','1.300521880995028','1.277722373950557','189.9958920372576','189.995892037257590','test','test','1.75'),('2018-08-17 15:59:59','2018-08-26 23:59:59','WAVESETH','4h','0.007029000000000','0.008092000000000','1.295455323874035','1.491367830529050','184.30151143463294','184.301511434632943','test','test','3.57'),('2018-09-04 15:59:59','2018-09-14 03:59:59','WAVESETH','4h','0.008038000000000','0.010560000000000','1.338991436464038','1.759112909810928','166.58266191391365','166.582661913913654','test','test','0.04'),('2018-09-19 23:59:59','2018-09-20 11:59:59','WAVESETH','4h','0.010816000000000','0.010516000000000','1.432351763874458','1.392623072198946','132.42897225170654','132.428972251706540','test','test','2.77'),('2018-09-26 23:59:59','2018-09-27 19:59:59','WAVESETH','4h','0.010995000000000','0.009928000000000','1.423523165724344','1.285378625676334','129.4700469053519','129.470046905351893','test','test','9.70'),('2018-09-27 23:59:59','2018-09-28 03:59:59','WAVESETH','4h','0.010126000000000','0.009914000000000','1.392824379047009','1.363663923945492','137.54931651659183','137.549316516591830','test','test','2.09'),('2018-10-13 15:59:59','2018-10-13 19:59:59','WAVESETH','4h','0.009501000000000','0.009479000000000','1.386344277913338','1.383134134337494','145.91561708381624','145.915617083816244','test','test','0.23'),('2018-10-14 03:59:59','2018-10-14 11:59:59','WAVESETH','4h','0.009630000000000','0.009551000000000','1.385630912674262','1.374263847035502','143.88690681975723','143.886906819757229','test','test','1.00'),('2018-10-14 23:59:59','2018-10-15 07:59:59','WAVESETH','4h','0.009629000000000','0.009420000000000','1.383104898087871','1.353084239275911','143.63951584669962','143.639515846699624','test','test','2.17'),('2018-10-15 11:59:59','2018-10-15 15:59:59','WAVESETH','4h','0.009534000000000','0.009652000000000','1.376433640574102','1.393469425091382','144.3710552311833','144.371055231183306','test','test','0.0'),('2018-10-15 19:59:59','2018-10-16 03:59:59','WAVESETH','4h','0.009734000000000','0.009541000000000','1.380219370466831','1.352853196386278','141.79364808576443','141.793648085764431','test','test','1.98'),('2018-10-16 07:59:59','2018-10-16 11:59:59','WAVESETH','4h','0.009651000000000','0.009513000000000','1.374137998448930','1.354489149232688','142.38296533508756','142.382965335087562','test','test','1.42'),('2018-10-16 15:59:59','2018-10-16 23:59:59','WAVESETH','4h','0.009594000000000','0.009518000000000','1.369771587511988','1.358920780689921','142.77377397456615','142.773773974566154','test','test','0.79'),('2018-10-17 07:59:59','2018-10-19 15:59:59','WAVESETH','4h','0.009749000000000','0.009649000000000','1.367360297107084','1.353334650403760','140.25646703324276','140.256467033242757','test','test','1.02'),('2018-10-23 15:59:59','2018-10-23 23:59:59','WAVESETH','4h','0.009849000000000','0.009700000000000','1.364243486728567','1.343604611764352','138.51593935714968','138.515939357149676','test','test','1.81'),('2018-10-24 03:59:59','2018-10-24 11:59:59','WAVESETH','4h','0.009701000000000','0.009660000000000','1.359657070069853','1.353910658372826','140.15638285432973','140.156382854329735','test','test','0.42'),('2018-10-24 19:59:59','2018-10-24 23:59:59','WAVESETH','4h','0.009695000000000','0.009692000000000','1.358380089692736','1.357959755472099','140.11140687908568','140.111406879085678','test','test','0.03'),('2018-10-25 07:59:59','2018-10-25 11:59:59','WAVESETH','4h','0.009690000000000','0.009604000000000','1.358286682088150','1.346231712567037','140.17406419898347','140.174064198983473','test','test','0.88'),('2018-11-17 23:59:59','2018-11-20 07:59:59','WAVESETH','4h','0.008610000000000','0.008498000000000','1.355607799972347','1.337973877371081','157.44573751130625','157.445737511306248','test','test','1.30'),('2018-11-22 15:59:59','2018-11-24 23:59:59','WAVESETH','4h','0.008750000000000','0.008796000000000','1.351689150505399','1.358795173468056','154.47876005775987','154.478760057759871','test','test','0.16'),('2018-11-25 03:59:59','2018-11-25 11:59:59','WAVESETH','4h','0.008990000000000','0.008892000000000','1.353268266719322','1.338516287838511','150.53039674297244','150.530396742972442','test','test','1.09'),('2018-11-25 15:59:59','2018-12-06 23:59:59','WAVESETH','4h','0.009199000000000','0.016499000000000','1.349990049190253','2.421294251721924','146.75400034680436','146.754000346804361','test','test','2.40'),('2018-12-09 03:59:59','2018-12-11 07:59:59','WAVESETH','4h','0.018084000000000','0.016949000000000','1.588057649752847','1.488386922454158','87.81561876536425','87.815618765364249','test','test','6.27'),('2018-12-11 11:59:59','2018-12-17 23:59:59','WAVESETH','4h','0.017271000000000','0.027135000000000','1.565908599242027','2.460247226010793','90.66693296520334','90.666932965203344','test','test','0.0'),('2018-12-18 11:59:59','2018-12-21 07:59:59','WAVESETH','4h','0.029647000000000','0.033713000000000','1.764650516301753','2.006667212739265','59.52206011744031','59.522060117440311','test','test','0.0'),('2019-01-13 23:59:59','2019-01-15 03:59:59','WAVESETH','4h','0.022897000000000','0.020810000000000','1.818432004398978','1.652686815370692','79.41791520282035','79.417915202820353','test','test','9.11'),('2019-01-18 11:59:59','2019-01-18 15:59:59','WAVESETH','4h','0.021613000000000','0.021002000000000','1.781599740170470','1.731233875124240','82.43185768613657','82.431857686136567','test','test','2.82'),('2019-01-21 07:59:59','2019-01-21 11:59:59','WAVESETH','4h','0.021386000000000','0.021424000000000','1.770407325715752','1.773553097640244','82.78347169717348','82.783471697173482','test','test','0.0'),('2019-01-21 15:59:59','2019-01-24 23:59:59','WAVESETH','4h','0.021426000000000','0.023377000000000','1.771106386143417','1.932379071636080','82.6615507394482','82.661550739448202','test','test','0.35'),('2019-01-25 03:59:59','2019-01-26 03:59:59','WAVESETH','4h','0.023433000000000','0.023744000000000','1.806944760697342','1.830926317500861','77.11111512385705','77.111115123857047','test','test','0.0'),('2019-01-27 19:59:59','2019-01-28 03:59:59','WAVESETH','4h','0.024754000000000','0.023161000000000','1.812273995542569','1.695648299699501','73.2113596001684','73.211359600168393','test','test','6.43'),('2019-01-28 07:59:59','2019-01-31 07:59:59','WAVESETH','4h','0.025285000000000','0.025999000000000','1.786357174244109','1.836800481438505','70.6488896280051','70.648889628005094','test','test','0.86'),('2019-03-02 07:59:59','2019-03-05 15:59:59','WAVESETH','4h','0.020000000000000','0.019571000000000','1.797566798065086','1.759008990246590','89.87833990325427','89.878339903254272','test','test','2.14'),('2019-03-10 07:59:59','2019-03-11 23:59:59','WAVESETH','4h','0.020008000000000','0.019897000000000','1.788998396327642','1.779073425216468','89.41415415472021','89.414154154720208','test','test','0.55'),('2019-03-12 11:59:59','2019-03-15 19:59:59','WAVESETH','4h','0.020149000000000','0.020255000000000','1.786792847191826','1.796192819488334','88.67898392931788','88.678983929317880','test','test','0.0'),('2019-03-21 11:59:59','2019-03-21 15:59:59','WAVESETH','4h','0.020272000000000','0.020318000000000','1.788881729924383','1.792940952476500','88.24396852428883','88.243968524288832','test','test','0.0'),('2019-03-22 11:59:59','2019-03-22 15:59:59','WAVESETH','4h','0.020126000000000','0.020116000000000','1.789783779380409','1.788894490013729','88.92893666801199','88.928936668011985','test','test','0.04'),('2019-03-22 19:59:59','2019-03-23 11:59:59','WAVESETH','4h','0.020186000000000','0.020287000000000','1.789586159521147','1.798540296156025','88.65481816710327','88.654818167103272','test','test','0.40'),('2019-03-23 15:59:59','2019-03-24 11:59:59','WAVESETH','4h','0.020385000000000','0.020081000000000','1.791575967662231','1.764858327526380','87.8869741310881','87.886974131088095','test','test','1.49'),('2019-04-02 03:59:59','2019-04-02 07:59:59','WAVESETH','4h','0.020456000000000','0.019784000000000','1.785638714298708','1.726978701783616','87.29168529031622','87.291685290316224','test','test','3.28'),('2019-05-25 07:59:59','2019-05-25 11:59:59','WAVESETH','4h','0.010552000000000','0.010749000000000','1.772603155962021','1.805696675837354','167.9874105346874','167.987410534687399','test','test','0.0'),('2019-05-25 15:59:59','2019-05-25 19:59:59','WAVESETH','4h','0.010762000000000','0.010755000000000','1.779957271489873','1.778799521917263','165.39279608714676','165.392796087146763','test','test','0.06'),('2019-05-25 23:59:59','2019-05-26 03:59:59','WAVESETH','4h','0.010848000000000','0.010626000000000','1.779699993807071','1.743279142163895','164.05789028457514','164.057890284575137','test','test','2.04');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 21:24:22
