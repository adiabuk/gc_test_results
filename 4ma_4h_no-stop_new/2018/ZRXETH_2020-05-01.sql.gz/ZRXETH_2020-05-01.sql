-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-21 03:59:59','2018-03-30 03:59:59','ZRXETH','4h','0.000985430000000','0.001298350000000','1.297777777777778','1.709882769732785','1316.9659719896672','1316.965971989667196','test','test','2.96'),('2018-03-31 19:59:59','2018-04-01 23:59:59','ZRXETH','4h','0.001397120000000','0.001333330000000','1.389356664878891','1.325921124873291','994.4433297632921','994.443329763292127','test','test','6.61'),('2018-04-02 03:59:59','2018-04-04 23:59:59','ZRXETH','4h','0.001366000000000','0.001368310000000','1.375259878210979','1.377585537302244','1006.7788273872469','1006.778827387246906','test','test','2.47'),('2018-04-05 19:59:59','2018-04-06 07:59:59','ZRXETH','4h','0.001780000000000','0.001394990000000','1.375776691342372','1.078199284638031','772.9082535631302','772.908253563130188','test','test','21.6'),('2018-04-06 11:59:59','2018-04-06 19:59:59','ZRXETH','4h','0.001398520000000','0.001405410000000','1.309648378741407','1.316100540547837','936.4530923700818','936.453092370081777','test','test','0.0'),('2018-04-08 15:59:59','2018-04-09 11:59:59','ZRXETH','4h','0.001430380000000','0.001362800000000','1.311082192476169','1.249138558918975','916.5971227758841','916.597122775884145','test','test','4.72'),('2018-04-11 19:59:59','2018-04-12 03:59:59','ZRXETH','4h','0.001442510000000','0.001444240000000','1.297316940574570','1.298872810764166','899.3469304022644','899.346930402264434','test','test','3.21'),('2018-04-14 07:59:59','2018-04-14 15:59:59','ZRXETH','4h','0.001434780000000','0.001423880000000','1.297662689505592','1.287804367452308','904.4332158976232','904.433215897623199','test','test','0.75'),('2018-04-14 19:59:59','2018-04-20 07:59:59','ZRXETH','4h','0.001470000000000','0.001612310000000','1.295471951271529','1.420885973982720','881.2734362391352','881.273436239135208','test','test','1.03'),('2018-04-23 11:59:59','2018-04-23 19:59:59','ZRXETH','4h','0.001612700000000','0.001549820000000','1.323341734096238','1.271743961268079','820.5752676233881','820.575267623388072','test','test','3.89'),('2018-04-24 15:59:59','2018-04-25 07:59:59','ZRXETH','4h','0.001627220000000','0.001605000000000','1.311875562356647','1.293961650903024','806.2066360766503','806.206636076650284','test','test','1.36'),('2018-04-25 19:59:59','2018-04-28 03:59:59','ZRXETH','4h','0.001669840000000','0.001651510000000','1.307894693144731','1.293537802828687','783.2455164235681','783.245516423568120','test','test','2.37'),('2018-04-28 07:59:59','2018-04-28 11:59:59','ZRXETH','4h','0.001710330000000','0.001669230000000','1.304704273074499','1.273351641931175','762.8377407134873','762.837740713487278','test','test','2.40'),('2018-04-28 15:59:59','2018-05-01 07:59:59','ZRXETH','4h','0.001703190000000','0.001726950000000','1.297737021709316','1.315840833753664','761.9449513614544','761.944951361454400','test','test','0.0'),('2018-05-02 11:59:59','2018-05-06 03:59:59','ZRXETH','4h','0.001880100000000','0.001943240000000','1.301760091052504','1.345477516800632','692.3887511581852','692.388751158185187','test','test','0.0'),('2018-05-07 07:59:59','2018-05-13 03:59:59','ZRXETH','4h','0.002101060000000','0.002400060000000','1.311475074552088','1.498109938521263','624.1968694621229','624.196869462122891','test','test','0.0'),('2018-05-24 15:59:59','2018-05-26 15:59:59','ZRXETH','4h','0.002331150000000','0.002099680000000','1.352949488767460','1.218609262627999','580.3785636992301','580.378563699230085','test','test','9.92'),('2018-05-29 15:59:59','2018-06-01 11:59:59','ZRXETH','4h','0.002184630000000','0.002189860000000','1.323096105180913','1.326263594700922','605.6385315503829','605.638531550382936','test','test','1.24'),('2018-06-07 15:59:59','2018-06-07 23:59:59','ZRXETH','4h','0.002199630000000','0.002144250000000','1.323799991740916','1.290470730209380','601.8284855820822','601.828485582082180','test','test','2.51'),('2018-06-08 03:59:59','2018-06-08 07:59:59','ZRXETH','4h','0.002151290000000','0.002127050000000','1.316393489178352','1.301560817535903','611.9088961406188','611.908896140618822','test','test','1.12'),('2018-07-01 11:59:59','2018-07-07 15:59:59','ZRXETH','4h','0.001698110000000','0.001985020000000','1.313097339924475','1.534956205249884','773.2698941319906','773.269894131990554','test','test','0.97'),('2018-07-13 23:59:59','2018-07-20 15:59:59','ZRXETH','4h','0.002229000000000','0.002433460000000','1.362399309996787','1.487368427503267','611.2154822776076','611.215482277607634','test','test','2.16'),('2018-07-22 03:59:59','2018-07-23 11:59:59','ZRXETH','4h','0.002559770000000','0.002462370000000','1.390170224998227','1.337273839809391','543.084036846368','543.084036846368008','test','test','4.24'),('2018-07-23 23:59:59','2018-07-24 03:59:59','ZRXETH','4h','0.002539780000000','0.002453630000000','1.378415472734042','1.331659260394376','542.7302651151051','542.730265115105112','test','test','3.39'),('2018-07-28 07:59:59','2018-07-30 07:59:59','ZRXETH','4h','0.002484590000000','0.002460720000000','1.368025203325227','1.354882285739881','550.6040044132943','550.604004413294319','test','test','0.96'),('2018-08-01 23:59:59','2018-08-02 11:59:59','ZRXETH','4h','0.002517650000000','0.002443240000000','1.365104554972928','1.324758426664571','542.213792613321','542.213792613320948','test','test','2.95'),('2018-08-09 23:59:59','2018-08-10 11:59:59','ZRXETH','4h','0.002557430000000','0.002435210000000','1.356138748682182','1.291328655008480','530.2740441310933','530.274044131093319','test','test','4.77'),('2018-08-10 15:59:59','2018-08-14 03:59:59','ZRXETH','4h','0.002493680000000','0.002518190000000','1.341736505643581','1.354924228909327','538.054804803977','538.054804803977049','test','test','0.43'),('2018-08-17 15:59:59','2018-08-18 07:59:59','ZRXETH','4h','0.002701320000000','0.002475750000000','1.344667110813747','1.232382538757768','497.7814960144474','497.781496014447384','test','test','8.35'),('2018-08-18 11:59:59','2018-08-18 15:59:59','ZRXETH','4h','0.002547150000000','0.002540000000000','1.319714983690196','1.316010466039730','518.1143567085552','518.114356708555192','test','test','0.28'),('2018-08-19 11:59:59','2018-08-19 15:59:59','ZRXETH','4h','0.002598570000000','0.002572170000000','1.318891757545648','1.305492563989498','507.5452104602333','507.545210460233307','test','test','1.01'),('2018-08-20 03:59:59','2018-08-20 07:59:59','ZRXETH','4h','0.002572000000000','0.002538000000000','1.315914158977615','1.298518715196418','511.6306994469732','511.630699446973210','test','test','1.32'),('2018-08-20 23:59:59','2018-08-21 03:59:59','ZRXETH','4h','0.002587430000000','0.002513000000000','1.312048504804016','1.274306123285458','507.08560417248606','507.085604172486057','test','test','2.87'),('2018-08-24 15:59:59','2018-08-25 15:59:59','ZRXETH','4h','0.002616020000000','0.002573660000000','1.303661308911003','1.282551725251295','498.3376690204978','498.337669020497799','test','test','2.39'),('2018-08-25 19:59:59','2018-08-26 07:59:59','ZRXETH','4h','0.002580140000000','0.002534000000000','1.298970290319956','1.275741128648356','503.44953774599696','503.449537745996963','test','test','1.78'),('2018-08-26 15:59:59','2018-08-30 11:59:59','ZRXETH','4h','0.002617520000000','0.002700890000000','1.293808254392934','1.335017029939535','494.2878199184474','494.287819918447383','test','test','0.78'),('2018-09-01 07:59:59','2018-09-02 11:59:59','ZRXETH','4h','0.002750170000000','0.002700280000000','1.302965760069957','1.279329053331868','473.77644293623916','473.776442936239164','test','test','1.81'),('2018-09-04 07:59:59','2018-09-05 19:59:59','ZRXETH','4h','0.002804180000000','0.002734730000000','1.297713158572604','1.265573217890170','462.7781235771611','462.778123577161125','test','test','2.47'),('2018-09-06 15:59:59','2018-09-10 19:59:59','ZRXETH','4h','0.002858290000000','0.002833800000000','1.290570949532063','1.279513260300375','451.5185476393448','451.518547639344774','test','test','0.85'),('2018-09-24 15:59:59','2018-09-28 23:59:59','ZRXETH','4h','0.002931780000000','0.002928430000000','1.288113685258354','1.286641821460383','439.3623277525443','439.362327752544275','test','test','2.58'),('2018-10-06 03:59:59','2018-10-14 19:59:59','ZRXETH','4h','0.002872020000000','0.003598220000000','1.287786604414361','1.613407816009583','448.39054199286943','448.390541992869430','test','test','1.53'),('2018-10-16 19:59:59','2018-10-21 15:59:59','ZRXETH','4h','0.004069980000000','0.004345780000000','1.360146873657744','1.452316493104229','334.1900632577417','334.190063257741713','test','test','0.0'),('2018-10-22 15:59:59','2018-10-23 23:59:59','ZRXETH','4h','0.004418280000000','0.004332530000000','1.380629011312518','1.353833756661376','312.48110380340717','312.481103803407166','test','test','1.94'),('2018-11-22 19:59:59','2018-11-23 03:59:59','ZRXETH','4h','0.003294660000000','0.003236760000000','1.374674510278931','1.350516128489869','417.243208792085','417.243208792084999','test','test','1.75'),('2018-11-23 07:59:59','2018-11-23 11:59:59','ZRXETH','4h','0.003238340000000','0.003240110000000','1.369305980992473','1.370054411233386','422.8419440183775','422.841944018377490','test','test','0.0'),('2018-11-23 15:59:59','2018-11-24 03:59:59','ZRXETH','4h','0.003264160000000','0.003246680000000','1.369472298823786','1.362138597110806','419.54815291645826','419.548152916458264','test','test','0.53'),('2018-11-24 07:59:59','2018-11-24 15:59:59','ZRXETH','4h','0.003276050000000','0.003224750000000','1.367842587332013','1.346423401199282','417.52799479007143','417.527994790071432','test','test','1.56'),('2018-11-26 11:59:59','2018-11-26 15:59:59','ZRXETH','4h','0.003267960000000','0.003215720000000','1.363082768191406','1.341293197997671','417.1050955921756','417.105095592175587','test','test','1.59'),('2018-11-26 19:59:59','2018-11-26 23:59:59','ZRXETH','4h','0.003224860000000','0.003233850000000','1.358240641481687','1.362027033252778','421.17817253514494','421.178172535144938','test','test','0.0'),('2018-11-27 03:59:59','2018-11-27 07:59:59','ZRXETH','4h','0.003253190000000','0.003160010000000','1.359082061875263','1.320154342767084','417.7690395812305','417.769039581230516','test','test','2.86'),('2018-11-27 11:59:59','2018-11-27 23:59:59','ZRXETH','4h','0.003287520000000','0.003262630000000','1.350431457629001','1.340207264626256','410.7751306848327','410.775130684832675','test','test','0.75'),('2018-11-28 03:59:59','2018-11-30 11:59:59','ZRXETH','4h','0.003308080000000','0.003420350000000','1.348159414739502','1.393913404211584','407.5353119451471','407.535311945147100','test','test','0.12'),('2018-11-30 15:59:59','2018-11-30 23:59:59','ZRXETH','4h','0.003490100000000','0.003458520000000','1.358326967955520','1.346036212490624','389.1942832456148','389.194283245614827','test','test','0.90'),('2018-12-01 15:59:59','2018-12-02 11:59:59','ZRXETH','4h','0.003574210000000','0.003492830000000','1.355595688963321','1.324730581102329','379.27141633069164','379.271416330691636','test','test','2.38'),('2018-12-07 03:59:59','2018-12-07 11:59:59','ZRXETH','4h','0.003549080000000','0.003434670000000','1.348736776105323','1.305258191639994','380.0243376044843','380.024337604484288','test','test','3.22'),('2018-12-07 15:59:59','2018-12-07 19:59:59','ZRXETH','4h','0.003477170000000','0.003281900000000','1.339074868446361','1.263875453530921','385.10480317222374','385.104803172223740','test','test','5.61'),('2018-12-08 03:59:59','2018-12-08 23:59:59','ZRXETH','4h','0.003582000000000','0.003518790000000','1.322363887354041','1.299028705522760','369.16914778169775','369.169147781697745','test','test','1.76'),('2018-12-09 03:59:59','2018-12-10 11:59:59','ZRXETH','4h','0.003542430000000','0.003475390000000','1.317178291391534','1.292250873586556','371.8290245372624','371.829024537262399','test','test','1.89'),('2019-01-12 07:59:59','2019-01-12 11:59:59','ZRXETH','4h','0.002243850000000','0.002237890000000','1.311638865212650','1.308154956913670','584.5483723121645','584.548372312164474','test','test','0.26'),('2019-01-12 19:59:59','2019-01-12 23:59:59','ZRXETH','4h','0.002235550000000','0.002255510000000','1.310864663368432','1.322568655084490','586.3723304638377','586.372330463837670','test','test','0.0'),('2019-01-13 03:59:59','2019-01-14 15:59:59','ZRXETH','4h','0.002269340000000','0.002248650000000','1.313465550416445','1.301490437723717','578.7874670240886','578.787467024088642','test','test','0.91'),('2019-01-14 19:59:59','2019-01-14 23:59:59','ZRXETH','4h','0.002249900000000','0.002213830000000','1.310804414262506','1.289789829070965','582.605633255925','582.605633255925000','test','test','1.60'),('2019-01-15 23:59:59','2019-01-20 03:59:59','ZRXETH','4h','0.002330220000000','0.002416540000000','1.306134506442163','1.354518577729890','560.5198249273302','560.519824927330205','test','test','0.0'),('2019-01-21 07:59:59','2019-01-21 19:59:59','ZRXETH','4h','0.002456420000000','0.002409870000000','1.316886522283881','1.291931071826584','536.0999024124053','536.099902412405299','test','test','1.89'),('2019-01-22 19:59:59','2019-01-25 11:59:59','ZRXETH','4h','0.002455920000000','0.002469490000000','1.311340866626703','1.318586581291727','533.9509701564805','533.950970156480480','test','test','1.36'),('2019-01-25 15:59:59','2019-01-25 19:59:59','ZRXETH','4h','0.002517440000000','0.002509820000000','1.312951025441153','1.308976874393318','521.5421322618029','521.542132261802863','test','test','0.30'),('2019-02-27 11:59:59','2019-02-28 11:59:59','ZRXETH','4h','0.001958440000000','0.001813540000000','1.312067880763857','1.214991311697313','669.955618126599','669.955618126599006','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-01  0:11:08
