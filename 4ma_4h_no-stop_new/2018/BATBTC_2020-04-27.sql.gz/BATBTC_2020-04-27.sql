-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-30 19:59:59','2018-05-03 19:59:59','BATBTC','4h','0.000054290000000','0.000051630000000','0.033333333333333','0.031700128937189','613.986615091791','613.986615091791009','test','test','0.0'),('2018-05-15 11:59:59','2018-05-15 15:59:59','BATBTC','4h','0.000046390000000','0.000044400000000','0.032970399023079','0.031556062009586','710.7221173330267','710.722117333026745','test','test','0.0'),('2018-05-15 23:59:59','2018-05-16 03:59:59','BATBTC','4h','0.000044220000000','0.000042890000000','0.032656101908970','0.031673907980003','738.4916759151866','738.491675915186647','test','test','0.0'),('2018-05-16 11:59:59','2018-05-17 19:59:59','BATBTC','4h','0.000047420000000','0.000044860000000','0.032437836591421','0.030686658572146','684.053913779446','684.053913779446020','test','test','9.55'),('2018-06-16 11:59:59','2018-06-20 03:59:59','BATBTC','4h','0.000038720000000','0.000037380000000','0.032048685920471','0.030939563008967','827.7036653014289','827.703665301428941','test','test','0.0'),('2018-06-20 19:59:59','2018-06-24 15:59:59','BATBTC','4h','0.000039400000000','0.000041330000000','0.031802214162359','0.033360038358637','807.1627959989677','807.162795998967681','test','test','5.12'),('2018-06-24 19:59:59','2018-06-24 23:59:59','BATBTC','4h','0.000043580000000','0.000042620000000','0.032148397317088','0.031440217844293','737.6869508280811','737.686950828081081','test','test','5.16'),('2018-07-02 15:59:59','2018-07-03 23:59:59','BATBTC','4h','0.000042540000000','0.000038870000000','0.031991024100911','0.029231102651679','752.022193251319','752.022193251318981','test','test','0.0'),('2018-07-07 23:59:59','2018-07-08 07:59:59','BATBTC','4h','0.000040360000000','0.000039560000000','0.031377708223304','0.030755751667837','777.4456943335975','777.445694333597544','test','test','3.69'),('2018-07-08 15:59:59','2018-07-09 23:59:59','BATBTC','4h','0.000041430000000','0.000039600000000','0.031239495655422','0.029859619308586','754.0307906208651','754.030790620865105','test','test','4.51'),('2018-07-11 11:59:59','2018-07-17 23:59:59','BATBTC','4h','0.000040910000000','0.000049130000000','0.030932856467237','0.037148160308857','756.1196887615904','756.119688761590396','test','test','3.20'),('2018-08-07 11:59:59','2018-08-08 11:59:59','BATBTC','4h','0.000041920000000','0.000037180000000','0.032314035098708','0.028660205748329','770.8500739195557','770.850073919555712','test','test','0.0'),('2018-08-28 11:59:59','2018-08-28 19:59:59','BATBTC','4h','0.000033360000000','0.000032270000000','0.031502073020846','0.030472778668546','944.3067452291899','944.306745229189914','test','test','0.0'),('2018-08-28 23:59:59','2018-08-29 03:59:59','BATBTC','4h','0.000032800000000','0.000031740000000','0.031273340942557','0.030262678095023','953.4555165413686','953.455516541368638','test','test','1.61'),('2018-08-29 07:59:59','2018-08-29 11:59:59','BATBTC','4h','0.000032170000000','0.000031830000000','0.031048749198660','0.030720599533520','965.146073940331','965.146073940331007','test','test','1.33'),('2018-09-21 19:59:59','2018-09-22 03:59:59','BATBTC','4h','0.000026120000000','0.000025200000000','0.030975827050852','0.029884794857637','1185.904557842709','1185.904557842708982','test','test','0.0'),('2018-09-22 07:59:59','2018-09-24 07:59:59','BATBTC','4h','0.000026000000000','0.000025270000000','0.030733375452359','0.029870476833889','1182.0529020138208','1182.052902013820812','test','test','3.07'),('2018-09-27 03:59:59','2018-09-27 07:59:59','BATBTC','4h','0.000025580000000','0.000025080000000','0.030541620203810','0.029944637791695','1193.9648242302756','1193.964824230275553','test','test','1.21'),('2018-09-27 11:59:59','2018-09-28 11:59:59','BATBTC','4h','0.000025450000000','0.000025260000000','0.030408957445563','0.030181935759329','1194.8509801792798','1194.850980179279759','test','test','1.45'),('2018-09-28 15:59:59','2018-09-28 19:59:59','BATBTC','4h','0.000025500000000','0.000025240000000','0.030358508181955','0.030048970451472','1190.5297326256905','1190.529732625690485','test','test','0.94'),('2018-09-28 23:59:59','2018-09-29 03:59:59','BATBTC','4h','0.000025490000000','0.000024930000000','0.030289722019626','0.029624275007818','1188.2982353717362','1188.298235371736155','test','test','0.98'),('2018-09-30 03:59:59','2018-10-03 03:59:59','BATBTC','4h','0.000025780000000','0.000025560000000','0.030141844905890','0.029884622024614','1169.194914891018','1169.194914891018016','test','test','3.29'),('2018-10-04 15:59:59','2018-10-06 19:59:59','BATBTC','4h','0.000026500000000','0.000026090000000','0.030084684265607','0.029619223112818','1135.2711043625243','1135.271104362524284','test','test','3.54'),('2018-10-06 23:59:59','2018-10-07 07:59:59','BATBTC','4h','0.000026460000000','0.000026380000000','0.029981248453876','0.029890602200047','1133.0781728600152','1133.078172860015229','test','test','1.39'),('2018-10-08 15:59:59','2018-10-10 07:59:59','BATBTC','4h','0.000026720000000','0.000026630000000','0.029961104841914','0.029860187946863','1121.2988339039669','1121.298833903966852','test','test','1.27'),('2018-10-10 11:59:59','2018-10-11 03:59:59','BATBTC','4h','0.000026920000000','0.000025910000000','0.029938678865236','0.028815422340203','1112.1351733000001','1112.135173300000133','test','test','1.07'),('2018-10-12 11:59:59','2018-10-14 07:59:59','BATBTC','4h','0.000027650000000','0.000027390000000','0.029689066304118','0.029409892443754','1073.745616785445','1073.745616785445009','test','test','6.29'),('2018-10-14 11:59:59','2018-10-14 19:59:59','BATBTC','4h','0.000027630000000','0.000027510000000','0.029627027668481','0.029498354366989','1072.2775124314553','1072.277512431455307','test','test','0.86'),('2018-10-16 07:59:59','2018-10-16 19:59:59','BATBTC','4h','0.000028170000000','0.000027510000000','0.029598433601483','0.028904966573546','1050.7076180860097','1050.707618086009688','test','test','2.34'),('2018-10-16 23:59:59','2018-10-26 23:59:59','BATBTC','4h','0.000028570000000','0.000041060000000','0.029444329817497','0.042316562208835','1030.6030737660794','1030.603073766079433','test','test','3.71'),('2018-10-31 23:59:59','2018-11-01 07:59:59','BATBTC','4h','0.000039170000000','0.000038560000000','0.032304825904461','0.031801738240388','824.7338755287437','824.733875528743738','test','test','18.7'),('2018-11-01 11:59:59','2018-11-09 07:59:59','BATBTC','4h','0.000039070000000','0.000045540000000','0.032193028645778','0.037524200781385','823.9833285328385','823.983328532838527','test','test','4.83'),('2018-11-29 07:59:59','2018-12-04 19:59:59','BATBTC','4h','0.000040060000000','0.000041890000000','0.033377733564802','0.034902477759100','833.1935487968493','833.193548796849313','test','test','0.0'),('2018-12-10 07:59:59','2018-12-10 11:59:59','BATBTC','4h','0.000040320000000','0.000039950000000','0.033716565607979','0.033407162600168','836.2243454359898','836.224345435989790','test','test','0.91'),('2018-12-11 07:59:59','2018-12-11 11:59:59','BATBTC','4h','0.000040370000000','0.000039920000000','0.033647809384021','0.033272740911819','833.4854937830347','833.485493783034713','test','test','1.04'),('2018-12-11 15:59:59','2018-12-11 19:59:59','BATBTC','4h','0.000040060000000','0.000040160000000','0.033564460834643','0.033648246308519','837.8547387579355','837.854738757935479','test','test','0.34'),('2018-12-12 03:59:59','2018-12-13 03:59:59','BATBTC','4h','0.000040980000000','0.000039820000000','0.033583079828838','0.032632460682878','819.4992637588472','819.499263758847178','test','test','2.00'),('2018-12-14 23:59:59','2018-12-15 07:59:59','BATBTC','4h','0.000040680000000','0.000039950000000','0.033371831129735','0.032772975753021','820.3498311144378','820.349831114437848','test','test','2.11'),('2019-01-13 07:59:59','2019-01-13 11:59:59','BATBTC','4h','0.000035250000000','0.000035210000000','0.033238752157132','0.033201034424188','942.9433236065877','942.943323606587683','test','test','0.0'),('2019-01-19 03:59:59','2019-01-19 07:59:59','BATBTC','4h','0.000034770000000','0.000034510000000','0.033230370438700','0.032981883343099','955.7195984670759','955.719598467075912','test','test','0.0'),('2019-01-19 15:59:59','2019-01-19 19:59:59','BATBTC','4h','0.000034650000000','0.000034660000000','0.033175151084122','0.033184725442299','957.435817723585','957.435817723585046','test','test','0.40'),('2019-01-19 23:59:59','2019-01-20 15:59:59','BATBTC','4h','0.000034900000000','0.000034440000000','0.033177278719273','0.032739985074263','950.6383587184145','950.638358718414452','test','test','0.68'),('2019-01-25 15:59:59','2019-01-27 15:59:59','BATBTC','4h','0.000035070000000','0.000034690000000','0.033080102353715','0.032721663833772','943.2592630086938','943.259263008693779','test','test','1.79'),('2019-02-08 11:59:59','2019-02-08 23:59:59','BATBTC','4h','0.000033000000000','0.000032360000000','0.033000449349283','0.032360440634630','1000.0136166449427','1000.013616644942658','test','test','0.0'),('2019-02-10 07:59:59','2019-02-11 23:59:59','BATBTC','4h','0.000033290000000','0.000033060000000','0.032858225190471','0.032631208314718','987.0298945770903','987.029894577090317','test','test','2.79'),('2019-02-14 03:59:59','2019-02-19 03:59:59','BATBTC','4h','0.000034840000000','0.000035430000000','0.032807776995860','0.033363362197569','941.6698334058427','941.669833405842724','test','test','5.10'),('2019-02-26 07:59:59','2019-03-04 03:59:59','BATBTC','4h','0.000047510000000','0.000043330000000','0.032931240374017','0.030033901187248','693.1433461169672','693.143346116967223','test','test','26.9'),('2019-03-05 03:59:59','2019-03-06 11:59:59','BATBTC','4h','0.000045890000000','0.000044970000000','0.032287387221402','0.031640091596131','703.5822013816033','703.582201381603340','test','test','23.2'),('2019-03-07 15:59:59','2019-03-11 15:59:59','BATBTC','4h','0.000046130000000','0.000049540000000','0.032143543749119','0.034519643558018','696.8034630201461','696.803463020146069','test','test','13.3'),('2019-03-15 11:59:59','2019-03-16 07:59:59','BATBTC','4h','0.000049960000000','0.000049440000000','0.032671565928875','0.032331509598150','653.9544821632239','653.954482163223929','test','test','14.6'),('2019-03-16 11:59:59','2019-03-16 15:59:59','BATBTC','4h','0.000049530000000','0.000049460000000','0.032595997855380','0.032549930424532','658.1061549642685','658.106154964268512','test','test','10.3'),('2019-03-22 19:59:59','2019-04-02 07:59:59','BATBTC','4h','0.000049650000000','0.000066050000000','0.032585760648525','0.043349234457907','656.3093786208483','656.309378620848292','test','test','0.66'),('2019-04-14 03:59:59','2019-04-15 19:59:59','BATBTC','4h','0.000063380000000','0.000058220000000','0.034977643717277','0.032129984493845','551.8719425256652','551.871942525665190','test','test','21.9'),('2019-04-16 11:59:59','2019-04-22 23:59:59','BATBTC','4h','0.000061730000000','0.000074340000000','0.034344830556514','0.041360678820205','556.3717893490038','556.371789349003848','test','test','16.3'),('2019-04-24 19:59:59','2019-04-26 03:59:59','BATBTC','4h','0.000080400000000','0.000072750000000','0.035903907948445','0.032487677901112','446.5660192592703','446.566019259270320','test','test','7.53'),('2019-04-28 19:59:59','2019-04-29 11:59:59','BATBTC','4h','0.000078000000000','0.000073500000000','0.035144745715705','0.033117164232107','450.5736630218548','450.573663021854827','test','test','6.73');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 13:32:20
