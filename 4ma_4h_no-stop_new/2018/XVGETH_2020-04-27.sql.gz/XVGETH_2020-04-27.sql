-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-20 03:59:59','2018-03-31 07:59:59','XVGETH','4h','0.000057860000000','0.000092250000000','1.297777777777778','2.069132388524024','22429.619387794293','22429.619387794293289','test','test','0.0'),('2018-03-31 11:59:59','2018-04-05 23:59:59','XVGETH','4h','0.000094530000000','0.000143070000000','1.469189913499166','2.223600983014129','15542.04922774956','15542.049227749559577','test','test','2.41'),('2018-04-06 07:59:59','2018-04-06 11:59:59','XVGETH','4h','0.000150170000000','0.000146030000000','1.636836817835824','1.591711263957950','10899.892241032325','10899.892241032324819','test','test','4.72'),('2018-04-06 19:59:59','2018-04-12 11:59:59','XVGETH','4h','0.000159710000000','0.000187000000000','1.626808916974074','1.904785345151536','10186.01788851089','10186.017888510890771','test','test','8.56'),('2018-04-12 19:59:59','2018-04-12 23:59:59','XVGETH','4h','0.000196880000000','0.000182180000000','1.688581456569066','1.562503909781351','8576.703863109844','8576.703863109843951','test','test','5.01'),('2018-04-17 07:59:59','2018-04-17 11:59:59','XVGETH','4h','0.000225350000000','0.000208460000000','1.660564223949574','1.536104806410154','7368.822826490232','7368.822826490231819','test','test','19.1'),('2018-05-02 19:59:59','2018-05-03 03:59:59','XVGETH','4h','0.000117450000000','0.000108850000000','1.632906575607480','1.513340832310551','13902.993406619671','13902.993406619671077','test','test','0.0'),('2018-05-03 07:59:59','2018-05-03 11:59:59','XVGETH','4h','0.000113760000000','0.000110560000000','1.606336410430385','1.561151138688321','14120.397419395089','14120.397419395088946','test','test','4.31'),('2018-07-02 11:59:59','2018-07-05 11:59:59','XVGETH','4h','0.000056750000000','0.000054280000000','1.596295238932149','1.526817719281710','28128.550465764733','28128.550465764732508','test','test','0.0'),('2018-07-17 23:59:59','2018-07-20 07:59:59','XVGETH','4h','0.000052780000000','0.000051120000000','1.580855790120940','1.531135808847716','29951.795947725273','29951.795947725273436','test','test','0.0'),('2018-07-26 19:59:59','2018-07-26 23:59:59','XVGETH','4h','0.000051510000000','0.000049640000000','1.569806905393557','1.512817215758808','30475.769858154865','30475.769858154864778','test','test','0.75'),('2018-07-30 07:59:59','2018-07-30 15:59:59','XVGETH','4h','0.000052400000000','0.000052000000000','1.557142529919168','1.545255945721312','29716.460494640614','29716.460494640614343','test','test','5.26'),('2018-07-30 23:59:59','2018-08-02 07:59:59','XVGETH','4h','0.000053110000000','0.000053260000000','1.554501066764089','1.558891485894472','29269.46086921652','29269.460869216520223','test','test','2.09'),('2018-08-17 23:59:59','2018-08-21 23:59:59','XVGETH','4h','0.000048620000000','0.000046830000000','1.555476715459730','1.498210090188794','31992.528084321875','31992.528084321875212','test','test','0.0'),('2018-08-22 03:59:59','2018-08-22 19:59:59','XVGETH','4h','0.000048100000000','0.000045950000000','1.542750798732855','1.473792083196979','32073.821179477236','32073.821179477236001','test','test','2.64'),('2018-08-24 23:59:59','2018-08-29 23:59:59','XVGETH','4h','0.000048180000000','0.000050990000000','1.527426639724883','1.616510675790199','31702.50393783484','31702.503937834841054','test','test','4.62'),('2018-08-31 23:59:59','2018-09-06 03:59:59','XVGETH','4h','0.000051730000000','0.000061840000000','1.547223092183842','1.849609047373841','29909.590028684353','29909.590028684353456','test','test','1.43'),('2018-09-06 23:59:59','2018-09-13 19:59:59','XVGETH','4h','0.000063900000000','0.000065110000000','1.614419971114953','1.644990364934188','25264.7882803592','25264.788280359200144','test','test','16.6'),('2018-09-19 15:59:59','2018-09-21 15:59:59','XVGETH','4h','0.000064840000000','0.000064370000000','1.621213391963672','1.609461845168130','25003.291054344103','25003.291054344103031','test','test','16.2'),('2018-09-21 23:59:59','2018-09-22 03:59:59','XVGETH','4h','0.000064400000000','0.000063430000000','1.618601937120218','1.594222373781606','25133.570452177297','25133.570452177296829','test','test','0.04'),('2018-09-26 03:59:59','2018-09-26 07:59:59','XVGETH','4h','0.000064950000000','0.000064870000000','1.613184256378304','1.611197270381225','24837.324963484276','24837.324963484275941','test','test','2.34'),('2018-09-26 11:59:59','2018-09-26 15:59:59','XVGETH','4h','0.000065860000000','0.000064790000000','1.612742703934509','1.586541144669251','24487.438565662145','24487.438565662145265','test','test','1.50'),('2018-09-26 23:59:59','2018-09-27 03:59:59','XVGETH','4h','0.000064660000000','0.000064360000000','1.606920135208896','1.599464582462799','24851.842486991893','24851.842486991892656','test','test','0.0'),('2018-09-27 07:59:59','2018-09-28 03:59:59','XVGETH','4h','0.000064870000000','0.000064080000000','1.605263345709763','1.585714123525229','24745.850866498582','24745.850866498582036','test','test','0.78'),('2018-09-28 07:59:59','2018-09-28 11:59:59','XVGETH','4h','0.000064950000000','0.000064440000000','1.600919074113200','1.588348346972357','24648.484589887605','24648.484589887604670','test','test','1.33'),('2018-09-29 07:59:59','2018-09-29 11:59:59','XVGETH','4h','0.000065000000000','0.000062340000000','1.598125579193013','1.532725363182960','24586.5473722002','24586.547372200198879','test','test','0.86'),('2018-10-01 03:59:59','2018-10-03 03:59:59','XVGETH','4h','0.000069380000000','0.000067320000000','1.583592197857445','1.536572884977849','22824.909164852197','22824.909164852197136','test','test','10.1'),('2018-10-04 07:59:59','2018-10-05 15:59:59','XVGETH','4h','0.000069690000000','0.000068130000000','1.573143461661979','1.537928885679877','22573.44614237307','22573.446142373071780','test','test','7.03'),('2018-10-05 19:59:59','2018-10-05 23:59:59','XVGETH','4h','0.000068870000000','0.000068600000000','1.565318000332623','1.559181281005052','22728.59010211447','22728.590102114470938','test','test','1.07'),('2018-10-06 03:59:59','2018-10-07 03:59:59','XVGETH','4h','0.000069530000000','0.000068830000000','1.563954284926497','1.548209023896028','22493.23004352793','22493.230043527928501','test','test','1.33'),('2018-10-08 03:59:59','2018-10-10 07:59:59','XVGETH','4h','0.000069330000000','0.000069190000000','1.560455338030837','1.557304267104480','22507.649473977166','22507.649473977166053','test','test','0.72'),('2018-10-10 11:59:59','2018-10-13 15:59:59','XVGETH','4h','0.000070300000000','0.000071960000000','1.559755100047202','1.596585732566097','22187.128023431036','22187.128023431036127','test','test','1.57'),('2018-10-21 23:59:59','2018-10-22 03:59:59','XVGETH','4h','0.000070740000000','0.000070240000000','1.567939685051401','1.556857272801957','22164.8244988889','22164.824498888898233','test','test','0.0'),('2018-10-22 07:59:59','2018-10-22 11:59:59','XVGETH','4h','0.000070430000000','0.000069770000000','1.565476926773747','1.550806832046065','22227.416254064272','22227.416254064271925','test','test','0.26'),('2018-10-22 15:59:59','2018-10-22 19:59:59','XVGETH','4h','0.000069850000000','0.000069970000000','1.562216905723151','1.564900742926970','22365.310031827496','22365.310031827495550','test','test','0.11'),('2018-10-23 19:59:59','2018-10-26 11:59:59','XVGETH','4h','0.000071650000000','0.000071910000000','1.562813313990666','1.568484374167045','21811.769909150957','21811.769909150956664','test','test','2.34'),('2018-10-26 15:59:59','2018-10-27 23:59:59','XVGETH','4h','0.000072290000000','0.000071810000000','1.564073549585417','1.553688222378321','21636.098348117535','21636.098348117535352','test','test','0.53'),('2018-10-28 03:59:59','2018-10-28 15:59:59','XVGETH','4h','0.000072490000000','0.000072440000000','1.561765699094951','1.560688470719248','21544.56751407023','21544.567514070229663','test','test','0.93'),('2018-11-28 11:59:59','2018-12-02 11:59:59','XVGETH','4h','0.000059250000000','0.000065450000000','1.561526315011461','1.724926537004222','26354.874514961375','26354.874514961375098','test','test','0.0'),('2018-12-02 15:59:59','2018-12-03 03:59:59','XVGETH','4h','0.000068190000000','0.000065710000000','1.597837475454297','1.539725773751311','23432.13778346235','23432.137783462349034','test','test','4.01'),('2018-12-08 07:59:59','2018-12-10 15:59:59','XVGETH','4h','0.000065140000000','0.000064720000000','1.584923763964745','1.574704728335866','24331.037211617204','24331.037211617203866','test','test','0.0'),('2018-12-14 19:59:59','2018-12-16 15:59:59','XVGETH','4h','0.000069210000000','0.000065870000000','1.582652867158327','1.506275745697429','22867.40163499967','22867.401634999670932','test','test','6.48'),('2018-12-17 19:59:59','2018-12-18 03:59:59','XVGETH','4h','0.000066490000000','0.000065350000000','1.565680173500350','1.538835905222558','23547.60375244924','23547.603752449238527','test','test','1.17'),('2018-12-19 03:59:59','2018-12-22 23:59:59','XVGETH','4h','0.000067260000000','0.000068960000000','1.559714780549729','1.599136652790802','23189.33661239562','23189.336612395618431','test','test','2.83'),('2019-01-10 23:59:59','2019-01-13 07:59:59','XVGETH','4h','0.000059140000000','0.000054870000000','1.568475196603301','1.455228847440364','26521.393246589465','26521.393246589464979','test','test','0.0'),('2019-01-14 03:59:59','2019-01-14 15:59:59','XVGETH','4h','0.000056210000000','0.000054290000000','1.543309341233760','1.490593562276834','27456.13487339903','27456.134873399030766','test','test','2.70'),('2019-01-16 03:59:59','2019-01-17 19:59:59','XVGETH','4h','0.000055890000000','0.000054750000000','1.531594723687776','1.500354466307134','27403.734544422547','27403.734544422546605','test','test','2.86'),('2019-01-19 07:59:59','2019-01-20 15:59:59','XVGETH','4h','0.000055290000000','0.000054950000000','1.524652444269856','1.515276755518694','27575.555150476685','27575.555150476684503','test','test','0.97'),('2019-01-20 19:59:59','2019-01-26 19:59:59','XVGETH','4h','0.000055290000000','0.000056910000000','1.522568957880709','1.567180310960230','27537.872271309614','27537.872271309614007','test','test','0.61'),('2019-01-28 23:59:59','2019-01-29 11:59:59','XVGETH','4h','0.000057290000000','0.000057470000000','1.532482591898380','1.537297513639377','26749.565227760166','26749.565227760165726','test','test','1.08'),('2019-01-29 15:59:59','2019-01-30 15:59:59','XVGETH','4h','0.000057510000000','0.000057030000000','1.533552574507490','1.520752970338413','26665.84201890959','26665.842018909588660','test','test','1.04'),('2019-03-02 15:59:59','2019-03-05 15:59:59','XVGETH','4h','0.000045280000000','0.000046920000000','1.530708218025473','1.586149063377986','33805.393507629706','33805.393507629705709','test','test','0.0'),('2019-03-09 07:59:59','2019-03-10 07:59:59','XVGETH','4h','0.000046840000000','0.000046240000000','1.543028405881587','1.523262884029987','32942.536419333635','32942.536419333635422','test','test','3.45'),('2019-03-10 11:59:59','2019-03-10 15:59:59','XVGETH','4h','0.000046700000000','0.000046750000000','1.538636067692343','1.540283429649187','32947.239136881006','32947.239136881005834','test','test','0.98'),('2019-03-10 19:59:59','2019-03-16 11:59:59','XVGETH','4h','0.000047300000000','0.000049770000000','1.539002148127197','1.619368645080139','32537.043300786405','32537.043300786404870','test','test','1.16');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27  9:55:24
