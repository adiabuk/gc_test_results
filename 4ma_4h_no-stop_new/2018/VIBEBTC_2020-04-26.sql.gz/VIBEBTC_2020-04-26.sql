-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-03 03:59:59','2018-07-03 23:59:59','VIBEBTC','4h','0.000013150000000','0.000012100000000','0.033333333333333','0.030671736375158','2534.854245880862','2534.854245880861981','test','test','0.0'),('2018-07-04 15:59:59','2018-07-05 11:59:59','VIBEBTC','4h','0.000012750000000','0.000012500000000','0.032741867342628','0.032099869943753','2567.9895955002175','2567.989595500217547','test','test','5.09'),('2018-08-27 19:59:59','2018-08-27 23:59:59','VIBEBTC','4h','0.000004920000000','0.000004900000000','0.032599201253989','0.032466684175721','6625.853913412375','6625.853913412374823','test','test','0.0'),('2018-08-28 07:59:59','2018-08-30 15:59:59','VIBEBTC','4h','0.000005200000000','0.000005190000000','0.032569753014374','0.032507118873962','6263.414041225727','6263.414041225726578','test','test','5.76'),('2018-08-31 07:59:59','2018-09-02 15:59:59','VIBEBTC','4h','0.000005380000000','0.000005270000000','0.032555834316504','0.031890194581408','6051.270319052871','6051.270319052870946','test','test','3.53'),('2018-09-15 11:59:59','2018-09-18 19:59:59','VIBEBTC','4h','0.000005110000000','0.000009310000000','0.032407914375372','0.059044556327733','6342.057607704892','6342.057607704891780','test','test','0.0'),('2018-09-20 15:59:59','2018-09-25 15:59:59','VIBEBTC','4h','0.000013100000000','0.000013000000000','0.038327168142563','0.038034594339948','2925.7380261498724','2925.738026149872439','test','test','61.6'),('2018-10-10 23:59:59','2018-10-11 03:59:59','VIBEBTC','4h','0.000012000000000','0.000011600000000','0.038262151741982','0.036986746683916','3188.512645165185','3188.512645165184949','test','test','56.0'),('2018-10-20 19:59:59','2018-10-21 23:59:59','VIBEBTC','4h','0.000011940000000','0.000011410000000','0.037978728395745','0.036292905443505','3180.798023094249','3180.798023094248947','test','test','4.27'),('2018-10-22 03:59:59','2018-10-22 11:59:59','VIBEBTC','4h','0.000011440000000','0.000011340000000','0.037604101073025','0.037275393895813','3287.071772117599','3287.071772117598812','test','test','0.26'),('2018-10-23 15:59:59','2018-10-23 23:59:59','VIBEBTC','4h','0.000011580000000','0.000011350000000','0.037531055033645','0.036785619570973','3241.0237507465363','3241.023750746536280','test','test','2.07'),('2018-10-24 03:59:59','2018-10-25 11:59:59','VIBEBTC','4h','0.000011530000000','0.000011450000000','0.037365402708607','0.037106145794757','3240.711423122868','3240.711423122867927','test','test','1.56'),('2018-11-29 15:59:59','2018-11-30 07:59:59','VIBEBTC','4h','0.000007520000000','0.000006960000000','0.037307790061084','0.034529550375684','4961.142295356974','4961.142295356973591','test','test','0.0'),('2018-11-30 15:59:59','2018-11-30 23:59:59','VIBEBTC','4h','0.000007090000000','0.000007060000000','0.036690403464329','0.036535154930629','5174.951123318601','5174.951123318601276','test','test','1.83'),('2018-12-01 03:59:59','2018-12-03 23:59:59','VIBEBTC','4h','0.000007190000000','0.000007860000000','0.036655903790173','0.040071683420133','5098.178552179878','5098.178552179878352','test','test','1.80'),('2018-12-18 19:59:59','2018-12-22 19:59:59','VIBEBTC','4h','0.000007120000000','0.000007350000000','0.037414965930164','0.038623595447571','5254.910945247816','5254.910945247816016','test','test','0.0'),('2018-12-23 03:59:59','2018-12-25 07:59:59','VIBEBTC','4h','0.000007460000000','0.000007180000000','0.037683550267366','0.036269154278779','5051.414244955227','5051.414244955227332','test','test','1.47'),('2018-12-28 07:59:59','2018-12-31 03:59:59','VIBEBTC','4h','0.000007650000000','0.000007440000000','0.037369240047680','0.036343417771861','4884.8679800888885','4884.867980088888544','test','test','6.14'),('2019-01-03 15:59:59','2019-01-03 19:59:59','VIBEBTC','4h','0.000007500000000','0.000007400000000','0.037141279541942','0.036646062481383','4952.170605592325','4952.170605592325046','test','test','0.80'),('2019-01-04 03:59:59','2019-01-07 03:59:59','VIBEBTC','4h','0.000007550000000','0.000008070000000','0.037031231306263','0.039581726707489','4904.798848511611','4904.798848511611141','test','test','1.98'),('2019-01-08 19:59:59','2019-01-10 07:59:59','VIBEBTC','4h','0.000008690000000','0.000008240000000','0.037598008062091','0.035651045619290','4326.583206224473','4326.583206224472633','test','test','9.55'),('2019-01-14 15:59:59','2019-01-18 15:59:59','VIBEBTC','4h','0.000009810000000','0.000010960000000','0.037165349741468','0.041522144053669','3788.516793217964','3788.516793217963823','test','test','16.0'),('2019-01-22 15:59:59','2019-01-27 11:59:59','VIBEBTC','4h','0.000011420000000','0.000011120000000','0.038133526255291','0.037131769873803','3339.187938291652','3339.187938291651790','test','test','4.02'),('2019-02-12 15:59:59','2019-02-13 07:59:59','VIBEBTC','4h','0.000010150000000','0.000010050000000','0.037910913726071','0.037537407186898','3735.0653917311447','3735.065391731144700','test','test','0.0'),('2019-02-20 15:59:59','2019-02-21 07:59:59','VIBEBTC','4h','0.000010230000000','0.000009760000000','0.037827912272922','0.036089972999386','3697.7431351829478','3697.743135182947753','test','test','2.15'),('2019-03-02 15:59:59','2019-03-04 03:59:59','VIBEBTC','4h','0.000010190000000','0.000009670000000','0.037441703545469','0.035531037613806','3674.357560890001','3674.357560890000968','test','test','4.21'),('2019-03-05 15:59:59','2019-03-07 03:59:59','VIBEBTC','4h','0.000010110000000','0.000010030000000','0.037017111116211','0.036724196290366','3661.435323067326','3661.435323067325953','test','test','4.35'),('2019-03-09 11:59:59','2019-03-11 15:59:59','VIBEBTC','4h','0.000010100000000','0.000010380000000','0.036952018932690','0.037976431338745','3658.615735909857','3658.615735909856994','test','test','0.69'),('2019-03-11 19:59:59','2019-03-11 23:59:59','VIBEBTC','4h','0.000010450000000','0.000010380000000','0.037179666134035','0.036930615738879','3557.8627879459436','3557.862787945943637','test','test','3.82'),('2019-03-12 11:59:59','2019-03-13 11:59:59','VIBEBTC','4h','0.000010690000000','0.000010640000000','0.037124321601778','0.036950681182686','3472.808381831452','3472.808381831452152','test','test','2.89'),('2019-03-13 15:59:59','2019-03-13 19:59:59','VIBEBTC','4h','0.000010690000000','0.000010590000000','0.037085734841980','0.036738814965067','3469.1987691281574','3469.198769128157437','test','test','0.46'),('2019-03-14 11:59:59','2019-03-16 07:59:59','VIBEBTC','4h','0.000010820000000','0.000010710000000','0.037008641535999','0.036632398415023','3420.3920088723967','3420.392008872396673','test','test','2.12'),('2019-03-16 11:59:59','2019-03-16 15:59:59','VIBEBTC','4h','0.000010800000000','0.000010620000000','0.036925031953560','0.036309614754334','3418.9844401444648','3418.984440144464770','test','test','0.83'),('2019-03-17 11:59:59','2019-03-18 11:59:59','VIBEBTC','4h','0.000011300000000','0.000011110000000','0.036788272575954','0.036169708700783','3255.599343004818','3255.599343004817911','test','test','6.01'),('2019-03-18 15:59:59','2019-03-20 23:59:59','VIBEBTC','4h','0.000011400000000','0.000010960000000','0.036650813937028','0.035236221118406','3214.983678686628','3214.983678686628082','test','test','3.50'),('2019-03-21 07:59:59','2019-03-21 15:59:59','VIBEBTC','4h','0.000011230000000','0.000010610000000','0.036336459977334','0.034330350877962','3235.659837696686','3235.659837696685827','test','test','2.40'),('2019-03-27 07:59:59','2019-04-02 03:59:59','VIBEBTC','4h','0.000011220000000','0.000011510000000','0.035890657955251','0.036818313107392','3198.810869451971','3198.810869451971030','test','test','5.43'),('2019-05-22 19:59:59','2019-05-24 19:59:59','VIBEBTC','4h','0.000006080000000','0.000005890000000','0.036096803544616','0.034968778433847','5936.974267206541','5936.974267206541299','test','test','0.0'),('2019-05-29 23:59:59','2019-05-30 15:59:59','VIBEBTC','4h','0.000006060000000','0.000005650000000','0.035846131297778','0.033420897992153','5915.203184451853','5915.203184451853303','test','test','2.80'),('2019-05-30 19:59:59','2019-05-30 23:59:59','VIBEBTC','4h','0.000005800000000','0.000005670000000','0.035307190563195','0.034515822498848','6087.446648826704','6087.446648826704404','test','test','2.58'),('2019-05-31 19:59:59','2019-06-03 23:59:59','VIBEBTC','4h','0.000005990000000','0.000005840000000','0.035131330993340','0.034251581469300','5864.996826934892','5864.996826934891942','test','test','5.34'),('2019-06-07 19:59:59','2019-06-09 15:59:59','VIBEBTC','4h','0.000005980000000','0.000005930000000','0.034935831099109','0.034643725487912','5842.112223931253','5842.112223931252629','test','test','2.34'),('2019-06-10 11:59:59','2019-06-12 15:59:59','VIBEBTC','4h','0.000006280000000','0.000006010000000','0.034870918741065','0.033371691342962','5552.694067048584','5552.694067048583747','test','test','5.57');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-26 22:23:02
