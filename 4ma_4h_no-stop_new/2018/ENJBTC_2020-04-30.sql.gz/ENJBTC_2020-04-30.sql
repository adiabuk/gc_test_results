-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-20 15:59:59','2018-04-21 07:59:59','ENJBTC','4h','0.000016110000000','0.000015210000000','0.033333333333333','0.031471135940409','2069.108214359611','2069.108214359610884','test','test','5.58'),('2018-04-22 15:59:59','2018-04-25 03:59:59','ENJBTC','4h','0.000015640000000','0.000015200000000','0.032919511690461','0.031993387320653','2104.8281132008524','2104.828113200852385','test','test','2.81'),('2018-04-27 07:59:59','2018-05-01 03:59:59','ENJBTC','4h','0.000015990000000','0.000016600000000','0.032713706274948','0.033961696320459','2045.8853205095959','2045.885320509595886','test','test','0.0'),('2018-05-01 07:59:59','2018-05-05 11:59:59','ENJBTC','4h','0.000017030000000','0.000017070000000','0.032991037396173','0.033068526620826','1937.2306163342992','1937.230616334299157','test','test','1.17'),('2018-05-20 03:59:59','2018-05-21 03:59:59','ENJBTC','4h','0.000016850000000','0.000016580000000','0.033008257223874','0.032479341529486','1958.9470162536368','1958.947016253636775','test','test','1.60'),('2018-05-21 07:59:59','2018-05-22 23:59:59','ENJBTC','4h','0.000016590000000','0.000016350000000','0.032890720402899','0.032414905279530','1982.5630140384972','1982.563014038497158','test','test','1.44'),('2018-07-04 11:59:59','2018-07-05 23:59:59','ENJBTC','4h','0.000009490000000','0.000009560000000','0.032784983708817','0.033026811828903','3454.6874298015455','3454.687429801545477','test','test','0.0'),('2018-07-07 23:59:59','2018-07-08 03:59:59','ENJBTC','4h','0.000009700000000','0.000009880000000','0.032838723291058','0.033448101661408','3385.435390830722','3385.435390830722099','test','test','0.0'),('2018-07-08 15:59:59','2018-07-09 03:59:59','ENJBTC','4h','0.000009680000000','0.000009420000000','0.032974140706691','0.032088471638123','3406.4194944929063','3406.419494492906324','test','test','2.68'),('2018-07-09 11:59:59','2018-07-09 15:59:59','ENJBTC','4h','0.000009630000000','0.000009870000000','0.032777325358121','0.033594205740878','3403.668261487089','3403.668261487088785','test','test','0.0'),('2018-07-09 19:59:59','2018-07-11 23:59:59','ENJBTC','4h','0.000010260000000','0.000009630000000','0.032958854332067','0.030935065030975','3212.3639699870046','3212.363969987004566','test','test','6.14'),('2018-08-28 23:59:59','2018-09-05 11:59:59','ENJBTC','4h','0.000006250000000','0.000006390000000','0.032509123376268','0.033237327739896','5201.45974020295','5201.459740202950343','test','test','5.44'),('2018-09-05 15:59:59','2018-09-05 23:59:59','ENJBTC','4h','0.000006740000000','0.000006190000000','0.032670946568186','0.030004919771079','4847.321449285723','4847.321449285723247','test','test','8.16'),('2018-09-06 07:59:59','2018-09-08 19:59:59','ENJBTC','4h','0.000006760000000','0.000006650000000','0.032078496168829','0.031556508805135','4745.339669945069','4745.339669945068636','test','test','1.62'),('2018-09-16 11:59:59','2018-09-17 15:59:59','ENJBTC','4h','0.000006470000000','0.000006170000000','0.031962498976897','0.030480466566840','4940.108033523442','4940.108033523441918','test','test','4.63'),('2018-09-20 11:59:59','2018-09-20 23:59:59','ENJBTC','4h','0.000006490000000','0.000006480000000','0.031633158441328','0.031584417056981','4874.13843471933','4874.138434719329780','test','test','0.92'),('2018-09-21 07:59:59','2018-09-21 15:59:59','ENJBTC','4h','0.000006530000000','0.000006240000000','0.031622327022585','0.030217966404430','4842.622821222767','4842.622821222767016','test','test','4.44'),('2018-09-21 19:59:59','2018-09-21 23:59:59','ENJBTC','4h','0.000006520000000','0.000006450000000','0.031310246885217','0.030974093927860','4802.185105094614','4802.185105094614300','test','test','1.07'),('2018-09-22 03:59:59','2018-09-22 07:59:59','ENJBTC','4h','0.000006460000000','0.000006310000000','0.031235546228026','0.030510262646880','4835.223874307498','4835.223874307497681','test','test','2.32'),('2018-09-22 19:59:59','2018-09-24 07:59:59','ENJBTC','4h','0.000006630000000','0.000006430000000','0.031074372098883','0.030136985308570','4686.933951566047','4686.933951566046744','test','test','3.01'),('2018-09-27 19:59:59','2018-10-01 07:59:59','ENJBTC','4h','0.000006560000000','0.000008800000000','0.030866063923258','0.041405695506810','4705.19267122832','4705.192671228320251','test','test','0.60'),('2018-10-21 11:59:59','2018-10-21 23:59:59','ENJBTC','4h','0.000008050000000','0.000007670000000','0.033208204275158','0.031640612023660','4125.242767100402','4125.242767100401579','test','test','4.72'),('2018-10-22 03:59:59','2018-10-22 07:59:59','ENJBTC','4h','0.000007710000000','0.000007750000000','0.032859850441492','0.033030329561811','4261.978007975616','4261.978007975615583','test','test','0.0'),('2018-10-22 11:59:59','2018-10-23 03:59:59','ENJBTC','4h','0.000007780000000','0.000007740000000','0.032897734690452','0.032728594666337','4228.500602885832','4228.500602885832450','test','test','0.51'),('2018-10-23 07:59:59','2018-10-23 15:59:59','ENJBTC','4h','0.000007750000000','0.000007910000000','0.032860148018426','0.033538551074290','4240.01909915177','4240.019099151770206','test','test','0.0'),('2018-10-23 19:59:59','2018-10-24 15:59:59','ENJBTC','4h','0.000007940000000','0.000007860000000','0.033010904253063','0.032678300683763','4157.544616254744','4157.544616254744142','test','test','1.63'),('2018-10-24 19:59:59','2018-10-25 23:59:59','ENJBTC','4h','0.000008020000000','0.000007820000000','0.032936992348774','0.032115620968505','4106.8569013433635','4106.856901343363461','test','test','2.49'),('2018-11-01 11:59:59','2018-11-02 23:59:59','ENJBTC','4h','0.000008120000000','0.000007810000000','0.032754465375381','0.031503987017454','4033.8011546035295','4033.801154603529540','test','test','3.81'),('2018-11-03 03:59:59','2018-11-03 11:59:59','ENJBTC','4h','0.000007920000000','0.000007770000000','0.032476581295841','0.031861494528874','4100.578446444612','4100.578446444612382','test','test','1.89'),('2018-11-09 15:59:59','2018-11-11 15:59:59','ENJBTC','4h','0.000007930000000','0.000007770000000','0.032339895347626','0.031687388001394','4078.170913950371','4078.170913950370959','test','test','2.01'),('2018-11-12 07:59:59','2018-11-12 19:59:59','ENJBTC','4h','0.000008040000000','0.000007810000000','0.032194893715130','0.031273895511836','4004.3400143197073','4004.340014319707279','test','test','2.86'),('2018-11-12 23:59:59','2018-11-13 03:59:59','ENJBTC','4h','0.000007860000000','0.000007860000000','0.031990227447732','0.031990227447732','4070.003492077835','4070.003492077834835','test','test','0.0'),('2018-11-13 07:59:59','2018-11-13 11:59:59','ENJBTC','4h','0.000007910000000','0.000007800000000','0.031990227447732','0.031545357028105','4044.2765420646997','4044.276542064699697','test','test','1.39'),('2018-12-01 03:59:59','2018-12-05 07:59:59','ENJBTC','4h','0.000006710000000','0.000007220000000','0.031891367354481','0.034315301385895','4752.811826301241','4752.811826301241126','test','test','2.23'),('2018-12-07 15:59:59','2018-12-14 15:59:59','ENJBTC','4h','0.000007180000000','0.000008350000000','0.032430019361462','0.037714576834012','4516.715788504487','4516.715788504487136','test','test','0.0'),('2018-12-14 23:59:59','2018-12-18 11:59:59','ENJBTC','4h','0.000008800000000','0.000009230000000','0.033604365466473','0.035246396960857','3818.677893917424','3818.677893917424171','test','test','2.50'),('2018-12-18 19:59:59','2018-12-19 15:59:59','ENJBTC','4h','0.000009740000000','0.000009190000000','0.033969261354114','0.032051079244795','3487.603835124664','3487.603835124663874','test','test','5.64'),('2018-12-20 03:59:59','2018-12-25 07:59:59','ENJBTC','4h','0.000009590000000','0.000010240000000','0.033542998663154','0.035816507435943','3497.705804291392','3497.705804291391814','test','test','0.0'),('2018-12-27 03:59:59','2018-12-30 03:59:59','ENJBTC','4h','0.000011480000000','0.000010780000000','0.034048222834885','0.031972111686416','2965.8730692408826','2965.873069240882614','test','test','6.35'),('2019-01-22 23:59:59','2019-01-24 03:59:59','ENJBTC','4h','0.000009640000000','0.000009520000000','0.033586864801892','0.033168771049171','3484.1146060054175','3484.114606005417500','test','test','1.24'),('2019-01-24 07:59:59','2019-01-25 11:59:59','ENJBTC','4h','0.000009530000000','0.000009540000000','0.033493955079065','0.033529100887123','3514.5808057781046','3514.580805778104605','test','test','0.0'),('2019-01-25 15:59:59','2019-01-25 19:59:59','ENJBTC','4h','0.000009620000000','0.000009570000000','0.033501765258634','0.033327639659577','3482.5119811469626','3482.511981146962626','test','test','0.51'),('2019-02-12 15:59:59','2019-02-16 19:59:59','ENJBTC','4h','0.000008440000000','0.000008490000000','0.033463070681066','0.033661311621120','3964.818801074118','3964.818801074117800','test','test','0.94'),('2019-02-17 15:59:59','2019-02-24 03:59:59','ENJBTC','4h','0.000008660000000','0.000009500000000','0.033507124223300','0.036757237889301','3869.18293571591','3869.182935715909935','test','test','0.0'),('2019-02-25 03:59:59','2019-03-02 03:59:59','ENJBTC','4h','0.000011100000000','0.000019990000000','0.034229371704633','0.061643706340145','3083.727180597598','3083.727180597597908','test','test','0.27'),('2019-03-02 19:59:59','2019-03-04 15:59:59','ENJBTC','4h','0.000022200000000','0.000020480000000','0.040321446068080','0.037197442138481','1816.281354418038','1816.281354418038063','test','test','7.79'),('2019-03-05 03:59:59','2019-03-11 19:59:59','ENJBTC','4h','0.000021620000000','0.000044410000000','0.039627222972614','0.081398934885004','1832.8965297231268','1832.896529723126832','test','test','0.0'),('2019-03-18 11:59:59','2019-03-23 11:59:59','ENJBTC','4h','0.000050800000000','0.000046200000000','0.048909825619812','0.044480983142427','962.7918429096808','962.791842909680781','test','test','11.0'),('2019-04-14 11:59:59','2019-04-15 03:59:59','ENJBTC','4h','0.000033810000000','0.000030660000000','0.047925638402615','0.043460516812309','1417.4989175573826','1417.498917557382583','test','test','9.31'),('2019-04-15 07:59:59','2019-04-15 15:59:59','ENJBTC','4h','0.000031700000000','0.000030060000000','0.046933389160325','0.044505289531841','1480.5485539534666','1480.548553953466580','test','test','5.17'),('2019-04-17 15:59:59','2019-04-20 11:59:59','ENJBTC','4h','0.000034280000000','0.000037730000000','0.046393811465106','0.051062966936361','1353.378397465176','1353.378397465176022','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 23:40:29
