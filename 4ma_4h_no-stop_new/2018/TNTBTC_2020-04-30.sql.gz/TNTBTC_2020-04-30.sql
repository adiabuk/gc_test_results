-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-03 11:59:59','2018-06-04 03:59:59','TNTBTC','4h','0.000010790000000','0.000010380000000','0.033333333333333','0.032066728452270','3089.2801977139325','3089.280197713932466','test','test','3.79'),('2018-07-03 15:59:59','2018-07-03 23:59:59','TNTBTC','4h','0.000007470000000','0.000007140000000','0.033051865581986','0.031591743006075','4424.613866397054','4424.613866397054153','test','test','4.41'),('2018-07-04 00:22:27','2018-07-04 11:59:59','TNTBTC','4h','0.000007170000000','0.000007370000000','0.032727393898450','0.033640291915143','4564.49008346586','4564.490083465860153','test','test','0.0'),('2018-07-04 15:59:59','2018-07-06 07:59:59','TNTBTC','4h','0.000007650000000','0.000006880000000','0.032930260124382','0.029615711066111','4304.609166585883','4304.609166585883031','test','test','10.0'),('2018-08-28 15:59:59','2018-09-02 11:59:59','TNTBTC','4h','0.000003110000000','0.000003110000000','0.032193693666988','0.032193693666988','10351.669989385353','10351.669989385352892','test','test','2.25'),('2018-09-02 19:59:59','2018-09-02 23:59:59','TNTBTC','4h','0.000003330000000','0.000003260000000','0.032193693666988','0.031516949355670','9667.775875972507','9667.775875972507492','test','test','2.10'),('2018-09-15 23:59:59','2018-09-18 19:59:59','TNTBTC','4h','0.000003660000000','0.000003860000000','0.032043306042251','0.033794306372429','8755.00165088828','8755.001650888279983','test','test','9.83'),('2018-09-21 03:59:59','2018-09-22 03:59:59','TNTBTC','4h','0.000004310000000','0.000003790000000','0.032432417226735','0.028519457375714','7524.922790425779','7524.922790425778658','test','test','12.0'),('2018-09-22 15:59:59','2018-09-24 11:59:59','TNTBTC','4h','0.000004300000000','0.000003950000000','0.031562870593175','0.028993799730940','7340.202463529042','7340.202463529041779','test','test','8.13'),('2018-09-24 19:59:59','2018-09-24 23:59:59','TNTBTC','4h','0.000004230000000','0.000004090000000','0.030991965957123','0.029966227131119','7326.705900028998','7326.705900028998258','test','test','3.30'),('2018-09-28 07:59:59','2018-09-29 03:59:59','TNTBTC','4h','0.000004300000000','0.000003980000000','0.030764023995788','0.028474608256567','7154.424185067079','7154.424185067078724','test','test','7.44'),('2018-09-29 11:59:59','2018-10-07 15:59:59','TNTBTC','4h','0.000004030000000','0.000004440000000','0.030255264942628','0.033333344006270','7507.509911322138','7507.509911322137668','test','test','0.0'),('2018-10-08 23:59:59','2018-10-09 11:59:59','TNTBTC','4h','0.000004590000000','0.000004430000000','0.030939282512326','0.029860789004271','6740.584425343451','6740.584425343450675','test','test','3.48'),('2018-10-10 23:59:59','2018-10-11 03:59:59','TNTBTC','4h','0.000004630000000','0.000004360000000','0.030699617288314','0.028909358828736','6630.5868873248855','6630.586887324885538','test','test','5.83'),('2018-10-15 03:59:59','2018-10-15 07:59:59','TNTBTC','4h','0.000004350000000','0.000004300000000','0.030301782075075','0.029953485729384','6965.926913810268','6965.926913810268161','test','test','1.14'),('2018-10-15 11:59:59','2018-10-15 19:59:59','TNTBTC','4h','0.000004380000000','0.000004270000000','0.030224382887143','0.029465323042945','6900.544038160577','6900.544038160576747','test','test','2.51'),('2018-10-15 23:59:59','2018-10-16 03:59:59','TNTBTC','4h','0.000004410000000','0.000004350000000','0.030055702921766','0.029646781793579','6815.352136454874','6815.352136454874199','test','test','1.36'),('2018-10-16 07:59:59','2018-10-18 23:59:59','TNTBTC','4h','0.000004550000000','0.000004640000000','0.029964831559947','0.030557542513880','6585.677265922344','6585.677265922344304','test','test','0.0'),('2018-10-20 15:59:59','2018-10-22 07:59:59','TNTBTC','4h','0.000004910000000','0.000004680000000','0.030096545105265','0.028686727310110','6129.642587630368','6129.642587630368325','test','test','4.68'),('2018-10-23 03:59:59','2018-10-27 07:59:59','TNTBTC','4h','0.000004870000000','0.000005390000000','0.029783252261897','0.032963394187192','6115.657548644216','6115.657548644216149','test','test','0.0'),('2018-10-30 19:59:59','2018-10-31 07:59:59','TNTBTC','4h','0.000005870000000','0.000005350000000','0.030489950467518','0.027788966780447','5194.199398214386','5194.199398214385837','test','test','8.85'),('2018-10-31 11:59:59','2018-10-31 15:59:59','TNTBTC','4h','0.000005360000000','0.000005370000000','0.029889731870392','0.029945496295523','5576.4425131327525','5576.442513132752538','test','test','0.0'),('2018-10-31 19:59:59','2018-11-01 11:59:59','TNTBTC','4h','0.000005440000000','0.000005390000000','0.029902123964865','0.029627288266659','5496.713964129616','5496.713964129616215','test','test','1.28'),('2018-11-01 15:59:59','2018-11-04 07:59:59','TNTBTC','4h','0.000005430000000','0.000005380000000','0.029841049365264','0.029566269905179','5495.589201706036','5495.589201706035965','test','test','0.92'),('2018-11-10 07:59:59','2018-11-11 19:59:59','TNTBTC','4h','0.000005550000000','0.000005430000000','0.029779987263023','0.029136095646525','5365.763470814894','5365.763470814894390','test','test','2.16'),('2018-11-30 07:59:59','2018-12-03 03:59:59','TNTBTC','4h','0.000003990000000','0.000003950000000','0.029636900237134','0.029339788455308','7427.7945456476755','7427.794545647675477','test','test','1.00'),('2018-12-14 03:59:59','2018-12-15 03:59:59','TNTBTC','4h','0.000003790000000','0.000003560000000','0.029570875396728','0.027776336784262','7802.3417933320425','7802.341793332042471','test','test','6.06'),('2018-12-15 07:59:59','2018-12-15 11:59:59','TNTBTC','4h','0.000003740000000','0.000003690000000','0.029172089038403','0.028782087848050','7800.023807059536','7800.023807059536011','test','test','1.33'),('2018-12-17 15:59:59','2018-12-17 19:59:59','TNTBTC','4h','0.000003860000000','0.000003720000000','0.029085422107213','0.028030510424568','7535.083447464536','7535.083447464536221','test','test','3.62'),('2019-01-06 19:59:59','2019-01-07 23:59:59','TNTBTC','4h','0.000003360000000','0.000003180000000','0.028850997288848','0.027305408148374','8586.606335966533','8586.606335966533152','test','test','5.35'),('2019-01-09 11:59:59','2019-01-10 07:59:59','TNTBTC','4h','0.000003410000000','0.000003160000000','0.028507533035409','0.026417537944836','8359.980362289996','8359.980362289996265','test','test','7.33'),('2019-01-12 23:59:59','2019-01-13 19:59:59','TNTBTC','4h','0.000003410000000','0.000003140000000','0.028043089681948','0.025822669091295','8223.77996538071','8223.779965380710564','test','test','7.91'),('2019-01-13 23:59:59','2019-01-14 03:59:59','TNTBTC','4h','0.000003190000000','0.000003230000000','0.027549662884025','0.027895113202320','8636.257957374712','8636.257957374711623','test','test','0.0'),('2019-01-14 19:59:59','2019-01-18 11:59:59','TNTBTC','4h','0.000003300000000','0.000004550000000','0.027626429621424','0.038090986296206','8371.645339825522','8371.645339825521660','test','test','0.0'),('2019-01-21 19:59:59','2019-01-22 23:59:59','TNTBTC','4h','0.000004900000000','0.000004430000000','0.029951886660265','0.027078950592852','6112.629930666259','6112.629930666258588','test','test','11.0'),('2019-01-25 15:59:59','2019-01-27 03:59:59','TNTBTC','4h','0.000004540000000','0.000004320000000','0.029313456423062','0.027892980561152','6456.708463229465','6456.708463229465451','test','test','4.84'),('2019-02-10 19:59:59','2019-02-11 19:59:59','TNTBTC','4h','0.000004110000000','0.000004050000000','0.028997795120415','0.028574469644205','7055.424603507327','7055.424603507327447','test','test','1.70'),('2019-02-20 11:59:59','2019-02-20 15:59:59','TNTBTC','4h','0.000003930000000','0.000003940000000','0.028903722792368','0.028977269160796','7354.636842841845','7354.636842841844555','test','test','0.0'),('2019-02-20 23:59:59','2019-02-21 11:59:59','TNTBTC','4h','0.000004070000000','0.000003930000000','0.028920066429797','0.027925272989951','7105.667427468523','7105.667427468522874','test','test','3.43'),('2019-02-21 15:59:59','2019-02-21 23:59:59','TNTBTC','4h','0.000003960000000','0.000004020000000','0.028699001220942','0.029133834572774','7247.222530540963','7247.222530540962907','test','test','0.25'),('2019-02-22 07:59:59','2019-02-24 03:59:59','TNTBTC','4h','0.000004060000000','0.000004130000000','0.028795630854683','0.029292107248729','7092.519914946468','7092.519914946467907','test','test','0.0'),('2019-02-26 15:59:59','2019-02-27 15:59:59','TNTBTC','4h','0.000004190000000','0.000004000000000','0.028905958942248','0.027595187534366','6898.796883591514','6898.796883591514415','test','test','4.53'),('2019-02-27 19:59:59','2019-02-27 23:59:59','TNTBTC','4h','0.000004040000000','0.000004050000000','0.028614676407164','0.028685504814112','7082.840694842464','7082.840694842463563','test','test','0.0'),('2019-03-01 11:59:59','2019-03-01 15:59:59','TNTBTC','4h','0.000004100000000','0.000004020000000','0.028630416053152','0.028071773788700','6983.02830564683','6983.028305646829722','test','test','1.95'),('2019-03-04 15:59:59','2019-03-04 23:59:59','TNTBTC','4h','0.000004190000000','0.000004290000000','0.028506273327718','0.029186613979931','6803.406522128453','6803.406522128452707','test','test','1.43'),('2019-03-05 11:59:59','2019-03-05 19:59:59','TNTBTC','4h','0.000004250000000','0.000004210000000','0.028657460139321','0.028387742867422','6742.93179748732','6742.931797487320182','test','test','2.35'),('2019-03-06 11:59:59','2019-03-06 15:59:59','TNTBTC','4h','0.000004120000000','0.000004150000000','0.028597522967788','0.028805757358330','6941.146351404854','6941.146351404853704','test','test','0.0'),('2019-03-07 23:59:59','2019-03-08 03:59:59','TNTBTC','4h','0.000004160000000','0.000004150000000','0.028643797276797','0.028574941994882','6885.528191537821','6885.528191537820931','test','test','0.24'),('2019-03-08 07:59:59','2019-03-11 15:59:59','TNTBTC','4h','0.000004210000000','0.000004270000000','0.028628496103038','0.029036503173390','6800.117839201529','6800.117839201529023','test','test','0.0'),('2019-03-11 19:59:59','2019-03-11 23:59:59','TNTBTC','4h','0.000004280000000','0.000004710000000','0.028719164340894','0.031604500945236','6710.0851263772065','6710.085126377206507','test','test','0.0'),('2019-03-12 11:59:59','2019-03-16 11:59:59','TNTBTC','4h','0.000004610000000','0.000004850000000','0.029360350252970','0.030888871741194','6368.839534266907','6368.839534266907322','test','test','0.0'),('2019-03-20 11:59:59','2019-03-21 07:59:59','TNTBTC','4h','0.000004890000000','0.000004840000000','0.029700021694798','0.029396340491375','6073.624068465849','6073.624068465848723','test','test','1.02'),('2019-03-26 23:59:59','2019-04-01 19:59:59','TNTBTC','4h','0.000005120000000','0.000005210000000','0.029632536982926','0.030153421422079','5787.604879477778','5787.604879477778013','test','test','2.73');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 23:38:02
