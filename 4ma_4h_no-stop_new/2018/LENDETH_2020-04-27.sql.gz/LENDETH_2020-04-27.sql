-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-01 15:59:59','2018-06-03 11:59:59','LENDETH','4h','0.000079600000000','0.000079600000000','1.297777777777778','1.297777777777778','16303.740926856504','16303.740926856504302','test','test','0.0'),('2018-07-01 03:59:59','2018-07-05 19:59:59','LENDETH','4h','0.000061010000000','0.000067570000000','1.297777777777778','1.437319200859604','21271.55839661986','21271.558396619861014','test','test','0.0'),('2018-07-18 07:59:59','2018-07-20 03:59:59','LENDETH','4h','0.000066480000000','0.000061200000000','1.328786982907072','1.223251554661745','19987.770501008912','19987.770501008912106','test','test','0.0'),('2018-07-31 03:59:59','2018-07-31 11:59:59','LENDETH','4h','0.000061700000000','0.000058380000000','1.305334665519222','1.235096236191445','21156.153411980908','21156.153411980907549','test','test','1.29'),('2018-08-25 11:59:59','2018-08-26 07:59:59','LENDETH','4h','0.000046540000000','0.000046750000000','1.289726125668605','1.295545689192249','27712.207255449186','27712.207255449186050','test','test','0.0'),('2018-08-26 11:59:59','2018-08-30 03:59:59','LENDETH','4h','0.000047950000000','0.000049000000000','1.291019362007192','1.319289858985451','26924.282836437797','26924.282836437796504','test','test','2.50'),('2018-08-31 15:59:59','2018-09-03 07:59:59','LENDETH','4h','0.000050770000000','0.000050610000000','1.297301694669028','1.293213290667707','25552.525008253455','25552.525008253454871','test','test','3.48'),('2018-09-03 19:59:59','2018-09-12 03:59:59','LENDETH','4h','0.000051720000000','0.000057910000000','1.296393160446512','1.451549263755946','25065.606350473936','25065.606350473935890','test','test','2.14'),('2018-09-17 03:59:59','2018-09-21 15:59:59','LENDETH','4h','0.000063670000000','0.000061810000000','1.330872294515275','1.291993348892558','20902.658936944794','20902.658936944793822','test','test','9.04'),('2018-09-25 19:59:59','2018-09-26 19:59:59','LENDETH','4h','0.000062710000000','0.000060790000000','1.322232528821338','1.281749568283354','21084.875280199933','21084.875280199932604','test','test','6.90'),('2018-09-26 23:59:59','2018-09-28 03:59:59','LENDETH','4h','0.000062370000000','0.000061790000000','1.313236315368453','1.301024080914169','21055.576645317506','21055.576645317505609','test','test','2.53'),('2018-09-28 07:59:59','2018-09-30 11:59:59','LENDETH','4h','0.000064360000000','0.000063000000000','1.310522485489723','1.282829654845441','20362.375473737153','20362.375473737152788','test','test','4.90'),('2018-10-03 03:59:59','2018-10-07 23:59:59','LENDETH','4h','0.000065220000000','0.000072130000000','1.304368523124327','1.442565188177824','19999.517373878058','19999.517373878057697','test','test','3.40'),('2018-10-08 07:59:59','2018-10-11 07:59:59','LENDETH','4h','0.000075900000000','0.000075720000000','1.335078893136215','1.331912698132730','17589.972241583862','17589.972241583862342','test','test','10.9'),('2018-10-13 03:59:59','2018-10-13 11:59:59','LENDETH','4h','0.000079130000000','0.000073610000000','1.334375294246552','1.241291108422706','16863.077142001162','16863.077142001162429','test','test','4.30'),('2018-10-13 15:59:59','2018-10-13 19:59:59','LENDETH','4h','0.000075280000000','0.000075450000000','1.313689919619031','1.316656541382252','17450.71625423792','17450.716254237919202','test','test','2.21'),('2018-10-14 07:59:59','2018-10-15 07:59:59','LENDETH','4h','0.000077000000000','0.000073000000000','1.314349168899746','1.246071289995863','17069.46972597073','17069.469725970731815','test','test','2.01'),('2018-10-18 03:59:59','2018-10-22 07:59:59','LENDETH','4h','0.000077560000000','0.000089140000000','1.299176306921106','1.493148220718765','16750.597046429935','16750.597046429935290','test','test','5.87'),('2018-10-23 07:59:59','2018-10-25 19:59:59','LENDETH','4h','0.000099810000000','0.000094760000000','1.342281176653919','1.274366940183603','13448.363657488417','13448.363657488416720','test','test','20.2'),('2018-10-27 07:59:59','2018-11-03 07:59:59','LENDETH','4h','0.000099100000000','0.000108560000000','1.327189124104960','1.453881446143637','13392.42304848597','13392.423048485970867','test','test','4.37'),('2018-11-29 11:59:59','2018-11-30 11:59:59','LENDETH','4h','0.000078850000000','0.000072440000000','1.355342973446888','1.245162270088682','17188.877278971308','17188.877278971307533','test','test','0.0'),('2018-12-01 03:59:59','2018-12-05 19:59:59','LENDETH','4h','0.000077600000000','0.000080880000000','1.330858372700620','1.387111149278687','17150.236761605924','17150.236761605923675','test','test','6.64'),('2018-12-14 15:59:59','2018-12-14 19:59:59','LENDETH','4h','0.000077700000000','0.000076450000000','1.343358989717968','1.321747680359571','17289.047486717736','17289.047486717736319','test','test','0.0'),('2018-12-14 23:59:59','2018-12-19 15:59:59','LENDETH','4h','0.000078520000000','0.000080500000000','1.338556476527213','1.372310193077441','17047.33159102411','17047.331591024110821','test','test','2.63'),('2019-01-11 23:59:59','2019-01-12 07:59:59','LENDETH','4h','0.000056310000000','0.000055460000000','1.346057302427264','1.325738554299699','23904.40956184095','23904.409561840948300','test','test','0.0'),('2019-01-12 11:59:59','2019-01-12 15:59:59','LENDETH','4h','0.000055840000000','0.000055500000000','1.341542025065583','1.333373610156516','24024.749732549833','24024.749732549833425','test','test','0.68'),('2019-01-12 19:59:59','2019-01-20 11:59:59','LENDETH','4h','0.000057470000000','0.000067110000000','1.339726821752457','1.564452183883894','23311.759557203008','23311.759557203007716','test','test','3.42'),('2019-01-22 11:59:59','2019-01-27 15:59:59','LENDETH','4h','0.000069660000000','0.000071030000000','1.389665791114998','1.416996283992224','19949.264873887427','19949.264873887426802','test','test','3.66'),('2019-01-30 11:59:59','2019-01-30 15:59:59','LENDETH','4h','0.000072330000000','0.000070520000000','1.395739233976604','1.360811983686300','19296.823364808573','19296.823364808573388','test','test','1.79'),('2019-02-02 19:59:59','2019-02-03 03:59:59','LENDETH','4h','0.000073720000000','0.000069100000000','1.387977622800981','1.300993675197338','18827.694286502723','18827.694286502723116','test','test','4.34'),('2019-02-03 11:59:59','2019-02-03 15:59:59','LENDETH','4h','0.000070910000000','0.000070350000000','1.368647856666838','1.357839186525343','19301.19668124155','19301.196681241548504','test','test','2.55'),('2019-02-03 19:59:59','2019-02-03 23:59:59','LENDETH','4h','0.000070890000000','0.000070660000000','1.366245929968728','1.361813195254483','19272.75962715091','19272.759627150910092','test','test','0.76'),('2019-03-01 11:59:59','2019-03-01 15:59:59','LENDETH','4h','0.000057330000000','0.000056710000000','1.365260877810007','1.350496151763570','23814.07426844596','23814.074268445958296','test','test','0.0'),('2019-03-01 19:59:59','2019-03-06 03:59:59','LENDETH','4h','0.000057900000000','0.000063330000000','1.361979827577465','1.489709541977217','23522.967661096118','23522.967661096117808','test','test','2.05'),('2019-03-08 19:59:59','2019-03-16 07:59:59','LENDETH','4h','0.000066070000000','0.000068980000000','1.390364208555188','1.451601681642755','21043.80518473117','21043.805184731168993','test','test','4.14'),('2019-03-27 15:59:59','2019-03-31 03:59:59','LENDETH','4h','0.000068980000000','0.000069690000000','1.403972535907981','1.418423398484013','20353.327571875627','20353.327571875626745','test','test','2.60'),('2019-04-01 11:59:59','2019-04-02 07:59:59','LENDETH','4h','0.000073210000000','0.000071990000000','1.407183838702655','1.383733978257125','19221.19708649986','19221.197086499858415','test','test','5.77'),('2019-04-05 15:59:59','2019-04-06 15:59:59','LENDETH','4h','0.000072970000000','0.000069500000000','1.401972758603648','1.335303641536981','19213.002036503327','19213.002036503326963','test','test','3.16'),('2019-04-19 19:59:59','2019-04-19 23:59:59','LENDETH','4h','0.000065780000000','0.000065300000000','1.387157399255500','1.377035241279783','21087.82911607631','21087.829116076311038','test','test','0.0'),('2019-04-20 11:59:59','2019-04-20 15:59:59','LENDETH','4h','0.000066200000000','0.000064980000000','1.384908030816451','1.359385556532523','20920.060888466032','20920.060888466032338','test','test','1.35'),('2019-05-23 03:59:59','2019-05-24 15:59:59','LENDETH','4h','0.000039830000000','0.000038310000000','1.379236369864467','1.326601690421986','34628.078580579146','34628.078580579145637','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27  8:14:02
