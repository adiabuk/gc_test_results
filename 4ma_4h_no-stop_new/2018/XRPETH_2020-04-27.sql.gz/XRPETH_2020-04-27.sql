-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-19 15:59:59','2018-04-22 15:59:59','XRPETH','4h','0.001335000000000','0.001399100000000','1.297777777777778','1.360090553474823','972.1181856013316','972.118185601331561','test','test','0.0'),('2018-05-24 07:59:59','2018-05-31 11:59:59','XRPETH','4h','0.001022000000000','0.001062700000000','1.311625061266010','1.363859053431888','1283.3904709060764','1283.390470906076416','test','test','0.0'),('2018-06-01 23:59:59','2018-06-03 19:59:59','XRPETH','4h','0.001075290000000','0.001066570000000','1.323232615080650','1.312501939259705','1230.58208955784','1230.582089557839936','test','test','5.48'),('2018-06-03 23:59:59','2018-06-09 15:59:59','XRPETH','4h','0.001113950000000','0.001106470000000','1.320848020453773','1.311978732610517','1185.733668884396','1185.733668884395911','test','test','4.25'),('2018-06-12 19:59:59','2018-06-13 19:59:59','XRPETH','4h','0.001129000000000','0.001102520000000','1.318877067599716','1.287943617865402','1168.1816364922195','1168.181636492219468','test','test','1.99'),('2018-06-13 23:59:59','2018-06-14 03:59:59','XRPETH','4h','0.001112930000000','0.001125040000000','1.312002967658757','1.326279117945251','1178.8728560275645','1178.872856027564467','test','test','0.93'),('2018-06-14 07:59:59','2018-06-14 19:59:59','XRPETH','4h','0.001131750000000','0.001075240000000','1.315175445500200','1.249506733836656','1162.0724060085713','1162.072406008571306','test','test','0.59'),('2018-06-27 03:59:59','2018-06-28 15:59:59','XRPETH','4h','0.001059700000000','0.001057100000000','1.300582398463857','1.297391387577751','1227.3118792713574','1227.311879271357384','test','test','0.0'),('2018-06-28 23:59:59','2018-06-29 11:59:59','XRPETH','4h','0.001060350000000','0.001042860000000','1.299873284933611','1.278432455251441','1225.8907765677477','1225.890776567747707','test','test','0.50'),('2018-07-04 19:59:59','2018-07-05 03:59:59','XRPETH','4h','0.001065490000000','0.001048280000000','1.295108656115352','1.274189811291144','1215.5052193031859','1215.505219303185868','test','test','2.12'),('2018-07-18 11:59:59','2018-07-18 19:59:59','XRPETH','4h','0.001030000000000','0.001015460000000','1.290460023932194','1.272243238739986','1252.873809642907','1252.873809642906963','test','test','0.0'),('2018-07-18 23:59:59','2018-07-19 03:59:59','XRPETH','4h','0.001018320000000','0.001006390000000','1.286411849445037','1.271341053070735','1263.268765658179','1263.268765658179063','test','test','0.28'),('2018-07-19 07:59:59','2018-07-19 11:59:59','XRPETH','4h','0.001006620000000','0.001018000000000','1.283062783584081','1.297568013439624','1274.6247676224207','1274.624767622420677','test','test','0.02'),('2018-07-19 15:59:59','2018-07-19 23:59:59','XRPETH','4h','0.001028700000000','0.001018880000000','1.286286167996424','1.274007242974819','1250.3996967011021','1250.399696701102130','test','test','1.04'),('2018-07-31 15:59:59','2018-08-06 11:59:59','XRPETH','4h','0.001002400000000','0.001047020000000','1.283557517991623','1.340692729935743','1280.4843555383306','1280.484355538330647','test','test','0.0'),('2018-08-15 07:59:59','2018-08-15 19:59:59','XRPETH','4h','0.001014020000000','0.000991860000000','1.296254231756983','1.267926394262915','1278.3320168803207','1278.332016880320680','test','test','1.55'),('2018-08-15 23:59:59','2018-08-24 15:59:59','XRPETH','4h','0.000998660000000','0.001167000000000','1.289959156758301','1.507402254958582','1291.6900213869594','1291.690021386959415','test','test','0.97'),('2018-08-26 03:59:59','2018-08-29 11:59:59','XRPETH','4h','0.001186900000000','0.001181100000000','1.338279845247252','1.331740100447830','1127.5422067969098','1127.542206796909795','test','test','16.4'),('2018-08-29 19:59:59','2018-08-30 07:59:59','XRPETH','4h','0.001197570000000','0.001186990000000','1.336826568625159','1.325016298581609','1116.2826128119095','1116.282612811909530','test','test','16.3'),('2018-09-05 23:59:59','2018-09-13 15:59:59','XRPETH','4h','0.001222490000000','0.001376730000000','1.334202064171036','1.502536632451955','1091.3807590827216','1091.380759082721625','test','test','16.6'),('2018-09-18 11:59:59','2018-09-24 19:59:59','XRPETH','4h','0.001562510000000','0.002220550000000','1.371609746011241','1.949253458541232','877.82461936963','877.824619369630000','test','test','32.9'),('2018-09-26 07:59:59','2018-09-28 11:59:59','XRPETH','4h','0.002480670000000','0.002344870000000','1.499975015462350','1.417861470694289','604.6652781153276','604.665278115327624','test','test','56.6'),('2018-09-28 19:59:59','2018-10-01 19:59:59','XRPETH','4h','0.002426800000000','0.002389810000000','1.481727561069447','1.459142633393512','610.5684692061345','610.568469206134523','test','test','45.0'),('2018-10-01 23:59:59','2018-10-02 03:59:59','XRPETH','4h','0.002498760000000','0.002471490000000','1.476708688252573','1.460592756378905','590.9765996944775','590.976599694477500','test','test','4.36'),('2018-10-16 23:59:59','2018-10-21 07:59:59','XRPETH','4h','0.002250180000000','0.002249500000000','1.473127370058424','1.472682193845126','654.6709019093691','654.670901909369150','test','test','0.0'),('2018-10-24 07:59:59','2018-10-27 03:59:59','XRPETH','4h','0.002284270000000','0.002255610000000','1.473028442011025','1.454546828564262','644.8574126574462','644.857412657446162','test','test','1.64'),('2018-10-30 03:59:59','2018-10-31 03:59:59','XRPETH','4h','0.002283150000000','0.002262790000000','1.468921416800633','1.455822303712986','643.3749060730277','643.374906073027660','test','test','1.20'),('2018-10-31 07:59:59','2018-10-31 11:59:59','XRPETH','4h','0.002264540000000','0.002262290000000','1.466010502781156','1.464553905136046','647.3767311600394','647.376731160039412','test','test','0.07'),('2018-10-31 15:59:59','2018-11-03 19:59:59','XRPETH','4h','0.002286340000000','0.002287000000000','1.465686814415576','1.466109915659273','641.0624904500537','641.062490450053701','test','test','1.05'),('2018-11-05 23:59:59','2018-11-08 15:59:59','XRPETH','4h','0.002385510000000','0.002378910000000','1.465780836914175','1.461725455245839','614.4517679297824','614.451767929782363','test','test','4.12'),('2018-11-12 07:59:59','2018-11-12 11:59:59','XRPETH','4h','0.002396640000000','0.002386470000000','1.464879640987878','1.458663510927107','611.2222281977596','611.222228197759591','test','test','0.73'),('2018-11-12 15:59:59','2018-11-14 19:59:59','XRPETH','4h','0.002478500000000','0.002506570000000','1.463498278752152','1.480072979855470','590.4774172895508','590.477417289550772','test','test','3.71'),('2018-11-14 23:59:59','2018-11-25 03:59:59','XRPETH','4h','0.002586730000000','0.003166640000000','1.467181545664000','1.796103872364510','567.1954729190909','567.195472919090889','test','test','4.45'),('2018-11-26 23:59:59','2018-11-28 15:59:59','XRPETH','4h','0.003283100000000','0.003259500000000','1.540275396041891','1.529203391123799','469.1527507666203','469.152750766620272','test','test','3.54'),('2018-12-04 03:59:59','2018-12-04 07:59:59','XRPETH','4h','0.003214530000000','0.003193960000000','1.537814950504537','1.527974366179028','478.39495991779114','478.394959917791141','test','test','0.0'),('2018-12-04 11:59:59','2018-12-04 15:59:59','XRPETH','4h','0.003203380000000','0.003187180000000','1.535628153987757','1.527862239205682','479.3774556836084','479.377455683608389','test','test','0.29'),('2018-12-04 19:59:59','2018-12-04 23:59:59','XRPETH','4h','0.003196000000000','0.003205770000000','1.533902395147296','1.538591452218820','479.94442901980483','479.944429019804829','test','test','0.27'),('2018-12-05 03:59:59','2018-12-07 19:59:59','XRPETH','4h','0.003231380000000','0.003203020000000','1.534944407829857','1.521473066357776','475.0120406234666','475.012040623466589','test','test','0.79'),('2018-12-07 23:59:59','2018-12-08 03:59:59','XRPETH','4h','0.003233320000000','0.003298690000000','1.531950776391617','1.562923158417745','473.8011630125125','473.801163012512518','test','test','0.93'),('2018-12-08 07:59:59','2018-12-09 15:59:59','XRPETH','4h','0.003348520000000','0.003272750000000','1.538833527952979','1.504012945602270','459.55631979291707','459.556319792917066','test','test','2.65'),('2018-12-11 03:59:59','2018-12-15 19:59:59','XRPETH','4h','0.003397000000000','0.003395010000000','1.531095620763932','1.530198688092363','450.71993546185826','450.719935461858256','test','test','3.65'),('2018-12-17 23:59:59','2018-12-19 03:59:59','XRPETH','4h','0.003479410000000','0.003632380000000','1.530896302392472','1.598201163669808','439.9873261249673','439.987326124967296','test','test','2.42'),('2018-12-19 11:59:59','2018-12-20 15:59:59','XRPETH','4h','0.003598820000000','0.003413370000000','1.545852938231881','1.466193931280963','429.54438905860275','429.544389058602746','test','test','0.0'),('2019-01-11 07:59:59','2019-01-14 19:59:59','XRPETH','4h','0.002592680000000','0.002596400000000','1.528150936687232','1.530343541052011','589.409775478359','589.409775478359052','test','test','0.0'),('2019-01-16 23:59:59','2019-01-19 11:59:59','XRPETH','4h','0.002680390000000','0.002648540000000','1.528638182101627','1.510473987301640','570.3043893245488','570.304389324548765','test','test','3.13'),('2019-01-20 19:59:59','2019-01-23 03:59:59','XRPETH','4h','0.002686180000000','0.002687950000000','1.524601694368297','1.525606297559086','567.5724241742166','567.572424174216621','test','test','1.40'),('2019-01-24 03:59:59','2019-01-25 15:59:59','XRPETH','4h','0.002720640000000','0.002712620000000','1.524824939521806','1.520330005971257','560.4655299936065','560.465529993606538','test','test','1.20'),('2019-01-25 19:59:59','2019-01-26 11:59:59','XRPETH','4h','0.002720240000000','0.002703780000000','1.523826065399461','1.514605490363260','560.180743390091','560.180743390091038','test','test','0.48'),('2019-01-27 23:59:59','2019-02-02 15:59:59','XRPETH','4h','0.002735430000000','0.002856100000000','1.521777048724750','1.588908299193457','556.3209618687921','556.320961868792097','test','test','1.15'),('2019-02-27 15:59:59','2019-02-28 03:59:59','XRPETH','4h','0.002289240000000','0.002287290000000','1.536695104384463','1.535386130465805','671.2686762351098','671.268676235109751','test','test','0.0'),('2019-02-28 07:59:59','2019-02-28 11:59:59','XRPETH','4h','0.002288530000000','0.002274310000000','1.536404221291428','1.526857626740881','671.349827745945','671.349827745945049','test','test','0.05'),('2019-02-28 23:59:59','2019-03-05 15:59:59','XRPETH','4h','0.002317970000000','0.002341950000000','1.534282755835751','1.550155308321306','661.9079435177119','661.907943517711942','test','test','1.88'),('2019-03-11 19:59:59','2019-03-12 11:59:59','XRPETH','4h','0.002355840000000','0.002319890000000','1.537809989721429','1.514343086565660','652.7650391034321','652.765039103432059','test','test','0.71'),('2019-03-12 15:59:59','2019-03-14 15:59:59','XRPETH','4h','0.002324780000000','0.002354590000000','1.532595122353481','1.552247158502002','659.2430777765986','659.243077776598625','test','test','0.21'),('2019-03-14 23:59:59','2019-03-15 03:59:59','XRPETH','4h','0.002353960000000','0.002335890000000','1.536962241497596','1.525163864420729','652.9262355764738','652.926235576473800','test','test','0.51');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 14:41:46
