-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-22 19:59:59','2018-03-30 15:59:59','MDAETH','4h','0.001624800000000','0.001837500000000','1.297777777777778','1.467667815526014','798.7307839597352','798.730783959735163','test','test','0.0'),('2018-04-02 15:59:59','2018-04-03 19:59:59','MDAETH','4h','0.001955400000000','0.001797100000000','1.335531119499608','1.227412792703665','682.9963790015383','682.996379001538344','test','test','8.09'),('2018-04-06 19:59:59','2018-04-07 07:59:59','MDAETH','4h','0.001911100000000','0.001853000000000','1.311504824656065','1.271633321169844','686.2565143927922','686.256514392792155','test','test','4.60'),('2018-04-07 11:59:59','2018-04-07 23:59:59','MDAETH','4h','0.001868700000000','0.001835600000000','1.302644490548016','1.279570946031968','697.0859370407321','697.085937040732119','test','test','1.77'),('2018-04-13 15:59:59','2018-04-14 03:59:59','MDAETH','4h','0.001846100000000','0.001801300000000','1.297517036211117','1.266029704418550','702.8422275126572','702.842227512657246','test','test','2.42'),('2018-04-14 07:59:59','2018-04-14 19:59:59','MDAETH','4h','0.001825200000000','0.001779800000000','1.290519851368324','1.258419478120394','707.0566794698246','707.056679469824644','test','test','2.48'),('2018-04-14 23:59:59','2018-04-15 03:59:59','MDAETH','4h','0.001790300000000','0.001791900000000','1.283386435091006','1.284533403920892','716.8555186789958','716.855518678995850','test','test','0.0'),('2018-04-15 15:59:59','2018-04-16 11:59:59','MDAETH','4h','0.001856800000000','0.001812700000000','1.283641317053203','1.253154144454083','691.319106556012','691.319106556012002','test','test','2.37'),('2018-04-16 15:59:59','2018-04-16 23:59:59','MDAETH','4h','0.001823000000000','0.001818900000000','1.276866389808954','1.273994666167584','700.4204003340394','700.420400334039414','test','test','0.22'),('2018-04-17 15:59:59','2018-04-18 07:59:59','MDAETH','4h','0.001897900000000','0.001875000000000','1.276228228999761','1.260829300476607','672.4422935875233','672.442293587523295','test','test','1.77'),('2018-04-18 11:59:59','2018-04-21 03:59:59','MDAETH','4h','0.001892800000000','0.001894400000000','1.272806244883504','1.273882158869035','672.44624095705','672.446240957050009','test','test','0.0'),('2018-04-23 19:59:59','2018-04-24 03:59:59','MDAETH','4h','0.001955300000000','0.001858600000000','1.273045336880289','1.210086464034013','651.0741762800025','651.074176280002462','test','test','4.94'),('2018-05-01 11:59:59','2018-05-01 15:59:59','MDAETH','4h','0.001832800000000','0.001899900000000','1.259054476247783','1.305149279475754','686.9568290308724','686.956829030872427','test','test','0.0'),('2018-05-01 23:59:59','2018-05-02 03:59:59','MDAETH','4h','0.001809100000000','0.001800000000000','1.269297765853999','1.262913038824387','701.6183549024371','701.618354902437090','test','test','0.50'),('2018-05-02 11:59:59','2018-05-02 15:59:59','MDAETH','4h','0.001806500000000','0.001799400000000','1.267878937625196','1.262895854061875','701.8427553972854','701.842755397285373','test','test','0.39'),('2018-05-02 19:59:59','2018-05-03 03:59:59','MDAETH','4h','0.001818500000000','0.001773700000000','1.266771585722236','1.235563795213379','696.6024667155546','696.602466715554556','test','test','2.46'),('2018-06-02 03:59:59','2018-06-03 11:59:59','MDAETH','4h','0.001347800000000','0.001282300000000','1.259836521164712','1.198611345221480','934.735510583701','934.735510583700943','test','test','4.85'),('2018-06-07 07:59:59','2018-06-08 03:59:59','MDAETH','4h','0.001287800000000','0.001294900000000','1.246230926510661','1.253101744633216','967.7208623316203','967.720862331620310','test','test','0.84'),('2018-06-30 15:59:59','2018-07-07 11:59:59','MDAETH','4h','0.001109800000000','0.001167900000000','1.247757774982339','1.313080109390767','1124.3086817285453','1124.308681728545253','test','test','2.29'),('2018-07-09 19:59:59','2018-07-09 23:59:59','MDAETH','4h','0.001199700000000','0.001148800000000','1.262273849295324','1.208719011478260','1052.1579138912425','1052.157913891242515','test','test','4.24'),('2018-07-17 19:59:59','2018-07-26 19:59:59','MDAETH','4h','0.001159700000000','0.001385600000000','1.250372774224865','1.493935083181834','1078.1864052986678','1078.186405298667751','test','test','0.0'),('2018-07-28 03:59:59','2018-07-28 07:59:59','MDAETH','4h','0.001405500000000','0.001380200000000','1.304497731770858','1.281015844461144','928.1378383286075','928.137838328607472','test','test','1.80'),('2018-07-29 23:59:59','2018-07-30 15:59:59','MDAETH','4h','0.001400000000000','0.001357900000000','1.299279534590922','1.260208342872152','928.0568104220869','928.056810422086869','test','test','3.00'),('2018-08-17 15:59:59','2018-09-05 15:59:59','MDAETH','4h','0.001426700000000','0.002897200000000','1.290597047542306','2.620815704871080','904.6029631613555','904.602963161355547','test','test','9.52'),('2018-10-07 19:59:59','2018-10-16 07:59:59','MDAETH','4h','0.002694400000000','0.008892300000000','1.586201193615367','5.234923127221619','588.702937060335','588.702937060334989','test','test','1.62'),('2018-10-19 15:59:59','2018-10-20 11:59:59','MDAETH','4h','0.009587800000000','0.008909000000000','2.397028289972312','2.227322747174882','250.0081655825436','250.008165582543597','test','test','7.07'),('2018-10-20 15:59:59','2018-10-21 15:59:59','MDAETH','4h','0.009737700000000','0.009081200000000','2.359315947128438','2.200254678113186','242.28677687014778','242.286776870147776','test','test','6.74'),('2018-11-24 15:59:59','2018-11-24 19:59:59','MDAETH','4h','0.005829700000000','0.005345400000000','2.323968998458382','2.130906201752995','398.6429830794693','398.642983079469275','test','test','8.30'),('2018-11-25 19:59:59','2018-11-29 15:59:59','MDAETH','4h','0.005917300000000','0.008457800000000','2.281066154746074','3.260406152064514','385.4910440143433','385.491044014343288','test','test','0.0'),('2018-11-29 19:59:59','2018-11-30 15:59:59','MDAETH','4h','0.008985700000000','0.008283200000000','2.498697265261283','2.303349676442821','278.07485952805933','278.074859528059335','test','test','7.81'),('2018-12-11 23:59:59','2018-12-20 15:59:59','MDAETH','4h','0.007635700000000','0.009343200000000','2.455286689968291','3.004339432103374','321.55358250956573','321.553582509565729','test','test','2.93'),('2019-01-17 07:59:59','2019-01-20 11:59:59','MDAETH','4h','0.006290300000000','0.005878800000000','2.577298410442754','2.408696229958962','409.72583349645544','409.725833496455436','test','test','6.54'),('2019-01-21 23:59:59','2019-01-25 15:59:59','MDAETH','4h','0.005962800000000','0.006005500000000','2.539831259224134','2.558019156649651','425.94607553903097','425.946075539030971','test','test','0.66'),('2019-01-25 19:59:59','2019-01-29 23:59:59','MDAETH','4h','0.006237400000000','0.006508700000000','2.543873014207582','2.654520519378730','407.8418915265306','407.841891526530617','test','test','1.97'),('2019-01-30 11:59:59','2019-01-30 15:59:59','MDAETH','4h','0.006631000000000','0.006384800000000','2.568461348690059','2.473097876506755','387.3414792173215','387.341479217321478','test','test','3.71'),('2019-01-31 23:59:59','2019-02-05 03:59:59','MDAETH','4h','0.006664600000000','0.006794800000000','2.547269465982658','2.597033065369109','382.2089046578426','382.208904657842595','test','test','0.04'),('2019-02-25 07:59:59','2019-03-01 03:59:59','MDAETH','4h','0.006912100000000','0.006708800000000','2.558328043624092','2.483082012567137','370.1231237430147','370.123123743014673','test','test','7.35'),('2019-03-09 11:59:59','2019-03-09 15:59:59','MDAETH','4h','0.006285800000000','0.006317100000000','2.541606703389212','2.554262576916223','404.3410072527303','404.341007252730321','test','test','0.0'),('2019-03-09 19:59:59','2019-03-12 19:59:59','MDAETH','4h','0.006945000000000','0.007400400000000','2.544419119728548','2.711262671510316','366.36704387740076','366.367043877400761','test','test','2.53'),('2019-03-12 23:59:59','2019-03-14 23:59:59','MDAETH','4h','0.008161400000000','0.008398100000000','2.581495464568941','2.656364969367563','316.30547020963826','316.305470209638258','test','test','5.68');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-01  2:52:16
