-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-31 19:59:59','2018-06-01 23:59:59','WABIETH','4h','0.001353100000000','0.001289690000000','1.297777777777778','1.236960329777712','959.1144614424489','959.114461442448942','test','test','4.68'),('2018-06-02 03:59:59','2018-06-02 07:59:59','WABIETH','4h','0.001292230000000','0.001340260000000','1.284262789333319','1.331996661609678','993.834525845491','993.834525845491044','test','test','0.0'),('2018-06-02 11:59:59','2018-06-03 23:59:59','WABIETH','4h','0.001382080000000','0.001313140000000','1.294870316505843','1.230280452228874','936.899684899458','936.899684899457952','test','test','4.98'),('2018-06-30 23:59:59','2018-07-03 23:59:59','WABIETH','4h','0.000838170000000','0.000854270000000','1.280517013333183','1.305113842036983','1527.7533356397666','1527.753335639766647','test','test','3.24'),('2018-07-04 15:59:59','2018-07-05 15:59:59','WABIETH','4h','0.000896890000000','0.000850910000000','1.285982975267361','1.220055718632999','1433.8246331962234','1433.824633196223431','test','test','5.12'),('2018-07-06 23:59:59','2018-07-07 15:59:59','WABIETH','4h','0.000911570000000','0.000868100000000','1.271332473793058','1.210706495935314','1394.6624765986792','1394.662476598679177','test','test','4.76'),('2018-07-07 23:59:59','2018-07-08 23:59:59','WABIETH','4h','0.000875150000000','0.000847710000000','1.257860034269115','1.218420304690935','1437.3079292339771','1437.307929233977120','test','test','3.13'),('2018-07-17 11:59:59','2018-07-20 07:59:59','WABIETH','4h','0.000874460000000','0.000788550000000','1.249095649918408','1.126380137162547','1428.4194244658513','1428.419424465851307','test','test','9.82'),('2018-08-20 15:59:59','2018-08-22 19:59:59','WABIETH','4h','0.000564280000000','0.000543430000000','1.221825535972662','1.176679398549698','2165.282370405936','2165.282370405936035','test','test','6.96'),('2018-08-22 23:59:59','2018-08-30 11:59:59','WABIETH','4h','0.000556990000000','0.000719200000000','1.211793060989781','1.564698772803552','2175.6100845433143','2175.610084543314315','test','test','1.95'),('2018-08-31 19:59:59','2018-09-05 23:59:59','WABIETH','4h','0.000750270000000','0.000789380000000','1.290216552503952','1.357472832734308','1719.6696555959215','1719.669655595921540','test','test','0.87'),('2018-09-07 11:59:59','2018-09-11 07:59:59','WABIETH','4h','0.000922000000000','0.000862020000000','1.305162392555142','1.220256058167444','1415.5774322723885','1415.577432272388478','test','test','8.76'),('2018-09-11 19:59:59','2018-09-13 19:59:59','WABIETH','4h','0.000905520000000','0.000851450000000','1.286294318246765','1.209487694662965','1420.5034877714074','1420.503487771407436','test','test','5.97'),('2018-09-16 03:59:59','2018-09-18 15:59:59','WABIETH','4h','0.000936000000000','0.000921550000000','1.269226179672587','1.249631822518454','1356.0108757185758','1356.010875718575790','test','test','1.54'),('2018-09-25 11:59:59','2018-09-28 07:59:59','WABIETH','4h','0.000997240000000','0.000977600000000','1.264871878082780','1.239961040485466','1268.3725864213025','1268.372586421302458','test','test','1.96'),('2018-10-05 19:59:59','2018-10-06 03:59:59','WABIETH','4h','0.000961080000000','0.000943610000000','1.259336136394488','1.236444595312776','1310.3343492679983','1310.334349267998277','test','test','1.81'),('2018-10-06 15:59:59','2018-10-06 19:59:59','WABIETH','4h','0.000939100000000','0.000940120000000','1.254249127265218','1.255611425326991','1335.586335071045','1335.586335071044914','test','test','0.0'),('2018-10-06 23:59:59','2018-10-07 03:59:59','WABIETH','4h','0.000947750000000','0.000948380000000','1.254551860167834','1.255385801261905','1323.7160223348292','1323.716022334829177','test','test','0.0'),('2018-10-07 07:59:59','2018-10-07 11:59:59','WABIETH','4h','0.000949660000000','0.000922560000000','1.254737180410961','1.218931336646733','1321.2488473884985','1321.248847388498461','test','test','2.85'),('2018-10-11 11:59:59','2018-10-11 15:59:59','WABIETH','4h','0.000934630000000','0.000934760000000','1.246780326241133','1.246953744002612','1333.9827806095814','1333.982780609581368','test','test','0.0'),('2018-10-11 19:59:59','2018-10-12 11:59:59','WABIETH','4h','0.000946470000000','0.000923300000000','1.246818863521462','1.216296191838480','1317.3358516608678','1317.335851660867775','test','test','2.44'),('2018-10-13 15:59:59','2018-10-16 07:59:59','WABIETH','4h','0.001232190000000','0.001235690000000','1.240036047591910','1.243558334062805','1006.3675631127587','1006.367563112758717','test','test','1.07'),('2018-10-20 11:59:59','2018-10-21 19:59:59','WABIETH','4h','0.001336700000000','0.001245470000000','1.240818777918776','1.156132687465024','928.2702011810995','928.270201181099537','test','test','6.82'),('2018-10-24 11:59:59','2018-10-26 03:59:59','WABIETH','4h','0.001282910000000','0.001262490000000','1.221999646706831','1.202549153074578','952.5217253796686','952.521725379668624','test','test','1.59'),('2018-10-28 23:59:59','2018-10-29 15:59:59','WABIETH','4h','0.001289570000000','0.001278420000000','1.217677314788552','1.207148920005878','944.2506531545803','944.250653154580277','test','test','0.86'),('2018-10-29 19:59:59','2018-11-04 07:59:59','WABIETH','4h','0.001314780000000','0.001451890000000','1.215337671503514','1.342077466860796','924.365803787336','924.365803787335949','test','test','0.15'),('2018-11-04 11:59:59','2018-11-04 19:59:59','WABIETH','4h','0.001452680000000','0.001407000000000','1.243502070471799','1.204399739208787','856.0055005037575','856.005500503757503','test','test','3.14'),('2018-11-12 07:59:59','2018-11-14 15:59:59','WABIETH','4h','0.001482920000000','0.001407720000000','1.234812663524463','1.172194375082039','832.6900058832995','832.690005883299477','test','test','5.17'),('2018-11-26 03:59:59','2018-11-30 11:59:59','WABIETH','4h','0.001305760000000','0.001328700000000','1.220897488315035','1.242346597172671','935.0091045177023','935.009104517702326','test','test','2.89'),('2018-11-30 15:59:59','2018-12-02 15:59:59','WABIETH','4h','0.001350560000000','0.001384010000000','1.225663956950065','1.256020593722944','907.5227734791977','907.522773479197667','test','test','0.0'),('2018-12-04 11:59:59','2018-12-06 15:59:59','WABIETH','4h','0.001412810000000','0.001380050000000','1.232409876232927','1.203832963877132','872.3111219717634','872.311121971763441','test','test','2.31'),('2018-12-17 11:59:59','2018-12-18 03:59:59','WABIETH','4h','0.001425940000000','0.001294980000000','1.226059451264973','1.113456715008426','859.8254142986189','859.825414298618853','test','test','9.18'),('2018-12-18 11:59:59','2018-12-18 15:59:59','WABIETH','4h','0.001296180000000','0.001289040000000','1.201036620985740','1.194420717736316','926.5970937568394','926.597093756839399','test','test','0.55'),('2018-12-18 19:59:59','2018-12-18 23:59:59','WABIETH','4h','0.001309930000000','0.001268750000000','1.199566420263646','1.161855897421619','915.7484905786155','915.748490578615474','test','test','3.14'),('2019-01-11 11:59:59','2019-01-14 15:59:59','WABIETH','4h','0.000895560000000','0.000882180000000','1.191186304076529','1.173389536971540','1330.1021752607628','1330.102175260762806','test','test','1.49'),('2019-01-14 19:59:59','2019-01-20 23:59:59','WABIETH','4h','0.000891810000000','0.001111700000000','1.187231466942087','1.479962348257496','1331.260545342715','1331.260545342714977','test','test','0.0'),('2019-01-23 03:59:59','2019-01-24 23:59:59','WABIETH','4h','0.001223780000000','0.001139700000000','1.252282773901066','1.166244486276165','1023.2907662333641','1023.290766233364138','test','test','7.15'),('2019-02-07 15:59:59','2019-02-08 11:59:59','WABIETH','4h','0.001113880000000','0.001079350000000','1.233163154428866','1.194935406626204','1107.0879757504094','1107.087975750409441','test','test','3.09'),('2019-02-08 15:59:59','2019-02-08 19:59:59','WABIETH','4h','0.001156610000000','0.001124600000000','1.224668099361608','1.190774543313705','1058.8427381412994','1058.842738141299378','test','test','2.76'),('2019-02-08 23:59:59','2019-02-09 19:59:59','WABIETH','4h','0.001128740000000','0.001097380000000','1.217136198017630','1.183320269486850','1078.3140475376345','1078.314047537634451','test','test','2.77'),('2019-02-09 23:59:59','2019-02-10 03:59:59','WABIETH','4h','0.001108850000000','0.001116150000000','1.209621547233012','1.217584966356249','1090.8793319502295','1090.879331950229471','test','test','0.0'),('2019-02-10 11:59:59','2019-02-11 03:59:59','WABIETH','4h','0.001125100000000','0.001127840000000','1.211391195927064','1.214341344248849','1076.6964678046968','1076.696467804696795','test','test','0.0'),('2019-02-11 07:59:59','2019-02-12 11:59:59','WABIETH','4h','0.001144490000000','0.001112500000000','1.212046784443017','1.178168483510434','1059.0278503464574','1059.027850346457399','test','test','2.79'),('2019-02-26 15:59:59','2019-03-06 15:59:59','WABIETH','4h','0.001131270000000','0.001346220000000','1.204518273124665','1.433386008332128','1064.7487099672626','1064.748709967262585','test','test','5.10'),('2019-03-06 19:59:59','2019-03-11 07:59:59','WABIETH','4h','0.001369270000000','0.001520770000000','1.255377769837435','1.394276403511124','916.822664512795','916.822664512794972','test','test','0.0'),('2019-03-12 23:59:59','2019-03-14 07:59:59','WABIETH','4h','0.001692520000000','0.001568530000000','1.286244132876032','1.192016939084940','759.9580110580862','759.958011058086186','test','test','7.32'),('2019-03-15 03:59:59','2019-03-16 07:59:59','WABIETH','4h','0.001649040000000','0.001546500000000','1.265304756478012','1.186626040540706','767.2977953706469','767.297795370646895','test','test','6.21'),('2019-03-19 11:59:59','2019-03-21 15:59:59','WABIETH','4h','0.001636680000000','0.001668870000000','1.247820597380833','1.272362563452202','762.4096325371072','762.409632537107200','test','test','3.38'),('2019-03-21 19:59:59','2019-03-23 23:59:59','WABIETH','4h','0.001672880000000','0.001677590000000','1.253274367618915','1.256802966365678','749.171708442276','749.171708442275985','test','test','0.0'),('2019-03-27 15:59:59','2019-04-01 07:59:59','WABIETH','4h','0.001723340000000','0.002343230000000','1.254058500673751','1.705146692198727','727.69070564935','727.690705649349979','test','test','0.77'),('2019-04-13 15:59:59','2019-04-17 03:59:59','WABIETH','4h','0.002550000000000','0.002422480000000','1.354300321012634','1.286574682998700','531.0981651029938','531.098165102993789','test','test','5.00'),('2019-04-26 03:59:59','2019-04-26 15:59:59','WABIETH','4h','0.002269550000000','0.002108710000000','1.339250179231760','1.244339294330508','590.0950317163139','590.095031716313883','test','test','7.08'),('2019-04-28 15:59:59','2019-04-29 15:59:59','WABIETH','4h','0.002321640000000','0.002188890000000','1.318158871475926','1.242787328003024','567.7705723005834','567.770572300583353','test','test','5.71'),('2019-04-29 19:59:59','2019-04-29 23:59:59','WABIETH','4h','0.002208760000000','0.002191000000000','1.301409639593059','1.290945381276550','589.2037340376769','589.203734037676895','test','test','0.80');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 23:38:39
