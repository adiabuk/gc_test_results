-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-07 19:59:59','2018-04-12 19:59:59','LINKBTC','4h','0.000043290000000','0.000048320000000','0.033333333333333','0.037206437206437','770.00077000077','770.000770000769990','test','test','0.0'),('2018-04-13 15:59:59','2018-04-13 23:59:59','LINKBTC','4h','0.000050510000000','0.000048250000000','0.034194023082912','0.032664058874490','676.9753134609383','676.975313460938310','test','test','4.47'),('2018-04-14 07:59:59','2018-04-15 03:59:59','LINKBTC','4h','0.000050960000000','0.000049160000000','0.033854031036596','0.032658245010971','664.3255697919152','664.325569791915200','test','test','3.53'),('2018-04-15 07:59:59','2018-04-21 07:59:59','LINKBTC','4h','0.000050140000000','0.000054200000000','0.033588300808679','0.036308055521149','669.8903232684349','669.890323268434940','test','test','0.43'),('2018-04-22 07:59:59','2018-04-24 07:59:59','LINKBTC','4h','0.000056660000000','0.000055300000000','0.034192690744784','0.033371969611482','603.471421545778','603.471421545777957','test','test','2.64'),('2018-04-30 07:59:59','2018-05-03 23:59:59','LINKBTC','4h','0.000055590000000','0.000058350000000','0.034010308270717','0.035698893462787','611.8062290109133','611.806229010913285','test','test','0.0'),('2018-05-05 07:59:59','2018-05-05 11:59:59','LINKBTC','4h','0.000060580000000','0.000059080000000','0.034385549424510','0.033534140970618','567.605635927864','567.605635927864000','test','test','2.47'),('2018-05-07 23:59:59','2018-05-09 03:59:59','LINKBTC','4h','0.000061310000000','0.000057760000000','0.034196347545867','0.032216294800999','557.7613365824064','557.761336582406443','test','test','5.79'),('2018-05-09 07:59:59','2018-05-09 11:59:59','LINKBTC','4h','0.000058550000000','0.000059180000000','0.033756335824786','0.034119555151338','576.5386135744758','576.538613574475789','test','test','0.0'),('2018-05-09 15:59:59','2018-05-09 23:59:59','LINKBTC','4h','0.000060160000000','0.000057970000000','0.033837051230686','0.032605283574516','562.4509845526263','562.450984552626323','test','test','3.64'),('2018-05-10 11:59:59','2018-05-10 23:59:59','LINKBTC','4h','0.000060820000000','0.000058700000000','0.033563325084870','0.032393409774447','551.8468445391392','551.846844539139170','test','test','3.48'),('2018-05-11 03:59:59','2018-05-11 07:59:59','LINKBTC','4h','0.000059510000000','0.000055730000000','0.033303343904776','0.031187957583821','559.6260108347578','559.626010834757835','test','test','6.35'),('2018-05-15 11:59:59','2018-05-16 15:59:59','LINKBTC','4h','0.000060690000000','0.000058540000000','0.032833258055675','0.031670109187333','540.9994736476409','540.999473647640912','test','test','3.54'),('2018-06-30 23:59:59','2018-07-04 23:59:59','LINKBTC','4h','0.000035590000000','0.000035210000000','0.032574780529377','0.032226974499561','915.2790258324559','915.279025832455886','test','test','2.95'),('2018-07-07 11:59:59','2018-07-09 15:59:59','LINKBTC','4h','0.000037450000000','0.000036010000000','0.032497490300529','0.031247920580028','867.7567503479066','867.756750347906632','test','test','5.36'),('2018-07-27 03:59:59','2018-07-31 11:59:59','LINKBTC','4h','0.000034810000000','0.000034310000000','0.032219808140418','0.031757012849691','925.5905814541157','925.590581454115750','test','test','9.62'),('2018-08-01 15:59:59','2018-08-04 03:59:59','LINKBTC','4h','0.000038890000000','0.000037560000000','0.032116964742478','0.031018595930251','825.8412122005257','825.841212200525661','test','test','3.41'),('2018-08-09 07:59:59','2018-08-11 15:59:59','LINKBTC','4h','0.000041910000000','0.000042130000000','0.031872882784206','0.032040194504858','760.507821145449','760.507821145449043','test','test','2.76'),('2018-08-11 19:59:59','2018-08-13 23:59:59','LINKBTC','4h','0.000042210000000','0.000041260000000','0.031910063166573','0.031191878849865','755.9834912715681','755.983491271568141','test','test','2.25'),('2018-08-17 07:59:59','2018-08-18 19:59:59','LINKBTC','4h','0.000042830000000','0.000041450000000','0.031750466651749','0.030727453717371','741.3137205638311','741.313720563831112','test','test','3.22'),('2018-08-18 23:59:59','2018-08-23 19:59:59','LINKBTC','4h','0.000043020000000','0.000047470000000','0.031523130444109','0.034783891264106','732.7552404488456','732.755240448845598','test','test','0.0'),('2018-08-23 23:59:59','2018-08-25 19:59:59','LINKBTC','4h','0.000049370000000','0.000048600000000','0.032247743959664','0.031744791501715','653.1850103233586','653.185010323358597','test','test','1.72'),('2018-08-26 23:59:59','2018-08-27 23:59:59','LINKBTC','4h','0.000049320000000','0.000048520000000','0.032135976746787','0.031614711917155','651.5810370394701','651.581037039470061','test','test','1.78'),('2018-09-14 19:59:59','2018-09-15 23:59:59','LINKBTC','4h','0.000041560000000','0.000041310000000','0.032020140117980','0.031827526185605','770.4557294990267','770.455729499026688','test','test','0.60'),('2018-09-16 11:59:59','2018-09-22 03:59:59','LINKBTC','4h','0.000042300000000','0.000050710000000','0.031977337021896','0.038335006155564','755.965414229225','755.965414229224962','test','test','0.14'),('2018-09-25 03:59:59','2018-09-25 15:59:59','LINKBTC','4h','0.000052510000000','0.000050950000000','0.033390152384934','0.032398176804654','635.8817822306904','635.881782230690419','test','test','4.47'),('2018-09-26 23:59:59','2018-09-28 11:59:59','LINKBTC','4h','0.000053590000000','0.000050040000000','0.033169713367094','0.030972428753301','618.9534123361364','618.953412336136353','test','test','6.62'),('2018-10-05 23:59:59','2018-10-09 03:59:59','LINKBTC','4h','0.000053770000000','0.000050940000000','0.032681427897362','0.030961352744869','607.8004072412456','607.800407241245580','test','test','5.52'),('2018-10-10 15:59:59','2018-10-11 03:59:59','LINKBTC','4h','0.000053620000000','0.000051180000000','0.032299188974586','0.030829401188350','602.3720435394546','602.372043539454580','test','test','4.55'),('2018-10-14 19:59:59','2018-10-15 07:59:59','LINKBTC','4h','0.000053180000000','0.000049990000000','0.031972569466533','0.030054696269876','601.2141682311602','601.214168231160215','test','test','5.99'),('2018-10-15 11:59:59','2018-10-15 15:59:59','LINKBTC','4h','0.000050070000000','0.000051370000000','0.031546375422832','0.032365434501116','630.0454448338636','630.045444833863598','test','test','0.0'),('2018-10-15 23:59:59','2018-10-20 11:59:59','LINKBTC','4h','0.000051410000000','0.000055980000000','0.031728388551339','0.034548826903403','617.1637531869112','617.163753186911208','test','test','0.0'),('2018-10-20 15:59:59','2018-10-22 07:59:59','LINKBTC','4h','0.000056750000000','0.000055730000000','0.032355152629576','0.031773615084516','570.1348480982476','570.134848098247630','test','test','1.79'),('2018-10-22 15:59:59','2018-10-25 11:59:59','LINKBTC','4h','0.000059000000000','0.000062560000000','0.032225922064007','0.034170401429225','546.2020688814689','546.202068881468904','test','test','0.0'),('2018-10-25 23:59:59','2018-10-29 11:59:59','LINKBTC','4h','0.000067830000000','0.000065010000000','0.032658028589611','0.031300286578367','481.4687983135878','481.468798313587797','test','test','4.34'),('2018-10-30 03:59:59','2018-11-04 19:59:59','LINKBTC','4h','0.000068750000000','0.000077740000000','0.032356308142668','0.036587336654706','470.63720934789166','470.637209347891655','test','test','1.78'),('2018-11-08 19:59:59','2018-11-09 03:59:59','LINKBTC','4h','0.000079260000000','0.000075850000000','0.033296536700898','0.031864021054291','420.0925649873608','420.092564987360788','test','test','4.30'),('2018-11-09 07:59:59','2018-11-09 11:59:59','LINKBTC','4h','0.000076290000000','0.000076500000000','0.032978199890541','0.033068977475769','432.27421536952556','432.274215369525564','test','test','0.0'),('2018-11-09 15:59:59','2018-11-17 03:59:59','LINKBTC','4h','0.000077910000000','0.000088350000000','0.032998372687258','0.037420180040037','423.54476559181666','423.544765591816656','test','test','0.93'),('2018-11-18 23:59:59','2018-11-19 07:59:59','LINKBTC','4h','0.000093490000000','0.000087630000000','0.033980996543432','0.031851050669600','363.47199212141993','363.471992121419930','test','test','6.26'),('2018-11-29 19:59:59','2018-11-30 23:59:59','LINKBTC','4h','0.000086690000000','0.000080230000000','0.033507675238136','0.031010736928777','386.5229581051511','386.522958105151076','test','test','7.45'),('2018-12-01 07:59:59','2018-12-01 15:59:59','LINKBTC','4h','0.000080910000000','0.000081080000000','0.032952800058278','0.033022037186073','407.2772223245334','407.277222324533398','test','test','0.61'),('2018-12-18 19:59:59','2018-12-22 03:59:59','LINKBTC','4h','0.000069600000000','0.000074100000000','0.032968186086677','0.035099749842281','473.6808345786909','473.680834578690906','test','test','0.0'),('2018-12-23 03:59:59','2018-12-23 19:59:59','LINKBTC','4h','0.000078400000000','0.000075830000000','0.033441866921256','0.032345622048965','426.5544250160147','426.554425016014704','test','test','3.27'),('2018-12-25 15:59:59','2018-12-27 11:59:59','LINKBTC','4h','0.000078060000000','0.000078050000000','0.033198256949635','0.033194004034320','425.29153150954824','425.291531509548236','test','test','0.98'),('2018-12-30 03:59:59','2018-12-31 11:59:59','LINKBTC','4h','0.000079310000000','0.000077650000000','0.033197311857343','0.032502474665524','418.5766215778982','418.576621577898209','test','test','2.35'),('2019-01-01 03:59:59','2019-01-02 03:59:59','LINKBTC','4h','0.000079090000000','0.000077820000000','0.033042903592494','0.032512312018813','417.7886406940756','417.788640694075582','test','test','1.60'),('2019-01-02 07:59:59','2019-01-06 11:59:59','LINKBTC','4h','0.000078250000000','0.000097710000000','0.032924994353899','0.041113114355520','420.76670100828954','420.766701008289544','test','test','0.0'),('2019-01-08 23:59:59','2019-01-10 07:59:59','LINKBTC','4h','0.000106210000000','0.000097250000000','0.034744576576481','0.031813483401401','327.1309347187751','327.130934718775109','test','test','8.43'),('2019-01-11 07:59:59','2019-01-17 19:59:59','LINKBTC','4h','0.000102490000000','0.000131350000000','0.034093222537574','0.043693480147432','332.6492588308561','332.649258830856127','test','test','0.48'),('2019-01-20 15:59:59','2019-01-24 03:59:59','LINKBTC','4h','0.000138990000000','0.000136850000000','0.036226613117543','0.035668839521806','260.6418671670112','260.641867167011185','test','test','2.64'),('2019-02-09 15:59:59','2019-02-10 23:59:59','LINKBTC','4h','0.000131900000000','0.000122400000000','0.036102663429601','0.033502395783041','273.71238384838','273.712383848380000','test','test','7.20'),('2019-02-16 23:59:59','2019-02-17 03:59:59','LINKBTC','4h','0.000121120000000','0.000119510000000','0.035524826174810','0.035052608785928','293.3027260139549','293.302726013954896','test','test','1.32'),('2019-02-17 07:59:59','2019-02-17 11:59:59','LINKBTC','4h','0.000120140000000','0.000123660000000','0.035419888977281','0.036457661652493','294.82178273082144','294.821782730821440','test','test','0.0'),('2019-02-17 19:59:59','2019-02-18 23:59:59','LINKBTC','4h','0.000124140000000','0.000121060000000','0.035650505127328','0.034765991225345','287.17983830617044','287.179838306170438','test','test','2.48'),('2019-02-19 03:59:59','2019-02-19 07:59:59','LINKBTC','4h','0.000121830000000','0.000120250000000','0.035453946482443','0.034994148112236','291.01162671298437','291.011626712984366','test','test','1.29'),('2019-03-08 03:59:59','2019-03-11 19:59:59','LINKBTC','4h','0.000125860000000','0.000119490000000','0.035351769066841','0.033562552723636','280.8816865313947','280.881686531394678','test','test','6.38'),('2019-03-12 11:59:59','2019-03-13 11:59:59','LINKBTC','4h','0.000127550000000','0.000122070000000','0.034954165435018','0.033452410620562','274.0428493533359','274.042849353335896','test','test','4.29'),('2019-03-14 03:59:59','2019-03-15 19:59:59','LINKBTC','4h','0.000126720000000','0.000124770000000','0.034620442142917','0.034087693861835','273.20424670862263','273.204246708622634','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-01  0:28:56
