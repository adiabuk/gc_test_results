-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 07:59:59','2019-01-13 11:59:59','BATBTC','4h','0.000035250000000','0.000035210000000','0.033333333333333','0.033295508274231','945.6264775413711','945.626477541371059','test','test','0.11'),('2019-01-19 03:59:59','2019-01-19 07:59:59','BATBTC','4h','0.000034770000000','0.000034510000000','0.033324927764644','0.033075733596717','958.439107409951','958.439107409951021','test','test','0.74'),('2019-01-19 15:59:59','2019-01-19 19:59:59','BATBTC','4h','0.000034650000000','0.000034660000000','0.033269551282882','0.033279152884984','960.1602101841974','960.160210184197354','test','test','0.0'),('2019-01-19 23:59:59','2019-01-20 15:59:59','BATBTC','4h','0.000034900000000','0.000034440000000','0.033271684972238','0.032833147004123','953.3434089466602','953.343408946660247','test','test','1.31'),('2019-01-25 15:59:59','2019-01-27 15:59:59','BATBTC','4h','0.000035070000000','0.000034690000000','0.033174232090435','0.032814773630373','945.9433159519563','945.943315951956265','test','test','1.08'),('2019-02-08 11:59:59','2019-02-08 23:59:59','BATBTC','4h','0.000033000000000','0.000032360000000','0.033094352432644','0.032452522567284','1002.8591646255624','1002.859164625562357','test','test','1.93'),('2019-02-10 07:59:59','2019-02-11 23:59:59','BATBTC','4h','0.000033290000000','0.000033060000000','0.032951723573675','0.032724060719306','989.8384972566738','989.838497256673804','test','test','0.69'),('2019-02-14 03:59:59','2019-02-19 03:59:59','BATBTC','4h','0.000034840000000','0.000035430000000','0.032901131828259','0.033458297952790','944.3493636124954','944.349363612495381','test','test','2.00'),('2019-02-26 07:59:59','2019-03-04 03:59:59','BATBTC','4h','0.000047510000000','0.000043330000000','0.033024946522600','0.030119362930420','695.1156919090624','695.115691909062434','test','test','14.9'),('2019-03-05 03:59:59','2019-03-06 11:59:59','BATBTC','4h','0.000045890000000','0.000044970000000','0.032379261279893','0.031730123768943','705.5842510327499','705.584251032749876','test','test','2.26'),('2019-03-07 15:59:59','2019-03-11 15:59:59','BATBTC','4h','0.000046130000000','0.000049540000000','0.032235008499682','0.034617869522529','698.7862237086881','698.786223708688112','test','test','0.0'),('2019-03-15 11:59:59','2019-03-16 07:59:59','BATBTC','4h','0.000049960000000','0.000049440000000','0.032764533171426','0.032423509207272','655.815315681056','655.815315681055949','test','test','1.08'),('2019-03-16 11:59:59','2019-03-16 15:59:59','BATBTC','4h','0.000049530000000','0.000049460000000','0.032688750068280','0.032642551552133','659.9788021053952','659.978802105395175','test','test','0.14'),('2019-03-22 19:59:59','2019-04-02 07:59:59','BATBTC','4h','0.000049650000000','0.000066050000000','0.032678483731359','0.043472585104859','658.1769130183014','658.176913018301434','test','test','0.66'),('2019-04-14 03:59:59','2019-04-15 19:59:59','BATBTC','4h','0.000063380000000','0.000058220000000','0.035077172925470','0.032221410661421','553.4422992342975','553.442299234297479','test','test','8.14'),('2019-04-16 11:59:59','2019-04-22 23:59:59','BATBTC','4h','0.000061730000000','0.000074340000000','0.034442559089014','0.041478371013726','557.9549504133233','557.954950413323331','test','test','0.51'),('2019-04-24 19:59:59','2019-04-26 03:59:59','BATBTC','4h','0.000080400000000','0.000072750000000','0.036006072850062','0.032580121888582','447.83672699081535','447.836726990815350','test','test','9.51'),('2019-04-28 19:59:59','2019-04-29 11:59:59','BATBTC','4h','0.000078000000000','0.000073500000000','0.035244750414177','0.033211399428744','451.85577454073217','451.855774540732170','test','test','5.76'),('2019-06-08 03:59:59','2019-06-08 15:59:59','BATBTC','4h','0.000043110000000','0.000042400000000','0.034792894639636','0.034219873178394','807.0724806225111','807.072480622511080','test','test','1.64'),('2019-06-08 19:59:59','2019-06-08 23:59:59','BATBTC','4h','0.000042470000000','0.000042510000000','0.034665556537138','0.034698205989963','816.2363206295792','816.236320629579154','test','test','0.0'),('2019-06-09 07:59:59','2019-06-09 15:59:59','BATBTC','4h','0.000043050000000','0.000042260000000','0.034672811971099','0.034036539695671','805.4079435795433','805.407943579543257','test','test','1.83'),('2019-07-02 23:59:59','2019-07-03 03:59:59','BATBTC','4h','0.000029710000000','0.000027490000000','0.034531418132115','0.031951150604236','1162.2826702159318','1162.282670215931830','test','test','7.47'),('2019-07-23 03:59:59','2019-07-23 07:59:59','BATBTC','4h','0.000024650000000','0.000023540000000','0.033958025348142','0.032428881001836','1377.6075191944105','1377.607519194410543','test','test','4.50'),('2019-07-23 11:59:59','2019-07-23 15:59:59','BATBTC','4h','0.000023670000000','0.000023250000000','0.033618215493408','0.033021694559431','1420.2879380400325','1420.287938040032486','test','test','1.77'),('2019-07-26 11:59:59','2019-07-30 03:59:59','BATBTC','4h','0.000024400000000','0.000025950000000','0.033485655285857','0.035612817814262','1372.362921551521','1372.362921551520913','test','test','0.20'),('2019-08-22 15:59:59','2019-08-26 03:59:59','BATBTC','4h','0.000019400000000','0.000018430000000','0.033958358069947','0.032260440166450','1750.4308283477892','1750.430828347789202','test','test','4.99'),('2019-09-01 19:59:59','2019-09-02 03:59:59','BATBTC','4h','0.000018960000000','0.000018260000000','0.033581042980281','0.032341236541136','1771.1520559219998','1771.152055921999818','test','test','3.69'),('2019-09-16 19:59:59','2019-09-22 19:59:59','BATBTC','4h','0.000017410000000','0.000019300000000','0.033305530438249','0.036921122197485','1913.0115128230261','1913.011512823026123','test','test','0.11'),('2019-09-23 15:59:59','2019-09-23 23:59:59','BATBTC','4h','0.000020320000000','0.000019210000000','0.034108995273635','0.032245757834967','1678.5922870883203','1678.592287088320290','test','test','5.46'),('2019-09-27 19:59:59','2019-09-30 07:59:59','BATBTC','4h','0.000020400000000','0.000019730000000','0.033694942509486','0.032588294887851','1651.7128681120696','1651.712868112069600','test','test','3.82'),('2019-09-30 11:59:59','2019-10-01 19:59:59','BATBTC','4h','0.000020050000000','0.000019730000000','0.033449020815790','0.032915171107009','1668.2803399396291','1668.280339939629130','test','test','1.59'),('2019-10-02 11:59:59','2019-10-09 15:59:59','BATBTC','4h','0.000020350000000','0.000023430000000','0.033330387547172','0.038374986743501','1637.8568819248924','1637.856881924892377','test','test','0.88'),('2019-10-13 11:59:59','2019-10-19 11:59:59','BATBTC','4h','0.000024270000000','0.000027160000000','0.034451409590800','0.038553781808246','1419.5059575937464','1419.505957593746416','test','test','2.96'),('2019-10-22 11:59:59','2019-10-25 19:59:59','BATBTC','4h','0.000028520000000','0.000028720000000','0.035363047861344','0.035611035574257','1239.938564563246','1239.938564563246018','test','test','0.0'),('2019-11-05 23:59:59','2019-11-08 15:59:59','BATBTC','4h','0.000026810000000','0.000026530000000','0.035418156241991','0.035048253826931','1321.0800537855694','1321.080053785569362','test','test','1.04'),('2019-11-09 11:59:59','2019-11-10 23:59:59','BATBTC','4h','0.000027520000000','0.000027040000000','0.035335955705311','0.034719630896497','1284.0100183615955','1284.010018361595485','test','test','1.74'),('2019-11-13 11:59:59','2019-11-19 11:59:59','BATBTC','4h','0.000028020000000','0.000030060000000','0.035198994636686','0.037761662340428','1256.2096586968514','1256.209658696851420','test','test','0.0'),('2019-11-23 15:59:59','2019-11-23 19:59:59','BATBTC','4h','0.000030640000000','0.000029930000000','0.035768476348628','0.034939637634283','1167.3784709082393','1167.378470908239251','test','test','2.31'),('2019-11-23 23:59:59','2019-11-24 07:59:59','BATBTC','4h','0.000030250000000','0.000029760000000','0.035584289967663','0.035007883287195','1176.340164220261','1176.340164220260931','test','test','1.61'),('2019-11-24 11:59:59','2019-11-24 15:59:59','BATBTC','4h','0.000030440000000','0.000029650000000','0.035456199594226','0.034536015701997','1164.7897369982115','1164.789736998211538','test','test','2.59'),('2019-11-24 19:59:59','2019-11-24 23:59:59','BATBTC','4h','0.000029720000000','0.000029350000000','0.035251714284841','0.034812847047782','1186.127667726828','1186.127667726827895','test','test','1.24'),('2019-11-25 03:59:59','2019-11-25 07:59:59','BATBTC','4h','0.000029880000000','0.000030300000000','0.035154188232162','0.035648323408116','1176.512323700186','1176.512323700186016','test','test','0.0'),('2019-12-15 15:59:59','2019-12-16 11:59:59','BATBTC','4h','0.000025910000000','0.000025500000000','0.035263996049040','0.034705978357797','1361.0187591293022','1361.018759129302225','test','test','1.58'),('2019-12-16 15:59:59','2019-12-16 19:59:59','BATBTC','4h','0.000025700000000','0.000025130000000','0.035139992117653','0.034360622642670','1367.314868391163','1367.314868391162918','test','test','2.21'),('2019-12-28 15:59:59','2019-12-31 19:59:59','BATBTC','4h','0.000024610000000','0.000025320000000','0.034966798900990','0.035975593180539','1420.837013449411','1420.837013449410961','test','test','0.0'),('2020-01-01 11:59:59','2020-01-01 15:59:59','BATBTC','4h','0.000026500000000','0.000026110000000','0.035190975407556','0.034673070486464','1327.9613361342056','1327.961336134205567','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-01  4:41:46
