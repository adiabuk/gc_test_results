-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-10 11:59:59','ADAUSDT','4h','0.041980000000000','0.045670000000000','222.222222222222200','241.755333227462785','5293.526017680376','5293.526017680375844','test','test','0.59'),('2019-01-18 15:59:59','2019-01-18 19:59:59','ADAUSDT','4h','0.044160000000000','0.043710000000000','226.562913556720133','224.254188214769869','5130.500759889496','5130.500759889496294','test','test','1.01'),('2019-01-18 23:59:59','2019-01-19 03:59:59','ADAUSDT','4h','0.043720000000000','0.043900000000000','226.049863480731204','226.980535379782737','5170.399439175005','5170.399439175004773','test','test','0.0'),('2019-01-19 11:59:59','2019-01-20 11:59:59','ADAUSDT','4h','0.045440000000000','0.043450000000000','226.256679458298208','216.347991251387697','4979.240304980154','4979.240304980154178','test','test','4.37'),('2019-02-09 07:59:59','2019-02-13 19:59:59','ADAUSDT','4h','0.041670000000000','0.041100000000000','224.054748745651409','220.989924968713041','5376.883819190099','5376.883819190098620','test','test','2.83'),('2019-02-16 19:59:59','2019-02-17 15:59:59','ADAUSDT','4h','0.041210000000000','0.040780000000000','223.373676795220689','221.042915304758566','5420.375559214285','5420.375559214285204','test','test','1.04'),('2019-02-17 19:59:59','2019-02-21 19:59:59','ADAUSDT','4h','0.040930000000000','0.044770000000000','222.855729797340217','243.763767970362096','5444.801607557787','5444.801607557787065','test','test','0.0'),('2019-02-23 03:59:59','2019-02-24 15:59:59','ADAUSDT','4h','0.046410000000000','0.042700000000000','227.501960502456171','209.315529270736448','4902.003027417715','4902.003027417715202','test','test','7.99'),('2019-03-09 07:59:59','2019-03-14 07:59:59','ADAUSDT','4h','0.044010000000000','0.046010000000000','223.460531339851769','233.615520266907083','5077.494463527648','5077.494463527647895','test','test','0.0'),('2019-03-14 15:59:59','2019-03-18 15:59:59','ADAUSDT','4h','0.047370000000000','0.049540000000000','225.717195545864087','236.057206403675451','4764.98196212506','4764.981962125059908','test','test','0.0'),('2019-03-19 15:59:59','2019-03-21 15:59:59','ADAUSDT','4h','0.050900000000000','0.051590000000000','228.014975736488822','231.105944955706462','4479.665535098012','4479.665535098011787','test','test','0.0'),('2019-03-21 19:59:59','2019-03-25 19:59:59','ADAUSDT','4h','0.053390000000000','0.057780000000000','228.701857785203828','247.506899097753802','4283.608499441914','4283.608499441914319','test','test','1.94'),('2019-03-26 15:59:59','2019-04-08 03:59:59','ADAUSDT','4h','0.060650000000000','0.087820000000000','232.880755854659384','337.206726779162125','3839.7486538278545','3839.748653827854469','test','test','0.0'),('2019-05-12 03:59:59','2019-05-17 03:59:59','ADAUSDT','4h','0.074240000000000','0.080870000000000','256.064304948993311','278.932116665208582','3449.1420386448453','3449.142038644845343','test','test','7.05'),('2019-05-19 07:59:59','2019-05-20 15:59:59','ADAUSDT','4h','0.085890000000000','0.081880000000000','261.146040885930063','248.953752797065448','3040.470845103389','3040.470845103388911','test','test','4.66'),('2019-05-20 19:59:59','2019-05-22 11:59:59','ADAUSDT','4h','0.083790000000000','0.081520000000000','258.436643532849018','251.435197288433585','3084.3375526059076','3084.337552605907604','test','test','2.70'),('2019-05-26 23:59:59','2019-05-30 23:59:59','ADAUSDT','4h','0.085140000000000','0.083920000000000','256.880766589645589','253.199834768652323','3017.1572303223584','3017.157230322358373','test','test','1.43'),('2019-06-01 23:59:59','2019-06-03 23:59:59','ADAUSDT','4h','0.090470000000000','0.087450000000000','256.062781740535968','247.515090783794335','2830.3612439541944','2830.361243954194379','test','test','3.33'),('2019-06-12 07:59:59','2019-06-14 11:59:59','ADAUSDT','4h','0.090250000000000','0.088010000000000','254.163294861260084','247.854975963872590','2816.213793476566','2816.213793476566025','test','test','2.48'),('2019-06-15 11:59:59','2019-06-18 07:59:59','ADAUSDT','4h','0.090730000000000','0.089290000000000','252.761446217396184','248.749801970145512','2785.8640605907217','2785.864060590721692','test','test','1.58'),('2019-06-22 15:59:59','2019-06-27 03:59:59','ADAUSDT','4h','0.093460000000000','0.098280000000000','251.869969718007155','264.859625763810698','2694.9493870961605','2694.949387096160535','test','test','0.0'),('2019-07-30 11:59:59','2019-07-30 19:59:59','ADAUSDT','4h','0.060900000000000','0.060160000000000','254.756559950407933','251.660995839352069','4183.194744670081','4183.194744670080581','test','test','1.21'),('2019-07-31 03:59:59','2019-07-31 07:59:59','ADAUSDT','4h','0.060490000000000','0.060100000000000','254.068656814617754','252.430588106439529','4200.176174815965','4200.176174815965169','test','test','0.64'),('2019-07-31 11:59:59','2019-07-31 19:59:59','ADAUSDT','4h','0.060170000000000','0.059340000000000','253.704641546133672','250.204976389356347','4216.464044310016','4216.464044310016106','test','test','1.37'),('2019-08-25 03:59:59','2019-08-25 19:59:59','ADAUSDT','4h','0.052530000000000','0.049780000000000','252.926938177960920','239.685950552044432','4814.904591242355','4814.904591242355309','test','test','5.23'),('2019-08-26 03:59:59','2019-08-26 07:59:59','ADAUSDT','4h','0.049520000000000','0.049690000000000','249.984496483312824','250.842682355731284','5048.152190696947','5048.152190696947400','test','test','0.0'),('2019-09-09 11:59:59','2019-09-10 19:59:59','ADAUSDT','4h','0.046180000000000','0.045970000000000','250.175204454961403','249.037551944447273','5417.392907210078','5417.392907210078192','test','test','0.45'),('2019-09-10 23:59:59','2019-09-11 03:59:59','ADAUSDT','4h','0.046460000000000','0.045730000000000','249.922392785958237','245.995501982390664','5379.302470640513','5379.302470640513093','test','test','1.57'),('2019-09-15 07:59:59','2019-09-16 15:59:59','ADAUSDT','4h','0.046400000000000','0.045870000000000','249.049750385165481','246.205001081197025','5367.45151692167','5367.451516921670191','test','test','1.14'),('2019-09-16 19:59:59','2019-09-22 03:59:59','ADAUSDT','4h','0.046370000000000','0.049850000000000','248.417583873172475','267.060956568420295','5357.29100438155','5357.291004381550010','test','test','0.0'),('2019-10-07 23:59:59','2019-10-11 07:59:59','ADAUSDT','4h','0.041360000000000','0.040450000000000','252.560555583227568','247.003734848683621','6106.39641158674','6106.396411586740214','test','test','2.20'),('2019-10-13 15:59:59','2019-10-13 23:59:59','ADAUSDT','4h','0.041480000000000','0.041270000000000','251.325706531106675','250.053324699584692','6058.961102485696','6058.961102485695847','test','test','0.55'),('2019-10-14 03:59:59','2019-10-14 19:59:59','ADAUSDT','4h','0.041400000000000','0.041580000000000','251.042955012990660','252.134446121742798','6063.839493067408','6063.839493067407602','test','test','0.43'),('2019-10-14 23:59:59','2019-10-15 11:59:59','ADAUSDT','4h','0.041730000000000','0.041240000000000','251.285508592713398','248.334875973244664','6021.699223405545','6021.699223405545126','test','test','1.55'),('2019-10-26 03:59:59','2019-10-30 15:59:59','ADAUSDT','4h','0.041560000000000','0.041500000000000','250.629812455053667','250.267979232067574','6030.553716435363','6030.553716435362730','test','test','4.54'),('2019-11-02 11:59:59','2019-11-03 11:59:59','ADAUSDT','4h','0.042210000000000','0.041540000000000','250.549405072167843','246.572430388482644','5935.783109977917','5935.783109977916865','test','test','1.58'),('2019-11-04 11:59:59','2019-11-07 11:59:59','ADAUSDT','4h','0.042430000000000','0.043180000000000','249.665632920237812','254.078765719912070','5884.177066232331','5884.177066232330617','test','test','0.0'),('2019-11-10 23:59:59','2019-11-11 07:59:59','ADAUSDT','4h','0.043840000000000','0.043060000000000','250.646329097943180','246.186836928773602','5717.297652781551','5717.297652781550823','test','test','1.77'),('2019-11-11 15:59:59','2019-11-12 15:59:59','ADAUSDT','4h','0.043190000000000','0.043710000000000','249.655330838127753','252.661137090404338','5780.396638993465','5780.396638993464876','test','test','0.09'),('2019-11-12 23:59:59','2019-11-13 23:59:59','ADAUSDT','4h','0.043700000000000','0.043260000000000','250.323287783078086','247.802870240182102','5728.221688399956','5728.221688399956292','test','test','1.12'),('2019-11-16 15:59:59','2019-11-17 11:59:59','ADAUSDT','4h','0.043840000000000','0.043830000000000','249.763194995767861','249.706223464062646','5697.153170523902','5697.153170523902190','test','test','1.14'),('2019-11-17 15:59:59','2019-11-18 19:59:59','ADAUSDT','4h','0.044570000000000','0.043370000000000','249.750534655388947','243.026266277859975','5603.556981274152','5603.556981274152349','test','test','2.69'),('2019-11-29 15:59:59','2019-12-01 03:59:59','ADAUSDT','4h','0.041850000000000','0.038790000000000','248.256252793715845','230.104182696971037','5932.049051223796','5932.049051223795686','test','test','7.31');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-01  2:26:13
