-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-14 15:59:59','WABIETH','4h','0.000895560000000','0.000882180000000','1.297777777777778','1.278388494349904','1449.1243219636626','1449.124321963662624','test','test','1.49'),('2019-01-14 19:59:59','2019-01-20 23:59:59','WABIETH','4h','0.000891810000000','0.001111700000000','1.293469048127139','1.612394501971205','1450.3863470101694','1450.386347010169402','test','test','0.0'),('2019-01-23 03:59:59','2019-01-24 23:59:59','WABIETH','4h','0.001223780000000','0.001139700000000','1.364341371203598','1.270604079786188','1114.858366049125','1114.858366049124925','test','test','7.15'),('2019-02-07 15:59:59','2019-02-08 11:59:59','WABIETH','4h','0.001113880000000','0.001079350000000','1.343510861999729','1.301862363000869','1206.1540399322453','1206.154039932245269','test','test','3.09'),('2019-02-08 15:59:59','2019-02-08 19:59:59','WABIETH','4h','0.001156610000000','0.001124600000000','1.334255639999983','1.297329171236614','1153.5916514641779','1153.591651464177858','test','test','2.76'),('2019-02-08 23:59:59','2019-02-09 19:59:59','WABIETH','4h','0.001128740000000','0.001097380000000','1.326049758052567','1.289207863185256','1174.8053210239445','1174.805321023944543','test','test','2.77'),('2019-02-09 23:59:59','2019-02-10 03:59:59','WABIETH','4h','0.001108850000000','0.001116150000000','1.317862670304276','1.326538683735508','1188.494990579678','1188.494990579677960','test','test','0.0'),('2019-02-10 11:59:59','2019-02-11 03:59:59','WABIETH','4h','0.001125100000000','0.001127840000000','1.319790673288994','1.323004811094355','1173.0429946573588','1173.042994657358804','test','test','0.0'),('2019-02-11 07:59:59','2019-02-12 11:59:59','WABIETH','4h','0.001144490000000','0.001112500000000','1.320504926134630','1.283595077567105','1153.7933281502067','1153.793328150206662','test','test','2.79'),('2019-02-26 15:59:59','2019-03-06 15:59:59','WABIETH','4h','0.001131270000000','0.001346220000000','1.312302737564069','1.561650349928400','1160.026110092258','1160.026110092258023','test','test','5.10'),('2019-03-06 19:59:59','2019-03-11 07:59:59','WABIETH','4h','0.001369270000000','0.001520770000000','1.367713318089476','1.519041082292705','998.8631300543179','998.863130054317935','test','test','0.0'),('2019-03-12 23:59:59','2019-03-14 07:59:59','WABIETH','4h','0.001692520000000','0.001568530000000','1.401341710134638','1.298682740881930','827.9616844318754','827.961684431875369','test','test','7.32'),('2019-03-15 03:59:59','2019-03-16 07:59:59','WABIETH','4h','0.001649040000000','0.001546500000000','1.378528605856258','1.292809446075718','835.9582580509011','835.958258050901122','test','test','6.21'),('2019-03-19 11:59:59','2019-03-21 15:59:59','WABIETH','4h','0.001636680000000','0.001668870000000','1.359479903682805','1.386217969828630','830.6326854869643','830.632685486964306','test','test','3.38'),('2019-03-21 19:59:59','2019-03-23 23:59:59','WABIETH','4h','0.001672880000000','0.001677590000000','1.365421696159655','1.369266046136289','816.2101861219303','816.210186121930292','test','test','0.0'),('2019-03-27 15:59:59','2019-04-01 07:59:59','WABIETH','4h','0.001723340000000','0.002343230000000','1.366275996154463','1.857729120468986','792.8069888440253','792.806988844025341','test','test','0.77'),('2019-04-13 15:59:59','2019-04-17 03:59:59','WABIETH','4h','0.002550000000000','0.002422480000000','1.475487801557690','1.401701839026460','578.6226672775254','578.622667277525352','test','test','5.00'),('2019-04-26 03:59:59','2019-04-26 15:59:59','WABIETH','4h','0.002269550000000','0.002108710000000','1.459090920995194','1.355687081585238','642.8987777291509','642.898777729150879','test','test','7.08'),('2019-04-28 15:59:59','2019-04-29 15:59:59','WABIETH','4h','0.002321640000000','0.002188890000000','1.436112290015204','1.353996239938742','618.5766484102635','618.576648410263488','test','test','5.71'),('2019-04-29 19:59:59','2019-04-29 23:59:59','WABIETH','4h','0.002208760000000','0.002191000000000','1.417864278887101','1.406463642515093','641.9277236490616','641.927723649061591','test','test','0.80'),('2019-06-08 03:59:59','2019-06-12 11:59:59','WABIETH','4h','0.001291660000000','0.001305090000000','1.415330804137766','1.430046667987053','1095.7456328583112','1095.745632858311183','test','test','2.89'),('2019-06-12 15:59:59','2019-06-12 23:59:59','WABIETH','4h','0.001339910000000','0.001298050000000','1.418600996104274','1.374282618230443','1058.7285684145013','1058.728568414501297','test','test','3.12'),('2019-07-21 15:59:59','2019-07-26 15:59:59','WABIETH','4h','0.000664200000000','0.000708000000000','1.408752467687868','1.501651230236390','2120.976313893206','2120.976313893206225','test','test','0.39'),('2019-07-28 15:59:59','2019-07-29 07:59:59','WABIETH','4h','0.000719110000000','0.000702460000000','1.429396637143095','1.396300929937754','1987.7301624829227','1987.730162482922651','test','test','2.34'),('2019-08-16 15:59:59','2019-08-16 19:59:59','WABIETH','4h','0.000571340000000','0.000552050000000','1.422042035541908','1.374030009663091','2488.9593508977273','2488.959350897727290','test','test','3.37'),('2019-08-17 23:59:59','2019-08-18 11:59:59','WABIETH','4h','0.000581400000000','0.000562110000000','1.411372696457726','1.364545418654717','2427.5416175743485','2427.541617574348493','test','test','3.31'),('2019-08-23 03:59:59','2019-08-23 15:59:59','WABIETH','4h','0.000576780000000','0.000560180000000','1.400966634723724','1.360646155275036','2428.944545101641','2428.944545101640870','test','test','2.87'),('2019-08-23 19:59:59','2019-08-26 11:59:59','WABIETH','4h','0.000574690000000','0.000643740000000','1.392006528179571','1.559258526249486','2422.186793192106','2422.186793192106052','test','test','0.0'),('2019-08-26 15:59:59','2019-08-26 23:59:59','WABIETH','4h','0.000693010000000','0.000634530000000','1.429173638861775','1.308572097180361','2062.2698645932596','2062.269864593259626','test','test','8.43'),('2019-08-27 11:59:59','2019-08-28 15:59:59','WABIETH','4h','0.000734350000000','0.000652540000000','1.402373296265905','1.246142399054066','1909.6797116714165','1909.679711671416499','test','test','11.1'),('2019-08-29 15:59:59','2019-09-06 03:59:59','WABIETH','4h','0.000731650000000','0.000938110000000','1.367655319107719','1.753585910487449','1869.2753626839592','1869.275362683959202','test','test','5.63'),('2019-09-07 03:59:59','2019-09-07 19:59:59','WABIETH','4h','0.001109470000000','0.000950410000000','1.453417672747658','1.245047356265696','1310.0107914118078','1310.010791411807759','test','test','14.3'),('2019-09-09 03:59:59','2019-09-10 19:59:59','WABIETH','4h','0.001037170000000','0.000958300000000','1.407113157973889','1.300111398600401','1356.6851701976427','1356.685170197642719','test','test','7.60'),('2019-09-29 07:59:59','2019-09-30 19:59:59','WABIETH','4h','0.000749980000000','0.000682330000000','1.383334989224225','1.258554845725707','1844.4958388546695','1844.495838854669501','test','test','9.02'),('2019-10-01 11:59:59','2019-10-02 19:59:59','WABIETH','4h','0.000713490000000','0.000693950000000','1.355606068446777','1.318480751234973','1899.965056898873','1899.965056898872945','test','test','2.73'),('2019-10-04 19:59:59','2019-10-06 11:59:59','WABIETH','4h','0.000737060000000','0.000717200000000','1.347355997955265','1.311051639939104','1828.0139987996424','1828.013998799642422','test','test','2.69'),('2019-10-06 15:59:59','2019-10-08 11:59:59','WABIETH','4h','0.000736930000000','0.000728620000000','1.339288362840563','1.324185861524013','1817.3888467569002','1817.388846756900193','test','test','2.14'),('2019-10-09 07:59:59','2019-10-09 15:59:59','WABIETH','4h','0.000755190000000','0.000667960000000','1.335932251436884','1.181622249592528','1769.0015114565663','1769.001511456566277','test','test','11.5'),('2019-10-15 11:59:59','2019-10-15 19:59:59','WABIETH','4h','0.000713040000000','0.000705990000000','1.301641139915916','1.288771497208063','1825.481235156396','1825.481235156395996','test','test','0.98'),('2019-10-16 03:59:59','2019-10-16 07:59:59','WABIETH','4h','0.000691330000000','0.000686910000000','1.298781219314171','1.290477496071481','1878.6704168981116','1878.670416898111625','test','test','0.63'),('2019-10-20 11:59:59','2019-10-23 15:59:59','WABIETH','4h','0.000700070000000','0.000744490000000','1.296935947482462','1.379227568016367','1852.5803812225383','1852.580381222538335','test','test','0.78'),('2019-10-23 23:59:59','2019-10-24 03:59:59','WABIETH','4h','0.000749300000000','0.000750510000000','1.315222974267775','1.317346849616586','1755.2688833147934','1755.268883314793356','test','test','0.0'),('2019-10-24 11:59:59','2019-10-25 19:59:59','WABIETH','4h','0.000821790000000','0.000753170000000','1.315694946567511','1.205833561988163','1601.0111422230868','1601.011142223086836','test','test','8.35'),('2019-10-28 03:59:59','2019-11-02 19:59:59','WABIETH','4h','0.000861050000000','0.000930490000000','1.291281305549878','1.395417620348535','1499.6589112709805','1499.658911270980525','test','test','8.07'),('2019-11-07 03:59:59','2019-11-07 07:59:59','WABIETH','4h','0.000948470000000','0.000932650000000','1.314422708838468','1.292498802701400','1385.834774783038','1385.834774783038029','test','test','1.66'),('2019-11-11 07:59:59','2019-11-15 19:59:59','WABIETH','4h','0.001036930000000','0.001078160000000','1.309550729696898','1.361620567183906','1262.9114112783868','1262.911411278386822','test','test','0.87'),('2019-11-18 03:59:59','2019-11-18 15:59:59','WABIETH','4h','0.001124180000000','0.001098760000000','1.321121804694010','1.291248549276442','1175.187073861846','1175.187073861846102','test','test','2.85'),('2019-11-18 23:59:59','2019-11-21 11:59:59','WABIETH','4h','0.001108370000000','0.001100650000000','1.314483303490106','1.305327686590565','1185.9607382824383','1185.960738282438342','test','test','0.69'),('2019-11-23 19:59:59','2019-11-24 19:59:59','WABIETH','4h','0.001179280000000','0.001140310000000','1.312448721956875','1.269078083351404','1112.9237517441786','1112.923751744178617','test','test','4.65'),('2019-11-25 07:59:59','2019-11-25 11:59:59','WABIETH','4h','0.001189190000000','0.001108890000000','1.302810802266770','1.214838562824779','1095.5447003983975','1095.544700398397481','test','test','6.75'),('2019-11-25 19:59:59','2019-11-25 23:59:59','WABIETH','4h','0.001147240000000','0.001103690000000','1.283261415724106','1.234547951536330','1118.5640456435494','1118.564045643549434','test','test','3.79'),('2019-11-26 11:59:59','2019-11-30 03:59:59','WABIETH','4h','0.001186240000000','0.001201830000000','1.272436201460155','1.289159023469836','1072.663374578631','1072.663374578630965','test','test','1.71'),('2019-12-16 11:59:59','2019-12-18 15:59:59','WABIETH','4h','0.001102790000000','0.001120910000000','1.276152384128973','1.297120910503366','1157.2034422954264','1157.203442295426385','test','test','0.0'),('2019-12-18 19:59:59','2019-12-18 23:59:59','WABIETH','4h','0.001133810000000','0.001120660000000','1.280812056656616','1.265957117517753','1129.6531664534766','1129.653166453476615','test','test','1.15'),('2019-12-19 15:59:59','2019-12-21 15:59:59','WABIETH','4h','0.001205300000000','0.001170000000000','1.277510959070202','1.240096094011563','1059.911191462874','1059.911191462874058','test','test','2.92');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-01  5:59:55
