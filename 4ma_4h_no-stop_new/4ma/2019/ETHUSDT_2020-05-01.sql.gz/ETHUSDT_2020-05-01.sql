-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-07 19:59:59','ETHUSDT','4h','135.270000000000010','151.409999999999997','222.222222222222200','248.737093713806928','1.6428049251291652','1.642804925129165','test','test','0.0'),('2019-02-09 07:59:59','2019-02-14 23:59:59','ETHUSDT','4h','119.049999999999997','120.420000000000002','228.114415887018822','230.739504083282696','1.9161227709955382','1.916122770995538','test','test','1.88'),('2019-02-15 07:59:59','2019-02-15 19:59:59','ETHUSDT','4h','122.519999999999996','121.150000000000006','228.697768819521912','226.140505162300713','1.8666158081906785','1.866615808190679','test','test','1.11'),('2019-02-16 03:59:59','2019-02-24 15:59:59','ETHUSDT','4h','122.480000000000004','139.990000000000009','228.129488006806099','260.743362394454493','1.8625856303625579','1.862585630362558','test','test','0.0'),('2019-03-07 15:59:59','2019-03-08 23:59:59','ETHUSDT','4h','136.620000000000005','133.520000000000010','235.377015648505704','230.036152315828446','1.7228591395733106','1.722859139573311','test','test','2.26'),('2019-03-09 07:59:59','2019-03-09 19:59:59','ETHUSDT','4h','137.090000000000003','136.969999999999999','234.190157130133031','233.985161734001906','1.7082949677593773','1.708294967759377','test','test','0.08'),('2019-03-09 23:59:59','2019-03-10 07:59:59','ETHUSDT','4h','137.270000000000010','134.930000000000007','234.144602597659429','230.153210668770953','1.7057230465335427','1.705723046533543','test','test','1.70'),('2019-03-16 03:59:59','2019-03-18 07:59:59','ETHUSDT','4h','139.599999999999994','137.819999999999993','233.257626613461980','230.283424784149929','1.670899904107894','1.670899904107894','test','test','1.31'),('2019-03-18 15:59:59','2019-03-18 19:59:59','ETHUSDT','4h','137.550000000000011','137.389999999999986','232.596692873614870','232.326133289029002','1.690997403661322','1.690997403661322','test','test','0.11'),('2019-03-19 23:59:59','2019-03-20 03:59:59','ETHUSDT','4h','138.550000000000011','137.560000000000002','232.536568521484696','230.874993618299783','1.6783584880655698','1.678358488065570','test','test','0.71'),('2019-03-20 15:59:59','2019-03-20 19:59:59','ETHUSDT','4h','138.240000000000009','137.830000000000013','232.167329654110262','231.478754674667357','1.679451169372904','1.679451169372904','test','test','0.29'),('2019-03-20 23:59:59','2019-03-21 15:59:59','ETHUSDT','4h','139.009999999999991','134.580000000000013','232.014312992011838','224.620431929105536','1.66904764399692','1.669047643996920','test','test','3.18'),('2019-03-27 23:59:59','2019-04-11 03:59:59','ETHUSDT','4h','139.449999999999989','168.879999999999995','230.371228311365968','278.989552077615542','1.651998768815819','1.651998768815819','test','test','1.39'),('2019-04-18 03:59:59','2019-04-21 11:59:59','ETHUSDT','4h','171.789999999999992','166.840000000000003','241.175300259421419','234.226014874450613','1.403896037367841','1.403896037367841','test','test','2.88'),('2019-04-23 03:59:59','2019-04-23 23:59:59','ETHUSDT','4h','171.539999999999992','169.159999999999997','239.631014618316840','236.306298430887722','1.3969395745500575','1.396939574550057','test','test','1.38'),('2019-05-03 15:59:59','2019-05-04 07:59:59','ETHUSDT','4h','168.289999999999992','165.930000000000007','238.892188798888128','235.542105219558579','1.4195269403938924','1.419526940393892','test','test','1.40'),('2019-05-04 19:59:59','2019-05-05 07:59:59','ETHUSDT','4h','162.780000000000001','162.810000000000002','238.147725781259368','238.191615889217587','1.463003598607073','1.463003598607073','test','test','0.0'),('2019-05-06 15:59:59','2019-05-08 03:59:59','ETHUSDT','4h','170.610000000000014','169.639999999999986','238.157479138583341','236.803439195060491','1.3959174675492838','1.395917467549284','test','test','0.83'),('2019-05-08 07:59:59','2019-05-09 15:59:59','ETHUSDT','4h','170.319999999999993','168.349999999999994','237.856581373356079','235.105421995094503','1.3965276031784646','1.396527603178465','test','test','1.15'),('2019-05-10 07:59:59','2019-05-18 11:59:59','ETHUSDT','4h','175.069999999999993','234.689999999999998','237.245212622631271','318.038949850947290','1.3551448713236494','1.355144871323649','test','test','1.38'),('2019-05-19 03:59:59','2019-05-22 23:59:59','ETHUSDT','4h','252.750000000000000','243.639999999999986','255.199376451145923','246.001092298940421','1.00969090584034','1.009690905840340','test','test','3.60'),('2019-05-25 03:59:59','2019-05-26 11:59:59','ETHUSDT','4h','250.629999999999995','246.099999999999994','253.155313306211411','248.579669651113704','1.0100758620524735','1.010075862052473','test','test','1.80'),('2019-05-26 19:59:59','2019-05-30 23:59:59','ETHUSDT','4h','258.910000000000025','254.560000000000002','252.138503605078569','247.902272904518156','0.9738461380598608','0.973846138059861','test','test','1.68'),('2019-06-02 07:59:59','2019-06-03 07:59:59','ETHUSDT','4h','271.279999999999973','261.509999999999991','251.197119004954061','242.150392918702238','0.9259699167095035','0.925969916709503','test','test','3.60'),('2019-06-13 07:59:59','2019-06-18 19:59:59','ETHUSDT','4h','259.040000000000020','264.519999999999982','249.186735430231437','254.458289283526938','0.9619623819882313','0.961962381988231','test','test','2.18'),('2019-06-20 03:59:59','2019-06-27 11:59:59','ETHUSDT','4h','269.980000000000018','317.310000000000002','250.358191842074888','294.248306739050179','0.9273212528412285','0.927321252841228','test','test','1.02'),('2019-07-08 15:59:59','2019-07-10 15:59:59','ETHUSDT','4h','307.740000000000009','288.230000000000018','260.111550708069331','243.621083578952437','0.8452315289142436','0.845231528914244','test','test','6.33'),('2019-08-03 03:59:59','2019-08-04 07:59:59','ETHUSDT','4h','221.729999999999990','218.189999999999998','256.447002457154497','252.352732900945028','1.1565733209631286','1.156573320963129','test','test','1.59'),('2019-08-04 11:59:59','2019-08-07 15:59:59','ETHUSDT','4h','218.800000000000011','224.539999999999992','255.537164777996821','262.240927693105164','1.1679029468829836','1.167902946882984','test','test','0.0'),('2019-09-08 15:59:59','2019-09-09 07:59:59','ETHUSDT','4h','181.349999999999994','177.229999999999990','257.026889870243110','251.187624437293550','1.4172974351819305','1.417297435181931','test','test','2.27'),('2019-09-09 11:59:59','2019-09-10 19:59:59','ETHUSDT','4h','182.780000000000001','178.129999999999995','255.729275329587693','249.223415113576181','1.3991097238734418','1.399109723873442','test','test','2.54'),('2019-09-10 23:59:59','2019-09-11 07:59:59','ETHUSDT','4h','179.810000000000002','179.060000000000002','254.283528614918424','253.222894353969707','1.4141790145982893','1.414179014598289','test','test','0.41'),('2019-09-12 23:59:59','2019-09-13 11:59:59','ETHUSDT','4h','180.719999999999999','179.169999999999987','254.047832112485395','251.868913676372330','1.4057538297503618','1.405753829750362','test','test','1.11'),('2019-09-13 23:59:59','2019-09-22 03:59:59','ETHUSDT','4h','180.949999999999989','209.300000000000011','253.563628015571368','293.290231244316601','1.4012911191797257','1.401291119179726','test','test','0.55'),('2019-10-08 23:59:59','2019-10-11 19:59:59','ETHUSDT','4h','180.599999999999994','181.990000000000009','262.391762066403658','264.411277843105211','1.4528890479867314','1.452889047986731','test','test','0.68'),('2019-10-14 23:59:59','2019-10-15 11:59:59','ETHUSDT','4h','186.719999999999999','183.900000000000006','262.840543350115126','258.870907894634570','1.4076721473335214','1.407672147333521','test','test','1.69'),('2019-10-26 23:59:59','2019-10-30 23:59:59','ETHUSDT','4h','179.490000000000009','183.129999999999995','261.958402137786095','267.270835052051780','1.4594595918312223','1.459459591831222','test','test','1.11'),('2019-11-02 15:59:59','2019-11-03 11:59:59','ETHUSDT','4h','183.919999999999987','181.479999999999990','263.138942785400729','259.647973774981097','1.430725004270339','1.430725004270339','test','test','1.32'),('2019-11-04 15:59:59','2019-11-07 19:59:59','ETHUSDT','4h','186.370000000000005','186.080000000000013','262.363171894196341','261.954923142523228','1.407754316114162','1.407754316114162','test','test','1.34'),('2019-11-10 19:59:59','2019-11-11 11:59:59','ETHUSDT','4h','189.949999999999989','186.490000000000009','262.272449949380075','257.495073393313476','1.3807446693834171','1.380744669383417','test','test','1.82'),('2019-11-11 19:59:59','2019-11-11 23:59:59','ETHUSDT','4h','186.569999999999993','184.979999999999990','261.210810714698596','258.984701538323122','1.4000686643870859','1.400068664387086','test','test','0.85'),('2019-11-13 11:59:59','2019-11-14 07:59:59','ETHUSDT','4h','187.180000000000007','185.270000000000010','260.716119786615195','258.055751217363991','1.3928631252623955','1.392863125262396','test','test','1.02'),('2019-12-30 07:59:59','2019-12-31 15:59:59','ETHUSDT','4h','135.590000000000003','129.729999999999990','260.124926771226058','248.882710745859981','1.9184668985266322','1.918466898526632','test','test','4.32'),('2020-01-01 15:59:59','2020-01-01 15:59:59','ETHUSDT','4h','132.080000000000013','132.080000000000013','257.626656543366892','257.626656543366892','1.9505349526299733','1.950534952629973','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-01  0:59:38
