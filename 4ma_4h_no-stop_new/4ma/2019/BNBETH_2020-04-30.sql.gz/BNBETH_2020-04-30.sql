-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 07:59:59','2019-01-14 19:59:59','BNBETH','4h','0.045554000000000','0.046534000000000','1.297777777777778','1.325696779890045','28.488777665578823','28.488777665578823','test','test','4.30'),('2019-01-15 23:59:59','2019-01-29 03:59:59','BNBETH','4h','0.048726000000000','0.059500000000000','1.303982000469392','1.592310656075377','26.761523631518955','26.761523631518955','test','test','0.0'),('2019-02-01 11:59:59','2019-02-08 19:59:59','BNBETH','4h','0.061535000000000','0.070926000000000','1.368055035048500','1.576837107594863','22.2321448776875','22.232144877687499','test','test','0.80'),('2019-02-10 03:59:59','2019-02-12 19:59:59','BNBETH','4h','0.077199000000000','0.074411000000000','1.414451051169914','1.363368918879836','18.32214214134787','18.322142141347872','test','test','5.10'),('2019-02-15 23:59:59','2019-02-16 15:59:59','BNBETH','4h','0.076314000000000','0.074028000000000','1.403099466216564','1.361069361913670','18.385872398466386','18.385872398466386','test','test','3.14'),('2019-02-22 23:59:59','2019-02-23 07:59:59','BNBETH','4h','0.072977000000000','0.072146000000000','1.393759443038143','1.377888496066293','19.098612481167258','19.098612481167258','test','test','1.13'),('2019-02-28 07:59:59','2019-03-10 11:59:59','BNBETH','4h','0.073316000000000','0.105077000000000','1.390232565933287','1.992490961462327','18.962198782438854','18.962198782438854','test','test','0.0'),('2019-03-11 03:59:59','2019-03-15 15:59:59','BNBETH','4h','0.107641000000000','0.110700000000000','1.524067764939741','1.567379544772246','14.15880347581071','14.158803475810711','test','test','0.54'),('2019-03-16 23:59:59','2019-03-19 15:59:59','BNBETH','4h','0.113143000000000','0.111646000000000','1.533692604902519','1.513400250717646','13.555346816882349','13.555346816882349','test','test','1.76'),('2019-03-23 19:59:59','2019-03-23 23:59:59','BNBETH','4h','0.110343000000000','0.110262000000000','1.529183192861437','1.528060658231947','13.858452215921595','13.858452215921595','test','test','0.07'),('2019-03-24 11:59:59','2019-03-27 19:59:59','BNBETH','4h','0.124743000000000','0.119909000000000','1.528933740721550','1.469684999688803','12.256669638549257','12.256669638549257','test','test','4.64'),('2019-03-29 03:59:59','2019-03-29 11:59:59','BNBETH','4h','0.121099000000000','0.118494000000000','1.515767353825384','1.483161188979142','12.516761937137254','12.516761937137254','test','test','2.15'),('2019-03-31 07:59:59','2019-04-02 15:59:59','BNBETH','4h','0.122900000000000','0.121304000000000','1.508521539415108','1.488931625851996','12.274381931774679','12.274381931774679','test','test','1.29'),('2019-04-02 19:59:59','2019-04-02 23:59:59','BNBETH','4h','0.124288000000000','0.120740000000000','1.504168225289972','1.461229334461181','12.102280391429359','12.102280391429359','test','test','2.85'),('2019-04-14 07:59:59','2019-04-18 03:59:59','BNBETH','4h','0.117523000000000','0.113702000000000','1.494626249550240','1.446031788044565','12.71773397165015','12.717733971650150','test','test','3.25'),('2019-04-18 07:59:59','2019-04-23 07:59:59','BNBETH','4h','0.120381000000000','0.136401000000000','1.483827480326757','1.681291500685739','12.326093655367188','12.326093655367188','test','test','0.0'),('2019-04-25 03:59:59','2019-04-27 19:59:59','BNBETH','4h','0.141428000000000','0.140285000000000','1.527708373739864','1.515361662542756','10.802022044714374','10.802022044714374','test','test','2.06'),('2019-04-28 07:59:59','2019-04-29 15:59:59','BNBETH','4h','0.144332000000000','0.140396000000000','1.524964660140507','1.483378172720440','10.565672616886811','10.565672616886811','test','test','2.72'),('2019-05-02 19:59:59','2019-05-03 11:59:59','BNBETH','4h','0.146615000000000','0.140481000000000','1.515723218491603','1.452309200674684','10.338118326853346','10.338118326853346','test','test','4.18'),('2019-05-03 19:59:59','2019-05-04 03:59:59','BNBETH','4h','0.140000000000000','0.139561000000000','1.501631214532288','1.496922528081004','10.725937246659202','10.725937246659202','test','test','0.31'),('2019-05-04 07:59:59','2019-05-04 11:59:59','BNBETH','4h','0.139968000000000','0.140613000000000','1.500584839765336','1.507499829060379','10.72091363572628','10.720913635726280','test','test','0.0'),('2019-05-05 15:59:59','2019-05-05 23:59:59','BNBETH','4h','0.141162000000000','0.140779000000000','1.502121504053123','1.498045955845728','10.641118034974873','10.641118034974873','test','test','0.53'),('2019-05-21 15:59:59','2019-05-26 19:59:59','BNBETH','4h','0.124170000000000','0.126951000000000','1.501215826673702','1.534838128469462','12.090004241553533','12.090004241553533','test','test','0.57'),('2019-06-06 07:59:59','2019-06-14 07:59:59','BNBETH','4h','0.129423000000000','0.131103000000000','1.508687449294982','1.528271255224497','11.657027338996793','11.657027338996793','test','test','3.37'),('2019-06-19 07:59:59','2019-06-21 03:59:59','BNBETH','4h','0.131690000000000','0.130000000000000','1.513039406168208','1.493622316059435','11.489402431226424','11.489402431226424','test','test','2.25'),('2019-06-21 07:59:59','2019-06-21 19:59:59','BNBETH','4h','0.130827000000000','0.128840000000000','1.508724497255147','1.485809995080168','11.532210455449924','11.532210455449924','test','test','1.51'),('2019-07-12 19:59:59','2019-07-24 07:59:59','BNBETH','4h','0.117524000000000','0.136001000000000','1.503632385660707','1.740031892058148','12.794258072059387','12.794258072059387','test','test','1.24'),('2019-08-08 11:59:59','2019-08-13 23:59:59','BNBETH','4h','0.139392000000000','0.140643000000000','1.556165609304583','1.570131713365361','11.16395208695322','11.163952086953220','test','test','0.81'),('2019-08-15 11:59:59','2019-08-18 11:59:59','BNBETH','4h','0.148398000000000','0.145666000000000','1.559269187984756','1.530563117676704','10.507346379228533','10.507346379228533','test','test','1.84'),('2019-10-09 19:59:59','2019-10-10 15:59:59','BNBETH','4h','0.091546000000000','0.090530000000000','1.552890061249633','1.535655705819252','16.962948258248677','16.962948258248677','test','test','1.10'),('2019-10-10 19:59:59','2019-10-10 23:59:59','BNBETH','4h','0.090774000000000','0.091715000000000','1.549060204487327','1.565118389126349','17.065020870373967','17.065020870373967','test','test','0.0'),('2019-10-11 11:59:59','2019-10-21 07:59:59','BNBETH','4h','0.091645000000000','0.103823000000000','1.552628689962665','1.758945588717265','16.94177194568896','16.941771945688959','test','test','0.16'),('2019-10-22 07:59:59','2019-10-23 15:59:59','BNBETH','4h','0.107100000000000','0.104092000000000','1.598476889685909','1.553582225968120','14.92508767213734','14.925087672137339','test','test','2.80'),('2019-10-28 03:59:59','2019-10-30 03:59:59','BNBETH','4h','0.111132000000000','0.106996000000000','1.588500297748623','1.529381077078714','14.293815442434427','14.293815442434427','test','test','3.72'),('2019-10-30 07:59:59','2019-10-30 11:59:59','BNBETH','4h','0.108014000000000','0.107578000000000','1.575362693155310','1.569003719927620','14.584800980940521','14.584800980940521','test','test','0.40'),('2019-10-30 23:59:59','2019-11-05 15:59:59','BNBETH','4h','0.109453000000000','0.108555000000000','1.573949587993601','1.561036221251545','14.380141138146977','14.380141138146977','test','test','0.82'),('2019-11-12 19:59:59','2019-11-15 23:59:59','BNBETH','4h','0.111114000000000','0.112719000000000','1.571079950939811','1.593773610795980','14.139351935307976','14.139351935307976','test','test','0.0'),('2019-12-05 19:59:59','2019-12-08 03:59:59','BNBETH','4h','0.105403000000000','0.104823000000000','1.576122986463403','1.567450070776480','14.953302908488407','14.953302908488407','test','test','0.69'),('2019-12-08 07:59:59','2019-12-08 15:59:59','BNBETH','4h','0.105239000000000','0.104066000000000','1.574195671866310','1.556649595572358','14.958291810700498','14.958291810700498','test','test','1.11'),('2019-12-19 19:59:59','2019-12-22 11:59:59','BNBETH','4h','0.104447000000000','0.103542000000000','1.570296543800987','1.556690424217467','15.034386280132384','15.034386280132384','test','test','0.86'),('2019-12-24 07:59:59','2019-12-26 19:59:59','BNBETH','4h','0.104971000000000','0.103488000000000','1.567272961671316','1.545130981484802','14.930532829746463','14.930532829746463','test','test','1.41'),('2019-12-27 07:59:59','2019-12-29 19:59:59','BNBETH','4h','0.105530000000000','0.104526000000000','1.562352521629869','1.547488483614931','14.804818739977907','14.804818739977907','test','test','0.95'),('2019-12-30 03:59:59','2019-12-30 23:59:59','BNBETH','4h','0.106623000000000','0.105284000000000','1.559049402070993','1.539470444910033','14.62207405598223','14.622074055982230','test','test','1.25'),('2019-12-31 19:59:59','2020-01-01 11:59:59','BNBETH','4h','0.106397000000000','0.104850000000000','1.554698522701891','1.532093387081339','14.61224022013676','14.612240220136760','test','test','1.45');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 23:50:17
