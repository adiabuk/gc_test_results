-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-19 11:59:59','2019-01-19 23:59:59','MDABTC','4h','0.000201540000000','0.000199400000000','0.033333333333333','0.032979392014819','165.39313949257385','165.393139492573852','test','test','1.06'),('2019-01-23 19:59:59','2019-01-24 07:59:59','MDABTC','4h','0.000200400000000','0.000197500000000','0.033254679706997','0.032773449312035','165.94151550397652','165.941515503976518','test','test','1.44'),('2019-01-24 11:59:59','2019-01-24 15:59:59','MDABTC','4h','0.000197840000000','0.000200030000000','0.033147739619228','0.033514670218531','167.54821885982386','167.548218859823862','test','test','0.0'),('2019-01-24 23:59:59','2019-01-25 03:59:59','MDABTC','4h','0.000200060000000','0.000198150000000','0.033229279752406','0.032912035304105','166.0965697910927','166.096569791092691','test','test','0.95'),('2019-01-25 19:59:59','2019-01-25 23:59:59','MDABTC','4h','0.000201260000000','0.000197130000000','0.033158780986117','0.032478338943621','164.75594249287929','164.755942492879285','test','test','2.05'),('2019-01-26 03:59:59','2019-01-26 07:59:59','MDABTC','4h','0.000200950000000','0.000205880000000','0.033007571643340','0.033817361781194','164.257634453048','164.257634453048013','test','test','0.0'),('2019-01-26 11:59:59','2019-01-27 03:59:59','MDABTC','4h','0.000207550000000','0.000198260000000','0.033187525007308','0.031702041474097','159.90134910772133','159.901349107721330','test','test','4.47'),('2019-01-27 07:59:59','2019-01-28 11:59:59','MDABTC','4h','0.000207390000000','0.000203510000000','0.032857417555483','0.032242697558785','158.43298883978443','158.432988839784429','test','test','1.87'),('2019-02-01 03:59:59','2019-02-04 19:59:59','MDABTC','4h','0.000208820000000','0.000210920000000','0.032720813111772','0.033049870230509','156.69386606537796','156.693866065377961','test','test','1.22'),('2019-02-21 11:59:59','2019-02-21 15:59:59','MDABTC','4h','0.000200720000000','0.000200540000000','0.032793936915936','0.032764528243931','163.38151113957755','163.381511139577555','test','test','0.08'),('2019-02-23 03:59:59','2019-02-24 19:59:59','MDABTC','4h','0.000207080000000','0.000207280000000','0.032787401655490','0.032819068066206','158.3320535806956','158.332053580695600','test','test','0.0'),('2019-02-24 23:59:59','2019-02-28 23:59:59','MDABTC','4h','0.000217700000000','0.000239420000000','0.032794438635650','0.036066350473805','150.64050820234064','150.640508202340641','test','test','0.0'),('2019-03-09 19:59:59','2019-03-12 19:59:59','MDABTC','4h','0.000240210000000','0.000253770000000','0.033521530155240','0.035413840837164','139.55093524515866','139.550935245158655','test','test','1.38'),('2019-03-12 23:59:59','2019-03-14 23:59:59','MDABTC','4h','0.000281530000000','0.000284800000000','0.033942043640112','0.034336283979341','120.56279487128033','120.562794871280332','test','test','6.68'),('2019-03-23 11:59:59','2019-03-26 11:59:59','MDABTC','4h','0.000298610000000','0.000281830000000','0.034029652604385','0.032117400601098','113.96019089911479','113.960190899114792','test','test','6.85'),('2019-03-26 15:59:59','2019-03-27 03:59:59','MDABTC','4h','0.000294140000000','0.000287270000000','0.033604707714765','0.032819828602776','114.24732343362118','114.247323433621176','test','test','2.33'),('2019-03-29 19:59:59','2019-04-02 07:59:59','MDABTC','4h','0.000292000000000','0.000272930000000','0.033430290134323','0.031247017419044','114.48729498055933','114.487294980559327','test','test','6.53'),('2019-05-24 03:59:59','2019-05-24 15:59:59','MDABTC','4h','0.000126640000000','0.000123910000000','0.032945118419817','0.032234914903660','260.1478081160525','260.147808116052488','test','test','2.15'),('2019-06-02 23:59:59','2019-06-03 07:59:59','MDABTC','4h','0.000122650000000','0.000117830000000','0.032787295416226','0.031498793468356','267.3240555746143','267.324055574614306','test','test','3.92'),('2019-06-03 15:59:59','2019-06-03 19:59:59','MDABTC','4h','0.000118520000000','0.000117390000000','0.032500961650033','0.032191089167207','274.22343612920275','274.223436129202753','test','test','0.95'),('2019-06-03 23:59:59','2019-06-04 03:59:59','MDABTC','4h','0.000118160000000','0.000119260000000','0.032432101098294','0.032734024855980','274.4761433504908','274.476143350490815','test','test','0.0'),('2019-06-04 15:59:59','2019-06-12 03:59:59','MDABTC','4h','0.000120320000000','0.000129900000000','0.032499195266669','0.035086814038733','270.106343639201','270.106343639200986','test','test','0.0'),('2019-07-23 19:59:59','2019-07-25 19:59:59','MDABTC','4h','0.000070100000000','0.000066080000000','0.033074221660461','0.031177525924726','471.81485963567286','471.814859635672860','test','test','6.41'),('2019-07-26 11:59:59','2019-07-26 15:59:59','MDABTC','4h','0.000066940000000','0.000066640000000','0.032652733719186','0.032506396400456','487.7910624318228','487.791062431822809','test','test','0.44'),('2019-07-26 19:59:59','2019-07-27 03:59:59','MDABTC','4h','0.000073690000000','0.000066730000000','0.032620214315024','0.029539244147667','442.66812749387975','442.668127493879751','test','test','9.44'),('2019-07-27 11:59:59','2019-07-29 15:59:59','MDABTC','4h','0.000068000000000','0.000066580000000','0.031935554277834','0.031268664762032','469.64050408578754','469.640504085787541','test','test','2.08'),('2019-07-30 23:59:59','2019-07-31 11:59:59','MDABTC','4h','0.000070410000000','0.000067540000000','0.031787356607655','0.030491664043190','451.46082385535186','451.460823855351862','test','test','4.07'),('2019-07-31 19:59:59','2019-07-31 23:59:59','MDABTC','4h','0.000067390000000','0.000066150000000','0.031499424926663','0.030919824289936','467.4198683285816','467.419868328581572','test','test','1.84'),('2019-08-02 19:59:59','2019-08-02 23:59:59','MDABTC','4h','0.000067730000000','0.000066540000000','0.031370624785168','0.030819450364758','463.17178185690557','463.171781856905568','test','test','1.75'),('2019-08-04 07:59:59','2019-08-04 23:59:59','MDABTC','4h','0.000068990000000','0.000067220000000','0.031248141580633','0.030446442630093','452.93726019180554','452.937260191805535','test','test','2.56'),('2019-08-21 07:59:59','2019-08-25 15:59:59','MDABTC','4h','0.000064720000000','0.000063870000000','0.031069986258290','0.030661928651375','480.0677728413232','480.067772841323176','test','test','2.13'),('2019-08-25 19:59:59','2019-08-26 03:59:59','MDABTC','4h','0.000066610000000','0.000063330000000','0.030979306790087','0.029453828239247','465.08492403673785','465.084924036737846','test','test','4.92'),('2019-08-26 19:59:59','2019-08-28 03:59:59','MDABTC','4h','0.000072610000000','0.000063800000000','0.030640311556567','0.026922626047500','421.98473428683525','421.984734286835248','test','test','12.3'),('2019-09-10 07:59:59','2019-09-12 23:59:59','MDABTC','4h','0.000064900000000','0.000060260000000','0.029814159221219','0.027682607622044','459.38612051184714','459.386120511847139','test','test','7.14'),('2019-09-25 07:59:59','2019-10-07 23:59:59','MDABTC','4h','0.000067700000000','0.000111790000000','0.029340481088069','0.048448631917803','433.38967633779737','433.389676337797368','test','test','0.60'),('2019-10-12 11:59:59','2019-10-15 19:59:59','MDABTC','4h','0.000117860000000','0.000109120000000','0.033586736828010','0.031096086226646','284.9714646869996','284.971464686999582','test','test','7.41'),('2019-11-09 11:59:59','2019-11-12 11:59:59','MDABTC','4h','0.000083070000000','0.000082930000000','0.033033258916596','0.032977587118735','397.65569900801194','397.655699008011936','test','test','0.16'),('2019-11-23 23:59:59','2019-11-24 15:59:59','MDABTC','4h','0.000082310000000','0.000079200000000','0.033020887405960','0.031773226613437','401.1771037050148','401.177103705014815','test','test','3.77'),('2019-11-24 19:59:59','2019-11-24 23:59:59','MDABTC','4h','0.000079590000000','0.000079390000000','0.032743629452066','0.032661348689528','411.40381269086276','411.403812690862765','test','test','0.25'),('2019-11-26 03:59:59','2019-11-26 23:59:59','MDABTC','4h','0.000082700000000','0.000081270000000','0.032725344838168','0.032159477327665','395.7115458061479','395.711545806147910','test','test','1.72'),('2019-11-27 03:59:59','2019-11-27 11:59:59','MDABTC','4h','0.000081450000000','0.000080650000000','0.032599596502501','0.032279404026111','400.240595488043','400.240595488043027','test','test','1.05'),('2019-12-13 23:59:59','2019-12-14 03:59:59','MDABTC','4h','0.000073310000000','0.000073120000000','0.032528442618859','0.032444137556827','443.71085280123964','443.710852801239639','test','test','0.25');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-01  6:36:31
