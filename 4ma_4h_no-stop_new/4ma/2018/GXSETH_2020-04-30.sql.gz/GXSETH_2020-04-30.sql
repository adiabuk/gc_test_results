-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-28 19:59:59','2018-06-02 07:59:59','GXSETH','4h','0.005303000000000','0.005830000000000','1.297777777777778','1.426747962369309','244.72520795356922','244.725207953569225','test','test','0.0'),('2018-06-04 03:59:59','2018-06-10 03:59:59','GXSETH','4h','0.005906000000000','0.006498000000000','1.326437818798118','1.459396028877442','224.59157107993872','224.591571079938717','test','test','2.20'),('2018-06-10 11:59:59','2018-06-10 19:59:59','GXSETH','4h','0.006620000000000','0.006472000000000','1.355984087704634','1.325669035592808','204.83143318801123','204.831433188011232','test','test','2.23'),('2018-06-11 07:59:59','2018-06-13 23:59:59','GXSETH','4h','0.006735000000000','0.006787000000000','1.349247409457562','1.359664761393983','200.33369108501293','200.333691085012930','test','test','1.70'),('2018-07-12 11:59:59','2018-07-13 03:59:59','GXSETH','4h','0.005704000000000','0.005722000000000','1.351562376554544','1.355827475218286','236.94992576341943','236.949925763419429','test','test','2.71'),('2018-07-13 07:59:59','2018-07-24 11:59:59','GXSETH','4h','0.005777000000000','0.006489000000000','1.352510176257598','1.519203485154155','234.11981586595087','234.119815865950869','test','test','1.35'),('2018-08-28 11:59:59','2018-08-28 15:59:59','GXSETH','4h','0.005087000000000','0.005188000000000','1.389553133790166','1.417142059780496','273.1576830725705','273.157683072570478','test','test','0.0'),('2018-08-28 19:59:59','2018-08-29 19:59:59','GXSETH','4h','0.005200000000000','0.005082000000000','1.395684006232462','1.364012715321802','268.4007704293196','268.400770429319607','test','test','2.26'),('2018-08-30 03:59:59','2018-08-30 07:59:59','GXSETH','4h','0.005109000000000','0.005043000000000','1.388645941585649','1.370706886556357','271.80386408018177','271.803864080181768','test','test','1.29'),('2018-08-31 15:59:59','2018-09-01 15:59:59','GXSETH','4h','0.005146000000000','0.005081000000000','1.384659484912473','1.367169615787072','269.0749096215454','269.074909621545373','test','test','1.45'),('2018-09-01 19:59:59','2018-09-01 23:59:59','GXSETH','4h','0.005101000000000','0.005140000000000','1.380772847329050','1.391329628557404','270.6866981629191','270.686698162919072','test','test','0.0'),('2018-09-02 07:59:59','2018-09-02 11:59:59','GXSETH','4h','0.005102000000000','0.005066000000000','1.383118798713129','1.373359434394495','271.0934532953996','271.093453295399627','test','test','0.70'),('2018-09-03 15:59:59','2018-09-03 19:59:59','GXSETH','4h','0.005190000000000','0.005119000000000','1.380950051086766','1.362058441524693','266.07900791652514','266.079007916525143','test','test','1.36'),('2018-09-04 03:59:59','2018-09-05 11:59:59','GXSETH','4h','0.005100000000000','0.005129000000000','1.376751915628527','1.384580504952689','269.95135600559354','269.951356005593539','test','test','0.0'),('2018-09-05 15:59:59','2018-09-06 03:59:59','GXSETH','4h','0.005151000000000','0.005070000000000','1.378491602145008','1.356814681202716','267.61630792952974','267.616307929529739','test','test','1.57'),('2018-09-07 03:59:59','2018-09-12 23:59:59','GXSETH','4h','0.005273000000000','0.005497000000000','1.373674508602276','1.432028972840264','260.5110010624457','260.511001062445700','test','test','1.42'),('2018-09-23 07:59:59','2018-09-23 11:59:59','GXSETH','4h','0.005267000000000','0.005187000000000','1.386642167321829','1.365580581336307','263.2698248190297','263.269824819029679','test','test','1.51'),('2018-09-23 15:59:59','2018-09-29 11:59:59','GXSETH','4h','0.005219000000000','0.005916000000000','1.381961814880602','1.566523490483549','264.79436958815904','264.794369588159043','test','test','0.21'),('2018-10-04 11:59:59','2018-10-06 15:59:59','GXSETH','4h','0.006230000000000','0.005972000000000','1.422975520570146','1.364046518273662','228.4069856452882','228.406985645288188','test','test','4.14'),('2018-10-08 11:59:59','2018-10-16 03:59:59','GXSETH','4h','0.006164000000000','0.007325000000000','1.409880186726483','1.675433544414582','228.72812893031838','228.728128930318377','test','test','1.97'),('2018-11-04 03:59:59','2018-11-04 11:59:59','GXSETH','4h','0.006896000000000','0.006720000000000','1.468892043990505','1.431402919897940','213.00638688957434','213.006386889574344','test','test','2.55'),('2018-11-17 11:59:59','2018-11-17 19:59:59','GXSETH','4h','0.006270000000000','0.006221000000000','1.460561127525490','1.449146853961096','232.94435845701597','232.944358457015966','test','test','0.78'),('2018-11-18 03:59:59','2018-11-18 07:59:59','GXSETH','4h','0.006172000000000','0.006207000000000','1.458024622288958','1.466292746362210','236.23211637863872','236.232116378638722','test','test','0.0'),('2018-11-18 11:59:59','2018-11-18 15:59:59','GXSETH','4h','0.006230000000000','0.006201000000000','1.459861983194125','1.453066477975404','234.32776616278093','234.327766162780932','test','test','0.46'),('2018-11-19 07:59:59','2018-11-19 15:59:59','GXSETH','4h','0.006362000000000','0.006206000000000','1.458351870923298','1.422592221149008','229.22852419416824','229.228524194168244','test','test','2.45'),('2018-11-20 03:59:59','2018-11-20 07:59:59','GXSETH','4h','0.006286000000000','0.006252000000000','1.450405282084567','1.442560264650447','230.73580688586816','230.735806885868158','test','test','0.54'),('2018-11-20 11:59:59','2018-11-20 15:59:59','GXSETH','4h','0.006303000000000','0.006219000000000','1.448661944876985','1.429355645754398','229.8368943165136','229.836894316513593','test','test','1.33'),('2018-11-20 23:59:59','2018-11-24 23:59:59','GXSETH','4h','0.006270000000000','0.006313000000000','1.444371656183077','1.454277235324364','230.36230561133604','230.362305611336041','test','test','0.0'),('2018-12-01 23:59:59','2018-12-04 07:59:59','GXSETH','4h','0.006340000000000','0.006197000000000','1.446572895992252','1.413945147707253','228.16607192306807','228.166071923068074','test','test','2.25'),('2019-01-11 11:59:59','2019-01-15 03:59:59','GXSETH','4h','0.004139000000000','0.004097000000000','1.439322285262252','1.424716937115111','347.7463844557265','347.746384455726513','test','test','1.01'),('2019-01-16 03:59:59','2019-01-23 23:59:59','GXSETH','4h','0.004331000000000','0.004781000000000','1.436076652340665','1.585288033904576','331.58084791980264','331.580847919802636','test','test','0.87'),('2019-01-25 07:59:59','2019-01-25 15:59:59','GXSETH','4h','0.004926000000000','0.004781000000000','1.469234737132645','1.425986861191875','298.26121338462144','298.261213384621442','test','test','2.94'),('2019-01-27 11:59:59','2019-01-31 11:59:59','GXSETH','4h','0.004869000000000','0.005001000000000','1.459624098034696','1.499194930020849','299.7790301981303','299.779030198130272','test','test','0.0'),('2019-02-02 07:59:59','2019-02-02 11:59:59','GXSETH','4h','0.005137000000000','0.005054000000000','1.468417616253842','1.444691966623889','285.85120036088017','285.851200360880171','test','test','1.61'),('2019-02-04 11:59:59','2019-02-04 19:59:59','GXSETH','4h','0.005135000000000','0.005045000000000','1.463145249669408','1.437501029129925','284.93578377203653','284.935783772036530','test','test','1.75'),('2019-02-04 23:59:59','2019-02-05 11:59:59','GXSETH','4h','0.005090000000000','0.005044000000000','1.457446533993967','1.444275111486359','286.3352719045121','286.335271904512126','test','test','0.90'),('2019-02-05 15:59:59','2019-02-05 19:59:59','GXSETH','4h','0.005092000000000','0.005039000000000','1.454519551214498','1.439380207888817','285.6479872770028','285.647987277002812','test','test','1.04'),('2019-02-06 03:59:59','2019-02-06 23:59:59','GXSETH','4h','0.005146000000000','0.005050000000000','1.451155252697681','1.424083565123064','281.99674556892353','281.996745568923529','test','test','1.86'),('2019-02-07 03:59:59','2019-02-08 11:59:59','GXSETH','4h','0.005075000000000','0.005146000000000','1.445139322125543','1.465357034809467','284.7565166749839','284.756516674983914','test','test','0.0'),('2019-02-26 11:59:59','2019-03-05 15:59:59','GXSETH','4h','0.004677000000000','0.004911000000000','1.449632147166415','1.522160246896358','309.94914414505354','309.949144145053538','test','test','1.60'),('2019-03-08 03:59:59','2019-03-15 03:59:59','GXSETH','4h','0.004996000000000','0.006686000000000','1.465749502661958','1.961569490552012','293.38460821896683','293.384608218966832','test','test','0.66'),('2019-03-17 23:59:59','2019-03-23 15:59:59','GXSETH','4h','0.006793000000000','0.007965000000000','1.575931722193081','1.847828082918871','231.99348184794366','231.993481847943656','test','test','0.0'),('2019-03-28 15:59:59','2019-03-30 03:59:59','GXSETH','4h','0.008095000000000','0.007915000000000','1.636353135687701','1.599967272262897','202.14368569335412','202.143685693354115','test','test','3.10'),('2019-03-30 07:59:59','2019-03-31 07:59:59','GXSETH','4h','0.007983000000000','0.007850000000000','1.628267388259967','1.601139796798289','203.96685309532344','203.966853095323444','test','test','1.82'),('2019-03-31 11:59:59','2019-04-02 07:59:59','GXSETH','4h','0.008001000000000','0.008155000000000','1.622239034601816','1.653463232993102','202.754535008351','202.754535008351013','test','test','0.38'),('2019-04-02 15:59:59','2019-04-02 19:59:59','GXSETH','4h','0.008025000000000','0.007904000000000','1.629177745355435','1.604613196173129','203.01280315955583','203.012803159555830','test','test','1.50'),('2019-04-13 11:59:59','2019-04-17 19:59:59','GXSETH','4h','0.007938000000000','0.007997000000000','1.623718956648256','1.635787414501902','204.5501331126551','204.550133112655089','test','test','0.89'),('2019-04-22 23:59:59','2019-04-23 15:59:59','GXSETH','4h','0.007823000000000','0.007612000000000','1.626400836171289','1.582533959470261','207.8998895783317','207.899889578331710','test','test','2.69'),('2019-04-23 19:59:59','2019-04-23 23:59:59','GXSETH','4h','0.007629000000000','0.007550000000000','1.616652641348838','1.599911841943076','211.90885323749353','211.908853237493531','test','test','1.03');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 22:59:24
