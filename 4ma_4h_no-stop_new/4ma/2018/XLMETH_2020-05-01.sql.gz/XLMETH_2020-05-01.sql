-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-25 15:59:59','2018-05-27 07:59:59','XLMETH','4h','0.000490070000000','0.000472230000000','1.297777777777778','1.250534821556105','2648.147770273181','2648.147770273180868','test','test','3.64'),('2018-05-28 07:59:59','2018-05-29 03:59:59','XLMETH','4h','0.000487090000000','0.000474530000000','1.287279343061850','1.254085829442484','2642.7956703316645','2642.795670331664496','test','test','2.57'),('2018-05-29 11:59:59','2018-05-30 19:59:59','XLMETH','4h','0.000499910000000','0.000488130000000','1.279903006701991','1.249743063074239','2560.2668614390413','2560.266861439041350','test','test','2.35'),('2018-05-30 23:59:59','2018-06-03 11:59:59','XLMETH','4h','0.000492440000000','0.000491920000000','1.273200797006935','1.271856339987920','2585.494267335991','2585.494267335991026','test','test','0.89'),('2018-07-02 15:59:59','2018-07-05 15:59:59','XLMETH','4h','0.000451620000000','0.000437130000000','1.272902028780488','1.232061608965092','2818.5244869148564','2818.524486914856425','test','test','3.20'),('2018-07-11 03:59:59','2018-07-11 07:59:59','XLMETH','4h','0.000441740000000','0.000426920000000','1.263826379932622','1.221426083489915','2861.018653354058','2861.018653354058188','test','test','3.35'),('2018-07-14 07:59:59','2018-07-24 11:59:59','XLMETH','4h','0.000465390000000','0.000622740000000','1.254404091834243','1.678522538406189','2695.3825648042343','2695.382564804234335','test','test','0.78'),('2018-07-24 15:59:59','2018-07-24 23:59:59','XLMETH','4h','0.000632150000000','0.000627030000000','1.348652635516897','1.337729434545851','2133.437689657355','2133.437689657354895','test','test','0.80'),('2018-07-25 11:59:59','2018-07-29 07:59:59','XLMETH','4h','0.000649000000000','0.000670040000000','1.346225257523331','1.389868677274165','2074.3070223780146','2074.307022378014608','test','test','0.30'),('2018-08-11 11:59:59','2018-08-16 03:59:59','XLMETH','4h','0.000674180000000','0.000740710000000','1.355923795245739','1.489730212074626','2011.2192518996987','2011.219251899698747','test','test','0.76'),('2018-08-17 23:59:59','2018-08-18 03:59:59','XLMETH','4h','0.000757630000000','0.000745500000000','1.385658554541047','1.363473532476737','1828.9383400090376','1828.938340009037574','test','test','1.60'),('2018-08-18 19:59:59','2018-08-23 07:59:59','XLMETH','4h','0.000768610000000','0.000771910000000','1.380728549637867','1.386656659100150','1796.3968067522765','1796.396806752276461','test','test','1.98'),('2018-08-23 15:59:59','2018-08-25 19:59:59','XLMETH','4h','0.000777320000000','0.000774000000000','1.382045907296152','1.376143071382727','1777.962624525488','1777.962624525488081','test','test','0.86'),('2018-08-25 23:59:59','2018-08-26 03:59:59','XLMETH','4h','0.000784000000000','0.000773590000000','1.380734165982058','1.362400693191403','1761.1405178342575','1761.140517834257480','test','test','1.32'),('2018-08-27 03:59:59','2018-08-29 15:59:59','XLMETH','4h','0.000794840000000','0.000778680000000','1.376660060917468','1.348670998232618','1731.996453270429','1731.996453270428901','test','test','2.03'),('2018-09-01 07:59:59','2018-09-01 15:59:59','XLMETH','4h','0.000788310000000','0.000777700000000','1.370440269209723','1.351995277700907','1738.4534881071195','1738.453488107119483','test','test','1.34'),('2018-09-04 23:59:59','2018-09-13 19:59:59','XLMETH','4h','0.000812530000000','0.001006820000000','1.366341382207764','1.693057278419776','1681.5888425138323','1681.588842513832333','test','test','0.71'),('2018-09-18 11:59:59','2018-09-22 03:59:59','XLMETH','4h','0.001018510000000','0.000984750000000','1.438944914699323','1.391248986018947','1412.794095982683','1412.794095982683075','test','test','3.72'),('2018-09-23 03:59:59','2018-09-28 07:59:59','XLMETH','4h','0.001069350000000','0.001133000000000','1.428345819437016','1.513364018723653','1335.7140500650082','1335.714050065008223','test','test','0.0'),('2018-10-02 03:59:59','2018-10-02 15:59:59','XLMETH','4h','0.001127200000000','0.001116570000000','1.447238752611825','1.433590644077170','1283.9236627145358','1283.923662714535794','test','test','0.94'),('2018-10-17 07:59:59','2018-10-21 23:59:59','XLMETH','4h','0.001125900000000','0.001190260000000','1.444205839604124','1.526761206721027','1282.712354209187','1282.712354209186969','test','test','0.0'),('2018-10-22 07:59:59','2018-10-22 11:59:59','XLMETH','4h','0.001201600000000','0.001193340000000','1.462551476741213','1.452497652508621','1217.17000394575','1217.170003945750068','test','test','0.68'),('2018-10-23 03:59:59','2018-10-23 19:59:59','XLMETH','4h','0.001217250000000','0.001185150000000','1.460317293578415','1.421807385898097','1199.6855975176957','1199.685597517695669','test','test','2.63'),('2018-11-03 07:59:59','2018-11-04 19:59:59','XLMETH','4h','0.001189250000000','0.001161000000000','1.451759536316122','1.417273762171972','1220.7353679345151','1220.735367934515125','test','test','2.37'),('2018-11-05 03:59:59','2018-11-05 07:59:59','XLMETH','4h','0.001166090000000','0.001166100000000','1.444096030950756','1.444108415038013','1238.4087256993505','1238.408725699350498','test','test','0.0'),('2018-11-05 23:59:59','2018-11-07 11:59:59','XLMETH','4h','0.001182900000000','0.001175020000000','1.444098782970146','1.434478782623705','1220.8122267056776','1220.812226705677631','test','test','0.66'),('2018-11-08 15:59:59','2018-11-13 19:59:59','XLMETH','4h','0.001220630000000','0.001238390000000','1.441961005115381','1.462941341049161','1181.325221496589','1181.325221496588938','test','test','0.98'),('2018-11-15 07:59:59','2018-11-23 03:59:59','XLMETH','4h','0.001296640000000','0.001456140000000','1.446623301989555','1.624572784241633','1115.670735122744','1115.670735122743963','test','test','1.14'),('2018-11-30 23:59:59','2018-12-02 03:59:59','XLMETH','4h','0.001404500000000','0.001394820000000','1.486167631378905','1.475924767248077','1058.147120953297','1058.147120953296962','test','test','0.68'),('2019-01-10 07:59:59','2019-01-11 07:59:59','XLMETH','4h','0.000848910000000','0.000829890000000','1.483891439349833','1.450644551957255','1747.9961825751052','1747.996182575105195','test','test','2.71'),('2019-01-11 11:59:59','2019-01-14 15:59:59','XLMETH','4h','0.000848240000000','0.000841350000000','1.476503242151482','1.464510047609344','1740.6668421101126','1740.666842110112611','test','test','2.23'),('2019-01-14 19:59:59','2019-01-14 23:59:59','XLMETH','4h','0.000844640000000','0.000845540000000','1.473838087808785','1.475408525248437','1744.9304885025392','1744.930488502539220','test','test','0.0'),('2019-01-16 03:59:59','2019-01-19 19:59:59','XLMETH','4h','0.000875050000000','0.000857130000000','1.474187073906485','1.443997447754374','1684.688959381161','1684.688959381161112','test','test','2.04'),('2019-01-21 11:59:59','2019-01-21 19:59:59','XLMETH','4h','0.000878640000000','0.000876940000000','1.467478268094905','1.464638978902788','1670.1701130097704','1670.170113009770375','test','test','0.44'),('2019-01-22 11:59:59','2019-01-22 15:59:59','XLMETH','4h','0.000880000000000','0.000869720000000','1.466847314941101','1.449711871307471','1666.8719487967055','1666.871948796705510','test','test','1.16'),('2019-02-28 07:59:59','2019-02-28 11:59:59','XLMETH','4h','0.000618210000000','0.000612070000000','1.463039438578072','1.448508676939035','2366.5735568464956','2366.573556846495649','test','test','0.99'),('2019-02-28 15:59:59','2019-02-28 19:59:59','XLMETH','4h','0.000616370000000','0.000613330000000','1.459810380436064','1.452610446051643','2368.3994685595726','2368.399468559572597','test','test','0.49'),('2019-02-28 23:59:59','2019-03-05 15:59:59','XLMETH','4h','0.000623030000000','0.000630670000000','1.458210395017304','1.476091921457334','2340.513931941164','2340.513931941164174','test','test','0.54'),('2019-03-08 15:59:59','2019-03-15 15:59:59','XLMETH','4h','0.000641320000000','0.000783390000000','1.462184067559533','1.786098011422476','2279.9601876746906','2279.960187674690587','test','test','0.0'),('2019-03-18 15:59:59','2019-03-20 19:59:59','XLMETH','4h','0.000797620000000','0.000794460000000','1.534164943973520','1.528086910294630','1923.4283793956015','1923.428379395601496','test','test','0.54'),('2019-04-06 07:59:59','2019-04-06 11:59:59','XLMETH','4h','0.000766120000000','0.000765550000000','1.532814269822655','1.531673842560870','2000.7495820793808','2000.749582079380843','test','test','0.07'),('2019-04-07 11:59:59','2019-04-07 15:59:59','XLMETH','4h','0.000776290000000','0.000764260000000','1.532560841542258','1.508811074156676','1974.2117527499497','1974.211752749949710','test','test','1.54'),('2019-04-07 19:59:59','2019-04-07 23:59:59','XLMETH','4h','0.000768820000000','0.000758880000000','1.527283115456574','1.507537018622935','1986.5288565029184','1986.528856502918416','test','test','1.29'),('2019-05-18 23:59:59','2019-05-19 07:59:59','XLMETH','4h','0.000562270000000','0.000549070000000','1.522895093937987','1.487143203849628','2708.476521845354','2708.476521845354000','test','test','2.34'),('2019-05-19 11:59:59','2019-05-19 15:59:59','XLMETH','4h','0.000554810000000','0.000550680000000','1.514950229473907','1.503672955366145','2730.5748444943447','2730.574844494344688','test','test','0.74'),('2019-05-19 19:59:59','2019-05-19 23:59:59','XLMETH','4h','0.000550900000000','0.000549600000000','1.512444168561071','1.508875140753612','2745.406005738013','2745.406005738012936','test','test','0.23');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-01  6:22:04
