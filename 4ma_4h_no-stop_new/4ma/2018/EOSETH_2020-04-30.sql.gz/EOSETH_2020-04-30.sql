-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-01-12 19:59:59','2018-01-14 23:59:59','EOSETH','4h','0.011136000000000','0.009795000000000','1.297777777777778','1.141499042145594','116.53895274584929','116.538952745849286','test','test','12.0'),('2018-01-19 15:59:59','2018-01-24 19:59:59','EOSETH','4h','0.010424000000000','0.012945000000000','1.263049169859515','1.568512231756660','121.1674184439289','121.167418443928895','test','test','0.0'),('2018-01-24 23:59:59','2018-01-27 19:59:59','EOSETH','4h','0.013146000000000','0.013058000000000','1.330929850281102','1.322020537423599','101.24219156253632','101.242191562536320','test','test','0.66'),('2018-03-19 15:59:59','2018-03-25 23:59:59','EOSETH','4h','0.009899000000000','0.012316000000000','1.328950002979435','1.653434512243128','134.25093473880543','134.250934738805427','test','test','0.0'),('2018-03-27 15:59:59','2018-04-01 15:59:59','EOSETH','4h','0.013054000000000','0.014571000000000','1.401057671704700','1.563874010602818','107.32784370343958','107.327843703439584','test','test','0.90'),('2018-04-02 23:59:59','2018-04-03 11:59:59','EOSETH','4h','0.015099000000000','0.014720000000000','1.437239080348726','1.401162942097705','95.18769987076803','95.187699870768029','test','test','2.51'),('2018-04-04 19:59:59','2018-04-07 19:59:59','EOSETH','4h','0.015018000000000','0.015225000000000','1.429222160737388','1.448921787004044','95.16727665051194','95.167276650511937','test','test','2.12'),('2018-04-11 15:59:59','2018-04-14 11:59:59','EOSETH','4h','0.016923000000000','0.016849000000000','1.433599855463312','1.427331085782742','84.71310379148566','84.713103791485665','test','test','0.43'),('2018-04-18 03:59:59','2018-04-19 19:59:59','EOSETH','4h','0.016955000000000','0.016568000000000','1.432206795534296','1.399516495925226','84.4710584213681','84.471058421368099','test','test','2.28'),('2018-04-20 07:59:59','2018-04-23 19:59:59','EOSETH','4h','0.017295000000000','0.017955000000000','1.424942284510059','1.479319960588500','82.39041830066832','82.390418300668316','test','test','0.0'),('2018-04-24 03:59:59','2018-04-30 19:59:59','EOSETH','4h','0.019405000000000','0.026930000000000','1.437026212527490','1.994285797648302','74.05442991638702','74.054429916387022','test','test','0.0'),('2018-05-02 11:59:59','2018-05-03 03:59:59','EOSETH','4h','0.027586000000000','0.026250000000000','1.560861675887670','1.485268577976196','56.5816601133789','56.581660113378902','test','test','4.84'),('2018-05-10 23:59:59','2018-05-11 03:59:59','EOSETH','4h','0.023962000000000','0.023886000000000','1.544063209685121','1.539165922149186','64.43799389387867','64.437993893878669','test','test','0.31'),('2018-05-25 11:59:59','2018-05-29 07:59:59','EOSETH','4h','0.020457000000000','0.021338000000000','1.542974923566024','1.609424593980145','75.42527856313359','75.425278563133588','test','test','0.0'),('2018-05-29 11:59:59','2018-05-29 19:59:59','EOSETH','4h','0.021399000000000','0.021580000000000','1.557741516991384','1.570917423088652','72.79506131087359','72.795061310873592','test','test','0.42'),('2018-06-02 11:59:59','2018-06-04 15:59:59','EOSETH','4h','0.023539000000000','0.022838000000000','1.560669496124110','1.514192189663215','66.30143575020648','66.301435750206480','test','test','3.39'),('2018-06-05 23:59:59','2018-06-06 15:59:59','EOSETH','4h','0.023304000000000','0.023001000000000','1.550341205799467','1.530183576836318','66.52682826121983','66.526828261219833','test','test','1.30'),('2018-06-07 19:59:59','2018-06-08 07:59:59','EOSETH','4h','0.023764000000000','0.023240000000000','1.545861732696545','1.511775234298422','65.05056946206636','65.050569462066363','test','test','2.62'),('2018-06-08 11:59:59','2018-06-10 03:59:59','EOSETH','4h','0.023250000000000','0.023028000000000','1.538286955274740','1.523598795959859','66.16287979676301','66.162879796763008','test','test','0.95'),('2018-07-03 15:59:59','2018-07-06 03:59:59','EOSETH','4h','0.019174000000000','0.018676000000000','1.535022919871433','1.495154274096114','80.05752163718749','80.057521637187492','test','test','2.59'),('2018-07-18 03:59:59','2018-07-21 03:59:59','EOSETH','4h','0.018023000000000','0.017092000000000','1.526163220810251','1.447327402213217','84.6786451095961','84.678645109596104','test','test','5.16'),('2018-07-23 07:59:59','2018-07-23 15:59:59','EOSETH','4h','0.017855000000000','0.017369000000000','1.508644150010910','1.467579963121786','84.49421170601569','84.494211706015690','test','test','2.72'),('2018-07-23 23:59:59','2018-07-24 03:59:59','EOSETH','4h','0.017607000000000','0.017173000000000','1.499518775146660','1.462556706173317','85.16605754226501','85.166057542265008','test','test','2.46'),('2018-07-24 19:59:59','2018-07-27 03:59:59','EOSETH','4h','0.017922000000000','0.017617000000000','1.491304982041473','1.465925670607333','83.21085716111331','83.210857161113310','test','test','1.70'),('2018-08-17 19:59:59','2018-08-21 11:59:59','EOSETH','4h','0.017239000000000','0.017188000000000','1.485665135056109','1.481269931048460','86.18047073821616','86.180470738216158','test','test','1.06'),('2018-08-22 03:59:59','2018-08-22 23:59:59','EOSETH','4h','0.017841000000000','0.017455000000000','1.484688423054409','1.452566359756444','83.21778056467735','83.217780564677355','test','test','2.93'),('2018-08-23 11:59:59','2018-09-05 19:59:59','EOSETH','4h','0.017588000000000','0.022067000000000','1.477550186765972','1.853826470966836','84.00899401671437','84.008994016714368','test','test','0.01'),('2018-09-06 23:59:59','2018-09-13 15:59:59','EOSETH','4h','0.022797000000000','0.026184000000000','1.561167138810608','1.793113144826818','68.48125362155582','68.481253621555823','test','test','0.30'),('2018-09-13 19:59:59','2018-09-13 23:59:59','EOSETH','4h','0.026598000000000','0.025547000000000','1.612710695703099','1.548985643399017','60.632780498650256','60.632780498650256','test','test','3.95'),('2018-09-20 15:59:59','2018-09-21 19:59:59','EOSETH','4h','0.025140000000000','0.024698000000000','1.598549572968859','1.570444604343074','63.585901868291934','63.585901868291934','test','test','1.75'),('2018-09-21 23:59:59','2018-09-22 03:59:59','EOSETH','4h','0.024940000000000','0.024677000000000','1.592304024385351','1.575512686838705','63.84538991120093','63.845389911200932','test','test','1.05'),('2018-09-26 03:59:59','2018-09-28 07:59:59','EOSETH','4h','0.025288000000000','0.026086000000000','1.588572616041652','1.638702359303327','62.81922714495619','62.819227144956187','test','test','0.85'),('2018-09-28 19:59:59','2018-09-29 11:59:59','EOSETH','4h','0.026190000000000','0.024723000000000','1.599712558988691','1.510106666509256','61.0810446349252','61.081044634925199','test','test','5.60'),('2018-10-03 23:59:59','2018-10-06 15:59:59','EOSETH','4h','0.025460000000000','0.025446000000000','1.579800138437705','1.578931434512405','62.05028037854302','62.050280378543022','test','test','0.94'),('2018-10-08 11:59:59','2018-10-13 15:59:59','EOSETH','4h','0.025634000000000','0.026194000000000','1.579607093120972','1.614115167247045','61.62156093941532','61.621560939415318','test','test','0.0'),('2018-10-18 11:59:59','2018-10-20 07:59:59','EOSETH','4h','0.026257000000000','0.026342000000000','1.587275554037877','1.592413933216505','60.45151974855761','60.451519748557608','test','test','0.0'),('2018-10-20 11:59:59','2018-10-20 23:59:59','EOSETH','4h','0.026350000000000','0.026226000000000','1.588417416077572','1.580942510590148','60.281495866321535','60.281495866321535','test','test','0.47'),('2018-10-21 03:59:59','2018-10-24 23:59:59','EOSETH','4h','0.026496000000000','0.026489000000000','1.586756325969256','1.586337119512365','59.88663669871891','59.886636698718910','test','test','0.19'),('2018-10-25 03:59:59','2018-10-26 11:59:59','EOSETH','4h','0.026654000000000','0.026482000000000','1.586663168978836','1.576424328089500','59.52814470544143','59.528144705441427','test','test','0.64'),('2018-11-02 11:59:59','2018-11-03 23:59:59','EOSETH','4h','0.026520000000000','0.026584000000000','1.584387871003428','1.588211431476438','59.743132390777824','59.743132390777824','test','test','0.0'),('2018-11-04 03:59:59','2018-11-04 19:59:59','EOSETH','4h','0.026620000000000','0.025901000000000','1.585237551108541','1.542420654066954','59.550621754640915','59.550621754640915','test','test','2.70'),('2018-11-17 15:59:59','2018-11-18 19:59:59','EOSETH','4h','0.026219000000000','0.025790000000000','1.575722685099300','1.549940426740568','60.09850433270909','60.098504332709091','test','test','1.63'),('2018-11-18 23:59:59','2018-11-19 03:59:59','EOSETH','4h','0.025916000000000','0.026028000000000','1.569993294352915','1.576778263058252','60.58007772622761','60.580077726227607','test','test','0.0'),('2018-11-19 07:59:59','2018-11-27 11:59:59','EOSETH','4h','0.026720000000000','0.028041000000000','1.571501065176323','1.649193913495856','58.81366261887435','58.813662618874353','test','test','1.42'),('2018-12-15 23:59:59','2018-12-20 11:59:59','EOSETH','4h','0.022515000000000','0.024440000000000','1.588766142580664','1.724603354415786','70.56478536889468','70.564785368894675','test','test','1.90'),('2019-01-10 03:59:59','2019-01-10 19:59:59','EOSETH','4h','0.019393000000000','0.018863000000000','1.618952189655135','1.574707118726593','83.48126590291008','83.481265902910081','test','test','2.73'),('2019-01-10 23:59:59','2019-01-10 23:59:59','EOSETH','4h','0.018998000000000','0.018998000000000','1.609119951671015','1.609119951671015','84.69943950263261','84.699439502632615','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 21:14:27
