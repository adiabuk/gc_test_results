-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-25 07:59:59','2018-03-28 03:59:59','BQXBTC','4h','0.000331000000000','0.000335850000000','0.033333333333333','0.033821752265861','100.70493454179254','100.704934541792539','test','test','0.0'),('2018-04-12 03:59:59','2018-04-12 15:59:59','BQXBTC','4h','0.000301120000000','0.000294480000000','0.033441870873895','0.032704443859407','111.05828531447634','111.058285314476336','test','test','2.20'),('2018-04-12 23:59:59','2018-04-13 07:59:59','BQXBTC','4h','0.000294030000000','0.000299780000000','0.033277998204009','0.033928777000979','113.17892121215145','113.178921212151451','test','test','0.39'),('2018-04-13 11:59:59','2018-04-16 15:59:59','BQXBTC','4h','0.000304300000000','0.000308580000000','0.033422615714447','0.033892707056076','109.83442561434985','109.834425614349854','test','test','0.77'),('2018-04-16 19:59:59','2018-04-18 03:59:59','BQXBTC','4h','0.000312110000000','0.000310410000000','0.033527080457031','0.033344465235548','107.42071851921081','107.420718519210808','test','test','1.31'),('2018-04-18 07:59:59','2018-04-21 11:59:59','BQXBTC','4h','0.000314080000000','0.000325790000000','0.033486499296701','0.034734993014112','106.61773846377143','106.617738463771431','test','test','0.0'),('2018-04-23 07:59:59','2018-04-25 11:59:59','BQXBTC','4h','0.000345090000000','0.000352930000000','0.033763942345015','0.034531015595428','97.84097581794573','97.840975817945733','test','test','0.0'),('2018-04-25 15:59:59','2018-04-25 19:59:59','BQXBTC','4h','0.000356310000000','0.000363480000000','0.033934403067329','0.034617262571673','95.23842459467568','95.238424594675678','test','test','0.0'),('2018-04-26 07:59:59','2018-05-01 19:59:59','BQXBTC','4h','0.000373770000000','0.000384330000000','0.034086149623850','0.035049174318255','91.19552030352833','91.195520303528326','test','test','1.54'),('2018-05-08 23:59:59','2018-05-11 07:59:59','BQXBTC','4h','0.000413800000000','0.000409030000000','0.034300155111495','0.033904766663255','82.89066000844691','82.890660008446915','test','test','1.15'),('2018-06-02 19:59:59','2018-06-04 03:59:59','BQXBTC','4h','0.000320380000000','0.000313710000000','0.034212291011886','0.033500024387723','106.78660032426009','106.786600324260093','test','test','2.08'),('2018-06-09 11:59:59','2018-06-10 03:59:59','BQXBTC','4h','0.000322350000000','0.000309290000000','0.034054009539850','0.032674312426183','105.64296429300519','105.642964293005193','test','test','4.05'),('2018-06-10 11:59:59','2018-06-10 15:59:59','BQXBTC','4h','0.000304800000000','0.000304080000000','0.033747410181258','0.033667691889491','110.71984967604187','110.719849676041875','test','test','0.23'),('2018-06-29 23:59:59','2018-06-30 15:59:59','BQXBTC','4h','0.000251030000000','0.000222460000000','0.033729695005309','0.029890881372270','134.3651954161229','134.365195416122901','test','test','11.3'),('2018-06-30 19:59:59','2018-07-01 03:59:59','BQXBTC','4h','0.000234600000000','0.000222600000000','0.032876625309078','0.031194956495314','140.1390678136336','140.139067813633602','test','test','5.11'),('2018-07-01 07:59:59','2018-07-01 15:59:59','BQXBTC','4h','0.000230030000000','0.000222550000000','0.032502921128242','0.031446007464636','141.2986181291223','141.298618129122303','test','test','3.25'),('2018-07-02 03:59:59','2018-07-06 19:59:59','BQXBTC','4h','0.000234020000000','0.000269890000000','0.032268051425218','0.037214017601710','137.885870546186','137.885870546185998','test','test','0.89'),('2018-08-27 07:59:59','2018-08-29 19:59:59','BQXBTC','4h','0.000077480000000','0.000073580000000','0.033367155019994','0.031687600237108','430.65507253477614','430.655072534776139','test','test','5.03'),('2018-09-02 03:59:59','2018-09-02 07:59:59','BQXBTC','4h','0.000073710000000','0.000072350000000','0.032993920623798','0.032385160183581','447.617970747491','447.617970747490972','test','test','1.84'),('2018-09-27 03:59:59','2018-09-29 07:59:59','BQXBTC','4h','0.000053210000000','0.000050600000000','0.032858640525972','0.031246893640560','617.5275423035437','617.527542303543669','test','test','5.01'),('2018-09-29 23:59:59','2018-10-01 07:59:59','BQXBTC','4h','0.000051780000000','0.000051350000000','0.032500474551436','0.032230578760453','627.6646301938116','627.664630193811604','test','test','1.04'),('2018-10-05 15:59:59','2018-10-05 23:59:59','BQXBTC','4h','0.000052350000000','0.000050710000000','0.032440497708995','0.031424214686211','619.6847699903515','619.684769990351469','test','test','3.13'),('2018-10-06 03:59:59','2018-10-09 11:59:59','BQXBTC','4h','0.000051330000000','0.000050770000000','0.032214657037265','0.031863201593258','627.5990071549799','627.599007154979859','test','test','1.09'),('2018-10-14 03:59:59','2018-10-15 07:59:59','BQXBTC','4h','0.000055490000000','0.000054200000000','0.032136555827486','0.031389463432145','579.1413917369937','579.141391736993683','test','test','2.32'),('2018-10-15 15:59:59','2018-10-15 19:59:59','BQXBTC','4h','0.000055010000000','0.000053260000000','0.031970535295188','0.030953475910229','581.176791404977','581.176791404977052','test','test','3.18'),('2018-10-15 23:59:59','2018-10-16 03:59:59','BQXBTC','4h','0.000054710000000','0.000053920000000','0.031744522098530','0.031286138394311','580.2325369864783','580.232536986478294','test','test','1.44'),('2018-10-16 07:59:59','2018-10-18 19:59:59','BQXBTC','4h','0.000058360000000','0.000055760000000','0.031642659053148','0.030232944976072','542.1977219525056','542.197721952505617','test','test','4.45'),('2018-10-19 19:59:59','2018-10-25 07:59:59','BQXBTC','4h','0.000060980000000','0.000063130000000','0.031329389258242','0.032433983992667','513.7649927556977','513.764992755697676','test','test','2.57'),('2018-12-16 19:59:59','2018-12-16 23:59:59','BQXBTC','4h','0.000027440000000','0.000026860000000','0.031574854754781','0.030907456221334','1150.6871266319727','1150.687126631972660','test','test','2.11'),('2018-12-17 03:59:59','2018-12-17 07:59:59','BQXBTC','4h','0.000027000000000','0.000026680000000','0.031426543969571','0.031054081226228','1163.94607294707','1163.946072947069979','test','test','1.18'),('2018-12-18 03:59:59','2018-12-18 07:59:59','BQXBTC','4h','0.000027560000000','0.000027800000000','0.031343774471050','0.031616724611582','1137.292252215175','1137.292252215175040','test','test','0.0'),('2018-12-19 11:59:59','2018-12-19 15:59:59','BQXBTC','4h','0.000027700000000','0.000026990000000','0.031404430057835','0.030599478962490','1133.7339371059609','1133.733937105960877','test','test','2.56'),('2018-12-19 19:59:59','2018-12-19 23:59:59','BQXBTC','4h','0.000027220000000','0.000026860000000','0.031225552036647','0.030812576330064','1147.1547405087192','1147.154740508719215','test','test','1.32'),('2018-12-20 23:59:59','2018-12-25 03:59:59','BQXBTC','4h','0.000027500000000','0.000029190000000','0.031133779657407','0.033047091934535','1132.1374420875152','1132.137442087515183','test','test','0.0'),('2018-12-28 11:59:59','2019-01-01 23:59:59','BQXBTC','4h','0.000031440000000','0.000030720000000','0.031558960163435','0.030836235884883','1003.7837202110405','1003.783720211040531','test','test','4.61'),('2019-01-16 11:59:59','2019-01-22 11:59:59','BQXBTC','4h','0.000031040000000','0.000052030000000','0.031398354768201','0.052630682944249','1011.5449345425686','1011.544934542568626','test','test','0.0'),('2019-02-17 23:59:59','2019-02-18 15:59:59','BQXBTC','4h','0.000040540000000','0.000040050000000','0.036116649918434','0.035680114189277','890.8892431779532','890.889243177953176','test','test','1.20'),('2019-02-18 19:59:59','2019-02-18 23:59:59','BQXBTC','4h','0.000040340000000','0.000040580000000','0.036019641978622','0.036233938311663','892.9013876703411','892.901387670341137','test','test','0.0'),('2019-03-08 11:59:59','2019-03-08 23:59:59','BQXBTC','4h','0.000039030000000','0.000037500000000','0.036067263385964','0.034653404483055','924.0907862148093','924.090786214809327','test','test','3.92'),('2019-03-09 03:59:59','2019-03-09 15:59:59','BQXBTC','4h','0.000038660000000','0.000039170000000','0.035753072518651','0.036224724535840','924.8078768404265','924.807876840426502','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 21:19:28
