-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 19:59:59','2019-01-14 15:59:59','ADAETH','4h','0.000318900000000','0.000334790000000','1.297777777777778','1.362442841712832','4069.544615170203','4069.544615170203087','test','test','0.0'),('2019-01-15 23:59:59','2019-01-20 15:59:59','ADAETH','4h','0.000352520000000','0.000363170000000','1.312147791985568','1.351789156970948','3722.1938953408817','3722.193895340881681','test','test','9.77'),('2019-01-21 03:59:59','2019-01-25 11:59:59','ADAETH','4h','0.000367100000000','0.000365110000000','1.320956984204541','1.313796253072514','3598.357352777284','3598.357352777284177','test','test','1.07'),('2019-01-26 07:59:59','2019-01-26 19:59:59','ADAETH','4h','0.000370580000000','0.000366590000000','1.319365710619646','1.305160224124497','3560.272304548669','3560.272304548669126','test','test','1.47'),('2019-03-02 07:59:59','2019-03-03 03:59:59','ADAETH','4h','0.000319190000000','0.000317160000000','1.316208935842946','1.307838046592778','4123.590763629644','4123.590763629644243','test','test','0.0'),('2019-03-03 15:59:59','2019-03-04 07:59:59','ADAETH','4h','0.000319330000000','0.000318480000000','1.314348738231798','1.310850174277591','4115.9575931850995','4115.957593185099540','test','test','0.67'),('2019-03-04 11:59:59','2019-03-05 03:59:59','ADAETH','4h','0.000320580000000','0.000318400000000','1.313571279575307','1.304638765415115','4097.483559720841','4097.483559720841185','test','test','0.65'),('2019-03-09 15:59:59','2019-03-18 11:59:59','ADAETH','4h','0.000335920000000','0.000359840000000','1.311586276428598','1.404980964843018','3904.4602179941594','3904.460217994159393','test','test','5.21'),('2019-03-18 19:59:59','2019-03-19 11:59:59','ADAETH','4h','0.000361830000000','0.000360420000000','1.332340651631802','1.327148709783971','3682.228260873345','3682.228260873344880','test','test','0.54'),('2019-03-19 15:59:59','2019-04-01 11:59:59','ADAETH','4h','0.000369270000000','0.000490290000000','1.331186886776729','1.767453675407594','3604.914796156549','3604.914796156549073','test','test','2.39'),('2019-04-01 19:59:59','2019-04-06 11:59:59','ADAETH','4h','0.000507870000000','0.000541550000000','1.428135062028032','1.522843528543290','2812.009100809326','2812.009100809325901','test','test','27.8'),('2019-04-06 15:59:59','2019-04-06 19:59:59','ADAETH','4h','0.000549540000000','0.000541140000000','1.449181387920312','1.427029909122534','2637.0808092592206','2637.080809259220587','test','test','1.45'),('2019-05-29 19:59:59','2019-05-30 03:59:59','ADAETH','4h','0.000343520000000','0.000332720000000','1.444258837076361','1.398852469352721','4204.293307744415','4204.293307744414960','test','test','0.0'),('2019-05-30 07:59:59','2019-05-30 19:59:59','ADAETH','4h','0.000335800000000','0.000331130000000','1.434168533137774','1.414223425782940','4270.90093251273','4270.900932512729923','test','test','0.91'),('2019-06-01 23:59:59','2019-06-04 07:59:59','ADAETH','4h','0.000342000000000','0.000344290000000','1.429736287058923','1.439309667460575','4180.515459236615','4180.515459236615243','test','test','3.17'),('2019-06-04 11:59:59','2019-06-04 15:59:59','ADAETH','4h','0.000345030000000','0.000345270000000','1.431863704925956','1.432859697416992','4149.968712650947','4149.968712650947054','test','test','0.21'),('2019-06-08 23:59:59','2019-06-09 19:59:59','ADAETH','4h','0.000343960000000','0.000341420000000','1.432085036590631','1.421509690640694','4163.522027534105','4163.522027534105291','test','test','0.0'),('2019-06-10 07:59:59','2019-06-10 11:59:59','ADAETH','4h','0.000345530000000','0.000342800000000','1.429734959712867','1.418438758398897','4137.802679109968','4137.802679109968267','test','test','1.20'),('2019-06-10 15:59:59','2019-06-11 07:59:59','ADAETH','4h','0.000343010000000','0.000340010000000','1.427224692754207','1.414742041874458','4160.88362658292','4160.883626582920442','test','test','0.06'),('2019-06-11 11:59:59','2019-06-13 19:59:59','ADAETH','4h','0.000345430000000','0.000348810000000','1.424450770336485','1.438388886897691','4123.703124617102','4123.703124617101821','test','test','1.56'),('2019-07-17 11:59:59','2019-07-18 07:59:59','ADAETH','4h','0.000260840000000','0.000260380000000','1.427548129572309','1.425030601050597','5472.888090677461','5472.888090677461150','test','test','0.0'),('2019-07-18 11:59:59','2019-07-18 15:59:59','ADAETH','4h','0.000263410000000','0.000260690000000','1.426988678789706','1.412253440164339','5417.367141679155','5417.367141679154884','test','test','1.15'),('2019-07-19 03:59:59','2019-07-19 07:59:59','ADAETH','4h','0.000261060000000','0.000258940000000','1.423714181317403','1.412152570712971','5453.589907750718','5453.589907750718339','test','test','0.14'),('2019-07-19 11:59:59','2019-07-23 07:59:59','ADAETH','4h','0.000262740000000','0.000267970000000','1.421144934516418','1.449433691491073','5408.940148117598','5408.940148117598255','test','test','1.44'),('2019-07-24 23:59:59','2019-07-25 03:59:59','ADAETH','4h','0.000272230000000','0.000268730000000','1.427431324955230','1.409079160839066','5243.47546176112','5243.475461761119732','test','test','1.56'),('2019-07-26 11:59:59','2019-07-31 11:59:59','ADAETH','4h','0.000283050000000','0.000282960000000','1.423353066262749','1.422900489771092','5028.62768508302','5028.627685083019969','test','test','5.05'),('2019-08-14 03:59:59','2019-08-14 15:59:59','ADAETH','4h','0.000254700000000','0.000253500000000','1.423252493709047','1.416546946035506','5587.956394617382','5587.956394617382102','test','test','0.0'),('2019-08-14 19:59:59','2019-08-16 03:59:59','ADAETH','4h','0.000254300000000','0.000245360000000','1.421762372003816','1.371779848977021','5590.886244608007','5590.886244608006564','test','test','1.42'),('2019-08-17 03:59:59','2019-08-19 07:59:59','ADAETH','4h','0.000253540000000','0.000252290000000','1.410655144664528','1.403700348849940','5563.836651670459','5563.836651670459105','test','test','3.22'),('2019-08-22 03:59:59','2019-08-23 15:59:59','ADAETH','4h','0.000257100000000','0.000254460000000','1.409109634483509','1.394640364024402','5480.7842648133355','5480.784264813335540','test','test','1.87'),('2019-08-23 19:59:59','2019-08-26 11:59:59','ADAETH','4h','0.000255420000000','0.000258530000000','1.405894241048152','1.423012442792963','5504.244934022989','5504.244934022988673','test','test','0.37'),('2019-08-26 19:59:59','2019-08-27 03:59:59','ADAETH','4h','0.000266100000000','0.000263000000000','1.409698285880332','1.393275645195518','5297.6260273593825','5297.626027359382533','test','test','2.84'),('2019-08-28 19:59:59','2019-08-29 03:59:59','ADAETH','4h','0.000267440000000','0.000260630000000','1.406048810172596','1.370245667795706','5257.43647237734','5257.436472377339669','test','test','1.66'),('2019-08-30 03:59:59','2019-08-31 23:59:59','ADAETH','4h','0.000265490000000','0.000260950000000','1.398092556311064','1.374184536402019','5266.083680406284','5266.083680406283747','test','test','1.83'),('2019-09-10 15:59:59','2019-09-10 19:59:59','ADAETH','4h','0.000261780000000','0.000258150000000','1.392779662997943','1.373466536797765','5320.420440820319','5320.420440820318618','test','test','0.31'),('2019-09-10 23:59:59','2019-09-11 03:59:59','ADAETH','4h','0.000258460000000','0.000253610000000','1.388487857175681','1.362432892742879','5372.157615010761','5372.157615010761219','test','test','0.11'),('2019-10-06 15:59:59','2019-10-08 07:59:59','ADAETH','4h','0.000227500000000','0.000226540000000','1.382697865079503','1.376863183978508','6077.792813536278','6077.792813536278118','test','test','0.0'),('2019-10-08 15:59:59','2019-10-09 15:59:59','ADAETH','4h','0.000227900000000','0.000222220000000','1.381401269279282','1.346972312677675','6061.43602140975','6061.436021409749628','test','test','0.59'),('2019-10-13 23:59:59','2019-10-14 19:59:59','ADAETH','4h','0.000228200000000','0.000223940000000','1.373750390034481','1.348105444103075','6019.9403594850155','6019.940359485015506','test','test','2.62'),('2019-10-15 03:59:59','2019-10-15 07:59:59','ADAETH','4h','0.000223770000000','0.000223900000000','1.368051513160835','1.368846287691428','6113.6502353346505','6113.650235334650461','test','test','0.0'),('2019-10-20 15:59:59','2019-10-20 19:59:59','ADAETH','4h','0.000225560000000','0.000223460000000','1.368228129723189','1.355489705036105','6065.916517659109','6065.916517659108649','test','test','0.73'),('2019-10-20 23:59:59','2019-10-21 03:59:59','ADAETH','4h','0.000225150000000','0.000222700000000','1.365397368681615','1.350539613614904','6064.3898231472995','6064.389823147299467','test','test','0.75'),('2019-10-21 11:59:59','2019-10-21 15:59:59','ADAETH','4h','0.000222430000000','0.000223720000000','1.362095645333456','1.369995224448145','6123.70474006859','6123.704740068589672','test','test','0.0'),('2019-10-21 19:59:59','2019-10-23 23:59:59','ADAETH','4h','0.000224220000000','0.000224240000000','1.363851107358943','1.363972760298677','6082.646986704767','6082.646986704767187','test','test','0.67'),('2019-10-24 03:59:59','2019-10-24 07:59:59','ADAETH','4h','0.000225920000000','0.000228340000000','1.363878141345550','1.378487671719382','6036.996022244823','6036.996022244822598','test','test','0.87'),('2019-10-24 11:59:59','2019-10-25 19:59:59','ADAETH','4h','0.000231510000000','0.000228630000000','1.367124703650846','1.350117580215511','5905.2511928247','5905.251192824700411','test','test','1.48'),('2019-10-27 23:59:59','2019-10-29 19:59:59','ADAETH','4h','0.000229840000000','0.000226390000000','1.363345342887438','1.342880926628468','5931.714857672461','5931.714857672461221','test','test','0.65'),('2019-11-01 15:59:59','2019-11-01 23:59:59','ADAETH','4h','0.000230740000000','0.000230710000000','1.358797694829890','1.358621028751859','5888.8692677034305','5888.869267703430523','test','test','1.88'),('2019-11-02 11:59:59','2019-11-03 07:59:59','ADAETH','4h','0.000230940000000','0.000229870000000','1.358758435701438','1.352462984388541','5883.599357848092','5883.599357848092041','test','test','0.46'),('2019-11-03 15:59:59','2019-11-03 23:59:59','ADAETH','4h','0.000229960000000','0.000229520000000','1.357359446520795','1.354762307207570','5902.589348237931','5902.589348237930608','test','test','0.03'),('2019-11-04 23:59:59','2019-11-06 03:59:59','ADAETH','4h','0.000232600000000','0.000230970000000','1.356782304451189','1.347274328714923','5833.113948629359','5833.113948629358674','test','test','1.32'),('2019-11-06 07:59:59','2019-11-07 07:59:59','ADAETH','4h','0.000232270000000','0.000230870000000','1.354669420954241','1.346504194324302','5832.304735670732','5832.304735670732043','test','test','0.67'),('2019-11-11 23:59:59','2019-11-13 11:59:59','ADAETH','4h','0.000233490000000','0.000232430000000','1.352854926147588','1.346713223197927','5794.059386473031','5794.059386473030827','test','test','1.12'),('2019-11-15 11:59:59','2019-11-19 07:59:59','ADAETH','4h','0.000236520000000','0.000237650000000','1.351490103269885','1.357946994089668','5714.062672373945','5714.062672373945134','test','test','1.72'),('2019-11-22 15:59:59','2019-11-25 15:59:59','ADAETH','4h','0.000245800000000','0.000246510000000','1.352924967896504','1.356832928544212','5504.169926348673','5504.169926348672561','test','test','3.31'),('2019-11-25 19:59:59','2019-11-26 07:59:59','ADAETH','4h','0.000248040000000','0.000246250000000','1.353793403595995','1.344023647941920','5457.964052556018','5457.964052556018032','test','test','0.97'),('2019-11-26 15:59:59','2019-11-28 03:59:59','ADAETH','4h','0.000249250000000','0.000253170000000','1.351622346783978','1.372879556811634','5422.757660116261','5422.757660116260922','test','test','1.20'),('2019-11-28 07:59:59','2019-12-01 15:59:59','ADAETH','4h','0.000254130000000','0.000259700000000','1.356346171234568','1.386074452719543','5337.213911126464','5337.213911126464154','test','test','2.99'),('2019-12-07 11:59:59','2019-12-08 15:59:59','ADAETH','4h','0.000259510000000','0.000257990000000','1.362952456009007','1.354969381240660','5252.0228739124','5252.022873912400428','test','test','2.27'),('2019-12-08 23:59:59','2019-12-09 03:59:59','ADAETH','4h','0.000257510000000','0.000255510000000','1.361178439393819','1.350606590227621','5285.924583098982','5285.924583098982112','test','test','0.0'),('2019-12-14 07:59:59','2019-12-14 11:59:59','ADAETH','4h','0.000257710000000','0.000254320000000','1.358829139579108','1.340954665235182','5272.706296143371','5272.706296143371219','test','test','0.85'),('2019-12-14 23:59:59','2019-12-15 03:59:59','ADAETH','4h','0.000255440000000','0.000254760000000','1.354857034169347','1.351250305453268','5304.0128177628685','5304.012817762868508','test','test','0.43'),('2019-12-16 19:59:59','2019-12-16 23:59:59','ADAETH','4h','0.000256510000000','0.000256820000000','1.354055538899107','1.355691955479586','5278.763162836174','5278.763162836174160','test','test','0.68'),('2019-12-17 07:59:59','2019-12-17 11:59:59','ADAETH','4h','0.000256000000000','0.000256290000000','1.354419187028102','1.355953490013407','5290.699949328525','5290.699949328524781','test','test','0.0'),('2019-12-17 15:59:59','2019-12-18 15:59:59','ADAETH','4h','0.000257320000000','0.000257510000000','1.354760143247059','1.355760471349099','5264.88474757912','5264.884747579119903','test','test','0.40'),('2019-12-18 19:59:59','2019-12-18 23:59:59','ADAETH','4h','0.000259510000000','0.000258720000000','1.354982438380846','1.350857602627615','5221.31108003871','5221.311080038710315','test','test','1.03'),('2019-12-19 03:59:59','2019-12-19 23:59:59','ADAETH','4h','0.000263620000000','0.000257990000000','1.354065808213461','1.325147704502658','5136.430499254461','5136.430499254461211','test','test','2.13'),('2019-12-20 03:59:59','2019-12-20 07:59:59','ADAETH','4h','0.000261800000000','0.000257510000000','1.347639562944394','1.325556393635641','5147.591913462162','5147.591913462161756','test','test','1.45'),('2019-12-20 11:59:59','2019-12-21 15:59:59','ADAETH','4h','0.000259970000000','0.000258960000000','1.342732191986893','1.337515591941092','5164.950540396558','5164.950540396557699','test','test','0.94'),('2019-12-24 15:59:59','2019-12-27 11:59:59','ADAETH','4h','0.000265400000000','0.000260010000000','1.341572947532271','1.314326986013059','5054.909372766657','5054.909372766656816','test','test','2.42');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 11:33:50
