-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-03 19:59:59','EOSBTC','4h','0.000695300000000','0.000691000000000','0.033333333333333','0.033127187305240','47.940936765904404','47.940936765904404','test','test','0.0'),('2019-01-03 23:59:59','2019-01-04 15:59:59','EOSBTC','4h','0.000699700000000','0.000702500000000','0.033287523104868','0.033420730286079','47.57399328979309','47.573993289793087','test','test','1.54'),('2019-01-04 19:59:59','2019-01-05 07:59:59','EOSBTC','4h','0.000705300000000','0.000699800000000','0.033317124700693','0.033057314427258','47.23823153366354','47.238231533663537','test','test','0.39'),('2019-01-05 11:59:59','2019-01-06 03:59:59','EOSBTC','4h','0.000707900000000','0.000698200000000','0.033259389084374','0.032803652293700','46.98317429633281','46.983174296332813','test','test','1.14'),('2019-01-06 15:59:59','2019-01-07 03:59:59','EOSBTC','4h','0.000715100000000','0.000694000000000','0.033158114242002','0.032179738895189','46.36849984897496','46.368499848974963','test','test','2.36'),('2019-01-09 23:59:59','2019-01-10 11:59:59','EOSBTC','4h','0.000721200000000','0.000677800000000','0.032940697498266','0.030958409268337','45.67484400757872','45.674844007578720','test','test','3.77'),('2019-01-18 07:59:59','2019-01-18 11:59:59','EOSBTC','4h','0.000686700000000','0.000676900000000','0.032500189002726','0.032036373869150','47.32807485470511','47.328074854705108','test','test','1.29'),('2019-01-18 23:59:59','2019-01-19 07:59:59','EOSBTC','4h','0.000675700000000','0.000672400000000','0.032397118973042','0.032238897139964','47.94601002374197','47.946010023741970','test','test','0.0'),('2019-01-23 11:59:59','2019-01-26 07:59:59','EOSBTC','4h','0.000682600000000','0.000676200000000','0.032361958565692','0.032058535572987','47.40984261015496','47.409842610154961','test','test','1.49'),('2019-01-26 11:59:59','2019-01-26 19:59:59','EOSBTC','4h','0.000678100000000','0.000677800000000','0.032294531233980','0.032280243725692','47.625027627163476','47.625027627163476','test','test','0.28'),('2019-02-01 15:59:59','2019-02-02 23:59:59','EOSBTC','4h','0.000672400000000','0.000695900000000','0.032291356232138','0.033419920883321','48.024027709901524','48.024027709901524','test','test','0.0'),('2019-02-03 23:59:59','2019-02-06 03:59:59','EOSBTC','4h','0.000685600000000','0.000679200000000','0.032542148376845','0.032238371029103','47.46521058466323','47.465210584663232','test','test','2.21'),('2019-02-07 03:59:59','2019-02-14 11:59:59','EOSBTC','4h','0.000693000000000','0.000761100000000','0.032474642299569','0.035665873382687','46.86095569923393','46.860955699233926','test','test','2.32'),('2019-02-16 15:59:59','2019-02-24 19:59:59','EOSBTC','4h','0.000781100000000','0.000941900000000','0.033183804762484','0.040015139810247','42.483426913947284','42.483426913947284','test','test','2.56'),('2019-03-06 07:59:59','2019-03-08 23:59:59','EOSBTC','4h','0.000971300000000','0.000928400000000','0.034701879217543','0.033169180135454','35.727251330734745','35.727251330734745','test','test','3.02'),('2019-03-16 23:59:59','2019-03-18 03:59:59','EOSBTC','4h','0.000947900000000','0.000935700000000','0.034361279421523','0.033919030651671','36.249899168185344','36.249899168185344','test','test','2.05'),('2019-03-26 23:59:59','2019-03-30 19:59:59','EOSBTC','4h','0.000948800000000','0.001013300000000','0.034263001917111','0.036592221587910','36.11193288059795','36.111932880597948','test','test','1.38'),('2019-04-03 11:59:59','2019-04-03 23:59:59','EOSBTC','4h','0.001047700000000','0.001056400000000','0.034780606288400','0.035069421096751','33.1971044081321','33.197104408132098','test','test','3.28'),('2019-04-04 07:59:59','2019-04-04 15:59:59','EOSBTC','4h','0.001040100000000','0.001033200000000','0.034844787356922','0.034613627821529','33.501381941084944','33.501381941084944','test','test','0.0'),('2019-04-04 23:59:59','2019-04-06 23:59:59','EOSBTC','4h','0.001034300000000','0.001056700000000','0.034793418571280','0.035546945184445','33.6395809448705','33.639580944870502','test','test','0.10'),('2019-04-07 07:59:59','2019-04-07 19:59:59','EOSBTC','4h','0.001057600000000','0.001048800000000','0.034960868929761','0.034669969112645','33.05679739954678','33.056797399546781','test','test','1.07'),('2019-04-09 11:59:59','2019-04-10 23:59:59','EOSBTC','4h','0.001072600000000','0.001100600000000','0.034896224525957','0.035807183212072','32.534238789816435','32.534238789816435','test','test','2.21'),('2019-04-11 07:59:59','2019-04-11 11:59:59','EOSBTC','4h','0.001082300000000','0.001049000000000','0.035098659789538','0.034018750918623','32.4296958232821','32.429695823282103','test','test','2.39'),('2019-04-15 15:59:59','2019-04-15 19:59:59','EOSBTC','4h','0.001068400000000','0.001052600000000','0.034858680040446','0.034343173540409','32.62699367319917','32.626993673199173','test','test','1.81'),('2019-04-15 23:59:59','2019-04-16 03:59:59','EOSBTC','4h','0.001059900000000','0.001059000000000','0.034744123040438','0.034714620530073','32.780567072778354','32.780567072778354','test','test','0.68'),('2019-04-16 11:59:59','2019-04-16 15:59:59','EOSBTC','4h','0.001065000000000','0.001057700000000','0.034737566927023','0.034499459660763','32.61743373429421','32.617433734294210','test','test','0.56'),('2019-04-16 23:59:59','2019-04-17 03:59:59','EOSBTC','4h','0.001060900000000','0.001050500000000','0.034684654201188','0.034344640624327','32.693613159758485','32.693613159758485','test','test','0.30'),('2019-05-17 07:59:59','2019-05-19 03:59:59','EOSBTC','4h','0.000818100000000','0.000790200000000','0.034609095628552','0.033428807438799','42.30423619184941','42.304236191849412','test','test','0.0'),('2019-05-25 23:59:59','2019-05-26 03:59:59','EOSBTC','4h','0.000792200000000','0.000793200000000','0.034346809364162','0.034390165599158','43.35623499641813','43.356234996418131','test','test','0.25'),('2019-05-26 07:59:59','2019-05-26 11:59:59','EOSBTC','4h','0.000794100000000','0.000790700000000','0.034356444083050','0.034209344335056','43.264631763065665','43.264631763065665','test','test','0.11'),('2019-05-26 15:59:59','2019-05-26 19:59:59','EOSBTC','4h','0.000792100000000','0.000779000000000','0.034323755250163','0.033756098144018','43.33260352248818','43.332603522488178','test','test','0.17'),('2019-05-27 03:59:59','2019-05-30 23:59:59','EOSBTC','4h','0.000798400000000','0.000882500000000','0.034197609226575','0.037799837352771','42.83267688699287','42.832676886992871','test','test','2.42'),('2019-05-31 03:59:59','2019-05-31 07:59:59','EOSBTC','4h','0.000889500000000','0.000892000000000','0.034998104365730','0.035096468908635','39.34581716214702','39.345817162147021','test','test','0.78'),('2019-05-31 11:59:59','2019-06-01 23:59:59','EOSBTC','4h','0.000924500000000','0.000902400000000','0.035019963153042','0.034182817468150','37.87989524396106','37.879895243961059','test','test','3.51'),('2019-07-24 11:59:59','2019-07-27 23:59:59','EOSBTC','4h','0.000436400000000','0.000451100000000','0.034833930778622','0.036007301040872','79.82110627548478','79.821106275484780','test','test','0.0'),('2019-08-24 11:59:59','2019-08-25 15:59:59','EOSBTC','4h','0.000360700000000','0.000356100000000','0.035094679725788','0.034647117966047','97.29603472633276','97.296034726332763','test','test','0.0'),('2019-09-08 15:59:59','2019-09-12 15:59:59','EOSBTC','4h','0.000361700000000','0.000362800000000','0.034995221556957','0.035101648827382','96.75206402255154','96.752064022551536','test','test','1.54'),('2019-09-14 15:59:59','2019-09-19 07:59:59','EOSBTC','4h','0.000380000000000','0.000392000000000','0.035018872061496','0.036124731179227','92.15492647762046','92.154926477620464','test','test','4.52'),('2019-09-21 11:59:59','2019-09-22 11:59:59','EOSBTC','4h','0.000401400000000','0.000388700000000','0.035264618532103','0.034148872006548','87.85405713030062','87.854057130300617','test','test','2.98'),('2019-10-04 11:59:59','2019-10-06 19:59:59','EOSBTC','4h','0.000364400000000','0.000369100000000','0.035016674859757','0.035468316933964','96.09405834181423','96.094058341814232','test','test','0.0'),('2019-10-06 23:59:59','2019-10-09 23:59:59','EOSBTC','4h','0.000369900000000','0.000377800000000','0.035117039765136','0.035867038722002','94.93657681842782','94.936576818427824','test','test','0.21'),('2019-10-14 03:59:59','2019-10-15 11:59:59','EOSBTC','4h','0.000376900000000','0.000374700000000','0.035283706199996','0.035077751958447','93.61556434066213','93.615564340662132','test','test','0.0'),('2019-10-25 07:59:59','2019-10-26 03:59:59','EOSBTC','4h','0.000368200000000','0.000344500000000','0.035237938590762','0.032969771440841','95.70325527094634','95.703255270946343','test','test','0.0'),('2019-11-02 03:59:59','2019-11-02 15:59:59','EOSBTC','4h','0.000364200000000','0.000358800000000','0.034733901446336','0.034218901260147','95.37040484990543','95.370404849905427','test','test','5.40'),('2019-11-02 23:59:59','2019-11-03 03:59:59','EOSBTC','4h','0.000357500000000','0.000356500000000','0.034619456960516','0.034522619318668','96.83764184759657','96.837641847596572','test','test','0.0'),('2019-11-04 15:59:59','2019-11-07 23:59:59','EOSBTC','4h','0.000370800000000','0.000376400000000','0.034597937484550','0.035120452182267','93.30619602089955','93.306196020899549','test','test','3.85'),('2019-11-08 03:59:59','2019-11-13 01:59:59','EOSBTC','4h','0.000381900000000','0.000392700000000','0.034714051861820','0.035695753249900','90.89827667405082','90.898276674050820','test','test','6.04'),('2019-11-15 07:59:59','2019-11-15 15:59:59','EOSBTC','4h','0.000398900000000','0.000391800000000','0.034932207725838','0.034310451208281','87.57134050097213','87.571340500972127','test','test','6.06'),('2019-11-16 15:59:59','2019-11-18 19:59:59','EOSBTC','4h','0.000396000000000','0.000385700000000','0.034794039610825','0.033889043125998','87.8637363909725','87.863736390972505','test','test','4.59'),('2019-12-02 03:59:59','2019-12-02 15:59:59','EOSBTC','4h','0.000375100000000','0.000368400000000','0.034592929280864','0.033975033716530','92.22321855735419','92.223218557354187','test','test','0.0'),('2019-12-02 23:59:59','2019-12-03 03:59:59','EOSBTC','4h','0.000366500000000','0.000367300000000','0.034455619155456','0.034530829238196','94.01260342552796','94.012603425527956','test','test','0.0'),('2019-12-03 07:59:59','2019-12-03 11:59:59','EOSBTC','4h','0.000368500000000','0.000367100000000','0.034472332507176','0.034341365707963','93.54771372367978','93.547713723679777','test','test','0.32'),('2019-12-03 15:59:59','2019-12-04 03:59:59','EOSBTC','4h','0.000369200000000','0.000363300000000','0.034443228774018','0.033892808812570','93.29151888953834','93.291518889538338','test','test','0.56'),('2019-12-27 03:59:59','2019-12-31 19:59:59','EOSBTC','4h','0.000352900000000','0.000358700000000','0.034320913227029','0.034884986042888','97.25393376885549','97.253933768855489','test','test','0.0'),('2020-01-01 11:59:59','2020-01-01 15:59:59','EOSBTC','4h','0.000363800000000','0.000363100000000','0.034446262741664','0.034379983511540','94.68461446306884','94.684614463068840','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 12:24:05
