-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-12 03:59:59','2019-01-14 15:59:59','RCNETH','4h','0.000086100000000','0.000084480000000','1.297777777777778','1.273359659310879','15072.912633888242','15072.912633888241544','test','test','1.88'),('2019-01-14 19:59:59','2019-01-22 19:59:59','RCNETH','4h','0.000085540000000','0.000104760000000','1.292351529229578','1.582730257214059','15108.154421669138','15108.154421669138173','test','test','0.0'),('2019-01-29 03:59:59','2019-01-31 03:59:59','RCNETH','4h','0.000104870000000','0.000103180000000','1.356880135448352','1.335013753938790','12938.687283764199','12938.687283764198583','test','test','1.93'),('2019-02-08 07:59:59','2019-02-08 11:59:59','RCNETH','4h','0.000101090000000','0.000097830000000','1.352020939557338','1.308420303856904','13374.428128967633','13374.428128967632802','test','test','3.22'),('2019-02-22 07:59:59','2019-02-24 11:59:59','RCNETH','4h','0.000118400000000','0.000102000000000','1.342331909401686','1.156400800329155','11337.262748325049','11337.262748325048960','test','test','13.8'),('2019-02-24 23:59:59','2019-03-03 19:59:59','RCNETH','4h','0.000111500000000','0.000147810000000','1.301013885163346','1.724689348573939','11668.285965590545','11668.285965590544947','test','test','2.34'),('2019-03-04 19:59:59','2019-03-06 03:59:59','RCNETH','4h','0.000161530000000','0.000152410000000','1.395163988143477','1.316392889450550','8637.181874224461','8637.181874224461353','test','test','5.99'),('2019-03-08 11:59:59','2019-03-11 07:59:59','RCNETH','4h','0.000172190000000','0.000163420000000','1.377659299545049','1.307492204725315','8000.808987426967','8000.808987426967178','test','test','5.09'),('2019-03-12 19:59:59','2019-03-13 03:59:59','RCNETH','4h','0.000179150000000','0.000169370000000','1.362066611807331','1.287709863476459','7602.939502134137','7602.939502134137001','test','test','5.45'),('2019-03-13 11:59:59','2019-03-13 15:59:59','RCNETH','4h','0.000170680000000','0.000168850000000','1.345542889956026','1.331116223160739','7883.42447829872','7883.424478298719805','test','test','1.07'),('2019-03-14 23:59:59','2019-03-16 19:59:59','RCNETH','4h','0.000179620000000','0.000172420000000','1.342336964001517','1.288529892735450','7473.2043425092825','7473.204342509282469','test','test','4.00'),('2019-03-17 11:59:59','2019-03-17 15:59:59','RCNETH','4h','0.000175350000000','0.000172920000000','1.330379837053502','1.311943435547713','7586.996504439706','7586.996504439705859','test','test','1.38'),('2019-03-17 23:59:59','2019-03-20 19:59:59','RCNETH','4h','0.000174540000000','0.000176620000000','1.326282858941105','1.342088223594466','7598.733006423199','7598.733006423199186','test','test','0.30'),('2019-03-27 23:59:59','2019-04-02 07:59:59','RCNETH','4h','0.000179210000000','0.000208630000000','1.329795162197408','1.548100913393478','7420.317851667918','7420.317851667918148','test','test','0.0'),('2019-04-14 03:59:59','2019-04-14 23:59:59','RCNETH','4h','0.000191200000000','0.000184500000000','1.378307551352090','1.330009117282744','7208.721502887498','7208.721502887497991','test','test','3.50'),('2019-04-15 07:59:59','2019-04-15 23:59:59','RCNETH','4h','0.000185420000000','0.000185460000000','1.367574566003346','1.367869588021684','7375.550458436771','7375.550458436770896','test','test','0.06'),('2019-04-16 03:59:59','2019-04-17 23:59:59','RCNETH','4h','0.000187160000000','0.000187050000000','1.367640126451866','1.366836320008664','7307.331301837282','7307.331301837281899','test','test','0.30'),('2019-04-20 11:59:59','2019-04-20 23:59:59','RCNETH','4h','0.000193870000000','0.000185540000000','1.367461502797821','1.308705871094588','7053.497203269308','7053.497203269307647','test','test','4.29'),('2019-04-21 03:59:59','2019-04-21 11:59:59','RCNETH','4h','0.000187820000000','0.000182640000000','1.354404695752658','1.317050759409357','7211.184622258854','7211.184622258853778','test','test','2.75'),('2019-05-02 15:59:59','2019-05-04 11:59:59','RCNETH','4h','0.000206320000000','0.000166980000000','1.346103821009702','1.089435905545755','6524.3496559213945','6524.349655921394515','test','test','19.0'),('2019-06-02 15:59:59','2019-06-03 07:59:59','RCNETH','4h','0.000129610000000','0.000127150000000','1.289066506462158','1.264600002288893','9945.733403766362','9945.733403766362244','test','test','1.89'),('2019-06-03 11:59:59','2019-06-04 03:59:59','RCNETH','4h','0.000128230000000','0.000127000000000','1.283629505534766','1.271316752732709','10010.368131753614','10010.368131753613852','test','test','1.73'),('2019-06-08 07:59:59','2019-06-12 15:59:59','RCNETH','4h','0.000128340000000','0.000128200000000','1.280893338245420','1.279496072643469','9980.468585362474','9980.468585362474187','test','test','1.03'),('2019-06-12 19:59:59','2019-06-12 23:59:59','RCNETH','4h','0.000129360000000','0.000123680000000','1.280582834778320','1.224354398619222','9899.372563221395','9899.372563221395467','test','test','4.39'),('2019-06-21 11:59:59','2019-06-21 23:59:59','RCNETH','4h','0.000131100000000','0.000120310000000','1.268087626742965','1.163719468905005','9672.674498420783','9672.674498420783493','test','test','8.23'),('2019-07-22 19:59:59','2019-07-23 19:59:59','RCNETH','4h','0.000086890000000','0.000083890000000','1.244894702778974','1.201912954495663','14327.24942777044','14327.249427770440889','test','test','3.63'),('2019-07-24 03:59:59','2019-07-24 07:59:59','RCNETH','4h','0.000083110000000','0.000085720000000','1.235343203160460','1.274138122667725','14863.953834201182','14863.953834201181962','test','test','0.0'),('2019-07-24 11:59:59','2019-07-24 23:59:59','RCNETH','4h','0.000086570000000','0.000084160000000','1.243964296384297','1.209333893770387','14369.46166552266','14369.461665522660041','test','test','3.92'),('2019-07-25 11:59:59','2019-07-29 03:59:59','RCNETH','4h','0.000084900000000','0.000091320000000','1.236268651358983','1.329753277292136','14561.468213886728','14561.468213886728336','test','test','0.28'),('2019-08-21 19:59:59','2019-08-27 15:59:59','RCNETH','4h','0.000080670000000','0.000087040000000','1.257043012677462','1.356303753854547','15582.53393674801','15582.533936748010092','test','test','3.57'),('2019-08-31 07:59:59','2019-09-01 07:59:59','RCNETH','4h','0.000088230000000','0.000087110000000','1.279100955161259','1.262863926148671','14497.347332667558','14497.347332667557566','test','test','1.30'),('2019-09-01 15:59:59','2019-09-01 19:59:59','RCNETH','4h','0.000087110000000','0.000086670000000','1.275492726491795','1.269050104523521','14642.322655169264','14642.322655169264181','test','test','0.50'),('2019-09-19 03:59:59','2019-09-28 03:59:59','RCNETH','4h','0.000097280000000','0.000228680000000','1.274061032721067','2.994986399698331','13096.844497543863','13096.844497543863326','test','test','6.52'),('2019-10-01 23:59:59','2019-10-06 07:59:59','RCNETH','4h','0.000242160000000','0.000217940000000','1.656488892049348','1.490812640953233','6840.472795050164','6840.472795050163768','test','test','10.6'),('2019-10-08 15:59:59','2019-10-09 15:59:59','RCNETH','4h','0.000227850000000','0.000210870000000','1.619671947361322','1.498969600790353','7108.5009759110035','7108.500975911003479','test','test','7.45'),('2019-10-21 19:59:59','2019-10-24 15:59:59','RCNETH','4h','0.000227460000000','0.000245000000000','1.592849203678885','1.715677723121985','7002.766216824429','7002.766216824428739','test','test','0.0'),('2019-11-02 03:59:59','2019-11-04 15:59:59','RCNETH','4h','0.000231270000000','0.000226800000000','1.620144430221796','1.588830184521569','7005.4240940104455','7005.424094010445515','test','test','1.93'),('2019-11-06 19:59:59','2019-11-09 23:59:59','RCNETH','4h','0.000256040000000','0.000245310000000','1.613185708955079','1.545581105545112','6300.522219009056','6300.522219009056244','test','test','4.19'),('2019-11-10 23:59:59','2019-11-14 11:59:59','RCNETH','4h','0.000256440000000','0.000251420000000','1.598162463752864','1.566877268120204','6232.110683796849','6232.110683796849116','test','test','2.09'),('2019-11-14 15:59:59','2019-11-15 19:59:59','RCNETH','4h','0.000258120000000','0.000255130000000','1.591210198056717','1.572778001821673','6164.614125432811','6164.614125432811306','test','test','1.15'),('2019-11-16 19:59:59','2019-11-17 11:59:59','RCNETH','4h','0.000269080000000','0.000255350000000','1.587114154448930','1.506130516346567','5898.2984779579665','5898.298477957966497','test','test','5.10'),('2019-11-20 11:59:59','2019-11-20 23:59:59','RCNETH','4h','0.000262860000000','0.000261420000000','1.569117790426182','1.560521847269316','5969.404970045584','5969.404970045584378','test','test','0.54'),('2019-11-21 03:59:59','2019-11-21 11:59:59','RCNETH','4h','0.000261580000000','0.000254040000000','1.567207580835768','1.522033082940280','5991.312718234451','5991.312718234450585','test','test','2.88'),('2019-11-21 15:59:59','2019-11-21 19:59:59','RCNETH','4h','0.000254750000000','0.000257850000000','1.557168803525659','1.576117668259436','6112.53701089562','6112.537010895620369','test','test','0.0'),('2019-11-21 23:59:59','2019-11-29 07:59:59','RCNETH','4h','0.000269610000000','0.000312980000000','1.561379662355387','1.812546295478614','5791.25278125955','5791.252781259549920','test','test','1.19'),('2019-11-29 11:59:59','2019-11-30 07:59:59','RCNETH','4h','0.000317300000000','0.000311600000000','1.617194469716105','1.588143072056534','5096.736431503639','5096.736431503639324','test','test','2.46'),('2019-12-01 07:59:59','2019-12-03 15:59:59','RCNETH','4h','0.000372200000000','0.000331020000000','1.610738603569533','1.432527384614688','4327.615807548451','4327.615807548450903','test','test','11.0'),('2019-12-07 03:59:59','2019-12-08 03:59:59','RCNETH','4h','0.000337340000000','0.000324160000000','1.571136110468456','1.509751234865283','4657.426070043447','4657.426070043446998','test','test','3.90'),('2019-12-09 11:59:59','2019-12-09 19:59:59','RCNETH','4h','0.000347170000000','0.000334530000000','1.557495027001085','1.500788695401887','4486.260411328989','4486.260411328988994','test','test','3.64'),('2019-12-18 11:59:59','2019-12-18 19:59:59','RCNETH','4h','0.000319230000000','0.000312030000000','1.544893619979041','1.510049670275538','4839.437458819788','4839.437458819787935','test','test','2.25'),('2019-12-18 23:59:59','2019-12-25 23:59:59','RCNETH','4h','0.000319070000000','0.000358800000000','1.537150520044929','1.728553629586362','4817.596515012156','4817.596515012155578','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-01  2:13:42
