-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 23:59:59','2019-01-07 11:59:59','OAXBTC','4h','0.000024540000000','0.000024190000000','0.033333333333333','0.032857919043738','1358.3265417006248','1358.326541700624830','test','test','0.0'),('2019-01-15 15:59:59','2019-01-22 23:59:59','OAXBTC','4h','0.000025410000000','0.000047690000000','0.033227685713423','0.062362390069781','1307.6617754200447','1307.661775420044705','test','test','4.80'),('2019-02-13 15:59:59','2019-02-15 15:59:59','OAXBTC','4h','0.000036040000000','0.000036110000000','0.039702064459281','0.039779177237088','1101.611111522771','1101.611111522770898','test','test','0.0'),('2019-03-03 15:59:59','2019-03-04 03:59:59','OAXBTC','4h','0.000033980000000','0.000033010000000','0.039719200632127','0.038585368242099','1168.899371163233','1168.899371163232900','test','test','0.0'),('2019-03-05 23:59:59','2019-03-06 15:59:59','OAXBTC','4h','0.000033400000000','0.000033750000000','0.039467237878787','0.039880816718834','1181.6538287062008','1181.653828706200784','test','test','1.16'),('2019-03-06 19:59:59','2019-03-11 11:59:59','OAXBTC','4h','0.000033860000000','0.000033840000000','0.039559144287686','0.039535777988638','1168.314952382943','1168.314952382942920','test','test','1.18'),('2019-03-12 19:59:59','2019-03-16 19:59:59','OAXBTC','4h','0.000037000000000','0.000038090000000','0.039553951776787','0.040719189815617','1069.025723696943','1069.025723696943032','test','test','8.78'),('2019-03-18 11:59:59','2019-03-19 19:59:59','OAXBTC','4h','0.000040500000000','0.000039730000000','0.039812893563194','0.039055957068289','983.0344089677421','983.034408967742138','test','test','11.4'),('2019-03-19 23:59:59','2019-03-20 23:59:59','OAXBTC','4h','0.000039810000000','0.000038660000000','0.039644685453215','0.038499460929950','995.8474115351587','995.847411535158699','test','test','2.48'),('2019-03-26 15:59:59','2019-03-27 15:59:59','OAXBTC','4h','0.000088340000000','0.000068150000000','0.039390191114711','0.030387610645999','445.8930395597842','445.893039559784199','test','test','56.2'),('2019-03-27 19:59:59','2019-03-28 23:59:59','OAXBTC','4h','0.000068490000000','0.000060780000000','0.037389617677220','0.033180624360073','545.9135301097938','545.913530109793783','test','test','41.9'),('2019-03-29 03:59:59','2019-03-29 07:59:59','OAXBTC','4h','0.000068190000000','0.000062110000000','0.036454285828965','0.033203925690527','534.5987069799809','534.598706979980875','test','test','30.0'),('2019-04-12 11:59:59','2019-04-12 19:59:59','OAXBTC','4h','0.000057250000000','0.000049230000000','0.035731983575979','0.030726385178086','624.1394511087975','624.139451108797516','test','test','0.0'),('2019-04-13 07:59:59','2019-04-13 11:59:59','OAXBTC','4h','0.000048970000000','0.000048710000000','0.034619628376447','0.034435819853313','706.955858208023','706.955858208022960','test','test','0.0'),('2019-05-21 11:59:59','2019-05-21 23:59:59','OAXBTC','4h','0.000027980000000','0.000026960000000','0.034578782037973','0.033318226009426','1235.839243673076','1235.839243673075998','test','test','0.0'),('2019-05-22 03:59:59','2019-05-24 15:59:59','OAXBTC','4h','0.000027460000000','0.000027620000000','0.034298658476073','0.034498504993049','1249.0407311024521','1249.040731102452128','test','test','1.82'),('2019-06-08 11:59:59','2019-06-09 19:59:59','OAXBTC','4h','0.000027410000000','0.000025540000000','0.034343068813179','0.032000072144786','1252.9393948624265','1252.939394862426525','test','test','0.0'),('2019-06-10 19:59:59','2019-06-11 07:59:59','OAXBTC','4h','0.000026340000000','0.000026020000000','0.033822402886870','0.033411500497963','1284.0699653329368','1284.069965332936818','test','test','3.03'),('2019-06-11 11:59:59','2019-06-13 07:59:59','OAXBTC','4h','0.000027690000000','0.000026450000000','0.033731091244890','0.032220562059492','1218.1686979014164','1218.168697901416408','test','test','6.03'),('2019-07-27 11:59:59','2019-07-30 15:59:59','OAXBTC','4h','0.000010400000000','0.000010840000000','0.033395418092580','0.034808301165728','3211.0978935172643','3211.097893517264311','test','test','0.0'),('2019-08-22 19:59:59','2019-08-23 07:59:59','OAXBTC','4h','0.000007690000000','0.000007470000000','0.033709392108835','0.032745014181144','4383.536034958994','4383.536034958993696','test','test','0.0'),('2019-08-23 11:59:59','2019-08-23 15:59:59','OAXBTC','4h','0.000007550000000','0.000007380000000','0.033495085902681','0.032740891915468','4436.43521889816','4436.435218898160201','test','test','1.72'),('2019-08-24 07:59:59','2019-08-26 03:59:59','OAXBTC','4h','0.000007670000000','0.000007750000000','0.033327487238856','0.033675101186589','4345.174346656584','4345.174346656584021','test','test','3.78'),('2019-08-26 07:59:59','2019-08-29 07:59:59','OAXBTC','4h','0.000008200000000','0.000007930000000','0.033404734782797','0.032304822783851','4073.748144243496','4073.748144243495972','test','test','5.48'),('2019-09-15 19:59:59','2019-09-16 07:59:59','OAXBTC','4h','0.000007340000000','0.000007020000000','0.033160309894142','0.031714628808839','4517.75339157248','4517.753391572479813','test','test','0.0'),('2019-09-16 11:59:59','2019-09-16 15:59:59','OAXBTC','4h','0.000007030000000','0.000007100000000','0.032839047430741','0.033166036523223','4671.272749749834','4671.272749749833565','test','test','0.14'),('2019-09-16 19:59:59','2019-09-16 23:59:59','OAXBTC','4h','0.000007120000000','0.000007150000000','0.032911711673515','0.033050384615960','4622.431414819538','4622.431414819538077','test','test','0.28'),('2019-09-17 03:59:59','2019-09-23 03:59:59','OAXBTC','4h','0.000007250000000','0.000007730000000','0.032942527882947','0.035123550418646','4543.796949372046','4543.796949372045674','test','test','1.37'),('2019-09-28 19:59:59','2019-09-29 15:59:59','OAXBTC','4h','0.000007690000000','0.000007460000000','0.033427199557547','0.032427426358817','4346.839994479469','4346.839994479469169','test','test','0.0'),('2019-09-29 19:59:59','2019-09-29 23:59:59','OAXBTC','4h','0.000007490000000','0.000007530000000','0.033205027735607','0.033382357656758','4433.248028785995','4433.248028785995302','test','test','0.40'),('2019-09-30 03:59:59','2019-09-30 07:59:59','OAXBTC','4h','0.000007550000000','0.000007610000000','0.033244434384752','0.033508628565293','4403.236342351229','4403.236342351228814','test','test','0.26'),('2019-09-30 11:59:59','2019-10-09 15:59:59','OAXBTC','4h','0.000007720000000','0.000008690000000','0.033303144202650','0.037487606621895','4313.878782726655','4313.878782726655118','test','test','1.42'),('2019-10-17 15:59:59','2019-10-18 03:59:59','OAXBTC','4h','0.000009260000000','0.000008740000000','0.034233024740260','0.032310651860677','3696.870922274274','3696.870922274274108','test','test','16.5'),('2019-10-31 19:59:59','2019-11-01 11:59:59','OAXBTC','4h','0.000008200000000','0.000007990000000','0.033805830767019','0.032940071686400','4122.6622886608675','4122.662288660867489','test','test','3.29'),('2019-11-01 15:59:59','2019-11-02 15:59:59','OAXBTC','4h','0.000008040000000','0.000008190000000','0.033613439860215','0.034240556275518','4180.776102016777','4180.776102016777259','test','test','0.62'),('2019-11-02 19:59:59','2019-11-04 07:59:59','OAXBTC','4h','0.000008470000000','0.000008270000000','0.033752799063616','0.032955802627639','3984.982179883773','3984.982179883772915','test','test','3.30'),('2019-11-04 11:59:59','2019-11-04 15:59:59','OAXBTC','4h','0.000008300000000','0.000008190000000','0.033575688744510','0.033130709737053','4045.2637041577777','4045.263704157777738','test','test','0.36'),('2019-11-14 03:59:59','2019-11-14 07:59:59','OAXBTC','4h','0.000008210000000','0.000008190000000','0.033476804520630','0.033395253230689','4077.5644970316966','4077.564497031696646','test','test','0.24'),('2019-11-14 15:59:59','2019-11-14 19:59:59','OAXBTC','4h','0.000008140000000','0.000008070000000','0.033458682011754','0.033170953788066','4110.403195547228','4110.403195547228279','test','test','0.0'),('2019-11-16 11:59:59','2019-11-16 23:59:59','OAXBTC','4h','0.000008200000000','0.000008190000000','0.033394742406490','0.033354017110872','4072.5295617671277','4072.529561767127689','test','test','1.58'),('2019-11-17 03:59:59','2019-11-17 11:59:59','OAXBTC','4h','0.000008220000000','0.000008310000000','0.033385692340798','0.033751229118252','4061.5197494887543','4061.519749488754314','test','test','0.36'),('2019-11-17 23:59:59','2019-11-18 07:59:59','OAXBTC','4h','0.000008300000000','0.000008220000000','0.033466922735787','0.033144349986526','4032.1593657575095','4032.159365757509477','test','test','0.0'),('2019-11-18 11:59:59','2019-11-18 15:59:59','OAXBTC','4h','0.000008400000000','0.000008160000000','0.033395239902618','0.032441090191115','3975.623797930741','3975.623797930741148','test','test','2.14'),('2019-11-20 23:59:59','2019-11-21 11:59:59','OAXBTC','4h','0.000008350000000','0.000008020000000','0.033183206633395','0.031871774514949','3974.036722562316','3974.036722562315845','test','test','2.27'),('2019-11-21 15:59:59','2019-11-21 19:59:59','OAXBTC','4h','0.000008060000000','0.000008040000000','0.032891777273741','0.032810159960407','4080.865666717204','4080.865666717204022','test','test','0.49'),('2019-11-27 07:59:59','2019-11-27 11:59:59','OAXBTC','4h','0.000008370000000','0.000008130000000','0.032873640093000','0.031931026757000','3927.55556666664','3927.555566666640061','test','test','3.94'),('2019-11-27 23:59:59','2019-11-28 03:59:59','OAXBTC','4h','0.000007950000000','0.000007920000000','0.032664170462778','0.032540909442164','4108.700687141831','4108.700687141830713','test','test','0.0'),('2019-11-28 11:59:59','2019-11-28 15:59:59','OAXBTC','4h','0.000008160000000','0.000008030000000','0.032636779124863','0.032116830437825','3999.6052849097223','3999.605284909722286','test','test','2.94'),('2019-11-28 19:59:59','2019-11-29 15:59:59','OAXBTC','4h','0.000008160000000','0.000008060000000','0.032521234972188','0.032122690425960','3985.4454622779685','3985.445462277968545','test','test','1.59'),('2019-11-29 19:59:59','2019-11-29 23:59:59','OAXBTC','4h','0.000008200000000','0.000008190000000','0.032432669517471','0.032393117481474','3955.2035996915724','3955.203599691572435','test','test','1.70'),('2019-11-30 23:59:59','2019-12-04 15:59:59','OAXBTC','4h','0.000008440000000','0.000008330000000','0.032423880176138','0.032001294060098','3841.691963997419','3841.691963997418952','test','test','3.67'),('2019-12-08 11:59:59','2019-12-08 23:59:59','OAXBTC','4h','0.000008390000000','0.000008280000000','0.032329972150352','0.031906098856366','3853.3935816867174','3853.393581686717425','test','test','0.95'),('2019-12-09 03:59:59','2019-12-09 07:59:59','OAXBTC','4h','0.000008300000000','0.000008300000000','0.032235778085021','0.032235778085021','3883.828684942329','3883.828684942328891','test','test','0.24'),('2019-12-09 11:59:59','2019-12-10 03:59:59','OAXBTC','4h','0.000008680000000','0.000008180000000','0.032235778085021','0.030378878425746','3713.7993185508444','3713.799318550844418','test','test','4.37');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 14:52:34
