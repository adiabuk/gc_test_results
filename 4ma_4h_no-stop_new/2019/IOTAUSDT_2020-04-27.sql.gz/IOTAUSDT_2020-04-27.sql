-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-05 15:59:59','IOTAUSDT','4h','0.351500000000000','0.364200000000000','222.222222222222200','230.251303935514443','632.211158526948','632.211158526947997','test','test','0.0'),('2019-01-07 07:59:59','2019-01-07 19:59:59','IOTAUSDT','4h','0.370100000000000','0.364000000000000','224.006462602953860','220.314380944272358','605.2592883084407','605.259288308440659','test','test','1.59'),('2019-02-09 11:59:59','2019-02-11 19:59:59','IOTAUSDT','4h','0.278100000000000','0.270000000000000','223.186000012135736','216.685436904986148','802.5386552036524','802.538655203652411','test','test','0.0'),('2019-02-13 03:59:59','2019-02-13 15:59:59','IOTAUSDT','4h','0.273100000000000','0.267200000000000','221.741430432769135','216.950971115473834','811.9422571686896','811.942257168689594','test','test','1.53'),('2019-02-15 23:59:59','2019-02-21 23:59:59','IOTAUSDT','4h','0.270900000000000','0.299900000000000','220.676883917814649','244.300470605214542','814.6064374965473','814.606437496547301','test','test','1.36'),('2019-02-22 23:59:59','2019-02-23 07:59:59','IOTAUSDT','4h','0.306900000000000','0.301200000000000','225.926569848347953','221.730475198183143','736.1569561692667','736.156956169266664','test','test','2.28'),('2019-02-23 19:59:59','2019-02-24 15:59:59','IOTAUSDT','4h','0.316300000000000','0.282100000000000','224.994104370533506','200.666572377260508','711.3313448325434','711.331344832543436','test','test','4.77'),('2019-03-13 19:59:59','2019-03-14 19:59:59','IOTAUSDT','4h','0.285000000000000','0.294500000000000','219.587986149806198','226.907585688133082','770.4841619291446','770.484161929144648','test','test','1.01'),('2019-03-14 23:59:59','2019-03-17 23:59:59','IOTAUSDT','4h','0.297000000000000','0.295400000000000','221.214563824989938','220.022835535023660','744.8301812289224','744.830181228922356','test','test','0.84'),('2019-03-20 11:59:59','2019-03-20 19:59:59','IOTAUSDT','4h','0.296600000000000','0.295700000000000','220.949735316108558','220.279287703888428','744.9417913557269','744.941791355726878','test','test','0.40'),('2019-03-20 23:59:59','2019-03-21 15:59:59','IOTAUSDT','4h','0.298500000000000','0.289900000000000','220.800746957837418','214.439318402268242','739.7009948336262','739.700994833626169','test','test','0.93'),('2019-03-21 19:59:59','2019-03-24 19:59:59','IOTAUSDT','4h','0.305000000000000','0.305700000000000','219.387096167710951','219.890607535964733','719.3019546482326','719.301954648232595','test','test','4.95'),('2019-03-28 15:59:59','2019-03-30 07:59:59','IOTAUSDT','4h','0.305500000000000','0.306400000000000','219.498987582878470','220.145629444824777','718.4909577180965','718.490957718096524','test','test','0.0'),('2019-03-30 19:59:59','2019-03-31 07:59:59','IOTAUSDT','4h','0.304700000000000','0.303300000000000','219.642685774422063','218.633497195215654','720.8489851474304','720.848985147430426','test','test','0.06'),('2019-03-31 11:59:59','2019-03-31 19:59:59','IOTAUSDT','4h','0.306800000000000','0.305500000000000','219.418421645709515','218.488682570939545','715.1839036691965','715.183903669196525','test','test','1.14'),('2019-03-31 23:59:59','2019-04-01 03:59:59','IOTAUSDT','4h','0.306300000000000','0.310500000000000','219.211812962427331','222.217655647514476','715.6768297826553','715.676829782655318','test','test','0.26'),('2019-04-01 07:59:59','2019-04-03 23:59:59','IOTAUSDT','4h','0.311500000000000','0.335900000000000','219.879778003557817','237.103105718764255','705.8740866887891','705.874086688789134','test','test','1.86'),('2019-04-04 07:59:59','2019-04-04 19:59:59','IOTAUSDT','4h','0.345300000000000','0.325700000000000','223.707184162492581','211.009064238991698','647.8632614031062','647.863261403106208','test','test','2.72'),('2019-04-05 11:59:59','2019-04-08 11:59:59','IOTAUSDT','4h','0.348800000000000','0.335800000000000','220.885379735047906','212.652839779326513','633.2723042862611','633.272304286261146','test','test','6.62'),('2019-04-08 23:59:59','2019-04-09 03:59:59','IOTAUSDT','4h','0.353800000000000','0.344600000000000','219.055926411554282','213.359729342627503','619.1518553181297','619.151855318129719','test','test','5.08'),('2019-04-10 15:59:59','2019-04-10 23:59:59','IOTAUSDT','4h','0.351000000000000','0.348000000000000','217.790104840681664','215.928650953154488','620.4846291757312','620.484629175731243','test','test','1.82'),('2019-04-30 11:59:59','2019-05-01 15:59:59','IOTAUSDT','4h','0.304000000000000','0.287800000000000','217.376448421231203','205.792571893520858','715.0541066487868','715.054106648786842','test','test','0.0'),('2019-05-01 19:59:59','2019-05-02 03:59:59','IOTAUSDT','4h','0.294500000000000','0.290900000000000','214.802253637295536','212.176487548690233','729.3794690570307','729.379469057030747','test','test','2.27'),('2019-05-11 19:59:59','2019-05-17 11:59:59','IOTAUSDT','4h','0.300100000000000','0.365500000000000','214.218750062049935','260.902876200197454','713.8245586872707','713.824558687270724','test','test','3.06'),('2019-05-19 03:59:59','2019-05-22 23:59:59','IOTAUSDT','4h','0.415000000000000','0.382400000000000','224.593000314971619','206.950273061313624','541.1879525661967','541.187952566196714','test','test','16.1'),('2019-05-27 15:59:59','2019-05-31 11:59:59','IOTAUSDT','4h','0.411200000000000','0.468900000000000','220.672394258603163','251.637367869306956','536.6546552981595','536.654655298159469','test','test','11.4'),('2019-05-31 23:59:59','2019-06-01 19:59:59','IOTAUSDT','4h','0.508000000000000','0.477400000000000','227.553499505426203','213.846536739941882','447.93995965635077','447.939959656350766','test','test','7.69'),('2019-06-02 23:59:59','2019-06-03 07:59:59','IOTAUSDT','4h','0.489100000000000','0.471000000000000','224.507507779763017','216.199215220340164','459.0216883659027','459.021688365902719','test','test','2.39'),('2019-06-16 07:59:59','2019-06-17 07:59:59','IOTAUSDT','4h','0.456100000000000','0.435800000000000','222.661220544335720','212.751063173035533','488.1850921822752','488.185092182275184','test','test','0.0'),('2019-06-17 11:59:59','2019-06-17 15:59:59','IOTAUSDT','4h','0.440100000000000','0.433600000000000','220.458963350713475','217.202923219425969','500.9292509673108','500.929250967310793','test','test','0.97'),('2019-06-22 19:59:59','2019-06-25 15:59:59','IOTAUSDT','4h','0.452700000000000','0.445100000000000','219.735398877094013','216.046445858613964','485.38855506316327','485.388555063163267','test','test','4.21'),('2019-06-26 03:59:59','2019-06-26 23:59:59','IOTAUSDT','4h','0.473000000000000','0.447200000000000','218.915631539654015','206.974778910218333','462.8237453269641','462.823745326964115','test','test','5.89'),('2019-06-27 03:59:59','2019-06-27 07:59:59','IOTAUSDT','4h','0.447600000000000','0.426400000000000','216.262108733112768','206.019131286414847','483.15931352348696','483.159313523486958','test','test','0.08'),('2019-08-23 11:59:59','2019-08-27 11:59:59','IOTAUSDT','4h','0.258000000000000','0.259500000000000','213.985891522735415','215.229995543216432','829.4026803206799','829.402680320679906','test','test','0.0'),('2019-09-15 11:59:59','2019-09-16 15:59:59','IOTAUSDT','4h','0.248200000000000','0.243400000000000','214.262359082842323','210.118687351989621','863.2649439276483','863.264943927648346','test','test','0.0'),('2019-09-16 19:59:59','2019-09-22 07:59:59','IOTAUSDT','4h','0.244400000000000','0.287900000000000','213.341543142652853','251.313544479417942','872.919570960118','872.919570960117994','test','test','0.40'),('2019-10-02 03:59:59','2019-10-03 15:59:59','IOTAUSDT','4h','0.268900000000000','0.269300000000000','221.779765661933965','222.109672341981508','824.7667001187579','824.766700118757853','test','test','5.16'),('2019-10-03 23:59:59','2019-10-04 03:59:59','IOTAUSDT','4h','0.269900000000000','0.269100000000000','221.853078257500073','221.195492253031773','821.9825055854024','821.982505585402350','test','test','0.22'),('2019-10-05 07:59:59','2019-10-06 11:59:59','IOTAUSDT','4h','0.275000000000000','0.270700000000000','221.706948034284892','218.240257574112405','806.207083761036','806.207083761035960','test','test','2.14'),('2019-10-06 15:59:59','2019-10-06 19:59:59','IOTAUSDT','4h','0.271300000000000','0.266300000000000','220.936572376468803','216.864759394963670','814.3625963010277','814.362596301027679','test','test','0.22'),('2019-10-07 11:59:59','2019-10-08 15:59:59','IOTAUSDT','4h','0.279700000000000','0.272200000000000','220.031725047245459','214.131696667358625','786.6704506515747','786.670450651574697','test','test','4.79'),('2019-10-08 19:59:59','2019-10-08 23:59:59','IOTAUSDT','4h','0.272500000000000','0.275200000000000','218.720607629492832','220.887747594996029','802.6444316678635','802.644431667863500','test','test','0.11'),('2019-10-09 15:59:59','2019-10-10 11:59:59','IOTAUSDT','4h','0.276500000000000','0.271600000000000','219.202194288493530','215.317598440343005','792.7746628878608','792.774662887860813','test','test','0.47'),('2019-10-13 19:59:59','2019-10-15 19:59:59','IOTAUSDT','4h','0.280800000000000','0.278800000000000','218.338950766682302','216.783830034725867','777.5603659782133','777.560365978213326','test','test','3.27'),('2019-10-15 23:59:59','2019-10-16 11:59:59','IOTAUSDT','4h','0.279600000000000','0.274600000000000','217.993368381803094','214.095060649653533','779.6615464299109','779.661546429910914','test','test','0.28'),('2019-10-28 03:59:59','2019-10-31 03:59:59','IOTAUSDT','4h','0.278100000000000','0.277100000000000','217.127077774658716','216.346325966767097','780.7518078916171','780.751807891617091','test','test','3.09'),('2019-11-05 19:59:59','2019-11-07 11:59:59','IOTAUSDT','4h','0.276900000000000','0.269400000000000','216.953577372905073','211.077261626076648','783.5087662437887','783.508766243788727','test','test','0.83');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 14:35:03
