-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-12 07:59:59','2019-01-13 07:59:59','ENJETH','4h','0.000297960000000','0.000277070000000','1.297777777777778','1.206790471502513','4355.543622559329','4355.543622559329378','test','test','0.0'),('2019-01-13 19:59:59','2019-01-14 15:59:59','ENJETH','4h','0.000287220000000','0.000263880000000','1.277558376383275','1.173741746257289','4448.013287317299','4448.013287317298818','test','test','3.53'),('2019-01-16 15:59:59','2019-01-17 07:59:59','ENJETH','4h','0.000277550000000','0.000277400000000','1.254488014133055','1.253810034662257','4519.863138652694','4519.863138652694033','test','test','4.92'),('2019-01-17 15:59:59','2019-01-17 19:59:59','ENJETH','4h','0.000277070000000','0.000275680000000','1.254337352028433','1.248044614022444','4527.149644596793','4527.149644596793223','test','test','0.0'),('2019-01-17 23:59:59','2019-01-18 15:59:59','ENJETH','4h','0.000276180000000','0.000274320000000','1.252938965804880','1.244500749871803','4536.675232836847','4536.675232836846590','test','test','0.38'),('2019-01-18 19:59:59','2019-01-19 11:59:59','ENJETH','4h','0.000278140000000','0.000281100000000','1.251063806708641','1.264377781210178','4497.964358627457','4497.964358627456932','test','test','1.37'),('2019-01-19 19:59:59','2019-01-19 23:59:59','ENJETH','4h','0.000281080000000','0.000276320000000','1.254022467708982','1.232785997855934','4461.443246438674','4461.443246438673668','test','test','1.92'),('2019-01-21 03:59:59','2019-01-21 07:59:59','ENJETH','4h','0.000283480000000','0.000280830000000','1.249303252186083','1.237624637757223','4407.024312777208','4407.024312777208252','test','test','2.52'),('2019-01-21 15:59:59','2019-01-21 23:59:59','ENJETH','4h','0.000285220000000','0.000288000000000','1.246708004535225','1.258859495498720','4371.039914926111','4371.039914926111123','test','test','2.74'),('2019-01-22 03:59:59','2019-01-26 19:59:59','ENJETH','4h','0.000288640000000','0.000291460000000','1.249408335860446','1.261614999895668','4328.604267809196','4328.604267809196244','test','test','0.63'),('2019-01-29 23:59:59','2019-01-30 15:59:59','ENJETH','4h','0.000305720000000','0.000289590000000','1.252120927868274','1.186058156160452','4095.646107118519','4095.646107118519012','test','test','5.79'),('2019-01-30 23:59:59','2019-01-31 03:59:59','ENJETH','4h','0.000291930000000','0.000286570000000','1.237440311933202','1.214720207552145','4238.825444227048','4238.825444227048138','test','test','0.80'),('2019-01-31 07:59:59','2019-01-31 11:59:59','ENJETH','4h','0.000287220000000','0.000279920000000','1.232391399848523','1.201068869318288','4290.757606881564','4290.757606881564243','test','test','0.22'),('2019-02-16 03:59:59','2019-02-16 11:59:59','ENJETH','4h','0.000257180000000','0.000254780000000','1.225430837508470','1.213995134848775','4764.8761082062','4764.876108206200115','test','test','0.0'),('2019-02-21 15:59:59','2019-02-23 19:59:59','ENJETH','4h','0.000257720000000','0.000252060000000','1.222889570250761','1.196032690817192','4745.031702043925','4745.031702043925179','test','test','1.14'),('2019-02-24 23:59:59','2019-03-02 07:59:59','ENJETH','4h','0.000271470000000','0.000560000000000','1.216921374821079','2.510317787968484','4482.710335658005','4482.710335658004624','test','test','7.14'),('2019-03-02 19:59:59','2019-03-11 23:59:59','ENJETH','4h','0.000637530000000','0.001232090000000','1.504342799964946','2.907291767303202','2359.6423697158507','2359.642369715850691','test','test','56.0'),('2019-03-18 11:59:59','2019-03-23 11:59:59','ENJETH','4h','0.001470060000000','0.001347880000000','1.816109237151226','1.665168305083734','1235.3980362374498','1235.398036237449787','test','test','16.1'),('2019-04-14 03:59:59','2019-04-15 03:59:59','ENJETH','4h','0.001057820000000','0.000942080000000','1.782566807802894','1.587529578089798','1685.1324495688248','1685.132449568824768','test','test','0.0'),('2019-04-15 07:59:59','2019-04-15 15:59:59','ENJETH','4h','0.000976060000000','0.000930770000000','1.739225201199984','1.658523697847376','1781.8834919984263','1781.883491998426280','test','test','3.48'),('2019-04-17 11:59:59','2019-04-22 03:59:59','ENJETH','4h','0.000989480000000','0.001079290000000','1.721291533788293','1.877524295086678','1739.5920420708783','1739.592042070878279','test','test','5.93'),('2019-05-26 07:59:59','2019-05-26 11:59:59','ENJETH','4h','0.000685670000000','0.000664560000000','1.756009925187934','1.701946936402196','2561.013206335313','2561.013206335313043','test','test','0.0'),('2019-06-07 23:59:59','2019-06-10 19:59:59','ENJETH','4h','0.000611700000000','0.000625540000000','1.743995927679992','1.783454655224689','2851.064128952088','2851.064128952088140','test','test','0.0'),('2019-06-11 07:59:59','2019-06-12 15:59:59','ENJETH','4h','0.000640000000000','0.000617410000000','1.752764533801036','1.690897423147027','2738.6945840641188','2738.694584064118771','test','test','2.25'),('2019-07-14 23:59:59','2019-07-16 23:59:59','ENJETH','4h','0.000461860000000','0.000413530000000','1.739016286989034','1.557041971936464','3765.245500777366','3765.245500777366033','test','test','0.0'),('2019-07-24 03:59:59','2019-07-24 15:59:59','ENJETH','4h','0.000410090000000','0.000404080000000','1.698577550310685','1.673684353506649','4141.9628625684245','4141.962862568424498','test','test','0.0'),('2019-07-26 11:59:59','2019-07-27 11:59:59','ENJETH','4h','0.000407620000000','0.000407420000000','1.693045728798677','1.692215030732440','4153.4903311875705','4153.490331187570519','test','test','0.86'),('2019-07-27 23:59:59','2019-07-28 03:59:59','ENJETH','4h','0.000405340000000','0.000403580000000','1.692861129228403','1.685510668905114','4176.397910959694','4176.397910959693945','test','test','0.0'),('2019-07-30 15:59:59','2019-07-31 07:59:59','ENJETH','4h','0.000416300000000','0.000406870000000','1.691227693601005','1.652918116011148','4062.521483547934','4062.521483547934167','test','test','3.05'),('2019-07-31 11:59:59','2019-07-31 15:59:59','ENJETH','4h','0.000409130000000','0.000396230000000','1.682714454136592','1.629657928195297','4112.908987697289','4112.908987697289376','test','test','0.55'),('2019-08-17 15:59:59','2019-08-18 11:59:59','ENJETH','4h','0.000368560000000','0.000335300000000','1.670924115038527','1.520134729141573','4533.655619271019','4533.655619271018622','test','test','0.0'),('2019-08-21 15:59:59','2019-08-25 23:59:59','ENJETH','4h','0.000345860000000','0.000361430000000','1.637415362616981','1.711128880213541','4734.329967666054','4734.329967666053562','test','test','3.05'),('2019-08-27 19:59:59','2019-08-29 03:59:59','ENJETH','4h','0.000376190000000','0.000363460000000','1.653796144305106','1.597832867989935','4396.172530649687','4396.172530649687360','test','test','3.92'),('2019-08-29 19:59:59','2019-08-30 15:59:59','ENJETH','4h','0.000377920000000','0.000371340000000','1.641359860679512','1.612781992656461','4343.141036937744','4343.141036937743593','test','test','3.82'),('2019-08-30 19:59:59','2019-09-03 19:59:59','ENJETH','4h','0.000373430000000','0.000418600000000','1.635009223341056','1.832779532685017','4378.35530980654','4378.355309806540390','test','test','0.55'),('2019-09-04 03:59:59','2019-09-07 07:59:59','ENJETH','4h','0.000445570000000','0.000460040000000','1.678958180973048','1.733482778407076','3768.1131606101126','3768.113160610112573','test','test','11.0'),('2019-10-03 23:59:59','2019-10-07 03:59:59','ENJETH','4h','0.000345200000000','0.000348240000000','1.691074758180610','1.705967189422989','4898.826066571871','4898.826066571870797','test','test','0.0'),('2019-10-09 07:59:59','2019-10-09 15:59:59','ENJETH','4h','0.000366090000000','0.000335290000000','1.694384187345583','1.551831719454507','4628.326879580383','4628.326879580383320','test','test','4.87'),('2019-10-14 11:59:59','2019-10-14 15:59:59','ENJETH','4h','0.000350570000000','0.000344920000000','1.662705861147566','1.635908679085542','4742.864081774155','4742.864081774155238','test','test','4.35'),('2019-10-23 07:59:59','2019-10-25 15:59:59','ENJETH','4h','0.000347130000000','0.000340000000000','1.656750931800449','1.622721507251325','4772.710315445076','4772.710315445076048','test','test','0.63'),('2019-10-28 03:59:59','2019-10-29 07:59:59','ENJETH','4h','0.000352050000000','0.000346930000000','1.649188837456199','1.625204043115123','4684.53014474137','4684.530144741370350','test','test','3.42'),('2019-10-31 15:59:59','2019-11-02 19:59:59','ENJETH','4h','0.000354000000000','0.000359300000000','1.643858883158183','1.668470329713941','4643.669161463793','4643.669161463792989','test','test','1.99'),('2019-11-02 23:59:59','2019-11-04 23:59:59','ENJETH','4h','0.000359480000000','0.000359270000000','1.649328093503907','1.648364593727464','4588.094173539297','4588.094173539297117','test','test','0.94'),('2019-11-15 19:59:59','2019-11-18 07:59:59','ENJETH','4h','0.000361240000000','0.000355340000000','1.649113982442475','1.622179610566685','4565.147775557732','4565.147775557731620','test','test','1.54'),('2019-11-19 19:59:59','2019-11-21 11:59:59','ENJETH','4h','0.000370150000000','0.000373010000000','1.643128566470077','1.655824359257067','4439.088387059509','4439.088387059508932','test','test','4.00'),('2019-11-21 15:59:59','2019-11-23 03:59:59','ENJETH','4h','0.000387070000000','0.000369440000000','1.645949853756075','1.570981253963480','4252.33124178075','4252.331241780750133','test','test','7.18'),('2019-11-23 15:59:59','2019-11-24 11:59:59','ENJETH','4h','0.000395100000000','0.000379810000000','1.629290164913276','1.566238161315392','4123.741242503862','4123.741242503861940','test','test','9.06'),('2019-11-27 23:59:59','2019-12-08 07:59:59','ENJETH','4h','0.000381290000000','0.000596350000000','1.615278608558191','2.526348444002406','4236.351880611059','4236.351880611058732','test','test','0.87'),('2019-12-08 11:59:59','2019-12-08 23:59:59','ENJETH','4h','0.000628810000000','0.000602850000000','1.817738571990238','1.742694451621817','2890.7596443921666','2890.759644392166592','test','test','39.5'),('2019-12-12 11:59:59','2019-12-14 07:59:59','ENJETH','4h','0.000605390000000','0.000562510000000','1.801062100797256','1.673492198945249','2975.044352891947','2975.044352891946801','test','test','32.7'),('2019-12-16 07:59:59','2019-12-18 23:59:59','ENJETH','4h','0.000595220000000','0.000581380000000','1.772713233719032','1.731494270722709','2978.2487714106246','2978.248771410624613','test','test','30.5'),('2019-12-20 11:59:59','2019-12-21 07:59:59','ENJETH','4h','0.000619890000000','0.000612460000000','1.763553464164294','1.742415516724037','2844.9458196846113','2844.945819684611251','test','test','6.21'),('2019-12-21 11:59:59','2019-12-23 03:59:59','ENJETH','4h','0.000627220000000','0.000590700000000','1.758856142510903','1.656446419727035','2804.209276666725','2804.209276666725145','test','test','3.30'),('2019-12-25 03:59:59','2019-12-25 19:59:59','ENJETH','4h','0.000626670000000','0.000605700000000','1.736098426336710','1.678004080029594','2770.3550933293604','2770.355093329360443','test','test','5.73'),('2019-12-28 19:59:59','2019-12-29 03:59:59','ENJETH','4h','0.000632870000000','0.000613630000000','1.723188571601796','1.670801591467458','2722.8160152982377','2722.816015298237744','test','test','4.29'),('2019-12-29 07:59:59','2019-12-29 19:59:59','ENJETH','4h','0.000633300000000','0.000593150000000','1.711547020460832','1.603038236517200','2702.5849051963232','2702.584905196323234','test','test','3.29'),('2019-12-29 23:59:59','2019-12-30 03:59:59','ENJETH','4h','0.000610380000000','0.000611650000000','1.687433957362247','1.690944952358561','2764.562989223511','2764.562989223511067','test','test','2.82'),('2019-12-30 11:59:59','2019-12-31 23:59:59','ENJETH','4h','0.000623640000000','0.000624220000000','1.688214178472539','1.689784257722610','2707.0331897770166','2707.033189777016560','test','test','1.92');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 11:03:24
