-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-02 03:59:59','GXSBTC','4h','0.000145300000000','0.000143400000000','0.033333333333333','0.032897453544391','229.41041523285156','229.410415232851562','test','test','0.0'),('2019-01-02 11:59:59','2019-01-03 03:59:59','GXSBTC','4h','0.000144300000000','0.000143000000000','0.033236471158013','0.032937043489923','230.32897545400476','230.328975454004762','test','test','1.03'),('2019-01-03 11:59:59','2019-01-03 15:59:59','GXSBTC','4h','0.000143800000000','0.000142600000000','0.033169931676215','0.032893131133715','230.66711874975732','230.667118749757321','test','test','0.55'),('2019-01-03 19:59:59','2019-01-06 19:59:59','GXSBTC','4h','0.000143500000000','0.000144800000000','0.033108420444548','0.033408357354499','230.7206999620101','230.720699962010087','test','test','0.62'),('2019-01-12 15:59:59','2019-01-13 11:59:59','GXSBTC','4h','0.000147000000000','0.000144400000000','0.033175073091204','0.032588303090951','225.68076932791985','225.680769327919847','test','test','2.44'),('2019-01-13 15:59:59','2019-01-13 19:59:59','GXSBTC','4h','0.000145100000000','0.000142900000000','0.033044679757815','0.032543657735298','227.73728296219616','227.737282962196161','test','test','0.48'),('2019-01-13 23:59:59','2019-01-14 03:59:59','GXSBTC','4h','0.000144200000000','0.000145900000000','0.032933341530589','0.033321598677621','228.3865570775913','228.386557077591306','test','test','0.90'),('2019-01-14 11:59:59','2019-01-15 03:59:59','GXSBTC','4h','0.000145700000000','0.000143200000000','0.033019620896596','0.032453052247032','226.62745982564022','226.627459825640216','test','test','0.0'),('2019-01-15 07:59:59','2019-01-15 11:59:59','GXSBTC','4h','0.000144400000000','0.000143400000000','0.032893716752248','0.032665920929864','227.7958223839904','227.795822383990412','test','test','0.83'),('2019-01-16 15:59:59','2019-01-16 19:59:59','GXSBTC','4h','0.000146200000000','0.000145600000000','0.032843095458385','0.032708308472920','224.64497577554795','224.644975775547948','test','test','1.91'),('2019-01-16 23:59:59','2019-01-20 19:59:59','GXSBTC','4h','0.000146000000000','0.000176700000000','0.032813142794948','0.039712892684023','224.7475533900578','224.747553390057789','test','test','0.61'),('2019-01-21 15:59:59','2019-01-23 23:59:59','GXSBTC','4h','0.000165100000000','0.000155800000000','0.034346420548076','0.032411703945428','208.0340432954344','208.034043295434401','test','test','11.8'),('2019-01-29 23:59:59','2019-01-31 11:59:59','GXSBTC','4h','0.000159600000000','0.000156800000000','0.033916483525266','0.033321457498507','212.5092952710874','212.509295271087410','test','test','8.58'),('2019-02-03 23:59:59','2019-02-04 07:59:59','GXSBTC','4h','0.000158400000000','0.000158000000000','0.033784255519319','0.033698941742755','213.28444140984286','213.284441409842856','test','test','1.01'),('2019-02-04 11:59:59','2019-02-04 19:59:59','GXSBTC','4h','0.000159100000000','0.000157000000000','0.033765296902305','0.033319620450420','212.22688184981072','212.226881849810724','test','test','0.69'),('2019-02-04 23:59:59','2019-02-05 07:59:59','GXSBTC','4h','0.000158000000000','0.000157100000000','0.033666257690775','0.033474487868486','213.0775803213601','213.077580321360102','test','test','0.63'),('2019-02-05 15:59:59','2019-02-05 19:59:59','GXSBTC','4h','0.000158500000000','0.000155200000000','0.033623642174711','0.032923591580537','212.13654368902627','212.136543689026269','test','test','0.88'),('2019-02-08 03:59:59','2019-02-09 19:59:59','GXSBTC','4h','0.000158700000000','0.000158400000000','0.033468075376005','0.033404808692875','210.88894376814952','210.888943768149517','test','test','2.20'),('2019-02-10 15:59:59','2019-02-10 23:59:59','GXSBTC','4h','0.000161800000000','0.000164200000000','0.033454016113088','0.033950243793381','206.76153345542372','206.761533455423717','test','test','2.10'),('2019-02-11 15:59:59','2019-02-11 19:59:59','GXSBTC','4h','0.000160500000000','0.000159000000000','0.033564288930930','0.033250603987650','209.12329551981583','209.123295519815827','test','test','0.0'),('2019-02-16 23:59:59','2019-02-18 15:59:59','GXSBTC','4h','0.000160600000000','0.000160400000000','0.033494581165757','0.033452869358577','208.55903590135188','208.559035901351876','test','test','0.99'),('2019-02-19 23:59:59','2019-02-20 03:59:59','GXSBTC','4h','0.000163600000000','0.000158600000000','0.033485311875273','0.032461922148034','204.67794544787697','204.677945447876965','test','test','1.95'),('2019-02-20 19:59:59','2019-02-21 11:59:59','GXSBTC','4h','0.000163500000000','0.000159000000000','0.033257891935886','0.032342537111963','203.41218309410533','203.412183094105330','test','test','2.99'),('2019-02-23 11:59:59','2019-02-24 15:59:59','GXSBTC','4h','0.000167100000000','0.000161300000000','0.033054479752792','0.031907166870888','197.8125658455549','197.812565845554900','test','test','4.84'),('2019-02-24 19:59:59','2019-02-25 03:59:59','GXSBTC','4h','0.000162900000000','0.000160900000000','0.032799521334591','0.032396826167807','201.347583392212','201.347583392211988','test','test','0.98'),('2019-02-26 11:59:59','2019-03-04 07:59:59','GXSBTC','4h','0.000167300000000','0.000169000000000','0.032710033519750','0.033042412820309','195.51723562313478','195.517235623134781','test','test','3.82'),('2019-03-06 07:59:59','2019-03-06 23:59:59','GXSBTC','4h','0.000169800000000','0.000170600000000','0.032783895586541','0.032938354458562','193.0735900267452','193.073590026745194','test','test','3.29'),('2019-03-07 11:59:59','2019-03-14 15:59:59','GXSBTC','4h','0.000173900000000','0.000224100000000','0.032818219780324','0.042291909446639','188.7189176556859','188.718917655685914','test','test','1.89'),('2019-03-15 19:59:59','2019-03-16 07:59:59','GXSBTC','4h','0.000231000000000','0.000225300000000','0.034923484150616','0.034061735840406','151.18391407193076','151.183914071930758','test','test','2.98'),('2019-03-17 19:59:59','2019-03-23 15:59:59','GXSBTC','4h','0.000232000000000','0.000273100000000','0.034731984526125','0.040884935233124','149.70682985398662','149.706829853986619','test','test','2.88'),('2019-03-28 11:59:59','2019-04-02 07:59:59','GXSBTC','4h','0.000266400000000','0.000262500000000','0.036099306905458','0.035570826061121','135.50790880427178','135.507908804271779','test','test','0.0'),('2019-04-14 11:59:59','2019-04-17 11:59:59','GXSBTC','4h','0.000260400000000','0.000256100000000','0.035981866717828','0.035387696107664','138.17921166600448','138.179211666004477','test','test','0.0'),('2019-06-04 15:59:59','2019-06-13 11:59:59','GXSBTC','4h','0.000154000000000','0.000271000000000','0.035849828804458','0.063086387052001','232.79109613284277','232.791096132842767','test','test','0.0'),('2019-06-18 23:59:59','2019-06-19 23:59:59','GXSBTC','4h','0.000271800000000','0.000257400000000','0.041902397303912','0.039682402744764','154.16628882969746','154.166288829697464','test','test','43.5'),('2019-06-20 03:59:59','2019-06-20 07:59:59','GXSBTC','4h','0.000258200000000','0.000253600000000','0.041409065179657','0.040671335900701','160.37593020781048','160.375930207810484','test','test','0.81'),('2019-07-25 03:59:59','2019-07-27 03:59:59','GXSBTC','4h','0.000150500000000','0.000152000000000','0.041245125339889','0.041656206323343','274.0539889693599','274.053988969359921','test','test','0.0'),('2019-07-30 11:59:59','2019-07-30 15:59:59','GXSBTC','4h','0.000154700000000','0.000152700000000','0.041336476669545','0.040802068438523','267.2041155109574','267.204115510957422','test','test','1.74'),('2019-07-30 19:59:59','2019-07-31 03:59:59','GXSBTC','4h','0.000156500000000','0.000154100000000','0.041217719284874','0.040585626465170','263.3720082100547','263.372008210054673','test','test','2.42'),('2019-07-31 07:59:59','2019-08-05 03:59:59','GXSBTC','4h','0.000171400000000','0.000164500000000','0.041077254213828','0.039423619125873','239.65725912385193','239.657259123851929','test','test','10.0'),('2019-09-28 15:59:59','2019-10-01 19:59:59','GXSBTC','4h','0.000060880000000','0.000051640000000','0.040709779749838','0.034531094387018','668.6888920801285','668.688892080128539','test','test','0.0'),('2019-10-02 23:59:59','2019-10-03 03:59:59','GXSBTC','4h','0.000053330000000','0.000051990000000','0.039336738558100','0.038348341226995','737.6099485861699','737.609948586169935','test','test','3.16'),('2019-10-03 19:59:59','2019-10-04 11:59:59','GXSBTC','4h','0.000053250000000','0.000052330000000','0.039117094706744','0.038441268845144','734.5933278261742','734.593327826174232','test','test','2.36'),('2019-10-08 19:59:59','2019-10-09 15:59:59','GXSBTC','4h','0.000052950000000','0.000051720000000','0.038966911181944','0.038061730808879','735.9190024918561','735.919002491856077','test','test','1.17'),('2019-10-09 19:59:59','2019-10-13 07:59:59','GXSBTC','4h','0.000052640000000','0.000055450000000','0.038765759987929','0.040835132814032','736.4316107129434','736.431610712943439','test','test','1.74'),('2019-10-14 23:59:59','2019-10-15 07:59:59','GXSBTC','4h','0.000055980000000','0.000055320000000','0.039225620615952','0.038763153491863','700.7077637719226','700.707763771922600','test','test','0.94'),('2019-10-15 11:59:59','2019-10-17 19:59:59','GXSBTC','4h','0.000067150000000','0.000061630000000','0.039122850143932','0.035906794555034','582.6187661047273','582.618766104727342','test','test','17.6'),('2019-10-18 03:59:59','2019-10-18 15:59:59','GXSBTC','4h','0.000063280000000','0.000060700000000','0.038408171124177','0.036842224829923','606.9559280053307','606.955928005330748','test','test','2.60'),('2019-10-28 11:59:59','2019-10-29 03:59:59','GXSBTC','4h','0.000062730000000','0.000054500000000','0.038060183058788','0.033066793825984','606.7301619446446','606.730161944644578','test','test','9.29'),('2019-10-29 07:59:59','2019-10-29 11:59:59','GXSBTC','4h','0.000055890000000','0.000054120000000','0.036950541007053','0.035780341372369','661.1297371095603','661.129737109560324','test','test','2.48'),('2019-11-02 03:59:59','2019-11-04 07:59:59','GXSBTC','4h','0.000060620000000','0.000056320000000','0.036690496643790','0.034087904503105','605.2539862057114','605.253986205711385','test','test','10.7'),('2019-11-04 11:59:59','2019-11-04 15:59:59','GXSBTC','4h','0.000057050000000','0.000056930000000','0.036112142834749','0.036036183901530','632.9911101621229','632.991110162122936','test','test','1.27'),('2019-11-04 19:59:59','2019-11-04 23:59:59','GXSBTC','4h','0.000057900000000','0.000056860000000','0.036095263071812','0.035446919831835','623.4069615166072','623.406961516607225','test','test','1.67'),('2019-11-05 11:59:59','2019-11-11 23:59:59','GXSBTC','4h','0.000058040000000','0.000062980000000','0.035951186796261','0.039011125851628','619.4208614104258','619.420861410425800','test','test','2.03'),('2019-11-12 11:59:59','2019-11-17 07:59:59','GXSBTC','4h','0.000065670000000','0.000068910000000','0.036631173253009','0.038438467319398','557.8068106138165','557.806810613816538','test','test','7.56');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 15:19:33
