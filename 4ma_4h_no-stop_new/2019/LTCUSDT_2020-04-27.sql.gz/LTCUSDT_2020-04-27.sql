-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-03 19:59:59','LTCUSDT','4h','31.480000000000000','30.850000000000001','222.222222222222200','217.774954115487759','7.059155724975292','7.059155724975292','test','test','0.0'),('2019-01-03 23:59:59','2019-01-04 15:59:59','LTCUSDT','4h','31.390000000000001','31.090000000000000','221.233940420725702','219.119566985675760','7.047911450166477','7.047911450166477','test','test','1.72'),('2019-01-04 23:59:59','2019-01-10 07:59:59','LTCUSDT','4h','31.760000000000002','35.170000000000002','220.764079657381245','244.467023978277695','6.951010064779006','6.951010064779006','test','test','2.10'),('2019-01-25 03:59:59','2019-01-27 03:59:59','LTCUSDT','4h','32.700000000000003','32.930000000000000','226.031400617580431','227.621223924676571','6.9122752482440495','6.912275248244049','test','test','0.0'),('2019-01-27 19:59:59','2019-01-27 23:59:59','LTCUSDT','4h','32.609999999999999','32.210000000000001','226.384694685824030','223.607820172658450','6.942186282913954','6.942186282913954','test','test','0.0'),('2019-02-01 19:59:59','2019-02-06 03:59:59','LTCUSDT','4h','33.020000000000003','32.789999999999999','225.767611460676136','224.195032701258924','6.837298953987768','6.837298953987768','test','test','2.45'),('2019-02-08 11:59:59','2019-02-13 11:59:59','LTCUSDT','4h','37.649999999999999','42.469999999999999','225.418149514139003','254.276462413425861','5.987201846325073','5.987201846325073','test','test','13.1'),('2019-02-16 03:59:59','2019-02-23 11:59:59','LTCUSDT','4h','43.270000000000003','48.890000000000001','231.831107936202756','261.941827293758990','5.357779245116772','5.357779245116772','test','test','18.7'),('2019-02-23 19:59:59','2019-02-24 15:59:59','LTCUSDT','4h','51.200000000000003','44.390000000000001','238.522378904548532','206.797039054158375','4.6586402129794635','4.658640212979464','test','test','4.51'),('2019-03-01 19:59:59','2019-03-02 11:59:59','LTCUSDT','4h','48.170000000000002','48.450000000000003','231.472303382239602','232.817793208833479','4.805320809263849','4.805320809263849','test','test','7.84'),('2019-03-02 23:59:59','2019-03-04 07:59:59','LTCUSDT','4h','48.490000000000002','46.140000000000001','231.771301121482679','220.538829320379676','4.779775234511913','4.779775234511913','test','test','2.12'),('2019-03-05 15:59:59','2019-03-11 07:59:59','LTCUSDT','4h','52.140000000000001','55.289999999999999','229.275196276793139','243.126689722744374','4.3972995066511915','4.397299506651192','test','test','11.5'),('2019-03-12 23:59:59','2019-03-13 15:59:59','LTCUSDT','4h','56.579999999999998','55.630000000000003','232.353305931448972','228.452004400256413','4.106633190729038','4.106633190729038','test','test','14.3'),('2019-03-15 03:59:59','2019-03-18 19:59:59','LTCUSDT','4h','56.289999999999999','58.880000000000003','231.486350035628419','242.137436313693399','4.112388524349412','4.112388524349412','test','test','1.17'),('2019-03-20 15:59:59','2019-03-21 15:59:59','LTCUSDT','4h','60.020000000000003','58.460000000000001','233.853258097420621','227.775099439773555','3.8962555497737523','3.896255549773752','test','test','1.89'),('2019-03-23 07:59:59','2019-03-24 07:59:59','LTCUSDT','4h','60.990000000000002','59.299999999999997','232.502556173499073','226.060035761411626','3.812142255673046','3.812142255673046','test','test','4.14'),('2019-03-24 11:59:59','2019-03-24 19:59:59','LTCUSDT','4h','59.759999999999998','59.320000000000000','231.070884970813012','229.369559847199270','3.8666480082130694','3.866648008213069','test','test','0.76'),('2019-03-25 03:59:59','2019-03-25 07:59:59','LTCUSDT','4h','60.060000000000002','59.539999999999999','230.692812721121044','228.695472351241193','3.841039172845838','3.841039172845838','test','test','1.23'),('2019-03-27 11:59:59','2019-03-30 19:59:59','LTCUSDT','4h','61.090000000000003','60.259999999999998','230.248959305592166','227.120679125142942','3.769012265601443','3.769012265601443','test','test','2.53'),('2019-04-02 07:59:59','2019-04-08 11:59:59','LTCUSDT','4h','66.909999999999997','85.379999999999995','229.553785932159030','292.920374277204303','3.430784425828113','3.430784425828113','test','test','9.93'),('2019-04-10 19:59:59','2019-04-11 03:59:59','LTCUSDT','4h','89.359999999999999','84.390000000000001','243.635250008835754','230.084811417252098','2.726446396696909','2.726446396696909','test','test','4.45'),('2019-04-19 15:59:59','2019-04-20 11:59:59','LTCUSDT','4h','82.750000000000000','80.769999999999996','240.624041432928266','234.866511498943993','2.9078434010021543','2.907843401002154','test','test','0.0'),('2019-04-20 15:59:59','2019-04-20 19:59:59','LTCUSDT','4h','80.840000000000003','80.519999999999996','239.344590336487300','238.397159993740161','2.9607198210847017','2.960719821084702','test','test','0.08'),('2019-04-20 23:59:59','2019-04-21 03:59:59','LTCUSDT','4h','81.150000000000006','80.840000000000003','239.134050260321288','238.220537560620727','2.9468151603243533','2.946815160324353','test','test','0.77'),('2019-05-03 11:59:59','2019-05-04 15:59:59','LTCUSDT','4h','78.829999999999998','75.950000000000003','238.931047438165592','230.201865443722909','3.0309659702925993','3.030965970292599','test','test','0.0'),('2019-05-04 19:59:59','2019-05-05 23:59:59','LTCUSDT','4h','76.340000000000003','75.700000000000003','236.991229217178329','235.004402040089047','3.104417464201969','3.104417464201969','test','test','0.82'),('2019-05-07 03:59:59','2019-05-07 15:59:59','LTCUSDT','4h','77.650000000000006','74.709999999999994','236.549712066714051','227.593419040620802','3.0463581721405544','3.046358172140554','test','test','2.51'),('2019-05-10 15:59:59','2019-05-17 03:59:59','LTCUSDT','4h','76.319999999999993','89.939999999999998','234.559424727582183','276.418693134155433','3.0733677244180058','3.073367724418006','test','test','2.10'),('2019-05-19 15:59:59','2019-05-20 15:59:59','LTCUSDT','4h','93.099999999999994','90.250000000000000','243.861484373487400','236.396336892666369','2.6193499932705415','2.619349993270542','test','test','18.4'),('2019-05-20 19:59:59','2019-05-21 03:59:59','LTCUSDT','4h','90.670000000000002','89.799999999999997','242.202562711082720','239.878572090605786','2.6712535867550757','2.671253586755076','test','test','10.8'),('2019-05-24 11:59:59','2019-05-30 23:59:59','LTCUSDT','4h','99.239999999999995','107.780000000000001','241.686120350976722','262.484180284444506','2.4353700156285445','2.435370015628544','test','test','14.9'),('2019-06-01 11:59:59','2019-06-02 03:59:59','LTCUSDT','4h','113.849999999999994','111.680000000000007','246.307911447302899','241.613241549712683','2.1634423491199204','2.163442349119920','test','test','5.33'),('2019-06-02 07:59:59','2019-06-03 07:59:59','LTCUSDT','4h','115.170000000000002','111.409999999999997','245.264651470060613','237.257400540761068','2.1295880131115794','2.129588013111579','test','test','3.03'),('2019-06-03 11:59:59','2019-06-03 15:59:59','LTCUSDT','4h','112.579999999999998','111.060000000000002','243.485262374660721','240.197843660772946','2.1627754696630017','2.162775469663002','test','test','1.03'),('2019-06-07 15:59:59','2019-06-14 03:59:59','LTCUSDT','4h','115.750000000000000','129.460000000000008','242.754724882685679','271.507789920626237','2.0972330443428566','2.097233044342857','test','test','4.05'),('2019-06-15 07:59:59','2019-06-17 15:59:59','LTCUSDT','4h','134.449999999999989','132.039999999999992','249.144294891116914','244.678413517464321','1.8530628106442315','1.853062810644232','test','test','3.71'),('2019-06-19 07:59:59','2019-06-20 19:59:59','LTCUSDT','4h','137.509999999999991','133.780000000000001','248.151876808083017','241.420682709514551','1.8046096779003928','1.804609677900393','test','test','3.97'),('2019-06-21 03:59:59','2019-06-21 15:59:59','LTCUSDT','4h','137.439999999999998','136.240000000000009','246.656055897290003','244.502481486079688','1.7946453426752764','1.794645342675276','test','test','2.66'),('2019-06-21 19:59:59','2019-06-24 03:59:59','LTCUSDT','4h','136.590000000000003','135.460000000000008','246.177483805909901','244.140873829332719','1.8023097137851225','1.802309713785123','test','test','0.25'),('2019-08-01 07:59:59','2019-08-02 19:59:59','LTCUSDT','4h','96.989999999999995','93.170000000000002','245.724903811115041','236.046904712667185','2.533507617394732','2.533507617394732','test','test','0.0'),('2019-08-02 23:59:59','2019-08-03 03:59:59','LTCUSDT','4h','94.760000000000005','95.780000000000001','243.574237344793232','246.196079072227690','2.570433066112212','2.570433066112212','test','test','1.67'),('2019-08-05 11:59:59','2019-08-05 23:59:59','LTCUSDT','4h','102.069999999999993','96.560000000000002','244.156868839778667','230.976655777104241','2.3920531874182296','2.392053187418230','test','test','6.16'),('2019-08-06 07:59:59','2019-08-06 11:59:59','LTCUSDT','4h','97.510000000000005','95.120000000000005','241.227932603628830','235.315362006534457','2.4738789109181503','2.473878910918150','test','test','0.97'),('2019-09-08 15:59:59','2019-09-09 11:59:59','LTCUSDT','4h','70.620000000000005','70.469999999999999','239.914028026496766','239.404440031538172','3.397253299723828','3.397253299723828','test','test','0.0'),('2019-09-09 19:59:59','2019-09-11 15:59:59','LTCUSDT','4h','69.659999999999997','68.989999999999995','239.800786249839319','237.494347450135137','3.4424459697077134','3.442445969707713','test','test','1.56'),('2019-09-14 19:59:59','2019-09-16 15:59:59','LTCUSDT','4h','70.750000000000000','69.969999999999999','239.288244294349482','236.650154816616720','3.3821659970932787','3.382165997093279','test','test','2.48'),('2019-09-16 19:59:59','2019-09-21 03:59:59','LTCUSDT','4h','70.549999999999997','74.599999999999994','238.702002188186611','252.404951994879099','3.3834443967141974','3.383444396714197','test','test','0.82'),('2019-10-09 19:59:59','2019-10-10 15:59:59','LTCUSDT','4h','59.149999999999999','57.820000000000000','241.747102145229405','236.311368487526039','4.0870177877469045','4.087017787746904','test','test','0.0'),('2019-10-11 03:59:59','2019-10-11 07:59:59','LTCUSDT','4h','57.590000000000003','56.180000000000000','240.539161332406394','234.649940678148795','4.176752237062101','4.176752237062101','test','test','0.0'),('2019-10-26 23:59:59','2019-10-30 19:59:59','LTCUSDT','4h','56.710000000000001','58.109999999999999','239.230445631460299','245.136328613016360','4.218487843968617','4.218487843968617','test','test','1.09'),('2019-11-02 15:59:59','2019-11-03 11:59:59','LTCUSDT','4h','58.469999999999999','57.579999999999998','240.542864071806093','236.881445412255772','4.113953550056544','4.113953550056544','test','test','3.91'),('2019-11-04 07:59:59','2019-11-07 19:59:59','LTCUSDT','4h','58.810000000000002','61.289999999999999','239.729215480794920','249.838524346504300','4.0763342200441235','4.076334220044123','test','test','2.09'),('2019-11-10 07:59:59','2019-11-10 19:59:59','LTCUSDT','4h','63.350000000000001','64.120000000000005','241.975728562063637','244.916870014199219','3.819664223552701','3.819664223552701','test','test','8.72'),('2019-11-11 15:59:59','2019-11-12 03:59:59','LTCUSDT','4h','62.130000000000003','61.829999999999998','242.629315551427112','241.457759223317822','3.9051877603641896','3.905187760364190','test','test','0.0'),('2019-12-28 11:59:59','2019-12-31 07:59:59','LTCUSDT','4h','42.060000000000002','42.420000000000002','242.368969700736187','244.443454462796694','5.762457672390304','5.762457672390304','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 15:05:35
