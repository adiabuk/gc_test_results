-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 19:59:59','2019-01-10 19:59:59','TRXUSDT','4h','0.019670000000000','0.025430000000000','222.222222222222200','287.295938541490102','11297.520194317347','11297.520194317346977','test','test','0.0'),('2019-01-11 03:59:59','2019-01-11 07:59:59','TRXUSDT','4h','0.026060000000000','0.025960000000000','236.683048070948445','235.774824555710723','9082.235152377147','9082.235152377146733','test','test','24.5'),('2019-01-15 19:59:59','2019-01-15 23:59:59','TRXUSDT','4h','0.024290000000000','0.023950000000000','236.481220623117821','233.171067679031353','9735.743953195464','9735.743953195464201','test','test','0.0'),('2019-01-16 03:59:59','2019-01-16 07:59:59','TRXUSDT','4h','0.023980000000000','0.023740000000000','235.745631079987533','233.386208583774135','9830.927067555776','9830.927067555776375','test','test','0.12'),('2019-01-16 11:59:59','2019-01-17 03:59:59','TRXUSDT','4h','0.024260000000000','0.024170000000000','235.221314969717838','234.348688492089053','9695.849751431073','9695.849751431072946','test','test','2.14'),('2019-01-17 11:59:59','2019-01-19 03:59:59','TRXUSDT','4h','0.024190000000000','0.023880000000000','235.027397974689251','232.015471832806071','9715.890780268262','9715.890780268262461','test','test','0.08'),('2019-01-21 19:59:59','2019-01-28 03:59:59','TRXUSDT','4h','0.025280000000000','0.026650000000000','234.358081054270770','247.058657440518829','9270.493712589825','9270.493712589825009','test','test','5.53'),('2019-01-28 07:59:59','2019-01-28 11:59:59','TRXUSDT','4h','0.027550000000000','0.027390000000000','237.180431362325891','235.802976951510203','8609.090067598036','8609.090067598035603','test','test','5.77'),('2019-02-09 03:59:59','2019-02-09 15:59:59','TRXUSDT','4h','0.027070000000000','0.026400000000000','236.874330382144620','231.011537572538543','8750.437029262823','8750.437029262822762','test','test','0.0'),('2019-02-09 23:59:59','2019-02-10 03:59:59','TRXUSDT','4h','0.026230000000000','0.025580000000000','235.571487535565467','229.733841065946052','8980.994568645272','8980.994568645272011','test','test','0.0'),('2019-02-20 07:59:59','2019-02-21 11:59:59','TRXUSDT','4h','0.024670000000000','0.024600000000000','234.274232764538937','233.609490312430381','9496.32074440774','9496.320744407739767','test','test','0.0'),('2019-02-22 23:59:59','2019-02-24 15:59:59','TRXUSDT','4h','0.024900000000000','0.023500000000000','234.126512219625937','220.962772576755413','9402.671173478953','9402.671173478953278','test','test','1.20'),('2019-03-16 07:59:59','2019-03-17 07:59:59','TRXUSDT','4h','0.023320000000000','0.022930000000000','231.201236743432474','227.334663744721553','9914.289740284412','9914.289740284411891','test','test','0.0'),('2019-03-17 11:59:59','2019-03-18 11:59:59','TRXUSDT','4h','0.022970000000000','0.022640000000000','230.341998299274536','227.032774988923620','10027.949425305813','10027.949425305812838','test','test','0.74'),('2019-03-23 11:59:59','2019-03-24 23:59:59','TRXUSDT','4h','0.023960000000000','0.023240000000000','229.606615341418745','222.706917384581487','9582.913828940682','9582.913828940681924','test','test','5.50'),('2019-03-27 19:59:59','2019-03-28 03:59:59','TRXUSDT','4h','0.023310000000000','0.022920000000000','228.073349128788209','224.257450108615416','9784.356461981475','9784.356461981475150','test','test','0.30'),('2019-03-28 11:59:59','2019-03-29 11:59:59','TRXUSDT','4h','0.023030000000000','0.023070000000000','227.225371568749807','227.620031354366404','9866.494640414669','9866.494640414668538','test','test','0.47'),('2019-03-29 15:59:59','2019-03-30 07:59:59','TRXUSDT','4h','0.023210000000000','0.023160000000000','227.313073743331302','226.823385949829913','9793.755870027198','9793.755870027198398','test','test','0.64'),('2019-03-30 11:59:59','2019-03-30 19:59:59','TRXUSDT','4h','0.023560000000000','0.023180000000000','227.204254233664301','223.539669487960026','9643.644067642797','9643.644067642797381','test','test','2.07'),('2019-03-30 23:59:59','2019-03-31 11:59:59','TRXUSDT','4h','0.023220000000000','0.023370000000000','226.389902067952249','227.852369135574662','9749.780450816203','9749.780450816202574','test','test','0.64'),('2019-03-31 19:59:59','2019-04-03 23:59:59','TRXUSDT','4h','0.023440000000000','0.025950000000000','226.714894749646163','250.991958991182543','9672.137148022448','9672.137148022447946','test','test','1.10'),('2019-04-04 07:59:59','2019-04-04 19:59:59','TRXUSDT','4h','0.026350000000000','0.025180000000000','232.109797914431994','221.803594363772220','8808.720983469906','8808.720983469906059','test','test','10.8'),('2019-04-05 03:59:59','2019-04-11 03:59:59','TRXUSDT','4h','0.027110000000000','0.027180000000000','229.819530458729815','230.412941271422966','8477.297324187748','8477.297324187748018','test','test','7.11'),('2019-05-07 19:59:59','2019-05-08 03:59:59','TRXUSDT','4h','0.024210000000000','0.024630000000000','229.951399528217166','233.940643138372081','9498.199071797488','9498.199071797487704','test','test','0.0'),('2019-05-08 07:59:59','2019-05-09 07:59:59','TRXUSDT','4h','0.024650000000000','0.023830000000000','230.837898108251608','223.158909205664770','9364.620612910816','9364.620612910815908','test','test','3.24'),('2019-05-11 15:59:59','2019-05-12 11:59:59','TRXUSDT','4h','0.025250000000000','0.024020000000000','229.131456129898993','217.969804999610830','9074.513114055406','9074.513114055405822','test','test','5.62'),('2019-05-12 19:59:59','2019-05-12 23:59:59','TRXUSDT','4h','0.023810000000000','0.023760000000000','226.651089212057173','226.175131443867201','9519.155363799126','9519.155363799125553','test','test','0.0'),('2019-05-13 11:59:59','2019-05-13 23:59:59','TRXUSDT','4h','0.024720000000000','0.024330000000000','226.545320819126090','222.971183476105921','9164.454725692804','9164.454725692803549','test','test','3.88'),('2019-05-14 03:59:59','2019-05-17 03:59:59','TRXUSDT','4h','0.025740000000000','0.026060000000000','225.751068076232713','228.557608161096539','8770.437765199407','8770.437765199407295','test','test','6.68'),('2019-05-19 07:59:59','2019-05-20 15:59:59','TRXUSDT','4h','0.028200000000000','0.027310000000000','226.374743650646877','219.230292521247037','8027.4731791009535','8027.473179100953530','test','test','9.29'),('2019-05-20 19:59:59','2019-05-22 11:59:59','TRXUSDT','4h','0.027790000000000','0.027420000000000','224.787087844113586','221.794240686779233','8088.776100903692','8088.776100903692168','test','test','5.00'),('2019-05-22 15:59:59','2019-05-22 23:59:59','TRXUSDT','4h','0.028080000000000','0.026550000000000','224.122010698039276','211.910234474107654','7981.553087537011','7981.553087537011379','test','test','2.45'),('2019-05-25 03:59:59','2019-05-26 03:59:59','TRXUSDT','4h','0.028090000000000','0.027220000000000','221.408282648276696','214.550852747813877','7882.103333865315','7882.103333865315108','test','test','5.48'),('2019-05-26 07:59:59','2019-05-30 23:59:59','TRXUSDT','4h','0.028750000000000','0.031020000000000','219.884409337062721','237.245717482980353','7648.153368245659','7648.153368245659294','test','test','5.32'),('2019-06-01 07:59:59','2019-06-03 23:59:59','TRXUSDT','4h','0.034910000000000','0.033750000000000','223.742477813933306','216.307895337159863','6409.1228248047355','6409.122824804735501','test','test','11.1'),('2019-06-16 15:59:59','2019-06-16 23:59:59','TRXUSDT','4h','0.033560000000000','0.032810000000000','222.090348374650347','217.127065857338408','6617.710023082549','6617.710023082549014','test','test','0.0'),('2019-06-17 03:59:59','2019-06-18 07:59:59','TRXUSDT','4h','0.033000000000000','0.032640000000000','220.987396704136586','218.576625103727821','6696.587778913229','6696.587778913229158','test','test','0.87'),('2019-06-18 11:59:59','2019-06-18 15:59:59','TRXUSDT','4h','0.032840000000000','0.032720000000000','220.451669681823518','219.646121558747410','6712.90102563409','6712.901025634089820','test','test','0.60'),('2019-06-18 19:59:59','2019-06-18 23:59:59','TRXUSDT','4h','0.032860000000000','0.033090000000000','220.272658987806608','221.814433533369453','6703.3675894037315','6703.367589403731472','test','test','0.42'),('2019-06-19 07:59:59','2019-06-20 11:59:59','TRXUSDT','4h','0.033670000000000','0.032580000000000','220.615275553487237','213.473290096008753','6552.280236218808','6552.280236218807659','test','test','1.93'),('2019-06-21 11:59:59','2019-06-21 15:59:59','TRXUSDT','4h','0.033490000000000','0.032900000000000','219.028167674047580','215.169504821623320','6540.106529532624','6540.106529532624336','test','test','2.71'),('2019-06-21 19:59:59','2019-06-26 23:59:59','TRXUSDT','4h','0.033170000000000','0.036770000000000','218.170687040175494','241.849145687888239','6577.349624364652','6577.349624364652300','test','test','0.81'),('2019-07-08 07:59:59','2019-07-10 11:59:59','TRXUSDT','4h','0.035120000000000','0.033510000000000','223.432566739667237','213.189786772387492','6361.975134956357','6361.975134956356669','test','test','5.78'),('2019-07-21 07:59:59','2019-07-21 19:59:59','TRXUSDT','4h','0.029050000000000','0.027740000000000','221.156393413605088','211.183420078946824','7612.956744013944','7612.956744013944444','test','test','0.0'),('2019-07-21 23:59:59','2019-07-22 23:59:59','TRXUSDT','4h','0.029160000000000','0.026610000000000','218.940177117014372','199.794173974065615','7508.236526646584','7508.236526646584025','test','test','4.86'),('2019-09-15 07:59:59','2019-09-15 19:59:59','TRXUSDT','4h','0.015800000000000','0.015470000000000','214.685509751914623','210.201571890007529','13587.690490627507','13587.690490627506733','test','test','0.0'),('2019-09-15 23:59:59','2019-09-16 15:59:59','TRXUSDT','4h','0.015520000000000','0.015370000000000','213.689079115935300','211.623785181180750','13768.626231696862','13768.626231696862305','test','test','0.32'),('2019-09-16 19:59:59','2019-09-16 23:59:59','TRXUSDT','4h','0.015440000000000','0.015650000000000','213.230124908212019','216.130275570823727','13810.241250531866','13810.241250531866172','test','test','0.45'),('2019-09-17 03:59:59','2019-09-22 19:59:59','TRXUSDT','4h','0.015660000000000','0.016580000000000','213.874602833236850','226.439394315138372','13657.382045545137','13657.382045545136862','test','test','0.06'),('2019-10-05 03:59:59','2019-10-06 19:59:59','TRXUSDT','4h','0.014570000000000','0.014630000000000','216.666778718103870','217.559023517217554','14870.74665189457','14870.746651894569368','test','test','0.0'),('2019-10-07 03:59:59','2019-10-11 03:59:59','TRXUSDT','4h','0.014800000000000','0.016360000000000','216.865055340129146','239.723804416521148','14653.044279738455','14653.044279738454861','test','test','1.89'),('2019-10-14 03:59:59','2019-10-15 19:59:59','TRXUSDT','4h','0.016460000000000','0.015610000000000','221.944777357105096','210.483473544617937','13483.886838220238','13483.886838220238133','test','test','0.60'),('2019-10-25 23:59:59','2019-10-31 03:59:59','TRXUSDT','4h','0.017640000000000','0.020140000000000','219.397820954330200','250.491616441055044','12437.518194689921','12437.518194689921074','test','test','11.5'),('2019-11-02 19:59:59','2019-11-03 11:59:59','TRXUSDT','4h','0.020120000000000','0.019490000000000','226.307553284713521','219.221382381663346','11247.890322301866','11247.890322301866036','test','test','17.5'),('2019-11-05 19:59:59','2019-11-07 11:59:59','TRXUSDT','4h','0.019920000000000','0.019340000000000','224.732848639591225','218.189422323779837','11281.76951001964','11281.769510019639711','test','test','2.15'),('2019-11-13 07:59:59','2019-11-14 11:59:59','TRXUSDT','4h','0.019730000000000','0.019240000000000','223.278753902744256','217.733564373481983','11316.71332502505','11316.713325025049926','test','test','1.97'),('2019-11-14 15:59:59','2019-11-14 19:59:59','TRXUSDT','4h','0.019280000000000','0.019240000000000','222.046489562908192','221.585812198669828','11516.93410595997','11516.934105959970111','test','test','0.20'),('2019-11-29 23:59:59','2019-11-30 11:59:59','TRXUSDT','4h','0.016140000000000','0.015590000000000','221.944116815299680','214.380965374877405','13751.18443713133','13751.184437131329105','test','test','0.0'),('2019-12-22 19:59:59','2019-12-23 19:59:59','TRXUSDT','4h','0.014840000000000','0.014040000000000','220.263416495205860','208.389377870127362','14842.548281348103','14842.548281348103046','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 13:17:28
