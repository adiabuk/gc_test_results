-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-03 19:59:59','EOSUSDT','4h','2.568600000000000','2.595500000000000','222.222222222222200','224.549473556714815','86.5149194978674','86.514919497867396','test','test','0.0'),('2019-01-03 23:59:59','2019-01-04 03:59:59','EOSUSDT','4h','2.637900000000000','2.674600000000000','222.739389185442832','225.838269197234666','84.43814746026871','84.438147460268709','test','test','1.60'),('2019-01-04 07:59:59','2019-01-04 15:59:59','EOSUSDT','4h','2.702300000000000','2.616900000000000','223.428029188063221','216.367098243067971','82.68069022242653','82.680690222426534','test','test','2.94'),('2019-01-05 03:59:59','2019-01-06 03:59:59','EOSUSDT','4h','2.713900000000000','2.635700000000000','221.858933422508727','215.466152334907775','81.7491187672754','81.749118767275405','test','test','3.57'),('2019-01-06 11:59:59','2019-01-10 07:59:59','EOSUSDT','4h','2.692300000000000','2.659100000000000','220.438315403041855','217.719988295594334','81.87732251347987','81.877322513479868','test','test','2.10'),('2019-01-25 07:59:59','2019-01-25 11:59:59','EOSUSDT','4h','2.439000000000000','2.423800000000000','219.834242712497939','218.464222011706624','90.13294084153257','90.132940841532573','test','test','0.0'),('2019-01-25 15:59:59','2019-01-25 19:59:59','EOSUSDT','4h','2.432600000000000','2.419200000000000','219.529793667877613','218.320511732849440','90.24492052449133','90.244920524491334','test','test','0.36'),('2019-01-25 23:59:59','2019-01-26 15:59:59','EOSUSDT','4h','2.428500000000000','2.420200000000000','219.261064348982501','218.511685376737660','90.28662316202697','90.286623162026970','test','test','0.38'),('2019-02-03 23:59:59','2019-02-05 15:59:59','EOSUSDT','4h','2.370700000000000','2.377700000000000','219.094535688483660','219.741459276377270','92.41765541337313','92.417655413373126','test','test','0.0'),('2019-02-05 19:59:59','2019-02-06 03:59:59','EOSUSDT','4h','2.382200000000000','2.325700000000000','219.238296485793370','214.038496405427594','92.03185982948256','92.031859829482556','test','test','0.18'),('2019-02-08 11:59:59','2019-02-14 11:59:59','EOSUSDT','4h','2.428500000000000','2.730200000000000','218.082785356823166','245.175878353386281','89.80143518913863','89.801435189138630','test','test','4.23'),('2019-02-16 11:59:59','2019-02-24 15:59:59','EOSUSDT','4h','2.812500000000000','3.570400000000000','224.103472689392760','284.493880494296150','79.68123473400631','79.681234734006310','test','test','13.9'),('2019-03-06 07:59:59','2019-03-08 23:59:59','EOSUSDT','4h','3.739300000000000','3.589700000000000','237.523563312704624','228.020842196030230','63.52086307937438','63.520863079374379','test','test','28.8'),('2019-03-09 07:59:59','2019-03-10 15:59:59','EOSUSDT','4h','3.753600000000000','3.685900000000000','235.411847508999159','231.165955012100369','62.71628503543243','62.716285035432428','test','test','28.7'),('2019-03-15 19:59:59','2019-03-18 15:59:59','EOSUSDT','4h','3.699100000000000','3.705600000000000','234.468315843021657','234.880319858317193','63.38523312238697','63.385233122386971','test','test','0.35'),('2019-03-27 03:59:59','2019-03-30 23:59:59','EOSUSDT','4h','4.036000000000000','4.150200000000000','234.559872290865115','241.196824078679015','58.11691583024409','58.116915830244089','test','test','8.18'),('2019-04-01 23:59:59','2019-04-02 03:59:59','EOSUSDT','4h','4.204300000000000','4.182900000000000','236.034750465934877','234.833327242099529','56.14127214183928','56.141272141839281','test','test','1.28'),('2019-04-02 07:59:59','2019-04-11 11:59:59','EOSUSDT','4h','4.533900000000000','5.246600000000000','235.767767527304812','272.828948390735889','52.0010956411268','52.001095641126803','test','test','7.74'),('2019-04-15 15:59:59','2019-04-15 19:59:59','EOSUSDT','4h','5.484400000000000','5.269100000000000','244.003585496956163','234.424785271317120','44.49047945025092','44.490479450250923','test','test','4.33'),('2019-04-15 23:59:59','2019-04-16 03:59:59','EOSUSDT','4h','5.323400000000000','5.341200000000000','241.874963224591937','242.683727237327730','45.43618049077505','45.436180490775051','test','test','1.02'),('2019-04-16 11:59:59','2019-04-16 15:59:59','EOSUSDT','4h','5.383300000000000','5.366300000000000','242.054688560755466','241.290300600669099','44.963997652138175','44.963997652138175','test','test','0.78'),('2019-04-16 19:59:59','2019-04-19 03:59:59','EOSUSDT','4h','5.452900000000000','5.401800000000000','241.884824569625124','239.618083104440018','44.35893278248733','44.358932782487329','test','test','1.58'),('2019-04-19 07:59:59','2019-04-20 15:59:59','EOSUSDT','4h','5.441400000000000','5.422400000000000','241.381104244028421','240.538262148127245','44.36011031058706','44.360110310587061','test','test','0.72'),('2019-05-03 23:59:59','2019-05-04 15:59:59','EOSUSDT','4h','5.084100000000000','4.847800000000000','241.193806000494845','229.983543346747496','47.4408068292313','47.440806829231299','test','test','0.0'),('2019-05-04 19:59:59','2019-05-04 23:59:59','EOSUSDT','4h','4.859800000000000','4.947200000000000','238.702636521884301','242.995531380111515','49.11779013989965','49.117790139899647','test','test','0.24'),('2019-05-05 15:59:59','2019-05-05 19:59:59','EOSUSDT','4h','4.888500000000000','4.909200000000000','239.656613157045939','240.671421767529921','49.0245705547808','49.024570554780802','test','test','0.0'),('2019-05-07 03:59:59','2019-05-07 15:59:59','EOSUSDT','4h','4.999100000000000','4.852100000000000','239.882126181597897','232.828321987103891','47.98506254757814','47.985062547578138','test','test','1.79'),('2019-05-07 19:59:59','2019-05-07 23:59:59','EOSUSDT','4h','4.885000000000000','4.849200000000000','238.314614138377038','236.568111950832758','48.78497730570666','48.784977305706661','test','test','0.67'),('2019-05-08 11:59:59','2019-05-08 15:59:59','EOSUSDT','4h','4.908600000000000','4.910000000000000','237.926502541144941','237.994362440822584','48.471356912591155','48.471356912591155','test','test','1.21'),('2019-05-08 23:59:59','2019-05-09 07:59:59','EOSUSDT','4h','4.900000000000000','4.888100000000000','237.941582518851163','237.363724389876779','48.55950663650023','48.559506636500231','test','test','0.0'),('2019-05-11 11:59:59','2019-05-17 11:59:59','EOSUSDT','4h','5.276000000000000','5.801400000000000','237.813169601301269','261.495322616563556','45.0745203944847','45.074520394484701','test','test','7.35'),('2019-05-19 07:59:59','2019-05-22 23:59:59','EOSUSDT','4h','6.312500000000000','5.928500000000000','243.075870271359548','228.289155945149304','38.50706855783913','38.507068557839133','test','test','22.2'),('2019-05-24 15:59:59','2019-05-30 23:59:59','EOSUSDT','4h','6.392300000000000','7.300000000000000','239.789933754423942','273.839856766311811','37.51230914607011','37.512309146070109','test','test','22.6'),('2019-05-31 23:59:59','2019-06-01 23:59:59','EOSUSDT','4h','8.564500000000001','7.702700000000000','247.356583312621268','222.466408346328166','28.881614024475596','28.881614024475596','test','test','36.6'),('2019-06-15 19:59:59','2019-06-18 15:59:59','EOSUSDT','4h','6.884700000000000','6.857200000000000','241.825433320111642','240.859494438780160','35.12505023023685','35.125050230236852','test','test','0.0'),('2019-06-21 07:59:59','2019-06-21 15:59:59','EOSUSDT','4h','6.997600000000000','6.909200000000000','241.610780235371323','238.558534755091387','34.52766380407159','34.527663804071587','test','test','2.00'),('2019-06-21 19:59:59','2019-06-24 15:59:59','EOSUSDT','4h','6.974600000000000','7.161200000000000','240.932503461975813','247.378465258495311','34.544275436867466','34.544275436867466','test','test','0.93'),('2019-06-26 11:59:59','2019-06-26 23:59:59','EOSUSDT','4h','7.380200000000000','6.809600000000000','242.364939416757920','223.626499478652960','32.83988772889053','32.839887728890531','test','test','2.96'),('2019-07-25 11:59:59','2019-07-27 11:59:59','EOSUSDT','4h','4.590400000000000','4.358800000000000','238.200841652734539','226.182866111001061','51.89108610420324','51.891086104203239','test','test','0.0'),('2019-08-05 19:59:59','2019-08-06 11:59:59','EOSUSDT','4h','4.505900000000000','4.335800000000000','235.530180421238242','226.638797192659581','52.2715063408505','52.271506340850500','test','test','3.26'),('2019-09-08 03:59:59','2019-09-11 15:59:59','EOSUSDT','4h','3.644500000000000','3.672200000000000','233.554317481554079','235.329445645702521','64.08404924723668','64.084049247236678','test','test','0.0'),('2019-09-14 15:59:59','2019-09-19 03:59:59','EOSUSDT','4h','3.936100000000000','3.887800000000000','233.948790406920438','231.077997851687002','59.436698866116316','59.436698866116316','test','test','9.08'),('2019-10-07 23:59:59','2019-10-10 11:59:59','EOSUSDT','4h','3.175900000000000','3.110000000000000','233.310836505757408','228.469631138545139','73.46290390306918','73.462903903069176','test','test','0.0'),('2019-10-10 15:59:59','2019-10-10 23:59:59','EOSUSDT','4h','3.113800000000000','3.105300000000000','232.235013090821354','231.601061773693772','74.582507897367','74.582507897366995','test','test','0.12'),('2019-10-14 03:59:59','2019-10-14 19:59:59','EOSUSDT','4h','3.123800000000000','3.158800000000000','232.094135020348546','234.694587906484713','74.29865388960513','74.298653889605134','test','test','0.59'),('2019-10-14 23:59:59','2019-10-15 07:59:59','EOSUSDT','4h','3.163400000000000','3.113000000000000','232.672013439489973','228.965030611725439','73.55124658262943','73.551246582629432','test','test','1.11'),('2019-10-26 03:59:59','2019-10-30 15:59:59','EOSUSDT','4h','3.291700000000000','3.246300000000000','231.848239477764508','228.650527027574498','70.4341949381063','70.434194938106302','test','test','7.00'),('2019-11-01 23:59:59','2019-11-03 15:59:59','EOSUSDT','4h','3.341900000000000','3.273900000000000','231.137636711055620','226.434515942525223','69.16354071368252','69.163540713682522','test','test','6.84'),('2019-11-04 11:59:59','2019-11-07 15:59:59','EOSUSDT','4h','3.369100000000000','3.447100000000000','230.092498762493307','235.419504462375869','68.29494487028978','68.294944870289783','test','test','6.24'),('2019-11-10 07:59:59','2019-11-11 11:59:59','EOSUSDT','4h','3.544500000000000','3.460800000000000','231.276277806911622','225.814908233646406','65.24933779289367','65.249337792893670','test','test','2.74'),('2019-11-11 15:59:59','2019-11-11 19:59:59','EOSUSDT','4h','3.462600000000000','3.474200000000000','230.062640123963803','230.833369236606927','66.44216488302541','66.442164883025413','test','test','0.05'),('2019-12-08 11:59:59','2019-12-09 15:59:59','EOSUSDT','4h','2.736900000000000','2.679000000000000','230.233913260106732','225.363240755535799','84.12215033801262','84.122150338012617','test','test','0.0'),('2019-12-23 11:59:59','2019-12-24 07:59:59','EOSUSDT','4h','2.547200000000000','2.487200000000000','229.151541592424309','223.753813696874118','89.96213159250325','89.962131592503255','test','test','0.0'),('2019-12-24 11:59:59','2019-12-25 15:59:59','EOSUSDT','4h','2.515000000000000','2.474800000000000','227.952046504524219','224.308439240316716','90.63699662207722','90.636996622077220','test','test','1.10'),('2019-12-26 19:59:59','2019-12-26 23:59:59','EOSUSDT','4h','2.574200000000000','2.516900000000000','227.142356001367034','222.086316455536007','88.23803744905875','88.238037449058751','test','test','3.86'),('2019-12-27 03:59:59','2019-12-31 03:59:59','EOSUSDT','4h','2.553100000000000','2.622300000000000','226.018791657849050','232.144873825693310','88.52719895728684','88.527198957286842','test','test','1.41');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 13:32:32
