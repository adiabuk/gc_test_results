-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 19:59:59','2019-01-03 19:59:59','BTCUSDT','4h','3824.980000000000018','3756.000000000000000','222.222222222222200','218.214648616899069','0.058097616777662155','0.058097616777662','test','test','0.0'),('2019-01-03 23:59:59','2019-01-04 03:59:59','BTCUSDT','4h','3766.780000000000200','3780.039999999999964','221.331650309928165','222.110792623285874','0.058758847161216786','0.058758847161217','test','test','0.28'),('2019-01-04 07:59:59','2019-01-04 11:59:59','BTCUSDT','4h','3783.280000000000200','3757.550000000000182','221.504793046229906','219.998344058822283','0.05854834774223158','0.058548347742232','test','test','0.08'),('2019-01-05 03:59:59','2019-01-05 23:59:59','BTCUSDT','4h','3815.000000000000000','3770.960000000000036','221.170026604583768','218.616860688026520','0.05797379465388827','0.057973794653888','test','test','1.50'),('2019-01-06 03:59:59','2019-01-06 07:59:59','BTCUSDT','4h','3771.150000000000091','3767.940000000000055','220.602656400904380','220.414879588248567','0.05849744942548145','0.058497449425481','test','test','0.00'),('2019-01-06 11:59:59','2019-01-10 07:59:59','BTCUSDT','4h','3814.239999999999782','3777.019999999999982','220.560928220314196','218.408657322740879','0.057825655496328024','0.057825655496328','test','test','1.21'),('2019-02-09 07:59:59','2019-02-13 15:59:59','BTCUSDT','4h','3660.860000000000127','3595.099999999999909','220.082645798631233','216.129302926268451','0.0601177444094096','0.060117744409410','test','test','0.0'),('2019-02-16 11:59:59','2019-02-24 15:59:59','BTCUSDT','4h','3626.010000000000218','3778.650000000000091','219.204125160328402','228.431710761160332','0.060453259963521445','0.060453259963521','test','test','0.85'),('2019-03-06 23:59:59','2019-03-08 23:59:59','BTCUSDT','4h','3861.840000000000146','3864.889999999999873','221.254699738291038','221.429442046155089','0.05729255995543343','0.057292559955433','test','test','2.19'),('2019-03-09 03:59:59','2019-03-11 07:59:59','BTCUSDT','4h','3876.800000000000182','3885.500000000000000','221.293531362260836','221.790140349789624','0.057081492819402814','0.057081492819403','test','test','0.30'),('2019-03-15 11:59:59','2019-03-21 15:59:59','BTCUSDT','4h','3914.050000000000182','3968.659999999999854','221.403888915045030','224.492982404819173','0.05656644368749633','0.056566443687496','test','test','0.72'),('2019-03-23 23:59:59','2019-03-24 03:59:59','BTCUSDT','4h','4006.010000000000218','3988.000000000000000','222.090354134994840','221.091892504102418','0.05543929099902267','0.055439290999023','test','test','0.93'),('2019-03-27 23:59:59','2019-04-11 11:59:59','BTCUSDT','4h','4038.050000000000182','5001.909999999999854','221.868473772574276','274.827240288698022','0.054944459274296815','0.054944459274297','test','test','1.23'),('2019-04-15 03:59:59','2019-04-15 19:59:59','BTCUSDT','4h','5136.880000000000109','5005.840000000000146','233.637088553935115','227.677088693298373','0.04548229441877854','0.045482294418779','test','test','2.62'),('2019-04-16 19:59:59','2019-04-21 15:59:59','BTCUSDT','4h','5158.140000000000327','5239.420000000000073','232.312644140460293','235.973338056433221','0.04503806491108428','0.045038064911084','test','test','2.95'),('2019-04-22 15:59:59','2019-04-25 23:59:59','BTCUSDT','4h','5279.689999999999600','5219.899999999999636','233.126131677343125','230.486088149600334','0.04415526890354228','0.044155268903542','test','test','0.76'),('2019-05-01 11:59:59','2019-05-06 11:59:59','BTCUSDT','4h','5362.140000000000327','5701.670000000000073','232.539455337844771','247.263823084837270','0.04336691234056641','0.043366912340566','test','test','2.65'),('2019-05-06 15:59:59','2019-05-17 03:59:59','BTCUSDT','4h','5730.979999999999563','7344.029999999999745','235.811537059398660','302.183396646007395','0.041146808584116276','0.041146808584116','test','test','0.51'),('2019-05-19 11:59:59','2019-05-22 23:59:59','BTCUSDT','4h','7964.409999999999854','7628.430000000000291','250.560839189756138','239.990887272291559','0.03146006285333831','0.031460062853338','test','test','7.78'),('2019-05-24 07:59:59','2019-05-30 23:59:59','BTCUSDT','4h','7852.270000000000437','8269.540000000000873','248.211960985875095','261.401956357987387','0.03161021729842136','0.031610217298421','test','test','2.85'),('2019-06-02 03:59:59','2019-06-03 07:59:59','BTCUSDT','4h','8544.100000000000364','8470.000000000000000','251.143071068566769','248.964994785964620','0.029393742005426757','0.029393742005427','test','test','3.21'),('2019-06-03 11:59:59','2019-06-03 15:59:59','BTCUSDT','4h','8507.840000000000146','8473.659999999999854','250.659054116877400','249.652038650000378','0.02946212600576379','0.029462126005764','test','test','0.44'),('2019-06-13 15:59:59','2019-06-27 19:59:59','BTCUSDT','4h','8172.109999999999673','11022.010000000000218','250.435272902015839','337.770793868260171','0.03064511771158438','0.030645117711584','test','test','0.0'),('2019-06-28 19:59:59','2019-06-29 03:59:59','BTCUSDT','4h','12368.430000000000291','11616.290000000000873','269.843166450070100','253.433659405622620','0.02181709129210984','0.021817091292110','test','test','31.4'),('2019-06-30 03:59:59','2019-06-30 07:59:59','BTCUSDT','4h','12133.799999999999272','11731.190000000000509','266.196609329081809','257.363975126937305','0.021938437202614337','0.021938437202614','test','test','4.26'),('2019-07-04 11:59:59','2019-07-04 23:59:59','BTCUSDT','4h','11672.129999999999200','11145.670000000000073','264.233801728605215','252.315794710345386','0.022638010519811316','0.022638010519811','test','test','0.0'),('2019-07-05 03:59:59','2019-07-05 07:59:59','BTCUSDT','4h','11154.559999999999491','10982.729999999999563','261.585355724547469','257.555773950443552','0.023450979305732138','0.023450979305732','test','test','0.07'),('2019-07-06 15:59:59','2019-07-06 23:59:59','BTCUSDT','4h','11574.319999999999709','11256.489999999999782','260.689893108079957','253.531367274463719','0.02252312819311026','0.022523128193110','test','test','5.11'),('2019-07-07 19:59:59','2019-07-08 03:59:59','BTCUSDT','4h','11474.180000000000291','11346.340000000000146','259.099109589498596','256.212347296252233','0.02258105673690831','0.022581056736908','test','test','1.89'),('2019-07-08 07:59:59','2019-07-10 23:59:59','BTCUSDT','4h','11420.549999999999272','12108.370000000000800','258.457606857666008','274.023609471273971','0.022630924680305767','0.022630924680306','test','test','0.64'),('2019-08-01 23:59:59','2019-08-10 11:59:59','BTCUSDT','4h','10374.989999999999782','11395.229999999999563','261.916718549578945','287.672686789839645','0.025245009252980382','0.025245009252980','test','test','0.0'),('2019-09-03 11:59:59','2019-09-06 23:59:59','BTCUSDT','4h','10424.500000000000000','10298.729999999999563','267.640267047414625','264.411228111585217','0.02567415866923254','0.025674158669233','test','test','0.85'),('2019-09-14 07:59:59','2019-09-14 15:59:59','BTCUSDT','4h','10319.000000000000000','10356.319999999999709','266.922702839452541','267.888063365663243','0.025867109491176717','0.025867109491177','test','test','0.24'),('2019-09-14 19:59:59','2019-09-15 07:59:59','BTCUSDT','4h','10363.729999999999563','10308.420000000000073','267.137227400832728','265.711547645808253','0.025776166245244977','0.025776166245245','test','test','0.62'),('2019-09-15 15:59:59','2019-09-15 23:59:59','BTCUSDT','4h','10307.969999999999345','10302.010000000000218','266.820409677493956','266.666135883364007','0.025884864786907023','0.025884864786907','test','test','0.0'),('2019-09-16 07:59:59','2019-09-16 11:59:59','BTCUSDT','4h','10302.250000000000000','10283.790000000000873','266.786126612131739','266.308088135366006','0.025895908817212914','0.025895908817213','test','test','0.06'),('2019-10-10 07:59:59','2019-10-11 11:59:59','BTCUSDT','4h','8613.729999999999563','8297.500000000000000','266.679895839517144','256.889458542163936','0.030959862433523822','0.030959862433524','test','test','0.0'),('2019-10-11 15:59:59','2019-10-11 19:59:59','BTCUSDT','4h','8343.469999999999345','8344.010000000000218','264.504243106771980','264.521362158111287','0.031701946924573586','0.031701946924574','test','test','0.55'),('2019-10-13 19:59:59','2019-10-13 23:59:59','BTCUSDT','4h','8434.020000000000437','8275.010000000000218','264.508047340402925','259.521169836247452','0.03136203700493986','0.031362037004940','test','test','1.06'),('2019-10-22 11:59:59','2019-10-22 23:59:59','BTCUSDT','4h','8276.159999999999854','8020.000000000000000','263.399852339479480','255.247218004802420','0.03182633640957636','0.031826336409576','test','test','1.30'),('2019-10-26 03:59:59','2019-10-30 11:59:59','BTCUSDT','4h','9554.049999999999272','9097.690000000000509','261.588155820662337','249.093101807932953','0.027379818592184715','0.027379818592185','test','test','16.0'),('2019-11-02 03:59:59','2019-11-03 19:59:59','BTCUSDT','4h','9236.670000000000073','9135.120000000000800','258.811477151166912','255.966046329810212','0.028019998240834294','0.028019998240834','test','test','10.4'),('2019-11-04 15:59:59','2019-11-07 07:59:59','BTCUSDT','4h','9295.159999999999854','9258.950000000000728','258.179159190865448','257.173402716065539','0.027775655200218765','0.027775655200219','test','test','1.72'),('2019-12-07 11:59:59','2019-12-08 03:59:59','BTCUSDT','4h','7524.979999999999563','7403.909999999999854','257.955657752021011','253.805388716882419','0.034279912737578175','0.034279912737578','test','test','0.0'),('2019-12-08 07:59:59','2019-12-08 11:59:59','BTCUSDT','4h','7434.630000000000109','7520.029999999999745','257.033375744212492','259.985862994896877','0.034572450242206065','0.034572450242206','test','test','0.41'),('2019-12-08 15:59:59','2019-12-09 15:59:59','BTCUSDT','4h','7546.000000000000000','7424.000000000000000','257.689484022142267','253.523287752502540','0.034149149751145275','0.034149149751145','test','test','0.99'),('2019-12-21 19:59:59','2019-12-24 19:59:59','BTCUSDT','4h','7145.819999999999709','7253.770000000000437','256.763662628889051','260.642522910954483','0.035932008171055116','0.035932008171055','test','test','0.0'),('2019-12-28 11:59:59','2019-12-30 15:59:59','BTCUSDT','4h','7308.279999999999745','7262.079999999999927','257.625631580459128','255.997026193279510','0.035251198856702144','0.035251198856702','test','test','2.34');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 14:48:03
