-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-14 15:59:59','THETAETH','4h','0.000363560000000','0.000358480000000','1.297777777777778','1.279644014131857','3569.6385129766136','3569.638512976613583','test','test','1.39'),('2019-01-15 23:59:59','2019-01-28 07:59:59','THETAETH','4h','0.000378740000000','0.000480220000000','1.293748052523129','1.640396287116906','3415.926631787317','3415.926631787317092','test','test','0.0'),('2019-01-29 23:59:59','2019-01-30 03:59:59','THETAETH','4h','0.000500890000000','0.000494190000000','1.370780993543968','1.352445166003501','2736.6906776816622','2736.690677681662237','test','test','1.33'),('2019-01-30 07:59:59','2019-01-30 11:59:59','THETAETH','4h','0.000499360000000','0.000493760000000','1.366706365201642','1.351379635697618','2736.9159828613465','2736.915982861346492','test','test','1.12'),('2019-02-01 15:59:59','2019-02-08 19:59:59','THETAETH','4h','0.000505340000000','0.000602010000000','1.363300425311859','1.624095636684198','2697.788469766611','2697.788469766610888','test','test','0.0'),('2019-02-09 23:59:59','2019-02-12 15:59:59','THETAETH','4h','0.000658870000000','0.000686910000000','1.421254916727934','1.481740274788024','2157.109773897634','2157.109773897634113','test','test','0.0'),('2019-02-13 23:59:59','2019-02-16 11:59:59','THETAETH','4h','0.000750720000000','0.000703600000000','1.434696107407954','1.344645381996266','1911.0934934568872','1911.093493456887245','test','test','6.27'),('2019-02-25 15:59:59','2019-03-03 23:59:59','THETAETH','4h','0.000759600000000','0.000999490000000','1.414684835094246','1.861457801248483','1862.407629139344','1862.407629139343953','test','test','1.00'),('2019-03-10 03:59:59','2019-03-12 19:59:59','THETAETH','4h','0.001262990000000','0.000976950000000','1.513967716461854','1.171086675743599','1198.717105014176','1198.717105014176013','test','test','22.6'),('2019-04-14 15:59:59','2019-04-15 03:59:59','THETAETH','4h','0.000744230000000','0.000708530000000','1.437771929635575','1.368803387803090','1931.8919280808018','1931.891928080801790','test','test','4.79'),('2019-04-15 07:59:59','2019-04-15 15:59:59','THETAETH','4h','0.000717560000000','0.000708530000000','1.422445587006134','1.404545085792765','1982.3367899633952','1982.336789963395177','test','test','1.25'),('2019-04-15 19:59:59','2019-04-18 07:59:59','THETAETH','4h','0.000740730000000','0.000731410000000','1.418467697847608','1.400620278485709','1914.959159002076','1914.959159002075921','test','test','1.25'),('2019-05-24 15:59:59','2019-05-26 19:59:59','THETAETH','4h','0.000497010000000','0.000469630000000','1.414501604656074','1.336577510703270','2846.022423404105','2846.022423404105211','test','test','5.50'),('2019-05-29 03:59:59','2019-05-29 07:59:59','THETAETH','4h','0.000493580000000','0.000490790000000','1.397185139333229','1.389287439793662','2830.716680848553','2830.716680848553096','test','test','0.56'),('2019-05-29 11:59:59','2019-05-30 19:59:59','THETAETH','4h','0.000577350000000','0.000526170000000','1.395430094991103','1.271730238298205','2416.956949841696','2416.956949841695860','test','test','13.1'),('2019-06-02 11:59:59','2019-06-03 07:59:59','THETAETH','4h','0.000530320000000','0.000511100000000','1.367941237948237','1.318363943874159','2579.4637915753447','2579.463791575344658','test','test','3.62'),('2019-06-03 11:59:59','2019-06-04 03:59:59','THETAETH','4h','0.000511510000000','0.000511790000000','1.356924061487330','1.357666840195892','2652.781102006472','2652.781102006471883','test','test','0.0'),('2019-06-05 03:59:59','2019-06-12 11:59:59','THETAETH','4h','0.000526840000000','0.000565010000000','1.357089123422567','1.455411368963982','2575.9037343834307','2575.903734383430674','test','test','2.26'),('2019-07-07 03:59:59','2019-07-07 19:59:59','THETAETH','4h','0.000421930000000','0.000388810000000','1.378938511320659','1.270696756776208','3268.168917404922','3268.168917404922013','test','test','7.84'),('2019-07-11 11:59:59','2019-07-12 03:59:59','THETAETH','4h','0.000424200000000','0.000393520000000','1.354884788088558','1.256893592193798','3193.9763981342726','3193.976398134272586','test','test','7.23'),('2019-07-12 07:59:59','2019-07-12 11:59:59','THETAETH','4h','0.000397290000000','0.000399570000000','1.333108966778612','1.340759520389967','3355.505969892552','3355.505969892552002','test','test','0.0'),('2019-07-12 15:59:59','2019-07-24 15:59:59','THETAETH','4h','0.000407000000000','0.000555670000000','1.334809089803358','1.822391564941110','3279.6292132760627','3279.629213276062728','test','test','0.0'),('2019-07-25 19:59:59','2019-07-30 19:59:59','THETAETH','4h','0.000591390000000','0.000585670000000','1.443160750945080','1.429202314895424','2440.2860226670728','2440.286022667072757','test','test','3.24'),('2019-07-31 23:59:59','2019-08-02 11:59:59','THETAETH','4h','0.000642610000000','0.000595670000000','1.440058876267379','1.334868537411789','2240.953107277165','2240.953107277165145','test','test','7.30'),('2019-08-12 07:59:59','2019-08-14 03:59:59','THETAETH','4h','0.000598160000000','0.000563980000000','1.416683245410581','1.335731270473886','2368.4018413310505','2368.401841331050491','test','test','5.71'),('2019-08-15 11:59:59','2019-08-15 23:59:59','THETAETH','4h','0.000579000000000','0.000593530000000','1.398693917646871','1.433794129431688','2415.706248094769','2415.706248094768853','test','test','0.83'),('2019-08-16 07:59:59','2019-08-25 19:59:59','THETAETH','4h','0.000588150000000','0.000662840000000','1.406493964710164','1.585106621726575','2391.3864910484804','2391.386491048480366','test','test','1.10'),('2019-08-27 23:59:59','2019-08-28 15:59:59','THETAETH','4h','0.000708420000000','0.000654500000000','1.446185666269366','1.336112078390362','2041.4241075482996','2041.424107548299617','test','test','7.61'),('2019-08-28 19:59:59','2019-08-29 03:59:59','THETAETH','4h','0.000684460000000','0.000645870000000','1.421724868962921','1.341567719248870','2077.1482175188044','2077.148217518804358','test','test','5.63'),('2019-08-29 19:59:59','2019-08-30 11:59:59','THETAETH','4h','0.000679520000000','0.000646440000000','1.403912169026465','1.335567728021939','2066.0350968720054','2066.035096872005397','test','test','4.86'),('2019-08-31 03:59:59','2019-08-31 23:59:59','THETAETH','4h','0.000674330000000','0.000657950000000','1.388724515469904','1.354991317238479','2059.4138114423263','2059.413811442326278','test','test','2.42'),('2019-10-06 23:59:59','2019-10-07 03:59:59','THETAETH','4h','0.000493740000000','0.000477650000000','1.381228249196254','1.336216780549663','2797.480960011856','2797.480960011856041','test','test','3.25'),('2019-10-08 23:59:59','2019-10-09 15:59:59','THETAETH','4h','0.000501890000000','0.000460740000000','1.371225700608123','1.258798799135641','2732.123972599818','2732.123972599817989','test','test','8.19'),('2019-10-15 07:59:59','2019-10-16 11:59:59','THETAETH','4h','0.000503140000000','0.000477830000000','1.346241944725349','1.278520468354958','2675.6806151873207','2675.680615187320655','test','test','5.03'),('2019-10-16 19:59:59','2019-10-17 03:59:59','THETAETH','4h','0.000485140000000','0.000480660000000','1.331192727754151','1.318899898013584','2743.9352099479543','2743.935209947954263','test','test','1.06'),('2019-10-17 11:59:59','2019-10-18 07:59:59','THETAETH','4h','0.000482690000000','0.000477630000000','1.328460987811803','1.314534839355594','2752.203252215299','2752.203252215299017','test','test','1.04'),('2019-10-20 03:59:59','2019-10-20 19:59:59','THETAETH','4h','0.000488220000000','0.000483680000000','1.325366288154867','1.313041592427074','2714.690688941189','2714.690688941188910','test','test','1.29'),('2019-10-20 23:59:59','2019-10-21 11:59:59','THETAETH','4h','0.000489540000000','0.000484400000000','1.322627466882024','1.308740337781698','2701.776089557593','2701.776089557592968','test','test','1.04'),('2019-10-21 15:59:59','2019-10-25 23:59:59','THETAETH','4h','0.000492670000000','0.000537650000000','1.319541438193063','1.440013506494206','2678.3474500031725','2678.347450003172526','test','test','0.16'),('2019-10-29 03:59:59','2019-10-29 23:59:59','THETAETH','4h','0.000566710000000','0.000530450000000','1.346313008926650','1.260171402631225','2375.6648178550763','2375.664817855076308','test','test','6.39'),('2019-10-30 03:59:59','2019-10-30 07:59:59','THETAETH','4h','0.000531360000000','0.000512000000000','1.327170429749889','1.278815228906849','2497.685993958689','2497.685993958688869','test','test','3.64'),('2019-11-16 19:59:59','2019-11-17 03:59:59','THETAETH','4h','0.000490930000000','0.000494210000000','1.316424829562547','1.325220123068679','2681.4919226010775','2681.491922601077476','test','test','0.07'),('2019-11-18 11:59:59','2019-11-20 23:59:59','THETAETH','4h','0.000514220000000','0.000508380000000','1.318379339230576','1.303406496204038','2563.842983996298','2563.842983996297789','test','test','2.51'),('2019-11-27 15:59:59','2019-11-27 19:59:59','THETAETH','4h','0.000510120000000','0.000498920000000','1.315052040780234','1.286179260146778','2577.926842272866','2577.926842272865997','test','test','2.19'),('2019-11-28 07:59:59','2019-11-28 11:59:59','THETAETH','4h','0.000499850000000','0.000504650000000','1.308635867306133','1.321202541634570','2618.0571517577932','2618.057151757793235','test','test','0.0'),('2019-11-28 19:59:59','2019-11-29 03:59:59','THETAETH','4h','0.000503200000000','0.000499580000000','1.311428461601341','1.301994099457071','2606.177387919995','2606.177387919994999','test','test','0.71'),('2019-11-29 07:59:59','2019-11-29 11:59:59','THETAETH','4h','0.000502700000000','0.000492000000000','1.309331936680393','1.281462726967880','2604.599038552601','2604.599038552601087','test','test','2.12'),('2019-11-29 23:59:59','2019-11-30 07:59:59','THETAETH','4h','0.000503220000000','0.000492560000000','1.303138778966501','1.275533637311195','2589.6005305164754','2589.600530516475374','test','test','2.11'),('2019-12-05 15:59:59','2019-12-10 03:59:59','THETAETH','4h','0.000527420000000','0.000550400000000','1.297004303043099','1.353515544338330','2459.1488814286513','2459.148881428651293','test','test','1.06'),('2019-12-11 19:59:59','2019-12-17 23:59:59','THETAETH','4h','0.000594470000000','0.000778510000000','1.309562356664262','1.714985432884241','2202.907390893168','2202.907390893168213','test','test','6.05'),('2019-12-18 07:59:59','2019-12-21 15:59:59','THETAETH','4h','0.000790190000000','0.000782360000000','1.399656373602035','1.385787165683302','1771.290921932744','1771.290921932743913','test','test','3.56');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-01  1:46:08
