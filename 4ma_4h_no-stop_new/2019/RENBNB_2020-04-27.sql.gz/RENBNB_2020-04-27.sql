-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-05-31 03:59:59','2019-06-07 03:59:59','RENBNB','4h','0.001190000000000','0.001310000000000','3.111111111111111','3.424836601307189','2614.37908496732','2614.379084967320068','test','test','0.0'),('2019-06-08 03:59:59','2019-06-11 23:59:59','RENBNB','4h','0.001360000000000','0.001430000000000','3.180827886710240','3.344546969114444','2338.844034345764','2338.844034345764157','test','test','13.9'),('2019-06-16 19:59:59','2019-06-17 23:59:59','RENBNB','4h','0.001560000000000','0.001400000000000','3.217209905022285','2.887239658353333','2062.314041680952','2062.314041680951959','test','test','9.61'),('2019-06-18 07:59:59','2019-06-18 11:59:59','RENBNB','4h','0.001440000000000','0.001420000000000','3.143883183540295','3.100218139324458','2183.2522107918717','2183.252210791871676','test','test','2.77'),('2019-06-22 07:59:59','2019-07-04 11:59:59','RENBNB','4h','0.001480000000000','0.002860000000000','3.134179840381220','6.056590772628574','2117.689081338662','2117.689081338662163','test','test','4.05'),('2019-07-04 19:59:59','2019-07-06 15:59:59','RENBNB','4h','0.003320000000000','0.002930000000000','3.783604491991744','3.339144928173437','1139.639907226429','1139.639907226428932','test','test','56.9'),('2019-07-09 23:59:59','2019-07-12 03:59:59','RENBNB','4h','0.003180000000000','0.003167000000000','3.684835700032119','3.669771906289850','1158.7533647899747','1158.753364789974739','test','test','7.86'),('2019-07-12 07:59:59','2019-07-13 03:59:59','RENBNB','4h','0.003304000000000','0.002979000000000','3.681488190311616','3.319356331397792','1114.2518735809974','1114.251873580997426','test','test','4.87'),('2019-07-21 07:59:59','2019-07-27 19:59:59','RENBNB','4h','0.003194000000000','0.004147000000000','3.601014443886321','4.675456136129172','1127.4309467396122','1127.430946739612182','test','test','6.73'),('2019-07-28 19:59:59','2019-07-29 03:59:59','RENBNB','4h','0.004488000000000','0.004178000000000','3.839779264384733','3.574553869563150','855.5657897470439','855.565789747043937','test','test','29.4'),('2019-08-02 23:59:59','2019-08-03 19:59:59','RENBNB','4h','0.004283000000000','0.004001000000000','3.780840287757714','3.531903336754288','882.7551454022213','882.755145402221274','test','test','2.89'),('2019-08-04 03:59:59','2019-08-04 07:59:59','RENBNB','4h','0.003988000000000','0.003937000000000','3.725520965312508','3.677877643037950','934.1827896972186','934.182789697218595','test','test','0.0'),('2019-08-04 11:59:59','2019-08-04 15:59:59','RENBNB','4h','0.004012000000000','0.004470000000000','3.714933560362607','4.139021190134809','925.9555235200914','925.955523520091447','test','test','1.86'),('2019-08-04 19:59:59','2019-08-07 03:59:59','RENBNB','4h','0.004648000000000','0.004418000000000','3.809175255867541','3.620683364979087','819.5299603845828','819.529960384582751','test','test','13.9'),('2019-09-19 19:59:59','2019-09-22 23:59:59','RENBNB','4h','0.002495000000000','0.002399000000000','3.767288169003440','3.622334395767235','1509.9351378771303','1509.935137877130273','test','test','0.0'),('2019-09-27 03:59:59','2019-09-28 03:59:59','RENBNB','4h','0.002452000000000','0.002408000000000','3.735076219395394','3.668052013174596','1523.277414109051','1523.277414109051051','test','test','2.16'),('2019-09-28 07:59:59','2019-09-30 07:59:59','RENBNB','4h','0.002455000000000','0.002455000000000','3.720181951346328','3.720181951346328','1515.3490636848587','1515.349063684858720','test','test','1.91'),('2019-09-30 15:59:59','2019-09-30 19:59:59','RENBNB','4h','0.002455000000000','0.002534000000000','3.720181951346328','3.839894527377432','1515.3490636848587','1515.349063684858720','test','test','0.0'),('2019-10-01 19:59:59','2019-10-04 03:59:59','RENBNB','4h','0.002597000000000','0.002545000000000','3.746784746019906','3.671762486954433','1442.7357512591088','1442.735751259108838','test','test','2.42'),('2019-10-04 11:59:59','2019-10-12 19:59:59','RENBNB','4h','0.002620000000000','0.003302000000000','3.730113132894246','4.701081513288855','1423.7073026313917','1423.707302631391713','test','test','2.86'),('2019-10-12 23:59:59','2019-10-13 15:59:59','RENBNB','4h','0.003582000000000','0.003389000000000','3.945883884093048','3.733277633498420','1101.586790645742','1101.586790645741985','test','test','7.81'),('2019-10-14 11:59:59','2019-10-15 11:59:59','RENBNB','4h','0.003619000000000','0.003395000000000','3.898638050627575','3.657329699331478','1077.2694254290068','1077.269425429006787','test','test','6.85'),('2019-11-07 03:59:59','2019-11-10 19:59:59','RENBNB','4h','0.002933000000000','0.002726000000000','3.845013972561775','3.573647490352335','1310.9491894175846','1310.949189417584648','test','test','0.0'),('2019-11-12 11:59:59','2019-11-12 19:59:59','RENBNB','4h','0.002950000000000','0.002801000000000','3.784710309848566','3.593550365385028','1282.9526474062936','1282.952647406293636','test','test','7.59'),('2019-11-14 23:59:59','2019-11-15 07:59:59','RENBNB','4h','0.002881000000000','0.002810000000000','3.742230322190003','3.650005972007604','1298.9345096112472','1298.934509611247222','test','test','2.77'),('2019-11-15 11:59:59','2019-11-17 07:59:59','RENBNB','4h','0.002844000000000','0.002798000000000','3.721736022149470','3.661539166657601','1308.6272933015011','1308.627293301501140','test','test','1.19'),('2019-11-21 19:59:59','2019-11-24 07:59:59','RENBNB','4h','0.002916000000000','0.002873000000000','3.708358943151277','3.653674637748155','1271.7280326307532','1271.728032630753205','test','test','4.04'),('2019-12-15 19:59:59','2019-12-16 11:59:59','RENBNB','4h','0.002457000000000','0.002408000000000','3.696206875283916','3.622493347856602','1504.3577025982565','1504.357702598256537','test','test','0.0'),('2019-12-16 15:59:59','2019-12-16 19:59:59','RENBNB','4h','0.002428000000000','0.002405000000000','3.679826091411179','3.644967771764368','1515.5791150787395','1515.579115078739505','test','test','0.82'),('2019-12-17 03:59:59','2019-12-17 15:59:59','RENBNB','4h','0.002469000000000','0.002409000000000','3.672079798156332','3.582843351056543','1487.2741183298228','1487.274118329822841','test','test','2.59'),('2019-12-23 07:59:59','2019-12-23 11:59:59','RENBNB','4h','0.002399000000000','0.002376000000000','3.652249476578602','3.617234162713947','1522.4049506371828','1522.404950637182765','test','test','0.0'),('2019-12-23 15:59:59','2019-12-23 19:59:59','RENBNB','4h','0.002421000000000','0.002431000000000','3.644468295719790','3.659521861583977','1505.3565864187483','1505.356586418748293','test','test','1.85'),('2019-12-23 23:59:59','2019-12-25 19:59:59','RENBNB','4h','0.002470000000000','0.002471000000000','3.647813532578498','3.649290380162538','1476.8475840398778','1476.847584039877802','test','test','2.46'),('2019-12-25 23:59:59','2019-12-26 03:59:59','RENBNB','4h','0.002491000000000','0.002460000000000','3.648141720930507','3.602741322155378','1464.5289927460885','1464.528992746088534','test','test','0.80'),('2020-01-02 15:59:59','2020-01-05 03:59:59','RENBNB','4h','0.002700000000000','0.002481000000000','3.638052743424922','3.342966243124901','1347.4269420092303','1347.426942009230288','test','test','8.88'),('2020-01-06 15:59:59','2020-01-07 23:59:59','RENBNB','4h','0.002644000000000','0.002572000000000','3.572477965580473','3.475194148060884','1351.1641322165178','1351.164132216517828','test','test','6.16'),('2020-01-08 15:59:59','2020-01-13 03:59:59','RENBNB','4h','0.002701000000000','0.002884000000000','3.550859339465009','3.791439590898588','1314.6461826971529','1314.646182697152881','test','test','4.77'),('2020-01-13 23:59:59','2020-01-14 03:59:59','RENBNB','4h','0.003033000000000','0.002963000000000','3.604321617561360','3.521135823552360','1188.3684858428487','1188.368485842848713','test','test','5.27'),('2020-02-02 03:59:59','2020-02-02 11:59:59','RENBNB','4h','0.002439000000000','0.002432000000000','3.585835885559360','3.575544433653285','1470.207415153489','1470.207415153488910','test','test','0.0'),('2020-02-02 19:59:59','2020-02-07 11:59:59','RENBNB','4h','0.002474000000000','0.002628000000000','3.583548896246899','3.806615399893634','1448.4837899138638','1448.483789913863802','test','test','1.69'),('2020-02-15 19:59:59','2020-02-15 23:59:59','RENBNB','4h','0.002538000000000','0.002498000000000','3.633119230390617','3.575859668051915','1431.4890584675404','1431.489058467540417','test','test','0.0'),('2020-02-16 03:59:59','2020-02-16 15:59:59','RENBNB','4h','0.002542000000000','0.002480000000000','3.620394883204240','3.532092568979746','1424.2308745886073','1424.230874588607321','test','test','1.73');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 14:45:04
