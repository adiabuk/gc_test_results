-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-05 19:59:59','2019-01-07 11:59:59','WANBTC','4h','0.000096200000000','0.000092200000000','0.033333333333333','0.031947331947332','346.5003465003465','346.500346500346495','test','test','0.0'),('2019-01-18 03:59:59','2019-01-20 11:59:59','WANBTC','4h','0.000092100000000','0.000087900000000','0.033025333025333','0.031519291779878','358.58124891784047','358.581248917840469','test','test','0.0'),('2019-01-22 07:59:59','2019-01-22 11:59:59','WANBTC','4h','0.000092600000000','0.000090800000000','0.032690657193010','0.032055201653621','353.03085521608824','353.030855216088241','test','test','5.07'),('2019-01-22 15:59:59','2019-01-23 15:59:59','WANBTC','4h','0.000091300000000','0.000090100000000','0.032549444850923','0.032121631775117','356.5108965051844','356.510896505184405','test','test','0.54'),('2019-01-25 07:59:59','2019-01-25 11:59:59','WANBTC','4h','0.000090700000000','0.000090500000000','0.032454375278522','0.032382811055196','357.8211166319956','357.821116631995608','test','test','0.66'),('2019-01-26 19:59:59','2019-01-27 15:59:59','WANBTC','4h','0.000091300000000','0.000087800000000','0.032438472117783','0.031194938137364','355.2954229768115','355.295422976811494','test','test','0.87'),('2019-02-26 23:59:59','2019-03-03 19:59:59','WANBTC','4h','0.000079700000000','0.000081000000000','0.032162131233245','0.032686733122871','403.53991509718105','403.539915097181051','test','test','0.0'),('2019-03-07 23:59:59','2019-03-16 03:59:59','WANBTC','4h','0.000081700000000','0.000107400000000','0.032278709430940','0.042432477269069','395.0882427287638','395.088242728763817','test','test','1.71'),('2019-03-28 19:59:59','2019-03-29 11:59:59','WANBTC','4h','0.000104900000000','0.000101200000000','0.034535102283858','0.033316990954494','329.219278206459','329.219278206459023','test','test','22.7'),('2019-03-29 15:59:59','2019-03-29 23:59:59','WANBTC','4h','0.000103500000000','0.000103000000000','0.034264410877332','0.034098882322369','331.0571099259152','331.057109925915199','test','test','15.1'),('2019-03-31 11:59:59','2019-04-02 03:59:59','WANBTC','4h','0.000103500000000','0.000103500000000','0.034227626754007','0.034227626754007','330.70170776818463','330.701707768184633','test','test','10.9'),('2019-05-18 23:59:59','2019-05-19 03:59:59','WANBTC','4h','0.000054500000000','0.000051100000000','0.034227626754007','0.032092325268436','628.0298486973782','628.029848697378156','test','test','0.0'),('2019-05-23 11:59:59','2019-05-24 15:59:59','WANBTC','4h','0.000053300000000','0.000053200000000','0.033753115312769','0.033689788642389','633.2667038042985','633.266703804298459','test','test','4.12'),('2019-06-02 15:59:59','2019-06-06 11:59:59','WANBTC','4h','0.000059000000000','0.000054900000000','0.033739042719351','0.031394465174447','571.8481816839209','571.848181683920870','test','test','10.8'),('2019-06-07 03:59:59','2019-06-09 23:59:59','WANBTC','4h','0.000057000000000','0.000056300000000','0.033218025487150','0.032810084823273','582.7723769675517','582.772376967551736','test','test','6.66'),('2019-06-11 07:59:59','2019-06-11 15:59:59','WANBTC','4h','0.000058200000000','0.000056900000000','0.033127372006289','0.032387413525049','569.1988317231768','569.198831723176795','test','test','3.26'),('2019-06-13 07:59:59','2019-06-13 19:59:59','WANBTC','4h','0.000058500000000','0.000056600000000','0.032962936788236','0.031892345678874','563.4690049271035','563.469004927103470','test','test','2.73'),('2019-06-13 23:59:59','2019-06-14 11:59:59','WANBTC','4h','0.000058000000000','0.000056200000000','0.032725027652822','0.031709423346355','564.2246147038238','564.224614703823818','test','test','2.41'),('2019-07-24 11:59:59','2019-07-28 07:59:59','WANBTC','4h','0.000026600000000','0.000029400000000','0.032499337806940','0.035920320733986','1221.779616802264','1221.779616802263945','test','test','0.0'),('2019-07-29 11:59:59','2019-07-30 15:59:59','WANBTC','4h','0.000030300000000','0.000029300000000','0.033259556235173','0.032161881111900','1097.6751232730253','1097.675123273025292','test','test','12.5'),('2019-08-22 23:59:59','2019-08-27 23:59:59','WANBTC','4h','0.000024300000000','0.000039830000000','0.033015628430001','0.054115739932796','1358.6678366255512','1358.667836625551217','test','test','0.0'),('2019-09-01 19:59:59','2019-09-02 23:59:59','WANBTC','4h','0.000041540000000','0.000036890000000','0.037704542097289','0.033483884399831','907.6683220339112','907.668322033911181','test','test','29.4'),('2019-09-03 03:59:59','2019-09-03 07:59:59','WANBTC','4h','0.000037980000000','0.000036030000000','0.036766618164520','0.034878916599991','968.0520843738869','968.052084373886942','test','test','2.86'),('2019-10-03 15:59:59','2019-10-06 15:59:59','WANBTC','4h','0.000024720000000','0.000024740000000','0.036347128927958','0.036376535990197','1470.35311197242','1470.353111972420038','test','test','0.0'),('2019-10-08 15:59:59','2019-10-10 11:59:59','WANBTC','4h','0.000025160000000','0.000025800000000','0.036353663830678','0.037278399317627','1444.8991983576311','1444.899198357631121','test','test','1.90'),('2019-10-15 11:59:59','2019-10-15 15:59:59','WANBTC','4h','0.000025510000000','0.000024700000000','0.036559160605556','0.035398324851322','1433.1305607822637','1433.130560782263728','test','test','0.0'),('2019-10-28 19:59:59','2019-10-28 23:59:59','WANBTC','4h','0.000024740000000','0.000023790000000','0.036301197104615','0.034907254612724','1467.307886201078','1467.307886201077963','test','test','0.16'),('2019-10-29 11:59:59','2019-10-29 15:59:59','WANBTC','4h','0.000024100000000','0.000023590000000','0.035991432106417','0.035229787692547','1493.4204193533885','1493.420419353388525','test','test','1.28'),('2019-10-29 19:59:59','2019-10-29 23:59:59','WANBTC','4h','0.000024010000000','0.000023810000000','0.035822177792223','0.035523783974712','1491.969087556157','1491.969087556157092','test','test','1.74'),('2019-10-31 07:59:59','2019-10-31 15:59:59','WANBTC','4h','0.000024370000000','0.000024780000000','0.035755868054999','0.036357423488013','1467.2083732047056','1467.208373204705595','test','test','2.29'),('2019-10-31 19:59:59','2019-11-02 15:59:59','WANBTC','4h','0.000024970000000','0.000024130000000','0.035889547040113','0.034682209454462','1437.3066495840164','1437.306649584016441','test','test','2.00'),('2019-11-04 19:59:59','2019-11-04 23:59:59','WANBTC','4h','0.000024750000000','0.000024360000000','0.035621249798857','0.035059945256572','1439.242416115439','1439.242416115439028','test','test','2.50'),('2019-11-05 03:59:59','2019-11-05 15:59:59','WANBTC','4h','0.000024390000000','0.000024500000000','0.035496515456127','0.035656606341743','1455.3716874180857','1455.371687418085685','test','test','0.12'),('2019-11-05 19:59:59','2019-11-07 07:59:59','WANBTC','4h','0.000026940000000','0.000024820000000','0.035532091208486','0.032735950400691','1318.9343432994146','1318.934343299414650','test','test','9.05'),('2019-11-07 11:59:59','2019-11-07 15:59:59','WANBTC','4h','0.000025320000000','0.000024920000000','0.034910726584532','0.034359214316214','1378.780670795094','1378.780670795094011','test','test','2.13'),('2019-11-11 19:59:59','2019-11-15 03:59:59','WANBTC','4h','0.000025370000000','0.000025560000000','0.034788168302683','0.035048702476018','1371.2324912370257','1371.232491237025670','test','test','1.77'),('2019-11-16 15:59:59','2019-11-19 11:59:59','WANBTC','4h','0.000026360000000','0.000026880000000','0.034846064785647','0.035533468188095','1321.9296200928175','1321.929620092817458','test','test','3.03'),('2019-11-20 15:59:59','2019-11-21 11:59:59','WANBTC','4h','0.000029500000000','0.000026990000000','0.034998821097302','0.032020955302243','1186.4007151627723','1186.400715162772258','test','test','12.5'),('2019-11-24 03:59:59','2019-11-24 11:59:59','WANBTC','4h','0.000028510000000','0.000027630000000','0.034337073142844','0.033277212589855','1204.3869920324175','1204.386992032417538','test','test','5.33'),('2019-11-26 19:59:59','2019-11-27 11:59:59','WANBTC','4h','0.000028880000000','0.000028070000000','0.034101548575513','0.033145099325300','1180.8015434734534','1180.801543473453421','test','test','4.32'),('2019-11-27 15:59:59','2019-11-27 23:59:59','WANBTC','4h','0.000029370000000','0.000027510000000','0.033889004297688','0.031742816078631','1153.86463390154','1153.864633901539946','test','test','4.49'),('2019-11-28 03:59:59','2019-11-30 07:59:59','WANBTC','4h','0.000027610000000','0.000027890000000','0.033412073582342','0.033750913879447','1210.1439182304318','1210.143918230431836','test','test','0.36'),('2019-12-16 23:59:59','2019-12-19 15:59:59','WANBTC','4h','0.000025540000000','0.000026490000000','0.033487371426143','0.034732986259927','1311.1735092460194','1311.173509246019421','test','test','0.0'),('2019-12-19 19:59:59','2019-12-19 23:59:59','WANBTC','4h','0.000027060000000','0.000026610000000','0.033764174722540','0.033202686229371','1247.7522070413813','1247.752207041381325','test','test','2.10');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 15:13:15
