-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 15:59:59','2019-01-03 19:59:59','VIBEBTC','4h','0.000007500000000','0.000007400000000','0.033333333333333','0.032888888888889','4444.444444444444','4444.444444444444343','test','test','1.33'),('2019-01-04 03:59:59','2019-01-07 03:59:59','VIBEBTC','4h','0.000007550000000','0.000008070000000','0.033234567901235','0.035523571253373','4401.929523342341','4401.929523342340872','test','test','0.0'),('2019-01-08 19:59:59','2019-01-10 07:59:59','VIBEBTC','4h','0.000008690000000','0.000008240000000','0.033743235312821','0.031995887109050','3882.9960083798487','3882.996008379848718','test','test','5.17'),('2019-01-14 15:59:59','2019-01-18 15:59:59','VIBEBTC','4h','0.000009810000000','0.000010960000000','0.033354935711983','0.037265045402990','3400.095383484494','3400.095383484494050','test','test','0.0'),('2019-01-22 15:59:59','2019-01-27 11:59:59','VIBEBTC','4h','0.000011420000000','0.000011120000000','0.034223848976651','0.033324798653271','2996.834411265421','2996.834411265420840','test','test','2.62'),('2019-02-12 15:59:59','2019-02-13 07:59:59','VIBEBTC','4h','0.000010150000000','0.000010050000000','0.034024060015900','0.033688847601950','3352.1241394975364','3352.124139497536362','test','test','0.98'),('2019-02-20 15:59:59','2019-02-21 07:59:59','VIBEBTC','4h','0.000010230000000','0.000009760000000','0.033949568368356','0.032389813027874','3318.6283840034753','3318.628384003475276','test','test','4.59'),('2019-03-02 15:59:59','2019-03-04 03:59:59','VIBEBTC','4h','0.000010190000000','0.000009670000000','0.033602956070471','0.031888183042341','3297.640438711547','3297.640438711547176','test','test','5.10'),('2019-03-05 15:59:59','2019-03-07 03:59:59','VIBEBTC','4h','0.000010110000000','0.000010030000000','0.033221895397553','0.032959011952271','3286.0430660289703','3286.043066028970316','test','test','0.79'),('2019-03-09 11:59:59','2019-03-11 15:59:59','VIBEBTC','4h','0.000010100000000','0.000010380000000','0.033163476854157','0.034082860370906','3283.5125598175136','3283.512559817513647','test','test','0.0'),('2019-03-11 19:59:59','2019-03-11 23:59:59','VIBEBTC','4h','0.000010450000000','0.000010380000000','0.033367784302323','0.033144268043839','3193.089406920893','3193.089406920892998','test','test','0.66'),('2019-03-12 11:59:59','2019-03-13 11:59:59','VIBEBTC','4h','0.000010690000000','0.000010640000000','0.033318114022660','0.033162276258288','3116.7552874331363','3116.755287433136345','test','test','0.46'),('2019-03-13 15:59:59','2019-03-13 19:59:59','VIBEBTC','4h','0.000010690000000','0.000010590000000','0.033283483408355','0.032972131832973','3113.5157538218273','3113.515753821827275','test','test','0.93'),('2019-03-14 11:59:59','2019-03-16 07:59:59','VIBEBTC','4h','0.000010820000000','0.000010710000000','0.033214294169382','0.032876625744370','3069.712954656336','3069.712954656336024','test','test','1.01'),('2019-03-16 11:59:59','2019-03-16 15:59:59','VIBEBTC','4h','0.000010800000000','0.000010620000000','0.033139256741601','0.032586935795908','3068.4496982963988','3068.449698296398765','test','test','1.66'),('2019-03-17 11:59:59','2019-03-18 11:59:59','VIBEBTC','4h','0.000011300000000','0.000011110000000','0.033016518753669','0.032461373748076','2921.8158189087903','2921.815818908790334','test','test','5.13'),('2019-03-18 15:59:59','2019-03-20 23:59:59','VIBEBTC','4h','0.000011400000000','0.000010960000000','0.032893153196871','0.031623592898044','2885.36431551499','2885.364315514989812','test','test','3.85'),('2019-03-21 07:59:59','2019-03-21 15:59:59','VIBEBTC','4h','0.000011230000000','0.000010610000000','0.032611028686020','0.030810597894806','2903.9206309902443','2903.920630990244263','test','test','5.52'),('2019-03-27 07:59:59','2019-04-02 03:59:59','VIBEBTC','4h','0.000011220000000','0.000011510000000','0.032210932954640','0.033043479350081','2870.8496394509407','2870.849639450940685','test','test','0.0'),('2019-05-22 19:59:59','2019-05-24 19:59:59','VIBEBTC','4h','0.000006080000000','0.000005890000000','0.032395943264738','0.031383570037715','5328.280142226571','5328.280142226571115','test','test','4.44'),('2019-05-29 23:59:59','2019-05-30 15:59:59','VIBEBTC','4h','0.000006060000000','0.000005650000000','0.032170971436510','0.029994387560442','5308.741161140301','5308.741161140301301','test','test','6.76'),('2019-05-30 19:59:59','2019-05-30 23:59:59','VIBEBTC','4h','0.000005800000000','0.000005670000000','0.031687286130717','0.030977053855373','5463.325194951263','5463.325194951263256','test','test','2.24'),('2019-05-31 19:59:59','2019-06-03 23:59:59','VIBEBTC','4h','0.000005990000000','0.000005840000000','0.031529456736196','0.030739904397226','5263.682259799072','5263.682259799072199','test','test','3.50'),('2019-06-07 19:59:59','2019-06-09 15:59:59','VIBEBTC','4h','0.000005980000000','0.000005930000000','0.031354000660870','0.031091843464709','5243.14392322237','5243.143923222370177','test','test','1.17'),('2019-06-10 11:59:59','2019-06-12 15:59:59','VIBEBTC','4h','0.000006280000000','0.000006010000000','0.031295743506167','0.029950225871348','4983.398647478875','4983.398647478875318','test','test','4.29'),('2019-07-06 19:59:59','2019-07-07 03:59:59','VIBEBTC','4h','0.000003220000000','0.000003090000000','0.030996739587319','0.029745318423856','9626.31664202443','9626.316642024430621','test','test','4.03'),('2019-07-07 07:59:59','2019-07-07 11:59:59','VIBEBTC','4h','0.000003140000000','0.000003110000000','0.030718645995438','0.030425155747074','9783.00827880191','9783.008278801909910','test','test','0.95'),('2019-07-07 15:59:59','2019-07-07 19:59:59','VIBEBTC','4h','0.000003210000000','0.000003110000000','0.030653425940246','0.029698490552699','9549.353875466044','9549.353875466043974','test','test','3.11'),('2019-07-26 11:59:59','2019-07-27 03:59:59','VIBEBTC','4h','0.000002200000000','0.000002140000000','0.030441218076347','0.029611003037901','13836.917307430303','13836.917307430303481','test','test','2.72'),('2019-07-27 07:59:59','2019-07-27 11:59:59','VIBEBTC','4h','0.000002170000000','0.000002170000000','0.030256725845581','0.030256725845581','13943.191633908242','13943.191633908241784','test','test','0.0'),('2019-07-27 23:59:59','2019-07-28 03:59:59','VIBEBTC','4h','0.000002180000000','0.000002210000000','0.030256725845581','0.030673102806759','13879.232039257287','13879.232039257287397','test','test','0.0'),('2019-07-28 19:59:59','2019-07-31 15:59:59','VIBEBTC','4h','0.000002230000000','0.000002120000000','0.030349254059176','0.028852205652670','13609.530968240362','13609.530968240362199','test','test','4.93'),('2019-08-22 11:59:59','2019-08-23 15:59:59','VIBEBTC','4h','0.000001530000000','0.000001480000000','0.030016576635508','0.029035642758531','19618.67753954771','19618.677539547708875','test','test','3.26'),('2019-08-23 23:59:59','2019-08-27 15:59:59','VIBEBTC','4h','0.000001500000000','0.000001690000000','0.029798591329513','0.033573079564585','19865.72755300874','19865.727553008739051','test','test','0.0'),('2019-08-27 23:59:59','2019-08-28 03:59:59','VIBEBTC','4h','0.000001790000000','0.000001740000000','0.030637366492862','0.029781574132726','17115.847202716446','17115.847202716446191','test','test','2.79'),('2019-09-11 03:59:59','2019-09-12 03:59:59','VIBEBTC','4h','0.000001550000000','0.000001490000000','0.030447190412832','0.029268589493626','19643.34865344014','19643.348653440141788','test','test','3.87'),('2019-09-14 19:59:59','2019-09-23 23:59:59','VIBEBTC','4h','0.000001560000000','0.000001810000000','0.030185279097453','0.035022663568199','19349.53788298276','19349.537882982760493','test','test','0.0'),('2019-09-27 15:59:59','2019-10-07 03:59:59','VIBEBTC','4h','0.000001900000000','0.000003000000000','0.031260253424286','0.049358294880452','16452.764960150293','16452.764960150292609','test','test','0.0'),('2019-10-08 11:59:59','2019-10-09 15:59:59','VIBEBTC','4h','0.000003140000000','0.000002700000000','0.035282040414545','0.030338060229067','11236.318603358175','11236.318603358175096','test','test','14.0'),('2019-11-09 19:59:59','2019-11-11 03:59:59','VIBEBTC','4h','0.000002100000000','0.000002090000000','0.034183378151105','0.034020600159909','16277.799119573863','16277.799119573863209','test','test','0.47'),('2019-11-11 07:59:59','2019-11-12 15:59:59','VIBEBTC','4h','0.000002110000000','0.000002100000000','0.034147205264173','0.033985370168134','16183.509603873299','16183.509603873299056','test','test','0.47'),('2019-11-17 15:59:59','2019-11-17 19:59:59','VIBEBTC','4h','0.000002120000000','0.000002080000000','0.034111241909497','0.033467633571582','16090.208447876099','16090.208447876098944','test','test','1.88'),('2019-11-18 03:59:59','2019-11-18 19:59:59','VIBEBTC','4h','0.000002110000000','0.000002130000000','0.033968217834405','0.034290191463167','16098.681438106685','16098.681438106685164','test','test','0.0'),('2019-11-18 23:59:59','2019-11-20 23:59:59','VIBEBTC','4h','0.000002160000000','0.000002110000000','0.034039767529686','0.033251809947980','15759.151634113681','15759.151634113681212','test','test','2.31'),('2019-11-29 19:59:59','2019-12-02 07:59:59','VIBEBTC','4h','0.000002100000000','0.000002060000000','0.033864665844862','0.033219624590674','16126.03135469619','16126.031354696189737','test','test','1.90'),('2019-12-02 11:59:59','2019-12-03 23:59:59','VIBEBTC','4h','0.000002080000000','0.000002080000000','0.033721323343931','0.033721323343931','16212.17468458237','16212.174684582370901','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-01  2:26:13
