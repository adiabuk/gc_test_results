-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-17 07:59:59','2019-01-20 11:59:59','MDAETH','4h','0.006290300000000','0.005878800000000','1.297777777777778','1.212879512900816','206.31413092821927','206.314130928219271','test','test','0.0'),('2019-01-21 23:59:59','2019-01-25 15:59:59','MDAETH','4h','0.005962800000000','0.006005500000000','1.278911496694008','1.288069865398113','214.4817026722359','214.481702672235912','test','test','1.40'),('2019-01-25 19:59:59','2019-01-29 23:59:59','MDAETH','4h','0.006237400000000','0.006508700000000','1.280946689739365','1.336662346411422','205.3654871804542','205.365487180454210','test','test','3.71'),('2019-01-30 11:59:59','2019-01-30 15:59:59','MDAETH','4h','0.006631000000000','0.006384800000000','1.293327946777600','1.245308441349061','195.04267030275977','195.042670302759774','test','test','1.84'),('2019-01-31 23:59:59','2019-02-05 03:59:59','MDAETH','4h','0.006664600000000','0.006794800000000','1.282656945571258','1.307715003716290','192.45820387889117','192.458203878891169','test','test','4.19'),('2019-02-25 07:59:59','2019-03-01 03:59:59','MDAETH','4h','0.006912100000000','0.006708800000000','1.288225402936821','1.250335872343072','186.37250660968743','186.372506609687434','test','test','7.35'),('2019-03-09 11:59:59','2019-03-09 15:59:59','MDAETH','4h','0.006285800000000','0.006317100000000','1.279805507249321','1.286178270044336','203.6026452081391','203.602645208139108','test','test','0.0'),('2019-03-09 19:59:59','2019-03-12 19:59:59','MDAETH','4h','0.006945000000000','0.007400400000000','1.281221676759324','1.365234398371447','184.48116296030585','184.481162960305852','test','test','9.04'),('2019-03-12 23:59:59','2019-03-14 23:59:59','MDAETH','4h','0.008161400000000','0.008398100000000','1.299891170450907','1.337591104291392','159.27306227496595','159.273062274965952','test','test','17.7'),('2019-03-23 11:59:59','2019-03-26 11:59:59','MDAETH','4h','0.008728700000000','0.008287400000000','1.308268933526570','1.242126314308900','149.8813034617492','149.881303461749212','test','test','22.1'),('2019-03-26 15:59:59','2019-03-27 03:59:59','MDAETH','4h','0.008635700000000','0.008342100000000','1.293570573700421','1.249591241343062','149.7933663397781','149.793366339778089','test','test','4.03'),('2019-03-30 03:59:59','2019-03-31 23:59:59','MDAETH','4h','0.008653900000000','0.008703600000000','1.283797388732119','1.291170333903658','148.3489974152832','148.348997415283208','test','test','3.60'),('2019-04-01 07:59:59','2019-04-02 07:59:59','MDAETH','4h','0.008627000000000','0.008505600000000','1.285435820992461','1.267347040574183','149.00148614726575','149.001486147265751','test','test','0.0'),('2019-06-02 15:59:59','2019-06-03 07:59:59','MDAETH','4h','0.004034700000000','0.003810900000000','1.281416092010622','1.210337468719677','317.59885295328576','317.598852953285757','test','test','0.0'),('2019-06-03 11:59:59','2019-06-03 15:59:59','MDAETH','4h','0.003823600000000','0.003849800000000','1.265620842390412','1.274293105720946','331.0024171959441','331.002417195944076','test','test','0.33'),('2019-06-03 19:59:59','2019-06-03 23:59:59','MDAETH','4h','0.003861200000000','0.003842300000000','1.267548012019419','1.261343552932304','328.2782585774939','328.278258577493887','test','test','0.29'),('2019-06-04 03:59:59','2019-06-04 07:59:59','MDAETH','4h','0.003901800000000','0.003835100000000','1.266169243333394','1.244524492569558','324.5090069540709','324.509006954070912','test','test','1.52'),('2019-06-04 15:59:59','2019-06-05 07:59:59','MDAETH','4h','0.003863600000000','0.003820000000000','1.261359298719208','1.247125096052224','326.47253823356664','326.472538233566638','test','test','0.73'),('2019-06-05 11:59:59','2019-06-06 15:59:59','MDAETH','4h','0.003876600000000','0.003898400000000','1.258196142570990','1.265271589072576','324.5617661277897','324.561766127789724','test','test','1.46'),('2019-06-06 19:59:59','2019-06-07 07:59:59','MDAETH','4h','0.003950200000000','0.003929700000000','1.259768464015786','1.253230756175088','318.91257759500434','318.912577595004336','test','test','1.31'),('2019-06-07 15:59:59','2019-06-11 23:59:59','MDAETH','4h','0.003972000000000','0.004296100000000','1.258315640051187','1.360989380972786','316.79648541067144','316.796485410671437','test','test','1.32'),('2019-07-08 11:59:59','2019-07-08 19:59:59','MDAETH','4h','0.003124000000000','0.002949200000000','1.281132026922653','1.209447686875892','410.09347852837806','410.093478528378057','test','test','0.0'),('2019-07-15 23:59:59','2019-07-18 11:59:59','MDAETH','4h','0.003130000000000','0.002966800000000','1.265202173578929','1.199233804656219','404.2179468303287','404.217946830328685','test','test','7.26'),('2019-07-19 15:59:59','2019-07-19 19:59:59','MDAETH','4h','0.003004200000000','0.002921600000000','1.250542536040549','1.216159068402925','416.2647413755904','416.264741375590404','test','test','1.83'),('2019-07-21 03:59:59','2019-07-24 19:59:59','MDAETH','4h','0.002979300000000','0.003176700000000','1.242901765454410','1.325252924619550','417.1791244434633','417.179124443463309','test','test','1.93'),('2019-07-26 19:59:59','2019-07-26 23:59:59','MDAETH','4h','0.003285100000000','0.003010500000000','1.261202023046663','1.155778725269240','383.9158695463345','383.915869546334477','test','test','3.29'),('2019-07-27 11:59:59','2019-07-28 07:59:59','MDAETH','4h','0.003126000000000','0.003106300000000','1.237774623540570','1.229974188452998','395.96117195795574','395.961171957955742','test','test','3.69'),('2019-07-28 15:59:59','2019-07-29 07:59:59','MDAETH','4h','0.003140600000000','0.003076200000000','1.236041193521109','1.210695382891688','393.5684880344867','393.568488034486677','test','test','1.31'),('2019-07-29 11:59:59','2019-07-29 15:59:59','MDAETH','4h','0.003087600000000','0.003038600000000','1.230408791159015','1.210882288125334','398.5000619118458','398.500061911845819','test','test','0.36'),('2019-07-30 23:59:59','2019-07-31 11:59:59','MDAETH','4h','0.003236000000000','0.003105900000000','1.226069568262642','1.176776721899549','378.8842917993331','378.884291799333084','test','test','6.10'),('2019-07-31 15:59:59','2019-07-31 23:59:59','MDAETH','4h','0.003116500000000','0.003079600000000','1.215115602404177','1.200728384137302','389.89751400743677','389.897514007436769','test','test','0.34'),('2019-08-01 19:59:59','2019-08-03 03:59:59','MDAETH','4h','0.003181000000000','0.003130600000000','1.211918442789316','1.192716717068919','380.98662143644003','380.986621436440032','test','test','3.18'),('2019-08-03 11:59:59','2019-08-03 15:59:59','MDAETH','4h','0.003185600000000','0.003350000000000','1.207651392629227','1.269974938883699','379.0969966817012','379.096996681701228','test','test','2.48'),('2019-08-03 19:59:59','2019-08-05 07:59:59','MDAETH','4h','0.003378700000000','0.003214900000000','1.221501069574666','1.162282472127029','361.52989894772116','361.529898947721165','test','test','5.63'),('2019-08-15 19:59:59','2019-08-17 15:59:59','MDAETH','4h','0.003205500000000','0.003093400000000','1.208341381252968','1.166084301596609','376.9587837320132','376.958783732013217','test','test','0.0'),('2019-08-21 07:59:59','2019-08-25 15:59:59','MDAETH','4h','0.003528800000000','0.003405800000000','1.198950919107111','1.157160235857798','339.7616524334366','339.761652433436609','test','test','12.3'),('2019-08-25 19:59:59','2019-08-26 11:59:59','MDAETH','4h','0.003591900000000','0.003328800000000','1.189664100607264','1.102523416047624','331.20746696936544','331.207466969365441','test','test','10.4'),('2019-08-26 19:59:59','2019-08-28 07:59:59','MDAETH','4h','0.004002300000000','0.003418200000000','1.170299504038455','0.999504725958635','292.40674213288725','292.406742132887246','test','test','16.8'),('2019-08-31 19:59:59','2019-08-31 23:59:59','MDAETH','4h','0.003523000000000','0.003476400000000','1.132345108909606','1.117367169064250','321.41501814067726','321.415018140677262','test','test','4.91'),('2019-09-01 19:59:59','2019-09-01 23:59:59','MDAETH','4h','0.003539500000000','0.003450000000000','1.129016677832860','1.100468297364986','318.97631807680744','318.976318076807445','test','test','1.78'),('2019-09-10 07:59:59','2019-09-12 23:59:59','MDAETH','4h','0.003716000000000','0.003490100000000','1.122672593284444','1.054424009101732','302.1185665458675','302.118566545867509','test','test','7.15'),('2019-09-25 19:59:59','2019-09-28 23:59:59','MDAETH','4h','0.003474900000000','0.003899400000000','1.107506241243841','1.242801184812867','318.71600369617573','318.716003696175733','test','test','0.0'),('2019-09-29 07:59:59','2019-10-07 23:59:59','MDAETH','4h','0.004378200000000','0.005117600000000','1.137571784259180','1.329687397360737','259.82636340486505','259.826363404865049','test','test','23.6'),('2019-10-12 19:59:59','2019-10-15 19:59:59','MDAETH','4h','0.006333700000000','0.004939600000000','1.180264142726193','0.920478197484930','186.34670772631998','186.346707726319977','test','test','44.8'),('2019-11-10 11:59:59','2019-11-10 19:59:59','MDAETH','4h','0.004111100000000','0.004106300000000','1.122533932672579','1.121223294917032','273.04953240557967','273.049532405579669','test','test','4.41'),('2019-11-11 03:59:59','2019-11-11 11:59:59','MDAETH','4h','0.004098900000000','0.004000200000000','1.122242679838013','1.095219490079782','273.79118296079747','273.791182960797471','test','test','0.0'),('2019-11-11 15:59:59','2019-11-11 19:59:59','MDAETH','4h','0.004002900000000','0.004011500000000','1.116237526558406','1.118635698565801','278.85721016223386','278.857210162233855','test','test','0.06'),('2019-11-11 23:59:59','2019-11-12 03:59:59','MDAETH','4h','0.004019100000000','0.004008700000000','1.116770453671160','1.113880649307452','277.8658042027221','277.865804202722074','test','test','0.18'),('2019-11-23 11:59:59','2019-11-25 11:59:59','MDAETH','4h','0.003868300000000','0.003820100000000','1.116128274923670','1.102221033279713','288.53198431447146','288.531984314471458','test','test','0.0'),('2019-11-25 19:59:59','2019-11-26 23:59:59','MDAETH','4h','0.003929600000000','0.003940800000000','1.113037776780568','1.116210115720904','283.2445482442407','283.244548244240718','test','test','2.78'),('2019-11-27 03:59:59','2019-11-27 19:59:59','MDAETH','4h','0.003962300000000','0.003971400000000','1.113742740989532','1.116300613675347','281.0849105291199','281.084910529119895','test','test','1.62'),('2019-11-30 03:59:59','2019-11-30 11:59:59','MDAETH','4h','0.003984900000000','0.003900700000000','1.114311157141935','1.090766024408027','279.6334053908341','279.633405390834128','test','test','1.22'),('2019-12-13 11:59:59','2019-12-13 15:59:59','MDAETH','4h','0.003821800000000','0.003708800000000','1.109078905423289','1.076286525834396','290.19804945923096','290.198049459230958','test','test','0.0'),('2019-12-14 03:59:59','2019-12-14 15:59:59','MDAETH','4h','0.003689800000000','0.003635400000000','1.101791709959090','1.085547612983163','298.60472382218285','298.604723822182848','test','test','0.0'),('2019-12-17 03:59:59','2019-12-21 15:59:59','MDAETH','4h','0.003729500000000','0.003868900000000','1.098181910631107','1.139229385719450','294.4582144070536','294.458214407053617','test','test','2.52'),('2019-12-21 19:59:59','2019-12-21 23:59:59','MDAETH','4h','0.003890900000000','0.003842200000000','1.107303571761850','1.093444134627819','284.5880314996144','284.588031499614374','test','test','4.68'),('2019-12-25 03:59:59','2019-12-28 19:59:59','MDAETH','4h','0.003880000000000','0.003907200000000','1.104223696843176','1.111964646470530','284.5937362997876','284.593736299787622','test','test','0.97');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 15:17:36
