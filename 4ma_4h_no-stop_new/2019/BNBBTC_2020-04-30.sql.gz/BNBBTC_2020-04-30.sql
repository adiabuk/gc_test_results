-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-02 07:59:59','BNBBTC','4h','0.001584200000000','0.001563700000000','0.033333333333333','0.032901990489416','21.04111433741531','21.041114337415308','test','test','1.29'),('2019-01-04 15:59:59','2019-01-06 19:59:59','BNBBTC','4h','0.001591300000000','0.001570800000000','0.033237479368018','0.032809295916095','20.88699765475928','20.886997654759281','test','test','1.28'),('2019-01-06 23:59:59','2019-01-07 03:59:59','BNBBTC','4h','0.001571600000000','0.001559400000000','0.033142327489813','0.032885050577510','21.088271500263','21.088271500263001','test','test','0.77'),('2019-01-08 11:59:59','2019-01-10 07:59:59','BNBBTC','4h','0.001623900000000','0.001605100000000','0.033085154842635','0.032702125770006','20.37388684194525','20.373886841945250','test','test','1.15'),('2019-01-10 11:59:59','2019-01-10 15:59:59','BNBBTC','4h','0.001606000000000','0.001607700000000','0.033000037270940','0.033034968817242','20.54796841278926','20.547968412789260','test','test','0.0'),('2019-01-11 11:59:59','2019-01-13 07:59:59','BNBBTC','4h','0.001662800000000','0.001634500000000','0.033007799836784','0.032446024075790','19.85073360403202','19.850733604032019','test','test','2.15'),('2019-01-14 23:59:59','2019-01-15 11:59:59','BNBBTC','4h','0.001669900000000','0.001624100000000','0.032882960778786','0.031981086652390','19.691574812135922','19.691574812135922','test','test','2.82'),('2019-01-15 19:59:59','2019-01-15 23:59:59','BNBBTC','4h','0.001634200000000','0.001632900000000','0.032682544306253','0.032656545464252','19.99910923158324','19.999109231583240','test','test','0.07'),('2019-01-16 03:59:59','2019-01-24 19:59:59','BNBBTC','4h','0.001641400000000','0.001805500000000','0.032676766785809','0.035943647149859','19.90786327879168','19.907863278791680','test','test','0.0'),('2019-01-25 07:59:59','2019-01-28 15:59:59','BNBBTC','4h','0.001826100000000','0.001800900000000','0.033402740200042','0.032941785677814','18.29184612016976','18.291846120169762','test','test','1.37'),('2019-02-01 19:59:59','2019-02-13 03:59:59','BNBBTC','4h','0.001893000000000','0.002497000000000','0.033300305861769','0.043925443072814','17.591286773253625','17.591286773253625','test','test','0.53'),('2019-02-15 15:59:59','2019-02-17 03:59:59','BNBBTC','4h','0.002560000000000','0.002474200000000','0.035661447464224','0.034466231764056','13.930252915712325','13.930252915712325','test','test','3.35'),('2019-02-18 03:59:59','2019-02-18 11:59:59','BNBBTC','4h','0.002526000000000','0.002492200000000','0.035395843975297','0.034922217876182','14.012606482698864','14.012606482698864','test','test','1.33'),('2019-02-19 15:59:59','2019-02-23 19:59:59','BNBBTC','4h','0.002630500000000','0.002635100000000','0.035290593731050','0.035352306991329','13.415926147519315','13.415926147519315','test','test','0.61'),('2019-02-28 23:59:59','2019-03-10 03:59:59','BNBBTC','4h','0.002695900000000','0.003658200000000','0.035304307788889','0.047906160745322','13.09555539481781','13.095555394817810','test','test','0.0'),('2019-03-11 15:59:59','2019-03-15 23:59:59','BNBBTC','4h','0.003714200000000','0.003804100000000','0.038104719556986','0.039027021610772','10.25919970841246','10.259199708412460','test','test','0.0'),('2019-03-16 11:59:59','2019-03-18 11:59:59','BNBBTC','4h','0.003948100000000','0.003844500000000','0.038309675568938','0.037304411672648','9.703319462257287','9.703319462257287','test','test','2.62'),('2019-03-24 11:59:59','2019-03-29 11:59:59','BNBBTC','4h','0.004268000000000','0.004057500000000','0.038086283591985','0.036207848096176','8.923684065600904','8.923684065600904','test','test','5.48'),('2019-03-31 03:59:59','2019-04-02 07:59:59','BNBBTC','4h','0.004189800000000','0.004032700000000','0.037668853481805','0.036256428811894','8.990608974606161','8.990608974606161','test','test','3.74'),('2019-04-15 03:59:59','2019-04-17 15:59:59','BNBBTC','4h','0.003799800000000','0.003753500000000','0.037354981332936','0.036899816420121','9.830775654754403','9.830775654754403','test','test','1.28'),('2019-04-18 07:59:59','2019-04-22 23:59:59','BNBBTC','4h','0.003929900000000','0.004438900000000','0.037253833574532','0.042078943956332','9.479588176424958','9.479588176424958','test','test','0.0'),('2019-04-26 19:59:59','2019-04-27 11:59:59','BNBBTC','4h','0.004323900000000','0.004248500000000','0.038326080326044','0.037657751628206','8.863775833401224','8.863775833401224','test','test','1.74'),('2019-04-28 07:59:59','2019-04-29 07:59:59','BNBBTC','4h','0.004332200000000','0.004271900000000','0.038177562837635','0.037646168386984','8.812511619416258','8.812511619416258','test','test','1.39'),('2019-05-18 03:59:59','2019-05-26 19:59:59','BNBBTC','4h','0.003598300000000','0.003871200000000','0.038059475181935','0.040945957903540','10.577071167477666','10.577071167477666','test','test','0.80'),('2019-06-06 03:59:59','2019-06-09 23:59:59','BNBBTC','4h','0.003991000000000','0.003948200000000','0.038700915786736','0.038285882162163','9.697047303116012','9.697047303116012','test','test','1.51'),('2019-06-10 07:59:59','2019-06-14 07:59:59','BNBBTC','4h','0.004022300000000','0.004064800000000','0.038608686092386','0.039016629099851','9.598658999176202','9.598658999176202','test','test','1.29'),('2019-07-18 07:59:59','2019-07-18 15:59:59','BNBBTC','4h','0.002949900000000','0.002781700000000','0.038699340094045','0.036492746987900','13.11886507815361','13.118865078153609','test','test','5.70'),('2019-07-19 03:59:59','2019-07-19 07:59:59','BNBBTC','4h','0.002743100000000','0.002800600000000','0.038208986070458','0.039009910826774','13.929126196805639','13.929126196805639','test','test','0.0'),('2019-07-19 15:59:59','2019-07-19 23:59:59','BNBBTC','4h','0.002788500000000','0.002760600000000','0.038386969349639','0.038002893163569','13.766171543711273','13.766171543711273','test','test','1.00'),('2019-07-20 03:59:59','2019-07-25 07:59:59','BNBBTC','4h','0.002896800000000','0.002911700000000','0.038301619086068','0.038498627552093','13.222044699691995','13.222044699691995','test','test','1.69'),('2019-07-26 19:59:59','2019-07-27 03:59:59','BNBBTC','4h','0.002945600000000','0.002890200000000','0.038345398745184','0.037624209483070','13.01785671686055','13.017856716860550','test','test','1.88'),('2019-08-12 03:59:59','2019-08-16 15:59:59','BNBBTC','4h','0.002661100000000','0.002662600000000','0.038185134464715','0.038206658534347','14.349379754505529','14.349379754505529','test','test','1.17'),('2019-08-18 23:59:59','2019-08-19 19:59:59','BNBBTC','4h','0.002706300000000','0.002665700000000','0.038189917591300','0.037616991214251','14.111487119424877','14.111487119424877','test','test','1.50'),('2019-08-22 15:59:59','2019-08-22 19:59:59','BNBBTC','4h','0.002689400000000','0.002662400000000','0.038062600618622','0.037680474413259','14.152822420845542','14.152822420845542','test','test','1.00'),('2019-08-22 23:59:59','2019-08-23 03:59:59','BNBBTC','4h','0.002670000000000','0.002661800000000','0.037977683684097','0.037861048101247','14.223851567077485','14.223851567077485','test','test','0.30'),('2019-09-18 23:59:59','2019-09-19 23:59:59','BNBBTC','4h','0.002184400000000','0.002101200000000','0.037951764665686','0.036506247901272','17.373999572278784','17.373999572278784','test','test','4.09'),('2019-09-20 11:59:59','2019-09-20 15:59:59','BNBBTC','4h','0.002106400000000','0.002091600000000','0.037630538718038','0.037366138806802','17.86485886727982','17.864858867279821','test','test','0.70'),('2019-10-07 19:59:59','2019-10-11 23:59:59','BNBBTC','4h','0.001938300000000','0.002005200000000','0.037571783182208','0.038868565050283','19.383884425634832','19.383884425634832','test','test','0.05'),('2019-10-12 07:59:59','2019-10-20 07:59:59','BNBBTC','4h','0.002031000000000','0.002250000000000','0.037859956930669','0.041942345196458','18.641042309536733','18.641042309536733','test','test','0.33'),('2019-10-24 23:59:59','2019-10-25 15:59:59','BNBBTC','4h','0.002284200000000','0.002231500000000','0.038767154323067','0.037872736569444','16.971873882789016','16.971873882789016','test','test','2.30'),('2019-11-01 03:59:59','2019-11-01 07:59:59','BNBBTC','4h','0.002179900000000','0.002169400000000','0.038568394822262','0.038382621096112','17.69273582378162','17.692735823781621','test','test','0.48'),('2019-11-01 11:59:59','2019-11-01 15:59:59','BNBBTC','4h','0.002169900000000','0.002172900000000','0.038527111772006','0.038580377514813','17.755247602196413','17.755247602196413','test','test','0.0'),('2019-11-02 07:59:59','2019-11-02 15:59:59','BNBBTC','4h','0.002180900000000','0.002169400000000','0.038538948603741','0.038335730707944','17.671121373625976','17.671121373625976','test','test','0.52'),('2019-11-02 19:59:59','2019-11-02 23:59:59','BNBBTC','4h','0.002174300000000','0.002173100000000','0.038493789071342','0.038472544281347','17.703991662301224','17.703991662301224','test','test','0.05'),('2019-11-03 03:59:59','2019-11-03 15:59:59','BNBBTC','4h','0.002183100000000','0.002173300000000','0.038489068006898','0.038316289450502','17.630464938343742','17.630464938343742','test','test','0.44'),('2019-11-03 19:59:59','2019-11-04 23:59:59','BNBBTC','4h','0.002180000000000','0.002195500000000','0.038450672772144','0.038724060583139','17.637923289974108','17.637923289974108','test','test','0.0'),('2019-11-05 03:59:59','2019-11-07 07:59:59','BNBBTC','4h','0.002201100000000','0.002206600000000','0.038511425619031','0.038607656067854','17.496445240575774','17.496445240575774','test','test','0.0'),('2019-11-07 23:59:59','2019-11-08 07:59:59','BNBBTC','4h','0.002217300000000','0.002201400000000','0.038532810163214','0.038256495870337','17.378257413617558','17.378257413617558','test','test','0.71'),('2019-11-08 11:59:59','2019-11-15 19:59:59','BNBBTC','4h','0.002215500000000','0.002375000000000','0.038471406987019','0.041241070455504','17.364661244423075','17.364661244423075','test','test','0.0'),('2019-12-30 03:59:59','2020-01-01 15:59:59','BNBBTC','4h','0.001943700000000','0.001910800000000','0.039086887757794','0.038425284317329','20.10952706579913','20.109527065799131','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-01  0:04:47
