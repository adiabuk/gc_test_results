-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 15:59:59','2019-01-14 15:59:59','NANOETH','4h','0.007057000000000','0.006798000000000','1.297777777777778','1.250147843748524','183.89935918630832','183.899359186308317','test','test','3.67'),('2019-01-16 07:59:59','2019-01-27 15:59:59','NANOETH','4h','0.007400000000000','0.008192000000000','1.287193347993499','1.424957825238208','173.94504702614853','173.945047026148529','test','test','4.12'),('2019-01-29 03:59:59','2019-01-29 07:59:59','NANOETH','4h','0.008537000000000','0.008230000000000','1.317807676270101','1.270417848858256','154.36425867050502','154.364258670505023','test','test','3.59'),('2019-03-01 11:59:59','2019-03-05 15:59:59','NANOETH','4h','0.006545000000000','0.006532000000000','1.307276603511913','1.304680026606542','199.7366850285582','199.736685028558213','test','test','0.44'),('2019-03-10 03:59:59','2019-03-16 03:59:59','NANOETH','4h','0.006805000000000','0.007145000000000','1.306699586421831','1.371986560614839','192.0205123323778','192.020512332377791','test','test','0.44'),('2019-03-18 07:59:59','2019-03-18 15:59:59','NANOETH','4h','0.007344000000000','0.007193000000000','1.321207802909166','1.294042446395102','179.90302327194527','179.903023271945273','test','test','2.05'),('2019-03-18 19:59:59','2019-03-19 07:59:59','NANOETH','4h','0.007396000000000','0.007221000000000','1.315171057017152','1.284052217782701','177.82193848257867','177.821938482578673','test','test','2.36'),('2019-03-20 19:59:59','2019-03-21 15:59:59','NANOETH','4h','0.007298000000000','0.007176000000000','1.308255759409496','1.286385767268093','179.26223066723705','179.262230667237048','test','test','1.67'),('2019-03-28 15:59:59','2019-03-29 11:59:59','NANOETH','4h','0.007339000000000','0.007276000000000','1.303395761155851','1.292207052482623','177.59855036869476','177.598550368694760','test','test','0.85'),('2019-03-29 19:59:59','2019-03-29 23:59:59','NANOETH','4h','0.007227000000000','0.007212000000000','1.300909381450689','1.298209278957018','180.00683291140018','180.006832911400181','test','test','0.20'),('2019-03-31 11:59:59','2019-04-05 07:59:59','NANOETH','4h','0.007498000000000','0.008363000000000','1.300309358674318','1.450318373778784','173.42082671036516','173.420826710365162','test','test','0.0'),('2019-04-05 15:59:59','2019-04-06 19:59:59','NANOETH','4h','0.008751000000000','0.008335000000000','1.333644695364199','1.270246661622740','152.3991195708147','152.399119570814690','test','test','4.75'),('2019-04-08 07:59:59','2019-04-11 03:59:59','NANOETH','4h','0.009098000000000','0.008952000000000','1.319556243421653','1.298380687086243','145.03805709185013','145.038057091850135','test','test','3.82'),('2019-04-12 11:59:59','2019-04-14 11:59:59','NANOETH','4h','0.009923000000000','0.009334000000000','1.314850564236006','1.236804914499535','132.50534760012155','132.505347600121553','test','test','5.93'),('2019-04-17 11:59:59','2019-04-19 07:59:59','NANOETH','4h','0.009851000000000','0.009424000000000','1.297507086516790','1.241265534801972','131.71323586608366','131.713235866083664','test','test','4.33'),('2019-04-19 23:59:59','2019-04-21 11:59:59','NANOETH','4h','0.010080000000000','0.009556000000000','1.285008963913497','1.218208894757676','127.4810480072914','127.481048007291406','test','test','5.19'),('2019-04-21 15:59:59','2019-04-26 03:59:59','NANOETH','4h','0.009910000000000','0.010386000000000','1.270164504101093','1.331173414691619','128.16998023219907','128.169980232199066','test','test','0.95'),('2019-06-09 23:59:59','2019-06-10 03:59:59','NANOETH','4h','0.006484000000000','0.006483000000000','1.283722039787876','1.283524056746576','197.98304129979584','197.983041299795843','test','test','0.01'),('2019-06-10 07:59:59','2019-06-10 23:59:59','NANOETH','4h','0.006548000000000','0.006454000000000','1.283678043556476','1.265250166938530','196.04124061644416','196.041240616444156','test','test','1.43'),('2019-06-13 23:59:59','2019-06-14 11:59:59','NANOETH','4h','0.006924000000000','0.006365000000000','1.279582959863599','1.176277518707656','184.80400922351234','184.804009223512338','test','test','8.07'),('2019-07-09 19:59:59','2019-07-10 03:59:59','NANOETH','4h','0.004515000000000','0.004267000000000','1.256626195162279','1.187602209248604','278.322523845466','278.322523845465980','test','test','5.49'),('2019-07-14 23:59:59','2019-07-15 23:59:59','NANOETH','4h','0.004500000000000','0.004444000000000','1.241287531625906','1.225840397899006','275.8416736946459','275.841673694645920','test','test','1.42'),('2019-07-16 07:59:59','2019-07-20 15:59:59','NANOETH','4h','0.004463000000000','0.004840000000000','1.237854835242151','1.342419314938833','277.3593625906679','277.359362590667899','test','test','0.0'),('2019-07-20 23:59:59','2019-07-30 07:59:59','NANOETH','4h','0.005254000000000','0.006203000000000','1.261091386285858','1.488875117839965','240.02500690633008','240.025006906330077','test','test','1.48'),('2019-08-12 11:59:59','2019-08-12 23:59:59','NANOETH','4h','0.005415000000000','0.005241000000000','1.311709993297882','1.269560863319335','242.23637918705117','242.236379187051170','test','test','3.21'),('2019-08-13 03:59:59','2019-08-13 07:59:59','NANOETH','4h','0.005316000000000','0.005216000000000','1.302343519969316','1.277844958645589','244.9856132372678','244.985613237267813','test','test','1.88'),('2019-08-15 01:59:59','2019-08-18 11:59:59','NANOETH','4h','0.005571000000000','0.005400000000000','1.296899395230710','1.257091497800365','232.79472181488237','232.794721814882365','test','test','3.06'),('2019-08-21 19:59:59','2019-08-22 03:59:59','NANOETH','4h','0.005419000000000','0.005346000000000','1.288053195801744','1.270701676463577','237.69204572831597','237.692045728315975','test','test','1.34'),('2019-08-22 07:59:59','2019-08-22 11:59:59','NANOETH','4h','0.005392000000000','0.005358000000000','1.284197302615485','1.276099619327479','238.16715552957805','238.167155529578054','test','test','0.63'),('2019-08-22 15:59:59','2019-08-22 19:59:59','NANOETH','4h','0.005405000000000','0.005489000000000','1.282397817440373','1.302327774270159','237.2613908307812','237.261390830781210','test','test','0.0'),('2019-08-23 03:59:59','2019-08-23 07:59:59','NANOETH','4h','0.005414000000000','0.005376000000000','1.286826696735881','1.277794665986719','237.68501971479137','237.685019714791366','test','test','0.70'),('2019-08-23 11:59:59','2019-08-23 15:59:59','NANOETH','4h','0.005395000000000','0.005331000000000','1.284819578791623','1.269577974891222','238.15006094376693','238.150060943766931','test','test','1.18'),('2019-08-24 19:59:59','2019-08-25 15:59:59','NANOETH','4h','0.005452000000000','0.005430000000000','1.281432555702644','1.276261697994379','235.03898673929643','235.038986739296433','test','test','1.08'),('2019-08-25 19:59:59','2019-08-26 07:59:59','NANOETH','4h','0.005474000000000','0.005386000000000','1.280283476211919','1.259701644661563','233.8844494358639','233.884449435863900','test','test','1.60'),('2019-08-26 15:59:59','2019-08-27 15:59:59','NANOETH','4h','0.005446000000000','0.005417000000000','1.275709735867395','1.268916569811546','234.24710537410854','234.247105374108543','test','test','0.53'),('2019-08-27 19:59:59','2019-08-28 11:59:59','NANOETH','4h','0.005439000000000','0.005439000000000','1.274200143410540','1.274200143410540','234.27103206665555','234.271032066655550','test','test','0.0'),('2019-08-28 19:59:59','2019-08-31 23:59:59','NANOETH','4h','0.005550000000000','0.005569000000000','1.274200143410540','1.278562270027621','229.58561142532244','229.585611425322440','test','test','0.0'),('2019-09-02 11:59:59','2019-09-03 15:59:59','NANOETH','4h','0.005700000000000','0.005486000000000','1.275169504881002','1.227294719960908','223.71394822473724','223.713948224737237','test','test','3.75'),('2019-10-08 23:59:59','2019-10-09 15:59:59','NANOETH','4h','0.004403000000000','0.004173000000000','1.264530663787648','1.198475235063787','287.1975161906991','287.197516190699105','test','test','5.22'),('2019-10-13 07:59:59','2019-10-14 19:59:59','NANOETH','4h','0.004300000000000','0.004232000000000','1.249851679626790','1.230086583297808','290.66318130855586','290.663181308555863','test','test','1.58'),('2019-10-14 23:59:59','2019-10-15 03:59:59','NANOETH','4h','0.004233000000000','0.004215000000000','1.245459435998127','1.240163364689843','294.2261837935572','294.226183793557198','test','test','0.42'),('2019-10-15 11:59:59','2019-10-19 03:59:59','NANOETH','4h','0.004337000000000','0.004538000000000','1.244282531262953','1.301949302944727','286.8993616008654','286.899361600865404','test','test','0.0'),('2019-10-20 15:59:59','2019-10-21 03:59:59','NANOETH','4h','0.004755000000000','0.004590000000000','1.257097369414459','1.213475694135093','264.3737895719156','264.373789571915609','test','test','3.68'),('2019-10-21 07:59:59','2019-10-23 03:59:59','NANOETH','4h','0.004688000000000','0.004531000000000','1.247403663796822','1.205628413110793','266.084399274066','266.084399274066016','test','test','3.34'),('2019-10-24 23:59:59','2019-10-25 11:59:59','NANOETH','4h','0.004748000000000','0.004595000000000','1.238120274755482','1.198222970198282','260.76669645229197','260.766696452291967','test','test','3.22'),('2019-10-28 03:59:59','2019-10-28 23:59:59','NANOETH','4h','0.004778000000000','0.004574000000000','1.229254207076104','1.176770352274194','257.27379804857765','257.273798048577646','test','test','4.26'),('2019-10-29 03:59:59','2019-10-29 07:59:59','NANOETH','4h','0.004610000000000','0.004559000000000','1.217591128231235','1.204121031151020','264.11955059245884','264.119550592458836','test','test','1.10'),('2019-10-29 15:59:59','2019-10-29 19:59:59','NANOETH','4h','0.004658000000000','0.004542000000000','1.214597773324521','1.184350168836405','260.75521110444845','260.755211104448449','test','test','2.49'),('2019-10-30 15:59:59','2019-11-02 15:59:59','NANOETH','4h','0.004669000000000','0.004668000000000','1.207876083438273','1.207617382199584','258.70123868885685','258.701238688856847','test','test','0.02'),('2019-11-04 19:59:59','2019-11-09 03:59:59','NANOETH','4h','0.004806000000000','0.005245000000000','1.207818594274120','1.318145760917137','251.31473039411563','251.314730394115628','test','test','0.0'),('2019-11-09 11:59:59','2019-11-09 23:59:59','NANOETH','4h','0.005359000000000','0.005279000000000','1.232335742417012','1.213939239451279','229.9562870716575','229.956287071657499','test','test','1.49'),('2019-11-10 03:59:59','2019-11-13 23:59:59','NANOETH','4h','0.005429000000000','0.005272000000000','1.228247630646849','1.192728220440263','226.2382815706114','226.238281570611406','test','test','2.89'),('2019-11-21 19:59:59','2019-11-22 11:59:59','NANOETH','4h','0.005427000000000','0.005287000000000','1.220354428378719','1.188873016922478','224.8672246874367','224.867224687436703','test','test','3.44'),('2019-11-22 23:59:59','2019-11-23 03:59:59','NANOETH','4h','0.005290000000000','0.005175000000000','1.213358559166221','1.186981199184347','229.36834766847278','229.368347668472779','test','test','2.17'),('2019-11-23 15:59:59','2019-11-25 07:59:59','NANOETH','4h','0.005282000000000','0.005383000000000','1.207496923614694','1.230586130219216','228.6060059853642','228.606005985364192','test','test','0.03'),('2019-11-25 15:59:59','2019-12-02 19:59:59','NANOETH','4h','0.005426000000000','0.005730000000000','1.212627858415698','1.280567200280492','223.4846771868224','223.484677186822410','test','test','2.74');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-01  1:12:11
