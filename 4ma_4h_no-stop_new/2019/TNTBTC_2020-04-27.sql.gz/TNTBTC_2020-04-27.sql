-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 19:59:59','2019-01-07 23:59:59','TNTBTC','4h','0.000003360000000','0.000003180000000','0.033333333333333','0.031547619047619','9920.63492063492','9920.634920634920491','test','test','0.0'),('2019-01-09 11:59:59','2019-01-10 07:59:59','TNTBTC','4h','0.000003410000000','0.000003160000000','0.032936507936508','0.030521807941163','9658.799981380645','9658.799981380645477','test','test','6.74'),('2019-01-12 23:59:59','2019-01-13 19:59:59','TNTBTC','4h','0.000003410000000','0.000003140000000','0.032399907937542','0.029834519332517','9501.439277871685','9501.439277871684681','test','test','7.33'),('2019-01-13 23:59:59','2019-01-14 03:59:59','TNTBTC','4h','0.000003190000000','0.000003230000000','0.031829821580870','0.032228941600693','9978.000495570603','9978.000495570602652','test','test','1.56'),('2019-01-14 19:59:59','2019-01-18 11:59:59','TNTBTC','4h','0.000003300000000','0.000004550000000','0.031918514918609','0.044008861478688','9672.27724806323','9672.277248063230218','test','test','2.12'),('2019-01-21 19:59:59','2019-01-22 23:59:59','TNTBTC','4h','0.000004900000000','0.000004430000000','0.034605258598626','0.031285978692227','7062.297673189025','7062.297673189024863','test','test','11.0'),('2019-01-25 15:59:59','2019-01-27 03:59:59','TNTBTC','4h','0.000004540000000','0.000004320000000','0.033867640841649','0.032226477629058','7459.832784504111','7459.832784504111260','test','test','2.42'),('2019-02-10 19:59:59','2019-02-11 19:59:59','TNTBTC','4h','0.000004110000000','0.000004050000000','0.033502937905517','0.033013843921495','8151.566400369181','8151.566400369180883','test','test','0.0'),('2019-02-20 11:59:59','2019-02-20 15:59:59','TNTBTC','4h','0.000003930000000','0.000003940000000','0.033394250353512','0.033479223000722','8497.264720995534','8497.264720995533935','test','test','0.0'),('2019-02-20 23:59:59','2019-02-21 11:59:59','TNTBTC','4h','0.000004070000000','0.000003930000000','0.033413133164004','0.032263787060082','8209.615028010701','8209.615028010701280','test','test','3.19'),('2019-02-21 15:59:59','2019-02-21 23:59:59','TNTBTC','4h','0.000003960000000','0.000004020000000','0.033157722918688','0.033660112659880','8373.162353203927','8373.162353203926614','test','test','0.75'),('2019-02-22 07:59:59','2019-02-24 03:59:59','TNTBTC','4h','0.000004060000000','0.000004130000000','0.033269365083397','0.033842974826214','8194.424897388395','8194.424897388395038','test','test','0.98'),('2019-02-26 15:59:59','2019-02-27 15:59:59','TNTBTC','4h','0.000004190000000','0.000004000000000','0.033396833915134','0.031882419012061','7970.604753015275','7970.604753015274582','test','test','3.57'),('2019-02-27 19:59:59','2019-02-27 23:59:59','TNTBTC','4h','0.000004040000000','0.000004050000000','0.033060297270007','0.033142129688992','8183.2418985165','8183.241898516500441','test','test','0.99'),('2019-03-01 11:59:59','2019-03-01 15:59:59','TNTBTC','4h','0.000004100000000','0.000004020000000','0.033078482252003','0.032433048451964','8067.922500488617','8067.922500488616606','test','test','1.21'),('2019-03-04 15:59:59','2019-03-04 23:59:59','TNTBTC','4h','0.000004190000000','0.000004290000000','0.032935052518661','0.033721091958247','7860.394395861895','7860.394395861894736','test','test','4.05'),('2019-03-05 11:59:59','2019-03-05 19:59:59','TNTBTC','4h','0.000004250000000','0.000004210000000','0.033109727949680','0.032798106980742','7790.524223454222','7790.524223454222010','test','test','0.0'),('2019-03-06 11:59:59','2019-03-06 15:59:59','TNTBTC','4h','0.000004120000000','0.000004150000000','0.033040478845472','0.033281064856483','8019.5337003572795','8019.533700357279486','test','test','0.0'),('2019-03-07 23:59:59','2019-03-08 03:59:59','TNTBTC','4h','0.000004160000000','0.000004150000000','0.033093942403474','0.033014389657312','7955.274616219818','7955.274616219818199','test','test','0.24'),('2019-03-08 07:59:59','2019-03-11 15:59:59','TNTBTC','4h','0.000004210000000','0.000004270000000','0.033076264015438','0.033547659702119','7856.5947780138795','7856.594778013879477','test','test','1.42'),('2019-03-11 19:59:59','2019-03-11 23:59:59','TNTBTC','4h','0.000004280000000','0.000004710000000','0.033181018612479','0.036514625622611','7752.574442167913','7752.574442167912821','test','test','0.23'),('2019-03-12 11:59:59','2019-03-16 11:59:59','TNTBTC','4h','0.000004610000000','0.000004850000000','0.033921820170286','0.035687815146613','7358.312401363509','7358.312401363508798','test','test','6.94'),('2019-03-20 11:59:59','2019-03-21 07:59:59','TNTBTC','4h','0.000004890000000','0.000004840000000','0.034314263498358','0.033963401908395','7017.231799255305','7017.231799255305305','test','test','11.6'),('2019-03-26 23:59:59','2019-04-01 19:59:59','TNTBTC','4h','0.000005120000000','0.000005210000000','0.034236294256144','0.034838104116115','6686.776221903211','6686.776221903211081','test','test','11.1'),('2019-05-21 19:59:59','2019-05-24 23:59:59','TNTBTC','4h','0.000003550000000','0.000004100000000','0.034370029780582','0.039694963971940','9681.698529741534','9681.698529741534003','test','test','0.0'),('2019-06-02 15:59:59','2019-06-02 19:59:59','TNTBTC','4h','0.000004180000000','0.000003740000000','0.035553348489773','0.031810890754007','8505.585763103614','8505.585763103614227','test','test','15.3'),('2019-06-03 11:59:59','2019-06-03 15:59:59','TNTBTC','4h','0.000003690000000','0.000003630000000','0.034721691215158','0.034157110870196','9409.672416032097','9409.672416032097317','test','test','0.0'),('2019-06-05 19:59:59','2019-06-10 07:59:59','TNTBTC','4h','0.000003820000000','0.000004270000000','0.034596228916278','0.038671700909033','9056.604428345026','9056.604428345026463','test','test','4.97'),('2019-06-11 19:59:59','2019-06-13 07:59:59','TNTBTC','4h','0.000004370000000','0.000004220000000','0.035501889359112','0.034283289037861','8124.002141673327','8124.002141673327060','test','test','14.4'),('2019-06-20 23:59:59','2019-06-22 15:59:59','TNTBTC','4h','0.000004870000000','0.000004370000000','0.035231089287723','0.031613934330051','7234.3099153436','7234.309915343599641','test','test','13.3'),('2019-06-22 19:59:59','2019-06-22 23:59:59','TNTBTC','4h','0.000004530000000','0.000004390000000','0.034427277074907','0.033363299416963','7599.840413886828','7599.840413886828173','test','test','3.53'),('2019-06-26 03:59:59','2019-06-26 07:59:59','TNTBTC','4h','0.000004930000000','0.000004770000000','0.034190837595364','0.033081195807279','6935.261175530267','6935.261175530266883','test','test','10.9'),('2019-06-26 11:59:59','2019-06-26 19:59:59','TNTBTC','4h','0.000004800000000','0.000004230000000','0.033944250531345','0.029913370780748','7071.718860696944','7071.718860696943921','test','test','2.70'),('2019-06-26 23:59:59','2019-07-03 23:59:59','TNTBTC','4h','0.000004500000000','0.000005870000000','0.033048499475657','0.043109931538246','7344.110994590469','7344.110994590469090','test','test','5.99'),('2019-07-22 19:59:59','2019-07-23 07:59:59','TNTBTC','4h','0.000004680000000','0.000004350000000','0.035284373267344','0.032796372588236','7539.39599729563','7539.395997295629968','test','test','0.0'),('2019-07-23 11:59:59','2019-07-23 15:59:59','TNTBTC','4h','0.000004400000000','0.000004420000000','0.034731484227542','0.034889354610394','7893.51914262313','7893.519142623130392','test','test','1.13'),('2019-07-23 23:59:59','2019-07-24 03:59:59','TNTBTC','4h','0.000004380000000','0.000004320000000','0.034766566534842','0.034290312198748','7937.572268228816','7937.572268228816029','test','test','0.0'),('2019-08-21 15:59:59','2019-08-23 15:59:59','TNTBTC','4h','0.000003180000000','0.000003110000000','0.034660732237932','0.033897760144644','10899.601332683156','10899.601332683156215','test','test','0.0'),('2019-08-24 03:59:59','2019-08-25 15:59:59','TNTBTC','4h','0.000003220000000','0.000003400000000','0.034491182883868','0.036419261430171','10711.547479462248','10711.547479462247793','test','test','3.41'),('2019-08-27 07:59:59','2019-08-27 19:59:59','TNTBTC','4h','0.000003400000000','0.000003220000000','0.034919644783047','0.033070957706297','10270.483759719671','10270.483759719671070','test','test','2.94'),('2019-09-01 03:59:59','2019-09-01 07:59:59','TNTBTC','4h','0.000003240000000','0.000003170000000','0.034508825432658','0.033763264389360','10650.872047116665','10650.872047116665271','test','test','0.61'),('2019-09-18 03:59:59','2019-09-30 03:59:59','TNTBTC','4h','0.000002830000000','0.000005300000000','0.034343145200814','0.064317551082797','12135.38699675406','12135.386996754059510','test','test','0.0'),('2019-10-02 19:59:59','2019-10-10 11:59:59','TNTBTC','4h','0.000005660000000','0.000006620000000','0.041004124285699','0.047958887415429','7244.544926801962','7244.544926801961992','test','test','43.9'),('2019-10-11 23:59:59','2019-10-12 23:59:59','TNTBTC','4h','0.000007200000000','0.000007020000000','0.042549627203417','0.041485886523332','5909.670444919011','5909.670444919011061','test','test','52.7'),('2019-10-15 03:59:59','2019-10-21 15:59:59','TNTBTC','4h','0.000007560000000','0.000009690000000','0.042313240385620','0.054234827954584','5596.989468997383','5596.989468997382573','test','test','42.8'),('2019-10-21 19:59:59','2019-10-23 15:59:59','TNTBTC','4h','0.000010050000000','0.000009090000000','0.044962482067612','0.040667558407422','4473.878812697732','4473.878812697732428','test','test','56.0'),('2019-10-24 11:59:59','2019-10-25 11:59:59','TNTBTC','4h','0.000010260000000','0.000009820000000','0.044008054587570','0.042120769595510','4289.284072862572','4289.284072862572430','test','test','53.5'),('2019-11-11 15:59:59','2019-11-12 19:59:59','TNTBTC','4h','0.000007750000000','0.000007560000000','0.043588657922668','0.042520032760693','5624.342957763583','5624.342957763583399','test','test','32.7'),('2019-11-12 23:59:59','2019-11-18 11:59:59','TNTBTC','4h','0.000007610000000','0.000008670000000','0.043351185664451','0.049389589975137','5696.607840269527','5696.607840269526605','test','test','0.91'),('2019-11-18 15:59:59','2019-11-18 19:59:59','TNTBTC','4h','0.000008780000000','0.000008490000000','0.044693053289048','0.043216859046016','5090.3249759735745','5090.324975973574510','test','test','13.8'),('2019-11-24 03:59:59','2019-11-24 11:59:59','TNTBTC','4h','0.000008720000000','0.000008360000000','0.044365010123930','0.042533427137162','5087.730518799285','5087.730518799285164','test','test','3.21'),('2019-11-24 19:59:59','2019-11-24 23:59:59','TNTBTC','4h','0.000008300000000','0.000008220000000','0.043957991682426','0.043534300196330','5296.143576195875','5296.143576195874630','test','test','0.0'),('2019-11-25 07:59:59','2019-11-25 23:59:59','TNTBTC','4h','0.000008420000000','0.000009270000000','0.043863838018849','0.048291897676334','5209.481949982052','5209.481949982052356','test','test','2.37'),('2019-11-26 07:59:59','2019-11-30 11:59:59','TNTBTC','4h','0.000009190000000','0.000009210000000','0.044847851276068','0.044945452693426','4880.070867907265','4880.070867907264983','test','test','9.03'),('2019-12-02 11:59:59','2019-12-04 07:59:59','TNTBTC','4h','0.000009570000000','0.000009260000000','0.044869540479925','0.043416086190607','4688.562223607639','4688.562223607638771','test','test','11.2'),('2020-01-01 11:59:59','2020-01-01 15:59:59','TNTBTC','4h','0.000006500000000','0.000006640000000','0.044546550637854','0.045506014805439','6853.315482746836','6853.315482746836096','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 15:00:34
