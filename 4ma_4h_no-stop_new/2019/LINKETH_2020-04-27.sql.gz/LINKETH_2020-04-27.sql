-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-04 11:59:59','2019-01-06 11:59:59','LINKETH','4h','0.002945920000000','0.002453200000000','1.297777777777778','1.080717889299250','440.53395128780744','440.533951287807440','test','test','0.0'),('2019-01-08 15:59:59','2019-01-18 03:59:59','LINKETH','4h','0.002580000000000','0.003878990000000','1.249542247004771','1.878667395623658','484.31870038944635','484.318700389446349','test','test','4.91'),('2019-01-18 23:59:59','2019-01-19 15:59:59','LINKETH','4h','0.004130980000000','0.003915180000000','1.389347835586746','1.316769110219007','336.32402858080803','336.324028580808033','test','test','6.10'),('2019-01-20 15:59:59','2019-01-24 03:59:59','LINKETH','4h','0.004179220000000','0.004200700000000','1.373219229949471','1.380277185515178','328.5826613457705','328.582661345770475','test','test','6.31'),('2019-02-08 07:59:59','2019-02-08 11:59:59','LINKETH','4h','0.003995020000000','0.003885270000000','1.374787664519628','1.337019907116404','344.1253521933878','344.125352193387812','test','test','0.0'),('2019-02-10 07:59:59','2019-02-10 19:59:59','LINKETH','4h','0.003979650000000','0.003836520000000','1.366394829541134','1.317251791346262','343.34547750207525','343.345477502075255','test','test','2.37'),('2019-03-03 19:59:59','2019-03-05 15:59:59','LINKETH','4h','0.003236060000000','0.003103600000000','1.355474154386718','1.299991219431845','418.8655817218216','418.865581721821627','test','test','0.0'),('2019-03-08 03:59:59','2019-03-15 15:59:59','LINKETH','4h','0.003609580000000','0.003553940000000','1.343144613285635','1.322440662609043','372.1055118007179','372.105511800717920','test','test','14.0'),('2019-03-27 19:59:59','2019-03-30 03:59:59','LINKETH','4h','0.003515940000000','0.003450000000000','1.338543735357504','1.313439901415664','380.70721780164155','380.707217801641548','test','test','0.0'),('2019-03-31 07:59:59','2019-04-02 23:59:59','LINKETH','4h','0.003573510000000','0.003570170000000','1.332965105592650','1.331719242714785','373.01283768413975','373.012837684139754','test','test','3.45'),('2019-05-01 19:59:59','2019-05-02 11:59:59','LINKETH','4h','0.002954280000000','0.002928340000000','1.332688247175347','1.320986603075354','451.10424440992296','451.104244409922956','test','test','0.0'),('2019-05-02 19:59:59','2019-05-02 23:59:59','LINKETH','4h','0.002896450000000','0.002861520000000','1.330087881819793','1.314047567051036','459.2131339466564','459.213133946656399','test','test','0.0'),('2019-05-03 15:59:59','2019-05-03 19:59:59','LINKETH','4h','0.002922590000000','0.002985500000000','1.326523367426736','1.355077350381860','453.8862335896365','453.886233589636504','test','test','2.08'),('2019-05-03 23:59:59','2019-05-11 19:59:59','LINKETH','4h','0.003036860000000','0.003610760000000','1.332868696972319','1.584751676494725','438.8969847053598','438.896984705359785','test','test','3.57'),('2019-05-15 19:59:59','2019-05-15 23:59:59','LINKETH','4h','0.003453090000000','0.003402300000000','1.388842692421743','1.368414808888994','402.2028653819456','402.202865381945628','test','test','0.0'),('2019-05-17 11:59:59','2019-05-25 07:59:59','LINKETH','4h','0.003742610000000','0.004716440000000','1.384303162747798','1.744499910199092','369.87641318432816','369.876413184328158','test','test','9.09'),('2019-06-06 07:59:59','2019-06-09 15:59:59','LINKETH','4h','0.004670550000000','0.004504760000000','1.464346884403642','1.412367123997420','313.52771823524887','313.527718235248869','test','test','23.9'),('2019-06-10 07:59:59','2019-06-11 23:59:59','LINKETH','4h','0.004679450000000','0.004597130000000','1.452795826535592','1.427238516928606','310.4629446912761','310.462944691276107','test','test','18.0'),('2019-06-13 19:59:59','2019-06-20 15:59:59','LINKETH','4h','0.006918550000000','0.006482030000000','1.447116424400706','1.355811850237132','209.16469844124944','209.164698441249442','test','test','39.2'),('2019-06-25 07:59:59','2019-06-26 03:59:59','LINKETH','4h','0.006642170000000','0.006220000000000','1.426826519031023','1.336138784218555','214.81330935989638','214.813309359896380','test','test','2.41'),('2019-06-26 07:59:59','2019-06-26 15:59:59','LINKETH','4h','0.006490600000000','0.006124140000000','1.406673689072697','1.327252735678931','216.72475411713816','216.724754117138161','test','test','4.16'),('2019-06-26 19:59:59','2019-07-04 03:59:59','LINKETH','4h','0.006632350000000','0.011642300000000','1.389024588318527','2.438267124711571','209.43173811975046','209.431738119750463','test','test','7.66'),('2019-07-05 15:59:59','2019-07-06 15:59:59','LINKETH','4h','0.012422820000000','0.011803100000000','1.622189596405870','1.541265672797169','130.58142969195964','130.581429691959642','test','test','6.28'),('2019-07-13 07:59:59','2019-07-16 19:59:59','LINKETH','4h','0.012081630000000','0.011354580000000','1.604206502270603','1.507668341651891','132.78063492017247','132.780634920172474','test','test','4.20'),('2019-07-18 11:59:59','2019-07-19 07:59:59','LINKETH','4h','0.012472020000000','0.011680960000000','1.582753577688667','1.482364623440165','126.90434890969281','126.904348909692814','test','test','8.95'),('2019-07-19 11:59:59','2019-07-19 15:59:59','LINKETH','4h','0.011740910000000','0.011830540000000','1.560444921189000','1.572357343504321','132.9066419203452','132.906641920345209','test','test','0.51'),('2019-07-19 23:59:59','2019-07-20 07:59:59','LINKETH','4h','0.011795910000000','0.011807950000000','1.563092126147960','1.564687562972997','132.51136420572558','132.511364205725584','test','test','0.0'),('2019-08-03 15:59:59','2019-08-05 19:59:59','LINKETH','4h','0.011821670000000','0.010835450000000','1.563446667664635','1.433016502333999','132.25260624468754','132.252606244687541','test','test','7.77'),('2019-08-10 19:59:59','2019-08-19 07:59:59','LINKETH','4h','0.011221850000000','0.012397950000000','1.534462186480049','1.695280676971295','136.7387896362943','136.738789636294314','test','test','3.44'),('2019-09-24 03:59:59','2019-09-27 07:59:59','LINKETH','4h','0.009020480000000','0.009650950000000','1.570199628811437','1.679945868476815','174.07051828854307','174.070518288543070','test','test','0.0'),('2019-09-29 07:59:59','2019-09-30 15:59:59','LINKETH','4h','0.010026400000000','0.009674850000000','1.594587682070410','1.538677554843105','159.03890549653016','159.038905496530163','test','test','3.74'),('2019-10-01 11:59:59','2019-10-10 15:59:59','LINKETH','4h','0.009930010000000','0.013316980000000','1.582163209353231','2.121814158867191','159.33148197768497','159.331481977684973','test','test','2.56'),('2019-10-11 03:59:59','2019-10-13 07:59:59','LINKETH','4h','0.014344280000000','0.014243330000000','1.702085642578556','1.690106962183423','118.659538337132','118.659538337132005','test','test','17.7'),('2019-10-18 11:59:59','2019-10-18 19:59:59','LINKETH','4h','0.014063990000000','0.013545390000000','1.699423713601860','1.636758627955900','120.83510537207859','120.835105372078587','test','test','0.0'),('2019-10-18 23:59:59','2019-10-19 03:59:59','LINKETH','4h','0.013638600000000','0.013502880000000','1.685498139013869','1.668725463854618','123.58292926061829','123.582929260618286','test','test','0.68'),('2019-10-20 19:59:59','2019-10-25 23:59:59','LINKETH','4h','0.013871250000000','0.015660850000000','1.681770877867368','1.898744630271185','121.24147988590562','121.241479885905619','test','test','2.65'),('2019-11-09 15:59:59','2019-11-10 19:59:59','LINKETH','4h','0.015462800000000','0.014727770000000','1.729987267290439','1.647751673408575','111.88059518912738','111.880595189127376','test','test','7.88'),('2019-11-12 15:59:59','2019-11-17 07:59:59','LINKETH','4h','0.015029520000000','0.015989420000000','1.711712690872247','1.821035743901770','113.89004378531362','113.890043785313622','test','test','2.00'),('2019-11-22 19:59:59','2019-11-22 23:59:59','LINKETH','4h','0.015815150000000','0.015699910000000','1.736006702656585','1.723356970443224','109.76858914753164','109.768589147531642','test','test','0.0'),('2019-11-23 15:59:59','2019-11-24 03:59:59','LINKETH','4h','0.016092700000000','0.015822910000000','1.733195651053616','1.704139069206085','107.70073704559309','107.700737045593087','test','test','2.44'),('2019-11-24 11:59:59','2019-11-24 15:59:59','LINKETH','4h','0.015788130000000','0.015566920000000','1.726738632865276','1.702545023300614','109.36942075250683','109.369420752506826','test','test','0.0'),('2019-11-24 19:59:59','2019-11-24 23:59:59','LINKETH','4h','0.015682380000000','0.015896840000000','1.721362275184240','1.744902283367692','109.76409672410948','109.764096724109478','test','test','0.73'),('2019-12-10 19:59:59','2019-12-12 07:59:59','LINKETH','4h','0.015186650000000','0.014520610000000','1.726593388113896','1.650870285242665','113.69152433972573','113.691524339725731','test','test','0.0'),('2019-12-12 11:59:59','2019-12-12 15:59:59','LINKETH','4h','0.014540170000000','0.014525060000000','1.709766031920289','1.707989260070832','117.58913629760099','117.589136297600987','test','test','0.13'),('2019-12-16 19:59:59','2019-12-17 07:59:59','LINKETH','4h','0.015055820000000','0.014345780000000','1.709371193731521','1.628756393448499','113.53557585913758','113.535575859137580','test','test','3.52'),('2019-12-20 23:59:59','2019-12-22 11:59:59','LINKETH','4h','0.014954100000000','0.014558630000000','1.691456793668627','1.646725220508615','113.109902546367','113.109902546366996','test','test','4.06'),('2019-12-22 15:59:59','2019-12-22 23:59:59','LINKETH','4h','0.014733000000000','0.014571380000000','1.681516444077513','1.663070323959967','114.13265757669946','114.132657576699458','test','test','1.18'),('2019-12-23 19:59:59','2019-12-23 23:59:59','LINKETH','4h','0.014749900000000','0.014568950000000','1.677417306273614','1.656838952415608','113.72397821501258','113.723978215012579','test','test','1.21'),('2019-12-27 03:59:59','2019-12-28 07:59:59','LINKETH','4h','0.014838000000000','0.014653180000000','1.672844338749613','1.652007629578047','112.74055389874731','112.740553898747308','test','test','1.81'),('2019-12-28 11:59:59','2019-12-28 19:59:59','LINKETH','4h','0.014760460000000','0.014665560000000','1.668213958933709','1.657488445995575','113.01910366842965','113.019103668429651','test','test','0.72');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 13:06:19
