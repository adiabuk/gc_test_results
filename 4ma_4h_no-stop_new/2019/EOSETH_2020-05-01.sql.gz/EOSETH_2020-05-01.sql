-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 03:59:59','2019-01-10 19:59:59','EOSETH','4h','0.019393000000000','0.018863000000000','1.297777777777778','1.262310226484929','66.91990809971524','66.919908099715244','test','test','2.73'),('2019-01-10 23:59:59','2019-01-14 15:59:59','EOSETH','4h','0.018998000000000','0.018867000000000','1.289896099712700','1.281001669295689','67.89641539702602','67.896415397026018','test','test','1.21'),('2019-01-15 23:59:59','2019-01-19 19:59:59','EOSETH','4h','0.019693000000000','0.019802000000000','1.287919559620031','1.295048145005629','65.39986592291835','65.399865922918352','test','test','0.29'),('2019-01-21 11:59:59','2019-02-10 07:59:59','EOSETH','4h','0.020259000000000','0.022877000000000','1.289503689705719','1.456141759682005','63.65090526214125','63.650905262141251','test','test','1.62'),('2019-02-10 11:59:59','2019-02-10 23:59:59','EOSETH','4h','0.023039000000000','0.022686000000000','1.326534371922672','1.306209417137798','57.57777559454282','57.577775594542821','test','test','1.53'),('2019-02-12 03:59:59','2019-02-14 07:59:59','EOSETH','4h','0.023099000000000','0.022735000000000','1.322017715303811','1.301185019153736','57.23268173097584','57.232681730975841','test','test','1.57'),('2019-02-19 03:59:59','2019-02-24 19:59:59','EOSETH','4h','0.024656000000000','0.025647000000000','1.317388227270461','1.370338086664727','53.43073601843207','53.430736018432071','test','test','1.56'),('2019-02-24 23:59:59','2019-02-25 07:59:59','EOSETH','4h','0.026685000000000','0.025736000000000','1.329154862691409','1.281886061316324','49.809063619689304','49.809063619689304','test','test','3.55'),('2019-02-28 15:59:59','2019-03-01 23:59:59','EOSETH','4h','0.026032000000000','0.025633000000000','1.318650684608057','1.298439343829069','50.654989421022464','50.654989421022464','test','test','1.53'),('2019-03-02 03:59:59','2019-03-04 07:59:59','EOSETH','4h','0.025841000000000','0.025897000000000','1.314159275546060','1.317007188530487','50.85558900762585','50.855589007625852','test','test','0.0'),('2019-03-05 15:59:59','2019-03-09 03:59:59','EOSETH','4h','0.027063000000000','0.027082000000000','1.314792145098154','1.315715215369627','48.58264586698276','48.582645866982759','test','test','0.75'),('2019-03-09 07:59:59','2019-03-11 07:59:59','EOSETH','4h','0.027386000000000','0.026933000000000','1.314997271825148','1.293245509459823','48.01713546429374','48.017135464293737','test','test','1.65'),('2019-03-12 19:59:59','2019-03-13 11:59:59','EOSETH','4h','0.027391000000000','0.026778000000000','1.310163546855076','1.280842592737951','47.83189904914302','47.831899049143018','test','test','2.23'),('2019-03-26 07:59:59','2019-03-30 11:59:59','EOSETH','4h','0.027174000000000','0.029744000000000','1.303647779273493','1.426941177107190','47.97408476019331','47.974084760193307','test','test','0.01'),('2019-04-02 07:59:59','2019-04-07 19:59:59','EOSETH','4h','0.030354000000000','0.031790000000000','1.331046312125425','1.394016019716257','43.85077130280772','43.850771302807722','test','test','0.70'),('2019-04-10 07:59:59','2019-04-10 23:59:59','EOSETH','4h','0.032187000000000','0.032975000000000','1.345039580478944','1.377968750312026','41.78828659020548','41.788286590205480','test','test','0.0'),('2019-04-11 07:59:59','2019-04-11 19:59:59','EOSETH','4h','0.032914000000000','0.031768000000000','1.352357173775184','1.305270787400196','41.08759718585357','41.087597185853568','test','test','3.48'),('2019-04-11 23:59:59','2019-04-17 15:59:59','EOSETH','4h','0.032166000000000','0.032614000000000','1.341893532358520','1.360583089732661','41.71776199585029','41.717761995850289','test','test','0.0'),('2019-05-05 19:59:59','2019-05-05 23:59:59','EOSETH','4h','0.030178000000000','0.029936000000000','1.346046767330551','1.335252701531161','44.603577683430025','44.603577683430025','test','test','0.80'),('2019-05-27 11:59:59','2019-06-01 23:59:59','EOSETH','4h','0.026158000000000','0.029174000000000','1.343648086041798','1.498569816583203','51.36662153229598','51.366621532295980','test','test','0.0'),('2019-07-21 03:59:59','2019-07-22 19:59:59','EOSETH','4h','0.018882000000000','0.019049000000000','1.378075137273221','1.390263387878275','72.98353655720906','72.983536557209064','test','test','0.64'),('2019-07-23 07:59:59','2019-07-27 23:59:59','EOSETH','4h','0.019023000000000','0.020632000000000','1.380783637407678','1.497572833254230','72.58495702085254','72.584957020852542','test','test','0.0'),('2019-08-11 19:59:59','2019-08-13 03:59:59','EOSETH','4h','0.019576000000000','0.019292000000000','1.406736792040245','1.386328473234594','71.86027748468764','71.860277484687643','test','test','1.45'),('2019-08-13 07:59:59','2019-08-13 11:59:59','EOSETH','4h','0.019329000000000','0.019299000000000','1.402201610083434','1.400025292203435','72.54392933330405','72.543929333304050','test','test','0.15'),('2019-08-13 15:59:59','2019-08-14 19:59:59','EOSETH','4h','0.019565000000000','0.019492000000000','1.401717983887878','1.396487960232176','71.64415966715454','71.644159667154540','test','test','0.60'),('2019-08-14 23:59:59','2019-08-15 15:59:59','EOSETH','4h','0.019632000000000','0.019185000000000','1.400555756408834','1.368666574302337','71.34045213981427','71.340452139814275','test','test','2.27'),('2019-08-25 03:59:59','2019-08-25 15:59:59','EOSETH','4h','0.019252000000000','0.019061000000000','1.393469271496279','1.379644597132276','72.38049405237268','72.380494052372683','test','test','0.99'),('2019-08-25 23:59:59','2019-08-26 03:59:59','EOSETH','4h','0.019037000000000','0.019054000000000','1.390397121637611','1.391638743272734','73.03656677194995','73.036566771949950','test','test','0.0'),('2019-08-30 23:59:59','2019-08-31 03:59:59','EOSETH','4h','0.019079000000000','0.019046000000000','1.390673037556527','1.388267659379507','72.89024778848616','72.890247788486164','test','test','0.17'),('2019-08-31 11:59:59','2019-09-01 11:59:59','EOSETH','4h','0.019225000000000','0.019240000000000','1.390138509072745','1.391223142499850','72.30889514032486','72.308895140324864','test','test','0.58'),('2019-09-01 15:59:59','2019-09-01 19:59:59','EOSETH','4h','0.019285000000000','0.018940000000000','1.390379538723213','1.365506272409523','72.0964240976517','72.096424097651706','test','test','1.78'),('2019-09-07 15:59:59','2019-09-12 15:59:59','EOSETH','4h','0.019671000000000','0.020813000000000','1.384852146209060','1.465249744245293','70.40069880580853','70.400698805808531','test','test','0.0'),('2019-09-14 15:59:59','2019-09-16 11:59:59','EOSETH','4h','0.021251000000000','0.020841000000000','1.402718279106000','1.375655341153270','66.00716573836527','66.007165738365273','test','test','1.92'),('2019-10-07 03:59:59','2019-10-09 15:59:59','EOSETH','4h','0.017254000000000','0.017030000000000','1.396704292894283','1.378571583864011','80.94959388514447','80.949593885144466','test','test','1.29'),('2019-10-14 15:59:59','2019-10-14 19:59:59','EOSETH','4h','0.017168000000000','0.017010000000000','1.392674801998667','1.379857780871233','81.12038688249457','81.120386882494572','test','test','0.92'),('2019-10-22 15:59:59','2019-10-22 23:59:59','EOSETH','4h','0.017275000000000','0.016901000000000','1.389826575081459','1.359737131429912','80.45305789183556','80.453057891835556','test','test','2.16'),('2019-10-23 03:59:59','2019-10-23 19:59:59','EOSETH','4h','0.017198000000000','0.016709000000000','1.383140032047782','1.343812466303430','80.42446982485068','80.424469824850675','test','test','2.84'),('2019-10-23 23:59:59','2019-10-24 03:59:59','EOSETH','4h','0.016734000000000','0.016815000000000','1.374400572993482','1.381053282830489','82.13222020996066','82.132220209960664','test','test','0.0'),('2019-10-24 19:59:59','2019-10-30 03:59:59','EOSETH','4h','0.017041000000000','0.017774000000000','1.375878952957261','1.435060883156057','80.73933178553258','80.739331785532585','test','test','0.77'),('2019-11-01 15:59:59','2019-11-03 15:59:59','EOSETH','4h','0.018150000000000','0.018063000000000','1.389030493001438','1.382372330307712','76.53060567501035','76.530605675010349','test','test','0.70'),('2019-11-04 15:59:59','2019-11-07 15:59:59','EOSETH','4h','0.018493000000000','0.018550000000000','1.387550901291721','1.391827676361944','75.03114158285412','75.031141582854119','test','test','0.0'),('2019-11-08 07:59:59','2019-11-08 15:59:59','EOSETH','4h','0.018796000000000','0.018559000000000','1.388501295751770','1.370993591607634','73.87216938453768','73.872169384537685','test','test','1.26'),('2019-11-09 15:59:59','2019-11-11 11:59:59','EOSETH','4h','0.018866000000000','0.018555000000000','1.384610694830851','1.361785828611600','73.3918527950202','73.391852795020199','test','test','1.64'),('2019-11-30 03:59:59','2019-12-02 23:59:59','EOSETH','4h','0.018065000000000','0.017986000000000','1.379538502337684','1.373505646445922','76.3652644526811','76.365264452681103','test','test','0.43'),('2019-12-03 15:59:59','2019-12-04 03:59:59','EOSETH','4h','0.018281000000000','0.017966000000000','1.378197867695071','1.354450133527140','75.38963227914614','75.389632279146142','test','test','1.72'),('2019-12-05 11:59:59','2019-12-05 15:59:59','EOSETH','4h','0.018285000000000','0.018074000000000','1.372920593435530','1.357077758039583','75.08452794287834','75.084527942878339','test','test','1.15'),('2019-12-05 19:59:59','2019-12-05 23:59:59','EOSETH','4h','0.018158000000000','0.018127000000000','1.369399963347542','1.367062073774694','75.4157926725158','75.415792672515806','test','test','0.17'),('2019-12-06 03:59:59','2019-12-08 15:59:59','EOSETH','4h','0.018211000000000','0.018206000000000','1.368880432331354','1.368504593433893','75.16777949213956','75.167779492139559','test','test','0.02'),('2019-12-08 19:59:59','2019-12-08 23:59:59','EOSETH','4h','0.018282000000000','0.018214000000000','1.368796912576362','1.363705664898034','74.87128938717659','74.871289387176589','test','test','0.37'),('2019-12-18 23:59:59','2019-12-22 19:59:59','EOSETH','4h','0.018515000000000','0.019069000000000','1.367665524203401','1.408588381368331','73.8679732218958','73.867973221895795','test','test','0.0'),('2019-12-23 07:59:59','2019-12-29 19:59:59','EOSETH','4h','0.019262000000000','0.020102000000000','1.376759492462274','1.436798843187448','71.47541752996956','71.475417529969562','test','test','0.52');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-01  0:58:56
