-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 23:59:59','2019-01-13 07:59:59','XVGETH','4h','0.000059140000000','0.000054870000000','1.297777777777778','1.204076203359261','21944.162627287416','21944.162627287416399','test','test','0.0'),('2019-01-14 03:59:59','2019-01-14 15:59:59','XVGETH','4h','0.000056210000000','0.000054290000000','1.276955205684774','1.233337450927351','22717.580602824655','22717.580602824655216','test','test','2.70'),('2019-01-16 03:59:59','2019-01-17 19:59:59','XVGETH','4h','0.000055890000000','0.000054750000000','1.267262371294236','1.241413756098755','22674.223855685017','22674.223855685017043','test','test','2.86'),('2019-01-19 07:59:59','2019-01-20 15:59:59','XVGETH','4h','0.000055290000000','0.000054950000000','1.261518234584129','1.253760661790521','22816.390569436222','22816.390569436221995','test','test','0.97'),('2019-01-20 19:59:59','2019-01-26 19:59:59','XVGETH','4h','0.000055290000000','0.000056910000000','1.259794329518882','1.296706371729419','22785.21124107221','22785.211241072211124','test','test','0.61'),('2019-01-28 23:59:59','2019-01-29 11:59:59','XVGETH','4h','0.000057290000000','0.000057470000000','1.267997005565668','1.271980937508447','22132.955237662216','22132.955237662215950','test','test','1.08'),('2019-01-29 15:59:59','2019-01-30 15:59:59','XVGETH','4h','0.000057510000000','0.000057030000000','1.268882323775175','1.258291756649248','22063.68151234872','22063.681512348721299','test','test','1.04'),('2019-03-02 15:59:59','2019-03-05 15:59:59','XVGETH','4h','0.000045280000000','0.000046920000000','1.266528864413858','1.312401376287505','27971.043825394383','27971.043825394383020','test','test','0.0'),('2019-03-09 07:59:59','2019-03-10 07:59:59','XVGETH','4h','0.000046840000000','0.000046240000000','1.276722755941335','1.260368493482650','27257.104097808176','27257.104097808176448','test','test','3.45'),('2019-03-10 11:59:59','2019-03-10 15:59:59','XVGETH','4h','0.000046700000000','0.000046750000000','1.273088475394961','1.274451525154485','27260.995190470247','27260.995190470246598','test','test','0.98'),('2019-03-10 19:59:59','2019-03-16 11:59:59','XVGETH','4h','0.000047300000000','0.000049770000000','1.273391375341521','1.339887711432294','26921.593559017365','26921.593559017364896','test','test','1.16'),('2019-03-21 19:59:59','2019-03-21 23:59:59','XVGETH','4h','0.000050340000000','0.000050710000000','1.288168338917249','1.297636401797650','25589.359136218685','25589.359136218685308','test','test','1.13'),('2019-03-22 11:59:59','2019-03-24 11:59:59','XVGETH','4h','0.000050630000000','0.000050140000000','1.290272352890671','1.277785024174170','25484.34431938912','25484.344319389121665','test','test','0.0'),('2019-03-24 15:59:59','2019-03-24 23:59:59','XVGETH','4h','0.000050230000000','0.000050170000000','1.287497390953671','1.285959468527687','25632.040433081245','25632.040433081245283','test','test','0.17'),('2019-03-27 19:59:59','2019-03-29 11:59:59','XVGETH','4h','0.000051150000000','0.000050490000000','1.287155630414563','1.270547170667278','25164.332950431348','25164.332950431347854','test','test','1.91'),('2019-03-29 15:59:59','2019-03-29 23:59:59','XVGETH','4h','0.000050700000000','0.000050360000000','1.283464861581833','1.274857799393710','25314.88878859632','25314.888788596319500','test','test','0.41'),('2019-03-31 11:59:59','2019-04-02 15:59:59','XVGETH','4h','0.000053700000000','0.000051190000000','1.281552181095584','1.221650952519236','23865.031305318138','23865.031305318138038','test','test','6.21'),('2019-04-03 15:59:59','2019-04-03 19:59:59','XVGETH','4h','0.000052500000000','0.000051810000000','1.268240796967506','1.251572489350219','24156.967561285837','24156.967561285837292','test','test','3.40'),('2019-04-03 23:59:59','2019-04-08 03:59:59','XVGETH','4h','0.000053460000000','0.000059300000000','1.264536728608109','1.402675420996275','23653.88568290515','23653.885682905151043','test','test','3.08'),('2019-04-08 07:59:59','2019-04-09 15:59:59','XVGETH','4h','0.000059600000000','0.000055730000000','1.295234215805480','1.211130920248983','21732.117714857042','21732.117714857042301','test','test','5.92'),('2019-05-19 15:59:59','2019-05-21 23:59:59','XVGETH','4h','0.000043720000000','0.000042850000000','1.276544594570703','1.251142174687892','29198.18377334635','29198.183773346350790','test','test','0.0'),('2019-05-22 07:59:59','2019-05-24 15:59:59','XVGETH','4h','0.000042130000000','0.000043710000000','1.270899612374522','1.318562118606465','30166.14318477385','30166.143184773849498','test','test','0.0'),('2019-05-24 19:59:59','2019-05-24 23:59:59','XVGETH','4h','0.000043880000000','0.000043310000000','1.281491280426065','1.264844743738671','29204.45032876174','29204.450328761740820','test','test','3.89'),('2019-05-25 15:59:59','2019-05-25 19:59:59','XVGETH','4h','0.000046260000000','0.000044180000000','1.277792050051089','1.220338365137421','27621.963900801744','27621.963900801743875','test','test','6.37'),('2019-07-15 15:59:59','2019-07-23 11:59:59','XVGETH','4h','0.000026170000000','0.000027000000000','1.265024564514718','1.305145710427871','48338.73001584708','48338.730015847082541','test','test','0.0'),('2019-07-26 07:59:59','2019-07-28 19:59:59','XVGETH','4h','0.000027610000000','0.000027520000000','1.273940374717641','1.269787725904726','46140.54236572404','46140.542365724038973','test','test','2.20'),('2019-08-16 23:59:59','2019-08-19 15:59:59','XVGETH','4h','0.000026600000000','0.000026250000000','1.273017563870326','1.256267332766769','47857.80315301979','47857.803153019791353','test','test','0.0'),('2019-08-21 03:59:59','2019-08-21 07:59:59','XVGETH','4h','0.000027230000000','0.000026500000000','1.269295290291758','1.235267175641997','46613.85568460368','46613.855684603680857','test','test','3.85'),('2019-08-23 15:59:59','2019-08-27 07:59:59','XVGETH','4h','0.000026750000000','0.000027110000000','1.261733487036256','1.278713825553379','47167.60699200956','47167.606992009561509','test','test','1.15'),('2019-10-07 23:59:59','2019-10-09 15:59:59','XVGETH','4h','0.000019670000000','0.000019260000000','1.265506895595616','1.239128765082438','64336.90369067699','64336.903690676990664','test','test','0.0'),('2019-10-09 19:59:59','2019-10-09 23:59:59','XVGETH','4h','0.000019520000000','0.000019440000000','1.259645088814910','1.254482608942718','64530.9984024032','64530.998402403201908','test','test','1.33'),('2019-10-11 19:59:59','2019-10-16 03:59:59','XVGETH','4h','0.000020710000000','0.000019960000000','1.258497871065534','1.212922139375570','60767.6422532851','60767.642253285099287','test','test','6.13'),('2019-10-28 03:59:59','2019-10-29 23:59:59','XVGETH','4h','0.000020560000000','0.000019780000000','1.248369930689987','1.201009592852526','60718.3818428982','60718.381842898197647','test','test','2.91'),('2019-10-30 07:59:59','2019-10-31 03:59:59','XVGETH','4h','0.000021010000000','0.000020150000000','1.237845411170551','1.187176822231633','58916.96388246315','58916.963882463147456','test','test','5.85'),('2019-10-31 07:59:59','2019-11-01 03:59:59','XVGETH','4h','0.000020370000000','0.000020460000000','1.226585724739681','1.232005102021300','60215.30312909576','60215.303129095758777','test','test','1.08'),('2019-11-01 07:59:59','2019-11-04 23:59:59','XVGETH','4h','0.000020710000000','0.000020750000000','1.227790030802262','1.230161426322884','59284.88801556072','59284.888015560718486','test','test','1.20'),('2019-11-06 11:59:59','2019-11-06 15:59:59','XVGETH','4h','0.000021100000000','0.000020740000000','1.228317007584623','1.207359940156639','58214.07618884468','58214.076188844679564','test','test','1.65'),('2019-11-06 23:59:59','2019-11-07 15:59:59','XVGETH','4h','0.000021290000000','0.000020820000000','1.223659881489515','1.196646253293175','57475.80467306318','57475.804673063183145','test','test','2.58'),('2019-11-07 19:59:59','2019-11-08 15:59:59','XVGETH','4h','0.000021220000000','0.000020340000000','1.217656853001440','1.167160244582907','57382.509566514585','57382.509566514585458','test','test','1.88'),('2019-11-14 15:59:59','2019-11-17 23:59:59','XVGETH','4h','0.000021250000000','0.000024640000000','1.206435384463988','1.398897311679655','56773.42985712884','56773.429857128838194','test','test','4.28'),('2019-11-22 11:59:59','2019-11-22 23:59:59','XVGETH','4h','0.000025120000000','0.000024930000000','1.249204701623025','1.239756099182405','49729.48652957902','49729.486529579022317','test','test','3.26'),('2019-11-23 07:59:59','2019-11-23 11:59:59','XVGETH','4h','0.000024350000000','0.000024680000000','1.247105012191776','1.264006230016141','51215.81158898465','51215.811588984652190','test','test','0.0'),('2019-11-23 15:59:59','2019-11-25 03:59:59','XVGETH','4h','0.000025210000000','0.000024440000000','1.250860838374968','1.212655251482912','49617.645314358124','49617.645314358123869','test','test','2.41'),('2019-11-25 23:59:59','2019-11-30 07:59:59','XVGETH','4h','0.000025240000000','0.000025940000000','1.242370707954511','1.276826313959589','49222.29429296797','49222.294292967970250','test','test','3.16'),('2019-12-03 23:59:59','2019-12-10 03:59:59','XVGETH','4h','0.000026790000000','0.000029200000000','1.250027509288973','1.362478658874133','46660.22804363469','46660.228043634691858','test','test','8.02'),('2019-12-14 15:59:59','2019-12-16 15:59:59','XVGETH','4h','0.000031340000000','0.000029630000000','1.275016653641231','1.205448099789077','40683.36482582104','40683.364825821037812','test','test','15.4'),('2019-12-19 23:59:59','2019-12-21 19:59:59','XVGETH','4h','0.000031010000000','0.000030860000000','1.259556975007419','1.253464309859044','40617.767655834214','40617.767655834213656','test','test','11.2');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 13:35:58
