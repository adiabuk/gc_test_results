-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 23:59:59','2019-01-03 15:59:59','MCOBTC','4h','0.000596000000000','0.000605000000000','0.033333333333333','0.033836689038031','55.928411633109626','55.928411633109626','test','test','0.33'),('2019-01-04 03:59:59','2019-01-09 03:59:59','MCOBTC','4h','0.000607000000000','0.000659000000000','0.033445190156600','0.036310346479735','55.099160060295816','55.099160060295816','test','test','0.49'),('2019-01-09 11:59:59','2019-01-09 15:59:59','MCOBTC','4h','0.000664000000000','0.000653000000000','0.034081891561741','0.033517281912375','51.32814994238052','51.328149942380520','test','test','1.65'),('2019-01-19 11:59:59','2019-01-20 11:59:59','MCOBTC','4h','0.000635000000000','0.000626000000000','0.033956422750770','0.033475150617295','53.474681497276286','53.474681497276286','test','test','1.41'),('2019-01-20 15:59:59','2019-01-20 19:59:59','MCOBTC','4h','0.000632000000000','0.000633000000000','0.033849473387776','0.033903032681111','53.559293335088604','53.559293335088604','test','test','0.0'),('2019-01-21 03:59:59','2019-01-21 07:59:59','MCOBTC','4h','0.000633000000000','0.000624000000000','0.033861375452962','0.033379934095811','53.49348412790134','53.493484127901340','test','test','1.42'),('2019-02-10 03:59:59','2019-02-10 07:59:59','MCOBTC','4h','0.000584000000000','0.000572000000000','0.033754388484706','0.033060805159678','57.79861041901675','57.798610419016747','test','test','2.05'),('2019-02-10 11:59:59','2019-02-11 03:59:59','MCOBTC','4h','0.000586000000000','0.000582000000000','0.033600258856922','0.033370905554144','57.338325694405746','57.338325694405746','test','test','1.02'),('2019-02-12 19:59:59','2019-02-13 03:59:59','MCOBTC','4h','0.000583000000000','0.000579000000000','0.033549291456304','0.033319107638422','57.545954470505045','57.545954470505045','test','test','0.68'),('2019-02-15 03:59:59','2019-02-19 15:59:59','MCOBTC','4h','0.000684000000000','0.000706000000000','0.033498139496775','0.034575565036145','48.973888153179985','48.973888153179985','test','test','2.92'),('2019-02-20 11:59:59','2019-02-22 23:59:59','MCOBTC','4h','0.000761000000000','0.000762000000000','0.033737567394413','0.033781900597297','44.33320288359119','44.333202883591191','test','test','0.0'),('2019-03-10 11:59:59','2019-03-18 23:59:59','MCOBTC','4h','0.000706000000000','0.000815000000000','0.033747419217276','0.038957714818810','47.80087707829461','47.800877078294612','test','test','0.0'),('2019-03-19 11:59:59','2019-03-21 15:59:59','MCOBTC','4h','0.000832000000000','0.000801000000000','0.034905262684284','0.033604706021769','41.95344072630235','41.953440726302347','test','test','3.72'),('2019-03-26 19:59:59','2019-03-30 07:59:59','MCOBTC','4h','0.000822000000000','0.000844000000000','0.034616250092614','0.035542719073195','42.112226390040824','42.112226390040824','test','test','0.0'),('2019-03-31 15:59:59','2019-04-01 19:59:59','MCOBTC','4h','0.000868000000000','0.000848000000000','0.034822132088298','0.034019778814374','40.11766369619611','40.117663696196111','test','test','2.30'),('2019-04-12 15:59:59','2019-04-13 23:59:59','MCOBTC','4h','0.000796000000000','0.000782000000000','0.034643831360760','0.034034517743862','43.52240120698436','43.522401206984362','test','test','1.75'),('2019-04-14 03:59:59','2019-04-15 23:59:59','MCOBTC','4h','0.000783000000000','0.000790000000000','0.034508428334782','0.034816932802654','44.07206683880232','44.072066838802321','test','test','0.0'),('2019-04-16 03:59:59','2019-04-23 07:59:59','MCOBTC','4h','0.000800000000000','0.000896000000000','0.034576984883198','0.038726223069182','43.22123110399777','43.221231103997773','test','test','0.0'),('2019-04-27 19:59:59','2019-04-28 11:59:59','MCOBTC','4h','0.000894000000000','0.000877000000000','0.035499037813417','0.034824000181618','39.708095988162064','39.708095988162064','test','test','1.90'),('2019-04-30 15:59:59','2019-05-01 15:59:59','MCOBTC','4h','0.000890000000000','0.000898000000000','0.035349029450795','0.035666773535746','39.718010618870665','39.718010618870665','test','test','0.0'),('2019-05-01 23:59:59','2019-05-02 03:59:59','MCOBTC','4h','0.000887000000000','0.000886000000000','0.035419639247451','0.035379707297905','39.93194954616761','39.931949546167608','test','test','0.11'),('2019-05-26 15:59:59','2019-05-27 03:59:59','MCOBTC','4h','0.000692000000000','0.000783000000000','0.035410765480885','0.040067383484874','51.17162641746371','51.171626417463713','test','test','3.75'),('2019-05-27 11:59:59','2019-06-01 07:59:59','MCOBTC','4h','0.000800000000000','0.000770000000000','0.036445569481771','0.035078860626205','45.556961852214165','45.556961852214165','test','test','4.87'),('2019-06-02 15:59:59','2019-06-03 11:59:59','MCOBTC','4h','0.000781000000000','0.000760000000000','0.036141856402757','0.035170052325346','46.27638463861289','46.276384638612889','test','test','2.68'),('2019-06-04 15:59:59','2019-06-05 11:59:59','MCOBTC','4h','0.000781000000000','0.000762000000000','0.035925899941110','0.035051902375321','45.99987188362327','45.999871883623271','test','test','2.43'),('2019-06-08 15:59:59','2019-06-09 15:59:59','MCOBTC','4h','0.000775000000000','0.000761000000000','0.035731678259823','0.035086202781581','46.10539130299785','46.105391302997852','test','test','1.80'),('2019-06-09 19:59:59','2019-06-10 15:59:59','MCOBTC','4h','0.000770000000000','0.000769000000000','0.035588239264658','0.035542020772106','46.21849255150448','46.218492551504482','test','test','0.12'),('2019-06-10 19:59:59','2019-06-13 23:59:59','MCOBTC','4h','0.000773000000000','0.000793000000000','0.035577968488536','0.036498485137657','46.025832456061806','46.025832456061806','test','test','0.0'),('2019-07-24 19:59:59','2019-07-25 03:59:59','MCOBTC','4h','0.000486000000000','0.000470000000000','0.035782527743896','0.034604502139159','73.6266002960823','73.626600296082302','test','test','3.29'),('2019-07-25 07:59:59','2019-07-25 11:59:59','MCOBTC','4h','0.000472000000000','0.000463000000000','0.035520744276177','0.034843441948877','75.25581414444208','75.255814144442084','test','test','1.90'),('2019-07-25 15:59:59','2019-07-26 03:59:59','MCOBTC','4h','0.000472000000000','0.000463000000000','0.035370232647888','0.034695800245704','74.93693357603344','74.936933576033439','test','test','1.90'),('2019-07-29 07:59:59','2019-07-29 11:59:59','MCOBTC','4h','0.000463000000000','0.000462000000000','0.035220358780736','0.035144288891361','76.06988937523927','76.069889375239271','test','test','0.21'),('2019-07-29 15:59:59','2019-07-29 23:59:59','MCOBTC','4h','0.000468000000000','0.000469000000000','0.035203454360875','0.035278675417202','75.22105632665527','75.221056326655273','test','test','0.64'),('2019-07-30 03:59:59','2019-07-30 07:59:59','MCOBTC','4h','0.000481000000000','0.000465000000000','0.035220170151170','0.034048605239697','73.22280696708847','73.222806967088474','test','test','3.32'),('2019-07-30 11:59:59','2019-07-30 15:59:59','MCOBTC','4h','0.000466000000000','0.000458000000000','0.034959822393064','0.034359653768290','75.02107809670481','75.021078096704812','test','test','1.71'),('2019-08-23 07:59:59','2019-08-25 15:59:59','MCOBTC','4h','0.000341000000000','0.000340000000000','0.034826451587559','0.034724321230997','102.13035656175694','102.130356561756940','test','test','0.87'),('2019-08-26 15:59:59','2019-08-27 07:59:59','MCOBTC','4h','0.000355000000000','0.000346000000000','0.034803755952768','0.033921407210303','98.03874916272551','98.038749162725509','test','test','3.66'),('2019-08-27 15:59:59','2019-08-28 19:59:59','MCOBTC','4h','0.000347000000000','0.000347000000000','0.034607678454442','0.034607678454442','99.73394367274351','99.733943672743507','test','test','0.86'),('2019-08-28 23:59:59','2019-08-29 03:59:59','MCOBTC','4h','0.000350000000000','0.000343000000000','0.034607678454442','0.033915524885353','98.8790812984057','98.879081298405694','test','test','2.00'),('2019-09-01 03:59:59','2019-09-01 15:59:59','MCOBTC','4h','0.000345000000000','0.000341000000000','0.034453866550200','0.034054401430777','99.86627985565217','99.866279855652166','test','test','1.15'),('2019-09-14 11:59:59','2019-09-19 07:59:59','MCOBTC','4h','0.000326000000000','0.000327800000000','0.034365096523662','0.034554842455388','105.41440651429924','105.414406514299245','test','test','2.45'),('2019-09-19 15:59:59','2019-09-21 23:59:59','MCOBTC','4h','0.000328500000000','0.000326200000000','0.034407262286267','0.034166359080001','104.74052446352307','104.740524463523073','test','test','0.70'),('2019-09-23 19:59:59','2019-09-24 19:59:59','MCOBTC','4h','0.000333800000000','0.000327200000000','0.034353728240430','0.033674475375281','102.91710078019906','102.917100780199064','test','test','1.97'),('2019-09-25 15:59:59','2019-09-29 23:59:59','MCOBTC','4h','0.000340700000000','0.000346200000000','0.034202783159286','0.034754926708966','100.38973630550697','100.389736305506972','test','test','1.05'),('2019-10-01 07:59:59','2019-10-02 03:59:59','MCOBTC','4h','0.000350700000000','0.000347000000000','0.034325481725882','0.033963336637813','97.87705082943192','97.877050829431923','test','test','1.45'),('2019-10-04 03:59:59','2019-10-15 19:59:59','MCOBTC','4h','0.000350400000000','0.000423100000000','0.034245005039644','0.041350061735940','97.73117876610793','97.731178766107931','test','test','0.31'),('2019-10-16 03:59:59','2019-10-18 03:59:59','MCOBTC','4h','0.000440600000000','0.000430600000000','0.035823906527710','0.035010835567027','81.30709606833862','81.307096068338623','test','test','2.26'),('2019-10-21 23:59:59','2019-10-26 03:59:59','MCOBTC','4h','0.000438000000000','0.000434400000000','0.035643224092003','0.035350266085767','81.37722395434398','81.377223954343975','test','test','0.82'),('2019-10-29 19:59:59','2019-11-03 03:59:59','MCOBTC','4h','0.000469700000000','0.000458800000000','0.035578122312839','0.034752485665596','75.74648139842265','75.746481398422645','test','test','4.30'),('2019-11-04 03:59:59','2019-11-04 19:59:59','MCOBTC','4h','0.000463300000000','0.000456200000000','0.035394647502341','0.034852230068137','76.39682171884452','76.396821718844521','test','test','1.53'),('2019-11-05 19:59:59','2019-11-14 11:59:59','MCOBTC','4h','0.000462500000000','0.000486600000000','0.035274110294740','0.037112177447396','76.26834658322115','76.268346583221145','test','test','0.0'),('2019-11-15 15:59:59','2019-11-18 15:59:59','MCOBTC','4h','0.000498400000000','0.000500900000000','0.035682569661997','0.035861555264234','71.59424089485687','71.594240894856867','test','test','0.12'),('2019-11-19 03:59:59','2019-11-22 23:59:59','MCOBTC','4h','0.000521900000000','0.000527300000000','0.035722344240272','0.036091956539367','68.44672205455367','68.446722054553675','test','test','1.82'),('2019-11-23 07:59:59','2019-11-25 11:59:59','MCOBTC','4h','0.000534100000000','0.000536600000000','0.035804480306737','0.035972072893831','67.0370348375531','67.037034837553094','test','test','0.0'),('2019-11-28 11:59:59','2019-11-29 19:59:59','MCOBTC','4h','0.000544000000000','0.000536700000000','0.035841723103869','0.035360758804865','65.8855204115241','65.885520411524098','test','test','1.34'),('2019-12-02 11:59:59','2019-12-03 03:59:59','MCOBTC','4h','0.000540400000000','0.000532900000000','0.035734842148535','0.035238892266755','66.12665090402459','66.126650904024586','test','test','1.38'),('2019-12-04 03:59:59','2019-12-15 19:59:59','MCOBTC','4h','0.000541000000000','0.000594000000000','0.035624631063695','0.039114659615221','65.8495953118205','65.849595311820494','test','test','0.51'),('2020-01-01 11:59:59','2020-01-01 15:59:59','MCOBTC','4h','0.000555700000000','0.000556200000000','0.036400192964034','0.036432944622270','65.50331647297821','65.503316472978213','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-01  6:56:29
