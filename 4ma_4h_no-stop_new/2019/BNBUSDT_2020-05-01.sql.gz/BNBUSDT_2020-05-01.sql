-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-03 11:59:59','BNBUSDT','4h','5.854000000000000','5.830000000000000','222.222222222222200','221.311164256159117','37.96074858596211','37.960748585962108','test','test','0.40'),('2019-01-04 19:59:59','2019-01-10 07:59:59','BNBUSDT','4h','5.957600000000000','6.059900000000000','222.019764896430416','225.832142690996164','37.26664510816946','37.266645108169463','test','test','0.11'),('2019-01-17 15:59:59','2019-01-22 11:59:59','BNBUSDT','4h','6.132900000000000','6.436200000000000','222.866959961889478','233.888752092274927','36.33957181135995','36.339571811359953','test','test','0.0'),('2019-01-22 15:59:59','2019-01-24 15:59:59','BNBUSDT','4h','6.481700000000000','6.424400000000000','225.316247101975137','223.324389879495982','34.76190615146877','34.761906151468771','test','test','1.03'),('2019-01-25 03:59:59','2019-01-28 07:59:59','BNBUSDT','4h','6.493200000000000','6.739800000000000','224.873612163646413','233.413905510463877','34.63217091166858','34.632170911668581','test','test','0.0'),('2019-01-28 11:59:59','2019-01-28 15:59:59','BNBUSDT','4h','6.799100000000000','6.158900000000000','226.771455129605897','205.418763512483963','33.35315778994365','33.353157789943651','test','test','9.41'),('2019-02-02 11:59:59','2019-02-13 07:59:59','BNBUSDT','4h','6.728300000000000','9.035700000000000','222.026412548023217','298.168044804805618','32.99888717031393','32.998887170313928','test','test','1.31'),('2019-02-15 23:59:59','2019-02-17 07:59:59','BNBUSDT','4h','9.291100000000000','8.920299999999999','238.946775271752671','229.410610095318646','25.71781331292879','25.717813312928790','test','test','3.99'),('2019-02-17 23:59:59','2019-02-24 15:59:59','BNBUSDT','4h','9.220000000000001','9.786300000000001','236.827627454767338','251.373775548870924','25.686293650191683','25.686293650191683','test','test','0.0'),('2019-02-28 23:59:59','2019-03-10 11:59:59','BNBUSDT','4h','10.277900000000001','14.194800000000001','240.060104809012529','331.546831136999856','23.356921628835902','23.356921628835902','test','test','0.0'),('2019-03-12 11:59:59','2019-03-18 19:59:59','BNBUSDT','4h','15.154299999999999','15.415500000000000','260.390488437454167','264.878587233166513','17.182614072405467','17.182614072405467','test','test','3.26'),('2019-03-19 07:59:59','2019-03-19 15:59:59','BNBUSDT','4h','15.686700000000000','15.414999999999999','261.387843725390269','256.860500361891980','16.663023052993317','16.663023052993317','test','test','1.73'),('2019-03-24 11:59:59','2019-03-26 15:59:59','BNBUSDT','4h','17.040199999999999','15.904299999999999','260.381767422390624','243.024714710855932','15.28044080599938','15.280440805999380','test','test','6.66'),('2019-03-26 19:59:59','2019-03-26 23:59:59','BNBUSDT','4h','16.150400000000001','16.199800000000000','256.524644597605118','257.309288782462545','15.883485523430076','15.883485523430076','test','test','0.0'),('2019-03-27 03:59:59','2019-03-29 23:59:59','BNBUSDT','4h','16.375200000000000','16.475300000000001','256.699009972017905','258.268185975865094','15.67608395451768','15.676083954517679','test','test','0.0'),('2019-03-30 23:59:59','2019-04-07 15:59:59','BNBUSDT','4h','16.966600000000000','18.961500000000001','257.047715750650582','287.270888817203286','15.150219593239104','15.150219593239104','test','test','0.0'),('2019-04-14 07:59:59','2019-04-23 19:59:59','BNBUSDT','4h','19.053100000000001','23.119000000000000','263.763976432106745','320.050772374777637','13.843625259517177','13.843625259517177','test','test','1.50'),('2019-04-26 11:59:59','2019-04-26 19:59:59','BNBUSDT','4h','23.480000000000000','22.763000000000002','276.272153308255838','267.835733635256702','11.766275694559448','11.766275694559448','test','test','4.01'),('2019-05-02 23:59:59','2019-05-04 11:59:59','BNBUSDT','4h','23.616599999999998','23.076200000000000','274.397393380922665','268.118574610098335','11.618835623287124','11.618835623287124','test','test','2.28'),('2019-05-04 19:59:59','2019-05-05 03:59:59','BNBUSDT','4h','22.831000000000000','22.966400000000000','273.002100320739544','274.621148298639298','11.957518300588653','11.957518300588653','test','test','0.0'),('2019-05-13 19:59:59','2019-05-17 03:59:59','BNBUSDT','4h','23.680000000000000','24.115600000000001','273.361888760272791','278.390454585609575','11.543998680754763','11.543998680754763','test','test','3.50'),('2019-05-17 07:59:59','2019-05-17 15:59:59','BNBUSDT','4h','24.800000000000001','24.301600000000001','274.479347832569886','268.963198358386308','11.067715638410077','11.067715638410077','test','test','2.00'),('2019-05-17 23:59:59','2019-05-26 19:59:59','BNBUSDT','4h','25.779499999999999','32.845900000000000','273.253536838306843','348.154865130717894','10.599644556267842','10.599644556267842','test','test','0.0'),('2019-05-27 03:59:59','2019-05-28 15:59:59','BNBUSDT','4h','34.226900000000001','33.000900000000001','289.898276458842645','279.514184211559382','8.469895797131572','8.469895797131572','test','test','3.58'),('2019-05-30 03:59:59','2019-05-30 19:59:59','BNBUSDT','4h','34.572299999999998','32.482100000000003','287.590700403890821','270.203309863365291','8.318529585937032','8.318529585937032','test','test','6.04'),('2019-06-02 11:59:59','2019-06-03 03:59:59','BNBUSDT','4h','33.416899999999998','32.081499999999998','283.726835839329567','272.388596308438309','8.490519343186518','8.490519343186518','test','test','3.99'),('2019-06-12 03:59:59','2019-06-14 11:59:59','BNBUSDT','4h','33.332200000000000','31.729299999999999','281.207227054687053','267.684355349670341','8.436503652764806','8.436503652764806','test','test','4.80'),('2019-06-17 15:59:59','2019-06-24 03:59:59','BNBUSDT','4h','33.849800000000002','36.632199999999997','278.202144453572259','301.069920532828803','8.218723432740289','8.218723432740289','test','test','0.06'),('2019-07-21 19:59:59','2019-07-21 23:59:59','BNBUSDT','4h','29.721599999999999','30.438800000000001','283.283872471184793','290.119681893838163','9.531245709221064','9.531245709221064','test','test','0.0'),('2019-07-22 03:59:59','2019-07-22 15:59:59','BNBUSDT','4h','30.953099999999999','29.940700000000000','284.802941231774469','275.487735397688425','9.201112044731367','9.201112044731367','test','test','3.27'),('2019-07-22 19:59:59','2019-07-23 07:59:59','BNBUSDT','4h','30.199999999999999','29.858599999999999','282.732895490866497','279.536703089522746','9.362016406982335','9.362016406982335','test','test','1.13'),('2019-08-07 19:59:59','2019-08-10 07:59:59','BNBUSDT','4h','29.969899999999999','29.295999999999999','282.022630512790045','275.681099486574794','9.410195913659708','9.410195913659708','test','test','2.24'),('2019-08-11 15:59:59','2019-08-13 15:59:59','BNBUSDT','4h','29.868300000000001','29.267199999999999','280.613401395853373','274.966052347563107','9.395024202778643','9.395024202778643','test','test','2.01'),('2019-09-18 23:59:59','2019-09-19 03:59:59','BNBUSDT','4h','22.201799999999999','20.731100000000001','279.358434940677682','260.853068246659461','12.582693067259308','12.582693067259308','test','test','6.62'),('2019-09-20 11:59:59','2019-09-20 19:59:59','BNBUSDT','4h','21.431100000000001','21.045300000000001','275.246131230895912','270.291184567921107','12.843303947575995','12.843303947575995','test','test','1.80'),('2019-09-21 03:59:59','2019-09-21 07:59:59','BNBUSDT','4h','21.360499999999998','21.239999999999998','274.145031972457048','272.598510292127457','12.834204816013534','12.834204816013534','test','test','0.56'),('2019-10-09 11:59:59','2019-10-11 19:59:59','BNBUSDT','4h','17.687000000000001','16.725700000000000','273.801360487939348','258.920077747109588','15.480373183012345','15.480373183012345','test','test','5.43'),('2019-10-12 15:59:59','2019-10-16 15:59:59','BNBUSDT','4h','17.298600000000000','17.608799999999999','270.494408767754976','275.344938036005374','15.636780361864831','15.636780361864831','test','test','0.74'),('2019-10-17 15:59:59','2019-10-18 11:59:59','BNBUSDT','4h','18.656099999999999','18.149999999999999','271.572304160699503','264.205129717180739','14.556756458246875','14.556756458246875','test','test','3.72'),('2019-10-18 19:59:59','2019-10-19 03:59:59','BNBUSDT','4h','18.274600000000000','18.136399999999998','269.935154284362000','267.893794236968404','14.77105678287689','14.771056782876890','test','test','0.75'),('2019-10-20 19:59:59','2019-10-21 15:59:59','BNBUSDT','4h','18.433000000000000','17.996099999999998','269.481518718274572','263.094252645035567','14.61951493073697','14.619514930736971','test','test','2.37'),('2019-10-21 23:59:59','2019-10-23 03:59:59','BNBUSDT','4h','18.255099999999999','17.800100000000000','268.062126257554780','261.380800630897738','14.684232146499049','14.684232146499049','test','test','2.49'),('2019-10-26 03:59:59','2019-10-30 19:59:59','BNBUSDT','4h','19.294499999999999','19.777999999999999','266.577387229408771','273.257537879874860','13.816237126093384','13.816237126093384','test','test','5.69'),('2019-11-02 03:59:59','2019-11-07 11:59:59','BNBUSDT','4h','20.074600000000000','20.150900000000000','268.061865151734594','269.080720835587670','13.353285502661802','13.353285502661802','test','test','0.73'),('2019-11-11 03:59:59','2019-11-11 07:59:59','BNBUSDT','4h','20.442100000000000','20.082100000000001','268.288277525924116','263.563529094533408','13.124301198307617','13.124301198307617','test','test','1.76'),('2019-11-11 15:59:59','2019-11-11 19:59:59','BNBUSDT','4h','20.074800000000000','20.156099999999999','267.238333430059527','268.320609542791090','13.312129307891462','13.312129307891462','test','test','0.0'),('2019-11-12 03:59:59','2019-11-12 15:59:59','BNBUSDT','4h','20.250000000000000','20.219999999999999','267.478839232888788','267.082574285877115','13.208831567056237','13.208831567056237','test','test','0.14'),('2019-11-12 19:59:59','2019-11-15 15:59:59','BNBUSDT','4h','20.638600000000000','20.140300000000000','267.390780355775064','260.934876086527993','12.955858457248798','12.955858457248798','test','test','2.41'),('2019-12-29 15:59:59','2019-12-31 19:59:59','BNBUSDT','4h','14.129500000000000','13.668100000000001','265.956134962609042','257.271315211609533','18.82275628738519','18.822756287385189','test','test','3.26');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-01  6:06:59
