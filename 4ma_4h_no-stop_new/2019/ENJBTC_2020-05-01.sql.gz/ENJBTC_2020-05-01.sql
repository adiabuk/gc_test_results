-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-22 23:59:59','2019-01-24 03:59:59','ENJBTC','4h','0.000009640000000','0.000009520000000','0.033333333333333','0.032918395573997','3457.8146611341635','3457.814661134163543','test','test','1.24'),('2019-01-24 07:59:59','2019-01-25 11:59:59','ENJBTC','4h','0.000009530000000','0.000009540000000','0.033241124942370','0.033276005451229','3488.050885873008','3488.050885873008156','test','test','0.0'),('2019-01-25 15:59:59','2019-01-25 19:59:59','ENJBTC','4h','0.000009620000000','0.000009570000000','0.033248876166561','0.033076064959874','3456.2241337381156','3456.224133738115597','test','test','0.51'),('2019-02-12 15:59:59','2019-02-16 19:59:59','ENJBTC','4h','0.000008440000000','0.000008490000000','0.033210473676186','0.033407218188486','3934.8902459935753','3934.890245993575263','test','test','0.94'),('2019-02-17 15:59:59','2019-02-24 03:59:59','ENJBTC','4h','0.000008660000000','0.000009500000000','0.033254194678919','0.036479774763248','3839.9762908682583','3839.976290868258275','test','test','0.0'),('2019-02-25 03:59:59','2019-03-02 03:59:59','ENJBTC','4h','0.000011100000000','0.000019990000000','0.033970990253214','0.061178386951509','3060.449572361662','3060.449572361661922','test','test','0.27'),('2019-03-02 19:59:59','2019-03-04 15:59:59','ENJBTC','4h','0.000022200000000','0.000020480000000','0.040017078408391','0.036916656117290','1802.5710994770773','1802.571099477077269','test','test','7.79'),('2019-03-05 03:59:59','2019-03-11 19:59:59','ENJBTC','4h','0.000021620000000','0.000044410000000','0.039328095677035','0.080784492553984','1819.0608546269814','1819.060854626981381','test','test','0.0'),('2019-03-18 11:59:59','2019-03-23 11:59:59','ENJBTC','4h','0.000050800000000','0.000046200000000','0.048540628316357','0.044145217090860','955.524179455853','955.524179455852959','test','test','11.0'),('2019-04-14 11:59:59','2019-04-15 03:59:59','ENJBTC','4h','0.000033810000000','0.000030660000000','0.047563870266247','0.043132453781814','1406.7988839469651','1406.798883946965134','test','test','9.31'),('2019-04-15 07:59:59','2019-04-15 15:59:59','ENJBTC','4h','0.000031700000000','0.000030060000000','0.046579111047484','0.044169340002756','1469.3725882487065','1469.372588248706506','test','test','5.17'),('2019-04-17 15:59:59','2019-04-21 23:59:59','ENJBTC','4h','0.000034280000000','0.000035290000000','0.046043606370878','0.047400200374221','1343.1623795471933','1343.162379547193268','test','test','6.70'),('2019-05-22 07:59:59','2019-05-22 23:59:59','ENJBTC','4h','0.000022940000000','0.000020230000000','0.046345071704954','0.040870130801710','2020.2733960311245','2020.273396031124548','test','test','11.8'),('2019-05-23 03:59:59','2019-05-23 07:59:59','ENJBTC','4h','0.000020610000000','0.000020920000000','0.045128418170900','0.045807205634897','2189.636980635603','2189.636980635602868','test','test','0.0'),('2019-05-23 15:59:59','2019-05-24 15:59:59','ENJBTC','4h','0.000021350000000','0.000020200000000','0.045279259829566','0.042840330143196','2120.808422930481','2120.808422930480901','test','test','5.38'),('2019-05-26 03:59:59','2019-05-26 11:59:59','ENJBTC','4h','0.000021160000000','0.000020660000000','0.044737275454817','0.043680156469590','2114.2379704544846','2114.237970454484639','test','test','2.36'),('2019-06-07 11:59:59','2019-06-07 19:59:59','ENJBTC','4h','0.000019580000000','0.000019000000000','0.044502360124766','0.043184108394819','2272.847810253649','2272.847810253649186','test','test','2.96'),('2019-06-07 23:59:59','2019-06-09 19:59:59','ENJBTC','4h','0.000019070000000','0.000018990000000','0.044209415295889','0.044023953669058','2318.270335390107','2318.270335390106993','test','test','0.41'),('2019-06-10 07:59:59','2019-06-10 11:59:59','ENJBTC','4h','0.000019390000000','0.000018980000000','0.044168201601038','0.043234268508907','2277.885590564105','2277.885590564104859','test','test','2.11'),('2019-06-11 07:59:59','2019-06-11 11:59:59','ENJBTC','4h','0.000019850000000','0.000019310000000','0.043960660913898','0.042764753765611','2214.64286719888','2214.642867198880140','test','test','2.72'),('2019-06-11 15:59:59','2019-06-12 15:59:59','ENJBTC','4h','0.000019600000000','0.000019290000000','0.043694903769834','0.043003810904087','2229.331824991531','2229.331824991530993','test','test','1.58'),('2019-06-12 19:59:59','2019-06-12 23:59:59','ENJBTC','4h','0.000019370000000','0.000019260000000','0.043541327577446','0.043294061390894','2247.8744232031895','2247.874423203189508','test','test','0.56'),('2019-07-26 15:59:59','2019-07-27 11:59:59','ENJBTC','4h','0.000009080000000','0.000008850000000','0.043486379535990','0.042384852301048','4789.248847575967','4789.248847575967375','test','test','2.53'),('2019-07-27 15:59:59','2019-07-27 19:59:59','ENJBTC','4h','0.000008900000000','0.000008880000000','0.043241595706003','0.043144423580821','4858.606259101423','4858.606259101423348','test','test','0.22'),('2019-07-30 11:59:59','2019-07-31 07:59:59','ENJBTC','4h','0.000008970000000','0.000008870000000','0.043220001900407','0.042738173562610','4818.283377971758','4818.283377971757545','test','test','1.11'),('2019-07-31 11:59:59','2019-07-31 15:59:59','ENJBTC','4h','0.000008940000000','0.000008560000000','0.043112928936452','0.041280388332889','4822.475272533755','4822.475272533754833','test','test','4.25'),('2019-08-22 03:59:59','2019-08-25 19:59:59','ENJBTC','4h','0.000006360000000','0.000006800000000','0.042705697691216','0.045660179921426','6714.732341386093','6714.732341386093140','test','test','0.0'),('2019-08-28 03:59:59','2019-08-28 15:59:59','ENJBTC','4h','0.000007100000000','0.000006710000000','0.043362249297929','0.040980379266071','6107.359056046323','6107.359056046322621','test','test','5.49'),('2019-08-31 11:59:59','2019-08-31 23:59:59','ENJBTC','4h','0.000007010000000','0.000007010000000','0.042832944846405','0.042832944846405','6110.263173524234','6110.263173524233935','test','test','1.28'),('2019-09-01 03:59:59','2019-09-03 11:59:59','ENJBTC','4h','0.000007360000000','0.000007220000000','0.042832944846405','0.042018187743348','5819.693593261533','5819.693593261533351','test','test','2.03'),('2019-09-04 11:59:59','2019-09-06 15:59:59','ENJBTC','4h','0.000007900000000','0.000007520000000','0.042651887712392','0.040600277923695','5398.973128150914','5398.973128150913908','test','test','4.81'),('2019-09-08 15:59:59','2019-09-09 11:59:59','ENJBTC','4h','0.000007930000000','0.000007630000000','0.042195974426015','0.040599657612925','5321.056043633683','5321.056043633682748','test','test','3.78'),('2019-09-29 23:59:59','2019-09-30 19:59:59','ENJBTC','4h','0.000006880000000','0.000006860000000','0.041841237356440','0.041719605852497','6081.575197156912','6081.575197156911599','test','test','0.29'),('2019-09-30 23:59:59','2019-10-01 19:59:59','ENJBTC','4h','0.000006900000000','0.000006850000000','0.041814208133341','0.041511206625128','6060.0301642523345','6060.030164252334544','test','test','0.72'),('2019-10-01 23:59:59','2019-10-02 07:59:59','ENJBTC','4h','0.000006970000000','0.000006980000000','0.041746874464849','0.041806769550164','5989.508531542228','5989.508531542228411','test','test','1.00'),('2019-10-02 23:59:59','2019-10-07 03:59:59','ENJBTC','4h','0.000006940000000','0.000007620000000','0.041760184483808','0.045851960485103','6017.317648963721','6017.317648963720785','test','test','0.0'),('2019-10-08 19:59:59','2019-10-09 15:59:59','ENJBTC','4h','0.000008050000000','0.000007490000000','0.042669468039652','0.039701157219502','5300.55503598156','5300.555035981559740','test','test','6.95'),('2019-10-14 03:59:59','2019-10-14 15:59:59','ENJBTC','4h','0.000007730000000','0.000007580000000','0.042009843412952','0.041194645934046','5434.649859372775','5434.649859372774699','test','test','1.94'),('2019-10-14 19:59:59','2019-10-14 23:59:59','ENJBTC','4h','0.000007610000000','0.000007570000000','0.041828688417639','0.041608826717678','5496.542499032735','5496.542499032734668','test','test','0.52'),('2019-10-15 03:59:59','2019-10-15 07:59:59','ENJBTC','4h','0.000007620000000','0.000007580000000','0.041779830262092','0.041560513567803','5482.917357229951','5482.917357229951449','test','test','0.52'),('2019-10-23 19:59:59','2019-10-25 15:59:59','ENJBTC','4h','0.000007680000000','0.000007180000000','0.041731093218917','0.039014225170810','5433.736096213137','5433.736096213136989','test','test','6.51'),('2019-11-02 19:59:59','2019-11-03 07:59:59','ENJBTC','4h','0.000007080000000','0.000007060000000','0.041127344763782','0.041011165823771','5808.947000534181','5808.947000534180916','test','test','0.28'),('2019-11-03 11:59:59','2019-11-03 15:59:59','ENJBTC','4h','0.000007090000000','0.000007100000000','0.041101527221557','0.041159498345988','5797.112443096944','5797.112443096943935','test','test','0.0'),('2019-11-03 23:59:59','2019-11-04 23:59:59','ENJBTC','4h','0.000007200000000','0.000007140000000','0.041114409693653','0.040771789612873','5710.334679674043','5710.334679674043400','test','test','1.11'),('2019-11-05 07:59:59','2019-11-05 11:59:59','ENJBTC','4h','0.000007130000000','0.000007130000000','0.041038271897924','0.041038271897924','5755.718358755149','5755.718358755148984','test','test','0.0'),('2019-11-05 19:59:59','2019-11-07 03:59:59','ENJBTC','4h','0.000007210000000','0.000007180000000','0.041038271897924','0.040867516258959','5691.85463216702','5691.854632167020100','test','test','0.83'),('2019-11-10 15:59:59','2019-11-10 19:59:59','ENJBTC','4h','0.000007170000000','0.000007030000000','0.041000326200376','0.040199761950996','5718.316066998108','5718.316066998107999','test','test','1.95'),('2019-11-14 07:59:59','2019-11-14 11:59:59','ENJBTC','4h','0.000007230000000','0.000007100000000','0.040822423033848','0.040088409894927','5646.254914778361','5646.254914778361126','test','test','1.79'),('2019-11-14 15:59:59','2019-11-18 15:59:59','ENJBTC','4h','0.000007270000000','0.000007600000000','0.040659309002976','0.042504917252079','5592.752270010485','5592.752270010484608','test','test','0.0'),('2019-11-18 23:59:59','2019-11-19 07:59:59','ENJBTC','4h','0.000007840000000','0.000007600000000','0.041069444169444','0.039812216286706','5238.449511408618','5238.449511408617582','test','test','3.06'),('2019-11-19 19:59:59','2019-11-22 07:59:59','ENJBTC','4h','0.000007950000000','0.000007960000000','0.040790060195502','0.040841368447320','5130.825181824123','5130.825181824123320','test','test','0.37'),('2019-11-23 19:59:59','2019-11-24 11:59:59','ENJBTC','4h','0.000008610000000','0.000007930000000','0.040801462029239','0.037579046909624','4738.845764139269','4738.845764139268795','test','test','7.89'),('2019-11-28 23:59:59','2019-11-29 15:59:59','ENJBTC','4h','0.000008050000000','0.000007810000000','0.040085369780436','0.038890278010584','4979.549041047922','4979.549041047922401','test','test','2.98'),('2019-11-29 19:59:59','2019-11-29 23:59:59','ENJBTC','4h','0.000007860000000','0.000007920000000','0.039819793831580','0.040123761723424','5066.131530735341','5066.131530735340675','test','test','0.0'),('2019-11-30 07:59:59','2019-11-30 15:59:59','ENJBTC','4h','0.000007950000000','0.000007800000000','0.039887342251990','0.039134750888745','5017.27575496724','5017.275754967239664','test','test','1.88'),('2019-11-30 23:59:59','2019-12-01 03:59:59','ENJBTC','4h','0.000007990000000','0.000007910000000','0.039720099726824','0.039322401606906','4971.226498976721','4971.226498976720904','test','test','1.00'),('2019-12-01 07:59:59','2019-12-03 11:59:59','ENJBTC','4h','0.000007990000000','0.000008050000000','0.039631722366842','0.039929332297006','4960.165502733696','4960.165502733695575','test','test','0.87'),('2019-12-03 15:59:59','2019-12-04 15:59:59','ENJBTC','4h','0.000008170000000','0.000008400000000','0.039697857906879','0.040815423062152','4858.978935970461','4858.978935970460952','test','test','0.0'),('2019-12-04 19:59:59','2019-12-08 03:59:59','ENJBTC','4h','0.000011600000000','0.000011450000000','0.039946205719162','0.039429659955552','3443.638424065651','3443.638424065651179','test','test','10.2'),('2019-12-08 15:59:59','2019-12-08 23:59:59','ENJBTC','4h','0.000012840000000','0.000012060000000','0.039831417771693','0.037411752206123','3102.135340474507','3102.135340474506847','test','test','7.78'),('2019-12-12 11:59:59','2019-12-14 07:59:59','ENJBTC','4h','0.000012120000000','0.000011170000000','0.039293714312677','0.036213761458135','3242.0556363594974','3242.055636359497385','test','test','7.83'),('2019-12-16 07:59:59','2019-12-17 23:59:59','ENJBTC','4h','0.000011890000000','0.000011480000000','0.038609280345001','0.037277925850346','3247.206084524904','3247.206084524903872','test','test','3.44'),('2019-12-18 03:59:59','2019-12-18 07:59:59','ENJBTC','4h','0.000011790000000','0.000011400000000','0.038313423790633','0.037046058627075','3249.654265532937','3249.654265532937188','test','test','3.30'),('2019-12-18 11:59:59','2019-12-18 15:59:59','ENJBTC','4h','0.000011590000000','0.000011330000000','0.038031787087620','0.037178614987294','3281.4311551009864','3281.431155100986416','test','test','2.24'),('2019-12-29 23:59:59','2020-01-01 03:59:59','ENJBTC','4h','0.000011090000000','0.000011130000000','0.037842193287548','0.037978684516719','3412.2807292649227','3412.280729264922684','test','test','1.26');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-01  9:44:13
