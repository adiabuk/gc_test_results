-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 07:59:59','2019-01-14 19:59:59','XRPETH','4h','0.002592680000000','0.002596400000000','1.297777777777778','1.299639840713942','500.55455273222213','500.554552732222135','test','test','0.0'),('2019-01-16 23:59:59','2019-01-19 11:59:59','XRPETH','4h','0.002680390000000','0.002648540000000','1.298191569541370','1.282765679469443','484.32935861623486','484.329358616234856','test','test','3.13'),('2019-01-20 19:59:59','2019-01-23 03:59:59','XRPETH','4h','0.002686180000000','0.002687950000000','1.294763593969831','1.295616750333636','482.0092450877568','482.009245087756824','test','test','1.40'),('2019-01-24 03:59:59','2019-01-25 15:59:59','XRPETH','4h','0.002720640000000','0.002712620000000','1.294953184272898','1.291135874912649','475.9737356919322','475.973735691932177','test','test','1.20'),('2019-01-25 19:59:59','2019-01-26 11:59:59','XRPETH','4h','0.002720240000000','0.002703780000000','1.294104893303954','1.286274346534631','475.7318814898516','475.731881489851617','test','test','0.48'),('2019-01-27 23:59:59','2019-02-02 15:59:59','XRPETH','4h','0.002735430000000','0.002856100000000','1.292364771799660','1.349375792740816','472.4539731594886','472.453973159488612','test','test','1.15'),('2019-02-27 15:59:59','2019-02-28 03:59:59','XRPETH','4h','0.002289240000000','0.002287290000000','1.305033887564361','1.303922245237322','570.0729882250708','570.072988225070844','test','test','0.0'),('2019-02-28 07:59:59','2019-02-28 11:59:59','XRPETH','4h','0.002288530000000','0.002274310000000','1.304786855936130','1.296679438034065','570.1419059117121','570.141905911712115','test','test','0.05'),('2019-02-28 23:59:59','2019-03-05 15:59:59','XRPETH','4h','0.002317970000000','0.002341950000000','1.302985207513449','1.316464926955967','562.1234129490241','562.123412949024100','test','test','1.88'),('2019-03-11 19:59:59','2019-03-12 11:59:59','XRPETH','4h','0.002355840000000','0.002319890000000','1.305980700722898','1.286051500865952','554.3588277314662','554.358827731466249','test','test','0.71'),('2019-03-12 15:59:59','2019-03-14 15:59:59','XRPETH','4h','0.002324780000000','0.002354590000000','1.301551989643577','1.318241424691743','559.8602834003977','559.860283400397748','test','test','0.21'),('2019-03-14 23:59:59','2019-03-15 03:59:59','XRPETH','4h','0.002353960000000','0.002335890000000','1.305260752987613','1.295241015266290','554.4957233715159','554.495723371515851','test','test','0.51'),('2019-04-30 19:59:59','2019-05-01 03:59:59','XRPETH','4h','0.001953710000000','0.001894390000000','1.303034144605097','1.263470450168372','666.9537160607753','666.953716060775264','test','test','0.0'),('2019-05-14 19:59:59','2019-05-16 03:59:59','XRPETH','4h','0.001951440000000','0.001728240000000','1.294242212508047','1.146210573394471','663.2241895769519','663.224189576951858','test','test','8.39'),('2019-05-29 11:59:59','2019-05-30 03:59:59','XRPETH','4h','0.001634130000000','0.001601300000000','1.261346292705030','1.236005592277582','771.8763456426541','771.876345642654087','test','test','0.0'),('2019-05-30 07:59:59','2019-06-01 03:59:59','XRPETH','4h','0.001638090000000','0.001618740000000','1.255715025943375','1.240881844767735','766.5726705757163','766.572670575716302','test','test','2.24'),('2019-06-02 19:59:59','2019-06-04 19:59:59','XRPETH','4h','0.001639990000000','0.001650030000000','1.252418763459900','1.260086056787992','763.674634272099','763.674634272098956','test','test','1.29'),('2019-06-04 23:59:59','2019-06-05 03:59:59','XRPETH','4h','0.001652930000000','0.001646550000000','1.254122606421698','1.249281928214532','758.7269917187647','758.726991718764680','test','test','0.17'),('2019-06-06 19:59:59','2019-06-09 15:59:59','XRPETH','4h','0.001717190000000','0.001672950000000','1.253046900153439','1.220764628032830','729.7077784947726','729.707778494772583','test','test','4.11'),('2019-06-18 23:59:59','2019-06-20 11:59:59','XRPETH','4h','0.001613730000000','0.001583120000000','1.245873061904414','1.222240747685248','772.0455478329177','772.045547832917691','test','test','0.0'),('2019-07-15 15:59:59','2019-07-19 07:59:59','XRPETH','4h','0.001387980000000','0.001424320000000','1.240621436522378','1.273103304419050','893.8323581913122','893.832358191312210','test','test','0.0'),('2019-07-20 03:59:59','2019-07-23 23:59:59','XRPETH','4h','0.001447770000000','0.001453180000000','1.247839629388305','1.252502533299141','861.9046045907187','861.904604590718691','test','test','5.01'),('2019-07-24 03:59:59','2019-07-25 03:59:59','XRPETH','4h','0.001497570000000','0.001435720000000','1.248875830257379','1.197296959085134','833.9348613135809','833.934861313580882','test','test','2.96'),('2019-07-26 23:59:59','2019-07-27 11:59:59','XRPETH','4h','0.001478000000000','0.001490000000000','1.237413858885769','1.247460520798238','837.2218260390862','837.221826039086181','test','test','2.86'),('2019-07-27 15:59:59','2019-07-29 11:59:59','XRPETH','4h','0.001495020000000','0.001474900000000','1.239646450421873','1.222963271211904','829.1838573543321','829.183857354332076','test','test','1.94'),('2019-07-30 03:59:59','2019-07-31 15:59:59','XRPETH','4h','0.001488100000000','0.001474270000000','1.235939077264103','1.224452592862139','830.5484021665901','830.548402166590108','test','test','0.88'),('2019-08-13 15:59:59','2019-08-13 19:59:59','XRPETH','4h','0.001433330000000','0.001415350000000','1.233386525174777','1.217914659154640','860.504228038747','860.504228038746987','test','test','0.0'),('2019-08-13 23:59:59','2019-08-14 03:59:59','XRPETH','4h','0.001423380000000','0.001423980000000','1.229948332725858','1.230466795117936','864.1039867961177','864.103986796117738','test','test','0.56'),('2019-08-15 11:59:59','2019-08-15 15:59:59','XRPETH','4h','0.001435060000000','0.001420810000000','1.230063546590764','1.217849140545777','857.1513014025646','857.151301402564627','test','test','0.77'),('2019-08-15 19:59:59','2019-08-15 23:59:59','XRPETH','4h','0.001421640000000','0.001403940000000','1.227349234136323','1.212068233711312','863.333357345265','863.333357345264972','test','test','0.05'),('2019-08-17 07:59:59','2019-08-19 11:59:59','XRPETH','4h','0.001436850000000','0.001426240000000','1.223953456264098','1.214915528734459','851.8310584014323','851.831058401432301','test','test','2.29'),('2019-08-23 23:59:59','2019-08-24 07:59:59','XRPETH','4h','0.001427690000000','0.001419470000000','1.221945027924178','1.214909615383965','855.8896034322426','855.889603432242552','test','test','0.10'),('2019-08-24 15:59:59','2019-08-24 23:59:59','XRPETH','4h','0.001426760000000','0.001424150000000','1.220381602915242','1.218149134957345','855.3517080064216','855.351708006421632','test','test','0.51'),('2019-08-25 03:59:59','2019-08-26 07:59:59','XRPETH','4h','0.001429650000000','0.001429220000000','1.219885498924598','1.219518590405354','853.275626149476','853.275626149476011','test','test','0.38'),('2019-08-26 15:59:59','2019-08-26 19:59:59','XRPETH','4h','0.001435120000000','0.001434360000000','1.219803963698100','1.219157989136802','849.9665280242067','849.966528024206696','test','test','0.61'),('2019-08-27 03:59:59','2019-08-27 15:59:59','XRPETH','4h','0.001436650000000','0.001427240000000','1.219660413795589','1.211671686900509','848.9614128671485','848.961412867148510','test','test','0.15'),('2019-08-27 19:59:59','2019-08-28 07:59:59','XRPETH','4h','0.001432000000000','0.001428880000000','1.217885141152238','1.215231648386599','850.4784505253059','850.478450525305902','test','test','0.33'),('2019-08-28 19:59:59','2019-09-01 11:59:59','XRPETH','4h','0.001481320000000','0.001498120000000','1.217295476093207','1.231101111606375','821.7640186409466','821.764018640946574','test','test','3.54'),('2019-09-07 15:59:59','2019-09-07 19:59:59','XRPETH','4h','0.001487280000000','0.001465280000000','1.220363395096133','1.202311653196750','820.5337226992451','820.533722699245118','test','test','0.87'),('2019-09-18 23:59:59','2019-09-19 03:59:59','XRPETH','4h','0.001490860000000','0.001424280000000','1.216351896896270','1.162031095952282','815.8726486030012','815.872648603001153','test','test','1.71'),('2019-09-19 07:59:59','2019-09-19 11:59:59','XRPETH','4h','0.001427630000000','0.001388640000000','1.204280607797606','1.171390502589654','843.5523264414493','843.552326441449281','test','test','0.23'),('2019-09-25 15:59:59','2019-09-27 23:59:59','XRPETH','4h','0.001485520000000','0.001392240000000','1.196971695529172','1.121810459222047','805.7593943731301','805.759394373130135','test','test','6.52'),('2019-09-30 07:59:59','2019-10-01 03:59:59','XRPETH','4h','0.001429190000000','0.001410980000000','1.180269198572034','1.165230818716314','825.8308542405374','825.830854240537406','test','test','2.58'),('2019-10-01 07:59:59','2019-10-01 15:59:59','XRPETH','4h','0.001418030000000','0.001413530000000','1.176927336381874','1.173192455586885','829.9735099975837','829.973509997583733','test','test','0.49'),('2019-10-04 03:59:59','2019-10-05 23:59:59','XRPETH','4h','0.001432790000000','0.001436540000000','1.176097362871876','1.179175528625943','820.8442010845106','820.844201084510587','test','test','1.34'),('2019-10-06 03:59:59','2019-10-09 15:59:59','XRPETH','4h','0.001443320000000','0.001472330000000','1.176781399706113','1.200434109018999','815.3295178519753','815.329517851975311','test','test','0.46'),('2019-10-12 19:59:59','2019-10-20 23:59:59','XRPETH','4h','0.001506660000000','0.001676280000000','1.182037557331199','1.315111515937997','784.5416731918276','784.541673191827613','test','test','2.27'),('2019-10-22 03:59:59','2019-10-23 19:59:59','XRPETH','4h','0.001705560000000','0.001662010000000','1.211609548132710','1.180672145859451','710.3881119003198','710.388111900319814','test','test','12.6'),('2019-10-24 19:59:59','2019-10-25 15:59:59','XRPETH','4h','0.001723630000000','0.001655970000000','1.204734569849763','1.157443480117027','698.9519617607972','698.951961760797190','test','test','8.15'),('2019-11-22 07:59:59','2019-11-25 03:59:59','XRPETH','4h','0.001527420000000','0.001529670000000','1.194225438798044','1.195984619139597','781.8579295793194','781.857929579319375','test','test','0.0'),('2019-11-25 07:59:59','2019-11-25 11:59:59','XRPETH','4h','0.001551880000000','0.001517620000000','1.194616367762834','1.168243480194495','769.7865606637328','769.786560663732757','test','test','1.72'),('2019-12-06 15:59:59','2019-12-09 23:59:59','XRPETH','4h','0.001517840000000','0.001523420000000','1.188755726080980','1.193125921194781','783.1890884948219','783.189088494821931','test','test','0.20'),('2019-12-11 11:59:59','2019-12-12 19:59:59','XRPETH','4h','0.001527890000000','0.001516710000000','1.189726880550714','1.181021315016181','778.6731247345779','778.673124734577868','test','test','0.67'),('2019-12-15 03:59:59','2019-12-15 15:59:59','XRPETH','4h','0.001531890000000','0.001518320000000','1.187792310431929','1.177270444206181','775.377024741939','775.377024741938953','test','test','0.99'),('2019-12-15 19:59:59','2019-12-16 03:59:59','XRPETH','4h','0.001526590000000','0.001507610000000','1.185454117937318','1.170715439471947','776.5373269426094','776.537326942609411','test','test','0.54'),('2019-12-16 19:59:59','2019-12-17 03:59:59','XRPETH','4h','0.001570440000000','0.001506220000000','1.182178856056125','1.133836018293508','752.7691959298826','752.769195929882585','test','test','4.00'),('2019-12-26 03:59:59','2019-12-26 11:59:59','XRPETH','4h','0.001509120000000','0.001500050000000','1.171436003219988','1.164395526286937','776.237809597638','776.237809597638034','test','test','0.23'),('2019-12-27 07:59:59','2019-12-27 15:59:59','XRPETH','4h','0.001510620000000','0.001498200000000','1.169871452790421','1.160253015695945','774.4313280576325','774.431328057632527','test','test','0.69'),('2019-12-27 19:59:59','2019-12-27 23:59:59','XRPETH','4h','0.001510560000000','0.001503450000000','1.167734022324981','1.162237657467756','773.0470966561948','773.047096656194753','test','test','0.81'),('2019-12-28 03:59:59','2019-12-28 07:59:59','XRPETH','4h','0.001506700000000','0.001507570000000','1.166512607912265','1.167186176617969','774.2169031076292','774.216903107629150','test','test','0.21'),('2019-12-28 11:59:59','2019-12-28 19:59:59','XRPETH','4h','0.001514190000000','0.001504540000000','1.166662289846866','1.159227099350943','770.4860617537205','770.486061753720492','test','test','0.52'),('2019-12-28 23:59:59','2019-12-29 03:59:59','XRPETH','4h','0.001507820000000','0.001498490000000','1.165010025292216','1.157801244710995','772.6452927353505','772.645292735350495','test','test','0.21');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 10:12:58
