-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 19:59:59','2019-01-08 03:59:59','ONTUSDT','4h','0.644900000000000','0.607000000000000','222.222222222222200','209.162488585654927','344.5840009648351','344.584000964835127','test','test','5.87'),('2019-01-08 07:59:59','2019-01-08 11:59:59','ONTUSDT','4h','0.615700000000000','0.635500000000000','219.320059191873952','226.373067429650604','356.2125372614487','356.212537261448688','test','test','0.0'),('2019-01-08 15:59:59','2019-01-10 07:59:59','ONTUSDT','4h','0.643600000000000','0.638600000000000','220.887394355824313','219.171364256726861','343.2060198194909','343.206019819490905','test','test','1.98'),('2019-01-19 15:59:59','2019-01-20 11:59:59','ONTUSDT','4h','0.620600000000000','0.595000000000000','220.506054333802666','211.410090764764050','355.31107691556986','355.311076915569856','test','test','4.12'),('2019-01-25 23:59:59','2019-01-26 15:59:59','ONTUSDT','4h','0.612100000000000','0.604600000000000','218.484729096238539','215.807657591220135','356.9428673357924','356.942867335792414','test','test','1.22'),('2019-01-26 19:59:59','2019-01-27 11:59:59','ONTUSDT','4h','0.607200000000000','0.600200000000000','217.889824317345528','215.377919228048086','358.8435841853517','358.843584185351688','test','test','1.15'),('2019-02-09 11:59:59','2019-02-14 07:59:59','ONTUSDT','4h','0.571200000000000','0.570000000000000','217.331623186390544','216.875044146082985','380.48253358961927','380.482533589619266','test','test','1.52'),('2019-02-15 11:59:59','2019-02-26 15:59:59','ONTUSDT','4h','0.619900000000000','0.917400000000000','217.230161177433303','321.482416299689135','350.4277483101037','350.427748310103709','test','test','0.0'),('2019-03-06 11:59:59','2019-03-10 11:59:59','ONTUSDT','4h','0.910600000000000','0.953700000000000','240.397328982379037','251.775678289583652','263.9988238330541','263.998823833054075','test','test','1.75'),('2019-03-13 03:59:59','2019-03-13 11:59:59','ONTUSDT','4h','0.980500000000000','0.953400000000000','242.925851050646742','236.211633239863943','247.75711478903287','247.757114789032869','test','test','2.76'),('2019-03-13 15:59:59','2019-03-24 03:59:59','ONTUSDT','4h','1.026900000000000','1.227700000000000','241.433802648250548','288.643762305246128','235.10936084161122','235.109360841611220','test','test','5.10'),('2019-03-27 23:59:59','2019-04-07 15:59:59','ONTUSDT','4h','1.252700000000000','1.535200000000000','251.924904794249557','308.737218679757291','201.10553587790338','201.105535877903378','test','test','2.61'),('2019-05-11 19:59:59','2019-05-17 03:59:59','ONTUSDT','4h','1.220000000000000','1.329000000000000','264.549863435473526','288.185875824380560','216.8441503569455','216.844150356945505','test','test','6.69'),('2019-05-19 15:59:59','2019-05-20 11:59:59','ONTUSDT','4h','1.402800000000000','1.333400000000000','269.802310633008460','256.454520243836214','192.33127361919622','192.331273619196224','test','test','4.94'),('2019-05-21 07:59:59','2019-05-21 11:59:59','ONTUSDT','4h','1.395400000000000','1.369000000000000','266.836134990970152','261.787780423275137','191.22555180662903','191.225551806629028','test','test','1.89'),('2019-05-21 15:59:59','2019-05-22 11:59:59','ONTUSDT','4h','1.381400000000000','1.338900000000000','265.714278420371272','257.539342244849479','192.35143942404176','192.351439424041757','test','test','3.07'),('2019-05-25 23:59:59','2019-05-26 07:59:59','ONTUSDT','4h','1.349500000000000','1.338900000000000','263.897625936921941','261.824773150755675','195.55214963832677','195.552149638326767','test','test','0.78'),('2019-05-26 19:59:59','2019-05-29 07:59:59','ONTUSDT','4h','1.362100000000000','1.425800000000000','263.436991984440567','275.756892424502837','193.40503045623709','193.405030456237085','test','test','0.0'),('2019-05-29 11:59:59','2019-05-30 23:59:59','ONTUSDT','4h','1.448000000000000','1.441700000000000','266.174747637787732','265.016666898755943','183.82233952885895','183.822339528858947','test','test','0.43'),('2019-06-01 03:59:59','2019-06-01 15:59:59','ONTUSDT','4h','1.528000000000000','1.469200000000000','265.917396362447391','255.684449434363700','174.02970966128757','174.029709661287569','test','test','3.84'),('2019-06-02 07:59:59','2019-06-03 03:59:59','ONTUSDT','4h','1.533200000000000','1.471400000000000','263.643408156206533','253.016508453588784','171.95630586760146','171.956305867601458','test','test','4.03'),('2019-06-11 15:59:59','2019-06-14 11:59:59','ONTUSDT','4h','1.422600000000000','1.394800000000000','261.281874888958157','256.175986992210653','183.6650322571054','183.665032257105395','test','test','1.95'),('2019-06-15 11:59:59','2019-06-18 15:59:59','ONTUSDT','4h','1.447600000000000','1.440900000000000','260.147233134125315','258.943180590605948','179.70933485363727','179.709334853637273','test','test','1.28'),('2019-06-22 07:59:59','2019-06-27 07:59:59','ONTUSDT','4h','1.475300000000000','1.596900000000000','259.879665902232148','281.299965077797424','176.1537761148459','176.153776114845897','test','test','0.44'),('2019-07-25 19:59:59','2019-07-27 11:59:59','ONTUSDT','4h','1.043000000000000','1.004000000000000','264.639732385691161','254.744286975296205','253.72936949730698','253.729369497306976','test','test','3.73'),('2019-08-25 07:59:59','2019-08-25 19:59:59','ONTUSDT','4h','0.835500000000000','0.791000000000000','262.440744516714460','248.462751541258086','314.11220169564865','314.112201695648650','test','test','5.32'),('2019-08-25 23:59:59','2019-08-26 11:59:59','ONTUSDT','4h','0.804600000000000','0.808600000000000','259.334523855501914','260.623783233356789','322.31484446371104','322.314844463711040','test','test','0.86'),('2019-08-26 15:59:59','2019-08-26 19:59:59','ONTUSDT','4h','0.808800000000000','0.796600000000000','259.621025939469689','255.704882867682443','320.99533375305356','320.995333753053558','test','test','1.50'),('2019-09-09 11:59:59','2019-09-11 07:59:59','ONTUSDT','4h','0.755500000000000','0.742000000000000','258.750771923516993','254.127164483454180','342.4894400046552','342.489440004655194','test','test','1.78'),('2019-09-13 23:59:59','2019-09-14 03:59:59','ONTUSDT','4h','0.748000000000000','0.739300000000000','257.723303603502984','254.725719724692169','344.54987112767776','344.549871127677761','test','test','1.16'),('2019-09-14 15:59:59','2019-09-19 03:59:59','ONTUSDT','4h','0.756200000000000','0.782500000000000','257.057173852656149','265.997406161998754','339.9327874274744','339.932787427474409','test','test','0.26'),('2019-09-19 07:59:59','2019-09-21 23:59:59','ONTUSDT','4h','0.796400000000000','0.805800000000000','259.043892143621179','262.101416736978820','325.268573761453','325.268573761453013','test','test','1.73'),('2019-10-08 19:59:59','2019-10-10 11:59:59','ONTUSDT','4h','0.629600000000000','0.636400000000000','259.723342053256204','262.528486154212544','412.5211913171159','412.521191317115893','test','test','0.04'),('2019-10-10 19:59:59','2019-10-11 07:59:59','ONTUSDT','4h','0.640700000000000','0.629800000000000','260.346707409024305','255.917521970038251','406.3472879803719','406.347287980371902','test','test','1.70'),('2019-10-11 19:59:59','2019-10-12 19:59:59','ONTUSDT','4h','0.648800000000000','0.633400000000000','259.362443978138515','253.206183748077876','399.75715779614444','399.757157796144440','test','test','2.37'),('2019-10-13 19:59:59','2019-10-13 23:59:59','ONTUSDT','4h','0.647300000000000','0.636600000000000','257.994386149236163','253.729686733514228','398.57003885252','398.570038852519986','test','test','1.65'),('2019-10-15 11:59:59','2019-10-15 19:59:59','ONTUSDT','4h','0.646200000000000','0.632600000000000','257.046675167964565','251.636841088292158','397.7819176229721','397.781917622972117','test','test','2.10'),('2019-10-16 03:59:59','2019-10-16 07:59:59','ONTUSDT','4h','0.643700000000000','0.635000000000000','255.844489816926284','252.386594739394411','397.4592043140069','397.459204314006911','test','test','1.35'),('2019-10-26 19:59:59','2019-10-31 11:59:59','ONTUSDT','4h','0.655700000000000','0.842700000000000','255.076068688585877','327.821569443146757','389.0133730190421','389.013373019042092','test','test','0.0'),('2019-11-02 03:59:59','2019-11-06 19:59:59','ONTUSDT','4h','0.901300000000000','0.882200000000000','271.241735522932743','265.493685874105495','300.9450077920035','300.945007792003480','test','test','2.56'),('2019-11-12 23:59:59','2019-11-14 11:59:59','ONTUSDT','4h','0.916600000000000','0.873100000000000','269.964391156526688','257.152421905698759','294.52802875466585','294.528028754665854','test','test','4.74'),('2019-11-14 15:59:59','2019-11-14 19:59:59','ONTUSDT','4h','0.877400000000000','0.873800000000000','267.117286878564926','266.021296187018493','304.441858762896','304.441858762896004','test','test','0.41'),('2019-12-09 07:59:59','2019-12-09 15:59:59','ONTUSDT','4h','0.639900000000000','0.616600000000000','266.873733391554595','257.156343193049793','417.0553733263863','417.055373326386302','test','test','3.64');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-01  1:31:34
