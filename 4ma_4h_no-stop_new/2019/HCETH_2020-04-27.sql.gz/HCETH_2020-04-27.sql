-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-02-08 07:59:59','2019-02-12 03:59:59','HCETH','4h','0.008732000000000','0.009503000000000','1.297777777777778','1.412366264569655','148.62319947065708','148.623199470657084','test','test','0.0'),('2019-02-28 03:59:59','2019-02-28 11:59:59','HCETH','4h','0.008416000000000','0.008341000000000','1.323241885953750','1.311449687587955','157.22931154393424','157.229311543934244','test','test','0.0'),('2019-02-28 19:59:59','2019-03-04 11:59:59','HCETH','4h','0.008391000000000','0.008472000000000','1.320621397428018','1.333369619712808','157.3854603060444','157.385460306044394','test','test','0.59'),('2019-03-08 11:59:59','2019-03-11 19:59:59','HCETH','4h','0.008718000000000','0.009103000000000','1.323454335713527','1.381900070887845','151.80710434887902','151.807104348879022','test','test','2.82'),('2019-03-12 11:59:59','2019-03-16 03:59:59','HCETH','4h','0.009342000000000','0.009660000000000','1.336442276863376','1.381934531631365','143.0574049307831','143.057404930783093','test','test','2.55'),('2019-03-18 07:59:59','2019-03-18 11:59:59','HCETH','4h','0.009696000000000','0.009553000000000','1.346551666811817','1.326692251758796','138.87702834280296','138.877028342802959','test','test','1.99'),('2019-03-21 11:59:59','2019-03-21 15:59:59','HCETH','4h','0.009747000000000','0.009500000000000','1.342138463466702','1.308127157374953','137.69759551315295','137.697595513152947','test','test','1.99'),('2019-03-21 19:59:59','2019-03-22 07:59:59','HCETH','4h','0.009638000000000','0.009529000000000','1.334580395446313','1.319487091534334','138.47067809154524','138.470678091545238','test','test','1.43'),('2019-03-22 11:59:59','2019-03-22 15:59:59','HCETH','4h','0.009570000000000','0.009569000000000','1.331226327910318','1.331087223800818','139.10410949951074','139.104109499510741','test','test','0.42'),('2019-03-22 19:59:59','2019-03-22 23:59:59','HCETH','4h','0.009626000000000','0.009556000000000','1.331195415885984','1.321515000436990','138.29164927134684','138.291649271346841','test','test','0.59'),('2019-03-23 03:59:59','2019-03-25 19:59:59','HCETH','4h','0.009724000000000','0.010014000000000','1.329044212452875','1.368680454905707','136.67669811321213','136.676698113212126','test','test','1.72'),('2019-03-31 19:59:59','2019-04-02 07:59:59','HCETH','4h','0.010394000000000','0.009921000000000','1.337852266331282','1.276970592098581','128.7138990120533','128.713899012053304','test','test','3.65'),('2019-04-02 11:59:59','2019-04-02 15:59:59','HCETH','4h','0.009974000000000','0.009780000000000','1.324323005390682','1.298564166103957','132.7775220965191','132.777522096519107','test','test','0.53'),('2019-04-05 03:59:59','2019-04-05 07:59:59','HCETH','4h','0.010162000000000','0.009886000000000','1.318598818882521','1.282785664581048','129.7578054401221','129.757805440122098','test','test','3.75'),('2019-04-05 15:59:59','2019-04-05 19:59:59','HCETH','4h','0.009850000000000','0.009918000000000','1.310640340148860','1.319688415593542','133.05993301003653','133.059933010036531','test','test','0.0'),('2019-04-06 03:59:59','2019-04-06 11:59:59','HCETH','4h','0.009986000000000','0.009834000000000','1.312651023581011','1.292670755647473','131.44913114169952','131.449131141699525','test','test','1.00'),('2019-05-30 23:59:59','2019-06-10 19:59:59','HCETH','4h','0.006050000000000','0.009519000000000','1.308210964040225','2.058323994495686','216.23321719673143','216.233217196731431','test','test','0.0'),('2019-06-14 07:59:59','2019-06-21 15:59:59','HCETH','4h','0.010123000000000','0.011235000000000','1.474902748585883','1.636919132703981','145.6981871565626','145.698187156562597','test','test','6.10'),('2019-06-22 19:59:59','2019-06-27 19:59:59','HCETH','4h','0.012409000000000','0.014303000000000','1.510906389501016','1.741517776535823','121.75891606906407','121.758916069064071','test','test','23.2'),('2019-06-28 15:59:59','2019-06-30 15:59:59','HCETH','4h','0.017401000000000','0.015543000000000','1.562153364397640','1.395353700524827','89.77376957632548','89.773769576325478','test','test','43.4'),('2019-07-04 03:59:59','2019-07-07 19:59:59','HCETH','4h','0.016500000000000','0.015988000000000','1.525086772425904','1.477762867730021','92.42950135914568','92.429501359145675','test','test','5.80'),('2019-07-24 19:59:59','2019-07-25 11:59:59','HCETH','4h','0.014627000000000','0.013972000000000','1.514570349160152','1.446747584498916','103.54620558967335','103.546205589673349','test','test','0.0'),('2019-07-27 03:59:59','2019-07-27 07:59:59','HCETH','4h','0.014144000000000','0.013982000000000','1.499498623679877','1.482323936389426','106.01658821266098','106.016588212660977','test','test','1.21'),('2019-08-17 19:59:59','2019-08-21 19:59:59','HCETH','4h','0.013163000000000','0.013970000000000','1.495682026504221','1.587379617888321','113.62774644869873','113.627746448698730','test','test','0.0'),('2019-10-27 15:59:59','2019-10-30 11:59:59','HCETH','4h','0.009887000000000','0.009117000000000','1.516059269034021','1.397988505692644','153.33865369010027','153.338653690100273','test','test','0.0'),('2019-10-31 19:59:59','2019-11-06 07:59:59','HCETH','4h','0.009600000000000','0.010274000000000','1.489821321624826','1.594419193580569','155.18972100258608','155.189721002586083','test','test','5.03'),('2019-11-12 07:59:59','2019-11-12 23:59:59','HCETH','4h','0.010207000000000','0.010090000000000','1.513065293170547','1.495721446859098','148.2380026619523','148.238002661952294','test','test','0.0'),('2019-11-13 01:59:59','2019-11-13 07:59:59','HCETH','4h','0.010240000000000','0.010129000000000','1.509211105101336','1.492851492536273','147.38389698255236','147.383896982552358','test','test','1.46'),('2019-11-13 11:59:59','2019-11-13 15:59:59','HCETH','4h','0.010153000000000','0.010012000000000','1.505575635642433','1.484666922491090','148.288745754204','148.288745754204001','test','test','0.23'),('2019-12-07 19:59:59','2019-12-08 03:59:59','HCETH','4h','0.008407000000000','0.008343000000000','1.500929254942135','1.489503125250652','178.5332764294201','178.533276429420113','test','test','0.0'),('2019-12-08 11:59:59','2019-12-08 15:59:59','HCETH','4h','0.008398000000000','0.008368000000000','1.498390115010694','1.493037447298105','178.42225708629368','178.422257086293683','test','test','0.65'),('2019-12-14 03:59:59','2019-12-14 11:59:59','HCETH','4h','0.008426000000000','0.008168000000000','1.497200633296785','1.451357081980553','177.68818339624798','177.688183396247979','test','test','1.03'),('2019-12-14 19:59:59','2019-12-15 11:59:59','HCETH','4h','0.008227000000000','0.008219000000000','1.487013177448734','1.485567194050218','180.74792481448085','180.747924814480854','test','test','0.71'),('2019-12-16 15:59:59','2019-12-17 03:59:59','HCETH','4h','0.008436000000000','0.008202000000000','1.486691847804619','1.445453595980735','176.23184540121136','176.231845401211359','test','test','2.57'),('2019-12-17 11:59:59','2019-12-17 15:59:59','HCETH','4h','0.008344000000000','0.008321000000000','1.477527791843756','1.473455028275634','177.0766768748509','177.076676874850904','test','test','1.70'),('2019-12-17 19:59:59','2019-12-20 15:59:59','HCETH','4h','0.008528000000000','0.008647000000000','1.476622733273062','1.497227576760338','173.1499452712315','173.149945271231502','test','test','2.42'),('2019-12-21 03:59:59','2019-12-21 11:59:59','HCETH','4h','0.008600000000000','0.008608000000000','1.481201587381346','1.482579449323096','172.23274271876116','172.232742718761159','test','test','2.69'),('2019-12-24 03:59:59','2019-12-24 07:59:59','HCETH','4h','0.008661000000000','0.008653000000000','1.481507778923957','1.480139338532386','171.0550489463061','171.055048946306101','test','test','0.61'),('2019-12-24 11:59:59','2019-12-26 19:59:59','HCETH','4h','0.008670000000000','0.008658000000000','1.481203681059164','1.479153572158044','170.84240842666244','170.842408426662445','test','test','0.65'),('2019-12-26 23:59:59','2019-12-28 19:59:59','HCETH','4h','0.008766000000000','0.008716000000000','1.480748101303359','1.472302127647739','168.91947311240693','168.919473112406934','test','test','1.28'),('2020-01-08 11:59:59','2020-01-08 19:59:59','HCETH','4h','0.008479000000000','0.008432000000000','1.478871218268777','1.470673677608483','174.4157587296588','174.415758729658791','test','test','0.0'),('2020-01-10 23:59:59','2020-01-11 07:59:59','HCETH','4h','0.008516000000000','0.008452000000000','1.477049542566489','1.465949123270545','173.44405149911807','173.444051499118075','test','test','1.51'),('2020-01-11 15:59:59','2020-01-11 19:59:59','HCETH','4h','0.008593000000000','0.008453000000000','1.474582782722946','1.450558391988486','171.60279096042663','171.602790960426631','test','test','1.87'),('2020-01-12 03:59:59','2020-01-12 19:59:59','HCETH','4h','0.008492000000000','0.008494000000000','1.469244029226400','1.469590059379303','173.01507645153083','173.015076451530831','test','test','0.45'),('2020-01-13 03:59:59','2020-01-13 07:59:59','HCETH','4h','0.008486000000000','0.008317000000000','1.469320924815934','1.440059171776352','173.14646768983425','173.146467689834253','test','test','0.0'),('2020-01-15 03:59:59','2020-01-18 15:59:59','HCETH','4h','0.009394000000000','0.008735000000000','1.462818313029360','1.360199911040181','155.71836417174367','155.718364171743673','test','test','11.4'),('2020-01-27 03:59:59','2020-01-28 23:59:59','HCETH','4h','0.008865000000000','0.008835000000000','1.440014223698431','1.435141079117388','162.43815270145868','162.438152701458677','test','test','4.18'),('2020-01-29 07:59:59','2020-01-29 11:59:59','HCETH','4h','0.008889000000000','0.008741000000000','1.438931302680422','1.414973395964627','161.87774807969643','161.877748079696431','test','test','1.94'),('2020-01-29 19:59:59','2020-01-30 15:59:59','HCETH','4h','0.008942000000000','0.008824000000000','1.433607323410245','1.414689221848804','160.32289458848635','160.322894588486349','test','test','2.24'),('2020-01-30 19:59:59','2020-01-30 23:59:59','HCETH','4h','0.008997000000000','0.008965000000000','1.429403300841036','1.424319283321095','158.87554749817002','158.875547498170022','test','test','1.92'),('2020-01-31 03:59:59','2020-02-03 11:59:59','HCETH','4h','0.008997000000000','0.009173000000000','1.428273519169938','1.456213514654423','158.7499743436632','158.749974343663212','test','test','0.97');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27 10:13:00
