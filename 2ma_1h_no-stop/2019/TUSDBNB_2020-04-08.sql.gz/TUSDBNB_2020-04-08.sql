-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 03:59:59','2019-01-01 05:59:59','TUSDBNB','1h','0.171050000000000','0.168780000000000','0.711908500000000','0.702460781233557','4.161990646009939','4.161990646009939','test'),('2019-01-01 09:59:59','2019-01-01 10:59:59','TUSDBNB','1h','0.169930000000000','0.168300000000000','0.711908500000000','0.705079741952569','4.189422114988525','4.189422114988525','test'),('2019-01-01 14:59:59','2019-01-01 20:59:59','TUSDBNB','1h','0.169430000000000','0.168780000000000','0.711908500000000','0.709177339491236','4.201785398099511','4.201785398099511','test'),('2019-01-02 09:59:59','2019-01-02 10:59:59','TUSDBNB','1h','0.169600000000000','0.168780000000000','0.711908500000000','0.708466489563679','4.197573702830189','4.197573702830189','test'),('2019-01-03 08:59:59','2019-01-03 12:59:59','TUSDBNB','1h','0.168560000000000','0.167840000000000','0.711908500000000','0.708867599905078','4.223472354057903','4.223472354057903','test'),('2019-01-04 07:59:59','2019-01-04 08:59:59','TUSDBNB','1h','0.169300000000000','0.169940000000000','0.711908500000000','0.714599707560543','4.205011813349085','4.205011813349085','test'),('2019-01-06 02:59:59','2019-01-06 05:59:59','TUSDBNB','1h','0.167160000000000','0.166190000000000','0.711908500000000','0.707777420525245','4.25884481933477','4.258844819334770','test'),('2019-01-09 21:59:59','2019-01-09 22:59:59','TUSDBNB','1h','0.155730000000000','0.153910000000000','0.711908500000000','0.703588500834778','4.571428112759263','4.571428112759263','test'),('2019-01-10 06:59:59','2019-01-11 19:59:59','TUSDBNB','1h','0.163830000000000','0.163960000000000','0.711908500000000','0.712473403283892','4.34540987609107','4.345409876091070','test'),('2019-01-15 20:59:59','2019-01-16 03:59:59','TUSDBNB','1h','0.174630000000000','0.169590000000000','0.711908500000000','0.691362094227796','4.0766678119452555','4.076667811945256','test'),('2019-01-16 04:59:59','2019-01-16 05:59:59','TUSDBNB','1h','0.170500000000000','0.168620000000000','0.711908500000000','0.704058717126100','4.17541642228739','4.175416422287390','test'),('2019-01-20 12:59:59','2019-01-20 17:59:59','TUSDBNB','1h','0.158640000000000','0.157300000000000','0.711908500000000','0.705895152861825','4.487572491174988','4.487572491174988','test'),('2019-01-21 01:59:59','2019-01-21 02:59:59','TUSDBNB','1h','0.157070000000000','0.156320000000000','0.711908500000000','0.708509178837461','4.532428216718661','4.532428216718661','test'),('2019-01-22 05:59:59','2019-01-22 06:59:59','TUSDBNB','1h','0.156750000000000','0.156020000000000','0.711908500000000','0.708593072854865','4.541681020733653','4.541681020733653','test'),('2019-01-23 10:59:59','2019-01-23 11:59:59','TUSDBNB','1h','0.155800000000000','0.155040000000000','0.711908500000000','0.708435775609756','4.569374197689346','4.569374197689346','test'),('2019-01-23 20:59:59','2019-01-23 23:59:59','TUSDBNB','1h','0.156420000000000','0.154190000000000','0.711908500000000','0.701759184343434','4.551262626262626','4.551262626262626','test'),('2019-01-24 01:59:59','2019-01-24 02:59:59','TUSDBNB','1h','0.156050000000000','0.155710000000000','0.711908500000000','0.710357401698174','4.562053828900994','4.562053828900994','test'),('2019-01-24 08:59:59','2019-01-24 10:59:59','TUSDBNB','1h','0.155590000000000','0.155720000000000','0.711908500000000','0.712503320393342','4.575541487242111','4.575541487242111','test'),('2019-01-28 04:59:59','2019-01-28 10:59:59','TUSDBNB','1h','0.150870000000000','0.147400000000000','0.711908500000000','0.695534651686883','4.718688274673561','4.718688274673561','test'),('2019-01-28 14:59:59','2019-01-31 22:59:59','TUSDBNB','1h','0.151170000000000','0.161560000000000','0.711908500000000','0.760838375735927','4.709323939935173','4.709323939935173','test'),('2019-02-01 01:59:59','2019-02-01 02:59:59','TUSDBNB','1h','0.164350000000000','0.162300000000000','0.711908500000000','0.703028594767265','4.331661089139033','4.331661089139033','test'),('2019-02-03 21:59:59','2019-02-03 22:59:59','TUSDBNB','1h','0.152690000000000','0.152210000000000','0.711908500000000','0.709670527113760','4.662443513000197','4.662443513000197','test'),('2019-02-12 11:59:59','2019-02-12 12:59:59','TUSDBNB','1h','0.111470000000000','0.108680000000000','0.711908500000000','0.694090031219162','6.386547950121109','6.386547950121109','test'),('2019-02-12 14:59:59','2019-02-12 17:59:59','TUSDBNB','1h','0.110920000000000','0.109320000000000','0.711908500000000','0.701639354670032','6.418215831229715','6.418215831229715','test'),('2019-02-12 19:59:59','2019-02-12 20:59:59','TUSDBNB','1h','0.110700000000000','0.110030000000000','0.711908500000000','0.707599749367660','6.430971093044264','6.430971093044264','test'),('2019-02-13 02:59:59','2019-02-13 06:59:59','TUSDBNB','1h','0.110800000000000','0.111470000000000','0.711908500000000','0.716213361868231','6.425166967509026','6.425166967509026','test'),('2019-02-16 12:59:59','2019-02-16 13:59:59','TUSDBNB','1h','0.111290000000000','0.110580000000000','0.711908500000000','0.707366716955701','6.396877527181239','6.396877527181239','test'),('2019-02-16 23:59:59','2019-02-17 00:59:59','TUSDBNB','1h','0.111040000000000','0.111340000000000','0.711908500000000','0.713831883915706','6.411279719020174','6.411279719020174','test'),('2019-02-21 09:59:59','2019-02-21 10:59:59','TUSDBNB','1h','0.099190000000000','0.098800000000000','0.711908500000000','0.709109384010485','7.177220485936083','7.177220485936083','test'),('2019-02-23 08:59:59','2019-02-23 09:59:59','TUSDBNB','1h','0.096100000000000','0.095750000000000','0.711908500000000','0.709315701092612','7.407996878251821','7.407996878251821','test'),('2019-02-23 15:59:59','2019-02-23 16:59:59','TUSDBNB','1h','0.096350000000000','0.095480000000000','0.711908500000000','0.705480265490400','7.388775298391282','7.388775298391282','test'),('2019-02-24 14:59:59','2019-02-27 04:59:59','TUSDBNB','1h','0.103360000000000','0.104560000000000','0.711908500000000','0.720173691563468','6.887659636222911','6.887659636222911','test'),('2019-02-27 20:59:59','2019-02-27 22:59:59','TUSDBNB','1h','0.104300000000000','0.102300000000000','0.711908500000000','0.698257330297220','6.825584851390221','6.825584851390221','test'),('2019-03-04 04:59:59','2019-03-04 05:59:59','TUSDBNB','1h','0.091390000000000','0.090460000000000','0.711908500000000','0.704663999452894','7.789785534522378','7.789785534522378','test'),('2019-03-04 08:59:59','2019-03-04 09:59:59','TUSDBNB','1h','0.090570000000000','0.089700000000000','0.711908500000000','0.705070028155018','7.860312465496302','7.860312465496302','test'),('2019-03-08 08:59:59','2019-03-08 09:59:59','TUSDBNB','1h','0.072900000000000','0.071600000000000','0.711908500000000','0.699213286694102','9.765548696844993','9.765548696844993','test'),('2019-03-08 16:59:59','2019-03-08 20:59:59','TUSDBNB','1h','0.071760000000000','0.070320000000000','0.711908500000000','0.697622710702341','9.9206870122631','9.920687012263100','test'),('2019-03-08 22:59:59','2019-03-08 23:59:59','TUSDBNB','1h','0.071930000000000','0.070430000000000','0.711908500000000','0.697062639441123','9.89724037258446','9.897240372584459','test'),('2019-03-10 05:59:59','2019-03-10 08:59:59','TUSDBNB','1h','0.070830000000000','0.069880000000000','0.711908500000000','0.702360101369476','10.050945926867147','10.050945926867147','test'),('2019-03-10 10:59:59','2019-03-10 21:59:59','TUSDBNB','1h','0.070650000000000','0.070580000000000','0.711908500000000','0.711203141259731','10.076553432413306','10.076553432413306','test'),('2019-03-11 09:59:59','2019-03-11 10:59:59','TUSDBNB','1h','0.070510000000000','0.070300000000000','0.711908500000000','0.709788222237980','10.096560771521771','10.096560771521771','test'),('2019-03-14 01:59:59','2019-03-14 02:59:59','TUSDBNB','1h','0.067920000000000','0.067680000000000','0.711908500000000','0.709392922261484','10.481573910482922','10.481573910482922','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-08  1:43:02
