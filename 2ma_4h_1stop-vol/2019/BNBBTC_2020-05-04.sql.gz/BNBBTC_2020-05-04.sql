-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 23:59:59','2019-01-03 07:59:59','BNBBTC','4h','0.001568000000000','0.001552320000000','0.033333333333333','0.033000000000000','21.258503401360546','21.258503401360546','test','test','1.00'),('2019-01-04 11:59:59','2019-01-06 19:59:59','BNBBTC','4h','0.001569800000000','0.001570800000000','0.033259259259259','0.033280446199799','21.186940539724382','21.186940539724382','test','test','0.0'),('2019-01-07 19:59:59','2019-01-13 19:59:59','BNBBTC','4h','0.001555200000000','0.001596000000000','0.033263967468268','0.034136633281479','21.38886797085148','21.388867970851479','test','test','0.0'),('2019-01-14 15:59:59','2019-01-15 11:59:59','BNBBTC','4h','0.001627500000000','0.001624100000000','0.033457893204537','0.033387996530561','20.5578452869661','20.557845286966099','test','test','0.28'),('2019-01-16 07:59:59','2019-01-28 15:59:59','BNBBTC','4h','0.001643700000000','0.001800900000000','0.033442360610320','0.036640717419922','20.34578123156321','20.345781231563208','test','test','0.0'),('2019-02-01 11:59:59','2019-02-14 15:59:59','BNBBTC','4h','0.001899200000000','0.002378400000000','0.034153106568010','0.042770507930368','17.982890989895626','17.982890989895626','test','test','0.85'),('2019-02-16 19:59:59','2019-02-17 03:59:59','BNBBTC','4h','0.002516100000000','0.002490939000000','0.036068084648534','0.035707403802049','14.33491699397233','14.334916993972330','test','test','1.00'),('2019-02-17 19:59:59','2019-02-18 15:59:59','BNBBTC','4h','0.002498700000000','0.002473713000000','0.035987933349315','0.035628054015822','14.402662724342614','14.402662724342614','test','test','1.00'),('2019-02-19 15:59:59','2019-02-23 19:59:59','BNBBTC','4h','0.002630500000000','0.002635100000000','0.035907960164094','0.035970753023533','13.650621617218864','13.650621617218864','test','test','0.61'),('2019-02-24 11:59:59','2019-02-24 15:59:59','BNBBTC','4h','0.002630000000000','0.002603700000000','0.035921914132858','0.035562694991529','13.658522483976595','13.658522483976595','test','test','0.99'),('2019-02-24 19:59:59','2019-02-25 11:59:59','BNBBTC','4h','0.002628400000000','0.002602116000000','0.035842087657008','0.035483666780438','13.636466160785101','13.636466160785101','test','test','1.00'),('2019-02-27 15:59:59','2019-02-27 23:59:59','BNBBTC','4h','0.002584600000000','0.002582400000000','0.035762438573325','0.035731997745011','13.83674014289458','13.836740142894580','test','test','0.33'),('2019-02-28 11:59:59','2019-02-28 19:59:59','BNBBTC','4h','0.002699300000000','0.002672307000000','0.035755673944811','0.035398117205363','13.2462764215949','13.246276421594899','test','test','0.99'),('2019-03-01 03:59:59','2019-03-19 15:59:59','BNBBTC','4h','0.002775300000000','0.003857300000000','0.035676216891600','0.049585223729315','12.854904655929248','12.854904655929248','test','test','0.0'),('2019-03-22 23:59:59','2019-03-23 15:59:59','BNBBTC','4h','0.003800000000000','0.003779400000000','0.038767107299982','0.038556948770935','10.20187034210041','10.201870342100410','test','test','0.73'),('2019-03-24 11:59:59','2019-03-25 11:59:59','BNBBTC','4h','0.004268000000000','0.004225320000000','0.038720405404638','0.038333201350592','9.07225993548214','9.072259935482140','test','test','0.99'),('2019-03-28 11:59:59','2019-03-29 11:59:59','BNBBTC','4h','0.004141200000000','0.004099788000000','0.038634360059294','0.038248016458701','9.329266893483585','9.329266893483585','test','test','1.00'),('2019-03-30 11:59:59','2019-04-02 07:59:59','BNBBTC','4h','0.004026000000000','0.004032700000000','0.038548505925829','0.038612657686808','9.574889698417564','9.574889698417564','test','test','0.0'),('2019-04-13 23:59:59','2019-04-14 03:59:59','BNBBTC','4h','0.003687700000000','0.003674800000000','0.038562761872713','0.038427864883219','10.457130968547695','10.457130968547695','test','test','0.34'),('2019-04-14 07:59:59','2019-04-16 07:59:59','BNBBTC','4h','0.003783100000000','0.003771400000000','0.038532784763937','0.038413614352968','10.185505211053602','10.185505211053602','test','test','0.85'),('2019-04-16 11:59:59','2019-04-16 19:59:59','BNBBTC','4h','0.003825700000000','0.003787443000000','0.038506302450388','0.038121239425884','10.065165185557733','10.065165185557733','test','test','0.99'),('2019-04-16 23:59:59','2019-04-17 15:59:59','BNBBTC','4h','0.003793900000000','0.003755961000000','0.038420732889387','0.038036525560493','10.126975642317229','10.126975642317229','test','test','0.99'),('2019-04-18 07:59:59','2019-04-23 19:59:59','BNBBTC','4h','0.003929900000000','0.004150000000000','0.038335353482966','0.040482383000664','9.754791084497427','9.754791084497427','test','test','0.0'),('2019-04-25 03:59:59','2019-04-25 11:59:59','BNBBTC','4h','0.004271200000000','0.004228488000000','0.038812471153566','0.038424346442030','9.08701797002388','9.087017970023879','test','test','1.00'),('2019-04-25 23:59:59','2019-04-27 07:59:59','BNBBTC','4h','0.004305500000000','0.004262445000000','0.038726221217669','0.038338959005492','8.994593245306959','8.994593245306959','test','test','1.00'),('2019-04-28 19:59:59','2019-04-29 11:59:59','BNBBTC','4h','0.004308500000000','0.004265415000000','0.038640162948296','0.038253761318813','8.968356260484262','8.968356260484262','test','test','1.0'),('2019-05-02 15:59:59','2019-05-03 03:59:59','BNBBTC','4h','0.004283300000000','0.004240467000000','0.038554295919522','0.038168752960327','9.001072985670497','9.001072985670497','test','test','0.99'),('2019-05-17 11:59:59','2019-05-17 15:59:59','BNBBTC','4h','0.003506400000000','0.003471336000000','0.038468619706368','0.038083933509304','10.970972994058863','10.970972994058863','test','test','1.00'),('2019-05-18 15:59:59','2019-05-19 03:59:59','BNBBTC','4h','0.003730000000000','0.003692700000000','0.038383133884798','0.037999302545950','10.290384419516949','10.290384419516949','test','test','1.00'),('2019-05-20 15:59:59','2019-05-21 07:59:59','BNBBTC','4h','0.003646600000000','0.003610134000000','0.038297838031721','0.037914859651404','10.502341367772965','10.502341367772965','test','test','1.00'),('2019-05-21 15:59:59','2019-05-26 19:59:59','BNBBTC','4h','0.003943200000000','0.003903768000000','0.038212731724984','0.037830604407734','9.690792180204852','9.690792180204852','test','test','0.99'),('2019-05-27 03:59:59','2019-05-27 07:59:59','BNBBTC','4h','0.003947800000000','0.003914600000000','0.038127814543373','0.037807169261738','9.657990410702839','9.657990410702839','test','test','0.84'),('2019-05-30 03:59:59','2019-05-30 07:59:59','BNBBTC','4h','0.003989700000000','0.003949803000000','0.038056560036343','0.037675994435980','9.538702167166118','9.538702167166118','test','test','0.99'),('2019-06-01 07:59:59','2019-06-01 15:59:59','BNBBTC','4h','0.003899300000000','0.003873900000000','0.037971989902929','0.037724640752175','9.738155541489157','9.738155541489157','test','test','0.92'),('2019-06-04 15:59:59','2019-06-04 19:59:59','BNBBTC','4h','0.003876400000000','0.003837636000000','0.037917023424983','0.037537853190733','9.781504340363051','9.781504340363051','test','test','1.00'),('2019-06-05 15:59:59','2019-06-14 07:59:59','BNBBTC','4h','0.003900600000000','0.004064800000000','0.037832763372928','0.039425374700886','9.699216370027116','9.699216370027116','test','test','0.46'),('2019-06-19 15:59:59','2019-06-19 19:59:59','BNBBTC','4h','0.003874900000000','0.003878100000000','0.038186677001363','0.038218212619419','9.854880642432809','9.854880642432809','test','test','0.0'),('2019-06-20 11:59:59','2019-06-20 15:59:59','BNBBTC','4h','0.003921300000000','0.003882087000000','0.038193684916486','0.037811748067321','9.740056847598103','9.740056847598103','test','test','1.00'),('2019-07-02 07:59:59','2019-07-02 11:59:59','BNBBTC','4h','0.003251400000000','0.003218886000000','0.038108810061116','0.037727721960505','11.720738777485527','11.720738777485527','test','test','0.99'),('2019-07-17 15:59:59','2019-07-18 15:59:59','BNBBTC','4h','0.002813600000000','0.002785464000000','0.038024123816536','0.037643882578371','13.514402834992968','13.514402834992968','test','test','1.00'),('2019-07-19 11:59:59','2019-07-19 15:59:59','BNBBTC','4h','0.002784300000000','0.002788500000000','0.037939625763611','0.037996856100934','13.626270791082378','13.626270791082378','test','test','0.0'),('2019-07-23 23:59:59','2019-07-24 03:59:59','BNBBTC','4h','0.002985600000000','0.002955744000000','0.037952343616349','0.037572820180186','12.711797835057983','12.711797835057983','test','test','0.99'),('2019-07-26 11:59:59','2019-07-27 03:59:59','BNBBTC','4h','0.002930500000000','0.002901195000000','0.037868005074980','0.037489325024230','12.922028689636429','12.922028689636429','test','test','0.99'),('2019-07-27 11:59:59','2019-07-28 23:59:59','BNBBTC','4h','0.002908400000000','0.002905500000000','0.037783853952591','0.037746179225434','12.991285226444322','12.991285226444322','test','test','0.30'),('2019-08-08 11:59:59','2019-08-08 15:59:59','BNBBTC','4h','0.002644900000000','0.002629300000000','0.037775481791000','0.037552676574947','14.28238564444789','14.282385644447890','test','test','0.58'),('2019-08-08 19:59:59','2019-08-08 23:59:59','BNBBTC','4h','0.002641700000000','0.002615283000000','0.037725969520766','0.037348709825558','14.280943907622449','14.280943907622449','test','test','0.99'),('2019-08-09 03:59:59','2019-08-09 07:59:59','BNBBTC','4h','0.002638800000000','0.002612412000000','0.037642134032942','0.037265712692613','14.264868134357366','14.264868134357366','test','test','1.00'),('2019-08-10 23:59:59','2019-08-11 11:59:59','BNBBTC','4h','0.002623000000000','0.002596770000000','0.037558484846202','0.037182899997740','14.318903868167155','14.318903868167155','test','test','0.99'),('2019-08-11 15:59:59','2019-08-16 19:59:59','BNBBTC','4h','0.002624600000000','0.002659600000000','0.037475021546544','0.037974764651828','14.278374436692912','14.278374436692912','test','test','0.16'),('2019-08-17 19:59:59','2019-08-18 11:59:59','BNBBTC','4h','0.002687400000000','0.002663700000000','0.037586075569941','0.037254606495368','13.98603690181613','13.986036901816130','test','test','0.88'),('2019-08-18 23:59:59','2019-08-19 19:59:59','BNBBTC','4h','0.002706300000000','0.002679237000000','0.037512415775591','0.037137291617835','13.86114465343499','13.861144653434989','test','test','0.99'),('2019-08-21 19:59:59','2019-08-21 23:59:59','BNBBTC','4h','0.002670600000000','0.002656200000000','0.037429054851645','0.037227235638785','14.015223115271974','14.015223115271974','test','test','0.53'),('2019-08-22 03:59:59','2019-08-22 07:59:59','BNBBTC','4h','0.002673100000000','0.002664800000000','0.037384206137676','0.037268127834978','13.985337674488962','13.985337674488962','test','test','0.31'),('2019-08-22 23:59:59','2019-08-23 07:59:59','BNBBTC','4h','0.002670000000000','0.002647900000000','0.037358410959299','0.037049189655104','13.99191421696596','13.991914216965959','test','test','0.82'),('2019-09-18 03:59:59','2019-09-19 07:59:59','BNBBTC','4h','0.002120800000000','0.002099592000000','0.037289695113922','0.036916798162783','17.582843791928727','17.582843791928727','test','test','0.99'),('2019-09-21 03:59:59','2019-09-21 15:59:59','BNBBTC','4h','0.002110700000000','0.002091000000000','0.037206829124780','0.036859563035919','17.62772024673352','17.627720246733521','test','test','0.93'),('2019-09-21 23:59:59','2019-09-22 03:59:59','BNBBTC','4h','0.002100000000000','0.002079000000000','0.037129658882811','0.036758362293983','17.680789944195876','17.680789944195876','test','test','1.00'),('2019-10-06 03:59:59','2019-10-06 07:59:59','BNBBTC','4h','0.001929600000000','0.001917100000000','0.037047148529738','0.036807156118553','19.199392894764948','19.199392894764948','test','test','0.64'),('2019-10-07 11:59:59','2019-10-07 15:59:59','BNBBTC','4h','0.001945000000000','0.001932500000000','0.036993816882808','0.036756067416980','19.019957266225422','19.019957266225422','test','test','0.64'),('2019-10-08 15:59:59','2019-10-21 07:59:59','BNBBTC','4h','0.001943700000000','0.002195700000000','0.036940983668180','0.041730368801884','19.005496562319287','19.005496562319287','test','test','0.0'),('2019-10-22 03:59:59','2019-10-23 15:59:59','BNBBTC','4h','0.002236500000000','0.002218400000000','0.038005291475670','0.037697714558295','16.993199854983132','16.993199854983132','test','test','0.80'),('2019-10-24 03:59:59','2019-10-25 15:59:59','BNBBTC','4h','0.002235100000000','0.002231500000000','0.037936941049586','0.037875837301307','16.973263410848038','16.973263410848038','test','test','0.61'),('2019-10-28 23:59:59','2019-10-29 03:59:59','BNBBTC','4h','0.002165000000000','0.002187200000000','0.037923362438858','0.038312230173797','17.51656463688581','17.516564636885811','test','test','0.0'),('2019-10-29 07:59:59','2019-10-30 03:59:59','BNBBTC','4h','0.002203600000000','0.002189900000000','0.038009777491066','0.037773466930335','17.248946038784922','17.248946038784922','test','test','0.62'),('2019-10-30 23:59:59','2019-10-31 07:59:59','BNBBTC','4h','0.002189600000000','0.002175700000000','0.037957264033126','0.037716304054107','17.33525028915155','17.335250289151549','test','test','0.63'),('2019-11-01 03:59:59','2019-11-01 07:59:59','BNBBTC','4h','0.002179900000000','0.002169400000000','0.037903717371122','0.037721145219924','17.387823923630446','17.387823923630446','test','test','0.48'),('2019-11-02 03:59:59','2019-11-02 07:59:59','BNBBTC','4h','0.002173300000000','0.002180900000000','0.037863145781967','0.037995552678366','17.421960052439555','17.421960052439555','test','test','0.0'),('2019-11-03 03:59:59','2019-11-03 15:59:59','BNBBTC','4h','0.002183100000000','0.002173300000000','0.037892569536722','0.037722468679473','17.35723033151126','17.357230331511261','test','test','0.44'),('2019-11-03 23:59:59','2019-11-04 23:59:59','BNBBTC','4h','0.002193300000000','0.002195500000000','0.037854769346222','0.037892739752715','17.259275678759153','17.259275678759153','test','test','0.0'),('2019-11-05 03:59:59','2019-11-07 11:59:59','BNBBTC','4h','0.002201100000000','0.002190400000000','0.037863207214332','0.037679146373301','17.20194775990732','17.201947759907320','test','test','0.48'),('2019-11-09 03:59:59','2019-11-18 07:59:59','BNBBTC','4h','0.002238000000000','0.002326700000000','0.037822304805214','0.039321338959022','16.900046829854336','16.900046829854336','test','test','0.13'),('2019-12-29 15:59:59','2019-12-29 19:59:59','BNBBTC','4h','0.001910400000000','0.001891296000000','0.038155423506060','0.037773869270999','19.972478803423485','19.972478803423485','test','test','1.00'),('2019-12-29 23:59:59','2020-01-01 15:59:59','BNBBTC','4h','0.001908000000000','0.001910800000000','0.038070633676047','0.038126502530498','19.953162304007687','19.953162304007687','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:07:14
