-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 11:59:59','2019-01-08 03:59:59','XLMBTC','4h','0.000030480000000','0.000030175200000','0.033333333333333','0.033000000000000','1093.6132983377079','1093.613298337707874','test','test','1.00'),('2019-01-08 11:59:59','2019-01-09 19:59:59','XLMBTC','4h','0.000030530000000','0.000030460000000','0.033259259259259','0.033183001540682','1089.395979667846','1089.395979667845950','test','test','0.45'),('2019-01-09 23:59:59','2019-01-10 07:59:59','XLMBTC','4h','0.000030870000000','0.000030561300000','0.033242313099576','0.032909889968580','1076.8484969088292','1076.848496908829247','test','test','0.99'),('2019-01-13 03:59:59','2019-01-13 07:59:59','XLMBTC','4h','0.000030740000000','0.000030432600000','0.033168441292688','0.032836756879761','1078.999391434208','1078.999391434208064','test','test','0.99'),('2019-01-17 15:59:59','2019-01-17 19:59:59','XLMBTC','4h','0.000029880000000','0.000029581200000','0.033094733645370','0.032763786308916','1107.588140741983','1107.588140741982897','test','test','1.00'),('2019-02-19 11:59:59','2019-02-20 03:59:59','XLMBTC','4h','0.000022370000000','0.000022480000000','0.033021189792825','0.033183564887917','1476.1372281101972','1476.137228110197157','test','test','0.0'),('2019-02-20 11:59:59','2019-02-20 15:59:59','XLMBTC','4h','0.000022780000000','0.000022552200000','0.033057273147290','0.032726700415817','1451.1533427256365','1451.153342725636548','test','test','1.00'),('2019-02-21 07:59:59','2019-02-21 11:59:59','XLMBTC','4h','0.000023190000000','0.000022958100000','0.032983812540296','0.032653974414893','1422.3291306725312','1422.329130672531164','test','test','1.00'),('2019-02-23 19:59:59','2019-02-24 15:59:59','XLMBTC','4h','0.000022870000000','0.000022641300000','0.032910515179095','0.032581410027304','1439.0255871926252','1439.025587192625153','test','test','1.00'),('2019-02-25 19:59:59','2019-02-25 23:59:59','XLMBTC','4h','0.000022620000000','0.000022470000000','0.032837380700920','0.032619626186988','1451.6967595455153','1451.696759545515306','test','test','0.66'),('2019-03-01 19:59:59','2019-03-01 23:59:59','XLMBTC','4h','0.000022290000000','0.000022170000000','0.032788990808935','0.032612468651148','1471.0179815583072','1471.017981558307156','test','test','0.53'),('2019-03-03 15:59:59','2019-03-04 03:59:59','XLMBTC','4h','0.000022850000000','0.000022621500000','0.032749763662760','0.032422266026132','1433.2500508866424','1433.250050886642384','test','test','0.99'),('2019-03-08 07:59:59','2019-03-21 15:59:59','XLMBTC','4h','0.000022390000000','0.000026230000000','0.032676986410176','0.038281257415762','1459.4455743714059','1459.445574371405883','test','test','0.31'),('2019-03-22 15:59:59','2019-03-23 07:59:59','XLMBTC','4h','0.000027200000000','0.000026928000000','0.033922379966973','0.033583156167303','1247.1463223151713','1247.146322315171346','test','test','1.00'),('2019-03-27 15:59:59','2019-03-28 07:59:59','XLMBTC','4h','0.000026410000000','0.000026340000000','0.033846996900379','0.033757285057023','1281.5977622256469','1281.597762225646875','test','test','0.26'),('2019-04-01 03:59:59','2019-04-02 07:59:59','XLMBTC','4h','0.000026650000000','0.000026383500000','0.033827060935189','0.033488790325837','1269.3081026337377','1269.308102633737690','test','test','1.00'),('2019-04-07 23:59:59','2019-04-08 03:59:59','XLMBTC','4h','0.000025560000000','0.000025304400000','0.033751889688666','0.033414370791779','1320.4964666927403','1320.496466692740341','test','test','1.00'),('2019-05-15 19:59:59','2019-05-15 23:59:59','XLMBTC','4h','0.000015500000000','0.000017320000000','0.033676885489358','0.037631203656496','2172.7022896360145','2172.702289636014484','test','test','0.0'),('2019-05-16 03:59:59','2019-05-16 11:59:59','XLMBTC','4h','0.000018420000000','0.000018235800000','0.034555622859833','0.034210066631235','1875.983868612016','1875.983868612016067','test','test','1.00'),('2019-05-16 15:59:59','2019-05-16 19:59:59','XLMBTC','4h','0.000018910000000','0.000018720900000','0.034478832586812','0.034134044260944','1823.3121410265235','1823.312141026523477','test','test','1.00'),('2019-05-18 03:59:59','2019-05-18 07:59:59','XLMBTC','4h','0.000018890000000','0.000018701100000','0.034402212958841','0.034058190829253','1821.1864986151875','1821.186498615187475','test','test','1.00'),('2019-05-21 11:59:59','2019-05-22 11:59:59','XLMBTC','4h','0.000016880000000','0.000016711200000','0.034325763596710','0.033982505960743','2033.5168007529753','2033.516800752975314','test','test','1.00'),('2019-05-30 07:59:59','2019-05-30 11:59:59','XLMBTC','4h','0.000016190000000','0.000016280000000','0.034249484122051','0.034439876560036','2115.4715331717657','2115.471533171765714','test','test','0.0'),('2019-06-03 03:59:59','2019-06-03 07:59:59','XLMBTC','4h','0.000015980000000','0.000015820200000','0.034291793552714','0.033948875617187','2145.919496415158','2145.919496415157937','test','test','1.00'),('2019-06-06 19:59:59','2019-06-06 23:59:59','XLMBTC','4h','0.000015860000000','0.000016030000000','0.034215589567042','0.034582339266058','2157.351170683578','2157.351170683577948','test','test','0.0'),('2019-06-07 15:59:59','2019-06-07 19:59:59','XLMBTC','4h','0.000016240000000','0.000016077600000','0.034297089500156','0.033954118605154','2111.889747546565','2111.889747546565104','test','test','1.00'),('2019-07-18 11:59:59','2019-07-18 15:59:59','XLMBTC','4h','0.000009100000000','0.000009009000000','0.034220873745711','0.033878665008254','3760.535576451795','3760.535576451794896','test','test','0.99'),('2019-07-19 23:59:59','2019-07-20 07:59:59','XLMBTC','4h','0.000008890000000','0.000008801100000','0.034144827359610','0.033803379086014','3840.812976334058','3840.812976334058021','test','test','1.00'),('2019-07-24 15:59:59','2019-07-25 03:59:59','XLMBTC','4h','0.000008720000000','0.000008632800000','0.034068949965477','0.033728260465822','3906.989674940061','3906.989674940060922','test','test','0.99'),('2019-07-25 19:59:59','2019-07-30 07:59:59','XLMBTC','4h','0.000008700000000','0.000008740000000','0.033993241187776','0.034149531951858','3907.2691020432444','3907.269102043244402','test','test','0.45'),('2019-07-30 11:59:59','2019-07-30 15:59:59','XLMBTC','4h','0.000008780000000','0.000008692200000','0.034027972468683','0.033687692743996','3875.6232880049356','3875.623288004935603','test','test','0.99'),('2019-08-14 11:59:59','2019-08-14 15:59:59','XLMBTC','4h','0.000007000000000','0.000007010000000','0.033952354752086','0.034000858116018','4850.336393155175','4850.336393155174846','test','test','0.0'),('2019-08-22 19:59:59','2019-08-23 03:59:59','XLMBTC','4h','0.000006780000000','0.000006712200000','0.033963133277404','0.033623501944630','5009.311692832514','5009.311692832514382','test','test','1.00'),('2019-08-24 11:59:59','2019-08-26 03:59:59','XLMBTC','4h','0.000006790000000','0.000006790000000','0.033887659647899','0.033887659647899','4990.818799396041','4990.818799396040959','test','test','0.0'),('2019-09-17 15:59:59','2019-09-23 03:59:59','XLMBTC','4h','0.000006060000000','0.000006570000000','0.033887659647899','0.036739591400445','5592.0230442077755','5592.023044207775456','test','test','0.0'),('2019-09-25 23:59:59','2019-10-01 19:59:59','XLMBTC','4h','0.000006800000000','0.000007070000000','0.034521422259576','0.035892125790471','5076.679744055295','5076.679744055294577','test','test','0.0'),('2019-10-04 11:59:59','2019-10-09 15:59:59','XLMBTC','4h','0.000007240000000','0.000007360000000','0.034826023044219','0.035403249945504','4810.224177378361','4810.224177378360764','test','test','0.55'),('2019-10-14 03:59:59','2019-10-20 19:59:59','XLMBTC','4h','0.000007490000000','0.000007690000000','0.034954295688949','0.035887654719362','4666.795152062661','4666.795152062661145','test','test','0.0'),('2019-10-21 23:59:59','2019-10-23 15:59:59','XLMBTC','4h','0.000007790000000','0.000007830000000','0.035161708806819','0.035342256733940','4513.698178025531','4513.698178025530979','test','test','0.89'),('2019-10-23 19:59:59','2019-10-25 15:59:59','XLMBTC','4h','0.000007870000000','0.000007791300000','0.035201830568401','0.034849812262717','4472.91366815773','4472.913668157730172','test','test','0.99'),('2019-11-01 03:59:59','2019-11-01 07:59:59','XLMBTC','4h','0.000007610000000','0.000007533900000','0.035123604278249','0.034772368235467','4615.453913041962','4615.453913041961641','test','test','1.0'),('2019-11-01 11:59:59','2019-11-01 15:59:59','XLMBTC','4h','0.000007670000000','0.000007593300000','0.035045551824298','0.034695096306055','4569.172336935826','4569.172336935826024','test','test','1.00'),('2019-11-02 03:59:59','2019-11-04 23:59:59','XLMBTC','4h','0.000007510000000','0.000008450000000','0.034967672820244','0.039344452107998','4656.148178461222','4656.148178461222415','test','test','0.93'),('2019-11-05 03:59:59','2019-11-05 07:59:59','XLMBTC','4h','0.000008860000000','0.000008771400000','0.035940290439745','0.035580887535348','4056.4661895874337','4056.466189587433746','test','test','0.99'),('2019-11-05 15:59:59','2019-11-06 15:59:59','XLMBTC','4h','0.000008650000000','0.000008563500000','0.035860423127656','0.035501818896379','4145.713656376468','4145.713656376467952','test','test','0.99'),('2019-11-10 03:59:59','2019-11-14 11:59:59','XLMBTC','4h','0.000008550000000','0.000008464500000','0.035780733298484','0.035422925965499','4184.881087541963','4184.881087541963097','test','test','0.99'),('2019-11-15 15:59:59','2019-11-16 15:59:59','XLMBTC','4h','0.000008480000000','0.000008420000000','0.035701220557820','0.035448617582175','4210.0495940826','4210.049594082600379','test','test','0.70'),('2019-11-17 07:59:59','2019-11-17 19:59:59','XLMBTC','4h','0.000008510000000','0.000008424900000','0.035645086563233','0.035288635697601','4188.611817066118','4188.611817066118419','test','test','1.00'),('2019-11-23 11:59:59','2019-11-24 03:59:59','XLMBTC','4h','0.000008360000000','0.000008276400000','0.035565875259759','0.035210216507161','4254.291299014221','4254.291299014221295','test','test','1.00'),('2019-11-25 07:59:59','2019-11-25 15:59:59','XLMBTC','4h','0.000008330000000','0.000008246700000','0.035486839981404','0.035131971581590','4260.124847707536','4260.124847707535992','test','test','0.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:37:00
