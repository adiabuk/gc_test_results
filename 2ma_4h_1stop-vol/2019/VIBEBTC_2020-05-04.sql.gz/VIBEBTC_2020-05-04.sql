-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 03:59:59','2019-01-03 07:59:59','VIBEBTC','4h','0.000007600000000','0.000007524000000','0.033333333333333','0.033000000000000','4385.964912280701','4385.964912280701355','test','test','0.99'),('2019-01-04 07:59:59','2019-01-07 11:59:59','VIBEBTC','4h','0.000007740000000','0.000007820000000','0.033259259259259','0.033603024212843','4297.061919800947','4297.061919800947180','test','test','0.0'),('2019-01-08 15:59:59','2019-01-08 23:59:59','VIBEBTC','4h','0.000008530000000','0.000008444700000','0.033335651471167','0.033002294956455','3908.048238120385','3908.048238120385122','test','test','1.00'),('2019-01-11 19:59:59','2019-01-11 23:59:59','VIBEBTC','4h','0.000008140000000','0.000008058600000','0.033261572245675','0.032928956523218','4086.188236569451','4086.188236569450964','test','test','1.00'),('2019-01-14 15:59:59','2019-01-27 11:59:59','VIBEBTC','4h','0.000009810000000','0.000011120000000','0.033187657640685','0.037619444746628','3383.043592322619','3383.043592322619133','test','test','0.0'),('2019-02-03 03:59:59','2019-02-03 07:59:59','VIBEBTC','4h','0.000010750000000','0.000010642500000','0.034172499219783','0.033830774227585','3178.8371367240306','3178.837136724030643','test','test','1.00'),('2019-02-11 19:59:59','2019-02-12 03:59:59','VIBEBTC','4h','0.000010080000000','0.000010340000000','0.034096560332628','0.034976035103112','3382.5952710940696','3382.595271094069631','test','test','0.0'),('2019-02-12 15:59:59','2019-02-13 07:59:59','VIBEBTC','4h','0.000010150000000','0.000010050000000','0.034291999170514','0.033954146961938','3378.522085764882','3378.522085764881922','test','test','0.98'),('2019-02-17 15:59:59','2019-02-17 19:59:59','VIBEBTC','4h','0.000010150000000','0.000010048500000','0.034216920901941','0.033874751692922','3371.1252120139025','3371.125212013902456','test','test','1.00'),('2019-02-17 23:59:59','2019-02-18 03:59:59','VIBEBTC','4h','0.000010050000000','0.000009949500000','0.034140883299937','0.033799474466938','3397.102815914118','3397.102815914117855','test','test','1.00'),('2019-02-19 19:59:59','2019-02-19 23:59:59','VIBEBTC','4h','0.000010140000000','0.000010038600000','0.034065014670382','0.033724364523678','3359.468902404493','3359.468902404492837','test','test','1.00'),('2019-02-20 15:59:59','2019-02-20 19:59:59','VIBEBTC','4h','0.000010230000000','0.000010127700000','0.033989314637781','0.033649421491403','3322.513649831932','3322.513649831932071','test','test','1.00'),('2019-02-23 15:59:59','2019-02-23 19:59:59','VIBEBTC','4h','0.000009950000000','0.000009850500000','0.033913782827474','0.033574644999199','3408.4203846707987','3408.420384670798740','test','test','0.99'),('2019-02-26 19:59:59','2019-02-26 23:59:59','VIBEBTC','4h','0.000009880000000','0.000009781200000','0.033838418865636','0.033500034676980','3424.941180732344','3424.941180732344037','test','test','0.99'),('2019-02-28 03:59:59','2019-02-28 07:59:59','VIBEBTC','4h','0.000009810000000','0.000009711900000','0.033763222379268','0.033425590155475','3441.714819497203','3441.714819497202825','test','test','0.99'),('2019-03-02 15:59:59','2019-03-02 19:59:59','VIBEBTC','4h','0.000010190000000','0.000010088100000','0.033688192996202','0.033351311066240','3306.0052008049497','3306.005200804949709','test','test','0.99'),('2019-03-03 03:59:59','2019-03-03 07:59:59','VIBEBTC','4h','0.000010460000000','0.000010355400000','0.033613330345100','0.033277197041649','3213.5115052676647','3213.511505267664688','test','test','1.00'),('2019-03-05 15:59:59','2019-03-07 03:59:59','VIBEBTC','4h','0.000010110000000','0.000010030000000','0.033538634055444','0.033273244270633','3317.3723101329374','3317.372310132937400','test','test','0.79'),('2019-03-08 15:59:59','2019-03-08 23:59:59','VIBEBTC','4h','0.000010130000000','0.000010028700000','0.033479658547708','0.033144861962231','3305.0008438014033','3305.000843801403335','test','test','1.00'),('2019-03-10 11:59:59','2019-03-11 15:59:59','VIBEBTC','4h','0.000010310000000','0.000010380000000','0.033405259306491','0.033632065140774','3240.083346895355','3240.083346895355135','test','test','0.0'),('2019-03-12 11:59:59','2019-03-13 11:59:59','VIBEBTC','4h','0.000010690000000','0.000010640000000','0.033455660602998','0.033299179496342','3129.622133114915','3129.622133114914959','test','test','0.46'),('2019-03-15 15:59:59','2019-03-15 19:59:59','VIBEBTC','4h','0.000011360000000','0.000011246400000','0.033420887023742','0.033086678153505','2941.979491526545','2941.979491526545189','test','test','1.00'),('2019-03-17 11:59:59','2019-03-17 15:59:59','VIBEBTC','4h','0.000011300000000','0.000011187000000','0.033346618385911','0.033013152202052','2951.028175744346','2951.028175744345845','test','test','1.00'),('2019-03-18 11:59:59','2019-03-20 23:59:59','VIBEBTC','4h','0.000011110000000','0.000010998900000','0.033272514789498','0.032939789641603','2994.8258136361833','2994.825813636183284','test','test','0.99'),('2019-03-26 15:59:59','2019-03-26 19:59:59','VIBEBTC','4h','0.000010900000000','0.000011170000000','0.033198575867744','0.034020925912174','3045.740905297573','3045.740905297573136','test','test','0.0'),('2019-03-27 11:59:59','2019-03-27 15:59:59','VIBEBTC','4h','0.000011580000000','0.000011464200000','0.033381320322061','0.033047507118840','2882.67014870996','2882.670148709959903','test','test','0.99'),('2019-03-31 07:59:59','2019-03-31 11:59:59','VIBEBTC','4h','0.000011880000000','0.000011761200000','0.033307139610234','0.032974068214132','2803.6312803227643','2803.631280322764269','test','test','0.99'),('2019-03-31 15:59:59','2019-03-31 19:59:59','VIBEBTC','4h','0.000012210000000','0.000012087900000','0.033233123744434','0.032900792506990','2721.795556464701','2721.795556464700894','test','test','1.00'),('2019-05-06 11:59:59','2019-05-06 23:59:59','VIBEBTC','4h','0.000007120000000','0.000007060000000','0.033159272358335','0.032879840287900','4657.201173923501','4657.201173923501301','test','test','0.84'),('2019-05-16 07:59:59','2019-05-16 11:59:59','VIBEBTC','4h','0.000006150000000','0.000006088500000','0.033097176342683','0.032766204579256','5381.654689867172','5381.654689867172237','test','test','1.00'),('2019-05-16 15:59:59','2019-05-16 19:59:59','VIBEBTC','4h','0.000005810000000','0.000005751900000','0.033023627061922','0.032693390791303','5683.9289263204055','5683.928926320405481','test','test','1.00'),('2019-05-21 19:59:59','2019-05-21 23:59:59','VIBEBTC','4h','0.000005500000000','0.000005680000000','0.032950241224006','0.034028612754973','5990.9529498193115','5990.952949819311470','test','test','0.0'),('2019-05-22 15:59:59','2019-05-22 23:59:59','VIBEBTC','4h','0.000005930000000','0.000005870700000','0.033189879341999','0.032857980548579','5596.944239797452','5596.944239797451701','test','test','1.00'),('2019-05-23 07:59:59','2019-05-24 15:59:59','VIBEBTC','4h','0.000006080000000','0.000006019200000','0.033116124054572','0.032784962814026','5446.730930028325','5446.730930028325020','test','test','1.00'),('2019-05-28 11:59:59','2019-05-28 15:59:59','VIBEBTC','4h','0.000005760000000','0.000005702400000','0.033042532667784','0.032712107341106','5736.550810379204','5736.550810379204449','test','test','1.00'),('2019-05-29 19:59:59','2019-05-30 15:59:59','VIBEBTC','4h','0.000005940000000','0.000005880600000','0.032969104817411','0.032639413769237','5550.354346365544','5550.354346365544188','test','test','0.99'),('2019-05-30 19:59:59','2019-05-30 23:59:59','VIBEBTC','4h','0.000005800000000','0.000005742000000','0.032895840140039','0.032566881738639','5671.696575868849','5671.696575868849322','test','test','1.00'),('2019-05-31 19:59:59','2019-06-01 03:59:59','VIBEBTC','4h','0.000005990000000','0.000005930100000','0.032822738273062','0.032494510890331','5479.589027222296','5479.589027222295954','test','test','1.00'),('2019-06-03 11:59:59','2019-06-03 19:59:59','VIBEBTC','4h','0.000005950000000','0.000005890500000','0.032749798854677','0.032422300866130','5504.167874735612','5504.167874735611804','test','test','1.00'),('2019-06-07 11:59:59','2019-06-09 15:59:59','VIBEBTC','4h','0.000005910000000','0.000005930000000','0.032677021523889','0.032787603661026','5529.106856833952','5529.106856833952406','test','test','0.16'),('2019-06-10 07:59:59','2019-06-12 15:59:59','VIBEBTC','4h','0.000006000000000','0.000006010000000','0.032701595332141','0.032756097991028','5450.265888690221','5450.265888690220891','test','test','0.0'),('2019-07-05 19:59:59','2019-07-06 07:59:59','VIBEBTC','4h','0.000003380000000','0.000003346200000','0.032713707034116','0.032386569963775','9678.611548555096','9678.611548555096306','test','test','1.0'),('2019-07-06 11:59:59','2019-07-06 15:59:59','VIBEBTC','4h','0.000003480000000','0.000003445200000','0.032641009907374','0.032314599808300','9379.60054809591','9379.600548095910199','test','test','1.00'),('2019-07-26 07:59:59','2019-07-27 03:59:59','VIBEBTC','4h','0.000002190000000','0.000002168100000','0.032568474329802','0.032242789586504','14871.44946566291','14871.449465662910370','test','test','1.00'),('2019-07-28 03:59:59','2019-07-28 07:59:59','VIBEBTC','4h','0.000002210000000','0.000002200000000','0.032496099942402','0.032349058766192','14704.11762099648','14704.117620996479673','test','test','0.45'),('2019-07-28 19:59:59','2019-07-28 23:59:59','VIBEBTC','4h','0.000002230000000','0.000002240000000','0.032463424125467','0.032609000018406','14557.589293931243','14557.589293931243446','test','test','0.0'),('2019-07-29 07:59:59','2019-07-31 15:59:59','VIBEBTC','4h','0.000002280000000','0.000002257200000','0.032495774323898','0.032170816580659','14252.53259820068','14252.532598200679786','test','test','1.00'),('2019-08-14 07:59:59','2019-08-14 11:59:59','VIBEBTC','4h','0.000001590000000','0.000001600000000','0.032423561492067','0.032627483262457','20392.177039035636','20392.177039035635971','test','test','0.0'),('2019-08-19 03:59:59','2019-08-19 07:59:59','VIBEBTC','4h','0.000001510000000','0.000001494900000','0.032468877441042','0.032144188666632','21502.567841749817','21502.567841749816580','test','test','1.00'),('2019-08-21 19:59:59','2019-08-21 23:59:59','VIBEBTC','4h','0.000001510000000','0.000001500000000','0.032396724380062','0.032182176536485','21454.784357657096','21454.784357657095825','test','test','0.66'),('2019-08-22 15:59:59','2019-08-22 19:59:59','VIBEBTC','4h','0.000001570000000','0.000001554300000','0.032349047081490','0.032025556610675','20604.48858693602','20604.488586936018692','test','test','0.99'),('2019-08-24 07:59:59','2019-08-24 15:59:59','VIBEBTC','4h','0.000001640000000','0.000001623600000','0.032277160310197','0.031954388707095','19681.19531109593','19681.195311095929355','test','test','0.99'),('2019-08-24 23:59:59','2019-08-25 07:59:59','VIBEBTC','4h','0.000001790000000','0.000001772100000','0.032205433287286','0.031883378954413','17991.86217166803','17991.862171668031806','test','test','1.00'),('2019-08-25 15:59:59','2019-08-25 23:59:59','VIBEBTC','4h','0.000001890000000','0.000001871100000','0.032133865657758','0.031812527001180','17002.045321565314','17002.045321565314225','test','test','0.99'),('2019-08-26 07:59:59','2019-08-26 15:59:59','VIBEBTC','4h','0.000001870000000','0.000001851300000','0.032062457067408','0.031741832496734','17145.698966528216','17145.698966528216260','test','test','0.99'),('2019-08-29 19:59:59','2019-08-29 23:59:59','VIBEBTC','4h','0.000001660000000','0.000001650000000','0.031991207162814','0.031798489047375','19271.811543863583','19271.811543863583211','test','test','0.60'),('2019-09-01 11:59:59','2019-09-02 03:59:59','VIBEBTC','4h','0.000001650000000','0.000001633500000','0.031948380914938','0.031628897105789','19362.655099962558','19362.655099962557870','test','test','0.99'),('2019-09-09 19:59:59','2019-09-12 03:59:59','VIBEBTC','4h','0.000001490000000','0.000001490000000','0.031877384512905','0.031877384512905','21394.21779389605','21394.217793896048533','test','test','0.0'),('2019-09-14 19:59:59','2019-09-24 03:59:59','VIBEBTC','4h','0.000001560000000','0.000001740000000','0.031877384512905','0.035555544264394','20434.22084160584','20434.220841605838359','test','test','0.0'),('2019-09-24 11:59:59','2019-09-24 15:59:59','VIBEBTC','4h','0.000001810000000','0.000001791900000','0.032694753346569','0.032367805813103','18063.39963898858','18063.399638988579682','test','test','1.00'),('2019-09-26 07:59:59','2019-09-26 11:59:59','VIBEBTC','4h','0.000001760000000','0.000001760000000','0.032622098339132','0.032622098339132','18535.283147234342','18535.283147234342323','test','test','0.0'),('2019-09-27 15:59:59','2019-10-09 15:59:59','VIBEBTC','4h','0.000001900000000','0.000002700000000','0.032622098339132','0.046357718692451','17169.525441648657','17169.525441648656852','test','test','0.0'),('2019-10-16 03:59:59','2019-10-16 07:59:59','VIBEBTC','4h','0.000002540000000','0.000002514600000','0.035674458417648','0.035317713833472','14045.062369152669','14045.062369152668907','test','test','1.00'),('2019-10-23 11:59:59','2019-10-23 15:59:59','VIBEBTC','4h','0.000002470000000','0.000002445300000','0.035595181843386','0.035239230024952','14411.004794893295','14411.004794893295184','test','test','0.99'),('2019-11-08 03:59:59','2019-11-08 07:59:59','VIBEBTC','4h','0.000002100000000','0.000002079000000','0.035516081439290','0.035160920624897','16912.419732995237','16912.419732995236700','test','test','0.99'),('2019-11-09 11:59:59','2019-11-09 15:59:59','VIBEBTC','4h','0.000002110000000','0.000002090000000','0.035437156813869','0.035101259592884','16794.86104922717','16794.861049227169133','test','test','0.94'),('2019-11-09 19:59:59','2019-11-09 23:59:59','VIBEBTC','4h','0.000002100000000','0.000002120000000','0.035362512986984','0.035699298824955','16839.2918985637','16839.291898563700670','test','test','0.0'),('2019-11-13 15:59:59','2019-11-13 19:59:59','VIBEBTC','4h','0.000002110000000','0.000002100000000','0.035437354284311','0.035269404737940','16794.954637114057','16794.954637114056823','test','test','0.47'),('2019-11-16 19:59:59','2019-11-16 23:59:59','VIBEBTC','4h','0.000002100000000','0.000002110000000','0.035400032162895','0.035568603744623','16857.15817280709','16857.158172807088704','test','test','0.0'),('2019-11-17 15:59:59','2019-11-17 19:59:59','VIBEBTC','4h','0.000002120000000','0.000002098800000','0.035437492514390','0.035083117589246','16715.798355844337','16715.798355844337493','test','test','0.99'),('2019-11-18 03:59:59','2019-11-18 19:59:59','VIBEBTC','4h','0.000002110000000','0.000002130000000','0.035358742531025','0.035693896488665','16757.697882002212','16757.697882002212282','test','test','0.0'),('2019-11-19 07:59:59','2019-11-20 19:59:59','VIBEBTC','4h','0.000002190000000','0.000002168100000','0.035433221188278','0.035078888976395','16179.553054008216','16179.553054008216350','test','test','1.00'),('2019-11-26 15:59:59','2019-11-27 11:59:59','VIBEBTC','4h','0.000002090000000','0.000002069100000','0.035354480696748','0.035000935889781','16916.01947212844','16916.019472128438792','test','test','1.00'),('2019-11-29 15:59:59','2019-12-03 23:59:59','VIBEBTC','4h','0.000002080000000','0.000002080000000','0.035275915184089','0.035275915184089','16959.57460773515','16959.574607735150494','test','test','0.96'),('2019-12-04 15:59:59','2019-12-04 19:59:59','VIBEBTC','4h','0.000002070000000','0.000002090000000','0.035275915184089','0.035616745282486','17041.50491984981','17041.504919849809085','test','test','0.0'),('2019-12-08 11:59:59','2019-12-08 23:59:59','VIBEBTC','4h','0.000002080000000','0.000002070000000','0.035351655205955','0.035181695325157','16995.98807978611','16995.988079786111484','test','test','0.48'),('2019-12-09 15:59:59','2019-12-09 19:59:59','VIBEBTC','4h','0.000002060000000','0.000002060000000','0.035313886343556','0.035313886343556','17142.663273570655','17142.663273570655292','test','test','0.0'),('2019-12-15 11:59:59','2019-12-15 15:59:59','VIBEBTC','4h','0.000002000000000','0.000001980000000','0.035313886343556','0.034960747480120','17656.943171777777','17656.943171777777025','test','test','0.99'),('2019-12-30 11:59:59','2019-12-30 15:59:59','VIBEBTC','4h','0.000001750000000','0.000001732500000','0.035235411040570','0.034883056930164','20134.520594611302','20134.520594611301931','test','test','1.00');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:47:42
