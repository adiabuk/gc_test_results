-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-05-03 03:59:59','2019-05-03 11:59:59','BCHABCUSDT','4h','272.220000000000027','289.709999999999980','222.222222222222200','236.499889795018674','0.8163331945566901','0.816333194556690','test','test','0.0'),('2019-05-03 15:59:59','2019-05-04 11:59:59','BCHABCUSDT','4h','290.589999999999975','287.684100000000001','225.395037238399226','223.141086866015257','0.7756462274627456','0.775646227462746','test','test','0.99'),('2019-05-04 23:59:59','2019-05-06 03:59:59','BCHABCUSDT','4h','290.629999999999995','287.723700000000008','224.894159377869443','222.645217784090732','0.7738160526369248','0.773816052636925','test','test','0.99'),('2019-05-07 03:59:59','2019-05-07 11:59:59','BCHABCUSDT','4h','296.720000000000027','293.752800000000036','224.394394579251951','222.150450633459428','0.7562496447130356','0.756249644713036','test','test','0.99'),('2019-05-10 07:59:59','2019-05-10 11:59:59','BCHABCUSDT','4h','292.420000000000016','289.495800000000031','223.895740369075838','221.656782965385105','0.7656649352611854','0.765664935261185','test','test','0.99'),('2019-05-10 19:59:59','2019-05-17 11:59:59','BCHABCUSDT','4h','288.199999999999989','351.100000000000023','223.398194279366777','272.155121483295204','0.7751498760560958','0.775149876056096','test','test','0.41'),('2019-05-19 03:59:59','2019-05-23 07:59:59','BCHABCUSDT','4h','390.639999999999986','386.733599999999967','234.233066991350853','231.890736321437345','0.5996136263346069','0.599613626334607','test','test','1.00'),('2019-05-23 11:59:59','2019-05-26 11:59:59','BCHABCUSDT','4h','382.800000000000011','393.449999999999989','233.712549064703438','240.214739888995751','0.6105343496988073','0.610534349698807','test','test','0.0'),('2019-05-26 15:59:59','2019-05-30 23:59:59','BCHABCUSDT','4h','403.379999999999995','420.990000000000009','235.157480358990597','245.423540225919623','0.582967624470699','0.582967624470699','test','test','0.0'),('2019-05-31 15:59:59','2019-06-03 07:59:59','BCHABCUSDT','4h','427.250000000000000','425.300000000000011','237.438826996085936','236.355138961814760','0.5557374534724071','0.555737453472407','test','test','0.45'),('2019-06-13 07:59:59','2019-06-13 11:59:59','BCHABCUSDT','4h','400.759999999999991','398.670000000000016','237.198007432914579','235.960998161692913','0.5918704646993577','0.591870464699358','test','test','0.52'),('2019-06-13 15:59:59','2019-06-13 23:59:59','BCHABCUSDT','4h','417.519999999999982','413.344799999999964','236.923116483754228','234.553885318916684','0.5674533351306625','0.567453335130663','test','test','1.00'),('2019-06-14 15:59:59','2019-06-14 19:59:59','BCHABCUSDT','4h','409.310000000000002','405.216900000000010','236.396620669345907','234.032654462652459','0.5775490964534116','0.577549096453412','test','test','0.99'),('2019-06-14 23:59:59','2019-06-18 07:59:59','BCHABCUSDT','4h','419.769999999999982','415.870000000000005','235.871294845636243','233.679861322759507','0.5619060315068639','0.561906031506864','test','test','0.92'),('2019-06-21 03:59:59','2019-06-26 23:59:59','BCHABCUSDT','4h','422.740000000000009','488.550000000000011','235.384309618330263','272.027734456250300','0.5568063339601889','0.556806333960189','test','test','0.0'),('2019-07-09 03:59:59','2019-07-09 11:59:59','BCHABCUSDT','4h','423.000000000000000','418.769999999999982','243.527292915645830','241.092019986489362','0.5757146404625197','0.575714640462520','test','test','1.00'),('2019-07-10 03:59:59','2019-07-10 07:59:59','BCHABCUSDT','4h','417.930000000000007','414.240000000000009','242.986121153611037','240.840740857731760','0.5814038742220253','0.581403874222025','test','test','0.88'),('2019-07-20 19:59:59','2019-07-20 23:59:59','BCHABCUSDT','4h','334.230000000000018','330.887699999999995','242.509369976748985','240.084276276981456','0.7255763096572688','0.725576309657269','test','test','1.00'),('2019-07-26 19:59:59','2019-07-26 23:59:59','BCHABCUSDT','4h','319.560000000000002','317.160000000000025','241.970460265689525','240.153183057535642','0.7571988367307846','0.757198836730785','test','test','0.75'),('2019-07-27 03:59:59','2019-07-27 07:59:59','BCHABCUSDT','4h','320.790000000000020','318.850000000000023','241.566620886099798','240.105729821792835','0.7530366310860681','0.753036631086068','test','test','0.60'),('2019-07-30 15:59:59','2019-08-07 19:59:59','BCHABCUSDT','4h','319.509999999999991','336.759999999999991','241.241978427364899','254.266372430281990','0.755037333502441','0.755037333502441','test','test','0.42'),('2019-08-11 19:59:59','2019-08-12 11:59:59','BCHABCUSDT','4h','338.730000000000018','335.342700000000036','244.136288205790947','241.694925323733059','0.720740082678803','0.720740082678803','test','test','0.99'),('2019-08-13 11:59:59','2019-08-14 19:59:59','BCHABCUSDT','4h','339.509999999999991','336.114899999999977','243.593763120889179','241.157825489680278','0.7174862688017708','0.717486268801771','test','test','1.00'),('2019-08-19 07:59:59','2019-08-19 11:59:59','BCHABCUSDT','4h','322.800000000000011','323.000000000000000','243.052443647287220','243.203033761071140','0.7529505689197249','0.752950568919725','test','test','0.0'),('2019-08-19 15:59:59','2019-08-19 19:59:59','BCHABCUSDT','4h','323.639999999999986','320.540000000000020','243.085908117016970','240.757499035436382','0.7510997037356847','0.751099703735685','test','test','0.95'),('2019-09-03 03:59:59','2019-09-03 11:59:59','BCHABCUSDT','4h','296.120000000000005','296.379999999999995','242.568483876665738','242.781464444705477','0.8191560309221455','0.819156030922146','test','test','0.48'),('2019-09-03 15:59:59','2019-09-04 11:59:59','BCHABCUSDT','4h','301.129999999999995','298.118699999999990','242.615812891785680','240.189654762867832','0.8056846308630349','0.805684630863035','test','test','1.00'),('2019-09-06 11:59:59','2019-09-06 19:59:59','BCHABCUSDT','4h','299.000000000000000','296.009999999999991','242.076666640915050','239.655899974505900','0.8096209586652677','0.809620958665268','test','test','1.00'),('2019-09-07 15:59:59','2019-09-07 19:59:59','BCHABCUSDT','4h','298.930000000000007','299.160000000000025','241.538718492824074','241.724561015332199','0.8080109674265683','0.808010967426568','test','test','0.0'),('2019-09-08 03:59:59','2019-09-08 07:59:59','BCHABCUSDT','4h','309.209999999999980','306.117899999999963','241.580016831159242','239.164216662847650','0.7812813842733394','0.781281384273339','test','test','1.00'),('2019-09-08 15:59:59','2019-09-08 19:59:59','BCHABCUSDT','4h','305.680000000000007','302.623199999999997','241.043172349312243','238.632740625819110','0.7885474101979594','0.788547410197959','test','test','1.00'),('2019-09-09 11:59:59','2019-09-09 15:59:59','BCHABCUSDT','4h','309.389999999999986','306.296099999999967','240.507520855202642','238.102445646650608','0.7773603570096081','0.777360357009608','test','test','1.00'),('2019-09-12 15:59:59','2019-09-12 19:59:59','BCHABCUSDT','4h','299.290000000000020','299.829999999999984','239.973059697746635','240.406035915584738','0.8018078108114091','0.801807810811409','test','test','0.0'),('2019-09-14 15:59:59','2019-09-16 15:59:59','BCHABCUSDT','4h','303.959999999999980','300.920399999999972','240.069276635043963','237.668583868693531','0.7898054896533885','0.789805489653388','test','test','1.00'),('2019-09-16 23:59:59','2019-09-19 03:59:59','BCHABCUSDT','4h','307.430000000000007','310.240000000000009','239.535789353632794','241.725216436492985','0.7791555455018468','0.779155545501847','test','test','0.61'),('2019-09-19 19:59:59','2019-09-20 19:59:59','BCHABCUSDT','4h','320.029999999999973','316.829699999999946','240.022328705379522','237.622105418325702','0.7499994647544903','0.749999464754490','test','test','1.00'),('2019-10-07 15:59:59','2019-10-08 11:59:59','BCHABCUSDT','4h','233.599999999999994','233.139999999999986','239.488945752700857','239.017349369797415','1.0252095280509455','1.025209528050945','test','test','0.37'),('2019-10-09 15:59:59','2019-10-10 11:59:59','BCHABCUSDT','4h','237.879999999999995','235.501199999999983','239.384146556500127','236.990305090935124','1.0063231316483106','1.006323131648311','test','test','1.00'),('2019-10-20 19:59:59','2019-10-23 03:59:59','BCHABCUSDT','4h','225.120000000000005','222.868799999999993','238.852181786374530','236.463659968510768','1.060999386044663','1.060999386044663','test','test','1.00'),('2019-10-25 15:59:59','2019-11-08 15:59:59','BCHABCUSDT','4h','235.370000000000005','279.550000000000011','238.321399160182608','283.055389961460889','1.0125394024734784','1.012539402473478','test','test','0.0'),('2019-11-10 19:59:59','2019-11-11 07:59:59','BCHABCUSDT','4h','293.430000000000007','290.495699999999999','248.262286004911090','245.779663144861985','0.8460698838050339','0.846069883805034','test','test','1.00'),('2019-11-12 07:59:59','2019-11-12 15:59:59','BCHABCUSDT','4h','290.189999999999998','287.288099999999986','247.710592036011320','245.233486115651203','0.8536151901719953','0.853615190171995','test','test','1.00');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 19:54:14
