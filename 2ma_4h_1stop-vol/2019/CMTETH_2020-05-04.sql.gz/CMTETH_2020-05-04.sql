-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-11 15:59:59','CMTETH','4h','0.000183550000000','0.000181860000000','1.297777777777778','1.285828747843458','7070.431913798844','7070.431913798844107','test','test','0.92'),('2019-01-13 07:59:59','2019-01-14 15:59:59','CMTETH','4h','0.000189330000000','0.000187436700000','1.295122437792373','1.282171213414449','6840.555843196395','6840.555843196394562','test','test','1.00'),('2019-01-15 23:59:59','2019-01-27 19:59:59','CMTETH','4h','0.000187730000000','0.000227580000000','1.292244387930612','1.566552910058322','6883.526276730478','6883.526276730477548','test','test','0.67'),('2019-02-05 23:59:59','2019-02-06 03:59:59','CMTETH','4h','0.000215820000000','0.000213661800000','1.353201837292326','1.339669818919403','6270.04836109872','6270.048361098720306','test','test','1.00'),('2019-02-07 19:59:59','2019-02-07 23:59:59','CMTETH','4h','0.000216230000000','0.000215410000000','1.350194722098343','1.345074435033085','6244.252518606775','6244.252518606775084','test','test','0.37'),('2019-02-08 07:59:59','2019-02-08 11:59:59','CMTETH','4h','0.000214390000000','0.000216070000000','1.349056880528286','1.359628341693861','6292.536408080067','6292.536408080067304','test','test','0.0'),('2019-02-10 07:59:59','2019-02-10 15:59:59','CMTETH','4h','0.000220300000000','0.000218097000000','1.351406094120635','1.337892033179429','6134.389896144509','6134.389896144509294','test','test','0.99'),('2019-02-11 03:59:59','2019-02-11 11:59:59','CMTETH','4h','0.000216880000000','0.000214711200000','1.348402969467034','1.334918939772364','6217.276694333429','6217.276694333429077','test','test','1.00'),('2019-02-16 03:59:59','2019-02-16 07:59:59','CMTETH','4h','0.000213290000000','0.000211157100000','1.345406518423774','1.331952453239536','6307.874342087177','6307.874342087176956','test','test','0.99'),('2019-02-16 19:59:59','2019-02-17 11:59:59','CMTETH','4h','0.000210590000000','0.000208484100000','1.342416726160610','1.328992558899004','6374.5511475407675','6374.551147540767488','test','test','1.00'),('2019-02-25 15:59:59','2019-02-25 19:59:59','CMTETH','4h','0.000193790000000','0.000191852100000','1.339433577880253','1.326039242101450','6911.778615409739','6911.778615409739359','test','test','1.00'),('2019-02-26 03:59:59','2019-03-05 15:59:59','CMTETH','4h','0.000201420000000','0.000205520000000','1.336457058818297','1.363661278563878','6635.1755477027955','6635.175547702795484','test','test','0.93'),('2019-03-08 03:59:59','2019-03-16 03:59:59','CMTETH','4h','0.000212910000000','0.000237970000000','1.342502440983982','1.500518086895675','6305.4926540978895','6305.492654097889499','test','test','0.42'),('2019-03-17 15:59:59','2019-03-18 15:59:59','CMTETH','4h','0.000239420000000','0.000239550000000','1.377617028964358','1.378365045895965','5753.97639697752','5753.976396977520380','test','test','0.93'),('2019-03-19 11:59:59','2019-03-21 15:59:59','CMTETH','4h','0.000242390000000','0.000241470000000','1.377783254949160','1.372553828840190','5684.158814097775','5684.158814097774666','test','test','0.37'),('2019-03-21 19:59:59','2019-03-21 23:59:59','CMTETH','4h','0.000244590000000','0.000242790000000','1.376621160258277','1.366490255117164','5628.2806339518265','5628.280633951826530','test','test','0.73'),('2019-03-22 03:59:59','2019-03-22 07:59:59','CMTETH','4h','0.000243920000000','0.000242340000000','1.374369848004696','1.365467321111258','5634.510692049427','5634.510692049427234','test','test','0.64'),('2019-03-23 07:59:59','2019-03-24 07:59:59','CMTETH','4h','0.000247080000000','0.000244609200000','1.372391508695044','1.358667593608093','5554.441916363298','5554.441916363298333','test','test','1.00'),('2019-03-25 03:59:59','2019-03-25 07:59:59','CMTETH','4h','0.000244010000000','0.000241569900000','1.369341749786832','1.355648332288964','5611.8263587018255','5611.826358701825484','test','test','0.99'),('2019-03-27 15:59:59','2019-03-27 19:59:59','CMTETH','4h','0.000243660000000','0.000241223400000','1.366298768120640','1.352635780439434','5607.398703606006','5607.398703606006166','test','test','0.99'),('2019-03-28 07:59:59','2019-03-29 15:59:59','CMTETH','4h','0.000242980000000','0.000241030000000','1.363262548635927','1.352321886977189','5610.595722429529','5610.595722429528905','test','test','0.80'),('2019-03-30 15:59:59','2019-04-03 03:59:59','CMTETH','4h','0.000252750000000','0.000250222500000','1.360831290489541','1.347222977584646','5384.100061284039','5384.100061284038929','test','test','1.00'),('2019-04-03 07:59:59','2019-04-07 23:59:59','CMTETH','4h','0.000261660000000','0.000275150000000','1.357807220955120','1.427809588190022','5189.20439102316','5189.204391023159587','test','test','0.0'),('2019-05-24 11:59:59','2019-05-24 15:59:59','CMTETH','4h','0.000165310000000','0.000163656900000','1.373363302562876','1.359629669537247','8307.805350933855','8307.805350933855152','test','test','1.00'),('2019-05-24 19:59:59','2019-05-25 03:59:59','CMTETH','4h','0.000169570000000','0.000167874300000','1.370311384112736','1.356608270271608','8081.095618993547','8081.095618993546850','test','test','1.00'),('2019-05-26 15:59:59','2019-05-26 19:59:59','CMTETH','4h','0.000168090000000','0.000166409100000','1.367266247703596','1.353593585226560','8134.131998950539','8134.131998950539128','test','test','1.00'),('2019-05-27 15:59:59','2019-05-27 19:59:59','CMTETH','4h','0.000165250000000','0.000164360000000','1.364227878264255','1.356880448239110','8255.53935409534','8255.539354095339149','test','test','0.53'),('2019-06-08 11:59:59','2019-06-09 15:59:59','CMTETH','4h','0.000148210000000','0.000149640000000','1.362595116036445','1.375742076537977','9193.678672400278','9193.678672400277719','test','test','0.0'),('2019-06-10 07:59:59','2019-06-10 11:59:59','CMTETH','4h','0.000153230000000','0.000151697700000','1.365516662814563','1.351861496186417','8911.54906228913','8911.549062289130234','test','test','0.99'),('2019-06-10 15:59:59','2019-06-10 19:59:59','CMTETH','4h','0.000159200000000','0.000157608000000','1.362482181341642','1.348857359528225','8558.305159181167','8558.305159181167255','test','test','0.99'),('2019-06-13 19:59:59','2019-06-14 19:59:59','CMTETH','4h','0.000167940000000','0.000166260600000','1.359454443160883','1.345859898729274','8094.881762301314','8094.881762301313756','test','test','1.00'),('2019-06-15 07:59:59','2019-06-16 15:59:59','CMTETH','4h','0.000202500000000','0.000200475000000','1.356433433287192','1.342869098954320','6698.43670759107','6698.436707591070444','test','test','1.00'),('2019-06-18 19:59:59','2019-06-19 03:59:59','CMTETH','4h','0.000182500000000','0.000180675000000','1.353419136768776','1.339884945401088','7415.995269965895','7415.995269965895204','test','test','1.00'),('2019-07-03 07:59:59','2019-07-07 19:59:59','CMTETH','4h','0.000153910000000','0.000180160000000','1.350411538687067','1.580729925345085','8774.033777448298','8774.033777448297769','test','test','0.0'),('2019-07-09 15:59:59','2019-07-09 19:59:59','CMTETH','4h','0.000233600000000','0.000231264000000','1.401593402388849','1.387577468364960','5999.97175680158','5999.971756801580341','test','test','0.99'),('2019-07-10 03:59:59','2019-07-10 07:59:59','CMTETH','4h','0.000216970000000','0.000214800300000','1.398478750383540','1.384493962879705','6445.493618396738','6445.493618396738384','test','test','0.99'),('2019-07-10 11:59:59','2019-07-10 15:59:59','CMTETH','4h','0.000203530000000','0.000201494700000','1.395371019827133','1.381417309628862','6855.849357967536','6855.849357967535980','test','test','0.99'),('2019-07-10 19:59:59','2019-07-10 23:59:59','CMTETH','4h','0.000204770000000','0.000202722300000','1.392270195338628','1.378347493385242','6799.190288316784','6799.190288316784063','test','test','0.99'),('2019-07-14 11:59:59','2019-07-15 07:59:59','CMTETH','4h','0.000219900000000','0.000217701000000','1.389176261571209','1.375284498955497','6317.309056713091','6317.309056713091195','test','test','1.00'),('2019-07-15 15:59:59','2019-07-15 19:59:59','CMTETH','4h','0.000223040000000','0.000220809600000','1.386089203212162','1.372228311180040','6214.531936926836','6214.531936926836352','test','test','1.00'),('2019-07-15 23:59:59','2019-07-16 03:59:59','CMTETH','4h','0.000234450000000','0.000232105500000','1.383009004982801','1.369178914932973','5898.950757017707','5898.950757017706565','test','test','0.99'),('2019-07-19 15:59:59','2019-07-19 19:59:59','CMTETH','4h','0.000208700000000','0.000206613000000','1.379935651638395','1.366136295122011','6612.053912977456','6612.053912977456093','test','test','1.00'),('2019-07-23 03:59:59','2019-07-23 07:59:59','CMTETH','4h','0.000208660000000','0.000206573400000','1.376869127968088','1.363100436688407','6598.6251699802915','6598.625169980291503','test','test','1.00'),('2019-07-28 19:59:59','2019-07-28 23:59:59','CMTETH','4h','0.000203240000000','0.000201207600000','1.373809418794825','1.360071324606877','6759.542505386858','6759.542505386857556','test','test','1.00'),('2019-08-19 11:59:59','2019-08-19 23:59:59','CMTETH','4h','0.000170960000000','0.000169250400000','1.370756508975281','1.357048943885528','8017.99549002855','8017.995490028550194','test','test','1.00'),('2019-08-20 03:59:59','2019-08-20 07:59:59','CMTETH','4h','0.000178060000000','0.000176279400000','1.367710383399780','1.354033279565782','7681.177038075819','7681.177038075818928','test','test','1.00'),('2019-08-25 07:59:59','2019-08-25 15:59:59','CMTETH','4h','0.000166610000000','0.000164943900000','1.364671026992225','1.351024316722303','8190.81103770617','8190.811037706170282','test','test','1.00'),('2019-09-22 03:59:59','2019-09-22 07:59:59','CMTETH','4h','0.000113060000000','0.000112630000000','1.361638424710020','1.356459718513086','12043.502783566428','12043.502783566427752','test','test','0.38'),('2019-10-03 03:59:59','2019-10-03 07:59:59','CMTETH','4h','0.000106100000000','0.000105039000000','1.360487601110702','1.346882725099595','12822.691810656943','12822.691810656942835','test','test','0.99'),('2019-10-03 15:59:59','2019-10-05 15:59:59','CMTETH','4h','0.000103630000000','0.000103080000000','1.357464295330456','1.350259766116602','13099.144025190155','13099.144025190154935','test','test','0.53'),('2019-10-08 19:59:59','2019-10-09 03:59:59','CMTETH','4h','0.000104310000000','0.000103266900000','1.355863288838488','1.342304655950103','12998.4017720112','12998.401772011200592','test','test','1.00'),('2019-10-09 07:59:59','2019-10-09 15:59:59','CMTETH','4h','0.000104130000000','0.000103088700000','1.352850259307736','1.339321756714659','12991.935650703315','12991.935650703315332','test','test','0.99'),('2019-10-22 11:59:59','2019-10-23 03:59:59','CMTETH','4h','0.000095550000000','0.000096390000000','1.349843925398163','1.361710685181883','14127.094980619184','14127.094980619183843','test','test','0.0'),('2019-10-23 07:59:59','2019-10-23 15:59:59','CMTETH','4h','0.000097750000000','0.000096772500000','1.352480983127879','1.338956173296600','13836.122589543516','13836.122589543516369','test','test','0.99'),('2019-10-27 15:59:59','2019-10-28 11:59:59','CMTETH','4h','0.000099330000000','0.000098336700000','1.349475469832039','1.335980715133719','13585.77942043732','13585.779420437320368','test','test','1.00'),('2019-10-29 11:59:59','2019-10-29 19:59:59','CMTETH','4h','0.000108680000000','0.000107593200000','1.346476635454635','1.333011869100089','12389.369115335248','12389.369115335248352','test','test','0.99'),('2019-10-30 03:59:59','2019-10-30 07:59:59','CMTETH','4h','0.000118940000000','0.000117750600000','1.343484465153624','1.330049620502088','11295.480621772527','11295.480621772527229','test','test','1.00'),('2019-10-30 11:59:59','2019-10-30 15:59:59','CMTETH','4h','0.000117660000000','0.000116483400000','1.340498944119950','1.327093954678750','11392.987796361971','11392.987796361971050','test','test','1.00'),('2019-11-05 03:59:59','2019-11-05 11:59:59','CMTETH','4h','0.000117800000000','0.000116622000000','1.337520057577461','1.324144857001686','11354.160081302723','11354.160081302723484','test','test','0.99'),('2019-11-14 11:59:59','2019-11-14 15:59:59','CMTETH','4h','0.000106670000000','0.000111490000000','1.334547790782844','1.394850784610287','12510.99457000885','12510.994570008850133','test','test','0.0'),('2019-11-14 19:59:59','2019-11-15 03:59:59','CMTETH','4h','0.000111390000000','0.000110276100000','1.347948456077831','1.334468971517053','12101.162187609583','12101.162187609583270','test','test','0.99'),('2019-11-15 07:59:59','2019-11-15 15:59:59','CMTETH','4h','0.000116030000000','0.000114869700000','1.344953015064325','1.331503484913682','11591.4247613921','11591.424761392099754','test','test','1.00'),('2019-11-28 15:59:59','2019-11-28 19:59:59','CMTETH','4h','0.000102160000000','0.000101138400000','1.341964230586405','1.328544588280541','13135.906720696994','13135.906720696993943','test','test','1.00'),('2019-11-29 11:59:59','2019-11-29 15:59:59','CMTETH','4h','0.000100180000000','0.000099178200000','1.338982087851768','1.325592266973250','13365.76250600687','13365.762506006869444','test','test','1.00'),('2019-12-04 15:59:59','2019-12-04 19:59:59','CMTETH','4h','0.000098250000000','0.000097267500000','1.336006572100986','1.322646506379976','13598.031268203424','13598.031268203423679','test','test','1.00'),('2019-12-19 15:59:59','2019-12-19 19:59:59','CMTETH','4h','0.000091710000000','0.000090792900000','1.333037668607429','1.319707291921355','14535.357852005545','14535.357852005545283','test','test','0.99'),('2019-12-27 03:59:59','2019-12-27 11:59:59','CMTETH','4h','0.000094120000000','0.000093178800000','1.330075362677190','1.316774609050418','14131.697436009243','14131.697436009242665','test','test','1.00'),('2019-12-27 15:59:59','2019-12-27 19:59:59','CMTETH','4h','0.000091650000000','0.000090733500000','1.327119639649019','1.313848443252529','14480.301578276252','14480.301578276252258','test','test','0.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:22:00
