-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-10 11:59:59','ADAUSDT','4h','0.041980000000000','0.045670000000000','222.222222222222200','241.755333227462785','5293.526017680376','5293.526017680375844','test','test','0.59'),('2019-01-16 15:59:59','2019-01-17 11:59:59','ADAUSDT','4h','0.044130000000000','0.044340000000000','226.562913556720133','227.641051146724919','5133.988523832317','5133.988523832316787','test','test','0.0'),('2019-01-19 11:59:59','2019-01-20 07:59:59','ADAUSDT','4h','0.045440000000000','0.044985600000000','226.802499687832295','224.534474690953971','4991.252193834337','4991.252193834337049','test','test','1.00'),('2019-02-08 15:59:59','2019-02-14 11:59:59','ADAUSDT','4h','0.039880000000000','0.040140000000000','226.298494132970490','227.773860443767234','5674.485810756532','5674.485810756532373','test','test','0.0'),('2019-02-16 15:59:59','2019-02-17 15:59:59','ADAUSDT','4h','0.041200000000000','0.040788000000000','226.626353313147519','224.360089780016040','5500.639643522998','5500.639643522998085','test','test','1.00'),('2019-02-17 19:59:59','2019-02-24 15:59:59','ADAUSDT','4h','0.040930000000000','0.042700000000000','226.122739194673841','235.901318436661938','5524.62104067124','5524.621040671239825','test','test','0.0'),('2019-03-05 19:59:59','2019-03-05 23:59:59','ADAUSDT','4h','0.043160000000000','0.042920000000000','228.295756804004526','227.026271594714444','5289.521705375453','5289.521705375453166','test','test','0.55'),('2019-03-06 11:59:59','2019-03-06 15:59:59','ADAUSDT','4h','0.042840000000000','0.042540000000000','228.013648979717829','226.416914743165165','5322.447455175486','5322.447455175485629','test','test','0.70'),('2019-03-07 03:59:59','2019-03-07 07:59:59','ADAUSDT','4h','0.043000000000000','0.042640000000000','227.658819149372789','225.752838337889671','5294.39114300867','5294.391143008670042','test','test','0.83'),('2019-03-07 19:59:59','2019-03-07 23:59:59','ADAUSDT','4h','0.043120000000000','0.042750000000000','227.235267857932143','225.285429056739332','5269.834597818463','5269.834597818463408','test','test','0.85'),('2019-03-08 15:59:59','2019-03-08 23:59:59','ADAUSDT','4h','0.043070000000000','0.042639300000000','226.801970346555919','224.533950643090350','5265.8920442664485','5265.892044266448465','test','test','0.99'),('2019-03-09 07:59:59','2019-04-09 07:59:59','ADAUSDT','4h','0.044010000000000','0.082850000000000','226.297965968008043','426.011962745954690','5141.9669613271535','5141.966961327153513','test','test','0.0'),('2019-04-09 15:59:59','2019-04-09 23:59:59','ADAUSDT','4h','0.083750000000000','0.082912500000000','270.678854140885051','267.972065599476196','3231.9863181001197','3231.986318100119661','test','test','1.00'),('2019-04-10 15:59:59','2019-04-11 03:59:59','ADAUSDT','4h','0.088030000000000','0.087149700000000','270.077345576127584','267.376572120366291','3068.014831036324','3068.014831036323812','test','test','1.00'),('2019-04-14 23:59:59','2019-04-15 11:59:59','ADAUSDT','4h','0.084160000000000','0.083318400000000','269.477173697069531','266.782401960098809','3201.962615221834','3201.962615221833858','test','test','0.99'),('2019-04-15 15:59:59','2019-04-15 19:59:59','ADAUSDT','4h','0.082850000000000','0.082021500000000','268.878335533298184','266.189552177965254','3245.3631325684755','3245.363132568475521','test','test','0.99'),('2019-04-18 03:59:59','2019-04-18 11:59:59','ADAUSDT','4h','0.082840000000000','0.082011600000000','268.280828121002003','265.598019839791959','3238.5421067238294','3238.542106723829420','test','test','1.00'),('2019-05-11 11:59:59','2019-05-12 15:59:59','ADAUSDT','4h','0.069500000000000','0.069000000000000','267.684648502955326','265.758859664804561','3851.577676301515','3851.577676301515112','test','test','0.71'),('2019-05-13 15:59:59','2019-05-13 23:59:59','ADAUSDT','4h','0.074770000000000','0.074022300000000','267.256695427810712','264.584128473532587','3574.3840501245245','3574.384050124524492','test','test','1.00'),('2019-05-14 03:59:59','2019-05-17 15:59:59','ADAUSDT','4h','0.077880000000000','0.077640000000000','266.662791660193363','265.841026508698121','3424.0214645633455','3424.021464563345489','test','test','0.56'),('2019-05-19 03:59:59','2019-05-20 07:59:59','ADAUSDT','4h','0.084370000000000','0.083526300000000','266.480177182083310','263.815375410262448','3158.470750054324','3158.470750054324071','test','test','1.00'),('2019-05-20 19:59:59','2019-05-22 11:59:59','ADAUSDT','4h','0.083790000000000','0.082952100000000','265.887999010567569','263.229119020461894','3173.2664877738102','3173.266487773810240','test','test','1.00'),('2019-05-24 11:59:59','2019-05-24 23:59:59','ADAUSDT','4h','0.082200000000000','0.081378000000000','265.297136790544016','262.644165422638594','3227.4590850431146','3227.459085043114555','test','test','1.00'),('2019-05-26 19:59:59','2019-05-30 23:59:59','ADAUSDT','4h','0.082760000000000','0.083920000000000','264.707587597676195','268.417843779567249','3198.4967085267785','3198.496708526778548','test','test','0.0'),('2019-06-01 23:59:59','2019-06-03 23:59:59','ADAUSDT','4h','0.090470000000000','0.089565300000000','265.532088971429744','262.876768081715454','2935.0291695747733','2935.029169574773277','test','test','0.99'),('2019-06-10 23:59:59','2019-06-11 03:59:59','ADAUSDT','4h','0.085080000000000','0.084229200000000','264.942017662604371','262.292597485978320','3114.0340580936104','3114.034058093610383','test','test','0.99'),('2019-06-11 19:59:59','2019-06-11 23:59:59','ADAUSDT','4h','0.088420000000000','0.087535800000000','264.353257623354125','261.709725047120571','2989.745053419522','2989.745053419521810','test','test','1.00'),('2019-06-12 03:59:59','2019-06-14 15:59:59','ADAUSDT','4h','0.087610000000000','0.086733900000000','263.765805939746656','261.128147880349161','3010.6814968581975','3010.681496858197534','test','test','1.00'),('2019-06-16 07:59:59','2019-06-16 11:59:59','ADAUSDT','4h','0.092570000000000','0.091644300000000','263.179659704325047','260.547863107281785','2843.034025108837','2843.034025108836886','test','test','1.00'),('2019-06-21 07:59:59','2019-06-21 11:59:59','ADAUSDT','4h','0.089430000000000','0.089960000000000','262.594816016093148','264.151063947307819','2936.3168513484643','2936.316851348464297','test','test','0.0'),('2019-06-22 03:59:59','2019-06-22 15:59:59','ADAUSDT','4h','0.090650000000000','0.093460000000000','262.940648889696433','271.091373913193934','2900.613887365653','2900.613887365653227','test','test','0.79'),('2019-06-22 19:59:59','2019-06-27 07:59:59','ADAUSDT','4h','0.095450000000000','0.094495500000000','264.751921117140341','262.104401905968928','2773.723636638453','2773.723636638453172','test','test','0.99'),('2019-07-20 19:59:59','2019-07-20 23:59:59','ADAUSDT','4h','0.064740000000000','0.064092600000000','264.163583514657773','261.521947679511186','4080.376637544914','4080.376637544914047','test','test','1.00'),('2019-07-26 11:59:59','2019-07-26 15:59:59','ADAUSDT','4h','0.061410000000000','0.061230000000000','263.576553329069668','262.803979162008432','4292.0787058959395','4292.078705895939493','test','test','0.29'),('2019-07-26 19:59:59','2019-07-27 07:59:59','ADAUSDT','4h','0.062500000000000','0.061875000000000','263.404870180833825','260.770821479025471','4214.477922893341','4214.477922893341201','test','test','1.00'),('2019-07-29 15:59:59','2019-07-29 19:59:59','ADAUSDT','4h','0.061570000000000','0.060954300000000','262.819526024876438','260.191330764627651','4268.629625221316','4268.629625221316019','test','test','1.00'),('2019-07-31 03:59:59','2019-07-31 07:59:59','ADAUSDT','4h','0.060490000000000','0.060100000000000','262.235482633710035','260.544759568291852','4335.187347226153','4335.187347226153179','test','test','0.64'),('2019-08-11 19:59:59','2019-08-11 23:59:59','ADAUSDT','4h','0.055350000000000','0.054796500000000','261.859766396950420','259.241168732980896','4730.980422709131','4730.980422709130835','test','test','0.99'),('2019-08-24 19:59:59','2019-08-25 19:59:59','ADAUSDT','4h','0.050280000000000','0.049780000000000','261.277855804957198','258.679627326387617','5196.456957139165','5196.456957139164842','test','test','0.99'),('2019-09-07 23:59:59','2019-09-09 03:59:59','ADAUSDT','4h','0.045970000000000','0.045700000000000','260.700471698608396','259.169274671011578','5671.10010221032','5671.100102210320074','test','test','0.58'),('2019-09-09 11:59:59','2019-09-10 19:59:59','ADAUSDT','4h','0.046180000000000','0.045970000000000','260.360205692475745','259.176237671786680','5637.9429556621','5637.942955662099848','test','test','0.45'),('2019-09-14 19:59:59','2019-09-15 03:59:59','ADAUSDT','4h','0.046780000000000','0.046312200000000','260.097101687878251','257.496130670999491','5560.006449078201','5560.006449078200603','test','test','0.99'),('2019-09-15 11:59:59','2019-09-16 15:59:59','ADAUSDT','4h','0.046600000000000','0.046134000000000','259.519108128571759','256.923917047286011','5569.079573574501','5569.079573574501410','test','test','1.00'),('2019-09-16 23:59:59','2019-09-22 07:59:59','ADAUSDT','4h','0.047020000000000','0.049490000000000','258.942398999397199','272.544860197366404','5507.069310918699','5507.069310918698648','test','test','0.0'),('2019-10-07 15:59:59','2019-10-08 11:59:59','ADAUSDT','4h','0.041240000000000','0.040827600000000','261.965168154501441','259.345516472956433','6352.21067299955','6352.210672999550297','test','test','1.00'),('2019-10-09 07:59:59','2019-10-10 11:59:59','ADAUSDT','4h','0.042040000000000','0.041619600000000','261.383023336380404','258.769193103016619','6217.483904290685','6217.483904290685132','test','test','1.00'),('2019-10-11 15:59:59','2019-10-11 19:59:59','ADAUSDT','4h','0.040920000000000','0.040510800000000','260.802172173410611','258.194150451676478','6373.464618118539','6373.464618118538965','test','test','0.99'),('2019-10-14 03:59:59','2019-10-14 19:59:59','ADAUSDT','4h','0.041400000000000','0.041580000000000','260.222611790803057','261.354014450763088','6285.570333111185','6285.570333111185391','test','test','0.43'),('2019-10-14 23:59:59','2019-10-15 07:59:59','ADAUSDT','4h','0.041730000000000','0.041312700000000','260.474034604127496','257.869294258086200','6241.889158977414','6241.889158977413899','test','test','1.00'),('2019-10-22 03:59:59','2019-10-22 07:59:59','ADAUSDT','4h','0.039840000000000','0.039510000000000','259.895203416118306','257.742457002279991','6523.47398132827','6523.473981328270384','test','test','0.82'),('2019-10-25 15:59:59','2019-10-31 11:59:59','ADAUSDT','4h','0.040070000000000','0.041020000000000','259.416815324154243','265.567201512273698','6474.090724336267','6474.090724336267158','test','test','0.99'),('2019-11-01 03:59:59','2019-11-01 15:59:59','ADAUSDT','4h','0.041760000000000','0.041342400000000','260.783567810403042','258.175732132299061','6244.817236839153','6244.817236839153338','test','test','0.99'),('2019-11-04 11:59:59','2019-11-08 11:59:59','ADAUSDT','4h','0.042430000000000','0.042570000000000','260.204048770824386','261.062605613339485','6132.54887510781','6132.548875107810090','test','test','0.0'),('2019-11-10 19:59:59','2019-11-11 11:59:59','ADAUSDT','4h','0.043470000000000','0.043035300000000','260.394839180272186','257.790890788469426','5990.2194428404','5990.219442840400006','test','test','1.00'),('2019-11-12 03:59:59','2019-11-13 07:59:59','ADAUSDT','4h','0.043740000000000','0.043302600000000','259.816183982093776','257.218022142272844','5940.013351213849','5940.013351213849091','test','test','0.99'),('2019-11-13 11:59:59','2019-11-14 07:59:59','ADAUSDT','4h','0.043510000000000','0.043074900000000','259.238814684355759','256.646426537512184','5958.143293136193','5958.143293136193279','test','test','1.00'),('2019-11-15 11:59:59','2019-11-15 15:59:59','ADAUSDT','4h','0.043380000000000','0.042946200000000','258.662728429501669','256.076101145206678','5962.718497683302','5962.718497683302303','test','test','0.99'),('2019-11-15 23:59:59','2019-11-17 07:59:59','ADAUSDT','4h','0.043880000000000','0.043441200000000','258.087922366324960','255.507043142661672','5881.675532505126','5881.675532505126284','test','test','1.00'),('2019-11-17 11:59:59','2019-11-18 19:59:59','ADAUSDT','4h','0.043830000000000','0.043391700000000','257.514393649955366','254.939249713455808','5875.299877936467','5875.299877936467055','test','test','1.00'),('2019-11-27 19:59:59','2019-11-28 03:59:59','ADAUSDT','4h','0.039340000000000','0.038946600000000','256.942139441844290','254.372718047425849','6531.320270509515','6531.320270509514557','test','test','1.00'),('2019-11-29 03:59:59','2019-11-30 11:59:59','ADAUSDT','4h','0.041070000000000','0.040659300000000','256.371156909751335','253.807445340653828','6242.297465540572','6242.297465540572375','test','test','0.99'),('2019-12-07 19:59:59','2019-12-07 23:59:59','ADAUSDT','4h','0.038890000000000','0.038501100000000','255.801443227729692','253.243428795452417','6577.563466899709','6577.563466899709056','test','test','0.99'),('2019-12-08 11:59:59','2019-12-09 03:59:59','ADAUSDT','4h','0.038620000000000','0.038400000000000','255.232995576112558','253.779053084482655','6608.8295074084035','6608.829507408403515','test','test','0.56'),('2019-12-26 19:59:59','2019-12-26 23:59:59','ADAUSDT','4h','0.034420000000000','0.034160000000000','254.909897244639211','252.984372163767489','7405.86569566064','7405.865695660640085','test','test','0.75');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:05:54
