-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 19:59:59','2019-01-02 23:59:59','MDABTC','4h','0.000224100000000','0.000223340000000','0.033333333333333','0.033220288561654','148.74312063067083','148.743120630670830','test','test','0.33'),('2019-01-03 15:59:59','2019-01-03 19:59:59','MDABTC','4h','0.000225740000000','0.000223482600000','0.033308212272960','0.032975130150230','147.551219424826','147.551219424826002','test','test','1.00'),('2019-01-05 15:59:59','2019-01-05 19:59:59','MDABTC','4h','0.000225110000000','0.000222858900000','0.033234194023465','0.032901852083230','147.63535171011802','147.635351710118016','test','test','0.99'),('2019-01-17 07:59:59','2019-01-17 11:59:59','MDABTC','4h','0.000211360000000','0.000209246400000','0.033160340258968','0.032828736856378','156.89033052123392','156.890330521233921','test','test','0.99'),('2019-01-17 15:59:59','2019-01-18 03:59:59','MDABTC','4h','0.000206400000000','0.000204336000000','0.033086650613948','0.032755784107809','160.30353979625968','160.303539796259685','test','test','0.99'),('2019-01-19 19:59:59','2019-01-19 23:59:59','MDABTC','4h','0.000201460000000','0.000199445400000','0.033013124723695','0.032682993476458','163.8693771651687','163.869377165168686','test','test','1.00'),('2019-01-23 11:59:59','2019-01-23 15:59:59','MDABTC','4h','0.000203190000000','0.000201158100000','0.032939762224309','0.032610364602066','162.11310706387562','162.113107063875617','test','test','1.00'),('2019-01-23 19:59:59','2019-01-23 23:59:59','MDABTC','4h','0.000200400000000','0.000201290000000','0.032866562752699','0.033012527028397','164.00480415518626','164.004804155186264','test','test','0.0'),('2019-01-24 15:59:59','2019-01-24 19:59:59','MDABTC','4h','0.000200030000000','0.000199290000000','0.032898999258410','0.032777291217360','164.47032574318854','164.470325743188539','test','test','0.36'),('2019-01-25 19:59:59','2019-01-25 23:59:59','MDABTC','4h','0.000201260000000','0.000199247400000','0.032871953027066','0.032543233496795','163.3307812136816','163.330781213681604','test','test','1.00'),('2019-01-26 07:59:59','2019-01-26 19:59:59','MDABTC','4h','0.000205880000000','0.000203821200000','0.032798904242561','0.032470915200135','159.31078415854324','159.310784158543242','test','test','1.00'),('2019-01-27 07:59:59','2019-01-28 11:59:59','MDABTC','4h','0.000207390000000','0.000205316100000','0.032726017788688','0.032398757610801','157.79940107376655','157.799401073766546','test','test','1.00'),('2019-01-31 15:59:59','2019-02-05 15:59:59','MDABTC','4h','0.000207030000000','0.000209070000000','0.032653293304714','0.032975047245407','157.7225199474161','157.722519947416089','test','test','0.53'),('2019-02-14 19:59:59','2019-02-14 23:59:59','MDABTC','4h','0.000209920000000','0.000207820800000','0.032724794180423','0.032397546238619','155.89174056985095','155.891740569850953','test','test','0.99'),('2019-02-18 03:59:59','2019-02-18 11:59:59','MDABTC','4h','0.000203080000000','0.000201049200000','0.032652072415578','0.032325551691422','160.7842841027072','160.784284102707204','test','test','1.00'),('2019-02-20 15:59:59','2019-02-20 23:59:59','MDABTC','4h','0.000202610000000','0.000203410000000','0.032579512254654','0.032708151560728','160.79913259293332','160.799132592933319','test','test','0.0'),('2019-02-21 15:59:59','2019-02-21 19:59:59','MDABTC','4h','0.000200540000000','0.000198720000000','0.032608098767115','0.032312164091957','162.60146986693482','162.601469866934821','test','test','0.90'),('2019-02-23 03:59:59','2019-02-24 19:59:59','MDABTC','4h','0.000207080000000','0.000207280000000','0.032542335505969','0.032573765229270','157.14861650554806','157.148616505548063','test','test','0.0'),('2019-02-24 23:59:59','2019-03-02 11:59:59','MDABTC','4h','0.000217700000000','0.000227270000000','0.032549319888925','0.033980174235903','149.51456081269941','149.514560812699415','test','test','0.0'),('2019-03-07 19:59:59','2019-03-07 23:59:59','MDABTC','4h','0.000230410000000','0.000228105900000','0.032867287521586','0.032538614646370','142.6469663711924','142.646966371192406','test','test','0.99'),('2019-03-08 07:59:59','2019-03-08 23:59:59','MDABTC','4h','0.000225470000000','0.000223215300000','0.032794249104872','0.032466306613823','145.44839271243083','145.448392712430831','test','test','1.00'),('2019-03-09 19:59:59','2019-03-09 23:59:59','MDABTC','4h','0.000240210000000','0.000237807900000','0.032721372995750','0.032394159265793','136.21986176990873','136.219861769908732','test','test','1.00'),('2019-03-10 03:59:59','2019-03-10 07:59:59','MDABTC','4h','0.000258000000000','0.000255420000000','0.032648658833537','0.032322172245202','126.54518927727561','126.545189277275611','test','test','1.00'),('2019-03-10 15:59:59','2019-03-12 19:59:59','MDABTC','4h','0.000251890000000','0.000253770000000','0.032576106258352','0.032819240482679','129.32671506749594','129.326715067495940','test','test','0.0'),('2019-03-12 23:59:59','2019-03-13 03:59:59','MDABTC','4h','0.000281530000000','0.000278714700000','0.032630136085980','0.032303834725120','115.90287388903413','115.902873889034126','test','test','1.00'),('2019-03-13 07:59:59','2019-03-14 11:59:59','MDABTC','4h','0.000297500000000','0.000294525000000','0.032557624672455','0.032232048425730','109.43739385699271','109.437393856992713','test','test','1.00'),('2019-03-18 11:59:59','2019-03-18 19:59:59','MDABTC','4h','0.000279460000000','0.000276665400000','0.032485274395405','0.032160421651451','116.24302009377134','116.243020093771335','test','test','1.00'),('2019-03-22 19:59:59','2019-03-28 03:59:59','MDABTC','4h','0.000262010000000','0.000279870000000','0.032413084896749','0.034622533758456','123.70934276076825','123.709342760768251','test','test','0.0'),('2019-03-29 15:59:59','2019-04-02 07:59:59','MDABTC','4h','0.000291830000000','0.000288911700000','0.032904073532684','0.032575032797357','112.75082593524922','112.750825935249225','test','test','1.00'),('2019-05-22 19:59:59','2019-05-22 23:59:59','MDABTC','4h','0.000129390000000','0.000128096100000','0.032830953369278','0.032502643835585','253.73640443061888','253.736404430618876','test','test','1.00'),('2019-05-23 11:59:59','2019-05-23 15:59:59','MDABTC','4h','0.000127800000000','0.000130970000000','0.032757995695124','0.033570537528876','256.32234503226744','256.322345032267435','test','test','0.0'),('2019-05-30 07:59:59','2019-05-30 11:59:59','MDABTC','4h','0.000121100000000','0.000119889000000','0.032938560547069','0.032609174941598','271.9947196289733','271.994719628973314','test','test','0.99'),('2019-06-01 19:59:59','2019-06-01 23:59:59','MDABTC','4h','0.000119600000000','0.000118404000000','0.032865363745853','0.032536710108394','274.79401125295067','274.794011252950668','test','test','1.00'),('2019-06-02 11:59:59','2019-06-02 15:59:59','MDABTC','4h','0.000119510000000','0.000123930000000','0.032792329604195','0.034005132690552','274.3898385423424','274.389838542342375','test','test','0.0'),('2019-06-02 19:59:59','2019-06-03 03:59:59','MDABTC','4h','0.000122400000000','0.000121176000000','0.033061841401164','0.032731222987152','270.11308334283945','270.113083342839445','test','test','1.00'),('2019-06-05 19:59:59','2019-06-06 11:59:59','MDABTC','4h','0.000126160000000','0.000124898400000','0.032988370642494','0.032658486936069','261.48042677944056','261.480426779440563','test','test','1.00'),('2019-06-08 19:59:59','2019-06-08 23:59:59','MDABTC','4h','0.000129410000000','0.000128115900000','0.032915063152178','0.032585912520656','254.3471381823472','254.347138182347209','test','test','0.99'),('2019-06-09 03:59:59','2019-06-12 15:59:59','MDABTC','4h','0.000127500000000','0.000126300000000','0.032841918567395','0.032532818157349','257.5836750383912','257.583675038391220','test','test','0.94'),('2019-07-08 11:59:59','2019-07-08 15:59:59','MDABTC','4h','0.000079550000000','0.000078754500000','0.032773229587385','0.032445497291511','411.9827729400964','411.982772940096424','test','test','1.00'),('2019-07-23 19:59:59','2019-07-23 23:59:59','MDABTC','4h','0.000070100000000','0.000069399000000','0.032700400188302','0.032373396186419','466.48217101714056','466.482171017140558','test','test','1.00'),('2019-07-24 11:59:59','2019-07-24 19:59:59','MDABTC','4h','0.000069800000000','0.000069102000000','0.032627732632328','0.032301455306005','467.4460262511111','467.446026251111107','test','test','0.99'),('2019-07-26 19:59:59','2019-07-26 23:59:59','MDABTC','4h','0.000073690000000','0.000072953100000','0.032555226559811','0.032229674294213','441.78622010871675','441.786220108716748','test','test','0.99'),('2019-07-28 19:59:59','2019-07-29 03:59:59','MDABTC','4h','0.000069590000000','0.000068894100000','0.032482881611901','0.032158052795782','466.775134529396','466.775134529395984','test','test','1.00'),('2019-07-29 19:59:59','2019-07-29 23:59:59','MDABTC','4h','0.000067030000000','0.000067020000000','0.032410697430541','0.032405862178052','483.52524885187063','483.525248851870629','test','test','0.01'),('2019-07-30 19:59:59','2019-07-31 03:59:59','MDABTC','4h','0.000069960000000','0.000069260400000','0.032409622929988','0.032085526700688','463.2593329043421','463.259332904342102','test','test','1.00'),('2019-07-31 19:59:59','2019-07-31 23:59:59','MDABTC','4h','0.000067390000000','0.000066716100000','0.032337601545699','0.032014225530242','479.8575685665363','479.857568566536315','test','test','1.00'),('2019-08-01 23:59:59','2019-08-02 03:59:59','MDABTC','4h','0.000067680000000','0.000068940000000','0.032265740208931','0.032866432180906','476.7396602974388','476.739660297438775','test','test','0.0'),('2019-08-03 15:59:59','2019-08-03 23:59:59','MDABTC','4h','0.000068000000000','0.000067500000000','0.032399227313814','0.032160997701212','476.459225203147','476.459225203147014','test','test','0.73'),('2019-08-15 11:59:59','2019-08-15 15:59:59','MDABTC','4h','0.000060510000000','0.000059904900000','0.032346287399902','0.032022824525903','534.561021317178','534.561021317177961','test','test','0.99'),('2019-08-20 19:59:59','2019-08-20 23:59:59','MDABTC','4h','0.000064940000000','0.000064290600000','0.032274406761236','0.031951662693624','496.9880930279642','496.988093027964226','test','test','1.00'),('2019-08-21 07:59:59','2019-08-22 03:59:59','MDABTC','4h','0.000064720000000','0.000064072800000','0.032202685857322','0.031880658998749','497.5693117633222','497.569311763322219','test','test','0.99'),('2019-08-22 23:59:59','2019-08-23 03:59:59','MDABTC','4h','0.000064820000000','0.000064171800000','0.032131124333195','0.031809813089863','495.69769103972357','495.697691039723566','test','test','0.99'),('2019-08-25 19:59:59','2019-08-25 23:59:59','MDABTC','4h','0.000066610000000','0.000065943900000','0.032059721834677','0.031739124616330','481.3049367163588','481.304936716358782','test','test','1.00'),('2019-08-26 15:59:59','2019-08-28 07:59:59','MDABTC','4h','0.000064200000000','0.000063558000000','0.031988478008377','0.031668593228293','498.2628973267496','498.262897326749624','test','test','0.99'),('2019-09-01 19:59:59','2019-09-01 23:59:59','MDABTC','4h','0.000062290000000','0.000061667100000','0.031917392501692','0.031598218576675','512.3999438383687','512.399943838368699','test','test','1.00'),('2019-09-09 19:59:59','2019-09-12 23:59:59','MDABTC','4h','0.000061770000000','0.000061152300000','0.031846464962799','0.031528000313171','515.5652414246289','515.565241424628880','test','test','1.00'),('2019-09-17 11:59:59','2019-09-17 15:59:59','MDABTC','4h','0.000063310000000','0.000062676900000','0.031775695040660','0.031457938090253','501.906413531192','501.906413531192015','test','test','0.99'),('2019-09-18 07:59:59','2019-09-18 11:59:59','MDABTC','4h','0.000063800000000','0.000063162000000','0.031705082385014','0.031388031561164','496.9448649688679','496.944864968867876','test','test','1.00'),('2019-09-18 15:59:59','2019-09-18 19:59:59','MDABTC','4h','0.000063550000000','0.000064130000000','0.031634626646380','0.031923345504836','497.79113526955837','497.791135269558367','test','test','0.0'),('2019-09-24 19:59:59','2019-09-24 23:59:59','MDABTC','4h','0.000063670000000','0.000063033300000','0.031698786392704','0.031381798528777','497.86063126596497','497.860631265964969','test','test','1.00'),('2019-09-25 03:59:59','2019-10-07 23:59:59','MDABTC','4h','0.000064500000000','0.000111790000000','0.031628344645165','0.054817560432295','490.36193248317295','490.361932483172950','test','test','0.0'),('2019-10-09 11:59:59','2019-10-09 15:59:59','MDABTC','4h','0.000120840000000','0.000119631600000','0.036781503708971','0.036413688671881','304.381857902775','304.381857902774982','test','test','1.00'),('2019-10-11 15:59:59','2019-10-15 19:59:59','MDABTC','4h','0.000114160000000','0.000113018400000','0.036699767034062','0.036332769363721','321.47658579241795','321.476585792417950','test','test','0.99'),('2019-11-06 19:59:59','2019-11-06 23:59:59','MDABTC','4h','0.000082730000000','0.000081902700000','0.036618211996209','0.036252029876247','442.62313545520226','442.623135455202259','test','test','1.00'),('2019-11-09 11:59:59','2019-11-12 19:59:59','MDABTC','4h','0.000083070000000','0.000082239300000','0.036536838191773','0.036171469809855','439.8319271911987','439.831927191198702','test','test','0.99'),('2019-11-22 15:59:59','2019-11-22 19:59:59','MDABTC','4h','0.000080790000000','0.000079982100000','0.036455645218013','0.036091088765833','451.23957442769307','451.239574427693071','test','test','1.00'),('2019-11-23 19:59:59','2019-11-24 15:59:59','MDABTC','4h','0.000081070000000','0.000080259300000','0.036374632673084','0.036010886346353','448.6817894792702','448.681789479270208','test','test','0.99'),('2019-11-26 03:59:59','2019-11-26 07:59:59','MDABTC','4h','0.000082700000000','0.000081873000000','0.036293800156033','0.035930862154473','438.8609450548137','438.860945054813726','test','test','0.99'),('2019-11-26 15:59:59','2019-11-26 19:59:59','MDABTC','4h','0.000083150000000','0.000082318500000','0.036213147266798','0.035851015794130','435.5159021863806','435.515902186380572','test','test','1.00'),('2019-12-12 23:59:59','2019-12-13 15:59:59','MDABTC','4h','0.000075710000000','0.000074952900000','0.036132673606205','0.035771346870143','477.2510052331878','477.251005233187811','test','test','0.99'),('2019-12-17 19:59:59','2019-12-17 23:59:59','MDABTC','4h','0.000073280000000','0.000072547200000','0.036052378775969','0.035691854988209','491.98115141878617','491.981151418786169','test','test','0.99'),('2019-12-18 03:59:59','2019-12-18 11:59:59','MDABTC','4h','0.000073470000000','0.000072840000000','0.035972262378689','0.035663802799288','489.6183800012067','489.618380001206674','test','test','0.89'),('2019-12-26 11:59:59','2019-12-26 15:59:59','MDABTC','4h','0.000071990000000','0.000071270100000','0.035903715805488','0.035544678647433','498.7319878523189','498.731987852318923','test','test','0.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:24:39
