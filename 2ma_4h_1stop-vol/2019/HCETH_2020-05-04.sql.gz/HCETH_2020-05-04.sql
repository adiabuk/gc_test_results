-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-02-08 11:59:59','2019-02-08 15:59:59','HCETH','4h','0.009920000000000','0.009820800000000','1.297777777777778','1.284800000000000','130.82437275985663','130.824372759856630','test','test','1.00'),('2019-02-09 03:59:59','2019-02-09 07:59:59','HCETH','4h','0.009695000000000','0.009598050000000','1.294893827160494','1.281944888888889','133.56305592166','133.563055921660009','test','test','1.00'),('2019-02-10 11:59:59','2019-02-11 03:59:59','HCETH','4h','0.010156000000000','0.010054440000000','1.292016285322359','1.279096122469135','127.21704266663639','127.217042666636388','test','test','1.00'),('2019-02-15 11:59:59','2019-02-15 15:59:59','HCETH','4h','0.009391000000000','0.009297090000000','1.289145138021643','1.276253686641426','137.27453285290628','137.274532852906276','test','test','1.00'),('2019-02-16 03:59:59','2019-02-16 07:59:59','HCETH','4h','0.009208000000000','0.009301000000000','1.286280371048261','1.299271691042559','139.69161284190503','139.691612841905027','test','test','0.0'),('2019-02-26 15:59:59','2019-02-26 23:59:59','HCETH','4h','0.008514000000000','0.008428860000000','1.289167331046994','1.276275657736524','151.41735154416185','151.417351544161846','test','test','1.00'),('2019-03-02 07:59:59','2019-03-03 11:59:59','HCETH','4h','0.008581000000000','0.008495190000000','1.286302514755779','1.273439489608221','149.90123700684987','149.901237006849868','test','test','1.00'),('2019-03-04 03:59:59','2019-03-04 07:59:59','HCETH','4h','0.008737000000000','0.008649630000000','1.283444064722988','1.270609624075758','146.8975695001703','146.897569500170306','test','test','0.99'),('2019-03-08 11:59:59','2019-03-08 15:59:59','HCETH','4h','0.008718000000000','0.008630820000000','1.280591966801381','1.267786047133367','146.8905674238795','146.890567423879503','test','test','1.00'),('2019-03-08 19:59:59','2019-03-20 15:59:59','HCETH','4h','0.008910000000000','0.009494000000000','1.277746206875156','1.361495228739925','143.40585935748103','143.405859357481035','test','test','0.0'),('2019-03-21 03:59:59','2019-03-21 15:59:59','HCETH','4h','0.009750000000000','0.009652500000000','1.296357100622882','1.283393529616653','132.95970262798795','132.959702627987951','test','test','1.00'),('2019-03-23 03:59:59','2019-03-26 07:59:59','HCETH','4h','0.009724000000000','0.009745000000000','1.293476307065943','1.296269705096423','133.01895383236763','133.018953832367629','test','test','0.27'),('2019-03-26 19:59:59','2019-03-27 07:59:59','HCETH','4h','0.009958000000000','0.009858420000000','1.294097062183827','1.281156091561989','129.95551939986214','129.955519399862141','test','test','1.00'),('2019-03-31 15:59:59','2019-04-02 07:59:59','HCETH','4h','0.010000000000000','0.009921000000000','1.291221290934530','1.281020642736147','129.12212909345297','129.122129093452969','test','test','0.79'),('2019-04-04 07:59:59','2019-04-04 19:59:59','HCETH','4h','0.009988000000000','0.009962000000000','1.288954480223778','1.285599172205574','129.05030839244873','129.050308392448727','test','test','0.26'),('2019-04-07 03:59:59','2019-04-07 07:59:59','HCETH','4h','0.010152000000000','0.010050480000000','1.288208856219733','1.275326767657535','126.89212531715256','126.892125317152562','test','test','1.00'),('2019-05-30 15:59:59','2019-07-01 11:59:59','HCETH','4h','0.005353000000000','0.014674000000000','1.285346169872578','3.523476498544781','240.11697550393754','240.116975503937539','test','test','0.0'),('2019-07-01 23:59:59','2019-07-02 07:59:59','HCETH','4h','0.015223000000000','0.015070770000000','1.782708465133067','1.764881380481736','117.10625140465525','117.106251404655254','test','test','0.99'),('2019-07-02 11:59:59','2019-07-07 23:59:59','HCETH','4h','0.014893000000000','0.016214000000000','1.778746890766105','1.936520653117681','119.43509640543239','119.435096405432390','test','test','0.0'),('2019-07-08 11:59:59','2019-07-08 15:59:59','HCETH','4h','0.015966000000000','0.015806340000000','1.813807726844233','1.795669649575791','113.60439226131984','113.604392261319845','test','test','0.99'),('2019-07-21 03:59:59','2019-07-21 15:59:59','HCETH','4h','0.014486000000000','0.014341140000000','1.809777043006801','1.791679272576733','124.93283466842477','124.932834668424775','test','test','1.00'),('2019-07-24 07:59:59','2019-07-24 11:59:59','HCETH','4h','0.014361000000000','0.014217390000000','1.805755316244564','1.787697763082118','125.74022117154544','125.740221171545443','test','test','1.00'),('2019-07-24 15:59:59','2019-07-24 23:59:59','HCETH','4h','0.014612000000000','0.014465880000000','1.801742526652909','1.783725101386380','123.30567524315008','123.305675243150077','test','test','0.99'),('2019-07-27 03:59:59','2019-07-27 07:59:59','HCETH','4h','0.014144000000000','0.014002560000000','1.797738654371458','1.779761267827743','127.10256323327617','127.102563233276172','test','test','0.99'),('2019-08-17 11:59:59','2019-08-24 07:59:59','HCETH','4h','0.011182000000000','0.013333000000000','1.793743679583966','2.138793103192007','160.41349307672743','160.413493076727434','test','test','0.0'),('2019-08-25 03:59:59','2019-08-25 07:59:59','HCETH','4h','0.013227000000000','0.013094730000000','1.870421329274642','1.851717115981896','141.40933917552292','141.409339175522916','test','test','1.00'),('2019-08-25 11:59:59','2019-08-25 15:59:59','HCETH','4h','0.013438000000000','0.013303620000000','1.866264837431809','1.847602189057491','138.87965749604177','138.879657496041773','test','test','0.99'),('2019-08-28 15:59:59','2019-08-28 19:59:59','HCETH','4h','0.013314000000000','0.013402000000000','1.862117582237516','1.874425404622742','139.86161801393393','139.861618013933935','test','test','0.0'),('2019-08-28 23:59:59','2019-08-29 03:59:59','HCETH','4h','0.013284000000000','0.013151160000000','1.864852653878678','1.846204127339891','140.38336750065326','140.383367500653264','test','test','1.00'),('2019-08-30 11:59:59','2019-08-30 15:59:59','HCETH','4h','0.012866000000000','0.012767000000000','1.860708536870058','1.846390944366550','144.62214650008224','144.622146500082238','test','test','0.76'),('2019-09-08 07:59:59','2019-09-08 11:59:59','HCETH','4h','0.012761000000000','0.012633390000000','1.857526849647057','1.838951581150586','145.56279677510045','145.562796775100452','test','test','1.00'),('2019-10-27 11:59:59','2019-11-08 15:59:59','HCETH','4h','0.008467000000000','0.009677000000000','1.853399012203397','2.118264112565522','218.89677715878076','218.896777158780765','test','test','0.0'),('2019-11-10 19:59:59','2019-11-11 03:59:59','HCETH','4h','0.009965000000000','0.010089000000000','1.912257923394980','1.936053205131154','191.89743335624482','191.897433356244818','test','test','0.0'),('2019-11-11 23:59:59','2019-11-12 15:59:59','HCETH','4h','0.010182000000000','0.010080180000000','1.917545763780796','1.898370306142988','188.32702453160445','188.327024531604451','test','test','1.00'),('2019-11-15 11:59:59','2019-11-15 15:59:59','HCETH','4h','0.010042000000000','0.009941580000000','1.913284550972395','1.894151705462671','190.52823650392298','190.528236503922983','test','test','1.00'),('2019-11-29 11:59:59','2019-11-29 15:59:59','HCETH','4h','0.008554000000000','0.008598000000000','1.909032807525789','1.918852475930177','223.17428191790847','223.174281917908473','test','test','0.0'),('2019-12-05 11:59:59','2019-12-05 15:59:59','HCETH','4h','0.008421000000000','0.008336790000000','1.911214956060098','1.892102806499497','226.95819452085237','226.958194520852373','test','test','0.99'),('2019-12-07 15:59:59','2019-12-07 19:59:59','HCETH','4h','0.008386000000000','0.008407000000000','1.906967811713298','1.911743190206737','227.39897587804646','227.398975878046457','test','test','0.0'),('2019-12-13 11:59:59','2019-12-13 15:59:59','HCETH','4h','0.008245000000000','0.008598000000000','1.908029006934062','1.989719029911348','231.41649568636282','231.416495686362822','test','test','0.0'),('2019-12-16 19:59:59','2019-12-17 03:59:59','HCETH','4h','0.008456000000000','0.008371440000000','1.926182345373459','1.906920521919724','227.7888298691413','227.788829869141296','test','test','1.00'),('2019-12-17 15:59:59','2019-12-20 15:59:59','HCETH','4h','0.008321000000000','0.008647000000000','1.921901940161518','1.997198182499297','230.9700685207929','230.970068520792893','test','test','0.0'),('2019-12-22 11:59:59','2019-12-22 23:59:59','HCETH','4h','0.008563000000000','0.008603000000000','1.938634438458802','1.947690304106163','226.39664118402453','226.396641184024531','test','test','0.70'),('2019-12-23 23:59:59','2019-12-26 19:59:59','HCETH','4h','0.008588000000000','0.008658000000000','1.940646853047104','1.956464887480418','225.97192047590875','225.971920475908746','test','test','0.0'),('2019-12-27 11:59:59','2019-12-27 15:59:59','HCETH','4h','0.008984000000000','0.008894160000000','1.944161971810063','1.924720352091962','216.4027128016544','216.402712801654388','test','test','1.00'),('2020-01-07 11:59:59','2020-01-07 15:59:59','HCETH','4h','0.008624000000000','0.008537760000000','1.939841611872707','1.920443195753980','224.9352518405273','224.935251840527286','test','test','0.99'),('2020-01-11 15:59:59','2020-01-11 19:59:59','HCETH','4h','0.008593000000000','0.008507070000000','1.935530852735212','1.916175544207860','225.24506606949984','225.245066069499842','test','test','0.99'),('2020-01-15 03:59:59','2020-01-15 15:59:59','HCETH','4h','0.009394000000000','0.009300060000000','1.931229673062467','1.911917376331842','205.58118725382874','205.581187253828745','test','test','1.00'),('2020-01-15 23:59:59','2020-01-16 03:59:59','HCETH','4h','0.009470000000000','0.009375300000000','1.926938051566773','1.907668671051105','203.478146944749','203.478146944749000','test','test','0.99'),('2020-01-17 15:59:59','2020-01-18 15:59:59','HCETH','4h','0.009011000000000','0.008920890000000','1.922655967007736','1.903429407337659','213.3676580854218','213.367658085421795','test','test','1.00'),('2020-01-26 19:59:59','2020-01-26 23:59:59','HCETH','4h','0.008974000000000','0.008884260000000','1.918383398192163','1.899199564210241','213.77127236373562','213.771272363735619','test','test','0.99'),('2020-01-29 19:59:59','2020-01-30 07:59:59','HCETH','4h','0.008942000000000','0.008852580000000','1.914120323973958','1.894979120734218','214.059530750834','214.059530750834000','test','test','0.99'),('2020-01-30 19:59:59','2020-01-30 23:59:59','HCETH','4h','0.008997000000000','0.008965000000000','1.909866723254016','1.903073821715267','212.2781730859193','212.278173085919292','test','test','0.35'),('2020-01-31 03:59:59','2020-02-04 11:59:59','HCETH','4h','0.008997000000000','0.009051000000000','1.908357189578738','1.919811150703252','212.1103911947025','212.110391194702487','test','test','0.97');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:20:57
