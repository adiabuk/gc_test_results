-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 11:59:59','2019-01-30 15:59:59','BNBETH','4h','0.043388000000000','0.056441000000000','1.297777777777778','1.688205853128873','29.910984091863593','29.910984091863593','test','test','0.0'),('2019-02-01 07:59:59','2019-02-13 23:59:59','BNBETH','4h','0.061007000000000','0.073157000000000','1.384539572300243','1.660280975802267','22.694765720331162','22.694765720331162','test','test','0.0'),('2019-02-15 03:59:59','2019-02-16 11:59:59','BNBETH','4h','0.074730000000000','0.073982700000000','1.445815439745137','1.431357285347685','19.34718907728004','19.347189077280039','test','test','1.00'),('2019-02-19 19:59:59','2019-02-19 23:59:59','BNBETH','4h','0.074288000000000','0.073545120000000','1.442602516545704','1.428176491380247','19.419051751907492','19.419051751907492','test','test','1.00'),('2019-02-20 03:59:59','2019-02-20 07:59:59','BNBETH','4h','0.076302000000000','0.075538980000000','1.439396733175602','1.425002765843846','18.86446925605623','18.864469256056228','test','test','1.00'),('2019-02-20 11:59:59','2019-02-20 15:59:59','BNBETH','4h','0.075751000000000','0.074993490000000','1.436198073768545','1.421836093030860','18.959460254894925','18.959460254894925','test','test','1.00'),('2019-02-24 23:59:59','2019-02-25 03:59:59','BNBETH','4h','0.075142000000000','0.074390580000000','1.433006522493504','1.418676457268569','19.070646542459667','19.070646542459667','test','test','1.00'),('2019-02-25 11:59:59','2019-02-25 15:59:59','BNBETH','4h','0.072196000000000','0.071733000000000','1.429822063554630','1.420652474998120','19.80472690390922','19.804726903909220','test','test','0.64'),('2019-02-27 23:59:59','2019-02-28 03:59:59','BNBETH','4h','0.072951000000000','0.072221490000000','1.427784377208739','1.413506533436652','19.571827352726334','19.571827352726334','test','test','1.00'),('2019-02-28 11:59:59','2019-03-16 07:59:59','BNBETH','4h','0.075651000000000','0.108480000000000','1.424611523037164','2.042826373994680','18.831364067060107','18.831364067060107','test','test','0.72'),('2019-03-16 11:59:59','2019-03-19 15:59:59','BNBETH','4h','0.111620000000000','0.111646000000000','1.561992601027723','1.562356440909704','13.993841614654388','13.993841614654388','test','test','0.42'),('2019-03-24 11:59:59','2019-03-25 11:59:59','BNBETH','4h','0.124743000000000','0.123495570000000','1.562073454334830','1.546452719791482','12.5223335524625','12.522333552462500','test','test','1.00'),('2019-03-31 03:59:59','2019-04-02 23:59:59','BNBETH','4h','0.121413000000000','0.120740000000000','1.558602179991863','1.549962748735453','12.837193545928884','12.837193545928884','test','test','0.55'),('2019-04-04 19:59:59','2019-04-04 23:59:59','BNBETH','4h','0.122672000000000','0.121445280000000','1.556682306379328','1.541115483315535','12.689793158824571','12.689793158824571','test','test','1.00'),('2019-04-12 19:59:59','2019-04-13 03:59:59','BNBETH','4h','0.111895000000000','0.110776050000000','1.553223012365152','1.537690782241500','13.881076119264952','13.881076119264952','test','test','1.00'),('2019-04-13 11:59:59','2019-04-18 03:59:59','BNBETH','4h','0.111510000000000','0.113702000000000','1.549771405671007','1.580235928325754','13.89804865636272','13.898048656362720','test','test','0.0'),('2019-04-18 07:59:59','2019-04-24 07:59:59','BNBETH','4h','0.120381000000000','0.131157000000000','1.556541299594284','1.695876319609303','12.930124351802062','12.930124351802062','test','test','0.0'),('2019-04-24 11:59:59','2019-04-30 03:59:59','BNBETH','4h','0.134610000000000','0.138262000000000','1.587504637375399','1.630574000243648','11.793363326464597','11.793363326464597','test','test','0.0'),('2019-04-30 15:59:59','2019-04-30 19:59:59','BNBETH','4h','0.138448000000000','0.139236000000000','1.597075606901677','1.606165630435701','11.535562860436242','11.535562860436242','test','test','0.0'),('2019-05-02 11:59:59','2019-05-03 11:59:59','BNBETH','4h','0.141443000000000','0.140481000000000','1.599095612131460','1.588219641041547','11.305583253547082','11.305583253547082','test','test','0.68'),('2019-05-03 23:59:59','2019-05-04 03:59:59','BNBETH','4h','0.140953000000000','0.139561000000000','1.596678729667035','1.580910517626876','11.327738534596886','11.327738534596886','test','test','0.98'),('2019-05-18 19:59:59','2019-05-19 03:59:59','BNBETH','4h','0.116093000000000','0.114932070000000','1.593174682546999','1.577242935721529','13.723262234131251','13.723262234131251','test','test','1.00'),('2019-05-20 23:59:59','2019-05-21 03:59:59','BNBETH','4h','0.116999000000000','0.115829010000000','1.589634294363562','1.573737951419926','13.586734026475114','13.586734026475114','test','test','0.99'),('2019-05-21 15:59:59','2019-05-26 23:59:59','BNBETH','4h','0.124170000000000','0.125118000000000','1.586101773709420','1.598211175992391','12.77363110018056','12.773631100180561','test','test','0.57'),('2019-05-27 03:59:59','2019-05-27 15:59:59','BNBETH','4h','0.128441000000000','0.127156590000000','1.588792751994525','1.572904824474580','12.369825460674747','12.369825460674747','test','test','1.00'),('2019-06-01 23:59:59','2019-06-02 03:59:59','BNBETH','4h','0.125969000000000','0.124709310000000','1.585262101434537','1.569409480420191','12.584541446185469','12.584541446185469','test','test','1.00'),('2019-06-04 11:59:59','2019-06-04 15:59:59','BNBETH','4h','0.124561000000000','0.123617000000000','1.581739296764683','1.569751901864627','12.698511546669364','12.698511546669364','test','test','0.75'),('2019-06-06 03:59:59','2019-06-06 23:59:59','BNBETH','4h','0.126974000000000','0.125704260000000','1.579075431231337','1.563284676919024','12.436210808758775','12.436210808758775','test','test','0.99'),('2019-06-08 11:59:59','2019-06-14 07:59:59','BNBETH','4h','0.129687000000000','0.131103000000000','1.575566374717490','1.592769347926832','12.148992379478972','12.148992379478972','test','test','0.60'),('2019-06-18 03:59:59','2019-06-21 03:59:59','BNBETH','4h','0.128230000000000','0.130000000000000','1.579389257652899','1.601190076385221','12.316846741424774','12.316846741424774','test','test','0.0'),('2019-06-21 15:59:59','2019-06-21 19:59:59','BNBETH','4h','0.131411000000000','0.130096890000000','1.584233884037859','1.568391545197480','12.055565242162828','12.055565242162828','test','test','1.00'),('2019-06-21 23:59:59','2019-06-22 03:59:59','BNBETH','4h','0.131288000000000','0.129975120000000','1.580713364295553','1.564906230652598','12.040044515077943','12.040044515077943','test','test','0.99'),('2019-07-04 23:59:59','2019-07-05 03:59:59','BNBETH','4h','0.116810000000000','0.115648000000000','1.577200667930452','1.561511025124740','13.502274359476516','13.502274359476516','test','test','0.99'),('2019-07-12 03:59:59','2019-07-25 03:59:59','BNBETH','4h','0.114090000000000','0.132219000000000','1.573714080640293','1.823778613622394','13.793619779474918','13.793619779474918','test','test','0.0'),('2019-07-27 11:59:59','2019-07-28 07:59:59','BNBETH','4h','0.133344000000000','0.132010560000000','1.629283976858538','1.612991137089953','12.218652334252296','12.218652334252296','test','test','0.99'),('2019-08-01 11:59:59','2019-08-02 03:59:59','BNBETH','4h','0.131630000000000','0.130976000000000','1.625663345798852','1.617586282605413','12.350249531253152','12.350249531253152','test','test','0.49'),('2019-08-07 19:59:59','2019-08-07 23:59:59','BNBETH','4h','0.133648000000000','0.132311520000000','1.623868442866977','1.607629758438307','12.15033852258902','12.150338522589021','test','test','1.00'),('2019-08-08 03:59:59','2019-08-18 15:59:59','BNBETH','4h','0.134084000000000','0.144352000000000','1.620259846327273','1.744337499903303','12.083916398133056','12.083916398133056','test','test','0.0'),('2019-08-19 07:59:59','2019-08-19 19:59:59','BNBETH','4h','0.143887000000000','0.143865000000000','1.647832658233057','1.647580708310679','11.452269198975985','11.452269198975985','test','test','0.33'),('2019-08-21 03:59:59','2019-08-22 03:59:59','BNBETH','4h','0.143400000000000','0.143184000000000','1.647776669361418','1.645294662662798','11.490771752869021','11.490771752869021','test','test','0.15'),('2019-09-05 19:59:59','2019-09-05 23:59:59','BNBETH','4h','0.133079000000000','0.131748210000000','1.647225112317280','1.630752861194107','12.377798993960578','12.377798993960578','test','test','0.99'),('2019-09-06 23:59:59','2019-09-07 03:59:59','BNBETH','4h','0.130289000000000','0.130426000000000','1.643564612067686','1.645292834341656','12.61476112386837','12.614761123868369','test','test','0.0'),('2019-10-09 07:59:59','2019-10-09 15:59:59','BNBETH','4h','0.093589000000000','0.092653110000000','1.643948661461901','1.627509174847282','17.565618410944676','17.565618410944676','test','test','0.99'),('2019-10-09 23:59:59','2019-10-10 03:59:59','BNBETH','4h','0.092067000000000','0.091146330000000','1.640295442214208','1.623892487792066','17.816323353798957','17.816323353798957','test','test','0.99'),('2019-10-11 11:59:59','2019-10-11 15:59:59','BNBETH','4h','0.091645000000000','0.091498000000000','1.636650341231510','1.634025128724979','17.85858847980261','17.858588479802609','test','test','0.16'),('2019-10-12 19:59:59','2019-10-24 07:59:59','BNBETH','4h','0.096199000000000','0.103161000000000','1.636066960674503','1.754470459465716','17.007109852228226','17.007109852228226','test','test','0.60'),('2019-10-25 03:59:59','2019-10-25 15:59:59','BNBETH','4h','0.106911000000000','0.105841890000000','1.662378849294773','1.645755060801825','15.549184361709951','15.549184361709951','test','test','0.99'),('2019-10-26 03:59:59','2019-10-26 07:59:59','BNBETH','4h','0.103708000000000','0.102670920000000','1.658684674074117','1.642097827333376','15.993796756991916','15.993796756991916','test','test','0.99'),('2019-10-28 03:59:59','2019-10-28 11:59:59','BNBETH','4h','0.111132000000000','0.110020680000000','1.654998708131731','1.638448721050414','14.892188641720935','14.892188641720935','test','test','0.99'),('2019-10-29 07:59:59','2019-10-29 11:59:59','BNBETH','4h','0.111850000000000','0.110731500000000','1.651320933224771','1.634807723892523','14.763709729322944','14.763709729322944','test','test','0.99'),('2019-10-31 11:59:59','2019-10-31 19:59:59','BNBETH','4h','0.110461000000000','0.109356390000000','1.647651331150938','1.631174817839429','14.916136293813548','14.916136293813548','test','test','1.00'),('2019-11-04 03:59:59','2019-11-04 11:59:59','BNBETH','4h','0.113333000000000','0.112199670000000','1.643989883748381','1.627549984910897','14.50583575612029','14.505835756120289','test','test','1.00'),('2019-11-04 23:59:59','2019-11-05 15:59:59','BNBETH','4h','0.111026000000000','0.109915740000000','1.640336572895607','1.623933207166651','14.774346305330344','14.774346305330344','test','test','1.00'),('2019-11-11 23:59:59','2019-11-12 03:59:59','BNBETH','4h','0.108600000000000','0.109105000000000','1.636691380511394','1.644302146139002','15.070823024966796','15.070823024966796','test','test','0.0'),('2019-11-12 07:59:59','2019-11-16 11:59:59','BNBETH','4h','0.109271000000000','0.110842000000000','1.638382661761974','1.661937851717480','14.993755541378535','14.993755541378535','test','test','0.0'),('2019-11-24 07:59:59','2019-11-24 11:59:59','BNBETH','4h','0.107656000000000','0.106797000000000','1.643617148418753','1.630502532136412','15.267306498650822','15.267306498650822','test','test','0.79'),('2019-12-04 11:59:59','2019-12-04 15:59:59','BNBETH','4h','0.104297000000000','0.104092000000000','1.640702789244900','1.637477921110676','15.731064069387418','15.731064069387418','test','test','0.19'),('2019-12-05 03:59:59','2019-12-06 11:59:59','BNBETH','4h','0.105446000000000','0.104906000000000','1.639986151881738','1.631587611187770','15.552853136977586','15.552853136977586','test','test','0.76'),('2019-12-06 15:59:59','2019-12-08 03:59:59','BNBETH','4h','0.105118000000000','0.104823000000000','1.638119809505301','1.633522639241368','15.583628013330745','15.583628013330745','test','test','0.28'),('2019-12-18 11:59:59','2019-12-18 19:59:59','BNBETH','4h','0.103794000000000','0.102756060000000','1.637098216113316','1.620727233952183','15.77257082406802','15.772570824068019','test','test','1.00'),('2019-12-19 11:59:59','2019-12-19 15:59:59','BNBETH','4h','0.104980000000000','0.103930200000000','1.633460220077509','1.617125617876734','15.559727758406444','15.559727758406444','test','test','1.00'),('2019-12-22 15:59:59','2019-12-22 19:59:59','BNBETH','4h','0.103843000000000','0.103529000000000','1.629830308477336','1.624902034863689','15.695138896963073','15.695138896963073','test','test','0.30'),('2019-12-23 15:59:59','2019-12-23 19:59:59','BNBETH','4h','0.103788000000000','0.104312000000000','1.628735136563193','1.636958218341039','15.69290415619525','15.692904156195249','test','test','0.0'),('2019-12-25 03:59:59','2019-12-26 19:59:59','BNBETH','4h','0.104962000000000','0.103912380000000','1.630562488069381','1.614256863188687','15.534788667035507','15.534788667035507','test','test','1.00'),('2019-12-26 23:59:59','2019-12-29 19:59:59','BNBETH','4h','0.104535000000000','0.104526000000000','1.626939015873671','1.626798943638124','15.563581727399155','15.563581727399155','test','test','0.20'),('2019-12-30 03:59:59','2019-12-30 07:59:59','BNBETH','4h','0.106623000000000','0.105556770000000','1.626907888710216','1.610638809823114','15.258507908333248','15.258507908333248','test','test','1.00'),('2019-12-30 15:59:59','2019-12-30 23:59:59','BNBETH','4h','0.106329000000000','0.105284000000000','1.623292537846416','1.607338840341036','15.266696177396717','15.266696177396717','test','test','0.98'),('2019-12-31 15:59:59','2020-01-01 11:59:59','BNBETH','4h','0.105931000000000','0.104871690000000','1.619747271734109','1.603549799016768','15.29058794624906','15.290587946249060','test','test','1.00');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:06:56
