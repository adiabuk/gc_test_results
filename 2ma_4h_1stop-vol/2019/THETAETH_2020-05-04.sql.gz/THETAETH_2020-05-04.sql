-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 15:59:59','2019-01-10 23:59:59','THETAETH','4h','0.000353100000000','0.000349670000000','1.297777777777778','1.285171213694578','3675.3831146354505','3675.383114635450511','test','test','0.97'),('2019-01-11 11:59:59','2019-01-14 15:59:59','THETAETH','4h','0.000363560000000','0.000359924400000','1.294976319092622','1.282026555901696','3561.932883410227','3561.932883410227078','test','test','1.00'),('2019-01-15 07:59:59','2019-01-15 15:59:59','THETAETH','4h','0.000370510000000','0.000366804900000','1.292098593939083','1.279177607999692','3487.3514721305314','3487.351472130531420','test','test','0.99'),('2019-01-15 19:59:59','2019-02-17 23:59:59','THETAETH','4h','0.000367640000000','0.000672760000000','1.289227263730330','2.359211549198174','3506.7654872438516','3506.765487243851567','test','test','0.0'),('2019-02-20 19:59:59','2019-02-20 23:59:59','THETAETH','4h','0.000678530000000','0.000671744700000','1.527001549389850','1.511731533895952','2250.455469013677','2250.455469013676975','test','test','1.00'),('2019-02-24 23:59:59','2019-03-04 07:59:59','THETAETH','4h','0.000662050000000','0.000976200000000','1.523608212613429','2.246577051813654','2301.3491618660655','2301.349161866065515','test','test','0.0'),('2019-03-04 19:59:59','2019-03-04 23:59:59','THETAETH','4h','0.001003470000000','0.000993435300000','1.684267954657923','1.667425275111344','1678.4437548286674','1678.443754828667352','test','test','0.99'),('2019-03-06 07:59:59','2019-03-07 03:59:59','THETAETH','4h','0.000987440000000','0.000977565600000','1.680525136980906','1.663719885611097','1701.901013713143','1701.901013713142902','test','test','0.99'),('2019-03-09 03:59:59','2019-03-09 11:59:59','THETAETH','4h','0.000955730000000','0.000946430000000','1.676790636676504','1.660474153024121','1754.4606077830597','1754.460607783059686','test','test','0.97'),('2019-03-09 23:59:59','2019-03-12 19:59:59','THETAETH','4h','0.001012890000000','0.001002761100000','1.673164751420418','1.656433103906214','1651.8721197962448','1651.872119796244760','test','test','0.99'),('2019-03-14 19:59:59','2019-03-14 23:59:59','THETAETH','4h','0.001090000000000','0.001079100000000','1.669446607528373','1.652752141453089','1531.6023922278653','1531.602392227865266','test','test','1.00'),('2019-04-05 03:59:59','2019-04-05 07:59:59','THETAETH','4h','0.000789050000000','0.000781159500000','1.665736726178310','1.649079358916527','2111.066125313111','2111.066125313111115','test','test','1.00'),('2019-04-14 03:59:59','2019-04-14 23:59:59','THETAETH','4h','0.000740530000000','0.000733124700000','1.662035089009025','1.645414738118935','2244.385897950151','2244.385897950151048','test','test','1.00'),('2019-04-15 19:59:59','2019-04-18 07:59:59','THETAETH','4h','0.000740730000000','0.000733322700000','1.658341677700116','1.641758260923115','2238.793727404204','2238.793727404204219','test','test','0.99'),('2019-05-18 07:59:59','2019-05-18 11:59:59','THETAETH','4h','0.000490570000000','0.000485664300000','1.654656473971894','1.638109909232175','3372.9263386915095','3372.926338691509500','test','test','1.00'),('2019-05-24 03:59:59','2019-05-24 07:59:59','THETAETH','4h','0.000559060000000','0.000553469400000','1.650979459585289','1.634469664989436','2953.134653856991','2953.134653856991008','test','test','0.99'),('2019-05-24 15:59:59','2019-05-24 19:59:59','THETAETH','4h','0.000497010000000','0.000492039900000','1.647310616341766','1.630837510178348','3314.4415934121375','3314.441593412137536','test','test','1.00'),('2019-05-25 03:59:59','2019-05-25 07:59:59','THETAETH','4h','0.000493010000000','0.000488079900000','1.643649926083229','1.627213426822397','3333.9078843902344','3333.907884390234358','test','test','1.00'),('2019-05-25 11:59:59','2019-05-25 15:59:59','THETAETH','4h','0.000532120000000','0.000526798800000','1.639997370691933','1.623597396985013','3082.006635142324','3082.006635142323830','test','test','1.00'),('2019-05-25 23:59:59','2019-05-26 03:59:59','THETAETH','4h','0.000547000000000','0.000541530000000','1.636352932090396','1.619989402769492','2991.504446234727','2991.504446234726856','test','test','1.00'),('2019-05-29 11:59:59','2019-05-29 15:59:59','THETAETH','4h','0.000577350000000','0.000571576500000','1.632716592241305','1.616389426318892','2827.9494106543784','2827.949410654378426','test','test','0.99'),('2019-05-29 19:59:59','2019-05-29 23:59:59','THETAETH','4h','0.000581710000000','0.000575892900000','1.629088333147436','1.612797449815962','2800.5162935954963','2800.516293595496336','test','test','1.00'),('2019-06-02 03:59:59','2019-06-02 07:59:59','THETAETH','4h','0.000523000000000','0.000517770000000','1.625468136851553','1.609213455483037','3107.969668932223','3107.969668932223158','test','test','1.00'),('2019-06-02 11:59:59','2019-06-02 15:59:59','THETAETH','4h','0.000530320000000','0.000525016800000','1.621855985436327','1.605637425581964','3058.2591368161247','3058.259136816124737','test','test','0.99'),('2019-06-02 19:59:59','2019-06-03 07:59:59','THETAETH','4h','0.000523900000000','0.000518661000000','1.618251861024247','1.602069342414004','3088.856386761303','3088.856386761302929','test','test','0.99'),('2019-06-03 15:59:59','2019-06-04 03:59:59','THETAETH','4h','0.000519440000000','0.000514245600000','1.614655745777526','1.598509188319751','3108.4547700938047','3108.454770093804655','test','test','0.99'),('2019-06-04 15:59:59','2019-06-04 19:59:59','THETAETH','4h','0.000518620000000','0.000513870000000','1.611067621898020','1.596311979608838','3106.4510082488537','3106.451008248853668','test','test','0.91'),('2019-06-05 03:59:59','2019-06-05 07:59:59','THETAETH','4h','0.000526840000000','0.000521571600000','1.607788590278202','1.591710704375420','3051.7587697938698','3051.758769793869760','test','test','1.00'),('2019-06-05 11:59:59','2019-06-05 15:59:59','THETAETH','4h','0.000522200000000','0.000516978000000','1.604215726744251','1.588173569476808','3072.0331802838964','3072.033180283896399','test','test','1.00'),('2019-06-05 23:59:59','2019-06-12 19:59:59','THETAETH','4h','0.000527440000000','0.000547800000000','1.600650802907041','1.662438400258754','3034.754290359171','3034.754290359171137','test','test','0.21'),('2019-07-02 03:59:59','2019-07-02 07:59:59','THETAETH','4h','0.000417370000000','0.000413196300000','1.614381380096311','1.598237566295348','3867.9861516072324','3867.986151607232387','test','test','1.00'),('2019-07-04 03:59:59','2019-07-04 07:59:59','THETAETH','4h','0.000418760000000','0.000414572400000','1.610793865918319','1.594685927259136','3846.5800599826134','3846.580059982613420','test','test','0.99'),('2019-07-06 11:59:59','2019-07-06 15:59:59','THETAETH','4h','0.000410170000000','0.000406068300000','1.607214323994056','1.591142180754115','3918.4102298901826','3918.410229890182563','test','test','1.00'),('2019-07-06 23:59:59','2019-07-07 15:59:59','THETAETH','4h','0.000413470000000','0.000411970000000','1.603642736607402','1.597824988995940','3878.4984076411893','3878.498407641189260','test','test','0.36'),('2019-07-10 15:59:59','2019-07-12 03:59:59','THETAETH','4h','0.000405870000000','0.000401811300000','1.602349903804855','1.586326404766806','3947.938758235039','3947.938758235039131','test','test','1.00'),('2019-07-12 15:59:59','2019-07-31 15:59:59','THETAETH','4h','0.000407000000000','0.000584000000000','1.598789126240844','2.294085625859098','3928.228811402566','3928.228811402565952','test','test','0.0'),('2019-07-31 19:59:59','2019-08-02 15:59:59','THETAETH','4h','0.000593440000000','0.000587505600000','1.753299459489345','1.735766464894452','2954.4679487215985','2954.467948721598532','test','test','1.00'),('2019-08-11 03:59:59','2019-08-11 11:59:59','THETAETH','4h','0.000558500000000','0.000555660000000','1.749403238468258','1.740507436861723','3132.3245093433447','3132.324509343344744','test','test','0.50'),('2019-08-11 15:59:59','2019-08-11 19:59:59','THETAETH','4h','0.000567510000000','0.000561834900000','1.747426393666806','1.729952129730138','3079.11119392928','3079.111193929280034','test','test','1.00'),('2019-08-12 03:59:59','2019-08-13 11:59:59','THETAETH','4h','0.000584130000000','0.000578288700000','1.743543223903102','1.726107791664071','2984.8547821599677','2984.854782159967726','test','test','1.00'),('2019-08-14 19:59:59','2019-08-14 23:59:59','THETAETH','4h','0.000587410000000','0.000581535900000','1.739668683405539','1.722271996571483','2961.5918751903087','2961.591875190308656','test','test','1.00'),('2019-08-15 23:59:59','2019-08-16 03:59:59','THETAETH','4h','0.000593530000000','0.000587594700000','1.735802752997971','1.718444725467991','2924.5408875675557','2924.540887567555728','test','test','0.99'),('2019-08-16 07:59:59','2019-08-16 11:59:59','THETAETH','4h','0.000588150000000','0.000582268500000','1.731945413546865','1.714625959411397','2944.734189487146','2944.734189487146068','test','test','0.99'),('2019-08-16 15:59:59','2019-08-26 03:59:59','THETAETH','4h','0.000597320000000','0.000649750000000','1.728096645961205','1.879781014721243','2893.083516308185','2893.083516308185153','test','test','0.75'),('2019-08-27 15:59:59','2019-08-28 15:59:59','THETAETH','4h','0.000656810000000','0.000654500000000','1.761804283463436','1.755608019863916','2682.3651945972747','2682.365194597274694','test','test','0.35'),('2019-08-28 19:59:59','2019-08-29 03:59:59','THETAETH','4h','0.000684460000000','0.000677615400000','1.760427335996876','1.742823062636907','2571.9944715496536','2571.994471549653554','test','test','0.99'),('2019-08-29 15:59:59','2019-08-30 11:59:59','THETAETH','4h','0.000666340000000','0.000659676600000','1.756515275250216','1.738950122497714','2636.0645845217396','2636.064584521739562','test','test','0.99'),('2019-09-01 23:59:59','2019-09-02 03:59:59','THETAETH','4h','0.000663670000000','0.000657033300000','1.752611907971882','1.735085788892163','2640.7882049390246','2640.788204939024581','test','test','0.99'),('2019-09-05 15:59:59','2019-09-06 07:59:59','THETAETH','4h','0.000661920000000','0.000655300800000','1.748717214843056','1.731230042694625','2641.8860509473293','2641.886050947329295','test','test','0.99'),('2019-10-06 03:59:59','2019-10-06 07:59:59','THETAETH','4h','0.000496230000000','0.000491267700000','1.744831176587849','1.727382864821971','3516.174307453901','3516.174307453900838','test','test','0.99'),('2019-10-08 15:59:59','2019-10-09 15:59:59','THETAETH','4h','0.000494630000000','0.000489683700000','1.740953773973209','1.723544236233477','3519.709225023167','3519.709225023167164','test','test','1.00'),('2019-10-12 19:59:59','2019-10-13 03:59:59','THETAETH','4h','0.000484660000000','0.000479813400000','1.737084987808825','1.719714137930737','3584.131118327951','3584.131118327950844','test','test','1.00'),('2019-10-13 11:59:59','2019-10-13 15:59:59','THETAETH','4h','0.000482170000000','0.000477348300000','1.733224798947027','1.715892550957557','3594.6342554431576','3594.634255443157599','test','test','0.99'),('2019-10-15 03:59:59','2019-10-16 11:59:59','THETAETH','4h','0.000486730000000','0.000481862700000','1.729373188282701','1.712079456399874','3553.0441688054993','3553.044168805499339','test','test','1.00'),('2019-10-16 19:59:59','2019-10-16 23:59:59','THETAETH','4h','0.000485140000000','0.000480288600000','1.725530136753183','1.708274835385651','3556.7674006537973','3556.767400653797267','test','test','1.00'),('2019-10-17 11:59:59','2019-10-18 07:59:59','THETAETH','4h','0.000482690000000','0.000477863100000','1.721695625338176','1.704478669084794','3566.8765156480895','3566.876515648089480','test','test','1.00'),('2019-10-21 23:59:59','2019-10-26 03:59:59','THETAETH','4h','0.000496250000000','0.000527100000000','1.717869635059647','1.824663142851265','3461.702035384679','3461.702035384679220','test','test','0.88'),('2019-10-28 23:59:59','2019-10-29 23:59:59','THETAETH','4h','0.000540910000000','0.000535500900000','1.741601525680006','1.724185510423206','3219.762115102339','3219.762115102339067','test','test','0.99'),('2019-11-15 15:59:59','2019-11-16 07:59:59','THETAETH','4h','0.000504510000000','0.000499464900000','1.737731300067384','1.720353987066710','3444.394164768556','3444.394164768556038','test','test','0.99'),('2019-11-18 07:59:59','2019-11-18 11:59:59','THETAETH','4h','0.000495040000000','0.000514220000000','1.733869674956123','1.801047317905498','3502.4839911039985','3502.483991103998505','test','test','0.0'),('2019-11-18 15:59:59','2019-11-18 19:59:59','THETAETH','4h','0.000514880000000','0.000509731200000','1.748798040055984','1.731310059655424','3396.515770773742','3396.515770773742133','test','test','1.00'),('2019-11-19 11:59:59','2019-11-20 15:59:59','THETAETH','4h','0.000521880000000','0.000516661200000','1.744911822189193','1.727462703967301','3343.5115777366323','3343.511577736632262','test','test','1.00'),('2019-11-21 19:59:59','2019-11-22 07:59:59','THETAETH','4h','0.000509140000000','0.000504048600000','1.741034240362106','1.723623897958485','3419.558943241753','3419.558943241752786','test','test','0.99'),('2019-11-26 15:59:59','2019-11-26 19:59:59','THETAETH','4h','0.000502000000000','0.000500770000000','1.737165275383524','1.732908874409975','3460.488596381522','3460.488596381521802','test','test','0.24'),('2019-11-27 15:59:59','2019-11-27 19:59:59','THETAETH','4h','0.000510120000000','0.000505018800000','1.736219408500513','1.718857214415508','3403.550945856882','3403.550945856882208','test','test','1.00'),('2019-11-30 03:59:59','2019-11-30 07:59:59','THETAETH','4h','0.000502260000000','0.000497237400000','1.732361143148290','1.715037531716807','3449.1322087131957','3449.132208713195723','test','test','1.00'),('2019-12-03 23:59:59','2019-12-04 03:59:59','THETAETH','4h','0.000497180000000','0.000492208200000','1.728511451719071','1.711226337201880','3476.631102858263','3476.631102858263148','test','test','1.00'),('2019-12-04 15:59:59','2019-12-04 19:59:59','THETAETH','4h','0.000495470000000','0.000490515300000','1.724670315159695','1.707423612008098','3480.877379376542','3480.877379376542194','test','test','0.99'),('2019-12-05 11:59:59','2019-12-10 03:59:59','THETAETH','4h','0.000502700000000','0.000550400000000','1.720837714459341','1.884123887086575','3423.1902018288056','3423.190201828805584','test','test','0.0'),('2019-12-11 19:59:59','2019-12-11 23:59:59','THETAETH','4h','0.000594470000000','0.000588525300000','1.757123530598726','1.739552295292739','2955.7816720755054','2955.781672075505412','test','test','1.00'),('2019-12-12 07:59:59','2019-12-17 23:59:59','THETAETH','4h','0.000566820000000','0.000778510000000','1.753218811641840','2.407992620322657','3093.0785992763836','3093.078599276383557','test','test','0.0'),('2019-12-18 07:59:59','2019-12-18 15:59:59','THETAETH','4h','0.000790190000000','0.000782288100000','1.898724102459799','1.879736861435201','2402.8703254404622','2402.870325440462238','test','test','1.00'),('2019-12-21 19:59:59','2019-12-21 23:59:59','THETAETH','4h','0.000817260000000','0.000809087400000','1.894504715565444','1.875559668409789','2318.1175091959035','2318.117509195903494','test','test','0.99'),('2019-12-25 03:59:59','2019-12-25 07:59:59','THETAETH','4h','0.000763910000000','0.000756270900000','1.890294705086410','1.871391758035546','2474.4992277708234','2474.499227770823381','test','test','0.99'),('2019-12-31 11:59:59','2019-12-31 15:59:59','THETAETH','4h','0.000708700000000','0.000701613000000','1.886094050186218','1.867233109684356','2661.3433754567764','2661.343375456776357','test','test','1.00');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 21:03:13
