-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-03 19:59:59','BTCUSDT','4h','3797.139999999999873','3759.168599999999969','222.222222222222200','219.999999999999972','0.05852357885730371','0.058523578857304','test','test','0.99'),('2019-01-04 23:59:59','2019-01-05 23:59:59','BTCUSDT','4h','3792.010000000000218','3770.960000000000036','221.728395061728406','220.497548435256050','0.058472523822914076','0.058472523822914','test','test','0.55'),('2019-01-06 11:59:59','2019-01-10 07:59:59','BTCUSDT','4h','3814.239999999999782','3777.019999999999982','221.454873589178987','219.293879421274198','0.05806002600496534','0.058060026004965','test','test','0.97'),('2019-01-19 11:59:59','2019-01-20 11:59:59','BTCUSDT','4h','3695.380000000000109','3658.426199999999881','220.974652662977888','218.764906136348117','0.059797545222136254','0.059797545222136','test','test','1.00'),('2019-01-26 07:59:59','2019-01-26 11:59:59','BTCUSDT','4h','3620.579999999999927','3589.929999999999836','220.483597879282428','218.617095198772660','0.06089731420912738','0.060897314209127','test','test','0.84'),('2019-02-08 15:59:59','2019-02-24 15:59:59','BTCUSDT','4h','3507.340000000000146','3778.650000000000091','220.068819505835791','237.092225112400399','0.06274521988339761','0.062745219883398','test','test','0.0'),('2019-02-25 19:59:59','2019-02-25 23:59:59','BTCUSDT','4h','3855.389999999999873','3827.920000000000073','223.851798529516827','222.256834361013574','0.058062037440963644','0.058062037440964','test','test','0.71'),('2019-02-28 15:59:59','2019-02-28 19:59:59','BTCUSDT','4h','3852.880000000000109','3821.110000000000127','223.497362047627234','221.654452018700027','0.05800786996938063','0.058007869969381','test','test','0.82'),('2019-03-05 19:59:59','2019-03-08 23:59:59','BTCUSDT','4h','3855.710000000000036','3864.889999999999873','223.087826485643404','223.618972823707765','0.05785907822052058','0.057859078220521','test','test','0.75'),('2019-03-09 07:59:59','2019-03-11 07:59:59','BTCUSDT','4h','3915.690000000000055','3885.500000000000000','223.205859005213256','221.484940116494442','0.05700294430999728','0.057002944309997','test','test','0.77'),('2019-03-12 11:59:59','2019-03-13 11:59:59','BTCUSDT','4h','3885.179999999999836','3856.119999999999891','222.823432585497955','221.156779058265073','0.05735215165976813','0.057352151659768','test','test','0.74'),('2019-03-13 15:59:59','2019-03-13 19:59:59','BTCUSDT','4h','3872.000000000000000','3870.119999999999891','222.453065135001765','222.345055898830822','0.05745172136751078','0.057451721367511','test','test','0.04'),('2019-03-14 15:59:59','2019-03-21 15:59:59','BTCUSDT','4h','3882.099999999999909','3968.659999999999854','222.429063082519320','227.388610672850035','0.05729606735594635','0.057296067355946','test','test','0.22'),('2019-03-22 15:59:59','2019-03-24 23:59:59','BTCUSDT','4h','3993.309999999999945','3992.179999999999836','223.531184769259454','223.467931418332711','0.055976416749328115','0.055976416749328','test','test','0.29'),('2019-03-27 03:59:59','2019-04-12 03:59:59','BTCUSDT','4h','3991.590000000000146','4984.880000000000109','223.517128469053546','279.138404335819985','0.05599701584307345','0.055997015843073','test','test','0.0'),('2019-04-12 11:59:59','2019-04-15 23:59:59','BTCUSDT','4h','5041.359999999999673','5024.949999999999818','235.877411995001665','235.109613557508993','0.04678844835421427','0.046788448354214','test','test','0.70'),('2019-04-16 15:59:59','2019-04-25 23:59:59','BTCUSDT','4h','5069.119999999999891','5219.899999999999636','235.706790120003262','242.717843283924054','0.046498561904236485','0.046498561904236','test','test','0.0'),('2019-04-26 03:59:59','2019-04-26 07:59:59','BTCUSDT','4h','5344.390000000000327','5293.359999999999673','237.264801934207895','234.999319279928784','0.044395113742486586','0.044395113742487','test','test','0.95'),('2019-04-30 15:59:59','2019-04-30 19:59:59','BTCUSDT','4h','5312.189999999999600','5292.529999999999745','236.761361344368083','235.885126050820560','0.04456944524656838','0.044569445246568','test','test','0.37'),('2019-05-01 03:59:59','2019-05-17 15:59:59','BTCUSDT','4h','5348.949999999999818','7094.430000000000291','236.566642390246415','313.763539530680987','0.04422674401335709','0.044226744013357','test','test','0.0'),('2019-05-19 03:59:59','2019-05-20 19:59:59','BTCUSDT','4h','7903.220000000000255','7824.187800000000607','253.721508421454132','251.184293337239581','0.032103561386555624','0.032103561386556','test','test','0.99'),('2019-05-20 23:59:59','2019-05-21 11:59:59','BTCUSDT','4h','7938.149999999999636','7858.768499999999221','253.157682847184191','250.626106018712335','0.03189126973503703','0.031891269735037','test','test','1.00'),('2019-05-21 15:59:59','2019-05-22 11:59:59','BTCUSDT','4h','7890.489999999999782','7811.585099999999329','252.595110218634886','250.069159116448532','0.03201260127300521','0.032012601273005','test','test','1.00'),('2019-05-23 23:59:59','2019-05-30 23:59:59','BTCUSDT','4h','7851.510000000000218','8269.540000000000873','252.033787751482379','265.452567615960959','0.03210004034274711','0.032100040342747','test','test','0.05'),('2019-05-31 15:59:59','2019-06-03 07:59:59','BTCUSDT','4h','8349.520000000000437','8470.000000000000000','255.015738832477638','258.695506796927873','0.0305425627859419','0.030542562785942','test','test','0.0'),('2019-06-12 15:59:59','2019-06-27 23:59:59','BTCUSDT','4h','8140.569999999999709','11329.989999999999782','255.833465046799887','356.067277923486017','0.03142697194997401','0.031426971949974','test','test','0.71'),('2019-07-03 03:59:59','2019-07-03 11:59:59','BTCUSDT','4h','11289.479999999999563','11176.585199999999531','278.107645686063449','275.326569229202789','0.02463422989243645','0.024634229892436','test','test','1.00'),('2019-07-03 23:59:59','2019-07-04 07:59:59','BTCUSDT','4h','11940.000000000000000','11820.600000000000364','277.489628695649969','274.714732408693465','0.023240337411695976','0.023240337411696','test','test','0.99'),('2019-07-07 19:59:59','2019-07-08 03:59:59','BTCUSDT','4h','11474.180000000000291','11359.438200000000506','276.872985076326302','274.104255225563008','0.024130089041336837','0.024130089041337','test','test','0.99'),('2019-07-08 11:59:59','2019-07-10 23:59:59','BTCUSDT','4h','11884.799999999999272','12108.370000000000800','276.257711776156725','281.454512447753700','0.023244624375349753','0.023244624375350','test','test','0.43'),('2019-07-20 19:59:59','2019-07-20 23:59:59','BTCUSDT','4h','10898.659999999999854','10789.673399999999674','277.412556369844935','274.638430806146459','0.0254538224304497','0.025453822430450','test','test','1.00'),('2019-07-31 15:59:59','2019-08-01 07:59:59','BTCUSDT','4h','10049.639999999999418','9960.190000000000509','276.796084022356354','274.332372912724622','0.027542885518521694','0.027542885518522','test','test','0.89'),('2019-08-01 15:59:59','2019-08-11 11:59:59','BTCUSDT','4h','10013.860000000000582','11469.940000000000509','276.248592664660407','316.416924437539080','0.02758662420531747','0.027586624205317','test','test','0.0'),('2019-08-19 15:59:59','2019-08-19 19:59:59','BTCUSDT','4h','10707.799999999999272','10685.879999999999200','285.174888614189001','284.591105431983237','0.026632444443694225','0.026632444443694','test','test','0.20'),('2019-08-20 15:59:59','2019-08-20 19:59:59','BTCUSDT','4h','10744.540000000000873','10734.100000000000364','285.045159018143295','284.768193093110710','0.02652930316403897','0.026529303164039','test','test','0.09'),('2019-09-02 19:59:59','2019-09-06 23:59:59','BTCUSDT','4h','10163.680000000000291','10298.729999999999563','284.983611034802720','288.770333626447666','0.028039412007737623','0.028039412007738','test','test','0.0'),('2019-09-07 19:59:59','2019-09-08 11:59:59','BTCUSDT','4h','10465.719999999999345','10387.000000000000000','285.825104944057159','283.675214419449560','0.027310601176417596','0.027310601176418','test','test','0.75'),('2019-09-09 11:59:59','2019-09-09 15:59:59','BTCUSDT','4h','10413.260000000000218','10321.100000000000364','285.347351494144391','282.821954844708955','0.02740230739404801','0.027402307394048','test','test','0.88'),('2019-09-12 15:59:59','2019-09-12 19:59:59','BTCUSDT','4h','10326.520000000000437','10300.629999999999200','284.786152238714237','284.072154349642176','0.02757813399274046','0.027578133992740','test','test','0.25'),('2019-09-12 23:59:59','2019-09-13 07:59:59','BTCUSDT','4h','10415.010000000000218','10310.859899999999470','284.627486041142674','281.781211180731191','0.027328584998107794','0.027328584998108','test','test','1.00'),('2019-09-13 23:59:59','2019-09-14 15:59:59','BTCUSDT','4h','10342.059999999999491','10356.319999999999709','283.994980516606859','284.386562892087795','0.02746019463400975','0.027460194634010','test','test','0.58'),('2019-09-14 19:59:59','2019-09-15 07:59:59','BTCUSDT','4h','10363.729999999999563','10308.420000000000073','284.081998822269213','282.565886828338478','0.027411173276635847','0.027411173276636','test','test','0.58'),('2019-09-15 15:59:59','2019-09-15 23:59:59','BTCUSDT','4h','10307.969999999999345','10302.010000000000218','283.745085045840199','283.581025516478633','0.02752676667140477','0.027526766671405','test','test','0.11'),('2019-10-09 15:59:59','2019-10-11 07:59:59','BTCUSDT','4h','8550.000000000000000','8464.500000000000000','283.708627372648721','280.871541098922251','0.0331822955991402','0.033182295599140','test','test','1.0'),('2019-10-13 15:59:59','2019-10-13 23:59:59','BTCUSDT','4h','8403.799999999999272','8319.761999999998807','283.078163756265099','280.247382118702433','0.03368454315384292','0.033684543153843','test','test','1.00'),('2019-10-20 19:59:59','2019-10-21 15:59:59','BTCUSDT','4h','8235.000000000000000','8191.250000000000000','282.449101170140068','280.948536728586475','0.03429861580693869','0.034298615806939','test','test','0.53'),('2019-10-22 11:59:59','2019-10-22 19:59:59','BTCUSDT','4h','8276.159999999999854','8193.398400000000038','282.115642405350343','279.294485981296816','0.03408774629844642','0.034087746298446','test','test','0.99'),('2019-10-25 15:59:59','2019-11-07 15:59:59','BTCUSDT','4h','8263.159999999999854','9191.930000000000291','281.488718755560683','313.127737886087289','0.034065505055639815','0.034065505055640','test','test','0.0'),('2019-11-29 15:59:59','2019-11-29 19:59:59','BTCUSDT','4h','7807.989999999999782','7729.910100000000057','288.519611895677656','285.634415776720857','0.03695184188192834','0.036951841881928','test','test','0.99'),('2019-12-18 23:59:59','2019-12-19 03:59:59','BTCUSDT','4h','7277.829999999999927','7205.051699999999983','287.878457202576215','284.999672630550435','0.039555534713311004','0.039555534713311','test','test','0.99'),('2019-12-19 11:59:59','2019-12-19 15:59:59','BTCUSDT','4h','7150.000000000000000','7145.840000000000146','287.238727297681578','287.071606583617495','0.04017324857310232','0.040173248573102','test','test','0.05'),('2019-12-22 19:59:59','2019-12-23 23:59:59','BTCUSDT','4h','7398.350000000000364','7324.366500000000087','287.201589361222887','284.329573467610658','0.038819681329110255','0.038819681329110','test','test','1.00'),('2019-12-24 11:59:59','2019-12-24 15:59:59','BTCUSDT','4h','7373.539999999999964','7299.804599999999482','286.563363607086842','283.697729971015917','0.03886374300635608','0.038863743006356','test','test','1.00'),('2019-12-26 19:59:59','2019-12-26 23:59:59','BTCUSDT','4h','7301.380000000000109','7228.366200000000390','285.926556132404414','283.067290571080378','0.039160618421778405','0.039160618421778','test','test','0.99'),('2019-12-28 03:59:59','2019-12-30 15:59:59','BTCUSDT','4h','7288.000000000000000','7262.079999999999927','285.291163785443473','284.276516836305348','0.039145329827859975','0.039145329827860','test','test','0.35');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:02:39
