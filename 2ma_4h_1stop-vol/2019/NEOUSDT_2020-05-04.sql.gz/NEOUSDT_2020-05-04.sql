-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-02 07:59:59','NEOUSDT','4h','7.756000000000000','7.678440000000000','222.222222222222200','219.999999999999972','28.65165320038966','28.651653200389660','test','test','1.00'),('2019-01-02 11:59:59','2019-01-03 11:59:59','NEOUSDT','4h','7.789000000000000','7.711110000000000','221.728395061728406','219.511111111111120','28.466862891478804','28.466862891478804','test','test','1.00'),('2019-01-05 15:59:59','2019-01-06 07:59:59','NEOUSDT','4h','7.737000000000000','7.659630000000000','221.235665294924530','219.023308641975291','28.594502429226385','28.594502429226385','test','test','1.00'),('2019-01-06 11:59:59','2019-01-10 07:59:59','NEOUSDT','4h','7.763000000000000','8.327999999999999','220.744030483158070','236.810032959389446','28.435402612798928','28.435402612798928','test','test','0.0'),('2019-01-19 11:59:59','2019-01-20 11:59:59','NEOUSDT','4h','7.900000000000000','7.821000000000001','224.314253255653938','222.071110723097405','28.394209272867585','28.394209272867585','test','test','0.99'),('2019-02-02 23:59:59','2019-02-03 03:59:59','NEOUSDT','4h','7.237000000000000','7.164630000000000','223.815777137308032','221.577619365934936','30.92659626050961','30.926596260509609','test','test','1.00'),('2019-02-08 15:59:59','2019-02-24 19:59:59','NEOUSDT','4h','7.413000000000000','9.410000000000000','223.318408743669551','283.478514269247285','30.125240623724476','30.125240623724476','test','test','0.0'),('2019-02-25 19:59:59','2019-02-25 23:59:59','NEOUSDT','4h','9.308999999999999','9.215909999999999','236.687321082686850','234.320447871859983','25.425644116735082','25.425644116735082','test','test','1.00'),('2019-03-01 23:59:59','2019-03-02 07:59:59','NEOUSDT','4h','8.946999999999999','8.857529999999999','236.161349258058635','233.799735765478033','26.395590617867292','26.395590617867292','test','test','1.00'),('2019-03-05 19:59:59','2019-03-05 23:59:59','NEOUSDT','4h','8.754000000000000','8.739000000000001','235.636546259707416','235.232782472422144','26.917585819020726','26.917585819020726','test','test','0.17'),('2019-03-06 11:59:59','2019-03-06 15:59:59','NEOUSDT','4h','8.736000000000001','8.689000000000000','235.546820973644003','234.279570448717095','26.962777126103937','26.962777126103937','test','test','0.53'),('2019-03-07 07:59:59','2019-03-07 11:59:59','NEOUSDT','4h','8.779999999999999','8.692200000000000','235.265209745882458','232.912557648423643','26.79558197561304','26.795581975613040','test','test','0.99'),('2019-03-07 19:59:59','2019-03-08 03:59:59','NEOUSDT','4h','9.144000000000000','9.052560000000000','234.742398168669411','232.394974186982722','25.671740832094205','25.671740832094205','test','test','1.00'),('2019-03-09 15:59:59','2019-03-10 07:59:59','NEOUSDT','4h','9.010999999999999','8.920890000000000','234.220748394961248','231.878540911011669','25.99275867217415','25.992758672174151','test','test','0.99'),('2019-03-12 15:59:59','2019-03-12 19:59:59','NEOUSDT','4h','8.789999999999999','8.811000000000000','233.700257842972434','234.258586104030741','26.587060050395046','26.587060050395046','test','test','0.0'),('2019-03-13 03:59:59','2019-03-13 11:59:59','NEOUSDT','4h','8.907000000000000','8.817930000000000','233.824330789874267','231.486087481975545','26.251749274713625','26.251749274713625','test','test','0.99'),('2019-03-13 15:59:59','2019-03-14 03:59:59','NEOUSDT','4h','8.981999999999999','8.892180000000000','233.304721165896808','230.971673954237843','25.974696188587934','25.974696188587934','test','test','0.99'),('2019-03-14 15:59:59','2019-03-18 07:59:59','NEOUSDT','4h','9.090999999999999','9.053000000000001','232.786266229972597','231.813229367499986','25.606233222964757','25.606233222964757','test','test','0.41'),('2019-03-19 15:59:59','2019-03-20 03:59:59','NEOUSDT','4h','9.125000000000000','9.033750000000000','232.570035816089785','230.244335457928884','25.487127212722168','25.487127212722168','test','test','1.00'),('2019-03-20 15:59:59','2019-03-21 15:59:59','NEOUSDT','4h','9.183999999999999','9.092160000000000','232.053213514276223','229.732681379133481','25.26711819624088','25.267118196240880','test','test','0.99'),('2019-03-22 11:59:59','2019-03-24 07:59:59','NEOUSDT','4h','9.143000000000001','9.132000000000000','231.537539706466760','231.258975456573808','25.324022717539837','25.324022717539837','test','test','0.12'),('2019-03-24 23:59:59','2019-03-25 03:59:59','NEOUSDT','4h','9.124000000000001','9.085000000000001','231.475636539823881','230.486207580480055','25.369973316508535','25.369973316508535','test','test','0.42'),('2019-03-25 11:59:59','2019-03-25 15:59:59','NEOUSDT','4h','9.268000000000001','9.175320000000001','231.255763437747447','228.943205803369978','24.95206769936852','24.952067699368520','test','test','0.99'),('2019-03-27 11:59:59','2019-04-09 07:59:59','NEOUSDT','4h','9.236000000000001','12.166000000000000','230.741861741219168','303.941694450375905','24.982878057732695','24.982878057732695','test','test','0.98'),('2019-05-02 15:59:59','2019-05-02 19:59:59','NEOUSDT','4h','10.061999999999999','9.961380000000000','247.008491232142859','244.538406319821462','24.54864750866059','24.548647508660590','test','test','0.99'),('2019-05-03 11:59:59','2019-05-03 19:59:59','NEOUSDT','4h','10.016000000000000','9.948000000000000','246.459583473849193','244.786335502980421','24.606587806893888','24.606587806893888','test','test','0.67'),('2019-05-04 03:59:59','2019-05-04 07:59:59','NEOUSDT','4h','9.968999999999999','9.869309999999999','246.087750591433945','243.626873085519577','24.685299487554815','24.685299487554815','test','test','1.00'),('2019-05-11 11:59:59','2019-05-12 11:59:59','NEOUSDT','4h','9.516000000000000','9.420840000000000','245.540888923452968','243.085480034218449','25.802951757403633','25.802951757403633','test','test','0.99'),('2019-05-13 15:59:59','2019-05-13 23:59:59','NEOUSDT','4h','9.846000000000000','9.747540000000001','244.995242503623075','242.545290078586874','24.882718109244674','24.882718109244674','test','test','0.99'),('2019-05-14 03:59:59','2019-05-22 23:59:59','NEOUSDT','4h','10.310000000000000','11.154000000000000','244.450808631392789','264.462106641566947','23.71006873243383','23.710068732433829','test','test','0.0'),('2019-05-24 11:59:59','2019-05-24 23:59:59','NEOUSDT','4h','11.675000000000001','11.558250000000001','248.897763744764831','246.408786107317184','21.318866273641525','21.318866273641525','test','test','0.99'),('2019-05-26 19:59:59','2019-06-03 23:59:59','NEOUSDT','4h','11.573000000000000','12.417999999999999','248.344657603109795','266.477487091974183','21.45896980930699','21.458969809306989','test','test','0.0'),('2019-06-10 11:59:59','2019-06-10 15:59:59','NEOUSDT','4h','12.257999999999999','12.272000000000000','252.374175267301894','252.662414658209258','20.588527921953165','20.588527921953165','test','test','0.0'),('2019-06-12 11:59:59','2019-06-20 11:59:59','NEOUSDT','4h','12.625999999999999','13.260000000000000','252.438228465281298','265.114122402156681','19.99352355974032','19.993523559740321','test','test','0.0'),('2019-06-20 23:59:59','2019-06-27 19:59:59','NEOUSDT','4h','13.538000000000000','17.274999999999999','255.255093784586933','325.715153281780090','18.854712201550225','18.854712201550225','test','test','0.0'),('2019-07-02 15:59:59','2019-07-03 07:59:59','NEOUSDT','4h','17.689000000000000','17.512110000000000','270.912884783963193','268.203755936123571','15.315330701789993','15.315330701789993','test','test','1.00'),('2019-07-03 23:59:59','2019-07-04 03:59:59','NEOUSDT','4h','17.904000000000000','17.724959999999999','270.310856151109988','267.607747589598887','15.097791339986037','15.097791339986037','test','test','1.00'),('2019-07-08 11:59:59','2019-07-09 11:59:59','NEOUSDT','4h','17.427000000000000','17.366000000000000','269.710165359662994','268.766094659775490','15.476568850614736','15.476568850614736','test','test','0.70'),('2019-07-10 07:59:59','2019-07-10 15:59:59','NEOUSDT','4h','17.251999999999999','17.079480000000000','269.500371870799142','266.805368152091205','15.62139878685365','15.621398786853650','test','test','0.99'),('2019-08-05 03:59:59','2019-08-05 07:59:59','NEOUSDT','4h','12.279000000000000','12.156210000000000','268.901482155530744','266.212467333975439','21.899298163981655','21.899298163981655','test','test','1.00'),('2019-08-05 11:59:59','2019-08-05 15:59:59','NEOUSDT','4h','12.452999999999999','12.328469999999999','268.303923306296213','265.620884073233242','21.545324283810828','21.545324283810828','test','test','1.00'),('2019-08-06 07:59:59','2019-08-06 11:59:59','NEOUSDT','4h','12.113000000000000','11.991869999999999','267.707692365615571','265.030615441959355','22.100857951425375','22.100857951425375','test','test','1.00'),('2019-08-24 23:59:59','2019-08-25 03:59:59','NEOUSDT','4h','10.102000000000000','10.000980000000000','267.112786382580850','264.441658518755048','26.4415745775669','26.441574577566900','test','test','1.00'),('2019-09-03 15:59:59','2019-09-03 19:59:59','NEOUSDT','4h','9.340000000000000','9.282999999999999','266.519202412841764','264.892693361714123','28.535246511010897','28.535246511010897','test','test','0.61'),('2019-09-06 11:59:59','2019-09-06 15:59:59','NEOUSDT','4h','9.206000000000000','9.127000000000001','266.157755957035647','263.873760441002048','28.911335645995617','28.911335645995617','test','test','0.85'),('2019-09-08 15:59:59','2019-09-09 03:59:59','NEOUSDT','4h','9.255000000000001','9.162450000000002','265.650201397917044','262.993699383937894','28.703425326625286','28.703425326625286','test','test','0.99'),('2019-09-14 15:59:59','2019-09-16 15:59:59','NEOUSDT','4h','9.050000000000001','8.959500000000000','265.059867617032808','262.409268940862489','29.28838316210307','29.288383162103070','test','test','1.00'),('2019-09-16 23:59:59','2019-09-22 03:59:59','NEOUSDT','4h','9.082000000000001','9.090000000000000','264.470845688994928','264.703808336595841','29.120330950120557','29.120330950120557','test','test','0.0'),('2019-10-09 07:59:59','2019-10-10 11:59:59','NEOUSDT','4h','7.609000000000000','7.532910000000000','264.522615166239575','261.877389014577204','34.76443884429486','34.764438844294858','test','test','0.99'),('2019-10-14 23:59:59','2019-10-15 11:59:59','NEOUSDT','4h','7.529000000000000','7.499000000000000','263.934787132536883','262.883114451705922','35.05575602769782','35.055756027697818','test','test','0.39'),('2019-10-20 19:59:59','2019-10-21 03:59:59','NEOUSDT','4h','7.298000000000000','7.300000000000000','263.701082092352237','263.773348763246304','36.13333544702004','36.133335447020038','test','test','0.0'),('2019-10-21 11:59:59','2019-10-21 15:59:59','NEOUSDT','4h','7.389000000000000','7.315110000000000','263.717141352550868','261.079969939025375','35.690504987488275','35.690504987488275','test','test','1.00'),('2019-10-22 03:59:59','2019-10-22 19:59:59','NEOUSDT','4h','7.457000000000000','7.382429999999999','263.131103260656289','260.499792228049728','35.28645611648871','35.286456116488708','test','test','1.00'),('2019-10-25 15:59:59','2019-11-08 15:59:59','NEOUSDT','4h','7.474000000000000','10.574999999999999','262.546367475632621','371.478169126948728','35.12795925550343','35.127959255503427','test','test','0.0'),('2019-11-10 11:59:59','2019-11-11 07:59:59','NEOUSDT','4h','10.901000000000000','10.791990000000000','286.753434509258398','283.885900164165832','26.30524121725148','26.305241217251481','test','test','0.99'),('2019-11-11 11:59:59','2019-11-18 11:59:59','NEOUSDT','4h','10.849000000000000','11.728999999999999','286.116204654793421','309.324081887369516','26.372587764291033','26.372587764291033','test','test','0.0'),('2019-11-20 03:59:59','2019-11-20 07:59:59','NEOUSDT','4h','11.815000000000000','11.785000000000000','291.273510706476998','290.533924983142754','24.652857444475412','24.652857444475412','test','test','0.25'),('2019-11-20 15:59:59','2019-11-20 19:59:59','NEOUSDT','4h','11.811000000000000','11.692890000000000','291.109158323513839','288.198066740278705','24.64729136597357','24.647291365973569','test','test','0.99'),('2019-12-13 15:59:59','2019-12-13 19:59:59','NEOUSDT','4h','9.034000000000001','8.943660000000001','290.462249082794926','287.557626591966994','32.15211966823056','32.152119668230561','test','test','0.99'),('2019-12-14 03:59:59','2019-12-14 11:59:59','NEOUSDT','4h','9.100000000000000','9.009000000000000','289.816777418166453','286.918609643984837','31.847997518479833','31.847997518479833','test','test','0.99'),('2019-12-15 19:59:59','2019-12-16 03:59:59','NEOUSDT','4h','8.952000000000000','8.862480000000000','289.172740135015033','286.281012733664852','32.30258491231178','32.302584912311779','test','test','1.00'),('2019-12-22 07:59:59','2019-12-23 19:59:59','NEOUSDT','4h','8.699000000000000','8.686000000000000','288.530134045826060','288.098947502246858','33.16819565994092','33.168195659940920','test','test','0.14'),('2019-12-24 11:59:59','2019-12-24 15:59:59','NEOUSDT','4h','8.726000000000001','8.648999999999999','288.434314813919570','285.889111715057311','33.05458569950946','33.054585699509460','test','test','0.88'),('2019-12-26 19:59:59','2019-12-26 23:59:59','NEOUSDT','4h','8.725000000000000','8.637749999999999','287.868714125283532','284.990026984030635','32.99354889688063','32.993548896880633','test','test','1.00'),('2019-12-27 19:59:59','2019-12-31 15:59:59','NEOUSDT','4h','8.736000000000001','8.776999999999999','287.229005871671802','288.577035775602440','32.87877814465107','32.878778144651072','test','test','0.57');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:24:31
