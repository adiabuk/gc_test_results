-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 11:59:59','2019-01-09 15:59:59','NANOETH','4h','0.006674000000000','0.006763000000000','1.297777777777778','1.315084074185063','194.45276862118334','194.452768621183338','test','test','0.0'),('2019-01-09 23:59:59','2019-01-14 15:59:59','NANOETH','4h','0.006854000000000','0.006798000000000','1.301623621423841','1.290988820898639','189.90715223575154','189.907152235751539','test','test','0.81'),('2019-01-15 23:59:59','2019-01-27 19:59:59','NANOETH','4h','0.007035000000000','0.008213000000000','1.299260332418241','1.516819489715851','184.68519295213088','184.685192952130876','test','test','0.0'),('2019-02-27 23:59:59','2019-02-28 03:59:59','NANOETH','4h','0.006418000000000','0.006387000000000','1.347606811817710','1.341097648345234','209.9730152411514','209.973015241151387','test','test','0.48'),('2019-03-01 11:59:59','2019-03-05 15:59:59','NANOETH','4h','0.006545000000000','0.006532000000000','1.346160331046048','1.343486521373993','205.67766708113803','205.677667081138026','test','test','0.44'),('2019-03-09 03:59:59','2019-03-09 07:59:59','NANOETH','4h','0.006510000000000','0.006486000000000','1.345566151118925','1.340605538580238','206.69218911197004','206.692189111970038','test','test','0.36'),('2019-03-09 15:59:59','2019-03-09 19:59:59','NANOETH','4h','0.006552000000000','0.006610000000000','1.344463792776994','1.356365334288146','205.19899157158036','205.198991571580365','test','test','0.0'),('2019-03-09 23:59:59','2019-03-16 07:59:59','NANOETH','4h','0.006633000000000','0.007230000000000','1.347108579779473','1.468354444716658','203.0919010673108','203.091901067310800','test','test','0.0'),('2019-03-17 19:59:59','2019-03-18 11:59:59','NANOETH','4h','0.007329000000000','0.007255710000000','1.374052105321069','1.360311584267858','187.48152617288434','187.481526172884344','test','test','1.00'),('2019-03-20 11:59:59','2019-03-21 15:59:59','NANOETH','4h','0.007308000000000','0.007234920000000','1.370998656198134','1.357288669636153','187.60244337686555','187.602443376865551','test','test','0.99'),('2019-03-21 23:59:59','2019-03-22 03:59:59','NANOETH','4h','0.007230000000000','0.007180000000000','1.367951992517694','1.358491743606783','189.20497821821485','189.204978218214848','test','test','0.69'),('2019-03-24 03:59:59','2019-03-24 07:59:59','NANOETH','4h','0.007249000000000','0.007176510000000','1.365849714981936','1.352191217832116','188.41905297033185','188.419052970331848','test','test','0.99'),('2019-03-24 11:59:59','2019-03-24 15:59:59','NANOETH','4h','0.007188000000000','0.007216000000000','1.362814493393086','1.368123175337300','189.5957837219096','189.595783721909612','test','test','0.0'),('2019-03-24 23:59:59','2019-03-25 03:59:59','NANOETH','4h','0.007244000000000','0.007171560000000','1.363994200491801','1.350354258486883','188.29295975866935','188.292959758669355','test','test','1.00'),('2019-03-27 07:59:59','2019-03-29 11:59:59','NANOETH','4h','0.007222000000000','0.007276000000000','1.360963102268485','1.371139231806355','188.44684329389162','188.446843293891618','test','test','0.36'),('2019-03-31 11:59:59','2019-04-07 23:59:59','NANOETH','4h','0.007498000000000','0.008035000000000','1.363224464388012','1.460857371480085','181.81174505041508','181.811745050415084','test','test','0.0'),('2019-04-08 03:59:59','2019-04-12 03:59:59','NANOETH','4h','0.008190000000000','0.008932000000000','1.384920665964028','1.510392110914615','169.09898241319027','169.098982413190271','test','test','0.0'),('2019-04-12 11:59:59','2019-04-13 03:59:59','NANOETH','4h','0.009923000000000','0.009823770000000','1.412803209286381','1.398675177193517','142.37662090964236','142.376620909642355','test','test','1.00'),('2019-04-13 19:59:59','2019-04-14 07:59:59','NANOETH','4h','0.009546000000000','0.009450540000000','1.409663646599078','1.395567010133087','147.67061037073938','147.670610370739382','test','test','1.00'),('2019-04-17 07:59:59','2019-04-18 07:59:59','NANOETH','4h','0.009745000000000','0.009647550000000','1.406531060717747','1.392465750110570','144.33361320859382','144.333613208593817','test','test','1.00'),('2019-04-19 15:59:59','2019-04-21 11:59:59','NANOETH','4h','0.009496000000000','0.009556000000000','1.403405436138374','1.412272783038996','147.78911501035955','147.789115010359552','test','test','0.0'),('2019-04-21 15:59:59','2019-04-26 03:59:59','NANOETH','4h','0.009910000000000','0.010386000000000','1.405375957671845','1.472879384094832','141.8139210566948','141.813921056694795','test','test','0.95'),('2019-06-08 11:59:59','2019-06-08 15:59:59','NANOETH','4h','0.006482000000000','0.006424000000000','1.420376719099176','1.407667393318899','219.12630655649122','219.126306556491215','test','test','0.89'),('2019-06-08 19:59:59','2019-06-09 07:59:59','NANOETH','4h','0.006592000000000','0.006526080000000','1.417552424481337','1.403376900236524','215.041326529329','215.041326529329012','test','test','0.99'),('2019-06-13 11:59:59','2019-06-13 15:59:59','NANOETH','4h','0.006472000000000','0.006407280000000','1.414402307982489','1.400258284902664','218.54176575749216','218.541765757492158','test','test','0.99'),('2019-06-13 23:59:59','2019-06-14 07:59:59','NANOETH','4h','0.006924000000000','0.006854760000000','1.411259191742528','1.397146599825103','203.8213737352005','203.821373735200496','test','test','0.99'),('2019-07-07 15:59:59','2019-07-07 19:59:59','NANOETH','4h','0.004472000000000','0.004427280000000','1.408123060205323','1.394041829603270','314.87546068992015','314.875460689920146','test','test','0.99'),('2019-07-08 03:59:59','2019-07-08 07:59:59','NANOETH','4h','0.004561000000000','0.004515390000000','1.404993897849311','1.390943958870818','308.04514313731875','308.045143137318746','test','test','0.99'),('2019-07-09 03:59:59','2019-07-09 07:59:59','NANOETH','4h','0.004488000000000','0.004443120000000','1.401871689187423','1.387852972295549','312.36000204710865','312.360002047108651','test','test','0.99'),('2019-07-13 03:59:59','2019-07-13 11:59:59','NANOETH','4h','0.004450000000000','0.004405500000000','1.398756418767007','1.384768854579337','314.3272851161814','314.327285116181372','test','test','1.00'),('2019-07-14 15:59:59','2019-07-14 19:59:59','NANOETH','4h','0.004497000000000','0.004452030000000','1.395648071169747','1.381691590458050','310.35091642645034','310.350916426450340','test','test','1.00'),('2019-07-15 03:59:59','2019-07-15 19:59:59','NANOETH','4h','0.004533000000000','0.004487670000000','1.392546631011592','1.378621164701476','307.2019922814014','307.201992281401374','test','test','0.99'),('2019-07-16 11:59:59','2019-07-31 15:59:59','NANOETH','4h','0.004481000000000','0.005844000000000','1.389452082942678','1.812086135397682','310.0763407593568','310.076340759356810','test','test','0.04'),('2019-08-09 23:59:59','2019-08-10 03:59:59','NANOETH','4h','0.005367000000000','0.005434000000000','1.483370761266012','1.501888711891095','276.38732276243934','276.387322762439339','test','test','0.0'),('2019-08-10 11:59:59','2019-08-11 11:59:59','NANOETH','4h','0.005330000000000','0.005276700000000','1.487485861404919','1.472611002790870','279.0780227776584','279.078022777658418','test','test','1.00'),('2019-08-12 15:59:59','2019-08-12 19:59:59','NANOETH','4h','0.005403000000000','0.005348970000000','1.484180337268464','1.469338533895779','274.695601937528','274.695601937528011','test','test','1.00'),('2019-08-13 03:59:59','2019-08-13 07:59:59','NANOETH','4h','0.005316000000000','0.005262840000000','1.480882158741201','1.466073337153789','278.5707597331077','278.570759733107707','test','test','1.00'),('2019-08-14 19:59:59','2019-08-14 23:59:59','NANOETH','4h','0.005355000000000','0.005301450000000','1.477591309499553','1.462815396404557','275.92741540607904','275.927415406079035','test','test','1.00'),('2019-08-15 01:59:59','2019-08-16 03:59:59','NANOETH','4h','0.005571000000000','0.005515290000000','1.474307773256221','1.459564695523659','264.6397008178462','264.639700817846176','test','test','1.00'),('2019-08-16 15:59:59','2019-08-17 11:59:59','NANOETH','4h','0.005526000000000','0.005470740000000','1.471031533760096','1.456321218422495','266.20187002535215','266.201870025352150','test','test','0.99'),('2019-08-17 19:59:59','2019-08-18 07:59:59','NANOETH','4h','0.005495000000000','0.005440050000000','1.467762574796185','1.453084949048223','267.1087488255113','267.108748825511327','test','test','0.99'),('2019-08-21 19:59:59','2019-08-22 03:59:59','NANOETH','4h','0.005419000000000','0.005364810000000','1.464500880185526','1.449855871383671','270.25297659817795','270.252976598177952','test','test','0.99'),('2019-08-22 07:59:59','2019-08-22 11:59:59','NANOETH','4h','0.005392000000000','0.005358000000000','1.461246433785114','1.452032342770891','271.0026768889307','271.002676888930694','test','test','0.63'),('2019-08-23 11:59:59','2019-08-23 15:59:59','NANOETH','4h','0.005395000000000','0.005341050000000','1.459198858004176','1.444606869424134','270.4724481935451','270.472448193545119','test','test','0.99'),('2019-08-24 19:59:59','2019-08-24 23:59:59','NANOETH','4h','0.005452000000000','0.005397480000000','1.455956193875277','1.441396631936524','267.0499255090384','267.049925509038417','test','test','0.99'),('2019-08-25 03:59:59','2019-08-25 15:59:59','NANOETH','4h','0.005442000000000','0.005430000000000','1.452720735666666','1.449517382335538','266.94611092735494','266.946110927354937','test','test','0.22'),('2019-08-25 23:59:59','2019-08-26 03:59:59','NANOETH','4h','0.005535000000000','0.005479650000000','1.452008879370860','1.437488790577151','262.3322275286106','262.332227528610588','test','test','1.00'),('2019-08-28 19:59:59','2019-09-01 03:59:59','NANOETH','4h','0.005550000000000','0.005548000000000','1.448782192972258','1.448260109299115','261.0418365715779','261.041836571577903','test','test','0.03'),('2019-09-02 11:59:59','2019-09-02 19:59:59','NANOETH','4h','0.005700000000000','0.005643000000000','1.448666174378226','1.434179512634444','254.1519604172326','254.151960417232601','test','test','0.99'),('2019-09-02 23:59:59','2019-09-03 15:59:59','NANOETH','4h','0.005690000000000','0.005633100000000','1.445446916212941','1.430992447050812','254.03284994955024','254.032849949550240','test','test','1.00'),('2019-09-26 07:59:59','2019-09-26 19:59:59','NANOETH','4h','0.004554000000000','0.004533000000000','1.442234811954690','1.435584190292185','316.69626964310277','316.696269643102767','test','test','0.46'),('2019-10-08 15:59:59','2019-10-08 19:59:59','NANOETH','4h','0.004278000000000','0.004370000000000','1.440756896029689','1.471740915299145','336.78281814625734','336.782818146257341','test','test','0.0'),('2019-10-08 23:59:59','2019-10-09 15:59:59','NANOETH','4h','0.004403000000000','0.004358970000000','1.447642233645124','1.433165811308672','328.78542667388683','328.785426673886832','test','test','1.00'),('2019-10-12 03:59:59','2019-10-12 11:59:59','NANOETH','4h','0.004282000000000','0.004239180000000','1.444425250903690','1.429980998394653','337.3249067967514','337.324906796751407','test','test','0.99'),('2019-10-13 19:59:59','2019-10-14 07:59:59','NANOETH','4h','0.004308000000000','0.004301000000000','1.441215417012793','1.438873609232132','334.54396866592214','334.543968665922137','test','test','0.23'),('2019-10-15 07:59:59','2019-10-23 03:59:59','NANOETH','4h','0.004297000000000','0.004531000000000','1.440695015283757','1.519150364033210','335.2792681600552','335.279268160055210','test','test','0.0'),('2019-10-23 07:59:59','2019-10-23 15:59:59','NANOETH','4h','0.004593000000000','0.004550000000000','1.458129537228080','1.444478422466311','317.4677851574308','317.467785157430797','test','test','0.93'),('2019-10-24 11:59:59','2019-10-24 15:59:59','NANOETH','4h','0.004572000000000','0.004596000000000','1.455095956169909','1.462734255152428','318.2624576049669','318.262457604966926','test','test','0.0'),('2019-10-27 19:59:59','2019-10-27 23:59:59','NANOETH','4h','0.004618000000000','0.004615000000000','1.456793355943802','1.455846976544098','315.4597999012131','315.459799901213103','test','test','0.06'),('2019-10-29 15:59:59','2019-10-29 19:59:59','NANOETH','4h','0.004658000000000','0.004611420000000','1.456583049410534','1.442017218916429','312.70567827619885','312.705678276198853','test','test','1.00'),('2019-10-31 11:59:59','2019-10-31 19:59:59','NANOETH','4h','0.004754000000000','0.004706460000000','1.453346198189622','1.438812736207726','305.71018051948295','305.710180519482947','test','test','1.00'),('2019-11-01 19:59:59','2019-11-02 15:59:59','NANOETH','4h','0.004754000000000','0.004706460000000','1.450116539971423','1.435615374571709','305.030824562773','305.030824562772978','test','test','1.00'),('2019-11-03 15:59:59','2019-11-04 11:59:59','NANOETH','4h','0.004690000000000','0.004671000000000','1.446894058771487','1.441032441049385','308.50619590010376','308.506195900103762','test','test','0.40'),('2019-11-04 19:59:59','2019-11-13 23:59:59','NANOETH','4h','0.004806000000000','0.005272000000000','1.445591477055464','1.585759106749148','300.7889049220691','300.788904922069094','test','test','0.0'),('2019-11-14 23:59:59','2019-11-15 03:59:59','NANOETH','4h','0.005300000000000','0.005247000000000','1.476739839209616','1.461972440817520','278.630158341437','278.630158341436982','test','test','1.00'),('2019-11-20 19:59:59','2019-11-20 23:59:59','NANOETH','4h','0.005193000000000','0.005154000000000','1.473458195122483','1.462392362345711','283.7393019685121','283.739301968512109','test','test','0.75'),('2019-11-21 07:59:59','2019-11-21 11:59:59','NANOETH','4h','0.005291000000000','0.005238090000000','1.470999121172090','1.456289129960369','278.01911192063693','278.019111920636931','test','test','0.99'),('2019-11-21 15:59:59','2019-11-22 07:59:59','NANOETH','4h','0.005317000000000','0.005263830000000','1.467730234236152','1.453052931893790','276.04480613807635','276.044806138076353','test','test','0.99'),('2019-11-22 11:59:59','2019-11-22 15:59:59','NANOETH','4h','0.005287000000000','0.005244000000000','1.464468611493404','1.452557858647893','276.99425222118487','276.994252221184865','test','test','0.81'),('2019-11-24 23:59:59','2019-11-25 03:59:59','NANOETH','4h','0.005373000000000','0.005319270000000','1.461821777527735','1.447203559752458','272.0680769640304','272.068076964030411','test','test','1.00'),('2019-11-25 07:59:59','2019-11-25 11:59:59','NANOETH','4h','0.005383000000000','0.005329170000000','1.458573284688785','1.443987551841897','270.9591834829621','270.959183482962089','test','test','1.00'),('2019-11-25 15:59:59','2019-11-25 19:59:59','NANOETH','4h','0.005426000000000','0.005371740000000','1.455332010722810','1.440778690615582','268.21452464482303','268.214524644823030','test','test','1.00'),('2019-11-26 15:59:59','2019-11-28 03:59:59','NANOETH','4h','0.005473000000000','0.005418270000000','1.452097939587871','1.437576960191992','265.32028861463016','265.320288614630158','test','test','1.00'),('2019-11-29 03:59:59','2019-12-04 03:59:59','NANOETH','4h','0.005580000000000','0.005662000000000','1.448871055277675','1.470162708778171','259.6543109816622','259.654310981662206','test','test','0.10'),('2019-12-05 03:59:59','2019-12-05 07:59:59','NANOETH','4h','0.005591000000000','0.005632000000000','1.453602533833341','1.464262112421638','259.98972166577374','259.989721665773743','test','test','0.0'),('2019-12-09 15:59:59','2019-12-09 19:59:59','NANOETH','4h','0.005583000000000','0.005578000000000','1.455971329075185','1.454667396306893','260.78655365846043','260.786553658460434','test','test','0.08'),('2019-12-20 19:59:59','2019-12-21 11:59:59','NANOETH','4h','0.005443000000000','0.005388570000000','1.455681566237786','1.441124750575408','267.4410373392957','267.441037339295690','test','test','1.00'),('2019-12-30 19:59:59','2019-12-30 23:59:59','NANOETH','4h','0.005211000000000','0.005158890000000','1.452446718312814','1.437922251129686','278.72706166049','278.727061660489994','test','test','1.00');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 21:01:35
