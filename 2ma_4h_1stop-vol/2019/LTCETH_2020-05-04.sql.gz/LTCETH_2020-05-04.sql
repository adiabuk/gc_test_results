-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 07:59:59','2019-01-14 15:59:59','LTCETH','4h','0.232610000000000','0.251430000000000','1.297777777777778','1.402778327099723','5.579200282781383','5.579200282781383','test','test','0.0'),('2019-01-15 23:59:59','2019-01-16 15:59:59','LTCETH','4h','0.258350000000000','0.256340000000000','1.321111233182654','1.310832798583478','5.113649054316448','5.113649054316448','test','test','0.77'),('2019-01-16 19:59:59','2019-01-17 07:59:59','LTCETH','4h','0.257580000000000','0.255004200000000','1.318827136605060','1.305638865239009','5.120068082168879','5.120068082168879','test','test','1.00'),('2019-01-17 15:59:59','2019-02-13 15:59:59','LTCETH','4h','0.255040000000000','0.338760000000000','1.315896409634826','1.747855503951905','5.159568732884357','5.159568732884357','test','test','0.0'),('2019-02-15 11:59:59','2019-02-17 11:59:59','LTCETH','4h','0.346280000000000','0.342817200000000','1.411887319483066','1.397768446288235','4.077299640415462','4.077299640415462','test','test','0.99'),('2019-02-20 11:59:59','2019-02-21 07:59:59','LTCETH','4h','0.346600000000000','0.343134000000000','1.408749792106437','1.394662294185372','4.064482954721398','4.064482954721398','test','test','1.00'),('2019-02-27 23:59:59','2019-02-28 03:59:59','LTCETH','4h','0.335070000000000','0.334360000000000','1.405619237012867','1.402640785769010','4.1950017519111436','4.195001751911144','test','test','0.21'),('2019-02-28 15:59:59','2019-03-20 11:59:59','LTCETH','4h','0.336440000000000','0.432480000000000','1.404957358958677','1.806015808472383','4.1759522023501265','4.175952202350127','test','test','0.0'),('2019-03-20 19:59:59','2019-03-21 11:59:59','LTCETH','4h','0.435300000000000','0.430947000000000','1.494081458850611','1.479140644262105','3.432302914887689','3.432302914887689','test','test','0.99'),('2019-03-21 15:59:59','2019-03-22 07:59:59','LTCETH','4h','0.434120000000000','0.429778800000000','1.490761277830943','1.475853665052633','3.4339843311318137','3.433984331131814','test','test','0.99'),('2019-03-22 11:59:59','2019-03-29 07:59:59','LTCETH','4h','0.432450000000000','0.433750000000000','1.487448474991319','1.491919935316186','3.4395848652822725','3.439584865282272','test','test','0.0'),('2019-03-29 11:59:59','2019-03-29 15:59:59','LTCETH','4h','0.435560000000000','0.432430000000000','1.488442132841289','1.477745962679214','3.4173067610462144','3.417306761046214','test','test','0.71'),('2019-04-02 07:59:59','2019-04-08 07:59:59','LTCETH','4h','0.448070000000000','0.493540000000000','1.486065206138606','1.636870626994995','3.316591617690552','3.316591617690552','test','test','0.39'),('2019-04-10 23:59:59','2019-04-11 07:59:59','LTCETH','4h','0.498150000000000','0.493730000000000','1.519577521884470','1.506094569667810','3.0504416779774566','3.050441677977457','test','test','0.88'),('2019-04-14 23:59:59','2019-04-15 11:59:59','LTCETH','4h','0.499060000000000','0.494069400000000','1.516581310280768','1.501415497177960','3.0388757068904897','3.038875706890490','test','test','1.00'),('2019-04-15 23:59:59','2019-04-16 03:59:59','LTCETH','4h','0.488330000000000','0.485630000000000','1.513211129591255','1.504844512652102','3.0987470145009626','3.098747014500963','test','test','0.55'),('2019-04-26 03:59:59','2019-04-26 15:59:59','LTCETH','4h','0.471700000000000','0.466983000000000','1.511351881382554','1.496238362568728','3.2040531723183254','3.204053172318325','test','test','1.00'),('2019-04-26 19:59:59','2019-04-27 07:59:59','LTCETH','4h','0.467870000000000','0.464160000000000','1.507993321646149','1.496035608556386','3.223103258696109','3.223103258696109','test','test','0.79'),('2019-04-30 23:59:59','2019-05-01 03:59:59','LTCETH','4h','0.459000000000000','0.454640000000000','1.505336052070646','1.491036999375596','3.279599241983977','3.279599241983977','test','test','0.94'),('2019-05-03 11:59:59','2019-05-05 11:59:59','LTCETH','4h','0.470640000000000','0.465933600000000','1.502158484805079','1.487136899957028','3.1917356892849718','3.191735689284972','test','test','0.99'),('2019-05-11 11:59:59','2019-05-12 03:59:59','LTCETH','4h','0.457700000000000','0.457310000000000','1.498820354838845','1.497543230219253','3.2746785117737502','3.274678511773750','test','test','0.72'),('2019-05-12 11:59:59','2019-05-12 15:59:59','LTCETH','4h','0.460670000000000','0.456063300000000','1.498536549367825','1.483551183874147','3.252950158177925','3.252950158177925','test','test','1.00'),('2019-05-24 11:59:59','2019-05-30 23:59:59','LTCETH','4h','0.395420000000000','0.424110000000000','1.495206468147008','1.603692315021566','3.781312195000273','3.781312195000273','test','test','0.0'),('2019-05-31 15:59:59','2019-06-04 07:59:59','LTCETH','4h','0.422760000000000','0.418532400000000','1.519314434119132','1.504121289777941','3.5937989263864405','3.593798926386440','test','test','0.99'),('2019-06-04 11:59:59','2019-06-04 15:59:59','LTCETH','4h','0.423440000000000','0.419205600000000','1.515938179821089','1.500778798022878','3.5800542693677717','3.580054269367772','test','test','1.00'),('2019-06-04 19:59:59','2019-06-05 19:59:59','LTCETH','4h','0.421230000000000','0.420430000000000','1.512569428310376','1.509696756509583','3.590839750992037','3.590839750992037','test','test','0.18'),('2019-06-06 19:59:59','2019-06-16 11:59:59','LTCETH','4h','0.433740000000000','0.497010000000000','1.511931056799088','1.732477646838462','3.485800379949021','3.485800379949021','test','test','0.0'),('2019-06-18 15:59:59','2019-06-20 19:59:59','LTCETH','4h','0.500760000000000','0.499320000000000','1.560941410141171','1.556452721686416','3.117144760246768','3.117144760246768','test','test','0.28'),('2019-07-15 03:59:59','2019-07-15 07:59:59','LTCETH','4h','0.401160000000000','0.397148400000000','1.559943923817892','1.544344484579713','3.8885829190794','3.888582919079400','test','test','1.00'),('2019-07-15 15:59:59','2019-07-15 19:59:59','LTCETH','4h','0.398590000000000','0.394604100000000','1.556477381764964','1.540912607947314','3.904958432888341','3.904958432888341','test','test','0.99'),('2019-07-16 15:59:59','2019-07-16 19:59:59','LTCETH','4h','0.398680000000000','0.394693200000000','1.553018543138819','1.537488357707431','3.895401181746813','3.895401181746813','test','test','1.00'),('2019-07-17 15:59:59','2019-07-23 19:59:59','LTCETH','4h','0.421170000000000','0.428760000000000','1.549567390820733','1.577492495876481','3.6791969770418906','3.679196977041891','test','test','0.06'),('2019-07-24 03:59:59','2019-07-25 07:59:59','LTCETH','4h','0.432000000000000','0.427680000000000','1.555772969722010','1.540215240024790','3.60132631880095','3.601326318800950','test','test','0.99'),('2019-07-27 11:59:59','2019-07-27 15:59:59','LTCETH','4h','0.431760000000000','0.427442400000000','1.552315696455962','1.536792539491402','3.5953207718546456','3.595320771854646','test','test','0.99'),('2019-07-27 23:59:59','2019-07-28 03:59:59','LTCETH','4h','0.428250000000000','0.426110000000000','1.548866106019393','1.541126296406126','3.616733464143357','3.616733464143357','test','test','0.49'),('2019-07-29 11:59:59','2019-07-29 15:59:59','LTCETH','4h','0.426630000000000','0.426500000000000','1.547146148327556','1.546674711721404','3.626435431937641','3.626435431937641','test','test','0.03'),('2019-07-29 19:59:59','2019-08-02 19:59:59','LTCETH','4h','0.430430000000000','0.430160000000000','1.547041384637300','1.546070956986225','3.594176485461747','3.594176485461747','test','test','0.49'),('2019-08-26 19:59:59','2019-08-26 23:59:59','LTCETH','4h','0.393910000000000','0.390000000000000','1.546825734048172','1.531471748061200','3.9268506360543576','3.926850636054358','test','test','0.99'),('2019-09-01 19:59:59','2019-09-01 23:59:59','LTCETH','4h','0.389520000000000','0.385624800000000','1.543413737162178','1.527979599790556','3.962347856752357','3.962347856752357','test','test','0.99'),('2019-09-03 23:59:59','2019-09-04 03:59:59','LTCETH','4h','0.386390000000000','0.382526100000000','1.539983928857373','1.524584089568799','3.9855688005832794','3.985568800583279','test','test','1.00'),('2019-09-06 23:59:59','2019-09-07 03:59:59','LTCETH','4h','0.384260000000000','0.382010000000000','1.536561742348801','1.527564542743625','3.9987553800780753','3.998755380078075','test','test','0.58'),('2019-09-07 15:59:59','2019-09-07 19:59:59','LTCETH','4h','0.396130000000000','0.392168700000000','1.534562364658762','1.519216741012174','3.8738857563394897','3.873885756339490','test','test','1.00'),('2019-09-10 03:59:59','2019-09-11 23:59:59','LTCETH','4h','0.393820000000000','0.391000000000000','1.531152226070631','1.520188208810159','3.887949383146187','3.887949383146187','test','test','0.93'),('2019-10-20 03:59:59','2019-10-20 11:59:59','LTCETH','4h','0.313190000000000','0.310500000000000','1.528715777790527','1.515585583843541','4.881112991444576','4.881112991444576','test','test','0.85'),('2019-10-20 15:59:59','2019-10-21 11:59:59','LTCETH','4h','0.312500000000000','0.311750000000000','1.525797956913419','1.522136041816827','4.88255346212294','4.882553462122940','test','test','0.65'),('2019-10-21 15:59:59','2019-10-22 23:59:59','LTCETH','4h','0.314380000000000','0.311540000000000','1.524984198003065','1.511208019103871','4.850767218026162','4.850767218026162','test','test','0.90'),('2019-10-23 03:59:59','2019-10-23 15:59:59','LTCETH','4h','0.315060000000000','0.311909400000000','1.521922824914355','1.506703596665212','4.830580920822558','4.830580920822558','test','test','1.00'),('2019-10-25 19:59:59','2019-10-26 03:59:59','LTCETH','4h','0.314080000000000','0.314510000000000','1.518540774192323','1.520619774870184','4.834885297352023','4.834885297352023','test','test','0.06'),('2019-10-27 15:59:59','2019-10-28 07:59:59','LTCETH','4h','0.326630000000000','0.323363700000000','1.519002774342959','1.503812746599529','4.650530491207051','4.650530491207051','test','test','1.0'),('2019-10-30 03:59:59','2019-10-30 07:59:59','LTCETH','4h','0.315060000000000','0.316810000000000','1.515627212622197','1.524045760270546','4.810598656199444','4.810598656199444','test','test','0.0'),('2019-10-31 03:59:59','2019-11-01 23:59:59','LTCETH','4h','0.318440000000000','0.318490000000000','1.517498000988496','1.517736271620481','4.765412639707626','4.765412639707626','test','test','0.04'),('2019-11-02 19:59:59','2019-11-03 03:59:59','LTCETH','4h','0.319080000000000','0.317290000000000','1.517550950017827','1.509037673721814','4.756020277102379','4.756020277102379','test','test','0.56'),('2019-11-03 23:59:59','2019-11-08 15:59:59','LTCETH','4h','0.321250000000000','0.328600000000000','1.515659110840935','1.550336447695973','4.718005014290848','4.718005014290848','test','test','0.04'),('2019-11-08 23:59:59','2019-11-11 11:59:59','LTCETH','4h','0.329020000000000','0.331400000000000','1.523365185697610','1.534384604401519','4.630007858785515','4.630007858785515','test','test','0.0'),('2019-11-25 07:59:59','2019-11-25 11:59:59','LTCETH','4h','0.320120000000000','0.317430000000000','1.525813945409590','1.512992380018012','4.766381186460046','4.766381186460046','test','test','0.84'),('2019-11-26 15:59:59','2019-11-26 19:59:59','LTCETH','4h','0.320020000000000','0.320920000000000','1.522964708655906','1.527247779207091','4.758967279094762','4.758967279094762','test','test','0.0'),('2019-12-01 15:59:59','2019-12-01 19:59:59','LTCETH','4h','0.315680000000000','0.315390000000000','1.523916502111725','1.522516553475092','4.827409091838965','4.827409091838965','test','test','0.09'),('2019-12-18 15:59:59','2019-12-29 23:59:59','LTCETH','4h','0.309940000000000','0.321130000000000','1.523605402414695','1.578613289273508','4.915807583450652','4.915807583450652','test','test','0.80'),('2019-12-30 07:59:59','2019-12-30 19:59:59','LTCETH','4h','0.323710000000000','0.320720000000000','1.535829377272209','1.521643439741568','4.744460712589075','4.744460712589075','test','test','0.92'),('2019-12-31 15:59:59','2019-12-31 19:59:59','LTCETH','4h','0.320660000000000','0.320510000000000','1.532676946709844','1.531959983128460','4.779757209224239','4.779757209224239','test','test','0.04');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:17:30
