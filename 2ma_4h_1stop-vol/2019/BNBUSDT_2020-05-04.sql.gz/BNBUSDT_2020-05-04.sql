-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 15:59:59','2019-01-03 11:59:59','BNBUSDT','4h','5.907100000000000','5.848028999999999','222.222222222222200','219.999999999999972','37.619512488737655','37.619512488737655','test','test','1.00'),('2019-01-04 07:59:59','2019-01-10 07:59:59','BNBUSDT','4h','5.865900000000000','6.059900000000000','221.728395061728406','229.061508248447439','37.79955250886111','37.799552508861112','test','test','0.0'),('2019-01-14 23:59:59','2019-01-15 03:59:59','BNBUSDT','4h','6.058300000000000','5.997717000000000','223.357975769888185','221.124396012189294','36.86809431191723','36.868094311917233','test','test','1.00'),('2019-01-16 23:59:59','2019-01-17 03:59:59','BNBUSDT','4h','6.091100000000000','6.030189000000000','222.861624712621762','220.633008465495550','36.588075177327866','36.588075177327866','test','test','0.99'),('2019-01-17 19:59:59','2019-01-28 07:59:59','BNBUSDT','4h','6.147800000000000','6.739800000000000','222.366376657704819','243.779060053612483','36.170073303898114','36.170073303898114','test','test','0.0'),('2019-02-01 11:59:59','2019-02-24 15:59:59','BNBUSDT','4h','6.574400000000000','9.786300000000001','227.124750745684310','338.085748999527084','34.546840889767026','34.546840889767026','test','test','0.78'),('2019-02-28 11:59:59','2019-02-28 19:59:59','BNBUSDT','4h','10.347600000000000','10.244123999999999','251.782750357649348','249.264922854072864','24.332478097109412','24.332478097109412','test','test','1.00'),('2019-02-28 23:59:59','2019-03-21 15:59:59','BNBUSDT','4h','10.277900000000001','14.458200000000000','251.223233134632352','353.402518929658868','24.443050928169406','24.443050928169406','test','test','0.0'),('2019-03-22 23:59:59','2019-03-24 03:59:59','BNBUSDT','4h','15.150200000000000','14.998697999999999','273.929741089082711','271.190443678191855','18.080932336806296','18.080932336806296','test','test','1.00'),('2019-03-24 11:59:59','2019-03-25 11:59:59','BNBUSDT','4h','17.040199999999999','16.869797999999999','273.321008331106952','270.587798247795888','16.039777017353494','16.039777017353494','test','test','0.99'),('2019-03-27 23:59:59','2019-03-29 19:59:59','BNBUSDT','4h','16.600000000000001','16.434000000000001','272.713628312593414','269.986492029467456','16.428531826059842','16.428531826059842','test','test','1.00'),('2019-03-29 23:59:59','2019-03-30 03:59:59','BNBUSDT','4h','16.475300000000001','16.310547000000000','272.107598027454344','269.386522047179824','16.516093669156515','16.516093669156515','test','test','1.00'),('2019-03-30 15:59:59','2019-04-08 11:59:59','BNBUSDT','4h','16.510999999999999','17.836900000000000','271.502914476282172','293.305695307491817','16.443759583082926','16.443759583082926','test','test','0.0'),('2019-04-09 23:59:59','2019-04-10 03:59:59','BNBUSDT','4h','18.298400000000001','18.115416000000000','276.347976883217655','273.584497114385499','15.102302763258955','15.102302763258955','test','test','1.00'),('2019-04-10 07:59:59','2019-04-10 23:59:59','BNBUSDT','4h','18.302099999999999','18.239999999999998','275.733870267921588','274.798290561568876','15.065695754471978','15.065695754471978','test','test','0.33'),('2019-04-12 19:59:59','2019-04-12 23:59:59','BNBUSDT','4h','18.270399999999999','18.333300000000001','275.525963666509881','276.474524350163449','15.08045601992895','15.080456019928951','test','test','0.0'),('2019-04-13 19:59:59','2019-04-24 07:59:59','BNBUSDT','4h','18.371700000000001','21.444099999999999','275.736754929544020','321.849722474492523','15.008777354819859','15.008777354819859','test','test','0.0'),('2019-04-24 11:59:59','2019-04-24 15:59:59','BNBUSDT','4h','22.004500000000000','22.086600000000001','285.984081050643738','287.051103389449793','12.996618012254027','12.996618012254027','test','test','0.0'),('2019-04-25 19:59:59','2019-04-25 23:59:59','BNBUSDT','4h','22.881300000000000','22.652487000000001','286.221197125933941','283.358985154674656','12.50895697036156','12.508956970361560','test','test','0.99'),('2019-04-26 03:59:59','2019-04-26 15:59:59','BNBUSDT','4h','23.489899999999999','23.255001000000000','285.585150021209643','282.729298520997588','12.15778483608741','12.157784836087410','test','test','0.99'),('2019-04-26 23:59:59','2019-04-27 03:59:59','BNBUSDT','4h','23.055499999999999','22.824945000000000','284.950516354495846','282.101011190950885','12.359329286048702','12.359329286048702','test','test','0.99'),('2019-04-27 19:59:59','2019-04-29 11:59:59','BNBUSDT','4h','22.637699999999999','22.411322999999999','284.317292984819176','281.474120054970967','12.559460236014223','12.559460236014223','test','test','0.99'),('2019-05-02 11:59:59','2019-05-04 15:59:59','BNBUSDT','4h','22.739300000000000','22.677000000000000','283.685476778186228','282.908249457939689','12.475558912463718','12.475558912463718','test','test','0.27'),('2019-05-05 23:59:59','2019-05-06 03:59:59','BNBUSDT','4h','22.977699999999999','22.747923000000000','283.512759595909245','280.677631999950165','12.33860480360999','12.338604803609989','test','test','0.99'),('2019-05-13 03:59:59','2019-05-29 07:59:59','BNBUSDT','4h','21.890100000000000','32.824399999999997','282.882731241251633','424.185176100398735','12.922861532896224','12.922861532896224','test','test','0.0'),('2019-05-29 19:59:59','2019-05-30 19:59:59','BNBUSDT','4h','33.473199999999999','33.138467999999996','314.283274543284392','311.140441797851508','9.389101566127064','9.389101566127064','test','test','1.00'),('2019-05-31 19:59:59','2019-06-03 03:59:59','BNBUSDT','4h','31.916899999999998','32.081499999999998','313.584867266521485','315.202069098531183','9.825041506741616','9.825041506741616','test','test','0.0'),('2019-06-06 11:59:59','2019-06-06 15:59:59','BNBUSDT','4h','31.897099999999998','31.578128999999997','313.944245451412542','310.804802996898388','9.842407160883358','9.842407160883358','test','test','1.00'),('2019-06-08 11:59:59','2019-06-08 15:59:59','BNBUSDT','4h','32.249200000000002','31.926708000000001','313.246591572631644','310.114125656905344','9.71331355731713','9.713313557317131','test','test','1.00'),('2019-06-08 23:59:59','2019-06-09 03:59:59','BNBUSDT','4h','31.733300000000000','31.415966999999998','312.550488035803539','309.424983155445489','9.849290431055186','9.849290431055186','test','test','1.00'),('2019-06-10 15:59:59','2019-06-11 11:59:59','BNBUSDT','4h','31.620000000000001','31.303799999999999','311.855931395723985','308.737372081766750','9.86261642617723','9.862616426177230','test','test','1.00'),('2019-06-11 23:59:59','2019-06-14 11:59:59','BNBUSDT','4h','31.888900000000000','31.729299999999999','311.162918214844638','309.605586298501009','9.757718774082663','9.757718774082663','test','test','0.50'),('2019-06-15 07:59:59','2019-06-15 15:59:59','BNBUSDT','4h','33.049999999999997','32.719499999999996','310.816844455657133','307.708676011100579','9.404443100019884','9.404443100019884','test','test','1.00'),('2019-06-17 07:59:59','2019-06-17 11:59:59','BNBUSDT','4h','33.579999999999998','33.244199999999999','310.126140356866756','307.024878953298071','9.235441940347432','9.235441940347432','test','test','0.99'),('2019-06-17 15:59:59','2019-06-25 23:59:59','BNBUSDT','4h','33.849800000000002','36.094099999999997','309.436971156073753','329.953174925832343','9.141471180215946','9.141471180215946','test','test','0.06'),('2019-06-26 07:59:59','2019-06-26 19:59:59','BNBUSDT','4h','37.454900000000002','37.080351000000000','313.996127549353446','310.856166273859913','8.38331239836052','8.383312398360520','test','test','1.00'),('2019-07-08 07:59:59','2019-07-08 19:59:59','BNBUSDT','4h','33.718499999999999','33.413400000000003','313.298358377021543','310.463495345130184','9.291586469653797','9.291586469653797','test','test','0.90'),('2019-07-22 07:59:59','2019-07-22 11:59:59','BNBUSDT','4h','31.940000000000001','31.620600000000000','312.668388814379000','309.541704926235184','9.789241979160268','9.789241979160268','test','test','1.00'),('2019-08-01 15:59:59','2019-08-01 19:59:59','BNBUSDT','4h','28.489899999999999','28.284800000000001','311.973570172569282','309.727659192102749','10.950321699008045','10.950321699008045','test','test','0.71'),('2019-08-01 23:59:59','2019-08-02 03:59:59','BNBUSDT','4h','28.708800000000000','28.421711999999999','311.474478843576719','308.359734055140962','10.849442639315356','10.849442639315356','test','test','1.00'),('2019-08-05 11:59:59','2019-08-05 15:59:59','BNBUSDT','4h','28.300000000000001','28.049800000000001','310.782313335035440','308.034690197352575','10.981707184983584','10.981707184983584','test','test','0.88'),('2019-08-07 15:59:59','2019-08-13 15:59:59','BNBUSDT','4h','28.730000000000000','29.267199999999999','310.171730415550371','315.971391173616212','10.796092252542651','10.796092252542651','test','test','0.0'),('2019-08-19 07:59:59','2019-08-19 19:59:59','BNBUSDT','4h','28.968299999999999','28.678616999999999','311.460543917342761','308.345938478169330','10.751771554331555','10.751771554331555','test','test','1.00'),('2019-08-19 23:59:59','2019-08-20 03:59:59','BNBUSDT','4h','28.793099999999999','28.505168999999999','310.768409375304259','307.660725281551208','10.793155630178907','10.793155630178907','test','test','1.00'),('2019-09-18 03:59:59','2019-09-19 03:59:59','BNBUSDT','4h','21.640699999999999','21.424292999999999','310.077812910025784','306.977034780925521','14.328455775923413','14.328455775923413','test','test','1.00'),('2019-10-09 07:59:59','2019-10-11 07:59:59','BNBUSDT','4h','16.963500000000000','16.793865000000000','309.388751103559002','306.294863592523427','18.238497427037995','18.238497427037995','test','test','0.99'),('2019-10-12 15:59:59','2019-10-16 15:59:59','BNBUSDT','4h','17.298600000000000','17.608799999999999','308.701220545551109','314.236877686199989','17.84544532768843','17.845445327688431','test','test','0.74'),('2019-10-17 07:59:59','2019-10-20 07:59:59','BNBUSDT','4h','18.095300000000002','17.914347000000003','309.931366576806454','306.832052911038431','17.127727452808543','17.127727452808543','test','test','0.99'),('2019-10-20 15:59:59','2019-10-21 15:59:59','BNBUSDT','4h','18.205200000000001','18.023148000000003','309.242630206635738','306.150203904569423','16.98650002233624','16.986500022336241','test','test','0.99'),('2019-10-21 19:59:59','2019-10-23 03:59:59','BNBUSDT','4h','18.181600000000000','17.999783999999998','308.555424361732150','305.469870118114784','16.970751988919137','16.970751988919137','test','test','1.00'),('2019-10-25 15:59:59','2019-10-26 19:59:59','BNBUSDT','4h','18.433199999999999','18.248867999999998','307.869745640928272','304.791048184518957','16.701915328913497','16.701915328913497','test','test','1.00'),('2019-10-27 07:59:59','2019-11-07 11:59:59','BNBUSDT','4h','18.942000000000000','20.150900000000000','307.185590650615097','326.790524688073049','16.217167704076395','16.217167704076395','test','test','0.55'),('2019-11-08 03:59:59','2019-11-08 07:59:59','BNBUSDT','4h','20.440100000000001','20.235699000000000','311.542242658939074','308.426820232349655','15.241718125593273','15.241718125593273','test','test','1.00'),('2019-11-10 07:59:59','2019-11-10 15:59:59','BNBUSDT','4h','20.195900000000002','20.069600000000001','310.849926564141413','308.905950523209754','15.391734290828404','15.391734290828404','test','test','0.62'),('2019-11-10 19:59:59','2019-11-11 07:59:59','BNBUSDT','4h','20.541799999999999','20.336381999999997','310.417931888378860','307.313752569495023','15.111525372089051','15.111525372089051','test','test','1.00'),('2019-11-12 03:59:59','2019-11-12 15:59:59','BNBUSDT','4h','20.250000000000000','20.219999999999999','309.728114261960229','309.269257796386967','15.295215519109147','15.295215519109147','test','test','0.14'),('2019-11-12 23:59:59','2019-11-13 01:59:59','BNBUSDT','4h','20.979800000000001','20.770002000000002','309.626146158499466','306.529884696914451','14.758298275412514','14.758298275412514','test','test','0.99'),('2019-11-13 07:59:59','2019-11-14 07:59:59','BNBUSDT','4h','21.277400000000000','21.064626000000001','308.938088055925050','305.848707175365803','14.519541299967338','14.519541299967338','test','test','0.99'),('2019-11-14 15:59:59','2019-11-15 03:59:59','BNBUSDT','4h','21.269400000000001','21.056706000000002','308.251558971356360','305.169043381642780','14.492724711151059','14.492724711151059','test','test','0.99'),('2019-12-28 19:59:59','2019-12-31 19:59:59','BNBUSDT','4h','13.693400000000000','13.668100000000001','307.566555506975533','306.998293873318005','22.46093413666259','22.460934136662591','test','test','0.58'),('2020-01-01 03:59:59','2020-01-01 15:59:59','BNBUSDT','4h','13.817000000000000','13.822300000000000','307.440275143940482','307.558204756610621','22.25087031511475','22.250870315114749','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:06:14
