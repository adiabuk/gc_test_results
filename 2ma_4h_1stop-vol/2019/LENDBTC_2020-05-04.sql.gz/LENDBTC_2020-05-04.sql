-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 23:59:59','2019-01-04 03:59:59','LENDBTC','4h','0.000002090000000','0.000002090000000','0.033333333333333','0.033333333333333','15948.96331738437','15948.963317384370384','test','test','0.0'),('2019-01-04 07:59:59','2019-01-04 11:59:59','LENDBTC','4h','0.000002090000000','0.000002090000000','0.033333333333333','0.033333333333333','15948.96331738437','15948.963317384370384','test','test','0.0'),('2019-01-09 11:59:59','2019-01-09 15:59:59','LENDBTC','4h','0.000002110000000','0.000002088900000','0.033333333333333','0.033000000000000','15797.78830963665','15797.788309636649501','test','test','1.00'),('2019-01-13 11:59:59','2019-01-13 19:59:59','LENDBTC','4h','0.000002080000000','0.000002060000000','0.033259259259259','0.032939458689458','15990.028490028526','15990.028490028525994','test','test','0.96'),('2019-01-13 23:59:59','2019-01-20 11:59:59','LENDBTC','4h','0.000002100000000','0.000002220000000','0.033188192465970','0.035084660606883','15803.901174271534','15803.901174271533819','test','test','0.0'),('2019-01-22 19:59:59','2019-01-23 19:59:59','LENDBTC','4h','0.000002350000000','0.000002326500000','0.033609629830618','0.033273533532312','14301.970140688321','14301.970140688321408','test','test','0.99'),('2019-01-25 07:59:59','2019-01-27 15:59:59','LENDBTC','4h','0.000002330000000','0.000002306700000','0.033534941764327','0.033199592346684','14392.678868810011','14392.678868810011409','test','test','0.99'),('2019-02-02 19:59:59','2019-02-02 23:59:59','LENDBTC','4h','0.000002290000000','0.000002267100000','0.033460419671518','0.033125815474803','14611.536974461913','14611.536974461912905','test','test','0.99'),('2019-02-09 19:59:59','2019-02-09 23:59:59','LENDBTC','4h','0.000002170000000','0.000002148300000','0.033386063183359','0.033052202551525','15385.282572976444','15385.282572976444499','test','test','1.00'),('2019-02-15 07:59:59','2019-02-15 11:59:59','LENDBTC','4h','0.000002110000000','0.000002120000000','0.033311871931840','0.033469748102133','15787.617029308161','15787.617029308161364','test','test','0.0'),('2019-02-21 23:59:59','2019-02-22 03:59:59','LENDBTC','4h','0.000002190000000','0.000002168100000','0.033346955525239','0.033013485969987','15226.920331159205','15226.920331159204579','test','test','1.00'),('2019-02-22 15:59:59','2019-02-22 19:59:59','LENDBTC','4h','0.000002180000000','0.000002158200000','0.033272851179627','0.032940122667831','15262.77577047115','15262.775770471149372','test','test','0.99'),('2019-03-01 19:59:59','2019-03-01 23:59:59','LENDBTC','4h','0.000002070000000','0.000002049300000','0.033198911510339','0.032866922395236','16038.121502579279','16038.121502579278967','test','test','1.00'),('2019-03-02 11:59:59','2019-03-07 07:59:59','LENDBTC','4h','0.000002050000000','0.000002170000000','0.033125136151427','0.035064168511511','16158.603000696263','16158.603000696262825','test','test','0.0'),('2019-03-08 03:59:59','2019-03-08 23:59:59','LENDBTC','4h','0.000002260000000','0.000002237400000','0.033556032231446','0.033220471909132','14847.801872321239','14847.801872321238989','test','test','1.00'),('2019-03-10 03:59:59','2019-03-10 07:59:59','LENDBTC','4h','0.000002340000000','0.000002316600000','0.033481463270932','0.033146648638223','14308.317637150332','14308.317637150332303','test','test','1.00'),('2019-03-10 15:59:59','2019-03-11 15:59:59','LENDBTC','4h','0.000002360000000','0.000002336400000','0.033407060019219','0.033072989419027','14155.533906448587','14155.533906448587004','test','test','1.00'),('2019-03-12 11:59:59','2019-03-16 23:59:59','LENDBTC','4h','0.000002340000000','0.000002340000000','0.033332822108065','0.033332822108065','14244.795772677302','14244.795772677302011','test','test','0.85'),('2019-03-26 23:59:59','2019-03-27 03:59:59','LENDBTC','4h','0.000002240000000','0.000002260000000','0.033332822108065','0.033630436591173','14880.72415538611','14880.724155386109487','test','test','0.0'),('2019-03-27 07:59:59','2019-04-02 07:59:59','LENDBTC','4h','0.000002270000000','0.000002310000000','0.033398958659867','0.033987486565768','14713.197647518353','14713.197647518352824','test','test','0.0'),('2019-04-05 15:59:59','2019-04-06 03:59:59','LENDBTC','4h','0.000002390000000','0.000002366100000','0.033529742638956','0.033194445212566','14029.181020483586','14029.181020483585598','test','test','0.99'),('2019-04-07 23:59:59','2019-04-08 03:59:59','LENDBTC','4h','0.000002370000000','0.000002346300000','0.033455232099758','0.033120679778760','14116.131687661604','14116.131687661603792','test','test','0.99'),('2019-04-14 19:59:59','2019-04-14 23:59:59','LENDBTC','4h','0.000002210000000','0.000002187900000','0.033380887139536','0.033047078268141','15104.47381879467','15104.473818794669569','test','test','1.00'),('2019-05-20 15:59:59','2019-05-20 19:59:59','LENDBTC','4h','0.000001250000000','0.000001237500000','0.033306707390337','0.032973640316434','26645.365912269863','26645.365912269862747','test','test','1.00'),('2019-05-21 07:59:59','2019-05-21 11:59:59','LENDBTC','4h','0.000001180000000','0.000001168200000','0.033232692485026','0.032900365560176','28163.29871612336','28163.298716123361373','test','test','1.00'),('2019-05-21 19:59:59','2019-05-22 11:59:59','LENDBTC','4h','0.000001180000000','0.000001168200000','0.033158842057281','0.032827253636708','28100.71360786535','28100.713607865349331','test','test','1.00'),('2019-05-22 15:59:59','2019-05-24 15:59:59','LENDBTC','4h','0.000001240000000','0.000001227600000','0.033085155741598','0.032754304184182','26681.577210966312','26681.577210966312123','test','test','1.00'),('2019-05-26 11:59:59','2019-05-26 15:59:59','LENDBTC','4h','0.000001200000000','0.000001220000000','0.033011633173284','0.033561827059505','27509.694311069634','27509.694311069633841','test','test','0.0'),('2019-06-06 15:59:59','2019-06-06 19:59:59','LENDBTC','4h','0.000001090000000','0.000001079100000','0.033133898481333','0.032802559496520','30398.072001222634','30398.072001222633844','test','test','0.99'),('2019-06-08 07:59:59','2019-06-12 15:59:59','LENDBTC','4h','0.000001130000000','0.000001180000000','0.033060267595819','0.034523111294749','29256.873978600594','29256.873978600593546','test','test','0.0'),('2019-06-16 11:59:59','2019-06-16 15:59:59','LENDBTC','4h','0.000001140000000','0.000001180000000','0.033385343973359','0.034556759551372','29285.389450314615','29285.389450314614805','test','test','0.0'),('2019-06-17 03:59:59','2019-06-17 11:59:59','LENDBTC','4h','0.000001170000000','0.000001158300000','0.033645658546250','0.033309201960787','28756.97311645337','28756.973116453369585','test','test','1.00'),('2019-06-19 15:59:59','2019-06-19 19:59:59','LENDBTC','4h','0.000001460000000','0.000001445400000','0.033570890416148','0.033235181511987','22993.76055900518','22993.760559005178948','test','test','1.00'),('2019-08-21 11:59:59','2019-08-22 19:59:59','LENDBTC','4h','0.000000350000000','0.000000350000000','0.033496288437445','0.033496288437445','95703.68124984317','95703.681249843168189','test','test','0.0'),('2019-08-23 07:59:59','2019-08-23 11:59:59','LENDBTC','4h','0.000000390000000','0.000000386100000','0.033496288437445','0.033161325553071','85887.91907037207','85887.919070372066926','test','test','1.00'),('2019-08-25 03:59:59','2019-08-25 07:59:59','LENDBTC','4h','0.000000410000000','0.000000405900000','0.033421852240918','0.033087633718509','81516.71278272575','81516.712782725750003','test','test','0.99'),('2019-08-25 19:59:59','2019-08-26 03:59:59','LENDBTC','4h','0.000000400000000','0.000000396000000','0.033347581458160','0.033014105643578','83368.95364540002','83368.953645400019013','test','test','0.99'),('2019-08-26 07:59:59','2019-08-26 23:59:59','LENDBTC','4h','0.000000420000000','0.000000415800000','0.033273475721586','0.032940740964370','79222.56124187195','79222.561241871953825','test','test','0.99'),('2019-08-27 03:59:59','2019-08-27 15:59:59','LENDBTC','4h','0.000000440000000','0.000000435600000','0.033199534664427','0.032867539317783','75453.48787369796','75453.487873697959003','test','test','1.00'),('2019-09-09 15:59:59','2019-09-11 15:59:59','LENDBTC','4h','0.000000380000000','0.000000380000000','0.033125757920728','0.033125757920728','87173.04715981167','87173.047159811671008','test','test','0.0'),('2019-09-13 15:59:59','2019-09-24 03:59:59','LENDBTC','4h','0.000000390000000','0.000000500000000','0.033125757920728','0.042468920411190','84937.8408223806','84937.840822380603640','test','test','0.0'),('2019-09-26 07:59:59','2019-09-26 15:59:59','LENDBTC','4h','0.000000540000000','0.000000534600000','0.035202016251942','0.034849996089423','65188.91898507817','65188.918985078169499','test','test','0.99'),('2019-09-28 11:59:59','2019-09-29 15:59:59','LENDBTC','4h','0.000000540000000','0.000000534600000','0.035123789549160','0.034772551653668','65044.054720667074','65044.054720667074434','test','test','0.99'),('2019-09-30 15:59:59','2019-09-30 19:59:59','LENDBTC','4h','0.000000550000000','0.000000544500000','0.035045736683495','0.034695279316660','63719.52124271878','63719.521242718779831','test','test','0.99'),('2019-10-02 19:59:59','2019-10-09 15:59:59','LENDBTC','4h','0.000000550000000','0.000000580000000','0.034967857268643','0.036875194937842','63577.92230662384','63577.922306623840996','test','test','0.0'),('2019-10-12 15:59:59','2019-10-31 11:59:59','LENDBTC','4h','0.000000650000000','0.000001360000000','0.035391710084021','0.074050347252721','54448.78474464718','54448.784744647178741','test','test','0.0'),('2019-11-03 15:59:59','2019-11-03 19:59:59','LENDBTC','4h','0.000001500000000','0.000001485000000','0.043982518343732','0.043542693160295','29321.678895821187','29321.678895821187325','test','test','1.00'),('2019-11-04 11:59:59','2019-11-04 15:59:59','LENDBTC','4h','0.000001550000000','0.000001534500000','0.043884779414079','0.043445931619938','28312.760912309102','28312.760912309102423','test','test','1.00'),('2019-11-08 15:59:59','2019-11-08 19:59:59','LENDBTC','4h','0.000001380000000','0.000001380000000','0.043787257682048','0.043787257682048','31729.896871049114','31729.896871049113543','test','test','0.0'),('2019-11-09 11:59:59','2019-11-21 03:59:59','LENDBTC','4h','0.000001450000000','0.000002000000000','0.043787257682048','0.060396217492480','30198.108746239843','30198.108746239842731','test','test','0.0'),('2019-11-22 03:59:59','2019-11-22 07:59:59','LENDBTC','4h','0.000002220000000','0.000002197800000','0.047478137639922','0.047003356263523','21386.548486451153','21386.548486451152712','test','test','0.99'),('2019-11-28 19:59:59','2019-11-28 23:59:59','LENDBTC','4h','0.000002050000000','0.000002029500000','0.047372630667388','0.046898904360714','23108.60032555534','23108.600325555340532','test','test','1.00'),('2019-11-29 07:59:59','2019-11-29 11:59:59','LENDBTC','4h','0.000002180000000','0.000002158200000','0.047267358154794','0.046794684573246','21682.27438293313','21682.274382933130255','test','test','0.99'),('2019-12-04 23:59:59','2019-12-05 03:59:59','LENDBTC','4h','0.000002030000000','0.000002009700000','0.047162319581117','0.046690696385306','23232.66974439256','23232.669744392558641','test','test','1.00'),('2019-12-06 11:59:59','2019-12-10 03:59:59','LENDBTC','4h','0.000001990000000','0.000001970100000','0.047057514426492','0.046586939282227','23646.992174116695','23646.992174116694514','test','test','1.00'),('2019-12-30 23:59:59','2020-01-01 15:59:59','LENDBTC','4h','0.000001370000000','0.000002770000000','0.046952942172211','0.094934050961332','34272.22056365774','34272.220563657741877','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:24:58
