-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 15:59:59','2019-01-11 19:59:59','ENJETH','4h','0.000271290000000','0.000273050000000','1.297777777777778','1.306197140411450','4783.728769131843','4783.728769131843364','test','test','0.0'),('2019-01-12 07:59:59','2019-01-12 15:59:59','ENJETH','4h','0.000297960000000','0.000294980400000','1.299648747251927','1.286652259779408','4361.822886467738','4361.822886467737590','test','test','1.00'),('2019-01-13 19:59:59','2019-01-13 23:59:59','ENJETH','4h','0.000287220000000','0.000284347800000','1.296760638924701','1.283793032535454','4514.868877253328','4514.868877253327810','test','test','1.00'),('2019-01-15 23:59:59','2019-01-16 07:59:59','ENJETH','4h','0.000285580000000','0.000282724200000','1.293878948615979','1.280940159129819','4530.705751859301','4530.705751859301017','test','test','1.00'),('2019-01-17 07:59:59','2019-01-17 15:59:59','ENJETH','4h','0.000277400000000','0.000277070000000','1.291003662063499','1.289467861023553','4653.9425452901905','4653.942545290190537','test','test','0.64'),('2019-01-18 19:59:59','2019-01-19 11:59:59','ENJETH','4h','0.000278140000000','0.000281100000000','1.290662372943511','1.304397760244556','4640.3335476505035','4640.333547650503533','test','test','0.52'),('2019-01-20 23:59:59','2019-01-21 07:59:59','ENJETH','4h','0.000278970000000','0.000280830000000','1.293714681232632','1.302340373267950','4637.468836192537','4637.468836192537310','test','test','0.0'),('2019-01-21 15:59:59','2019-01-21 23:59:59','ENJETH','4h','0.000285220000000','0.000288000000000','1.295631501684925','1.308259843227187','4542.568900094401','4542.568900094401215','test','test','0.0'),('2019-01-23 03:59:59','2019-01-23 07:59:59','ENJETH','4h','0.000301900000000','0.000298881000000','1.298437799805428','1.285453421807374','4300.887048047127','4300.887048047126882','test','test','0.99'),('2019-01-24 15:59:59','2019-01-24 19:59:59','ENJETH','4h','0.000299320000000','0.000296326800000','1.295552382472527','1.282596858647802','4328.318797516126','4328.318797516126324','test','test','0.99'),('2019-01-25 03:59:59','2019-01-25 11:59:59','ENJETH','4h','0.000300470000000','0.000297465300000','1.292673377178144','1.279746643406362','4302.171189064278','4302.171189064278224','test','test','0.99'),('2019-02-11 11:59:59','2019-02-11 19:59:59','ENJETH','4h','0.000272270000000','0.000269547300000','1.289800769673303','1.276902761976570','4737.212214615282','4737.212214615282392','test','test','1.0'),('2019-02-20 07:59:59','2019-02-20 11:59:59','ENJETH','4h','0.000263680000000','0.000261043200000','1.286934545740696','1.274065200283289','4880.668028446207','4880.668028446207245','test','test','0.99'),('2019-02-20 15:59:59','2019-02-20 19:59:59','ENJETH','4h','0.000257910000000','0.000255330900000','1.284074691194605','1.271233944282659','4978.77046719633','4978.770467196330173','test','test','0.99'),('2019-02-21 03:59:59','2019-02-21 07:59:59','ENJETH','4h','0.000258680000000','0.000256093200000','1.281221191880840','1.268408979962032','4952.919405755527','4952.919405755526896','test','test','1.00'),('2019-02-22 03:59:59','2019-02-23 19:59:59','ENJETH','4h','0.000262400000000','0.000259776000000','1.278374033676660','1.265590293339893','4871.852262487273','4871.852262487273038','test','test','1.00'),('2019-02-25 03:59:59','2019-03-16 07:59:59','ENJETH','4h','0.000303950000000','0.001167460000000','1.275533202490712','4.899272882315534','4196.523120548485','4196.523120548485167','test','test','0.0'),('2019-03-17 07:59:59','2019-03-24 11:59:59','ENJETH','4h','0.001177280000000','0.001318800000000','2.080808686896228','2.330941234267758','1767.4713635636617','1767.471363563661725','test','test','0.94'),('2019-04-13 07:59:59','2019-04-13 11:59:59','ENJETH','4h','0.000951090000000','0.000941579100000','2.136393697423235','2.115029760449003','2246.2581852645226','2246.258185264522581','test','test','0.99'),('2019-04-13 19:59:59','2019-04-13 23:59:59','ENJETH','4h','0.001030760000000','0.001020452400000','2.131646155873405','2.110329694314671','2068.033447042382','2068.033447042381795','test','test','0.99'),('2019-04-14 03:59:59','2019-04-14 07:59:59','ENJETH','4h','0.001057820000000','0.001047241800000','2.126909164415909','2.105640072771750','2010.6531965891259','2010.653196589125855','test','test','1.00'),('2019-04-14 11:59:59','2019-04-14 15:59:59','ENJETH','4h','0.001046750000000','0.001036282500000','2.122182699606096','2.100960872610035','2027.4016714651023','2027.401671465102254','test','test','1.00'),('2019-04-17 07:59:59','2019-04-23 03:59:59','ENJETH','4h','0.000968200000000','0.001041040000000','2.117466738051415','2.276768821504901','2187.0137761324268','2187.013776132426756','test','test','0.0'),('2019-04-25 07:59:59','2019-04-25 11:59:59','ENJETH','4h','0.001046470000000','0.001036005300000','2.152867201041079','2.131338529030668','2057.266047799821','2057.266047799821081','test','test','0.99'),('2019-05-11 03:59:59','2019-05-11 07:59:59','ENJETH','4h','0.000890250000000','0.000881347500000','2.148083051705432','2.126602221188378','2412.898682061704','2412.898682061704221','test','test','1.00'),('2019-05-22 03:59:59','2019-05-22 11:59:59','ENJETH','4h','0.000700120000000','0.000693118800000','2.143309533812753','2.121876438474625','3061.3459604250033','3061.345960425003341','test','test','1.00'),('2019-05-22 19:59:59','2019-05-22 23:59:59','ENJETH','4h','0.000700020000000','0.000693019800000','2.138546623737614','2.117161157500238','3054.9793202160135','3054.979320216013548','test','test','1.00'),('2019-05-24 03:59:59','2019-05-24 07:59:59','ENJETH','4h','0.000700830000000','0.000693821700000','2.133794297907086','2.112456354928015','3044.6674627328825','3044.667462732882541','test','test','0.99'),('2019-06-02 19:59:59','2019-06-02 23:59:59','ENJETH','4h','0.000638290000000','0.000631907100000','2.129052532800626','2.107762007472620','3335.5567732545173','3335.556773254517339','test','test','0.99'),('2019-06-07 03:59:59','2019-06-07 07:59:59','ENJETH','4h','0.000634700000000','0.000628353000000','2.124321304949958','2.103078091900458','3346.96912706784','3346.969127067839963','test','test','0.99'),('2019-06-07 11:59:59','2019-06-07 15:59:59','ENJETH','4h','0.000625640000000','0.000619383600000','2.119600590938957','2.098404585029567','3387.8917443561113','3387.891744356111303','test','test','0.99'),('2019-06-08 07:59:59','2019-06-08 11:59:59','ENJETH','4h','0.000630700000000','0.000624393000000','2.114890367403538','2.093741463729503','3353.243011580051','3353.243011580051189','test','test','0.99'),('2019-06-09 15:59:59','2019-06-09 19:59:59','ENJETH','4h','0.000647530000000','0.000641054700000','2.110190611031530','2.089088704921215','3258.8306503660524','3258.830650366052396','test','test','1.00'),('2019-06-10 03:59:59','2019-06-10 11:59:59','ENJETH','4h','0.000629850000000','0.000623551500000','2.105501298562571','2.084446285576945','3342.861472672177','3342.861472672177115','test','test','1.00'),('2019-06-11 07:59:59','2019-06-11 11:59:59','ENJETH','4h','0.000640000000000','0.000633600000000','2.100822406787988','2.079814182720108','3282.5350106062306','3282.535010606230571','test','test','1.00'),('2019-06-11 15:59:59','2019-06-12 11:59:59','ENJETH','4h','0.000638930000000','0.000632540700000','2.096153912550681','2.075192373425174','3280.7254512242043','3280.725451224204335','test','test','0.99'),('2019-07-01 11:59:59','2019-07-01 15:59:59','ENJETH','4h','0.000442270000000','0.000441420000000','2.091495792745012','2.087476140894710','4729.002176826401','4729.002176826401410','test','test','0.19'),('2019-07-01 19:59:59','2019-07-01 23:59:59','ENJETH','4h','0.000446440000000','0.000441975600000','2.090602536778279','2.069696511410496','4682.829801940415','4682.829801940414654','test','test','1.00'),('2019-07-07 03:59:59','2019-07-07 19:59:59','ENJETH','4h','0.000430230000000','0.000425927700000','2.085956753363216','2.065097185829584','4848.468850064421','4848.468850064420621','test','test','1.00'),('2019-07-14 11:59:59','2019-07-16 23:59:59','ENJETH','4h','0.000412630000000','0.000413530000000','2.081321293911297','2.085860927880034','5044.037743041702','5044.037743041702015','test','test','0.0'),('2019-07-22 15:59:59','2019-07-23 15:59:59','ENJETH','4h','0.000405500000000','0.000402230000000','2.082330101459906','2.065537945031364','5135.2160331933555','5135.216033193355543','test','test','0.80'),('2019-07-24 03:59:59','2019-07-24 15:59:59','ENJETH','4h','0.000410090000000','0.000405989100000','2.078598511142452','2.057812526031027','5068.6398379439925','5068.639837943992461','test','test','1.00'),('2019-07-26 07:59:59','2019-07-27 11:59:59','ENJETH','4h','0.000406930000000','0.000407420000000','2.073979403339913','2.076476761380944','5096.649063327632','5096.649063327631666','test','test','0.31'),('2019-07-30 11:59:59','2019-07-31 07:59:59','ENJETH','4h','0.000409790000000','0.000406870000000','2.074534371793475','2.059752067770349','5062.432884632313','5062.432884632313289','test','test','0.71'),('2019-08-12 15:59:59','2019-08-12 19:59:59','ENJETH','4h','0.000344720000000','0.000341272800000','2.071249415343892','2.050536921190453','6008.497955859515','6008.497955859515059','test','test','1.00'),('2019-08-17 07:59:59','2019-08-18 11:59:59','ENJETH','4h','0.000333530000000','0.000335300000000','2.066646638865350','2.077614061738230','6196.284108971756','6196.284108971755813','test','test','0.0'),('2019-08-21 15:59:59','2019-08-21 23:59:59','ENJETH','4h','0.000345860000000','0.000342401400000','2.069083843948212','2.048393005508730','5982.431746799896','5982.431746799896246','test','test','1.00'),('2019-08-22 07:59:59','2019-08-26 03:59:59','ENJETH','4h','0.000348230000000','0.000359530000000','2.064485879850550','2.131478070191162','5928.512419523159','5928.512419523159224','test','test','0.0'),('2019-08-27 11:59:59','2019-08-29 03:59:59','ENJETH','4h','0.000371700000000','0.000367983000000','2.079373033259575','2.058579302926979','5594.223925906846','5594.223925906845579','test','test','0.99'),('2019-08-29 11:59:59','2019-09-09 11:59:59','ENJETH','4h','0.000365480000000','0.000434270000000','2.074752204296775','2.465258399255665','5676.787250456318','5676.787250456318361','test','test','0.0'),('2019-10-03 15:59:59','2019-10-07 03:59:59','ENJETH','4h','0.000342010000000','0.000348240000000','2.161531358732084','2.200905471667089','6320.082333066531','6320.082333066530737','test','test','0.23'),('2019-10-07 15:59:59','2019-10-08 03:59:59','ENJETH','4h','0.000361000000000','0.000357390000000','2.170281161606530','2.148578349990465','6011.85917342529','6011.859173425289555','test','test','1.00'),('2019-10-22 15:59:59','2019-10-25 15:59:59','ENJETH','4h','0.000350000000000','0.000346500000000','2.165458314580737','2.143803731434930','6187.023755944963','6187.023755944963341','test','test','0.99'),('2019-10-25 19:59:59','2019-10-25 23:59:59','ENJETH','4h','0.000344920000000','0.000343950000000','2.160646184992780','2.154569915714561','6264.195132183638','6264.195132183637725','test','test','0.28'),('2019-10-27 19:59:59','2019-10-27 23:59:59','ENJETH','4h','0.000352000000000','0.000349610000000','2.159295902930954','2.144634774499122','6134.363360599301','6134.363360599300904','test','test','0.67'),('2019-10-28 03:59:59','2019-10-28 07:59:59','ENJETH','4h','0.000352050000000','0.000348529500000','2.156037874390547','2.134477495646641','6124.23767757576','6124.237677575760245','test','test','1.00'),('2019-10-28 15:59:59','2019-10-28 19:59:59','ENJETH','4h','0.000360000000000','0.000356400000000','2.151246679114123','2.129734212322982','5975.685219761453','5975.685219761452572','test','test','0.99'),('2019-10-31 15:59:59','2019-11-02 19:59:59','ENJETH','4h','0.000354000000000','0.000359300000000','2.146466130938314','2.178602488265922','6063.463646718401','6063.463646718400923','test','test','0.77'),('2019-11-04 03:59:59','2019-11-04 11:59:59','ENJETH','4h','0.000364750000000','0.000361102500000','2.153607543677782','2.132071468241004','5904.338707821199','5904.338707821199023','test','test','1.00'),('2019-11-04 15:59:59','2019-11-04 23:59:59','ENJETH','4h','0.000362990000000','0.000359360100000','2.148821749136276','2.127333531644913','5919.782223026188','5919.782223026188149','test','test','0.99'),('2019-11-05 19:59:59','2019-11-05 23:59:59','ENJETH','4h','0.000356960000000','0.000354960000000','2.144046589693751','2.132033778231997','6006.4057308767115','6006.405730876711459','test','test','0.56'),('2019-11-14 19:59:59','2019-11-18 11:59:59','ENJETH','4h','0.000344520000000','0.000352190000000','2.141377076035584','2.189050250809742','6215.537780203134','6215.537780203134389','test','test','0.0'),('2019-11-18 19:59:59','2019-11-19 07:59:59','ENJETH','4h','0.000355260000000','0.000351707400000','2.151971114874285','2.130451403725542','6057.454019237419','6057.454019237418834','test','test','1.00'),('2019-11-19 15:59:59','2019-11-24 15:59:59','ENJETH','4h','0.000354000000000','0.000372720000000','2.147188956841231','2.260735220321649','6065.505527800089','6065.505527800089112','test','test','0.0'),('2019-11-26 15:59:59','2019-11-26 23:59:59','ENJETH','4h','0.000374420000000','0.000371060000000','2.172421459836880','2.152926411214873','5802.097804168795','5802.097804168794937','test','test','0.89'),('2019-11-27 11:59:59','2019-11-27 19:59:59','ENJETH','4h','0.000379550000000','0.000375754500000','2.168089226809767','2.146408334541670','5712.262486654637','5712.262486654636632','test','test','1.00'),('2019-11-28 15:59:59','2019-11-29 15:59:59','ENJETH','4h','0.000392610000000','0.000388683900000','2.163271250750190','2.141638538242688','5509.97491340055','5509.974913400549667','test','test','0.99'),('2019-11-29 19:59:59','2019-11-30 15:59:59','ENJETH','4h','0.000393120000000','0.000389188800000','2.158463981304079','2.136879341491039','5490.598243040493','5490.598243040492889','test','test','1.00'),('2019-11-30 23:59:59','2019-12-01 03:59:59','ENJETH','4h','0.000398670000000','0.000394683300000','2.153667394678958','2.132130720732168','5402.130570845457','5402.130570845457441','test','test','1.00'),('2019-12-01 23:59:59','2019-12-02 23:59:59','ENJETH','4h','0.000400940000000','0.000396930600000','2.148881467135227','2.127392652463875','5359.608587657073','5359.608587657073258','test','test','0.99'),('2019-12-03 11:59:59','2019-12-10 03:59:59','ENJETH','4h','0.000399640000000','0.000521830000000','2.144106174986038','2.799667013544600','5365.094022084972','5365.094022084971584','test','test','0.0'),('2019-12-11 07:59:59','2019-12-11 15:59:59','ENJETH','4h','0.000557540000000','0.000551964600000','2.289786361332385','2.266888497719061','4106.945441282034','4106.945441282034153','test','test','0.99'),('2019-12-11 23:59:59','2019-12-12 23:59:59','ENJETH','4h','0.000583750000000','0.000577912500000','2.284697947196091','2.261850967724130','3913.829459864824','3913.829459864824003','test','test','1.00'),('2019-12-15 19:59:59','2019-12-23 03:59:59','ENJETH','4h','0.000562610000000','0.000590700000000','2.279620840646766','2.393437782069364','4051.866907176848','4051.866907176848144','test','test','0.0'),('2019-12-23 23:59:59','2019-12-24 03:59:59','ENJETH','4h','0.000603590000000','0.000597554100000','2.304913494296232','2.281864359353269','3818.6740905187835','3818.674090518783487','test','test','1.00'),('2019-12-24 11:59:59','2019-12-24 23:59:59','ENJETH','4h','0.000617930000000','0.000611750700000','2.299791464308907','2.276793549665818','3721.766970868718','3721.766970868718090','test','test','1.00'),('2019-12-26 23:59:59','2019-12-27 03:59:59','ENJETH','4h','0.000602210000000','0.000596440000000','2.294680816610443','2.272694618586759','3810.4329330473474','3810.432933047347433','test','test','0.95'),('2019-12-27 07:59:59','2019-12-27 11:59:59','ENJETH','4h','0.000615050000000','0.000608899500000','2.289794994827402','2.266897044879128','3722.941215880664','3722.941215880664004','test','test','0.99'),('2019-12-28 15:59:59','2019-12-29 03:59:59','ENJETH','4h','0.000620410000000','0.000614205900000','2.284706561505563','2.261859495890507','3682.575331644499','3682.575331644498874','test','test','1.00'),('2019-12-29 07:59:59','2019-12-29 15:59:59','ENJETH','4h','0.000633300000000','0.000626967000000','2.279629435813329','2.256833141455196','3599.60435151323','3599.604351513230085','test','test','0.99'),('2019-12-29 23:59:59','2019-12-30 03:59:59','ENJETH','4h','0.000610380000000','0.000611650000000','2.274563592622633','2.279296211257960','3726.4713663990183','3726.471366399018279','test','test','0.0'),('2019-12-30 15:59:59','2019-12-30 19:59:59','ENJETH','4h','0.000646780000000','0.000640312200000','2.275615285652706','2.252859132796179','3518.3760871590116','3518.376087159011604','test','test','0.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:59:59
