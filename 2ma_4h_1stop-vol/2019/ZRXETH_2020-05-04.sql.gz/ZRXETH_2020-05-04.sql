-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 19:59:59','2019-01-14 15:59:59','ZRXETH','4h','0.002310750000000','0.002287642500000','1.297777777777778','1.284800000000000','561.6262156346545','561.626215634654500','test','test','0.99'),('2019-01-15 23:59:59','2019-01-26 15:59:59','ZRXETH','4h','0.002330220000000','0.002482570000000','1.294893827160494','1.379554105832852','555.6959545281105','555.695954528110519','test','test','0.0'),('2019-02-08 03:59:59','2019-02-08 07:59:59','ZRXETH','4h','0.002354000000000','0.002330460000000','1.313707222421018','1.300570150196808','558.0744360327178','558.074436032717813','test','test','0.99'),('2019-02-26 11:59:59','2019-02-26 15:59:59','ZRXETH','4h','0.001777610000000','0.001827560000000','1.310787873037860','1.347620392127110','737.387769554548','737.387769554547958','test','test','0.0'),('2019-02-26 19:59:59','2019-02-26 23:59:59','ZRXETH','4h','0.001827100000000','0.001808829000000','1.318972877279916','1.305783148507117','721.8941914946722','721.894191494672214','test','test','1.00'),('2019-02-27 07:59:59','2019-02-28 11:59:59','ZRXETH','4h','0.001824730000000','0.001813540000000','1.316041826441516','1.307971312974931','721.2255108654516','721.225510865451611','test','test','0.61'),('2019-03-03 19:59:59','2019-03-04 03:59:59','ZRXETH','4h','0.001843420000000','0.001824985800000','1.314248379004497','1.301105895214452','712.9402843652','712.940284365200000','test','test','0.99'),('2019-03-09 03:59:59','2019-03-09 11:59:59','ZRXETH','4h','0.001800000000000','0.001792450000000','1.311327827051154','1.305827535332134','728.5154594728632','728.515459472863199','test','test','0.41'),('2019-03-09 15:59:59','2019-03-09 19:59:59','ZRXETH','4h','0.001849400000000','0.001830906000000','1.310105540002483','1.297004484602458','708.3949064574904','708.394906457490379','test','test','0.99'),('2019-03-10 03:59:59','2019-03-10 07:59:59','ZRXETH','4h','0.001967770000000','0.001948092300000','1.307194194358033','1.294122252414453','664.3023292143047','664.302329214304677','test','test','1.00'),('2019-03-10 15:59:59','2019-03-11 07:59:59','ZRXETH','4h','0.001962530000000','0.001942904700000','1.304289318370570','1.291246425186864','664.5958626724536','664.595862672453563','test','test','0.99'),('2019-03-11 15:59:59','2019-03-12 01:59:59','ZRXETH','4h','0.001929530000000','0.001910234700000','1.301390897663080','1.288376988686449','674.4600486455666','674.460048645566644','test','test','1.00'),('2019-03-12 11:59:59','2019-03-16 03:59:59','ZRXETH','4h','0.001984860000000','0.001965011400000','1.298498917890495','1.285513928711590','654.2017663162617','654.201766316261683','test','test','1.00'),('2019-03-19 15:59:59','2019-03-19 23:59:59','ZRXETH','4h','0.001946830000000','0.001927361700000','1.295613364739628','1.282657231092232','665.4989725551935','665.498972555193518','test','test','1.00'),('2019-03-20 03:59:59','2019-03-21 15:59:59','ZRXETH','4h','0.001952390000000','0.001932866100000','1.292734223929095','1.279806881689804','662.1290950727545','662.129095072754467','test','test','1.00'),('2019-03-21 19:59:59','2019-03-21 23:59:59','ZRXETH','4h','0.001925130000000','0.001917860000000','1.289861481209253','1.284990489136826','670.0126647079693','670.012664707969293','test','test','0.37'),('2019-03-22 23:59:59','2019-03-23 07:59:59','ZRXETH','4h','0.002003360000000','0.001983326400000','1.288779038526491','1.275891248141226','643.308760545529','643.308760545529026','test','test','1.00'),('2019-03-23 15:59:59','2019-03-24 03:59:59','ZRXETH','4h','0.001985000000000','0.001965150000000','1.285915085107543','1.273055934256468','647.8161637821378','647.816163782137778','test','test','1.00'),('2019-03-24 11:59:59','2019-03-24 15:59:59','ZRXETH','4h','0.002094000000000','0.002073060000000','1.283057496029527','1.270226921069232','612.7304183522095','612.730418352209540','test','test','1.00'),('2019-03-24 19:59:59','2019-03-24 23:59:59','ZRXETH','4h','0.002164190000000','0.002142548100000','1.280206257149461','1.267404194577966','591.5406027887853','591.540602788785350','test','test','1.00'),('2019-03-25 07:59:59','2019-03-25 11:59:59','ZRXETH','4h','0.002249990000000','0.002227490100000','1.277361354355796','1.264587740812238','567.7186806856012','567.718680685601157','test','test','0.99'),('2019-03-26 07:59:59','2019-03-26 11:59:59','ZRXETH','4h','0.002157590000000','0.002136014100000','1.274522773568338','1.261777545832655','590.7159254391883','590.715925439188254','test','test','1.00'),('2019-03-26 15:59:59','2019-03-26 19:59:59','ZRXETH','4h','0.002148780000000','0.002127292200000','1.271690500738186','1.258973595730804','591.8197771471191','591.819777147119112','test','test','0.99'),('2019-03-30 03:59:59','2019-04-03 03:59:59','ZRXETH','4h','0.002171000000000','0.002203380000000','1.268864521847657','1.287789364416716','584.460857599105','584.460857599104997','test','test','0.75'),('2019-06-03 07:59:59','2019-06-03 11:59:59','ZRXETH','4h','0.001286320000000','0.001276680000000','1.273070042418559','1.263529340875463','989.6993301966534','989.699330196653364','test','test','0.74'),('2019-06-06 07:59:59','2019-06-06 15:59:59','ZRXETH','4h','0.001328100000000','0.001314819000000','1.270949886520093','1.258240387654892','956.9685163166127','956.968516316612750','test','test','0.99'),('2019-06-07 19:59:59','2019-06-11 07:59:59','ZRXETH','4h','0.001328030000000','0.001318410000000','1.268125553438938','1.258939490003562','954.892248999599','954.892248999599019','test','test','0.72'),('2019-06-15 15:59:59','2019-06-15 19:59:59','ZRXETH','4h','0.001333020000000','0.001326480000000','1.266084206008854','1.259872603251733','949.7863542999008','949.786354299900836','test','test','0.49'),('2019-06-15 23:59:59','2019-06-16 03:59:59','ZRXETH','4h','0.001333000000000','0.001319670000000','1.264703849840605','1.252056811342199','948.765078650116','948.765078650116038','test','test','0.99'),('2019-06-17 07:59:59','2019-06-17 11:59:59','ZRXETH','4h','0.001310000000000','0.001296900000000','1.261893396840959','1.249274462872549','963.2774021686711','963.277402168671074','test','test','1.00'),('2019-07-15 19:59:59','2019-07-18 15:59:59','ZRXETH','4h','0.001042710000000','0.001049060000000','1.259089189292424','1.266756916994284','1207.5161735213276','1207.516173521327573','test','test','0.0'),('2019-07-20 23:59:59','2019-07-21 03:59:59','ZRXETH','4h','0.001084320000000','0.001073476800000','1.260793128781726','1.248185197493909','1162.7500449883114','1162.750044988311402','test','test','1.00'),('2019-07-22 07:59:59','2019-07-23 15:59:59','ZRXETH','4h','0.001079070000000','0.001068279300000','1.257991366273322','1.245411452610589','1165.81071318202','1165.810713182019981','test','test','0.99'),('2019-07-24 03:59:59','2019-07-24 15:59:59','ZRXETH','4h','0.001064200000000','0.001057490000000','1.255195829903826','1.247281561891559','1179.4736232886917','1179.473623288691670','test','test','0.63'),('2019-07-26 15:59:59','2019-07-26 19:59:59','ZRXETH','4h','0.001084820000000','0.001073971800000','1.253437103678878','1.240902732642089','1155.4332549905769','1155.433254990576870','test','test','1.00'),('2019-07-27 11:59:59','2019-07-27 19:59:59','ZRXETH','4h','0.001075860000000','0.001065101400000','1.250651687892925','1.238145171013996','1162.4669454138311','1162.466945413831127','test','test','1.00'),('2019-07-28 03:59:59','2019-07-28 11:59:59','ZRXETH','4h','0.001101240000000','0.001090227600000','1.247872461919829','1.235393737300631','1133.1521393336866','1133.152139333686591','test','test','1.00'),('2019-07-29 11:59:59','2019-07-29 19:59:59','ZRXETH','4h','0.001079670000000','0.001068873300000','1.245099412004452','1.232648417884407','1153.2221993798585','1153.222199379858466','test','test','1.00'),('2019-07-30 23:59:59','2019-07-31 03:59:59','ZRXETH','4h','0.001066440000000','0.001055775600000','1.242332524422219','1.229909199177997','1164.9342901824944','1164.934290182494351','test','test','0.99'),('2019-08-15 23:59:59','2019-08-17 23:59:59','ZRXETH','4h','0.000923980000000','0.000925320000000','1.239571785479059','1.241369471784544','1341.5569443917175','1341.556944391717479','test','test','0.0'),('2019-08-21 23:59:59','2019-08-22 15:59:59','ZRXETH','4h','0.000919420000000','0.000910225800000','1.239971271324723','1.227571558611476','1348.645092911534','1348.645092911533993','test','test','0.99'),('2019-08-22 19:59:59','2019-08-23 03:59:59','ZRXETH','4h','0.000925950000000','0.000916690500000','1.237215779610667','1.224843621814560','1336.1583018636722','1336.158301863672250','test','test','1.00'),('2019-08-23 11:59:59','2019-08-23 15:59:59','ZRXETH','4h','0.000917310000000','0.000922330000000','1.234466411211532','1.241222056941200','1345.7461612884767','1345.746161288476742','test','test','0.0'),('2019-08-23 19:59:59','2019-08-23 23:59:59','ZRXETH','4h','0.000977140000000','0.000967368600000','1.235967665818125','1.223607989159944','1264.8828886527267','1264.882888652726706','test','test','1.00'),('2019-08-24 03:59:59','2019-08-24 23:59:59','ZRXETH','4h','0.000997000000000','0.000987030000000','1.233221071005196','1.220888860295144','1236.9318666050112','1236.931866605011237','test','test','0.99'),('2019-08-30 19:59:59','2019-09-01 03:59:59','ZRXETH','4h','0.000951930000000','0.000942410700000','1.230480579736296','1.218175773938933','1292.6166627129053','1292.616662712905281','test','test','1.00'),('2019-09-01 23:59:59','2019-09-02 19:59:59','ZRXETH','4h','0.000940250000000','0.000940460000000','1.227746178447993','1.228020389240308','1305.7656776899685','1305.765677689968470','test','test','0.0'),('2019-09-02 23:59:59','2019-09-03 03:59:59','ZRXETH','4h','0.000971970000000','0.000962250300000','1.227807114179619','1.215529043037823','1263.2150315129259','1263.215031512925862','test','test','0.99'),('2019-09-03 23:59:59','2019-09-04 07:59:59','ZRXETH','4h','0.000954690000000','0.000945143100000','1.225078653925886','1.212827867386627','1283.221416298365','1283.221416298365057','test','test','1.00'),('2019-09-05 11:59:59','2019-09-05 19:59:59','ZRXETH','4h','0.000956360000000','0.000946796400000','1.222356256917162','1.210132694347990','1278.1340258032144','1278.134025803214399','test','test','0.99'),('2019-09-18 15:59:59','2019-09-30 03:59:59','ZRXETH','4h','0.000897620000000','0.001142630000000','1.219639909679568','1.552546901803842','1358.748590360696','1358.748590360695971','test','test','0.0'),('2019-09-30 11:59:59','2019-09-30 15:59:59','ZRXETH','4h','0.001153990000000','0.001145570000000','1.293619241262740','1.284180447155831','1120.996924811082','1120.996924811081954','test','test','0.72'),('2019-10-01 15:59:59','2019-10-02 15:59:59','ZRXETH','4h','0.001167000000000','0.001164530000000','1.291521731461205','1.288788176468309','1106.7024262735258','1106.702426273525816','test','test','0.21'),('2019-10-03 19:59:59','2019-10-04 07:59:59','ZRXETH','4h','0.001205310000000','0.001193256900000','1.290914274796117','1.278005132048156','1071.0226205674196','1071.022620567419608','test','test','0.99'),('2019-10-04 19:59:59','2019-10-07 23:59:59','ZRXETH','4h','0.001236250000000','0.001223887500000','1.288045576407681','1.275165120643604','1041.8973317756772','1041.897331775677230','test','test','1.00'),('2019-10-08 07:59:59','2019-10-25 15:59:59','ZRXETH','4h','0.001271010000000','0.001720930000000','1.285183252904553','1.740120388841183','1011.1511734011164','1011.151173401116353','test','test','0.0'),('2019-11-01 19:59:59','2019-11-01 23:59:59','ZRXETH','4h','0.001685000000000','0.001668150000000','1.386280394223804','1.372417590281566','822.7183348509222','822.718334850922247','test','test','1.00'),('2019-11-07 11:59:59','2019-11-07 15:59:59','ZRXETH','4h','0.001654730000000','0.001638182700000','1.383199771125529','1.369367773414274','835.9066259302296','835.906625930229552','test','test','1.00'),('2019-11-07 19:59:59','2019-11-08 15:59:59','ZRXETH','4h','0.001637950000000','0.001621570500000','1.380125993856361','1.366324733917798','842.5934820088287','842.593482008828687','test','test','0.99'),('2019-11-09 11:59:59','2019-11-09 23:59:59','ZRXETH','4h','0.001670530000000','0.001653824700000','1.377059047203347','1.363288456731313','824.3246437976852','824.324643797685212','test','test','0.99'),('2019-11-10 15:59:59','2019-11-10 19:59:59','ZRXETH','4h','0.001683400000000','0.001666566000000','1.373998915987339','1.360258926827465','816.2046548576329','816.204654857632931','test','test','1.00'),('2019-11-11 15:59:59','2019-11-11 19:59:59','ZRXETH','4h','0.001671420000000','0.001654705800000','1.370945585062923','1.357236129212294','820.2280606088973','820.228060608897295','test','test','0.99'),('2019-11-21 19:59:59','2019-11-22 11:59:59','ZRXETH','4h','0.001584830000000','0.001568981700000','1.367899039318339','1.354220048925156','863.1203594823032','863.120359482303229','test','test','1.00'),('2019-11-22 15:59:59','2019-11-23 03:59:59','ZRXETH','4h','0.001596100000000','0.001580139000000','1.364859263675409','1.351210671038655','855.1213982052561','855.121398205256128','test','test','1.00'),('2019-11-24 07:59:59','2019-11-24 11:59:59','ZRXETH','4h','0.001702830000000','0.001685801700000','1.361826243089464','1.348207980658569','799.7429238910895','799.742923891089504','test','test','0.99'),('2019-11-25 07:59:59','2019-11-25 11:59:59','ZRXETH','4h','0.001704960000000','0.001687910400000','1.358799962549265','1.345211962923772','796.968821878088','796.968821878087965','test','test','1.00'),('2019-11-26 07:59:59','2019-11-26 15:59:59','ZRXETH','4h','0.001676660000000','0.001659893400000','1.355780407076933','1.342222603006164','808.6197601642152','808.619760164215222','test','test','1.00'),('2019-11-27 15:59:59','2019-11-27 19:59:59','ZRXETH','4h','0.001720270000000','0.001703067300000','1.352767561727873','1.339239886110594','786.3693267497969','786.369326749796869','test','test','1.00'),('2019-11-28 03:59:59','2019-11-30 07:59:59','ZRXETH','4h','0.001756540000000','0.001738974600000','1.349761411590700','1.336263797474793','768.4205378703019','768.420537870301928','test','test','1.00'),('2019-12-01 23:59:59','2019-12-02 03:59:59','ZRXETH','4h','0.001727080000000','0.001709809200000','1.346761941787165','1.333294322369293','779.7912903786538','779.791290378653798','test','test','1.00'),('2019-12-02 11:59:59','2019-12-02 19:59:59','ZRXETH','4h','0.001718250000000','0.001701067500000','1.343769137472083','1.330331446097362','782.0568237870407','782.056823787040685','test','test','1.00'),('2019-12-20 15:59:59','2019-12-20 19:59:59','ZRXETH','4h','0.001542410000000','0.001530360000000','1.340782983833256','1.330308184684397','869.2779376646001','869.277937664600131','test','test','0.78'),('2019-12-29 11:59:59','2019-12-29 15:59:59','ZRXETH','4h','0.001482580000000','0.001493320000000','1.338455250689065','1.348151192488091','902.78787700432','902.787877004319967','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:40:26
