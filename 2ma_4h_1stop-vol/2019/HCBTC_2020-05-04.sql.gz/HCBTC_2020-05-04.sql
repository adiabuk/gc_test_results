-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-02-07 15:59:59','2019-02-07 19:59:59','HCBTC','4h','0.000271400000000','0.000268686000000','0.033333333333333','0.033000000000000','122.81994595922379','122.819945959223787','test','test','1.00'),('2019-02-08 11:59:59','2019-02-08 15:59:59','HCBTC','4h','0.000312900000000','0.000309771000000','0.033259259259259','0.032926666666666','106.29357385509535','106.293573855095346','test','test','0.99'),('2019-02-08 19:59:59','2019-02-14 11:59:59','HCBTC','4h','0.000297300000000','0.000300500000000','0.033185349794239','0.033542541584826','111.62243455848862','111.622434558488621','test','test','0.80'),('2019-02-15 07:59:59','2019-02-16 19:59:59','HCBTC','4h','0.000311100000000','0.000307989000000','0.033264725747702','0.032932078490225','106.92615155159898','106.926151551598977','test','test','0.99'),('2019-02-17 19:59:59','2019-02-17 23:59:59','HCBTC','4h','0.000325000000000','0.000321750000000','0.033190804134930','0.032858896093581','102.12555118439931','102.125551184399313','test','test','0.99'),('2019-02-26 15:59:59','2019-02-26 23:59:59','HCBTC','4h','0.000304200000000','0.000301158000000','0.033117046792408','0.032785876324484','108.8660315332274','108.866031533227400','test','test','1.00'),('2019-03-01 19:59:59','2019-03-02 03:59:59','HCBTC','4h','0.000302700000000','0.000299673000000','0.033043453355091','0.032713018821540','109.16238306934699','109.162383069346987','test','test','1.00'),('2019-03-07 07:59:59','2019-03-07 15:59:59','HCBTC','4h','0.000298500000000','0.000295515000000','0.032970023458747','0.032640323224160','110.45233989529872','110.452339895298721','test','test','0.99'),('2019-03-08 11:59:59','2019-03-08 15:59:59','HCBTC','4h','0.000304500000000','0.000301455000000','0.032896756739950','0.032567789172551','108.03532591116438','108.035325911164378','test','test','1.00'),('2019-03-08 19:59:59','2019-03-08 23:59:59','HCBTC','4h','0.000314100000000','0.000310959000000','0.032823652836083','0.032495416307722','104.50064576912803','104.500645769128027','test','test','1.00'),('2019-03-09 03:59:59','2019-03-09 19:59:59','HCBTC','4h','0.000334000000000','0.000330660000000','0.032750711385336','0.032423204271483','98.05602211178513','98.056022111785126','test','test','1.00'),('2019-03-12 15:59:59','2019-03-13 03:59:59','HCBTC','4h','0.000323000000000','0.000319770000000','0.032677932026702','0.032351152706435','101.17006819412454','101.170068194124539','test','test','1.00'),('2019-03-13 07:59:59','2019-03-13 11:59:59','HCBTC','4h','0.000339300000000','0.000335907000000','0.032605314399976','0.032279261255976','96.09582788086125','96.095827880861250','test','test','1.00'),('2019-03-13 23:59:59','2019-03-14 07:59:59','HCBTC','4h','0.000337300000000','0.000333927000000','0.032532858145754','0.032207529564296','96.45080980063443','96.450809800634431','test','test','0.99'),('2019-03-15 07:59:59','2019-03-15 11:59:59','HCBTC','4h','0.000348100000000','0.000344619000000','0.032460562905430','0.032135957276376','93.25068343990233','93.250683439902332','test','test','1.00'),('2019-03-17 11:59:59','2019-03-17 15:59:59','HCBTC','4h','0.000339400000000','0.000336006000000','0.032388428321196','0.032064544037984','95.42848650912134','95.428486509121342','test','test','0.99'),('2019-03-19 03:59:59','2019-03-19 07:59:59','HCBTC','4h','0.000331600000000','0.000328284000000','0.032316454036038','0.031993289495678','97.45613400493835','97.456134004938349','test','test','1.00'),('2019-03-19 11:59:59','2019-03-20 03:59:59','HCBTC','4h','0.000331000000000','0.000327690000000','0.032244639693735','0.031922193296798','97.41582989043906','97.415829890439056','test','test','1.00'),('2019-03-20 11:59:59','2019-03-20 15:59:59','HCBTC','4h','0.000327500000000','0.000325700000000','0.032172984938860','0.031996156319349','98.2381219507189','98.238121950718906','test','test','0.54'),('2019-03-21 03:59:59','2019-03-21 15:59:59','HCBTC','4h','0.000331900000000','0.000328581000000','0.032133689690080','0.031812352793179','96.81738382066955','96.817383820669548','test','test','1.0'),('2019-03-23 07:59:59','2019-03-26 07:59:59','HCBTC','4h','0.000333800000000','0.000330462000000','0.032062281490769','0.031741658675861','96.0523711526929','96.052371152692899','test','test','1.00'),('2019-03-26 19:59:59','2019-03-28 15:59:59','HCBTC','4h','0.000338000000000','0.000338200000000','0.031991031976345','0.032009961581065','94.64802359865352','94.648023598653523','test','test','0.0'),('2019-03-30 03:59:59','2019-03-30 07:59:59','HCBTC','4h','0.000340400000000','0.000338100000000','0.031995238555172','0.031779054510880','93.99306273552162','93.993062735521619','test','test','0.67'),('2019-03-31 07:59:59','2019-03-31 11:59:59','HCBTC','4h','0.000338000000000','0.000338900000000','0.031947197656440','0.032032264159075','94.51833626165683','94.518336261656827','test','test','0.0'),('2019-03-31 15:59:59','2019-04-02 03:59:59','HCBTC','4h','0.000343400000000','0.000340500000000','0.031966101323692','0.031696148808145','93.08707432641881','93.087074326418815','test','test','0.84'),('2019-05-16 03:59:59','2019-05-16 07:59:59','HCBTC','4h','0.000176500000000','0.000174735000000','0.031906111875793','0.031587050757035','180.77117210080957','180.771172100809565','test','test','1.00'),('2019-05-16 19:59:59','2019-05-16 23:59:59','HCBTC','4h','0.000177300000000','0.000175527000000','0.031835209404958','0.031516857310908','179.5556086010027','179.555608601002689','test','test','0.99'),('2019-05-17 03:59:59','2019-05-17 07:59:59','HCBTC','4h','0.000173900000000','0.000173000000000','0.031764464495169','0.031600071061899','182.65937029999358','182.659370299993583','test','test','0.51'),('2019-05-30 03:59:59','2019-06-22 03:59:59','HCBTC','4h','0.000164800000000','0.000310900000000','0.031727932621109','0.059855669004264','192.5238629921656','192.523862992165590','test','test','0.48'),('2019-06-22 15:59:59','2019-06-26 19:59:59','HCBTC','4h','0.000335400000000','0.000362800000000','0.037978540706254','0.041081140632764','113.23357396021002','113.233573960210023','test','test','0.0'),('2019-06-26 23:59:59','2019-06-27 07:59:59','HCBTC','4h','0.000420700000000','0.000416493000000','0.038668007356590','0.038281327283024','91.91349502398386','91.913495023983856','test','test','0.99'),('2019-06-28 11:59:59','2019-07-01 11:59:59','HCBTC','4h','0.000417400000000','0.000413226000000','0.038582078451353','0.038196257666839','92.43430390836872','92.434303908368719','test','test','1.00'),('2019-07-01 19:59:59','2019-07-02 07:59:59','HCBTC','4h','0.000405400000000','0.000412600000000','0.038496340499239','0.039180044622560','94.95890601686949','94.958906016869491','test','test','0.0'),('2019-07-02 11:59:59','2019-07-03 03:59:59','HCBTC','4h','0.000415300000000','0.000411147000000','0.038648274748866','0.038261792001377','93.06109980463708','93.061099804637081','test','test','1.00'),('2019-07-03 19:59:59','2019-07-08 07:59:59','HCBTC','4h','0.000409100000000','0.000417900000000','0.038562389693868','0.039391891109918','94.2615245511323','94.261524551132297','test','test','0.0'),('2019-07-24 15:59:59','2019-07-25 07:59:59','HCBTC','4h','0.000318900000000','0.000315711000000','0.038746723341879','0.038359256108460','121.50117071771504','121.501170717715041','test','test','1.00'),('2019-08-17 15:59:59','2019-08-24 03:59:59','HCBTC','4h','0.000234000000000','0.000245400000000','0.038660619512231','0.040544085591032','165.21632270184045','165.216322701840454','test','test','0.0'),('2019-08-24 15:59:59','2019-08-24 19:59:59','HCBTC','4h','0.000246500000000','0.000245800000000','0.039079167529742','0.038968192206128','158.53617659124544','158.536176591245436','test','test','0.28'),('2019-08-25 03:59:59','2019-08-25 07:59:59','HCBTC','4h','0.000247800000000','0.000245322000000','0.039054506346717','0.038663961283250','157.6049489375168','157.604948937516809','test','test','0.99'),('2019-08-28 19:59:59','2019-08-28 23:59:59','HCBTC','4h','0.000238700000000','0.000236313000000','0.038967718554835','0.038578041369287','163.24976353093888','163.249763530938878','test','test','0.99'),('2019-09-08 07:59:59','2019-09-08 11:59:59','HCBTC','4h','0.000220700000000','0.000218493000000','0.038881123624713','0.038492312388466','176.1718333697931','176.171833369793092','test','test','1.00'),('2019-09-08 15:59:59','2019-09-08 19:59:59','HCBTC','4h','0.000214600000000','0.000212454000000','0.038794721127770','0.038406773916492','180.77689248727657','180.776892487276569','test','test','0.99'),('2019-09-15 11:59:59','2019-09-15 19:59:59','HCBTC','4h','0.000215100000000','0.000212949000000','0.038708510636374','0.038321425530010','179.95588394409322','179.955883944093216','test','test','1.00'),('2019-09-16 03:59:59','2019-09-16 11:59:59','HCBTC','4h','0.000213700000000','0.000211563000000','0.038622491723849','0.038236266806611','180.73229632124057','180.732296321240568','test','test','1.00'),('2019-09-17 15:59:59','2019-09-17 23:59:59','HCBTC','4h','0.000212600000000','0.000210474000000','0.038536663964463','0.038151297324818','181.26370632390825','181.263706323908252','test','test','0.99'),('2019-09-18 03:59:59','2019-09-19 23:59:59','HCBTC','4h','0.000213100000000','0.000212200000000','0.038451026933431','0.038288634046335','180.43654121741278','180.436541217412781','test','test','0.42'),('2019-10-01 03:59:59','2019-10-01 07:59:59','HCBTC','4h','0.000201400000000','0.000199386000000','0.038414939625187','0.038030790228935','190.73952147560632','190.739521475606324','test','test','0.99'),('2019-10-03 19:59:59','2019-10-03 23:59:59','HCBTC','4h','0.000202500000000','0.000200475000000','0.038329573092687','0.037946277361760','189.28184243302056','189.281842433020557','test','test','1.00'),('2019-10-07 03:59:59','2019-10-07 07:59:59','HCBTC','4h','0.000202400000000','0.000200376000000','0.038244396263592','0.037861952300956','188.95452699403052','188.954526994030516','test','test','0.99'),('2019-10-27 15:59:59','2019-10-27 19:59:59','HCBTC','4h','0.000188700000000','0.000186813000000','0.038159408716339','0.037777814629176','202.2226217082105','202.222621708210511','test','test','1.00'),('2019-10-27 23:59:59','2019-10-30 07:59:59','HCBTC','4h','0.000184200000000','0.000187200000000','0.038074610030303','0.038694717685520','206.70255173888768','206.702551738887678','test','test','0.65'),('2019-10-31 19:59:59','2019-11-01 03:59:59','HCBTC','4h','0.000190800000000','0.000188892000000','0.038212411731462','0.037830287614147','200.27469460934194','200.274694609341935','test','test','1.00'),('2019-11-01 19:59:59','2019-11-10 19:59:59','HCBTC','4h','0.000197000000000','0.000208300000000','0.038127495260948','0.040314503872363','193.54058508095432','193.540585080954315','test','test','0.45'),('2019-11-11 03:59:59','2019-11-15 15:59:59','HCBTC','4h','0.000211600000000','0.000209484000000','0.038613497174596','0.038227362202850','182.4834460047059','182.483446004705911','test','test','1.00'),('2019-12-13 11:59:59','2019-12-13 15:59:59','HCBTC','4h','0.000165000000000','0.000169700000000','0.038527689403097','0.039625144798216','233.50114789755554','233.501147897555541','test','test','0.0'),('2019-12-15 07:59:59','2019-12-15 11:59:59','HCBTC','4h','0.000165800000000','0.000164800000000','0.038771568379790','0.038537722973398','233.84540639197695','233.845406391976951','test','test','0.60'),('2019-12-16 15:59:59','2019-12-16 19:59:59','HCBTC','4h','0.000165900000000','0.000164241000000','0.038719602733925','0.038332406706586','233.3912159971362','233.391215997136186','test','test','0.99'),('2019-12-31 11:59:59','2019-12-31 15:59:59','HCBTC','4h','0.000153700000000','0.000152600000000','0.038633559172294','0.038357066556227','251.35692369742353','251.356923697423525','test','test','0.71'),('2020-01-06 15:59:59','2020-01-06 19:59:59','HCBTC','4h','0.000150900000000','0.000149800000000','0.038572116368724','0.038290941232835','255.61375989876444','255.613759898764442','test','test','0.72'),('2020-01-07 03:59:59','2020-01-07 07:59:59','HCBTC','4h','0.000150600000000','0.000150300000000','0.038509633005193','0.038432920588848','255.708054483351','255.708054483350992','test','test','0.19'),('2020-01-07 11:59:59','2020-01-07 15:59:59','HCBTC','4h','0.000154900000000','0.000153351000000','0.038492585801560','0.038107659943544','248.4995855491313','248.499585549131297','test','test','0.99'),('2020-01-10 23:59:59','2020-01-11 03:59:59','HCBTC','4h','0.000148900000000','0.000147411000000','0.038407046722001','0.038022976254781','257.93852734722185','257.938527347221850','test','test','0.99'),('2020-01-11 15:59:59','2020-01-11 23:59:59','HCBTC','4h','0.000151400000000','0.000149886000000','0.038321697729286','0.037938480751993','253.11557284865108','253.115572848651084','test','test','1.00'),('2020-01-12 07:59:59','2020-01-12 11:59:59','HCBTC','4h','0.000152600000000','0.000151074000000','0.038236538400998','0.037854173016988','250.56709306027815','250.567093060278154','test','test','1.00'),('2020-01-12 15:59:59','2020-01-13 03:59:59','HCBTC','4h','0.000151600000000','0.000150084000000','0.038151568315663','0.037770052632506','251.659421607275','251.659421607274993','test','test','0.99'),('2020-01-14 15:59:59','2020-01-14 19:59:59','HCBTC','4h','0.000150400000000','0.000154700000000','0.038066787052739','0.039155132693210','253.10363731874403','253.103637318744035','test','test','0.0'),('2020-01-14 23:59:59','2020-01-16 03:59:59','HCBTC','4h','0.000155800000000','0.000162000000000','0.038308641639510','0.039833119034664','245.88345083126086','245.883450831260859','test','test','0.0'),('2020-01-20 15:59:59','2020-01-21 19:59:59','HCBTC','4h','0.000165800000000','0.000164142000000','0.038647414393989','0.038260940250049','233.09658862478355','233.096588624783550','test','test','1.00'),('2020-01-24 15:59:59','2020-01-24 19:59:59','HCBTC','4h','0.000163700000000','0.000162400000000','0.038561531250891','0.038255300397952','235.56219456867032','235.562194568670321','test','test','0.79'),('2020-01-25 03:59:59','2020-01-25 19:59:59','HCBTC','4h','0.000165600000000','0.000163944000000','0.038493479950238','0.038108545150736','232.44855042414386','232.448550424143860','test','test','0.99'),('2020-01-26 19:59:59','2020-01-27 23:59:59','HCBTC','4h','0.000172000000000','0.000170280000000','0.038407938883682','0.038023859494845','223.3019702539664','223.301970253966402','test','test','1.00'),('2020-01-29 19:59:59','2020-01-30 03:59:59','HCBTC','4h','0.000167200000000','0.000165528000000','0.038322587908385','0.037939362029301','229.20208079177698','229.202080791776979','test','test','1.00'),('2020-01-30 19:59:59','2020-02-04 15:59:59','HCBTC','4h','0.000169900000000','0.000184000000000','0.038237426601922','0.041410750410557','225.05842614433192','225.058426144331918','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:11:59
