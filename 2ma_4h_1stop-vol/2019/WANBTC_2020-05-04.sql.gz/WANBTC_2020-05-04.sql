-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-05 03:59:59','2019-01-07 11:59:59','WANBTC','4h','0.000093100000000','0.000092200000000','0.033333333333333','0.033011099176512','358.03795202291445','358.037952022914453','test','test','0.96'),('2019-01-16 15:59:59','2019-01-16 19:59:59','WANBTC','4h','0.000087800000000','0.000087700000000','0.033261725742929','0.033223842228415','378.83514513586175','378.835145135861751','test','test','0.11'),('2019-01-17 03:59:59','2019-01-18 11:59:59','WANBTC','4h','0.000091700000000','0.000090783000000','0.033253307184148','0.032920774112307','362.6314851052102','362.631485105210174','test','test','1.00'),('2019-01-21 23:59:59','2019-01-22 11:59:59','WANBTC','4h','0.000090700000000','0.000090800000000','0.033179410945961','0.033215992435427','365.8148946632953','365.814894663295320','test','test','0.0'),('2019-01-22 15:59:59','2019-01-23 15:59:59','WANBTC','4h','0.000091300000000','0.000090387000000','0.033187540165842','0.032855664764184','363.4998922874285','363.499892287428509','test','test','0.99'),('2019-01-26 11:59:59','2019-01-27 15:59:59','WANBTC','4h','0.000091100000000','0.000090189000000','0.033113790076585','0.032782652175819','363.4883652753555','363.488365275355477','test','test','1.00'),('2019-02-06 19:59:59','2019-02-06 23:59:59','WANBTC','4h','0.000082600000000','0.000082900000000','0.033040203876415','0.033160204616886','400.0024682374657','400.002468237465678','test','test','0.0'),('2019-02-07 07:59:59','2019-02-07 15:59:59','WANBTC','4h','0.000083000000000','0.000082170000000','0.033066870707630','0.032736202000554','398.39603262205355','398.396032622053553','test','test','1.00'),('2019-02-11 23:59:59','2019-02-12 03:59:59','WANBTC','4h','0.000080700000000','0.000079893000000','0.032993388772725','0.032663454884998','408.8400095752746','408.840009575274621','test','test','0.99'),('2019-02-12 07:59:59','2019-02-12 11:59:59','WANBTC','4h','0.000081100000000','0.000081000000000','0.032920070131008','0.032879478182634','405.91948373622137','405.919483736221366','test','test','0.12'),('2019-02-12 15:59:59','2019-02-12 23:59:59','WANBTC','4h','0.000081600000000','0.000081100000000','0.032911049698036','0.032709388854298','403.32168747592584','403.321687475925842','test','test','0.61'),('2019-02-17 23:59:59','2019-02-18 03:59:59','WANBTC','4h','0.000079900000000','0.000079600000000','0.032866236177205','0.032742833538242','411.34212987740784','411.342129877407842','test','test','0.37'),('2019-02-24 03:59:59','2019-02-24 15:59:59','WANBTC','4h','0.000079400000000','0.000078606000000','0.032838813368546','0.032510425234861','413.5870701328266','413.587070132826625','test','test','1.00'),('2019-02-26 07:59:59','2019-02-26 11:59:59','WANBTC','4h','0.000078200000000','0.000078200000000','0.032765838227728','0.032765838227728','419.00048884562085','419.000488845620850','test','test','0.0'),('2019-02-26 15:59:59','2019-03-04 07:59:59','WANBTC','4h','0.000078200000000','0.000078500000000','0.032765838227728','0.032891538374382','419.00048884562085','419.000488845620850','test','test','0.0'),('2019-03-07 19:59:59','2019-03-08 07:59:59','WANBTC','4h','0.000081400000000','0.000080586000000','0.032793771593651','0.032465833877714','402.8718868998853','402.871886899885283','test','test','0.99'),('2019-03-08 11:59:59','2019-03-17 03:59:59','WANBTC','4h','0.000082900000000','0.000101100000000','0.032720896545665','0.039904495063531','394.7032152673662','394.703215267366204','test','test','0.0'),('2019-03-19 07:59:59','2019-03-19 11:59:59','WANBTC','4h','0.000103900000000','0.000102861000000','0.034317251771857','0.033974079254138','330.2911623855352','330.291162385535188','test','test','1.00'),('2019-03-19 19:59:59','2019-03-19 23:59:59','WANBTC','4h','0.000102500000000','0.000101475000000','0.034240991212364','0.033898581300240','334.05845085233165','334.058450852331646','test','test','0.99'),('2019-03-23 07:59:59','2019-03-23 11:59:59','WANBTC','4h','0.000101900000000','0.000101100000000','0.034164900120781','0.033896677156143','335.2787057976534','335.278705797653402','test','test','0.78'),('2019-03-23 19:59:59','2019-03-24 11:59:59','WANBTC','4h','0.000104500000000','0.000103455000000','0.034105295017528','0.033764242067353','326.3664594978755','326.366459497875496','test','test','1.00'),('2019-03-27 03:59:59','2019-03-27 07:59:59','WANBTC','4h','0.000101600000000','0.000103400000000','0.034029505473045','0.034632390412528','334.93607749059703','334.936077490597029','test','test','0.0'),('2019-03-27 11:59:59','2019-03-27 15:59:59','WANBTC','4h','0.000102700000000','0.000101673000000','0.034163479904041','0.033821845105001','332.65316362259864','332.653163622598640','test','test','1.00'),('2019-03-28 07:59:59','2019-03-29 11:59:59','WANBTC','4h','0.000102200000000','0.000101200000000','0.034087561059810','0.033754023280360','333.53777945019345','333.537779450193455','test','test','0.97'),('2019-03-29 15:59:59','2019-03-30 03:59:59','WANBTC','4h','0.000103500000000','0.000102465000000','0.034013441553265','0.033673307137732','328.6322855387954','328.632285538795372','test','test','1.00'),('2019-03-31 11:59:59','2019-04-02 03:59:59','WANBTC','4h','0.000103500000000','0.000103500000000','0.033937856127591','0.033937856127591','327.9019915709307','327.901991570930704','test','test','0.0'),('2019-04-19 07:59:59','2019-04-19 15:59:59','WANBTC','4h','0.000085300000000','0.000084447000000','0.033937856127591','0.033598477566315','397.86466738090655','397.864667380906553','test','test','1.00'),('2019-04-19 19:59:59','2019-04-20 03:59:59','WANBTC','4h','0.000084600000000','0.000083900000000','0.033862438669530','0.033582253006780','400.26523250035456','400.265232500354557','test','test','0.82'),('2019-05-16 03:59:59','2019-05-16 07:59:59','WANBTC','4h','0.000053200000000','0.000053000000000','0.033800175188919','0.033673106861141','635.3416388894527','635.341638889452724','test','test','0.37'),('2019-05-18 03:59:59','2019-05-18 07:59:59','WANBTC','4h','0.000054600000000','0.000054054000000','0.033771937782746','0.033434218404919','618.5336590246518','618.533659024651797','test','test','0.99'),('2019-05-18 23:59:59','2019-05-19 03:59:59','WANBTC','4h','0.000054500000000','0.000053955000000','0.033696889032118','0.033359920141797','618.2915418737206','618.291541873720575','test','test','1.00'),('2019-05-22 07:59:59','2019-05-22 11:59:59','WANBTC','4h','0.000053000000000','0.000052470000000','0.033622007056491','0.033285786985926','634.3774916319034','634.377491631903354','test','test','1.00'),('2019-05-22 19:59:59','2019-05-22 23:59:59','WANBTC','4h','0.000053600000000','0.000053064000000','0.033547291485254','0.033211818570401','625.8823038293696','625.882303829369562','test','test','1.00'),('2019-05-23 03:59:59','2019-05-23 07:59:59','WANBTC','4h','0.000053300000000','0.000052767000000','0.033472741948620','0.033138014529134','628.0064155463456','628.006415546345579','test','test','1.00'),('2019-05-23 11:59:59','2019-05-24 15:59:59','WANBTC','4h','0.000053300000000','0.000053200000000','0.033398358077623','0.033335696993050','626.6108457340212','626.610845734021154','test','test','0.18'),('2019-05-30 07:59:59','2019-05-30 15:59:59','WANBTC','4h','0.000051300000000','0.000050787000000','0.033384433392163','0.033050589058241','650.768682108434','650.768682108433950','test','test','1.0'),('2019-06-02 11:59:59','2019-06-03 23:59:59','WANBTC','4h','0.000054600000000','0.000054054000000','0.033310245762402','0.032977143304778','610.0777612161578','610.077761216157796','test','test','0.99'),('2019-06-07 03:59:59','2019-06-09 23:59:59','WANBTC','4h','0.000057000000000','0.000056430000000','0.033236222994041','0.032903860764101','583.0916314744092','583.091631474409155','test','test','1.00'),('2019-06-12 11:59:59','2019-06-12 23:59:59','WANBTC','4h','0.000057300000000','0.000057500000000','0.033162364720721','0.033278114684842','578.7498206059569','578.749820605956870','test','test','0.34'),('2019-06-13 11:59:59','2019-06-13 15:59:59','WANBTC','4h','0.000058800000000','0.000058212000000','0.033188086934970','0.032856206065620','564.4232471933747','564.423247193374664','test','test','1.00'),('2019-06-14 03:59:59','2019-06-14 11:59:59','WANBTC','4h','0.000060300000000','0.000059697000000','0.033114335630670','0.032783192274363','549.1597948701565','549.159794870156475','test','test','1.00'),('2019-07-07 07:59:59','2019-07-07 11:59:59','WANBTC','4h','0.000034300000000','0.000033957000000','0.033040748218158','0.032710340735976','963.2871200629088','963.287120062908798','test','test','0.99'),('2019-07-07 23:59:59','2019-07-08 03:59:59','WANBTC','4h','0.000034100000000','0.000033759000000','0.032967324333228','0.032637651089896','966.7837047867574','966.783704786757426','test','test','1.00'),('2019-07-23 23:59:59','2019-07-24 03:59:59','WANBTC','4h','0.000025900000000','0.000025641000000','0.032894063612488','0.032565122976363','1270.0410661192275','1270.041066119227480','test','test','0.99'),('2019-07-24 07:59:59','2019-07-30 23:59:59','WANBTC','4h','0.000026200000000','0.000028600000000','0.032820965693349','0.035827466367549','1252.7086142499656','1252.708614249965649','test','test','0.0'),('2019-07-31 07:59:59','2019-07-31 11:59:59','WANBTC','4h','0.000028600000000','0.000029200000000','0.033489076954282','0.034191645002274','1170.9467466532321','1170.946746653232140','test','test','0.0'),('2019-08-22 15:59:59','2019-08-29 03:59:59','WANBTC','4h','0.000021800000000','0.000034700000000','0.033645203187170','0.053554520669486','1543.3579443655756','1543.357944365575577','test','test','0.0'),('2019-08-30 15:59:59','2019-08-30 19:59:59','WANBTC','4h','0.000039580000000','0.000039184200000','0.038069495961018','0.037688801001408','961.8366842096399','961.836684209639884','test','test','1.00'),('2019-08-30 23:59:59','2019-08-31 07:59:59','WANBTC','4h','0.000038200000000','0.000037818000000','0.037984897081104','0.037605048110293','994.3690335367596','994.369033536759616','test','test','0.99'),('2019-08-31 11:59:59','2019-08-31 15:59:59','WANBTC','4h','0.000040660000000','0.000040253400000','0.037900486198702','0.037521481336715','932.1319773414109','932.131977341410902','test','test','0.99'),('2019-09-01 19:59:59','2019-09-02 03:59:59','WANBTC','4h','0.000041540000000','0.000041124600000','0.037816262896038','0.037438100267078','910.3577972084254','910.357797208425382','test','test','1.00'),('2019-09-02 15:59:59','2019-09-02 19:59:59','WANBTC','4h','0.000039830000000','0.000039431700000','0.037732226756269','0.037354904488706','947.3318291807457','947.331829180745672','test','test','0.99'),('2019-09-22 15:59:59','2019-09-22 19:59:59','WANBTC','4h','0.000026540000000','0.000026310000000','0.037648377363477','0.037322110340357','1418.552274433961','1418.552274433960974','test','test','0.86'),('2019-09-23 15:59:59','2019-09-23 19:59:59','WANBTC','4h','0.000026040000000','0.000025779600000','0.037575873580562','0.037200114844756','1443.0058978710356','1443.005897871035586','test','test','1.00'),('2019-10-02 11:59:59','2019-10-02 15:59:59','WANBTC','4h','0.000024120000000','0.000024000000000','0.037492371639272','0.037305842427136','1554.4101011306614','1554.410101130661360','test','test','0.49'),('2019-10-02 23:59:59','2019-10-03 11:59:59','WANBTC','4h','0.000024870000000','0.000024621300000','0.037450920703241','0.037076411496209','1505.8673382887541','1505.867338288754127','test','test','0.99'),('2019-10-03 19:59:59','2019-10-06 19:59:59','WANBTC','4h','0.000024830000000','0.000024581700000','0.037367696435012','0.036994019470662','1504.9414593238819','1504.941459323881872','test','test','0.99'),('2019-10-07 11:59:59','2019-10-07 15:59:59','WANBTC','4h','0.000024810000000','0.000024561900000','0.037284657109601','0.036911810538505','1502.8076223136184','1502.807622313618367','test','test','1.00'),('2019-10-08 11:59:59','2019-10-11 03:59:59','WANBTC','4h','0.000024910000000','0.000024660900000','0.037201802316024','0.036829784292864','1493.4485072671212','1493.448507267121158','test','test','1.00'),('2019-10-14 15:59:59','2019-10-14 23:59:59','WANBTC','4h','0.000025070000000','0.000025630000000','0.037119131644211','0.037948278581617','1480.6195310813985','1480.619531081398463','test','test','0.0'),('2019-10-15 11:59:59','2019-10-15 15:59:59','WANBTC','4h','0.000025510000000','0.000025254900000','0.037303386519190','0.036930352653998','1462.304449987839','1462.304449987839007','test','test','1.00'),('2019-10-21 19:59:59','2019-10-21 23:59:59','WANBTC','4h','0.000024610000000','0.000024540000000','0.037220490104703','0.037114621177140','1512.4132509021806','1512.413250902180607','test','test','0.28'),('2019-10-22 03:59:59','2019-10-22 11:59:59','WANBTC','4h','0.000024590000000','0.000024344100000','0.037196963676355','0.036824994039591','1512.6866074158327','1512.686607415832668','test','test','1.00'),('2019-10-27 19:59:59','2019-10-27 23:59:59','WANBTC','4h','0.000024530000000','0.000024284700000','0.037114303757074','0.036743160719503','1513.0168673899077','1513.016867389907702','test','test','0.99'),('2019-10-28 03:59:59','2019-10-28 07:59:59','WANBTC','4h','0.000026230000000','0.000025967700000','0.037031827526503','0.036661509251238','1411.8119529738124','1411.811952973812367','test','test','0.99'),('2019-10-31 15:59:59','2019-11-02 03:59:59','WANBTC','4h','0.000024780000000','0.000024532200000','0.036949534576444','0.036580039230680','1491.103090251986','1491.103090251986032','test','test','1.00'),('2019-11-04 15:59:59','2019-11-04 23:59:59','WANBTC','4h','0.000024440000000','0.000024360000000','0.036867424499608','0.036746745532343','1508.4870908186485','1508.487090818648539','test','test','0.32'),('2019-11-05 19:59:59','2019-11-05 23:59:59','WANBTC','4h','0.000026940000000','0.000026670600000','0.036840606951327','0.036472200881814','1367.5058259586733','1367.505825958673313','test','test','1.00'),('2019-11-06 11:59:59','2019-11-06 23:59:59','WANBTC','4h','0.000026380000000','0.000026116200000','0.036758738935879','0.036391151546520','1393.4321052266612','1393.432105226661179','test','test','0.99'),('2019-11-11 19:59:59','2019-11-15 15:59:59','WANBTC','4h','0.000025370000000','0.000025120000000','0.036677052849355','0.036315631358920','1445.6859617404457','1445.685961740445691','test','test','0.98'),('2019-11-16 11:59:59','2019-11-21 11:59:59','WANBTC','4h','0.000026110000000','0.000026990000000','0.036596736962592','0.037830177350454','1401.6368043888076','1401.636804388807604','test','test','0.0'),('2019-11-23 15:59:59','2019-11-24 11:59:59','WANBTC','4h','0.000028040000000','0.000027759600000','0.036870834826561','0.036502126478295','1314.9370480228638','1314.937048022863792','test','test','1.00'),('2019-11-26 19:59:59','2019-11-26 23:59:59','WANBTC','4h','0.000028880000000','0.000028591200000','0.036788899638058','0.036421010641677','1273.85386558371','1273.853865583710103','test','test','0.99'),('2019-11-27 15:59:59','2019-11-27 19:59:59','WANBTC','4h','0.000029370000000','0.000029076300000','0.036707146527751','0.036340075062473','1249.817723110339','1249.817723110339102','test','test','1.00'),('2019-12-16 11:59:59','2019-12-16 19:59:59','WANBTC','4h','0.000025700000000','0.000025443000000','0.036625575091022','0.036259319340112','1425.119653347168','1425.119653347167969','test','test','1.00'),('2019-12-16 23:59:59','2019-12-20 23:59:59','WANBTC','4h','0.000025540000000','0.000026260000000','0.036544184924153','0.037574404702751','1430.860803608196','1430.860803608195965','test','test','0.0'),('2019-12-31 03:59:59','2019-12-31 07:59:59','WANBTC','4h','0.000025200000000','0.000024948000000','0.036773122652731','0.036405391426204','1459.2508989178834','1459.250898917883433','test','test','1.00'),('2019-12-31 11:59:59','2019-12-31 15:59:59','WANBTC','4h','0.000025450000000','0.000025195500000','0.036691404602391','0.036324490556367','1441.7054853591876','1441.705485359187605','test','test','0.99'),('2020-01-01 15:59:59','2020-01-01 15:59:59','WANBTC','4h','0.000024690000000','0.000024690000000','0.036609868147719','0.036609868147719','1482.781212949345','1482.781212949344990','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:37:15
