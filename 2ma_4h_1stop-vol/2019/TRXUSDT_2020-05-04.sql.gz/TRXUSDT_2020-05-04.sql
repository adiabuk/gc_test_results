-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-12 03:59:59','TRXUSDT','4h','0.019280000000000','0.023730000000000','222.222222222222200','273.513139695712312','11526.04887044721','11526.048870447209993','test','test','0.98'),('2019-01-14 07:59:59','2019-01-14 11:59:59','TRXUSDT','4h','0.023710000000000','0.023472900000000','233.620203882997771','231.284001844167790','9853.235085744318','9853.235085744317985','test','test','1.00'),('2019-01-14 15:59:59','2019-01-15 23:59:59','TRXUSDT','4h','0.024100000000000','0.023950000000000','233.101047874368902','231.650211476810568','9672.242650388751','9672.242650388750917','test','test','0.62'),('2019-01-17 19:59:59','2019-01-17 23:59:59','TRXUSDT','4h','0.025250000000000','0.024997500000000','232.778639786022609','230.450853388162386','9218.956031129608','9218.956031129608164','test','test','0.99'),('2019-01-19 11:59:59','2019-01-19 19:59:59','TRXUSDT','4h','0.024740000000000','0.024492600000000','232.261353919831464','229.938740380633135','9388.09029587031','9388.090295870310001','test','test','1.00'),('2019-01-21 11:59:59','2019-01-28 15:59:59','TRXUSDT','4h','0.025160000000000','0.025900000000000','231.745217577787372','238.561253388898791','9210.859204204586','9210.859204204585694','test','test','0.07'),('2019-02-04 11:59:59','2019-02-05 03:59:59','TRXUSDT','4h','0.027060000000000','0.026789400000000','233.259892202478824','230.927293280454023','8620.099490113778','8620.099490113778302','test','test','0.99'),('2019-02-05 07:59:59','2019-02-05 15:59:59','TRXUSDT','4h','0.026960000000000','0.026690400000000','232.741536886473313','230.414121517608550','8632.846323682244','8632.846323682244474','test','test','1.00'),('2019-02-08 15:59:59','2019-02-09 15:59:59','TRXUSDT','4h','0.026640000000000','0.026400000000000','232.224333471170013','230.132222358817131','8717.12963480368','8717.129634803679437','test','test','0.90'),('2019-02-18 19:59:59','2019-02-20 03:59:59','TRXUSDT','4h','0.024840000000000','0.024640000000000','231.759419890647195','229.893402017131507','9330.08936757839','9330.089367578390011','test','test','0.80'),('2019-02-20 11:59:59','2019-02-21 11:59:59','TRXUSDT','4h','0.025060000000000','0.024809400000000','231.344749252088121','229.031301759567242','9231.634048367443','9231.634048367443029','test','test','1.00'),('2019-02-23 19:59:59','2019-02-24 15:59:59','TRXUSDT','4h','0.025040000000000','0.024789600000000','230.830649809305697','228.522343311212637','9218.476430084094','9218.476430084094318','test','test','1.00'),('2019-03-05 19:59:59','2019-03-05 23:59:59','TRXUSDT','4h','0.023600000000000','0.023750000000000','230.317692809729465','231.781576450469288','9759.224271598707','9759.224271598706764','test','test','0.0'),('2019-03-15 15:59:59','2019-03-15 19:59:59','TRXUSDT','4h','0.022740000000000','0.022910000000000','230.643000285449460','232.367244350907953','10142.612149755912','10142.612149755912469','test','test','0.0'),('2019-03-15 23:59:59','2019-03-17 03:59:59','TRXUSDT','4h','0.022950000000000','0.022800000000000','231.026165633329100','229.516190694549152','10066.499591866192','10066.499591866191622','test','test','0.65'),('2019-03-23 11:59:59','2019-03-24 07:59:59','TRXUSDT','4h','0.023960000000000','0.023720400000000','230.690615646933566','228.383709490464241','9628.15591180858','9628.155911808580640','test','test','0.99'),('2019-03-27 11:59:59','2019-03-28 03:59:59','TRXUSDT','4h','0.023200000000000','0.022968000000000','230.177969834384811','227.876190136040947','9921.464216999346','9921.464216999345808','test','test','0.99'),('2019-03-29 07:59:59','2019-03-29 11:59:59','TRXUSDT','4h','0.023560000000000','0.023324400000000','229.666463234752854','227.369798602405325','9748.152089760308','9748.152089760307717','test','test','0.99'),('2019-03-29 15:59:59','2019-03-30 07:59:59','TRXUSDT','4h','0.023210000000000','0.023160000000000','229.156093316453394','228.662435209351997','9873.16214202729','9873.162142027289519','test','test','0.64'),('2019-04-01 15:59:59','2019-04-11 03:59:59','TRXUSDT','4h','0.024080000000000','0.027180000000000','229.046391514875296','258.533260854414891','9511.893335335353','9511.893335335353186','test','test','0.0'),('2019-04-15 11:59:59','2019-04-15 15:59:59','TRXUSDT','4h','0.026830000000000','0.027130000000000','235.599029145884089','238.233382807597309','8781.178872377342','8781.178872377342486','test','test','0.0'),('2019-04-18 03:59:59','2019-04-18 11:59:59','TRXUSDT','4h','0.026920000000000','0.026690000000000','236.184441070709255','234.166520511784171','8773.567647500344','8773.567647500343810','test','test','0.85'),('2019-05-03 23:59:59','2019-05-04 07:59:59','TRXUSDT','4h','0.023810000000000','0.023740000000000','235.736014279837036','235.042964258854738','9900.714585461446','9900.714585461446404','test','test','0.29'),('2019-05-06 19:59:59','2019-05-07 15:59:59','TRXUSDT','4h','0.024010000000000','0.023830000000000','235.582003164063167','233.815874027472944','9811.828536612376','9811.828536612376411','test','test','0.91'),('2019-05-08 03:59:59','2019-05-09 03:59:59','TRXUSDT','4h','0.024630000000000','0.024383700000000','235.189530022598660','232.837634722372684','9548.904994827391','9548.904994827391420','test','test','1.00'),('2019-05-11 11:59:59','2019-05-12 11:59:59','TRXUSDT','4h','0.024500000000000','0.024255000000000','234.666886622548446','232.320217756322990','9578.240270308099','9578.240270308098843','test','test','0.99'),('2019-05-13 15:59:59','2019-05-13 23:59:59','TRXUSDT','4h','0.024840000000000','0.024591600000000','234.145404652276142','231.803950605753386','9426.143504519972','9426.143504519972339','test','test','0.99'),('2019-05-14 03:59:59','2019-05-17 03:59:59','TRXUSDT','4h','0.025740000000000','0.026060000000000','233.625081530826606','236.529511448847785','9076.343493816108','9076.343493816108094','test','test','0.03'),('2019-05-21 11:59:59','2019-05-22 11:59:59','TRXUSDT','4h','0.028560000000000','0.028274400000000','234.270510401498058','231.927805297483076','8202.748963637887','8202.748963637886845','test','test','1.00'),('2019-05-24 11:59:59','2019-05-24 19:59:59','TRXUSDT','4h','0.028030000000000','0.027749700000000','233.749909267272443','231.412410174599728','8339.276106574116','8339.276106574116056','test','test','1.00'),('2019-05-25 03:59:59','2019-05-25 07:59:59','TRXUSDT','4h','0.028090000000000','0.027809100000000','233.230465024456294','230.898160374211727','8302.971342985273','8302.971342985272713','test','test','1.00'),('2019-05-26 07:59:59','2019-05-30 23:59:59','TRXUSDT','4h','0.028750000000000','0.031020000000000','232.712175102179714','251.086319014595290','8094.336525293207','8094.336525293207160','test','test','0.0'),('2019-06-01 03:59:59','2019-06-03 23:59:59','TRXUSDT','4h','0.033700000000000','0.033750000000000','236.795318193827626','237.146646559100390','7026.567305454825','7026.567305454825146','test','test','0.0'),('2019-06-12 15:59:59','2019-06-12 19:59:59','TRXUSDT','4h','0.032820000000000','0.032491800000000','236.873391163888272','234.504657252249388','7217.3489081014095','7217.348908101409506','test','test','1.00'),('2019-06-12 23:59:59','2019-06-13 03:59:59','TRXUSDT','4h','0.033490000000000','0.033155100000000','236.347005850190726','233.983535791688809','7057.241142137675','7057.241142137674615','test','test','0.99'),('2019-06-15 19:59:59','2019-06-15 23:59:59','TRXUSDT','4h','0.032450000000000','0.032640000000000','235.821790281634748','237.202565016719831','7267.2354478161715','7267.235447816171472','test','test','0.0'),('2019-06-16 07:59:59','2019-06-16 11:59:59','TRXUSDT','4h','0.033120000000000','0.032788800000000','236.128629111653623','233.767342820537067','7129.487593950895','7129.487593950894734','test','test','1.00'),('2019-06-16 15:59:59','2019-06-16 19:59:59','TRXUSDT','4h','0.033560000000000','0.033224400000000','235.603898824738849','233.247859836491472','7020.37839167875','7020.378391678749722','test','test','0.99'),('2019-06-17 03:59:59','2019-06-18 07:59:59','TRXUSDT','4h','0.033000000000000','0.032670000000000','235.080334605128314','232.729531259077049','7123.646503185706','7123.646503185706024','test','test','0.99'),('2019-06-21 03:59:59','2019-06-26 23:59:59','TRXUSDT','4h','0.033030000000000','0.036770000000000','234.557933861561395','261.117021740527207','7101.360395445396','7101.360395445395625','test','test','0.39'),('2019-07-07 19:59:59','2019-07-08 11:59:59','TRXUSDT','4h','0.034810000000000','0.034461900000000','240.459953390220448','238.055353856318277','6907.783780241897','6907.783780241897148','test','test','0.99'),('2019-07-09 11:59:59','2019-07-10 07:59:59','TRXUSDT','4h','0.034230000000000','0.033887700000000','239.925597938242191','237.526341958859746','7009.219922239036','7009.219922239036350','test','test','1.00'),('2019-07-20 03:59:59','2019-07-21 15:59:59','TRXUSDT','4h','0.027890000000000','0.027870000000000','239.392429942823895','239.220760936052386','8583.45033857382','8583.450338573820773','test','test','0.07'),('2019-08-05 15:59:59','2019-08-05 19:59:59','TRXUSDT','4h','0.023330000000000','0.023096700000000','239.354281274652436','236.960738461905947','10259.506269809362','10259.506269809362493','test','test','0.99'),('2019-08-06 07:59:59','2019-08-06 11:59:59','TRXUSDT','4h','0.022860000000000','0.022631400000000','238.822382871819883','236.434159043101687','10447.173353972874','10447.173353972873883','test','test','0.99'),('2019-09-08 03:59:59','2019-09-08 07:59:59','TRXUSDT','4h','0.016060000000000','0.015899400000000','238.291666465438055','235.908749800783681','14837.588198346079','14837.588198346078570','test','test','1.00'),('2019-09-09 11:59:59','2019-09-09 15:59:59','TRXUSDT','4h','0.015800000000000','0.015680000000000','237.762129428848198','235.956341104072095','15048.236039800517','15048.236039800516664','test','test','0.75'),('2019-09-10 03:59:59','2019-09-10 11:59:59','TRXUSDT','4h','0.015980000000000','0.015820200000000','237.360843134453518','234.987234703108953','14853.619720554036','14853.619720554035666','test','test','1.00'),('2019-09-14 19:59:59','2019-09-15 19:59:59','TRXUSDT','4h','0.015790000000000','0.015632100000000','236.833374594154719','234.465040848213192','14998.94709272671','14998.947092726710252','test','test','0.99'),('2019-09-16 07:59:59','2019-09-16 11:59:59','TRXUSDT','4h','0.015680000000000','0.015620000000000','236.307078206167716','235.402841937521686','15070.604477434166','15070.604477434166256','test','test','0.38'),('2019-09-16 23:59:59','2019-09-22 19:59:59','TRXUSDT','4h','0.015650000000000','0.016580000000000','236.106136813135237','250.136725134938189','15086.65410946551','15086.654109465509464','test','test','0.0'),('2019-09-23 15:59:59','2019-09-23 19:59:59','TRXUSDT','4h','0.016960000000000','0.016790400000000','239.224045329091467','236.831804875800572','14105.191351951149','14105.191351951149045','test','test','0.99'),('2019-09-30 19:59:59','2019-09-30 23:59:59','TRXUSDT','4h','0.014630000000000','0.014530000000000','238.692436339471243','237.060909091764643','16315.272477065702','16315.272477065702333','test','test','0.68'),('2019-10-01 03:59:59','2019-10-01 07:59:59','TRXUSDT','4h','0.014600000000000','0.014550000000000','238.329874728869783','237.513676527743513','16323.964022525328','16323.964022525327891','test','test','0.34'),('2019-10-04 11:59:59','2019-10-05 15:59:59','TRXUSDT','4h','0.014420000000000','0.014710000000000','238.148497350841780','242.937891541670069','16515.152382166558','16515.152382166557800','test','test','0.0'),('2019-10-05 19:59:59','2019-10-06 11:59:59','TRXUSDT','4h','0.014990000000000','0.014840100000000','239.212807171025815','236.820679099315555','15958.159250902323','15958.159250902323038','test','test','0.99'),('2019-10-06 15:59:59','2019-10-06 19:59:59','TRXUSDT','4h','0.014890000000000','0.014741100000000','238.681223155090152','236.294410923539260','16029.632179656826','16029.632179656826338','test','test','1.00'),('2019-10-07 03:59:59','2019-10-15 19:59:59','TRXUSDT','4h','0.014800000000000','0.015610000000000','238.150820436967791','251.184750474396452','16091.271651146471','16091.271651146471413','test','test','0.0'),('2019-10-19 15:59:59','2019-10-19 19:59:59','TRXUSDT','4h','0.015650000000000','0.015493500000000','241.047249334174126','238.636776840832368','15402.380149148506','15402.380149148506462','test','test','1.00'),('2019-10-25 11:59:59','2019-11-04 07:59:59','TRXUSDT','4h','0.015410000000000','0.019090000000000','240.511588780098151','297.947192070867857','15607.5008942309','15607.500894230899576','test','test','0.0'),('2019-11-04 11:59:59','2019-11-07 11:59:59','TRXUSDT','4h','0.019530000000000','0.019340000000000','253.275056178047038','250.811038734430610','12968.512861139123','12968.512861139122833','test','test','0.97'),('2019-11-10 19:59:59','2019-11-11 03:59:59','TRXUSDT','4h','0.019420000000000','0.019225800000000','252.727496746132260','250.200221778670965','13013.774291767882','13013.774291767882460','test','test','0.99'),('2019-11-12 11:59:59','2019-11-12 15:59:59','TRXUSDT','4h','0.019600000000000','0.019410000000000','252.165880086696376','249.721414922590668','12865.606126872264','12865.606126872264213','test','test','0.96'),('2019-11-12 19:59:59','2019-11-13 01:59:59','TRXUSDT','4h','0.019680000000000','0.019483200000000','251.622665605784022','249.106438949726169','12785.704553139432','12785.704553139432392','test','test','1.00'),('2019-11-13 11:59:59','2019-11-14 07:59:59','TRXUSDT','4h','0.019950000000000','0.019750500000000','251.063504126660064','248.552869085393439','12584.636798328826','12584.636798328825535','test','test','1.00'),('2019-11-27 19:59:59','2019-11-27 23:59:59','TRXUSDT','4h','0.016240000000000','0.016077600000000','250.505585228600808','248.000529376314802','15425.220765307931','15425.220765307931288','test','test','1.00'),('2019-12-22 03:59:59','2019-12-23 19:59:59','TRXUSDT','4h','0.013870000000000','0.014040000000000','249.948906150315025','253.012447177391692','18020.829571039296','18020.829571039295843','test','test','0.0'),('2019-12-29 19:59:59','2019-12-30 03:59:59','TRXUSDT','4h','0.013770000000000','0.013632300000000','250.629693045220961','248.123396114768781','18201.139654700142','18201.139654700142273','test','test','0.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:47:27
