-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-02 15:59:59','MCOBTC','4h','0.000604000000000','0.000597960000000','0.033333333333333','0.033000000000000','55.187637969094915','55.187637969094915','test','test','1.00'),('2019-01-03 15:59:59','2019-01-10 07:59:59','MCOBTC','4h','0.000605000000000','0.000638000000000','0.033259259259259','0.035073400673400','54.973982246709646','54.973982246709646','test','test','0.99'),('2019-01-12 03:59:59','2019-01-12 11:59:59','MCOBTC','4h','0.000641000000000','0.000634590000000','0.033662401795735','0.033325777777778','52.51544741924354','52.515447419243543','test','test','0.99'),('2019-01-17 23:59:59','2019-01-18 07:59:59','MCOBTC','4h','0.000627000000000','0.000622000000000','0.033587596458411','0.033319752786494','53.56873438343115','53.568734383431149','test','test','0.79'),('2019-01-18 23:59:59','2019-01-19 07:59:59','MCOBTC','4h','0.000631000000000','0.000624690000000','0.033528075642430','0.033192794886006','53.134826691647824','53.134826691647824','test','test','1.00'),('2019-01-19 11:59:59','2019-01-20 11:59:59','MCOBTC','4h','0.000635000000000','0.000628650000000','0.033453568807669','0.033119033119592','52.68278552388801','52.682785523888008','test','test','1.00'),('2019-01-26 11:59:59','2019-01-26 19:59:59','MCOBTC','4h','0.000629000000000','0.000624000000000','0.033379227543652','0.033113891871604','53.067134409621275','53.067134409621275','test','test','0.79'),('2019-02-08 15:59:59','2019-02-08 19:59:59','MCOBTC','4h','0.000584000000000','0.000578160000000','0.033320264060974','0.032987061420364','57.05524667975076','57.055246679750759','test','test','1.00'),('2019-02-09 03:59:59','2019-02-10 07:59:59','MCOBTC','4h','0.000582000000000','0.000576180000000','0.033246219029728','0.032913756839431','57.12408767994463','57.124087679944630','test','test','1.00'),('2019-02-10 11:59:59','2019-02-10 19:59:59','MCOBTC','4h','0.000586000000000','0.000580140000000','0.033172338542995','0.032840615157565','56.60808625084489','56.608086250844892','test','test','1.00'),('2019-02-11 19:59:59','2019-02-11 23:59:59','MCOBTC','4h','0.000587000000000','0.000581130000000','0.033098622235122','0.032767636012771','56.38606854364869','56.386068543648690','test','test','1.00'),('2019-02-12 19:59:59','2019-02-13 03:59:59','MCOBTC','4h','0.000583000000000','0.000579000000000','0.033025069741266','0.032798482641841','56.64677485637392','56.646774856373924','test','test','0.68'),('2019-02-15 03:59:59','2019-02-15 15:59:59','MCOBTC','4h','0.000684000000000','0.000677160000000','0.032974717052505','0.032644969881980','48.20865066155685','48.208650661556852','test','test','1.00'),('2019-02-15 23:59:59','2019-02-16 11:59:59','MCOBTC','4h','0.000729000000000','0.000721710000000','0.032901439903499','0.032572425504464','45.13229067695381','45.132290676953808','test','test','0.99'),('2019-02-16 15:59:59','2019-02-16 19:59:59','MCOBTC','4h','0.000758000000000','0.000750420000000','0.032828325592603','0.032500042336677','43.309136665702724','43.309136665702724','test','test','0.99'),('2019-02-18 03:59:59','2019-02-19 03:59:59','MCOBTC','4h','0.000724000000000','0.000716760000000','0.032755373757952','0.032427820020372','45.24222894744812','45.242228947448119','test','test','1.00'),('2019-02-20 11:59:59','2019-02-23 07:59:59','MCOBTC','4h','0.000761000000000','0.000753390000000','0.032682584038490','0.032355758198105','42.9468909835614','42.946890983561403','test','test','1.00'),('2019-02-24 11:59:59','2019-02-24 15:59:59','MCOBTC','4h','0.000726000000000','0.000718740000000','0.032609956073960','0.032283856513220','44.91729486771381','44.917294867713807','test','test','1.00'),('2019-03-06 11:59:59','2019-03-06 15:59:59','MCOBTC','4h','0.000693000000000','0.000686070000000','0.032537489504907','0.032212114609858','46.951644307224946','46.951644307224946','test','test','1.00'),('2019-03-09 15:59:59','2019-03-21 15:59:59','MCOBTC','4h','0.000708000000000','0.000801000000000','0.032465183972674','0.036729678477559','45.85477962242059','45.854779622420587','test','test','0.84'),('2019-03-24 15:59:59','2019-03-24 19:59:59','MCOBTC','4h','0.000801000000000','0.000800000000000','0.033412849418204','0.033371135498830','41.713919373537806','41.713919373537806','test','test','0.12'),('2019-03-25 11:59:59','2019-03-25 15:59:59','MCOBTC','4h','0.000808000000000','0.000823000000000','0.033403579658343','0.034023695617347','41.341063933592686','41.341063933592686','test','test','0.0'),('2019-03-26 07:59:59','2019-03-26 15:59:59','MCOBTC','4h','0.000808000000000','0.000812000000000','0.033541383204788','0.033707429656297','41.511612877213146','41.511612877213146','test','test','0.0'),('2019-03-26 19:59:59','2019-03-30 19:59:59','MCOBTC','4h','0.000822000000000','0.000837000000000','0.033578282416235','0.034191024796093','40.84949199055312','40.849491990553119','test','test','0.0'),('2019-03-31 15:59:59','2019-04-01 15:59:59','MCOBTC','4h','0.000868000000000','0.000859320000000','0.033714447389536','0.033377302915641','38.84152925061803','38.841529250618031','test','test','1.00'),('2019-04-11 07:59:59','2019-04-11 11:59:59','MCOBTC','4h','0.000788000000000','0.000780120000000','0.033639526395338','0.033303131131385','42.689754308804','42.689754308803998','test','test','1.00'),('2019-04-12 07:59:59','2019-04-13 23:59:59','MCOBTC','4h','0.000790000000000','0.000782100000000','0.033564771892237','0.033229124173315','42.48705302814796','42.487053028147962','test','test','1.00'),('2019-04-14 23:59:59','2019-04-15 19:59:59','MCOBTC','4h','0.000798000000000','0.000790020000000','0.033490183510254','0.033155281675151','41.9676485090905','41.967648509090502','test','test','0.99'),('2019-04-16 11:59:59','2019-04-16 19:59:59','MCOBTC','4h','0.000810000000000','0.000801900000000','0.033415760880231','0.033081603271429','41.25402577806338','41.254025778063379','test','test','1.00'),('2019-04-17 07:59:59','2019-04-23 19:59:59','MCOBTC','4h','0.000814000000000','0.000866000000000','0.033341503633831','0.035471427698891','40.96007817423942','40.960078174239420','test','test','0.0'),('2019-04-25 11:59:59','2019-04-25 23:59:59','MCOBTC','4h','0.000878000000000','0.000869220000000','0.033814820092733','0.033476671891806','38.513462520197166','38.513462520197166','test','test','1.00'),('2019-04-26 03:59:59','2019-04-26 07:59:59','MCOBTC','4h','0.000896000000000','0.000887040000000','0.033739676048083','0.033402279287602','37.655888446520834','37.655888446520834','test','test','1.00'),('2019-04-30 03:59:59','2019-04-30 11:59:59','MCOBTC','4h','0.000897000000000','0.000888030000000','0.033664698990198','0.033328052000296','37.53032217413377','37.530322174133772','test','test','0.99'),('2019-04-30 23:59:59','2019-05-01 11:59:59','MCOBTC','4h','0.000914000000000','0.000904860000000','0.033589888547998','0.033253989662518','36.750425107218334','36.750425107218334','test','test','1.00'),('2019-05-23 11:59:59','2019-05-23 15:59:59','MCOBTC','4h','0.000674000000000','0.000667260000000','0.033515244351224','0.033180091907712','49.72588182674217','49.725881826742167','test','test','0.99'),('2019-05-26 03:59:59','2019-05-26 07:59:59','MCOBTC','4h','0.000705000000000','0.000697950000000','0.033440766030444','0.033106358370140','47.433710681480534','47.433710681480534','test','test','0.99'),('2019-05-27 03:59:59','2019-05-28 07:59:59','MCOBTC','4h','0.000783000000000','0.000775170000000','0.033366453217043','0.033032788684873','42.61360564117866','42.613605641178658','test','test','1.00'),('2019-05-30 11:59:59','2019-05-30 15:59:59','MCOBTC','4h','0.000775000000000','0.000767250000000','0.033292305543227','0.032959382487795','42.9578136041643','42.957813604164301','test','test','1.00'),('2019-05-31 11:59:59','2019-05-31 19:59:59','MCOBTC','4h','0.000788000000000','0.000780120000000','0.033218322642020','0.032886139415600','42.15523177921347','42.155231779213473','test','test','1.00'),('2019-06-02 11:59:59','2019-06-03 11:59:59','MCOBTC','4h','0.000775000000000','0.000767250000000','0.033144504147260','0.032813059105787','42.76710212549706','42.767102125497061','test','test','1.00'),('2019-06-04 03:59:59','2019-06-05 23:59:59','MCOBTC','4h','0.000765000000000','0.000757350000000','0.033070849693600','0.032740141196664','43.229868880522304','43.229868880522304','test','test','0.99'),('2019-06-06 11:59:59','2019-06-06 15:59:59','MCOBTC','4h','0.000761000000000','0.000754000000000','0.032997358916503','0.032693835247100','43.36052420039772','43.360524200397720','test','test','0.91'),('2019-06-06 23:59:59','2019-06-07 03:59:59','MCOBTC','4h','0.000758000000000','0.000753000000000','0.032929909212191','0.032712693452216','43.44315199497479','43.443151994974791','test','test','0.65'),('2019-06-08 03:59:59','2019-06-09 19:59:59','MCOBTC','4h','0.000766000000000','0.000770000000000','0.032881639043308','0.033053344730218','42.92642172755556','42.926421727555557','test','test','0.65'),('2019-06-10 07:59:59','2019-06-10 15:59:59','MCOBTC','4h','0.000777000000000','0.000769230000000','0.032919795862621','0.032590597903995','42.36781964301272','42.367819643012723','test','test','1.00'),('2019-06-11 03:59:59','2019-06-14 07:59:59','MCOBTC','4h','0.000793000000000','0.000785070000000','0.032846640760704','0.032518174353097','41.42073235902144','41.420732359021443','test','test','0.99'),('2019-07-01 11:59:59','2019-07-02 15:59:59','MCOBTC','4h','0.000580000000000','0.000575000000000','0.032773648225680','0.032491116775459','56.50629004427624','56.506290044276241','test','test','0.86'),('2019-07-14 07:59:59','2019-07-14 11:59:59','MCOBTC','4h','0.000527000000000','0.000521730000000','0.032710863458964','0.032383754824374','62.06994963750368','62.069949637503683','test','test','1.00'),('2019-07-14 15:59:59','2019-07-14 19:59:59','MCOBTC','4h','0.000515000000000','0.000511000000000','0.032638172651278','0.032384672281171','63.37509252675296','63.375092526752958','test','test','0.77'),('2019-07-24 03:59:59','2019-07-24 07:59:59','MCOBTC','4h','0.000519000000000','0.000513810000000','0.032581839235698','0.032256020843341','62.778110280729166','62.778110280729166','test','test','0.99'),('2019-07-28 11:59:59','2019-07-28 15:59:59','MCOBTC','4h','0.000466000000000','0.000472000000000','0.032509435148508','0.032928011566729','69.76273637018885','69.762736370188847','test','test','0.0'),('2019-07-29 15:59:59','2019-07-29 19:59:59','MCOBTC','4h','0.000468000000000','0.000465000000000','0.032602452130335','0.032393462052576','69.66335925285233','69.663359252852331','test','test','0.64'),('2019-07-29 23:59:59','2019-07-30 07:59:59','MCOBTC','4h','0.000469000000000','0.000465000000000','0.032556009890833','0.032278346693470','69.41579934079506','69.415799340795061','test','test','0.85'),('2019-08-22 07:59:59','2019-08-22 11:59:59','MCOBTC','4h','0.000334000000000','0.000333000000000','0.032494306958086','0.032397018613900','97.28834418588488','97.288344185884881','test','test','0.29'),('2019-08-22 15:59:59','2019-08-25 15:59:59','MCOBTC','4h','0.000333000000000','0.000340000000000','0.032472687326044','0.033155296368934','97.51557755568837','97.515577555688367','test','test','0.0'),('2019-08-26 15:59:59','2019-08-27 03:59:59','MCOBTC','4h','0.000355000000000','0.000351450000000','0.032624378224464','0.032298134442219','91.89965697032174','91.899656970321743','test','test','1.00'),('2019-08-28 19:59:59','2019-08-29 03:59:59','MCOBTC','4h','0.000347000000000','0.000343530000000','0.032551879606188','0.032226360810126','93.80945131466156','93.809451314661558','test','test','0.99'),('2019-09-10 11:59:59','2019-09-10 15:59:59','MCOBTC','4h','0.000320000000000','0.000319000000000','0.032479542095952','0.032378043526902','101.49856904984861','101.498569049848612','test','test','0.31'),('2019-09-10 19:59:59','2019-09-10 23:59:59','MCOBTC','4h','0.000323000000000','0.000319770000000','0.032456986858385','0.032132416989801','100.48602742534023','100.486027425340225','test','test','1.00'),('2019-09-11 03:59:59','2019-09-11 11:59:59','MCOBTC','4h','0.000322000000000','0.000319000000000','0.032384860220922','0.032083137920727','100.57410006497444','100.574100064974445','test','test','0.93'),('2019-09-14 07:59:59','2019-09-15 03:59:59','MCOBTC','4h','0.000320000000000','0.000319000000000','0.032317810820878','0.032216817662063','100.99315881524512','100.993158815245124','test','test','0.31'),('2019-09-16 15:59:59','2019-09-17 15:59:59','MCOBTC','4h','0.000326000000000','0.000322740000000','0.032295367896697','0.031972414217730','99.06554569539058','99.065545695390583','test','test','0.99'),('2019-09-17 19:59:59','2019-09-19 07:59:59','MCOBTC','4h','0.000325200000000','0.000327800000000','0.032223600412482','0.032481230674082','99.08856215400505','99.088562154005047','test','test','0.0'),('2019-09-22 15:59:59','2019-09-23 03:59:59','MCOBTC','4h','0.000330000000000','0.000326700000000','0.032280851581727','0.031958043065910','97.82076236886935','97.820762368869353','test','test','1.00'),('2019-09-23 15:59:59','2019-09-24 19:59:59','MCOBTC','4h','0.000330600000000','0.000327294000000','0.032209116355990','0.031887025192430','97.42624427099145','97.426244270991447','test','test','1.00'),('2019-09-25 11:59:59','2019-10-26 03:59:59','MCOBTC','4h','0.000331500000000','0.000434400000000','0.032137540541865','0.042113265796037','96.94582365570238','96.945823655702384','test','test','0.0'),('2019-10-29 07:59:59','2019-11-04 23:59:59','MCOBTC','4h','0.000438500000000','0.000451800000000','0.034354368376126','0.035396359480807','78.34519584065173','78.345195840651726','test','test','0.0'),('2019-11-05 11:59:59','2019-11-29 23:59:59','MCOBTC','4h','0.000459900000000','0.000532400000000','0.034585921954944','0.040038149268998','75.20313536626175','75.203135366261748','test','test','0.0'),('2019-11-30 23:59:59','2019-12-01 03:59:59','MCOBTC','4h','0.000538700000000','0.000534200000000','0.035797528024734','0.035498495397833','66.45169486677845','66.451694866778453','test','test','0.83'),('2019-12-04 03:59:59','2019-12-16 15:59:59','MCOBTC','4h','0.000541000000000','0.000582600000000','0.035731076329867','0.038478604565214','66.0463518112138','66.046351811213796','test','test','0.51'),('2019-12-22 11:59:59','2019-12-22 15:59:59','MCOBTC','4h','0.000567600000000','0.000564700000000','0.036341638159944','0.036155960304652','64.02684665247318','64.026846652473182','test','test','0.51'),('2019-12-31 15:59:59','2020-01-01 15:59:59','MCOBTC','4h','0.000554300000000','0.000556200000000','0.036300376414323','0.036424804910060','65.48868196702749','65.488681967027489','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:26:00
