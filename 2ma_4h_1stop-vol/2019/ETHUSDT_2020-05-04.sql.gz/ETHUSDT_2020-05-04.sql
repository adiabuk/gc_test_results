-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-10 07:59:59','ETHUSDT','4h','139.099999999999994','137.709000000000003','222.222222222222200','220.000000000000000','1.597571691029635','1.597571691029635','test','test','0.99'),('2019-02-08 15:59:59','2019-02-24 15:59:59','ETHUSDT','4h','112.560000000000002','139.990000000000009','221.728395061728406','275.761887212965178','1.9698684706976581','1.969868470697658','test','test','0.0'),('2019-03-05 19:59:59','2019-03-06 03:59:59','ETHUSDT','4h','136.650000000000006','135.283500000000004','233.735837762003229','231.398479384383194','1.7104708215294784','1.710470821529478','test','test','1.00'),('2019-03-06 11:59:59','2019-03-06 19:59:59','ETHUSDT','4h','138.650000000000006','137.263499999999993','233.216424789198783','230.884260541306759','1.6820513868676434','1.682051386867643','test','test','1.00'),('2019-03-09 07:59:59','2019-03-09 19:59:59','ETHUSDT','4h','137.090000000000003','136.969999999999999','232.698166067445044','232.494476666846225','1.6974116716569045','1.697411671656905','test','test','0.08'),('2019-03-15 11:59:59','2019-03-20 11:59:59','ETHUSDT','4h','134.909999999999997','138.199999999999989','232.652901756200805','238.326521552938601','1.7245044974887023','1.724504497488702','test','test','0.0'),('2019-03-21 03:59:59','2019-03-21 15:59:59','ETHUSDT','4h','138.710000000000008','137.322900000000004','233.913706155475865','231.574569093921099','1.6863507040262118','1.686350704026212','test','test','1.00'),('2019-03-23 07:59:59','2019-03-23 11:59:59','ETHUSDT','4h','137.659999999999997','137.090000000000003','233.393897919574812','232.427498661880833','1.6954372942000204','1.695437294200020','test','test','0.41'),('2019-03-27 07:59:59','2019-04-11 11:59:59','ETHUSDT','4h','137.250000000000000','162.550000000000011','233.179142528976172','276.162255869472347','1.6989372861856187','1.698937286185619','test','test','0.0'),('2019-04-14 23:59:59','2019-04-15 11:59:59','ETHUSDT','4h','167.229999999999990','165.557699999999983','242.730945493530868','240.303636038595556','1.4514796716709375','1.451479671670937','test','test','1.00'),('2019-04-16 19:59:59','2019-04-16 23:59:59','ETHUSDT','4h','164.379999999999995','165.370000000000005','242.191543392434141','243.650173566168831','1.4733638118532313','1.473363811853231','test','test','0.0'),('2019-04-17 11:59:59','2019-04-21 11:59:59','ETHUSDT','4h','166.099999999999994','166.840000000000003','242.515683431041879','243.596126572155498','1.4600582988021786','1.460058298802179','test','test','0.57'),('2019-04-22 11:59:59','2019-04-22 19:59:59','ETHUSDT','4h','170.490000000000009','171.530000000000001','242.755781906844874','244.236607839058593','1.4238710886670471','1.423871088667047','test','test','0.42'),('2019-04-23 07:59:59','2019-04-23 19:59:59','ETHUSDT','4h','174.460000000000008','172.715400000000017','243.084854336225703','240.654005792863472','1.39335580841583','1.393355808415830','test','test','0.99'),('2019-05-02 15:59:59','2019-05-02 19:59:59','ETHUSDT','4h','162.069999999999993','160.759999999999991','242.544665771034062','240.584194911775370','1.4965426406554827','1.496542640655483','test','test','0.80'),('2019-05-02 23:59:59','2019-05-03 03:59:59','ETHUSDT','4h','161.810000000000002','162.419999999999987','242.109005580087683','243.021721069883455','1.4962549013045403','1.496254901304540','test','test','0.0'),('2019-05-03 07:59:59','2019-05-04 07:59:59','ETHUSDT','4h','163.590000000000003','165.930000000000007','242.311831244486740','245.777872476298597','1.4812142016289915','1.481214201628992','test','test','0.0'),('2019-05-06 11:59:59','2019-05-08 03:59:59','ETHUSDT','4h','165.080000000000013','169.639999999999986','243.082062629333876','249.796711318392283','1.47251067742509','1.472510677425090','test','test','0.0'),('2019-05-10 03:59:59','2019-05-23 11:59:59','ETHUSDT','4h','171.139999999999986','235.960000000000008','244.574206782457935','337.207723690480179','1.429088505214783','1.429088505214783','test','test','0.0'),('2019-05-23 15:59:59','2019-05-30 23:59:59','ETHUSDT','4h','241.930000000000007','254.560000000000002','265.159432762018412','279.002129557720878','1.0960171651387525','1.096017165138752','test','test','0.31'),('2019-06-12 15:59:59','2019-06-27 11:59:59','ETHUSDT','4h','253.500000000000000','317.310000000000002','268.235587605507874','335.754770426444622','1.0581285507120626','1.058128550712063','test','test','0.04'),('2019-07-07 19:59:59','2019-07-10 15:59:59','ETHUSDT','4h','306.319999999999993','303.256799999999998','283.239850454604948','280.407451950058885','0.9246534684467386','0.924653468446739','test','test','0.99'),('2019-08-02 07:59:59','2019-08-02 19:59:59','ETHUSDT','4h','221.090000000000003','218.879099999999994','282.610428564705842','279.784324279058808','1.2782596615166033','1.278259661516603','test','test','1.00'),('2019-08-03 03:59:59','2019-08-04 03:59:59','ETHUSDT','4h','221.729999999999990','219.512699999999995','281.982405390117606','279.162581336216419','1.2717377233126668','1.271737723312667','test','test','0.99'),('2019-08-05 03:59:59','2019-08-06 23:59:59','ETHUSDT','4h','229.270000000000010','226.977300000000014','281.355777822583946','278.542220044358089','1.2271809561764904','1.227180956176490','test','test','0.99'),('2019-08-19 15:59:59','2019-08-19 19:59:59','ETHUSDT','4h','201.280000000000001','199.267200000000003','280.730542760756009','277.923237333148450','1.394726464431419','1.394726464431419','test','test','0.99'),('2019-09-03 15:59:59','2019-09-03 23:59:59','ETHUSDT','4h','181.259999999999991','179.447399999999988','280.106697110176526','277.305630139074765','1.5453310002768208','1.545331000276821','test','test','1.00'),('2019-09-08 03:59:59','2019-09-08 11:59:59','ETHUSDT','4h','182.949999999999989','181.120499999999993','279.484237783265030','276.689395405432379','1.5276536637511071','1.527653663751107','test','test','0.99'),('2019-09-08 15:59:59','2019-09-09 03:59:59','ETHUSDT','4h','181.349999999999994','179.536499999999990','278.863161699302225','276.074530082309195','1.537706984832105','1.537706984832105','test','test','1.00'),('2019-09-09 11:59:59','2019-09-09 19:59:59','ETHUSDT','4h','182.780000000000001','180.952200000000005','278.243465784414923','275.461031126570788','1.522286167985638','1.522286167985638','test','test','0.99'),('2019-09-11 03:59:59','2019-09-11 07:59:59','ETHUSDT','4h','179.810000000000002','179.060000000000002','277.625146971560639','276.467153199085942','1.5439916966328937','1.543991696632894','test','test','0.41'),('2019-09-12 15:59:59','2019-09-13 11:59:59','ETHUSDT','4h','179.759999999999991','179.169999999999987','277.367815022121874','276.457451143266439','1.5429896251786932','1.542989625178693','test','test','0.58'),('2019-09-13 23:59:59','2019-09-23 23:59:59','ETHUSDT','4h','180.949999999999989','201.289999999999992','277.165511937931740','308.320784183400292','1.5317242991872437','1.531724299187244','test','test','0.55'),('2019-10-01 03:59:59','2019-10-01 07:59:59','ETHUSDT','4h','182.219999999999999','180.789999999999992','284.088905770258066','281.859473571534181','1.5590434956111188','1.559043495611119','test','test','0.78'),('2019-10-07 19:59:59','2019-10-08 19:59:59','ETHUSDT','4h','180.199999999999989','178.689999999999998','283.593476392763876','281.217082667164163','1.5737706792051271','1.573770679205127','test','test','0.83'),('2019-10-09 11:59:59','2019-10-11 19:59:59','ETHUSDT','4h','183.490000000000009','181.990000000000009','283.065388898186200','280.751376781191937','1.542674744662849','1.542674744662849','test','test','0.81'),('2019-10-14 19:59:59','2019-10-15 07:59:59','ETHUSDT','4h','185.810000000000002','183.951899999999995','282.551163983298579','279.725652343465583','1.5206456271637618','1.520645627163762','test','test','1.00'),('2019-10-25 15:59:59','2019-10-31 11:59:59','ETHUSDT','4h','175.520000000000010','180.300000000000011','281.923272507780098','289.600991528901318','1.6062173684353924','1.606217368435392','test','test','0.0'),('2019-10-31 15:59:59','2019-11-01 15:59:59','ETHUSDT','4h','181.710000000000008','179.892899999999997','283.629432290251486','280.793137967348969','1.5608906075078504','1.560890607507850','test','test','1.00'),('2019-11-04 11:59:59','2019-11-08 07:59:59','ETHUSDT','4h','184.830000000000013','184.960000000000008','282.999144662939841','283.198191834969180','1.531132092533354','1.531132092533354','test','test','0.51'),('2019-11-10 07:59:59','2019-11-10 19:59:59','ETHUSDT','4h','187.229999999999990','189.949999999999989','283.043377367835262','287.155314484966709','1.5117415871806617','1.511741587180662','test','test','0.35'),('2019-11-13 11:59:59','2019-11-14 07:59:59','ETHUSDT','4h','187.180000000000007','185.308199999999999','283.957141171642263','281.117569759925857','1.5170271459111135','1.517027145911114','test','test','1.00'),('2019-12-08 19:59:59','2019-12-09 03:59:59','ETHUSDT','4h','150.419999999999987','150.310000000000002','283.326125302371906','283.118932949072757','1.8835668481742582','1.883566848174258','test','test','0.07'),('2019-12-29 15:59:59','2019-12-30 15:59:59','ETHUSDT','4h','131.990000000000009','130.670100000000019','283.280082557194305','280.447281731622411','2.1462238242078513','2.146223824207851','test','test','0.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:46:26
