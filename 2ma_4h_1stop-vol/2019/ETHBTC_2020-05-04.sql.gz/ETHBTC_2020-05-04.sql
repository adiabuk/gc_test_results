-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-08 03:59:59','ETHBTC','4h','0.036629000000000','0.037143000000000','0.033333333333333','0.033801086570750','0.9100257537288304','0.910025753728830','test','test','0.0'),('2019-01-08 11:59:59','2019-01-08 15:59:59','ETHBTC','4h','0.037406000000000','0.037186000000000','0.033437278497204','0.033240620173155','0.8939014729509643','0.893901472950964','test','test','0.58'),('2019-01-09 03:59:59','2019-01-09 19:59:59','ETHBTC','4h','0.037759000000000','0.037381410000000','0.033393576647415','0.033059640880941','0.8843872096034087','0.884387209603409','test','test','0.99'),('2019-02-08 11:59:59','2019-02-24 19:59:59','ETHBTC','4h','0.031576000000000','0.036752000000000','0.033319368699310','0.038781145124051','1.0552118285821437','1.055211828582144','test','test','0.0'),('2019-02-25 03:59:59','2019-02-25 07:59:59','ETHBTC','4h','0.036534000000000','0.036269000000000','0.034533096793697','0.034282610379663','0.945231751072882','0.945231751072882','test','test','0.72'),('2019-03-05 19:59:59','2019-03-05 23:59:59','ETHBTC','4h','0.035449000000000','0.035450000000000','0.034477433146134','0.034478405738680','0.9725925455198611','0.972592545519861','test','test','0.0'),('2019-03-06 11:59:59','2019-03-06 19:59:59','ETHBTC','4h','0.035893000000000','0.035534070000000','0.034477649277810','0.034132872785032','0.9605675000086492','0.960567500008649','test','test','1.00'),('2019-03-15 15:59:59','2019-03-15 23:59:59','ETHBTC','4h','0.034832000000000','0.034804000000000','0.034401032279415','0.034373378716489','0.987627247341965','0.987627247341965','test','test','0.08'),('2019-03-16 03:59:59','2019-03-17 03:59:59','ETHBTC','4h','0.035075000000000','0.034724250000000','0.034394887043210','0.034050938172778','0.9806097517664876','0.980609751766488','test','test','0.99'),('2019-03-17 07:59:59','2019-03-18 07:59:59','ETHBTC','4h','0.034891000000000','0.034651000000000','0.034318453960891','0.034082392255849','0.9835904376742235','0.983590437674223','test','test','0.68'),('2019-03-27 11:59:59','2019-03-27 15:59:59','ETHBTC','4h','0.034359000000000','0.034336000000000','0.034265995804215','0.034243058061455','0.997293163485996','0.997293163485996','test','test','0.06'),('2019-03-30 03:59:59','2019-03-31 03:59:59','ETHBTC','4h','0.034965000000000','0.034615350000000','0.034260898528046','0.033918289542766','0.979862677764806','0.979862677764806','test','test','0.99'),('2019-04-07 23:59:59','2019-04-10 19:59:59','ETHBTC','4h','0.033702000000000','0.033582000000000','0.034184763197984','0.034063044261904','1.0143244673308476','1.014324467330848','test','test','0.35'),('2019-04-18 19:59:59','2019-04-18 23:59:59','ETHBTC','4h','0.033074000000000','0.032962000000000','0.034157714545522','0.034042044713355','1.0327663586358469','1.032766358635847','test','test','0.33'),('2019-04-19 11:59:59','2019-04-19 15:59:59','ETHBTC','4h','0.032940000000000','0.032692000000000','0.034132010138374','0.033875035684387','1.0361873144618636','1.036187314461864','test','test','0.75'),('2019-05-06 19:59:59','2019-05-07 07:59:59','ETHBTC','4h','0.030215000000000','0.029912850000000','0.034074904704154','0.033734155657112','1.1277479630698144','1.127747963069814','test','test','1.00'),('2019-05-15 15:59:59','2019-05-23 07:59:59','ETHBTC','4h','0.029813000000000','0.030991000000000','0.033999182693701','0.035342591180374','1.140414674594998','1.140414674594998','test','test','0.72'),('2019-05-24 11:59:59','2019-05-26 03:59:59','ETHBTC','4h','0.031482000000000','0.031167180000000','0.034297717912961','0.033954740733831','1.0894389782403067','1.089438978240307','test','test','1.00'),('2019-05-28 15:59:59','2019-05-29 03:59:59','ETHBTC','4h','0.031169000000000','0.031048000000000','0.034221500762044','0.034088650763898','1.0979338689737739','1.097933868973774','test','test','0.38'),('2019-05-29 15:59:59','2019-05-30 03:59:59','ETHBTC','4h','0.031298000000000','0.032502000000000','0.034191978540233','0.035507306745308','1.092465286607238','1.092465286607238','test','test','0.63'),('2019-05-30 07:59:59','2019-05-30 15:59:59','ETHBTC','4h','0.032545000000000','0.032219550000000','0.034484273696917','0.034139430959948','1.0595874541993138','1.059587454199314','test','test','0.99'),('2019-06-01 03:59:59','2019-06-01 15:59:59','ETHBTC','4h','0.031525000000000','0.031209750000000','0.034407641977590','0.034063565557814','1.091439872405717','1.091439872405717','test','test','0.99'),('2019-06-04 15:59:59','2019-06-04 19:59:59','ETHBTC','4h','0.031330000000000','0.031103000000000','0.034331180550973','0.034082435642417','1.0957925487064581','1.095792548706458','test','test','0.72'),('2019-06-05 11:59:59','2019-06-07 07:59:59','ETHBTC','4h','0.031474000000000','0.031223000000000','0.034275903904628','0.034002559179456','1.0890228094499446','1.089022809449945','test','test','0.79'),('2019-06-12 11:59:59','2019-06-12 15:59:59','ETHBTC','4h','0.031110000000000','0.031134000000000','0.034215160632367','0.034241556127551','1.0998122993367763','1.099812299336776','test','test','0.0'),('2019-06-12 19:59:59','2019-06-13 23:59:59','ETHBTC','4h','0.031514000000000','0.031198860000000','0.034221026297964','0.033878816034984','1.0858991653856556','1.085899165385656','test','test','1.00'),('2019-07-01 19:59:59','2019-07-02 15:59:59','ETHBTC','4h','0.027624000000000','0.027347760000000','0.034144979572857','0.033803529777128','1.2360621044329891','1.236062104432989','test','test','1.00'),('2019-07-07 19:59:59','2019-07-08 11:59:59','ETHBTC','4h','0.026690000000000','0.026423100000000','0.034069101840473','0.033728410822068','1.2764744039143001','1.276474403914300','test','test','1.00'),('2019-07-28 23:59:59','2019-07-29 11:59:59','ETHBTC','4h','0.022165000000000','0.022031000000000','0.033993392725272','0.033787883380576','1.5336518260894','1.533651826089400','test','test','0.60'),('2019-08-14 03:59:59','2019-08-14 19:59:59','ETHBTC','4h','0.019593000000000','0.019397070000000','0.033947723982006','0.033608246742186','1.7326455357528594','1.732645535752859','test','test','1.00'),('2019-08-22 15:59:59','2019-08-23 15:59:59','ETHBTC','4h','0.018903000000000','0.018713970000000','0.033872284595379','0.033533561749425','1.7918999415637258','1.791899941563726','test','test','0.99'),('2019-08-24 11:59:59','2019-08-25 11:59:59','ETHBTC','4h','0.018882000000000','0.018722000000000','0.033797012851834','0.033510627826080','1.7899064109646108','1.789906410964611','test','test','0.84'),('2019-09-08 03:59:59','2019-09-08 07:59:59','ETHBTC','4h','0.017357000000000','0.017220000000000','0.033733371735000','0.033467111901636','1.9435024333121824','1.943502433312182','test','test','0.78'),('2019-09-08 11:59:59','2019-09-09 07:59:59','ETHBTC','4h','0.017322000000000','0.017463000000000','0.033674202883141','0.033948308795075','1.9440135598164696','1.944013559816470','test','test','0.06'),('2019-09-09 11:59:59','2019-09-12 15:59:59','ETHBTC','4h','0.017554000000000','0.017409000000000','0.033735115308015','0.033456455645279','1.9217907774874734','1.921790777487473','test','test','0.82'),('2019-09-13 19:59:59','2019-09-14 11:59:59','ETHBTC','4h','0.017485000000000','0.017520000000000','0.033673190938518','0.033740595095387','1.9258330533896608','1.925833053389661','test','test','0.0'),('2019-09-14 15:59:59','2019-09-24 11:59:59','ETHBTC','4h','0.017868000000000','0.020317000000000','0.033688169640045','0.038305492644772','1.8853911820038431','1.885391182003843','test','test','0.0'),('2019-09-25 19:59:59','2019-09-25 23:59:59','ETHBTC','4h','0.020207000000000','0.020163000000000','0.034714241418873','0.034638652433748','1.7179314801243577','1.717931480124358','test','test','0.21'),('2019-09-26 15:59:59','2019-09-26 19:59:59','ETHBTC','4h','0.020179000000000','0.020305000000000','0.034697443866623','0.034914098702204','1.719482822073586','1.719482822073586','test','test','0.0'),('2019-09-30 07:59:59','2019-10-03 19:59:59','ETHBTC','4h','0.021393000000000','0.021179070000000','0.034745589385641','0.034398133491785','1.6241569385145092','1.624156938514509','test','test','1.00'),('2019-10-04 11:59:59','2019-10-11 19:59:59','ETHBTC','4h','0.021438000000000','0.021802000000000','0.034668376964784','0.035257018126048','1.617146047429051','1.617146047429051','test','test','0.0'),('2019-10-14 19:59:59','2019-10-15 15:59:59','ETHBTC','4h','0.022311000000000','0.022087890000000','0.034799186111732','0.034451194250615','1.5597322447103024','1.559732244710302','test','test','0.99'),('2019-11-05 15:59:59','2019-11-07 11:59:59','ETHBTC','4h','0.020321000000000','0.020291000000000','0.034721854587039','0.034670594529089','1.7086685983484522','1.708668598348452','test','test','0.49'),('2019-11-08 11:59:59','2019-11-21 11:59:59','ETHBTC','4h','0.020405000000000','0.021376000000000','0.034710463463050','0.036362208624658','1.701076376527812','1.701076376527812','test','test','0.0'),('2019-12-14 19:59:59','2019-12-14 23:59:59','ETHBTC','4h','0.020096000000000','0.020072000000000','0.035077517943407','0.035035626003188','1.7454975091265592','1.745497509126559','test','test','0.11'),('2019-12-29 19:59:59','2019-12-31 15:59:59','ETHBTC','4h','0.018054000000000','0.018033000000000','0.035068208623359','0.035027418084914','1.942406592630922','1.942406592630922','test','test','0.38');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:45:24
