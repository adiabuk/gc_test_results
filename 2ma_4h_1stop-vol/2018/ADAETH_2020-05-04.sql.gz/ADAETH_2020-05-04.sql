-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-29 07:59:59','2018-05-29 11:59:59','ADAETH','4h','0.000359480000000','0.000355885200000','1.297777777777778','1.284800000000000','3610.1529369583222','3610.152936958322243','test','test','0.99'),('2018-05-29 15:59:59','2018-06-03 23:59:59','ADAETH','4h','0.000356530000000','0.000365890000000','1.294893827160494','1.328888739852897','3631.9351167096565','3631.935116709656540','test','test','0.07'),('2018-06-14 03:59:59','2018-06-14 07:59:59','ADAETH','4h','0.000355920000000','0.000352360800000','1.302448252203250','1.289423769681217','3659.384839860783','3659.384839860782904','test','test','0.99'),('2018-06-30 15:59:59','2018-06-30 19:59:59','ADAETH','4h','0.000298120000000','0.000302480000000','1.299553922753909','1.318559877078366','4359.163835884575','4359.163835884574837','test','test','0.0'),('2018-07-01 11:59:59','2018-07-01 15:59:59','ADAETH','4h','0.000313010000000','0.000309879900000','1.303777468159344','1.290739693477750','4165.290144593924','4165.290144593924197','test','test','0.99'),('2018-07-01 23:59:59','2018-07-05 23:59:59','ADAETH','4h','0.000314530000000','0.000315610000000','1.300880184896768','1.305347010317836','4135.949463951826','4135.949463951826147','test','test','0.41'),('2018-07-13 23:59:59','2018-07-14 03:59:59','ADAETH','4h','0.000317920000000','0.000314740800000','1.301872812768116','1.288854084640435','4094.969843885619','4094.969843885618957','test','test','0.99'),('2018-07-14 07:59:59','2018-07-26 23:59:59','ADAETH','4h','0.000312690000000','0.000354780000000','1.298979762073076','1.473830439055569','4154.2094792704465','4154.209479270446536','test','test','0.0'),('2018-08-09 15:59:59','2018-08-10 11:59:59','ADAETH','4h','0.000331730000000','0.000328412700000','1.337835468069186','1.324457113388494','4032.9046756976622','4032.904675697662242','test','test','1.00'),('2018-08-10 23:59:59','2018-08-14 03:59:59','ADAETH','4h','0.000346000000000','0.000347180000000','1.334862500362365','1.339414921606375','3857.9841050935406','3857.984105093540620','test','test','0.0'),('2018-08-15 03:59:59','2018-08-15 07:59:59','ADAETH','4h','0.000344240000000','0.000346510000000','1.335874149527701','1.344683219709632','3880.6476572382658','3880.647657238265765','test','test','0.0'),('2018-08-17 15:59:59','2018-08-18 03:59:59','ADAETH','4h','0.000340820000000','0.000342790000000','1.337831720679241','1.345564625114832','3925.3322008075847','3925.332200807584741','test','test','0.0'),('2018-08-20 23:59:59','2018-08-21 03:59:59','ADAETH','4h','0.000338920000000','0.000335530800000','1.339550143887150','1.326154642448279','3952.4080723685533','3952.408072368553348','test','test','0.99'),('2018-08-25 19:59:59','2018-08-26 03:59:59','ADAETH','4h','0.000337550000000','0.000336560000000','1.336573365789623','1.332653331329153','3959.6307681517496','3959.630768151749635','test','test','0.29'),('2018-08-26 15:59:59','2018-09-10 19:59:59','ADAETH','4h','0.000337260000000','0.000373110000000','1.335702247020630','1.477684473064897','3960.4526093240524','3960.452609324052446','test','test','0.0'),('2018-09-11 23:59:59','2018-09-12 03:59:59','ADAETH','4h','0.000378060000000','0.000374279400000','1.367253852808245','1.353581314280162','3616.49963711645','3616.499637116449776','test','test','0.99'),('2018-09-19 07:59:59','2018-09-19 11:59:59','ADAETH','4h','0.000347440000000','0.000343965600000','1.364215510913115','1.350573355803984','3926.477984437932','3926.477984437931809','test','test','1.00'),('2018-09-20 15:59:59','2018-09-22 03:59:59','ADAETH','4h','0.000356530000000','0.000352964700000','1.361183920888864','1.347572081679975','3817.8664372952185','3817.866437295218475','test','test','1.00'),('2018-09-23 07:59:59','2018-09-23 15:59:59','ADAETH','4h','0.000371300000000','0.000367587000000','1.358159067731333','1.344577477054020','3657.848283682556','3657.848283682556030','test','test','1.00'),('2018-09-25 23:59:59','2018-09-29 11:59:59','ADAETH','4h','0.000369510000000','0.000367380000000','1.355140936469708','1.347329374686047','3667.3998984322693','3667.399898432269310','test','test','0.73'),('2018-10-01 11:59:59','2018-10-01 15:59:59','ADAETH','4h','0.000369330000000','0.000365636700000','1.353405033851116','1.339870983512605','3664.4871357623706','3664.487135762370599','test','test','1.00'),('2018-10-02 19:59:59','2018-10-02 23:59:59','ADAETH','4h','0.000367840000000','0.000364470000000','1.350397467109225','1.338025676482436','3671.1544886614433','3671.154488661443338','test','test','0.91'),('2018-10-04 03:59:59','2018-10-04 11:59:59','ADAETH','4h','0.000366800000000','0.000364850000000','1.347648180303272','1.340483747501769','3674.0681033349833','3674.068103334983334','test','test','0.53'),('2018-10-04 15:59:59','2018-10-04 19:59:59','ADAETH','4h','0.000367450000000','0.000367470000000','1.346056084125160','1.346129348846027','3663.236043339666','3663.236043339666139','test','test','0.0'),('2018-10-07 15:59:59','2018-10-11 07:59:59','ADAETH','4h','0.000373670000000','0.000376290000000','1.346072365174242','1.355510397654121','3602.3024732363897','3602.302473236389687','test','test','0.79'),('2018-10-12 03:59:59','2018-10-12 23:59:59','ADAETH','4h','0.000372040000000','0.000372630000000','1.348169705725326','1.350307701979433','3623.722464588017','3623.722464588016919','test','test','0.0'),('2018-10-17 15:59:59','2018-10-18 19:59:59','ADAETH','4h','0.000372330000000','0.000370990000000','1.348644816004017','1.343791100070718','3622.1760696264514','3622.176069626451408','test','test','0.35'),('2018-10-18 23:59:59','2018-10-19 11:59:59','ADAETH','4h','0.000371990000000','0.000369790000000','1.347566212463283','1.339596520623666','3622.5871998260254','3622.587199826025426','test','test','0.59'),('2018-10-19 19:59:59','2018-10-21 23:59:59','ADAETH','4h','0.000375730000000','0.000372580000000','1.345795169832257','1.334512454092307','3581.8145206192144','3581.814520619214363','test','test','0.83'),('2018-10-22 07:59:59','2018-10-22 11:59:59','ADAETH','4h','0.000372190000000','0.000371840000000','1.343287899667824','1.342024698708949','3609.1455967861143','3609.145596786114311','test','test','0.09'),('2018-10-22 15:59:59','2018-10-23 11:59:59','ADAETH','4h','0.000372800000000','0.000369072000000','1.343007188343630','1.329577116460194','3602.4870931964315','3602.487093196431488','test','test','0.99'),('2018-11-02 23:59:59','2018-11-03 03:59:59','ADAETH','4h','0.000362130000000','0.000360790000000','1.340022727925088','1.335064203485192','3700.3913730568806','3700.391373056880639','test','test','0.37'),('2018-11-04 07:59:59','2018-11-04 19:59:59','ADAETH','4h','0.000368580000000','0.000364894200000','1.338920833605111','1.325531625269060','3632.646463739517','3632.646463739517003','test','test','1.00'),('2018-11-06 07:59:59','2018-11-06 11:59:59','ADAETH','4h','0.000372540000000','0.000368814600000','1.335945453974878','1.322585999435129','3586.045670196161','3586.045670196161154','test','test','1.00'),('2018-11-08 15:59:59','2018-11-08 19:59:59','ADAETH','4h','0.000365610000000','0.000361953900000','1.332976686299378','1.319646919436384','3645.8977771378736','3645.897777137873618','test','test','1.00'),('2018-11-11 19:59:59','2018-11-12 03:59:59','ADAETH','4h','0.000362950000000','0.000361450000000','1.330014515885379','1.324517831014658','3664.4565804804497','3664.456580480449702','test','test','0.41'),('2018-11-12 15:59:59','2018-11-12 19:59:59','ADAETH','4h','0.000362910000000','0.000362500000000','1.328793030358552','1.327291817544226','3661.4946690875217','3661.494669087521743','test','test','0.11'),('2018-11-23 15:59:59','2018-11-23 23:59:59','ADAETH','4h','0.000352820000000','0.000350960000000','1.328459427510924','1.321456041832192','3765.2611175979946','3765.261117597994598','test','test','0.58'),('2018-11-28 19:59:59','2018-11-28 23:59:59','ADAETH','4h','0.000343520000000','0.000343330000000','1.326903119582317','1.326169212989628','3862.6662773122885','3862.666277312288457','test','test','0.05'),('2018-11-29 03:59:59','2018-11-30 11:59:59','ADAETH','4h','0.000342640000000','0.000339213600000','1.326740029228387','1.313472628936103','3872.110755394544','3872.110755394543958','test','test','0.99'),('2018-12-04 07:59:59','2018-12-04 15:59:59','ADAETH','4h','0.000352940000000','0.000349410600000','1.323791718052323','1.310553800871800','3750.7557036672615','3750.755703667261514','test','test','1.00'),('2018-12-12 11:59:59','2018-12-12 15:59:59','ADAETH','4h','0.000338800000000','0.000337900000000','1.320849958678874','1.317341207312844','3898.6126289222957','3898.612628922295698','test','test','0.26'),('2018-12-12 23:59:59','2018-12-13 03:59:59','ADAETH','4h','0.000339260000000','0.000338230000000','1.320070236153089','1.316062477079701','3891.0282265904893','3891.028226590489339','test','test','0.30'),('2018-12-15 19:59:59','2018-12-15 23:59:59','ADAETH','4h','0.000339990000000','0.000336590100000','1.319179623025670','1.305987826795413','3880.0541869633516','3880.054186963351640','test','test','0.99'),('2018-12-17 03:59:59','2018-12-17 15:59:59','ADAETH','4h','0.000342880000000','0.000350000000000','1.316248112752280','1.343580376409525','3838.801075455785','3838.801075455784940','test','test','0.74'),('2018-12-18 03:59:59','2018-12-18 11:59:59','ADAETH','4h','0.000350240000000','0.000346737600000','1.322321949120556','1.309098729629351','3775.473815442429','3775.473815442428986','test','test','0.99'),('2018-12-18 19:59:59','2018-12-18 23:59:59','ADAETH','4h','0.000346500000000','0.000343035000000','1.319383455900288','1.306189621341285','3807.744461472693','3807.744461472692819','test','test','1.00'),('2018-12-19 03:59:59','2018-12-19 23:59:59','ADAETH','4h','0.000349330000000','0.000345836700000','1.316451492664954','1.303286977738304','3768.5039723612463','3768.503972361246269','test','test','1.00'),('2018-12-20 19:59:59','2018-12-20 23:59:59','ADAETH','4h','0.000343500000000','0.000340065000000','1.313526044903476','1.300390784454441','3823.947728976642','3823.947728976641883','test','test','0.99'),('2018-12-21 03:59:59','2018-12-23 03:59:59','ADAETH','4h','0.000357610000000','0.000354033900000','1.310607098137024','1.297501027155654','3664.906177503493','3664.906177503492927','test','test','1.00'),('2019-01-06 15:59:59','2019-01-14 19:59:59','ADAETH','4h','0.000308000000000','0.000339920000000','1.307694637918942','1.443219354939633','4245.761811425136','4245.761811425136329','test','test','0.0'),('2019-01-14 23:59:59','2019-01-27 07:59:59','ADAETH','4h','0.000341380000000','0.000360010000000','1.337811241701318','1.410819102246445','3918.833094209731','3918.833094209730916','test','test','0.78'),('2019-01-27 15:59:59','2019-01-27 19:59:59','ADAETH','4h','0.000363000000000','0.000362290000000','1.354035210711346','1.351386822282682','3730.1245474141765','3730.124547414176504','test','test','0.19'),('2019-01-28 11:59:59','2019-01-28 15:59:59','ADAETH','4h','0.000364960000000','0.000365140000000','1.353446679949421','1.354114206260224','3708.479504464656','3708.479504464656202','test','test','0.0'),('2019-01-28 19:59:59','2019-01-28 23:59:59','ADAETH','4h','0.000366700000000','0.000365480000000','1.353595019129599','1.349091648735985','3691.2872078800087','3691.287207880008737','test','test','0.33'),('2019-03-03 15:59:59','2019-03-04 07:59:59','ADAETH','4h','0.000319330000000','0.000318480000000','1.352594270153240','1.348993903355162','4235.7256447976715','4235.725644797671521','test','test','0.26'),('2019-03-04 11:59:59','2019-03-04 15:59:59','ADAETH','4h','0.000320580000000','0.000318970000000','1.351794188642557','1.345005279029623','4216.7140453008815','4216.714045300881480','test','test','0.50'),('2019-03-05 11:59:59','2019-03-05 15:59:59','ADAETH','4h','0.000319660000000','0.000317350000000','1.350285542061904','1.340527800704953','4224.130457554604','4224.130457554603709','test','test','0.72'),('2019-03-08 23:59:59','2019-04-07 23:59:59','ADAETH','4h','0.000317500000000','0.000515610000000','1.348117155093693','2.189299799489320','4246.038283759663','4246.038283759662590','test','test','0.0'),('2019-04-10 23:59:59','2019-04-11 03:59:59','ADAETH','4h','0.000504110000000','0.000499068900000','1.535046631626055','1.519696165309794','3045.062846652625','3045.062846652625012','test','test','1.00'),('2019-04-11 19:59:59','2019-04-11 23:59:59','ADAETH','4h','0.000507480000000','0.000505450000000','1.531635416889108','1.525508633771970','3018.1197621366514','3018.119762136651389','test','test','0.40'),('2019-04-13 11:59:59','2019-04-14 07:59:59','ADAETH','4h','0.000510560000000','0.000505454400000','1.530273909529744','1.514971170434446','2997.2459838799437','2997.245983879943651','test','test','1.00'),('2019-04-15 19:59:59','2019-04-16 07:59:59','ADAETH','4h','0.000511810000000','0.000506691900000','1.526873300841900','1.511604567833481','2983.2814928233133','2983.281492823313329','test','test','0.99'),('2019-05-14 23:59:59','2019-05-15 02:59:59','ADAETH','4h','0.000390490000000','0.000386585100000','1.523480249062251','1.508245446571629','3901.457781408618','3901.457781408617848','test','test','0.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 18:53:10
