-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-24 15:59:59','2018-06-01 07:59:59','CMTETH','4h','0.000506980000000','0.000583450000000','1.297777777777778','1.493527248499831','2559.820461907329','2559.820461907328990','test','test','0.50'),('2018-06-04 23:59:59','2018-06-05 03:59:59','CMTETH','4h','0.000588880000000','0.000582991200000','1.341277660160456','1.327864883558852','2277.675689716846','2277.675689716846136','test','test','0.99'),('2018-07-01 03:59:59','2018-07-06 07:59:59','CMTETH','4h','0.000353660000000','0.000379090000000','1.338297043137878','1.434527586051966','3784.1346014190967','3784.134601419096725','test','test','0.85'),('2018-07-08 15:59:59','2018-07-09 03:59:59','CMTETH','4h','0.000383770000000','0.000379932300000','1.359681608229897','1.346084792147598','3542.9596066130675','3542.959606613067535','test','test','0.99'),('2018-07-17 19:59:59','2018-07-18 23:59:59','CMTETH','4h','0.000353250000000','0.000349717500000','1.356660093544942','1.343093492609493','3840.509818952419','3840.509818952419209','test','test','1.00'),('2018-08-11 03:59:59','2018-08-11 07:59:59','CMTETH','4h','0.000275970000000','0.000273210300000','1.353645293337064','1.340108840403693','4905.045089455608','4905.045089455607922','test','test','0.99'),('2018-08-13 11:59:59','2018-08-14 03:59:59','CMTETH','4h','0.000273780000000','0.000275000000000','1.350637192685204','1.356655811193042','4933.29385888379','4933.293858883789653','test','test','0.0'),('2018-08-14 15:59:59','2018-08-14 19:59:59','CMTETH','4h','0.000271590000000','0.000268874100000','1.351974663464724','1.338454916830077','4977.998687229735','4977.998687229734969','test','test','1.00'),('2018-08-17 03:59:59','2018-08-17 07:59:59','CMTETH','4h','0.000274230000000','0.000271487700000','1.348970275323691','1.335480572570454','4919.11999169927','4919.119991699270031','test','test','1.00'),('2018-08-17 11:59:59','2018-08-18 07:59:59','CMTETH','4h','0.000279970000000','0.000277170300000','1.345972563600750','1.332512837964742','4807.55996571329','4807.559965713289785','test','test','1.00'),('2018-08-21 19:59:59','2018-08-29 03:59:59','CMTETH','4h','0.000280710000000','0.000344960000000','1.342981513459414','1.650368361949911','4784.231104910457','4784.231104910457361','test','test','0.0'),('2018-09-01 07:59:59','2018-09-01 15:59:59','CMTETH','4h','0.000357780000000','0.000354202200000','1.411289702012858','1.397176804992730','3944.5740455387613','3944.574045538761311','test','test','0.99'),('2018-09-02 07:59:59','2018-09-13 15:59:59','CMTETH','4h','0.000347960000000','0.000394380000000','1.408153502675052','1.596009824074569','4046.8832701317724','4046.883270131772406','test','test','0.67'),('2018-09-17 19:59:59','2018-09-18 11:59:59','CMTETH','4h','0.000415800000000','0.000411642000000','1.449899351874945','1.435400358356196','3487.01142827067','3487.011428270669967','test','test','0.99'),('2018-09-19 03:59:59','2018-09-21 15:59:59','CMTETH','4h','0.000403800000000','0.000407400000000','1.446677353315222','1.459574922586977','3582.658131043146','3582.658131043146113','test','test','0.0'),('2018-09-25 03:59:59','2018-09-27 19:59:59','CMTETH','4h','0.000400290000000','0.000400620000000','1.449543479820057','1.450738486810840','3621.2333054037244','3621.233305403724444','test','test','0.0'),('2018-09-28 23:59:59','2018-10-12 03:59:59','CMTETH','4h','0.000419690000000','0.000534970000000','1.449809036929120','1.848041031442186','3454.476010696275','3454.476010696274898','test','test','0.0'),('2018-10-12 15:59:59','2018-10-12 23:59:59','CMTETH','4h','0.000580000000000','0.000574200000000','1.538305035709801','1.522921985352703','2652.250061568622','2652.250061568622186','test','test','1.00'),('2018-10-13 11:59:59','2018-10-13 19:59:59','CMTETH','4h','0.000599930000000','0.000593930700000','1.534886580074891','1.519537714274142','2558.442785116414','2558.442785116414143','test','test','1.00'),('2018-10-16 07:59:59','2018-10-18 07:59:59','CMTETH','4h','0.000552370000000','0.000554360000000','1.531475721008057','1.536993103713139','2772.554123156683','2772.554123156683090','test','test','0.0'),('2018-10-21 11:59:59','2018-10-21 15:59:59','CMTETH','4h','0.000564570000000','0.000558924300000','1.532701806053631','1.517374787993095','2714.812700025915','2714.812700025915092','test','test','0.99'),('2018-11-25 11:59:59','2018-11-25 15:59:59','CMTETH','4h','0.000391420000000','0.000387505800000','1.529295802040179','1.514002844019777','3907.0456339486445','3907.045633948644536','test','test','1.00'),('2018-11-29 07:59:59','2018-11-29 11:59:59','CMTETH','4h','0.000391000000000','0.000387090000000','1.525897366924534','1.510638393255289','3902.5508105486792','3902.550810548679237','test','test','0.99'),('2018-11-29 15:59:59','2018-11-30 03:59:59','CMTETH','4h','0.000390070000000','0.000386169300000','1.522506483886924','1.507281419048055','3903.162211620795','3903.162211620795006','test','test','1.00'),('2018-11-30 15:59:59','2018-11-30 19:59:59','CMTETH','4h','0.000432010000000','0.000427689900000','1.519123136144953','1.503931904783504','3516.40734275816','3516.407342758160212','test','test','1.00'),('2019-01-11 11:59:59','2019-01-11 15:59:59','CMTETH','4h','0.000183550000000','0.000181860000000','1.515747306953520','1.501791366072281','8257.953184165186','8257.953184165186030','test','test','0.92'),('2019-01-13 07:59:59','2019-01-14 15:59:59','CMTETH','4h','0.000189330000000','0.000187436700000','1.512645986757689','1.497519526890112','7989.468054495795','7989.468054495794604','test','test','1.00'),('2019-01-15 23:59:59','2019-01-27 19:59:59','CMTETH','4h','0.000187730000000','0.000227580000000','1.509284551231561','1.829664828047082','8039.655628996755','8039.655628996754785','test','test','0.67'),('2019-02-05 23:59:59','2019-02-06 03:59:59','CMTETH','4h','0.000215820000000','0.000213661800000','1.580480168301676','1.564675366618659','7323.140433239164','7323.140433239163940','test','test','1.00'),('2019-02-07 19:59:59','2019-02-07 23:59:59','CMTETH','4h','0.000216230000000','0.000215410000000','1.576967990149895','1.570987720289455','7293.012024926675','7293.012024926674712','test','test','0.37'),('2019-02-08 07:59:59','2019-02-08 11:59:59','CMTETH','4h','0.000214390000000','0.000216070000000','1.575639041292019','1.587986042501826','7349.40548202817','7349.405482028169899','test','test','0.0'),('2019-02-10 07:59:59','2019-02-10 15:59:59','CMTETH','4h','0.000220300000000','0.000218097000000','1.578382819338643','1.562598991145257','7164.697318831788','7164.697318831787925','test','test','0.99'),('2019-02-11 03:59:59','2019-02-11 11:59:59','CMTETH','4h','0.000216880000000','0.000214711200000','1.574875301962335','1.559126548942712','7261.505449844775','7261.505449844775285','test','test','1.00'),('2019-02-16 03:59:59','2019-02-16 07:59:59','CMTETH','4h','0.000213290000000','0.000211157100000','1.571375579069086','1.555661823278395','7367.319513662551','7367.319513662550889','test','test','0.99'),('2019-02-16 19:59:59','2019-02-17 11:59:59','CMTETH','4h','0.000210590000000','0.000208484100000','1.567883633337821','1.552204797004443','7445.195086840879','7445.195086840879412','test','test','1.00'),('2019-02-25 15:59:59','2019-02-25 19:59:59','CMTETH','4h','0.000193790000000','0.000191852100000','1.564399447485959','1.548755453011099','8072.653116703437','8072.653116703437263','test','test','1.00'),('2019-02-26 03:59:59','2019-03-05 15:59:59','CMTETH','4h','0.000201420000000','0.000205520000000','1.560923004269323','1.592696335207185','7749.592911673733','7749.592911673733397','test','test','0.93'),('2019-03-08 03:59:59','2019-03-16 03:59:59','CMTETH','4h','0.000212910000000','0.000237970000000','1.567983744477737','1.752539061919905','7364.537806950059','7364.537806950059348','test','test','0.42'),('2019-03-17 15:59:59','2019-03-18 15:59:59','CMTETH','4h','0.000239420000000','0.000239550000000','1.608996037242663','1.609869688085707','6720.391100336912','6720.391100336912132','test','test','0.93'),('2019-03-19 11:59:59','2019-03-21 15:59:59','CMTETH','4h','0.000242390000000','0.000241470000000','1.609190181874451','1.603082442416039','6638.847237404395','6638.847237404394946','test','test','0.37'),('2019-03-21 19:59:59','2019-03-21 23:59:59','CMTETH','4h','0.000244590000000','0.000242790000000','1.607832906439248','1.596000455269574','6573.583983152412','6573.583983152411747','test','test','0.73'),('2019-03-22 03:59:59','2019-03-22 07:59:59','CMTETH','4h','0.000243920000000','0.000242340000000','1.605203472845987','1.594805713387571','6580.860416718544','6580.860416718544002','test','test','0.64'),('2019-03-23 07:59:59','2019-03-24 07:59:59','CMTETH','4h','0.000247080000000','0.000244609200000','1.602892859633006','1.586863931036676','6487.343611919242','6487.343611919241994','test','test','1.00'),('2019-03-25 03:59:59','2019-03-25 07:59:59','CMTETH','4h','0.000244010000000','0.000241569900000','1.599330875500488','1.583337566745483','6554.3661140956865','6554.366114095686498','test','test','0.99'),('2019-03-27 15:59:59','2019-03-27 19:59:59','CMTETH','4h','0.000243660000000','0.000241223400000','1.595776806888265','1.579819038819382','6549.194807880921','6549.194807880920962','test','test','0.99'),('2019-03-28 07:59:59','2019-03-29 15:59:59','CMTETH','4h','0.000242980000000','0.000241030000000','1.592230636206291','1.579452425075324','6552.928785111083','6552.928785111083016','test','test','0.80'),('2019-03-30 15:59:59','2019-04-03 03:59:59','CMTETH','4h','0.000252750000000','0.000250222500000','1.589391033732743','1.573497123395416','6288.391824857538','6288.391824857538268','test','test','1.00'),('2019-04-03 07:59:59','2019-04-07 23:59:59','CMTETH','4h','0.000261660000000','0.000275150000000','1.585859053657781','1.667618736581588','6060.7622626988505','6060.762262698850463','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 18:56:43
