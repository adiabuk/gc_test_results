-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-30 19:59:59','2018-04-30 23:59:59','BATBTC','4h','0.000054290000000','0.000053747100000','0.033333333333333','0.033000000000000','613.986615091791','613.986615091791009','test','test','0.99'),('2018-05-01 15:59:59','2018-05-01 19:59:59','BATBTC','4h','0.000054840000000','0.000054291600000','0.033259259259259','0.032926666666666','606.4781046546195','606.478104654619528','test','test','1.00'),('2018-05-14 15:59:59','2018-05-15 07:59:59','BATBTC','4h','0.000047090000000','0.000046619100000','0.033185349794239','0.032853496296297','704.7218049318045','704.721804931804513','test','test','1.00'),('2018-05-16 07:59:59','2018-05-17 19:59:59','BATBTC','4h','0.000045470000000','0.000045015300000','0.033111604572474','0.032780488526749','728.2077099730323','728.207709973032252','test','test','1.00'),('2018-06-03 11:59:59','2018-06-03 19:59:59','BATBTC','4h','0.000040250000000','0.000039847500000','0.033038023228979','0.032707642996689','820.8204528938963','820.820452893896345','test','test','1.00'),('2018-06-15 11:59:59','2018-06-20 03:59:59','BATBTC','4h','0.000035160000000','0.000037380000000','0.032964605399582','0.035045988334368','937.5598805341737','937.559880534173658','test','test','0.0'),('2018-06-20 15:59:59','2018-06-25 15:59:59','BATBTC','4h','0.000037900000000','0.000041520000000','0.033427134940645','0.036619911417825','881.9824522597654','881.982452259765410','test','test','0.0'),('2018-07-01 15:59:59','2018-07-03 23:59:59','BATBTC','4h','0.000039670000000','0.000039273300000','0.034136640824463','0.033795274416218','860.5152716022911','860.515271602291136','test','test','1.00'),('2018-07-04 15:59:59','2018-07-04 19:59:59','BATBTC','4h','0.000039790000000','0.000039392100000','0.034060781622631','0.033720173806405','856.0136120289186','856.013612028918601','test','test','0.99'),('2018-07-06 23:59:59','2018-07-07 03:59:59','BATBTC','4h','0.000040460000000','0.000040055400000','0.033985090996803','0.033645240086835','839.967646979799','839.967646979799042','test','test','0.99'),('2018-07-08 15:59:59','2018-07-09 03:59:59','BATBTC','4h','0.000041430000000','0.000041015700000','0.033909568572365','0.033570472886641','818.4786042086731','818.478604208673119','test','test','1.00'),('2018-07-09 15:59:59','2018-07-09 19:59:59','BATBTC','4h','0.000041970000000','0.000041550300000','0.033834213975538','0.033495871835783','806.1523463316125','806.152346331612534','test','test','0.99'),('2018-07-11 03:59:59','2018-07-19 03:59:59','BATBTC','4h','0.000040170000000','0.000047730000000','0.033759026833370','0.040112480725834','840.403954029624','840.403954029623947','test','test','0.0'),('2018-07-23 11:59:59','2018-07-23 15:59:59','BATBTC','4h','0.000050000000000','0.000049500000000','0.035170905476140','0.034819196421379','703.4181095227955','703.418109522795476','test','test','0.99'),('2018-07-24 03:59:59','2018-07-24 07:59:59','BATBTC','4h','0.000047170000000','0.000046698300000','0.035092747908415','0.034741820429331','743.9632798052812','743.963279805281218','test','test','0.99'),('2018-08-06 19:59:59','2018-08-06 23:59:59','BATBTC','4h','0.000037990000000','0.000038840000000','0.035014764024174','0.035798195175018','921.6837068748148','921.683706874814789','test','test','0.0'),('2018-08-07 03:59:59','2018-08-08 03:59:59','BATBTC','4h','0.000039720000000','0.000039322800000','0.035188859835473','0.034836971237118','885.9229565829025','885.922956582902543','test','test','1.00'),('2018-08-17 19:59:59','2018-08-18 03:59:59','BATBTC','4h','0.000033910000000','0.000033570900000','0.035110662369172','0.034759555745480','1035.407324363662','1035.407324363661928','test','test','0.99'),('2018-08-19 11:59:59','2018-08-19 15:59:59','BATBTC','4h','0.000034970000000','0.000034620300000','0.035032638675018','0.034682312288268','1001.7912117534457','1001.791211753445737','test','test','1.00'),('2018-08-27 19:59:59','2018-08-27 23:59:59','BATBTC','4h','0.000032700000000','0.000032373000000','0.034954788366851','0.034605240483182','1068.9537726865851','1068.953772686585125','test','test','0.99'),('2018-08-28 03:59:59','2018-08-28 19:59:59','BATBTC','4h','0.000032820000000','0.000032491800000','0.034877111059369','0.034528339948775','1062.678581943002','1062.678581943001973','test','test','1.00'),('2018-08-28 23:59:59','2018-08-29 03:59:59','BATBTC','4h','0.000032800000000','0.000032472000000','0.034799606368126','0.034451610304445','1060.963608784336','1060.963608784335975','test','test','1.00'),('2018-09-01 19:59:59','2018-09-01 23:59:59','BATBTC','4h','0.000032440000000','0.000032115600000','0.034722273909530','0.034375051170435','1070.3536963480408','1070.353696348040785','test','test','0.99'),('2018-09-03 03:59:59','2018-09-03 07:59:59','BATBTC','4h','0.000031940000000','0.000031620600000','0.034645113300843','0.034298662167835','1084.693591134711','1084.693591134710914','test','test','1.00'),('2018-09-05 07:59:59','2018-09-05 11:59:59','BATBTC','4h','0.000032520000000','0.000032194800000','0.034568124160174','0.034222442918572','1062.9804477298346','1062.980447729834623','test','test','1.00'),('2018-09-20 23:59:59','2018-09-21 03:59:59','BATBTC','4h','0.000025060000000','0.000024990000000','0.034491306106485','0.034394961676020','1376.3490066434513','1376.349006643451276','test','test','0.27'),('2018-09-21 11:59:59','2018-09-21 15:59:59','BATBTC','4h','0.000026440000000','0.000026175600000','0.034469896233048','0.034125197270718','1303.7025806750464','1303.702580675046420','test','test','1.00'),('2018-09-21 19:59:59','2018-09-22 03:59:59','BATBTC','4h','0.000026120000000','0.000025858800000','0.034393296463642','0.034049363499006','1316.7418247948526','1316.741824794852619','test','test','1.00'),('2018-09-22 07:59:59','2018-09-24 07:59:59','BATBTC','4h','0.000026000000000','0.000025740000000','0.034316866915945','0.033973698246786','1319.8794967671026','1319.879496767102637','test','test','1.00'),('2018-09-24 19:59:59','2018-09-24 23:59:59','BATBTC','4h','0.000025410000000','0.000025155900000','0.034240607211687','0.033898201139570','1347.524880428458','1347.524880428457891','test','test','1.00'),('2018-09-25 23:59:59','2018-09-26 03:59:59','BATBTC','4h','0.000025750000000','0.000025492500000','0.034164516973439','0.033822871803705','1326.7773581918013','1326.777358191801341','test','test','0.99'),('2018-09-26 15:59:59','2018-09-26 23:59:59','BATBTC','4h','0.000025640000000','0.000025383600000','0.034088595824609','0.033747709866363','1329.5084174964554','1329.508417496455422','test','test','0.99'),('2018-09-27 15:59:59','2018-09-28 11:59:59','BATBTC','4h','0.000025510000000','0.000025260000000','0.034012843389443','0.033679514857598','1333.3141273791978','1333.314127379197771','test','test','0.98'),('2018-09-28 23:59:59','2018-09-29 03:59:59','BATBTC','4h','0.000025490000000','0.000025235100000','0.033938770382367','0.033599382678543','1331.454310802929','1331.454310802929058','test','test','0.99'),('2018-09-29 11:59:59','2018-10-03 03:59:59','BATBTC','4h','0.000025400000000','0.000025560000000','0.033863350892628','0.034076663339196','1333.2027910483466','1333.202791048346626','test','test','0.0'),('2018-10-04 11:59:59','2018-10-06 19:59:59','BATBTC','4h','0.000026180000000','0.000026090000000','0.033910753658532','0.033794177347254','1295.2923475375096','1295.292347537509613','test','test','0.38'),('2018-10-07 19:59:59','2018-10-10 07:59:59','BATBTC','4h','0.000026660000000','0.000026630000000','0.033884847811581','0.033846717825296','1270.999542820005','1270.999542820004990','test','test','0.15'),('2018-10-10 11:59:59','2018-10-11 03:59:59','BATBTC','4h','0.000026920000000','0.000026650800000','0.033876374481296','0.033537610736483','1258.4091560659651','1258.409156065965135','test','test','1.00'),('2018-10-12 03:59:59','2018-10-15 03:59:59','BATBTC','4h','0.000027190000000','0.000027570000000','0.033801093649115','0.034273488484961','1243.1443048589597','1243.144304858959686','test','test','0.0'),('2018-10-15 15:59:59','2018-10-15 19:59:59','BATBTC','4h','0.000027350000000','0.000027150000000','0.033906070279303','0.033658128266292','1239.7100650567866','1239.710065056786561','test','test','0.73'),('2018-10-16 23:59:59','2018-10-27 23:59:59','BATBTC','4h','0.000028570000000','0.000037700000000','0.033850972054190','0.044668591055056','1184.8432640598376','1184.843264059837566','test','test','0.0'),('2018-10-28 23:59:59','2018-10-29 03:59:59','BATBTC','4h','0.000038760000000','0.000038372400000','0.036254887387715','0.035892338513838','935.3686116541622','935.368611654162237','test','test','1.00'),('2018-10-30 07:59:59','2018-10-30 15:59:59','BATBTC','4h','0.000039140000000','0.000038748600000','0.036174320971298','0.035812577761585','924.2289466351104','924.228946635110447','test','test','0.99'),('2018-10-30 23:59:59','2018-10-31 15:59:59','BATBTC','4h','0.000039390000000','0.000038996100000','0.036093933591362','0.035732994255448','916.3222541599899','916.322254159989939','test','test','1.00'),('2018-11-01 15:59:59','2018-11-09 07:59:59','BATBTC','4h','0.000039530000000','0.000045540000000','0.036013724850048','0.041489122936281','911.0479344813502','911.047934481350239','test','test','0.0'),('2018-11-22 03:59:59','2018-11-22 11:59:59','BATBTC','4h','0.000039440000000','0.000040090000000','0.037230479980322','0.037844065476955','943.977687127834','943.977687127833974','test','test','0.0'),('2018-11-28 03:59:59','2018-11-28 07:59:59','BATBTC','4h','0.000038660000000','0.000038273400000','0.037366832312907','0.036993163989778','966.5502408925735','966.550240892573470','test','test','1.00'),('2018-11-28 15:59:59','2018-11-28 23:59:59','BATBTC','4h','0.000038270000000','0.000039990000000','0.037283794907767','0.038959471083397','974.2303346685944','974.230334668594423','test','test','0.0'),('2018-11-29 15:59:59','2018-11-29 23:59:59','BATBTC','4h','0.000040020000000','0.000039619800000','0.037656167391240','0.037279605717328','940.9337179220499','940.933717922049937','test','test','1.00'),('2018-11-30 15:59:59','2018-12-01 15:59:59','BATBTC','4h','0.000041300000000','0.000040887000000','0.037572487019260','0.037196762149067','909.7454484082322','909.745448408232164','test','test','0.99'),('2018-12-02 23:59:59','2018-12-03 03:59:59','BATBTC','4h','0.000044110000000','0.000043668900000','0.037488992603662','0.037114102677625','849.8978146375323','849.897814637532292','test','test','0.99'),('2018-12-11 03:59:59','2018-12-11 11:59:59','BATBTC','4h','0.000040180000000','0.000039920000000','0.037405683731209','0.037163636001739','930.9528056547757','930.952805654775716','test','test','0.64'),('2018-12-12 03:59:59','2018-12-12 23:59:59','BATBTC','4h','0.000040980000000','0.000040570200000','0.037351895346882','0.036978376393413','911.4664555120113','911.466455512011294','test','test','0.99'),('2018-12-14 19:59:59','2018-12-15 07:59:59','BATBTC','4h','0.000040430000000','0.000040025700000','0.037268891135000','0.036896202223650','921.8127908731196','921.812790873119638','test','test','0.99'),('2019-01-04 11:59:59','2019-01-05 03:59:59','BATBTC','4h','0.000035840000000','0.000035820000000','0.037186071376922','0.037165320221020','1037.5577951150235','1037.557795115023509','test','test','0.05'),('2019-01-05 19:59:59','2019-01-05 23:59:59','BATBTC','4h','0.000036380000000','0.000036016200000','0.037181460008944','0.036809645408855','1022.0302366394783','1022.030236639478289','test','test','0.99'),('2019-01-09 11:59:59','2019-01-09 15:59:59','BATBTC','4h','0.000035690000000','0.000035333100000','0.037098834542258','0.036727846196835','1039.474209645777','1039.474209645776909','test','test','1.00'),('2019-01-11 23:59:59','2019-01-12 03:59:59','BATBTC','4h','0.000035280000000','0.000034927200000','0.037016392687719','0.036646228760842','1049.2174798106385','1049.217479810638451','test','test','1.00'),('2019-01-12 11:59:59','2019-01-13 03:59:59','BATBTC','4h','0.000035370000000','0.000035080000000','0.036934134037302','0.036631309641746','1044.2220536415668','1044.222053641566845','test','test','0.81'),('2019-01-18 03:59:59','2019-01-18 15:59:59','BATBTC','4h','0.000035280000000','0.000034927200000','0.036866839727179','0.036498171329907','1044.9784503168557','1044.978450316855742','test','test','1.00'),('2019-01-25 03:59:59','2019-01-25 07:59:59','BATBTC','4h','0.000034710000000','0.000034590000000','0.036784913416674','0.036657739990860','1059.778548449259','1059.778548449259006','test','test','0.34'),('2019-01-25 11:59:59','2019-01-27 15:59:59','BATBTC','4h','0.000034790000000','0.000034690000000','0.036756652655382','0.036650999730244','1056.5292513763086','1056.529251376308594','test','test','0.28'),('2019-02-06 23:59:59','2019-02-07 03:59:59','BATBTC','4h','0.000034240000000','0.000033897600000','0.036733174227573','0.036365842485297','1072.8146678613707','1072.814667861370708','test','test','0.99'),('2019-02-07 07:59:59','2019-02-08 03:59:59','BATBTC','4h','0.000034090000000','0.000033749100000','0.036651544951512','0.036285029501997','1075.1406556618363','1075.140655661836263','test','test','1.00'),('2019-02-10 11:59:59','2019-02-10 15:59:59','BATBTC','4h','0.000034590000000','0.000034244100000','0.036570097073842','0.036204396103104','1057.244783863602','1057.244783863601924','test','test','0.99'),('2019-02-14 03:59:59','2019-02-14 07:59:59','BATBTC','4h','0.000034840000000','0.000034491600000','0.036488830191456','0.036123941889541','1047.3257804665836','1047.325780466583637','test','test','0.99'),('2019-02-14 11:59:59','2019-02-14 23:59:59','BATBTC','4h','0.000035360000000','0.000035006400000','0.036407743902141','0.036043666463120','1029.630766463273','1029.630766463272948','test','test','1.00'),('2019-02-15 03:59:59','2019-02-15 15:59:59','BATBTC','4h','0.000035530000000','0.000035174700000','0.036326837804581','0.035963569426535','1022.427182791475','1022.427182791475047','test','test','0.99'),('2019-02-17 19:59:59','2019-02-17 23:59:59','BATBTC','4h','0.000038530000000','0.000038144700000','0.036246111498349','0.035883650383366','940.7244095081409','940.724409508140866','test','test','0.99'),('2019-02-18 03:59:59','2019-02-18 11:59:59','BATBTC','4h','0.000038650000000','0.000038263500000','0.036165564583908','0.035803908938069','935.7196528824837','935.719652882483729','test','test','1.00'),('2019-02-25 23:59:59','2019-02-26 03:59:59','BATBTC','4h','0.000039000000000','0.000038610000000','0.036085196662610','0.035724344695984','925.2614528874471','925.261452887447149','test','test','1.00'),('2019-02-26 07:59:59','2019-02-26 11:59:59','BATBTC','4h','0.000047510000000','0.000047034900000','0.036005007336694','0.035644957263327','757.8406090653242','757.840609065324202','test','test','0.99'),('2019-02-26 23:59:59','2019-02-27 03:59:59','BATBTC','4h','0.000042660000000','0.000042233400000','0.035924996209279','0.035565746247186','842.1236804800438','842.123680480043845','test','test','1.00'),('2019-03-02 07:59:59','2019-03-03 03:59:59','BATBTC','4h','0.000047080000000','0.000046609200000','0.035845162884369','0.035486711255525','761.3670960995986','761.367096099598598','test','test','1.00'),('2019-03-04 07:59:59','2019-03-17 07:59:59','BATBTC','4h','0.000043890000000','0.000048350000000','0.035765506966848','0.039399914829052','814.8896552027392','814.889655202739164','test','test','0.27'),('2019-03-18 11:59:59','2019-03-18 15:59:59','BATBTC','4h','0.000048730000000','0.000048560000000','0.036573153158449','0.036445563664566','750.5264346080261','750.526434608026079','test','test','0.34'),('2019-03-21 07:59:59','2019-03-21 15:59:59','BATBTC','4h','0.000048510000000','0.000048024900000','0.036544799937586','0.036179351938210','753.3457006305139','753.345700630513875','test','test','0.99'),('2019-03-21 19:59:59','2019-03-22 03:59:59','BATBTC','4h','0.000048720000000','0.000048520000000','0.036463589271058','0.036313902944001','748.4316352844461','748.431635284446088','test','test','0.41'),('2019-03-22 07:59:59','2019-04-02 07:59:59','BATBTC','4h','0.000048740000000','0.000066050000000','0.036430325642823','0.049368547573009','747.4420525815211','747.442052581521125','test','test','0.0'),('2019-04-02 23:59:59','2019-04-03 03:59:59','BATBTC','4h','0.000065660000000','0.000065003400000','0.039305486071754','0.038912431211036','598.621475354151','598.621475354151016','test','test','1.00'),('2019-04-05 19:59:59','2019-04-05 23:59:59','BATBTC','4h','0.000062730000000','0.000062102700000','0.039218140547150','0.038825959141678','625.1895512059549','625.189551205954899','test','test','0.99'),('2019-04-13 07:59:59','2019-04-15 19:59:59','BATBTC','4h','0.000058460000000','0.000058220000000','0.039130989123711','0.038970341888171','669.3634814182575','669.363481418257493','test','test','0.41'),('2019-04-16 11:59:59','2019-04-26 03:59:59','BATBTC','4h','0.000061730000000','0.000072750000000','0.039095289738036','0.046074555782312','633.3272272482712','633.327227248271242','test','test','0.51'),('2019-04-28 03:59:59','2019-04-28 11:59:59','BATBTC','4h','0.000077790000000','0.000077012100000','0.040646237747875','0.040239775370396','522.5123762421248','522.512376242124787','test','test','1.00'),('2019-04-28 19:59:59','2019-04-28 23:59:59','BATBTC','4h','0.000078000000000','0.000077220000000','0.040555912775102','0.040150353647351','519.9475996807921','519.947599680792109','test','test','1.00'),('2019-04-30 15:59:59','2019-04-30 19:59:59','BATBTC','4h','0.000073140000000','0.000073640000000','0.040465788524490','0.040742420931685','553.2648143900799','553.264814390079891','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 18:53:25
