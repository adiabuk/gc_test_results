-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-29 19:59:59','2018-05-01 07:59:59','ENJETH','4h','0.000233300000000','0.000230967000000','1.297777777777778','1.284800000000000','5562.699433252369','5562.699433252369090','test','test','1.00'),('2018-05-03 11:59:59','2018-05-03 15:59:59','ENJETH','4h','0.000237740000000','0.000235362600000','1.294893827160494','1.281944888888889','5446.68052141202','5446.680521412020425','test','test','0.99'),('2018-05-21 11:59:59','2018-05-22 11:59:59','ENJETH','4h','0.000203610000000','0.000203190000000','1.292016285322359','1.289351156694907','6345.544351074894','6345.544351074893711','test','test','0.79'),('2018-05-22 15:59:59','2018-05-23 03:59:59','ENJETH','4h','0.000203990000000','0.000203550000000','1.291424034516259','1.288638473580982','6330.820307447712','6330.820307447712366','test','test','0.38'),('2018-05-23 07:59:59','2018-05-23 11:59:59','ENJETH','4h','0.000203760000000','0.000201950000000','1.290805020975086','1.279338800480559','6334.928450015146','6334.928450015146154','test','test','0.88'),('2018-05-23 15:59:59','2018-05-23 19:59:59','ENJETH','4h','0.000202810000000','0.000200781900000','1.288256971976302','1.275374402256539','6352.038715922797','6352.038715922796655','test','test','1.00'),('2018-05-24 03:59:59','2018-05-24 07:59:59','ENJETH','4h','0.000204440000000','0.000202395600000','1.285394178705244','1.272540236918192','6287.390817380376','6287.390817380375665','test','test','1.00'),('2018-06-07 15:59:59','2018-06-07 19:59:59','ENJETH','4h','0.000182530000000','0.000180704700000','1.282537747197010','1.269712369725040','7026.449061507754','7026.449061507753868','test','test','0.99'),('2018-06-07 23:59:59','2018-06-08 07:59:59','ENJETH','4h','0.000187750000000','0.000185872500000','1.279687663314350','1.266890786681206','6815.9129870271645','6815.912987027164490','test','test','0.99'),('2018-07-02 15:59:59','2018-07-03 03:59:59','ENJETH','4h','0.000133350000000','0.000132016500000','1.276843912951429','1.264075473821915','9575.132455578772','9575.132455578772351','test','test','0.99'),('2018-07-03 11:59:59','2018-07-03 23:59:59','ENJETH','4h','0.000130580000000','0.000130440000000','1.274006482033759','1.272640569126080','9756.52076913585','9756.520769135850060','test','test','0.10'),('2018-07-04 15:59:59','2018-07-04 23:59:59','ENJETH','4h','0.000138870000000','0.000137481300000','1.273702945832053','1.260965916373733','9171.908589558961','9171.908589558961467','test','test','1.00'),('2018-07-05 03:59:59','2018-07-05 07:59:59','ENJETH','4h','0.000141870000000','0.000140451300000','1.270872494841315','1.258163769892902','8958.00729429277','8958.007294292770894','test','test','1.00'),('2018-07-06 19:59:59','2018-07-06 23:59:59','ENJETH','4h','0.000132460000000','0.000131135400000','1.268048333741668','1.255367850404251','9573.06608592532','9573.066085925320294','test','test','0.99'),('2018-07-07 11:59:59','2018-07-07 15:59:59','ENJETH','4h','0.000137000000000','0.000135630000000','1.265230448555575','1.252578144070019','9235.258748580842','9235.258748580841711','test','test','0.99'),('2018-07-07 23:59:59','2018-07-08 03:59:59','ENJETH','4h','0.000135080000000','0.000137240000000','1.262418825336563','1.282605564030130','9345.712358132683','9345.712358132683221','test','test','0.0'),('2018-07-08 15:59:59','2018-07-08 19:59:59','ENJETH','4h','0.000132780000000','0.000132850000000','1.266904767268467','1.267572664042897','9541.382491854696','9541.382491854696127','test','test','0.0'),('2018-07-09 11:59:59','2018-07-12 07:59:59','ENJETH','4h','0.000133810000000','0.000133540000000','1.267053188773896','1.264496546064316','9469.04707251996','9469.047072519959329','test','test','0.20'),('2018-07-12 15:59:59','2018-07-12 19:59:59','ENJETH','4h','0.000137320000000','0.000136870000000','1.266485045949544','1.262334752687985','9222.873914575768','9222.873914575768140','test','test','0.32'),('2018-07-13 11:59:59','2018-07-13 15:59:59','ENJETH','4h','0.000136480000000','0.000136110000000','1.265562758558087','1.262131792697401','9272.880704558082','9272.880704558081561','test','test','0.27'),('2018-07-18 19:59:59','2018-07-18 23:59:59','ENJETH','4h','0.000135800000000','0.000134442000000','1.264800321700157','1.252152318483156','9313.698981591728','9313.698981591727716','test','test','0.99'),('2018-07-24 11:59:59','2018-07-24 15:59:59','ENJETH','4h','0.000131870000000','0.000130551300000','1.261989654318601','1.249369757775415','9569.952637587023','9569.952637587022764','test','test','1.00'),('2018-07-24 23:59:59','2018-07-25 03:59:59','ENJETH','4h','0.000141690000000','0.000140273100000','1.259185232864559','1.246593380535913','8886.902624494032','8886.902624494032352','test','test','0.99'),('2018-07-28 11:59:59','2018-07-29 03:59:59','ENJETH','4h','0.000134610000000','0.000133263900000','1.256387043458194','1.243823173023612','9333.534235630294','9333.534235630293551','test','test','1.00'),('2018-07-29 15:59:59','2018-07-30 19:59:59','ENJETH','4h','0.000134810000000','0.000133461900000','1.253595072250509','1.241059121528004','9298.976873010228','9298.976873010227791','test','test','1.00'),('2018-07-30 23:59:59','2018-07-31 19:59:59','ENJETH','4h','0.000132990000000','0.000131660100000','1.250809305423285','1.238301212369052','9405.28840832608','9405.288408326079661','test','test','1.00'),('2018-08-07 11:59:59','2018-08-07 19:59:59','ENJETH','4h','0.000126860000000','0.000125591400000','1.248029729189011','1.235549431897121','9837.85061634094','9837.850616340940178','test','test','1.00'),('2018-08-07 23:59:59','2018-08-08 03:59:59','ENJETH','4h','0.000127180000000','0.000125908200000','1.245256329790813','1.232803766492905','9791.290531457882','9791.290531457882025','test','test','1.00'),('2018-08-13 03:59:59','2018-08-14 03:59:59','ENJETH','4h','0.000127730000000','0.000126452700000','1.242489093502390','1.230064202567366','9727.464914291002','9727.464914291002060','test','test','0.99'),('2018-08-14 11:59:59','2018-08-14 15:59:59','ENJETH','4h','0.000129760000000','0.000128462400000','1.239728006627940','1.227330726561660','9554.007449352186','9554.007449352186086','test','test','0.99'),('2018-08-15 03:59:59','2018-08-15 23:59:59','ENJETH','4h','0.000131850000000','0.000130531500000','1.236973055502100','1.224603324947079','9381.668983709516','9381.668983709516397','test','test','0.99'),('2018-08-16 11:59:59','2018-08-19 11:59:59','ENJETH','4h','0.000128970000000','0.000131090000000','1.234224226489873','1.254512319535996','9569.855210435551','9569.855210435551271','test','test','0.0'),('2018-08-19 15:59:59','2018-08-20 23:59:59','ENJETH','4h','0.000132190000000','0.000130868100000','1.238732691611234','1.226345364695122','9370.85022778753','9370.850227787530457','test','test','0.99'),('2018-08-21 11:59:59','2018-08-21 15:59:59','ENJETH','4h','0.000133280000000','0.000131947200000','1.235979952296542','1.223620152773577','9273.559065850406','9273.559065850406114','test','test','0.99'),('2018-08-22 03:59:59','2018-08-22 11:59:59','ENJETH','4h','0.000133780000000','0.000134220000000','1.233233330180328','1.237289412294839','9218.368442071516','9218.368442071516256','test','test','0.0'),('2018-08-24 19:59:59','2018-08-24 23:59:59','ENJETH','4h','0.000136120000000','0.000134758800000','1.234134681761330','1.221793334943717','9066.519848378857','9066.519848378857205','test','test','1.00'),('2018-08-26 23:59:59','2018-08-27 07:59:59','ENJETH','4h','0.000137360000000','0.000135986400000','1.231392160246305','1.219078238643842','8964.70704896844','8964.707048968439267','test','test','1.00'),('2018-08-27 11:59:59','2018-09-13 15:59:59','ENJETH','4h','0.000137930000000','0.000196310000000','1.228655733223535','1.748694315878432','8907.820874527191','8907.820874527191336','test','test','0.0'),('2018-09-13 19:59:59','2018-09-13 23:59:59','ENJETH','4h','0.000199330000000','0.000197336700000','1.344219862702402','1.330777664075378','6743.690677280899','6743.690677280898853','test','test','1.00'),('2018-09-15 03:59:59','2018-09-15 15:59:59','ENJETH','4h','0.000197070000000','0.000195099300000','1.341232707451952','1.327820380377433','6805.869525812917','6805.869525812917345','test','test','1.00'),('2018-09-17 03:59:59','2018-09-17 07:59:59','ENJETH','4h','0.000198390000000','0.000196406100000','1.338252190324281','1.324869668421038','6745.56273161087','6745.562731610870287','test','test','1.00'),('2018-09-17 19:59:59','2018-09-18 15:59:59','ENJETH','4h','0.000199030000000','0.000197039700000','1.335278296568004','1.321925513602324','6708.929792332836','6708.929792332835859','test','test','0.99'),('2018-09-20 11:59:59','2018-09-20 23:59:59','ENJETH','4h','0.000197010000000','0.000195039900000','1.332311011464520','1.318987901349875','6762.656776125678','6762.656776125678334','test','test','0.99'),('2018-09-25 11:59:59','2018-09-25 15:59:59','ENJETH','4h','0.000193470000000','0.000191535300000','1.329350320327932','1.316056817124653','6871.092780937262','6871.092780937262432','test','test','1.00'),('2018-09-25 19:59:59','2018-09-25 23:59:59','ENJETH','4h','0.000193000000000','0.000191070000000','1.326396208504981','1.313132246419931','6872.519215051717','6872.519215051716856','test','test','1.00'),('2018-09-26 03:59:59','2018-09-26 07:59:59','ENJETH','4h','0.000190010000000','0.000188620000000','1.323448661374970','1.313767099145028','6965.152683411243','6965.152683411242833','test','test','0.73'),('2018-09-27 07:59:59','2018-09-27 19:59:59','ENJETH','4h','0.000194500000000','0.000192555000000','1.321297203101650','1.308084231070634','6793.301815432646','6793.301815432646436','test','test','0.99'),('2018-09-28 03:59:59','2018-09-30 15:59:59','ENJETH','4h','0.000253010000000','0.000250479900000','1.318360987094757','1.305177377223809','5210.707035669568','5210.707035669567631','test','test','1.00'),('2018-10-03 23:59:59','2018-10-04 03:59:59','ENJETH','4h','0.000248890000000','0.000246401100000','1.315431296012325','1.302276983052201','5285.191434016331','5285.191434016331186','test','test','1.00'),('2018-10-04 11:59:59','2018-10-06 15:59:59','ENJETH','4h','0.000245450000000','0.000242995500000','1.312508115354519','1.299383034200974','5347.354309857484','5347.354309857483713','test','test','0.99'),('2018-10-10 15:59:59','2018-10-11 07:59:59','ENJETH','4h','0.000244420000000','0.000241975800000','1.309591430653731','1.296495516347194','5357.9552845664475','5357.955284566447517','test','test','1.00'),('2018-10-11 11:59:59','2018-10-11 15:59:59','ENJETH','4h','0.000243220000000','0.000242580000000','1.306681227474501','1.303242875424572','5372.425078013736','5372.425078013736311','test','test','0.26'),('2018-10-12 11:59:59','2018-10-12 15:59:59','ENJETH','4h','0.000243770000000','0.000242920000000','1.305917149241183','1.301363555374608','5357.169254794205','5357.169254794204790','test','test','0.34'),('2018-10-14 03:59:59','2018-10-15 03:59:59','ENJETH','4h','0.000245220000000','0.000242767800000','1.304905239493056','1.291856187098126','5321.365465675946','5321.365465675946325','test','test','0.99'),('2018-10-19 03:59:59','2018-10-19 05:59:59','ENJETH','4h','0.000241550000000','0.000242390000000','1.302005450071960','1.306533227252918','5390.21092971211','5390.210929712109646','test','test','0.0'),('2018-10-20 03:59:59','2018-10-20 07:59:59','ENJETH','4h','0.000239400000000','0.000238450000000','1.303011622778840','1.297840941736067','5442.82215028755','5442.822150287550357','test','test','0.39'),('2018-10-20 15:59:59','2018-10-21 03:59:59','ENJETH','4h','0.000254300000000','0.000251757000000','1.301862582547112','1.288843956721641','5119.396706830957','5119.396706830956646','test','test','0.99'),('2018-10-21 11:59:59','2018-10-21 15:59:59','ENJETH','4h','0.000255190000000','0.000252638100000','1.298969554585897','1.285979859040038','5090.205551102695','5090.205551102694699','test','test','0.99'),('2018-10-22 03:59:59','2018-10-22 07:59:59','ENJETH','4h','0.000245590000000','0.000246200000000','1.296082955575706','1.299302185197845','5277.425610064358','5277.425610064357897','test','test','0.0'),('2018-10-24 15:59:59','2018-10-26 03:59:59','ENJETH','4h','0.000251670000000','0.000249153300000','1.296798339936181','1.283830356536819','5152.7728371922785','5152.772837192278530','test','test','1.00'),('2018-10-31 19:59:59','2018-11-02 23:59:59','ENJETH','4h','0.000248850000000','0.000248100000000','1.293916565847434','1.290016877583879','5199.5843514062035','5199.584351406203496','test','test','0.30'),('2018-11-03 03:59:59','2018-11-03 11:59:59','ENJETH','4h','0.000251200000000','0.000248688000000','1.293049968455533','1.280119468770978','5147.4919126414525','5147.491912641452473','test','test','0.99'),('2018-11-09 07:59:59','2018-11-09 11:59:59','ENJETH','4h','0.000240340000000','0.000237936600000','1.290176524081187','1.277274758840375','5368.130665229204','5368.130665229204169','test','test','0.99'),('2018-11-09 15:59:59','2018-11-09 19:59:59','ENJETH','4h','0.000241910000000','0.000242750000000','1.287309465138784','1.291779474442726','5321.439647549851','5321.439647549850633','test','test','0.0'),('2018-11-10 03:59:59','2018-11-10 11:59:59','ENJETH','4h','0.000243920000000','0.000241480800000','1.288302800539660','1.275419772534263','5281.66120260602','5281.661202606020197','test','test','1.00'),('2018-11-12 07:59:59','2018-11-12 15:59:59','ENJETH','4h','0.000245910000000','0.000243450900000','1.285439905427350','1.272585506373076','5227.277887956366','5227.277887956365703','test','test','0.99'),('2018-11-12 23:59:59','2018-11-13 03:59:59','ENJETH','4h','0.000239970000000','0.000239740000000','1.282583372304178','1.281354076243712','5344.765480285777','5344.765480285776903','test','test','0.09'),('2018-11-13 15:59:59','2018-11-13 19:59:59','ENJETH','4h','0.000239800000000','0.000240530000000','1.282310195401852','1.286213808590523','5347.415326946841','5347.415326946840651','test','test','0.0'),('2018-11-28 11:59:59','2018-11-28 15:59:59','ENJETH','4h','0.000246780000000','0.000244312200000','1.283177664999335','1.270345888349342','5199.682571518498','5199.682571518497753','test','test','0.99'),('2018-11-29 11:59:59','2018-11-29 15:59:59','ENJETH','4h','0.000234460000000','0.000232115400000','1.280326159077114','1.267522897486343','5460.744515384774','5460.744515384773877','test','test','1.00'),('2018-11-29 19:59:59','2018-11-30 11:59:59','ENJETH','4h','0.000229600000000','0.000227304000000','1.277480989834720','1.264706179936373','5563.941593356796','5563.941593356796147','test','test','0.99'),('2018-12-01 19:59:59','2018-12-03 03:59:59','ENJETH','4h','0.000244110000000','0.000241668900000','1.274642143190643','1.261895721758737','5221.589214659963','5221.589214659962636','test','test','1.00'),('2018-12-03 15:59:59','2018-12-23 03:59:59','ENJETH','4h','0.000245500000000','0.000338000000000','1.271809605094664','1.751004670150698','5180.487189794966','5180.487189794966071','test','test','0.0'),('2018-12-27 07:59:59','2018-12-27 11:59:59','ENJETH','4h','0.000341280000000','0.000337867200000','1.378297397329338','1.364514423356045','4038.6116893147514','4038.611689314751402','test','test','1.00'),('2018-12-27 15:59:59','2018-12-28 11:59:59','ENJETH','4h','0.000343300000000','0.000339867000000','1.375234514224162','1.361482169081920','4005.926344958236','4005.926344958235859','test','test','1.00'),('2019-01-11 15:59:59','2019-01-11 19:59:59','ENJETH','4h','0.000271290000000','0.000273050000000','1.372178437525886','1.381080476119441','5057.9764736108455','5057.976473610845460','test','test','0.0'),('2019-01-12 07:59:59','2019-01-12 15:59:59','ENJETH','4h','0.000297960000000','0.000294980400000','1.374156668324454','1.360415101641209','4611.883032368284','4611.883032368284148','test','test','1.00'),('2019-01-13 19:59:59','2019-01-13 23:59:59','ENJETH','4h','0.000287220000000','0.000284347800000','1.371102986839288','1.357391956970895','4773.703038922388','4773.703038922388259','test','test','1.00'),('2019-01-15 23:59:59','2019-01-16 07:59:59','ENJETH','4h','0.000285580000000','0.000282724200000','1.368056091312979','1.354375530399849','4790.447830075562','4790.447830075561797','test','test','1.00'),('2019-01-17 07:59:59','2019-01-17 15:59:59','ENJETH','4h','0.000277400000000','0.000277070000000','1.365015966665617','1.363392119264753','4920.749699587659','4920.749699587659052','test','test','0.64'),('2019-01-18 19:59:59','2019-01-19 11:59:59','ENJETH','4h','0.000278140000000','0.000281100000000','1.364655111687647','1.379177938791248','4906.3605079731315','4906.360507973131462','test','test','0.52'),('2019-01-20 23:59:59','2019-01-21 07:59:59','ENJETH','4h','0.000278970000000','0.000280830000000','1.367882406599558','1.377002603309868','4903.3315646827905','4903.331564682790486','test','test','0.0'),('2019-01-21 15:59:59','2019-01-21 23:59:59','ENJETH','4h','0.000285220000000','0.000288000000000','1.369909116979627','1.383261432193158','4802.991084004023','4802.991084004022923','test','test','0.0'),('2019-01-23 03:59:59','2019-01-23 07:59:59','ENJETH','4h','0.000301900000000','0.000298881000000','1.372876298138190','1.359147535156808','4547.453786479595','4547.453786479594783','test','test','0.99'),('2019-01-24 15:59:59','2019-01-24 19:59:59','ENJETH','4h','0.000299320000000','0.000296326800000','1.369825461920105','1.356127207300904','4576.458178271097','4576.458178271096585','test','test','0.99'),('2019-01-25 03:59:59','2019-01-25 11:59:59','ENJETH','4h','0.000300470000000','0.000297465300000','1.366781405338060','1.353113591284679','4548.811546370885','4548.811546370884571','test','test','0.99'),('2019-02-11 11:59:59','2019-02-11 19:59:59','ENJETH','4h','0.000272270000000','0.000269547300000','1.363744113326198','1.350106672192936','5008.793158725521','5008.793158725520698','test','test','1.0'),('2019-02-20 07:59:59','2019-02-20 11:59:59','ENJETH','4h','0.000263680000000','0.000261043200000','1.360713570852139','1.347106435143618','5160.47319042832','5160.473190428319867','test','test','0.99'),('2019-02-20 15:59:59','2019-02-20 19:59:59','ENJETH','4h','0.000257910000000','0.000255330900000','1.357689762916912','1.344112865287743','5264.199770915872','5264.199770915872250','test','test','0.99'),('2019-02-21 03:59:59','2019-02-21 07:59:59','ENJETH','4h','0.000258680000000','0.000256093200000','1.354672674554875','1.341125947809326','5236.866686851999','5236.866686851998566','test','test','1.00'),('2019-02-22 03:59:59','2019-02-23 19:59:59','ENJETH','4h','0.000262400000000','0.000259776000000','1.351662290833642','1.338145667925306','5151.152022994062','5151.152022994061554','test','test','1.00'),('2019-02-25 03:59:59','2019-03-16 07:59:59','ENJETH','4h','0.000303950000000','0.001167460000000','1.348658596854012','5.180144647090589','4437.106750630076','4437.106750630076021','test','test','0.0'),('2019-03-17 07:59:59','2019-03-24 11:59:59','ENJETH','4h','0.001177280000000','0.001318800000000','2.200099941351028','2.464572406440045','1868.7992162875685','1868.799216287568470','test','test','0.94'),('2019-04-13 07:59:59','2019-04-13 11:59:59','ENJETH','4h','0.000951090000000','0.000941579100000','2.258871600259699','2.236282884257102','2375.0345395911','2375.034539591099929','test','test','0.99'),('2019-04-13 19:59:59','2019-04-13 23:59:59','ENJETH','4h','0.001030760000000','0.001020452400000','2.253851885592456','2.231313366736531','2186.59230625214','2186.592306252140133','test','test','0.99'),('2019-04-14 03:59:59','2019-04-14 07:59:59','ENJETH','4h','0.001057820000000','0.001047241800000','2.248843325846695','2.226354892588227','2125.9224876129165','2125.922487612916484','test','test','1.00'),('2019-04-14 11:59:59','2019-04-14 15:59:59','ENJETH','4h','0.001046750000000','0.001036282500000','2.243845896233702','2.221407437271365','2143.6311404191088','2143.631140419108760','test','test','1.00'),('2019-04-17 07:59:59','2019-04-20 11:59:59','ENJETH','4h','0.000968200000000','0.001156600000000','2.238859572019849','2.674514543480849','2312.393691406578','2312.393691406578000','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 19:43:09
