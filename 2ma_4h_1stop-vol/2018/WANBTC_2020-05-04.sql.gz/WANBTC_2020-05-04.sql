-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-16 19:59:59','2018-09-16 23:59:59','WANBTC','4h','0.000152800000000','0.000151272000000','0.033333333333333','0.033000000000000','218.1500872600349','218.150087260034894','test','test','0.99'),('2018-09-17 03:59:59','2018-09-17 11:59:59','WANBTC','4h','0.000151300000000','0.000151000000000','0.033259259259259','0.033193312281217','219.82326014051117','219.823260140511167','test','test','0.72'),('2018-09-20 15:59:59','2018-09-20 19:59:59','WANBTC','4h','0.000145900000000','0.000144441000000','0.033244604375250','0.032912158331497','227.85883739033582','227.858837390335822','test','test','1.00'),('2018-09-20 23:59:59','2018-09-21 11:59:59','WANBTC','4h','0.000150100000000','0.000149600000000','0.033170727476638','0.033060232048668','220.9908559402946','220.990855940294608','test','test','0.33'),('2018-09-21 19:59:59','2018-09-22 03:59:59','WANBTC','4h','0.000156700000000','0.000155133000000','0.033146172937089','0.032814711207718','211.52631102162945','211.526311021629454','test','test','1.00'),('2018-09-22 19:59:59','2018-09-24 11:59:59','WANBTC','4h','0.000149200000000','0.000147708000000','0.033072514775007','0.032741789627257','221.66564862605154','221.665648626051535','test','test','0.99'),('2018-09-30 23:59:59','2018-10-01 15:59:59','WANBTC','4h','0.000147000000000','0.000146700000000','0.032999020297729','0.032931675358346','224.48313127706876','224.483131277068765','test','test','0.20'),('2018-10-01 19:59:59','2018-10-03 03:59:59','WANBTC','4h','0.000151800000000','0.000150282000000','0.032984054755644','0.032654214208088','217.28626321241106','217.286263212411058','test','test','0.99'),('2018-10-04 15:59:59','2018-10-04 23:59:59','WANBTC','4h','0.000158200000000','0.000156618000000','0.032910756856187','0.032581649287625','208.03259706818656','208.032597068186561','test','test','0.99'),('2018-10-05 07:59:59','2018-10-05 11:59:59','WANBTC','4h','0.000166000000000','0.000164340000000','0.032837621840951','0.032509245622541','197.81699904187414','197.816999041874141','test','test','1.00'),('2018-10-05 15:59:59','2018-10-06 03:59:59','WANBTC','4h','0.000166800000000','0.000165132000000','0.032764649347971','0.032437002854491','196.43075148663738','196.430751486637377','test','test','0.99'),('2018-10-08 11:59:59','2018-10-08 19:59:59','WANBTC','4h','0.000166400000000','0.000164736000000','0.032691839016087','0.032364920625926','196.4653787024439','196.465378702443900','test','test','0.99'),('2018-10-09 07:59:59','2018-10-09 11:59:59','WANBTC','4h','0.000166500000000','0.000164835000000','0.032619190484940','0.032292998580091','195.91105396360226','195.911053963602257','test','test','1.00'),('2018-10-10 03:59:59','2018-10-10 07:59:59','WANBTC','4h','0.000164300000000','0.000162657000000','0.032546703394973','0.032221236361023','198.0931430004463','198.093143000446304','test','test','1.00'),('2018-10-10 15:59:59','2018-10-11 03:59:59','WANBTC','4h','0.000164400000000','0.000162756000000','0.032474377387429','0.032149633613555','197.53270916927545','197.532709169275449','test','test','0.99'),('2018-10-17 07:59:59','2018-10-17 11:59:59','WANBTC','4h','0.000155500000000','0.000154500000000','0.032402212104346','0.032193837749977','208.3743543687831','208.374354368783088','test','test','0.64'),('2018-10-17 15:59:59','2018-10-17 19:59:59','WANBTC','4h','0.000161700000000','0.000160083000000','0.032355906692264','0.032032347625341','200.0983716281','200.098371628100011','test','test','1.00'),('2018-10-24 15:59:59','2018-10-25 03:59:59','WANBTC','4h','0.000157000000000','0.000155430000000','0.032284004677392','0.031961164630618','205.63060304071334','205.630603040713339','test','test','1.00'),('2018-10-25 07:59:59','2018-10-27 15:59:59','WANBTC','4h','0.000157500000000','0.000158400000000','0.032212262444776','0.032396332515889','204.5223012366702','204.522301236670188','test','test','0.0'),('2018-10-28 23:59:59','2018-10-29 07:59:59','WANBTC','4h','0.000165400000000','0.000163746000000','0.032253166905023','0.031930635235973','195.0010090992919','195.001009099291906','test','test','0.99'),('2018-10-29 11:59:59','2018-10-29 15:59:59','WANBTC','4h','0.000165800000000','0.000165800000000','0.032181493200790','0.032181493200790','194.09827020982843','194.098270209828428','test','test','0.0'),('2018-10-30 03:59:59','2018-10-30 15:59:59','WANBTC','4h','0.000169000000000','0.000167310000000','0.032181493200790','0.031859678268782','190.42303669106244','190.423036691062435','test','test','0.99'),('2018-10-30 19:59:59','2018-11-02 03:59:59','WANBTC','4h','0.000171900000000','0.000170181000000','0.032109978771454','0.031788878983739','186.79452455761745','186.794524557617450','test','test','0.99'),('2018-12-02 03:59:59','2018-12-02 07:59:59','WANBTC','4h','0.000105900000000','0.000105000000000','0.032038623263073','0.031766340345823','302.53657472212774','302.536574722127739','test','test','0.84'),('2018-12-04 15:59:59','2018-12-04 19:59:59','WANBTC','4h','0.000105000000000','0.000103950000000','0.031978115948129','0.031658334788648','304.55348522027504','304.553485220275036','test','test','0.99'),('2018-12-19 19:59:59','2018-12-19 23:59:59','WANBTC','4h','0.000095300000000','0.000094347000000','0.031907053468244','0.031587982933562','334.8064372323633','334.806437232363294','test','test','1.00'),('2018-12-20 19:59:59','2018-12-21 03:59:59','WANBTC','4h','0.000095200000000','0.000094248000000','0.031836148904982','0.031517787415932','334.41332883383984','334.413328833839842','test','test','1.00'),('2018-12-21 11:59:59','2018-12-21 15:59:59','WANBTC','4h','0.000095100000000','0.000101000000000','0.031765401907415','0.033736126105667','334.0210505511555','334.021050551155497','test','test','0.0'),('2018-12-22 03:59:59','2018-12-25 03:59:59','WANBTC','4h','0.000100200000000','0.000099198000000','0.032203340618138','0.031881307211957','321.39062493151243','321.390624931512434','test','test','1.00'),('2019-01-05 03:59:59','2019-01-07 11:59:59','WANBTC','4h','0.000093100000000','0.000092200000000','0.032131777638986','0.031821158950747','345.131875821549','345.131875821548988','test','test','0.96'),('2019-01-16 15:59:59','2019-01-16 19:59:59','WANBTC','4h','0.000087800000000','0.000087700000000','0.032062751263822','0.032026233323886','365.17939936015927','365.179399360159266','test','test','0.11'),('2019-01-17 03:59:59','2019-01-18 11:59:59','WANBTC','4h','0.000091700000000','0.000090783000000','0.032054636166058','0.031734089804397','349.5598273288815','349.559827328881511','test','test','1.00'),('2019-01-21 23:59:59','2019-01-22 11:59:59','WANBTC','4h','0.000090700000000','0.000090800000000','0.031983403641245','0.032018666489802','352.6284855705058','352.628485570505802','test','test','0.0'),('2019-01-22 15:59:59','2019-01-23 15:59:59','WANBTC','4h','0.000091300000000','0.000090387000000','0.031991239829813','0.031671327431515','350.3969313232541','350.396931323254080','test','test','0.99'),('2019-01-26 11:59:59','2019-01-27 15:59:59','WANBTC','4h','0.000091100000000','0.000090189000000','0.031920148185747','0.031600946703890','350.3858198215903','350.385819821590303','test','test','1.00'),('2019-02-06 19:59:59','2019-02-06 23:59:59','WANBTC','4h','0.000082600000000','0.000082900000000','0.031849214523112','0.031964889636392','385.5837109335592','385.583710933559189','test','test','0.0'),('2019-02-07 07:59:59','2019-02-07 15:59:59','WANBTC','4h','0.000083000000000','0.000082170000000','0.031874920103841','0.031556170902803','384.0351819739864','384.035181973986425','test','test','1.00'),('2019-02-11 23:59:59','2019-02-12 03:59:59','WANBTC','4h','0.000080700000000','0.000079893000000','0.031804086948055','0.031486046078574','394.10268832781486','394.102688327814860','test','test','0.99'),('2019-02-12 07:59:59','2019-02-12 11:59:59','WANBTC','4h','0.000081100000000','0.000081000000000','0.031733411199281','0.031694282455509','391.2874377223317','391.287437722331674','test','test','0.12'),('2019-02-12 15:59:59','2019-02-12 23:59:59','WANBTC','4h','0.000081600000000','0.000081100000000','0.031724715922887','0.031530324281203','388.78328336871715','388.783283368717150','test','test','0.61'),('2019-02-17 23:59:59','2019-02-18 03:59:59','WANBTC','4h','0.000079900000000','0.000079600000000','0.031681517780291','0.031562563395634','396.51461552303977','396.514615523039765','test','test','0.37'),('2019-02-24 03:59:59','2019-02-24 15:59:59','WANBTC','4h','0.000079400000000','0.000078606000000','0.031655083472589','0.031338532637863','398.67863315603677','398.678633156036767','test','test','1.00'),('2019-02-26 07:59:59','2019-02-26 11:59:59','WANBTC','4h','0.000078200000000','0.000078200000000','0.031584738842650','0.031584738842650','403.89691614642214','403.896916146422143','test','test','0.0'),('2019-02-26 15:59:59','2019-03-04 07:59:59','WANBTC','4h','0.000078200000000','0.000078500000000','0.031584738842650','0.031705907917494','403.89691614642214','403.896916146422143','test','test','0.0'),('2019-03-07 19:59:59','2019-03-08 07:59:59','WANBTC','4h','0.000081400000000','0.000080586000000','0.031611665303727','0.031295548650690','388.34969660597864','388.349696605978636','test','test','0.99'),('2019-03-08 11:59:59','2019-03-17 03:59:59','WANBTC','4h','0.000082900000000','0.000101100000000','0.031541417158607','0.038466070865322','380.4754783909208','380.475478390920784','test','test','0.0'),('2019-03-19 07:59:59','2019-03-19 11:59:59','WANBTC','4h','0.000103900000000','0.000102861000000','0.033080229093433','0.032749426802499','318.38526557683235','318.385265576832353','test','test','1.00'),('2019-03-19 19:59:59','2019-03-19 23:59:59','WANBTC','4h','0.000102500000000','0.000101475000000','0.033006717473225','0.032676650298493','322.0167558363447','322.016755836344714','test','test','0.99'),('2019-03-23 07:59:59','2019-03-23 11:59:59','WANBTC','4h','0.000101900000000','0.000101100000000','0.032933369212174','0.032674814792451','323.1930246533246','323.193024653324585','test','test','0.78'),('2019-03-23 19:59:59','2019-03-24 11:59:59','WANBTC','4h','0.000104500000000','0.000103455000000','0.032875912674458','0.032547153547713','314.60203516227324','314.602035162273239','test','test','1.00'),('2019-03-27 03:59:59','2019-03-27 07:59:59','WANBTC','4h','0.000101600000000','0.000103400000000','0.032802855090736','0.033384008035257','322.86274695606727','322.862746956067269','test','test','0.0'),('2019-03-27 11:59:59','2019-03-27 15:59:59','WANBTC','4h','0.000102700000000','0.000101673000000','0.032932000189519','0.032602680187624','320.66212453280315','320.662124532803148','test','test','1.00'),('2019-03-28 07:59:59','2019-03-29 11:59:59','WANBTC','4h','0.000102200000000','0.000101200000000','0.032858817966876','0.032537303113971','321.5148529048488','321.514852904848794','test','test','0.97'),('2019-03-29 15:59:59','2019-03-30 03:59:59','WANBTC','4h','0.000103500000000','0.000102465000000','0.032787370221786','0.032459496519568','316.78618571773484','316.786185717734838','test','test','1.00'),('2019-03-31 11:59:59','2019-04-02 03:59:59','WANBTC','4h','0.000103500000000','0.000103500000000','0.032714509399070','0.032714509399070','316.08221641613954','316.082216416139545','test','test','0.0'),('2019-04-19 07:59:59','2019-04-19 15:59:59','WANBTC','4h','0.000085300000000','0.000084447000000','0.032714509399070','0.032387364305079','383.5229706807789','383.522970680778883','test','test','1.00'),('2019-04-19 19:59:59','2019-04-20 03:59:59','WANBTC','4h','0.000084600000000','0.000083900000000','0.032641810489295','0.032371724586901','385.83700341955864','385.837003419558641','test','test','0.82'),('2019-05-16 03:59:59','2019-05-16 07:59:59','WANBTC','4h','0.000053200000000','0.000053000000000','0.032581791399874','0.032459303462280','612.4396879675521','612.439687967552118','test','test','0.37'),('2019-05-18 03:59:59','2019-05-18 07:59:59','WANBTC','4h','0.000054600000000','0.000054054000000','0.032554571858186','0.032229026139604','596.2375798202603','596.237579820260294','test','test','0.99'),('2019-05-18 23:59:59','2019-05-19 03:59:59','WANBTC','4h','0.000054500000000','0.000053955000000','0.032482228365168','0.032157406081516','596.0041901865686','596.004190186568621','test','test','1.00'),('2019-05-22 07:59:59','2019-05-22 11:59:59','WANBTC','4h','0.000053000000000','0.000052470000000','0.032410045635468','0.032085945179113','611.5102950088217','611.510295008821686','test','test','1.00'),('2019-05-22 19:59:59','2019-05-22 23:59:59','WANBTC','4h','0.000053600000000','0.000053064000000','0.032338023311833','0.032014643078715','603.3213304446475','603.321330444647515','test','test','1.00'),('2019-05-23 03:59:59','2019-05-23 07:59:59','WANBTC','4h','0.000053300000000','0.000052767000000','0.032266161037807','0.031943499427429','605.3688750057577','605.368875005757673','test','test','1.00'),('2019-05-23 11:59:59','2019-05-24 15:59:59','WANBTC','4h','0.000053300000000','0.000053200000000','0.032194458457723','0.032134056096639','604.0236108390785','604.023610839078515','test','test','0.18'),('2019-05-30 07:59:59','2019-05-30 15:59:59','WANBTC','4h','0.000051300000000','0.000050787000000','0.032181035710815','0.031859225353707','627.3106376377257','627.310637637725677','test','test','1.0'),('2019-06-02 11:59:59','2019-06-03 23:59:59','WANBTC','4h','0.000054600000000','0.000054054000000','0.032109522298125','0.031788427075144','588.0864889766422','588.086488976642158','test','test','0.99'),('2019-06-07 03:59:59','2019-06-09 23:59:59','WANBTC','4h','0.000057000000000','0.000056430000000','0.032038167804129','0.031717786126088','562.0731193706822','562.073119370682207','test','test','1.00'),('2019-06-12 11:59:59','2019-06-12 23:59:59','WANBTC','4h','0.000057300000000','0.000057500000000','0.031966971875675','0.032078549438941','557.8878163294124','557.887816329412431','test','test','0.34'),('2019-06-13 11:59:59','2019-06-13 15:59:59','WANBTC','4h','0.000058800000000','0.000058212000000','0.031991766889734','0.031671849220837','544.0776681927625','544.077668192762530','test','test','1.00'),('2019-06-14 03:59:59','2019-06-14 11:59:59','WANBTC','4h','0.000060300000000','0.000059697000000','0.031920674074424','0.031601467333680','529.3644125111773','529.364412511177306','test','test','1.00'),('2019-07-07 07:59:59','2019-07-07 11:59:59','WANBTC','4h','0.000034300000000','0.000033957000000','0.031849739243148','0.031531241850717','928.5638263308324','928.563826330832399','test','test','0.99'),('2019-07-07 23:59:59','2019-07-08 03:59:59','WANBTC','4h','0.000034100000000','0.000033759000000','0.031778962044830','0.031461172424382','931.9343708161158','931.934370816115802','test','test','1.00'),('2019-07-23 23:59:59','2019-07-24 03:59:59','WANBTC','4h','0.000025900000000','0.000025641000000','0.031708342129174','0.031391258707882','1224.2603138677391','1224.260313867739114','test','test','0.99'),('2019-07-24 07:59:59','2019-07-30 23:59:59','WANBTC','4h','0.000026200000000','0.000028600000000','0.031637879146665','0.034536005480711','1207.5526391856913','1207.552639185691305','test','test','0.0'),('2019-07-31 07:59:59','2019-07-31 11:59:59','WANBTC','4h','0.000028600000000','0.000029200000000','0.032281907220898','0.032959150029728','1128.7380147166978','1128.738014716697762','test','test','0.0'),('2019-08-22 15:59:59','2019-08-29 03:59:59','WANBTC','4h','0.000021800000000','0.000034700000000','0.032432405622860','0.051624058491433','1487.7250285715493','1487.725028571549274','test','test','0.0'),('2019-08-30 15:59:59','2019-08-30 19:59:59','WANBTC','4h','0.000039580000000','0.000039184200000','0.036697217371432','0.036330245197718','927.1656738613328','927.165673861332834','test','test','1.00'),('2019-08-30 23:59:59','2019-08-31 07:59:59','WANBTC','4h','0.000038200000000','0.000037818000000','0.036615667999495','0.036249511319500','958.5253403009189','958.525340300918856','test','test','0.99'),('2019-08-31 11:59:59','2019-08-31 15:59:59','WANBTC','4h','0.000040660000000','0.000040253400000','0.036534299848385','0.036168956849901','898.5317227836968','898.531722783696750','test','test','0.99'),('2019-09-01 19:59:59','2019-09-02 03:59:59','WANBTC','4h','0.000041540000000','0.000041124600000','0.036453112515389','0.036088581390235','877.5424293545659','877.542429354565911','test','test','1.00'),('2019-09-02 15:59:59','2019-09-02 19:59:59','WANBTC','4h','0.000039830000000','0.000039431700000','0.036372105598688','0.036008384542701','913.1836705671045','913.183670567104514','test','test','0.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 19:51:20
