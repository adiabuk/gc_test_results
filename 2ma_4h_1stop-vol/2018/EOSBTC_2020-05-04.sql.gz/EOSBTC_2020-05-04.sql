-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-29 15:59:59','2018-03-29 19:59:59','EOSBTC','4h','0.000828000000000','0.000819720000000','0.033333333333333','0.033000000000000','40.25764895330113','40.257648953301128','test','test','1.00'),('2018-03-29 23:59:59','2018-04-01 11:59:59','EOSBTC','4h','0.000828120000000','0.000819838800000','0.033259259259259','0.032926666666666','40.16236687830186','40.162366878301860','test','test','1.00'),('2018-04-02 11:59:59','2018-04-03 07:59:59','EOSBTC','4h','0.000819660000000','0.000811463400000','0.033185349794239','0.032853496296297','40.48672595251527','40.486725952515272','test','test','1.00'),('2018-04-04 19:59:59','2018-04-05 07:59:59','EOSBTC','4h','0.000835760000000','0.000827402400000','0.033111604572474','0.032780488526749','39.61855625116514','39.618556251165138','test','test','1.00'),('2018-04-05 15:59:59','2018-04-06 15:59:59','EOSBTC','4h','0.000885560000000','0.000876704400000','0.033038023228979','0.032707642996689','37.30749269273604','37.307492692736041','test','test','0.99'),('2018-04-09 11:59:59','2018-05-03 19:59:59','EOSBTC','4h','0.000860990000000','0.001886300000000','0.032964605399582','0.072220507979456','38.28686210011911','38.286862100119109','test','test','0.0'),('2018-05-05 03:59:59','2018-05-05 11:59:59','EOSBTC','4h','0.001860000000000','0.001841400000000','0.041688139306220','0.041271257913158','22.412978121623773','22.412978121623773','test','test','0.99'),('2018-05-06 15:59:59','2018-05-06 19:59:59','EOSBTC','4h','0.001845000000000','0.001826550000000','0.041595498996651','0.041179544006684','22.54498590604384','22.544985906043841','test','test','0.99'),('2018-05-07 03:59:59','2018-05-11 07:59:59','EOSBTC','4h','0.001812500000000','0.001794375000000','0.041503064554436','0.041088033908892','22.898242512792272','22.898242512792272','test','test','0.99'),('2018-05-24 23:59:59','2018-05-25 03:59:59','EOSBTC','4h','0.001680700000000','0.001663893000000','0.041410835522093','0.040996727166872','24.639040591475506','24.639040591475506','test','test','0.99'),('2018-05-25 11:59:59','2018-05-26 03:59:59','EOSBTC','4h','0.001635900000000','0.001619541000000','0.041318811443155','0.040905623328723','25.257541074121214','25.257541074121214','test','test','1.00'),('2018-05-27 07:59:59','2018-05-27 19:59:59','EOSBTC','4h','0.001693000000000','0.001676070000000','0.041226991862170','0.040814721943548','24.351442328511517','24.351442328511517','test','test','1.00'),('2018-05-27 23:59:59','2018-05-28 07:59:59','EOSBTC','4h','0.001689600000000','0.001672704000000','0.041135376324698','0.040724022561451','24.34622178308383','24.346221783083831','test','test','0.99'),('2018-05-28 15:59:59','2018-05-28 23:59:59','EOSBTC','4h','0.001658700000000','0.001642113000000','0.041043964377310','0.040633524733537','24.74465809206621','24.744658092066210','test','test','0.99'),('2018-05-31 19:59:59','2018-05-31 23:59:59','EOSBTC','4h','0.001654900000000','0.001638351000000','0.040952755567583','0.040543228011907','24.746362660935944','24.746362660935944','test','test','1.00'),('2018-06-02 11:59:59','2018-06-04 11:59:59','EOSBTC','4h','0.001820900000000','0.001802691000000','0.040861749444099','0.040453131949658','22.440413775660023','22.440413775660023','test','test','0.99'),('2018-06-04 19:59:59','2018-06-05 03:59:59','EOSBTC','4h','0.001816200000000','0.001798038000000','0.040770945556446','0.040363236100882','22.448488908955937','22.448488908955937','test','test','0.99'),('2018-06-05 11:59:59','2018-06-06 19:59:59','EOSBTC','4h','0.001836100000000','0.001817739000000','0.040680343455209','0.040273540020657','22.155843066940434','22.155843066940434','test','test','0.99'),('2018-06-06 23:59:59','2018-06-07 11:59:59','EOSBTC','4h','0.001816400000000','0.001798236000000','0.040589942691976','0.040184043265056','22.346367921149284','22.346367921149284','test','test','0.99'),('2018-06-07 19:59:59','2018-06-08 03:59:59','EOSBTC','4h','0.001871700000000','0.001852983000000','0.040499742819327','0.040094745391134','21.63794562126765','21.637945621267651','test','test','0.99'),('2018-06-08 19:59:59','2018-06-10 03:59:59','EOSBTC','4h','0.001847200000000','0.001828728000000','0.040409743390839','0.040005645956931','21.876214481831596','21.876214481831596','test','test','1.00'),('2018-06-10 11:59:59','2018-06-10 15:59:59','EOSBTC','4h','0.001841600000000','0.001823184000000','0.040319943961082','0.039916744521471','21.893974783385097','21.893974783385097','test','test','1.00'),('2018-07-16 15:59:59','2018-07-16 23:59:59','EOSBTC','4h','0.001199600000000','0.001203400000000','0.040230344085613','0.040357782654740','33.53646555986403','33.536465559864027','test','test','0.0'),('2018-07-17 19:59:59','2018-07-18 11:59:59','EOSBTC','4h','0.001200600000000','0.001198100000000','0.040258663767641','0.040174833466609','33.532120412827844','33.532120412827844','test','test','0.20'),('2018-08-05 03:59:59','2018-08-05 11:59:59','EOSBTC','4h','0.001008500000000','0.000998415000000','0.040240034811856','0.039837634463737','39.90087735434429','39.900877354344289','test','test','0.99'),('2018-08-05 15:59:59','2018-08-05 23:59:59','EOSBTC','4h','0.001001000000000','0.001001000000000','0.040150612512274','0.040150612512274','40.11050201026396','40.110502010263957','test','test','0.18'),('2018-08-06 07:59:59','2018-08-07 07:59:59','EOSBTC','4h','0.001001100000000','0.001002400000000','0.040150612512274','0.040202750956252','40.10649536737011','40.106495367370108','test','test','0.18'),('2018-08-17 23:59:59','2018-08-18 03:59:59','EOSBTC','4h','0.000848800000000','0.000840312000000','0.040162198833158','0.039760576844826','47.31644537365482','47.316445373654823','test','test','0.99'),('2018-08-27 15:59:59','2018-08-27 19:59:59','EOSBTC','4h','0.000771200000000','0.000774900000000','0.040072949502418','0.040265208207240','51.961812114130936','51.961812114130936','test','test','0.0'),('2018-08-27 23:59:59','2018-08-28 11:59:59','EOSBTC','4h','0.000780300000000','0.000772497000000','0.040115673659045','0.039714516922455','51.41057754587323','51.410577545873231','test','test','1.00'),('2018-08-28 19:59:59','2018-09-05 11:59:59','EOSBTC','4h','0.000823500000000','0.000830600000000','0.040026527717580','0.040371625892194','48.60537670623004','48.605376706230039','test','test','0.0'),('2018-09-13 15:59:59','2018-09-14 11:59:59','EOSBTC','4h','0.000817400000000','0.000810900000000','0.040103216200828','0.039784313698619','49.06192341672131','49.061923416721307','test','test','0.79'),('2018-09-15 11:59:59','2018-09-15 23:59:59','EOSBTC','4h','0.000831800000000','0.000823482000000','0.040032348978115','0.039632025488334','48.12737314031604','48.127373140316038','test','test','0.99'),('2018-09-19 19:59:59','2018-09-25 03:59:59','EOSBTC','4h','0.000820000000000','0.000834600000000','0.039943388202608','0.040654575358411','48.71144902757073','48.711449027570730','test','test','0.35'),('2018-09-26 15:59:59','2018-09-27 07:59:59','EOSBTC','4h','0.000860900000000','0.000852291000000','0.040101429792786','0.039700415494858','46.580822154473736','46.580822154473736','test','test','1.00'),('2018-09-27 11:59:59','2018-09-29 07:59:59','EOSBTC','4h','0.000857100000000','0.000860800000000','0.040012315504358','0.040185043969375','46.68336892353051','46.683368923530509','test','test','0.45'),('2018-09-30 11:59:59','2018-09-30 19:59:59','EOSBTC','4h','0.000878800000000','0.000870012000000','0.040050699607695','0.039650192611618','45.57430542523339','45.574305425233391','test','test','1.00'),('2018-10-01 23:59:59','2018-10-02 07:59:59','EOSBTC','4h','0.000868800000000','0.000863200000000','0.039961698053011','0.039704118047144','45.99642961902777','45.996429619027772','test','test','0.64'),('2018-10-04 11:59:59','2018-10-06 19:59:59','EOSBTC','4h','0.000863400000000','0.000865500000000','0.039904458051708','0.040001515454891','46.21781103973541','46.217811039735409','test','test','0.0'),('2018-10-08 07:59:59','2018-10-11 03:59:59','EOSBTC','4h','0.000870500000000','0.000861795000000','0.039926026363526','0.039526766099891','45.865624771425615','45.865624771425615','test','test','1.00'),('2018-10-21 03:59:59','2018-10-21 11:59:59','EOSBTC','4h','0.000839800000000','0.000837200000000','0.039837301860496','0.039713966560618','47.43665379911406','47.436653799114062','test','test','0.30'),('2018-10-21 15:59:59','2018-10-21 19:59:59','EOSBTC','4h','0.000838100000000','0.000836000000000','0.039809894016079','0.039710143655223','47.500171836390244','47.500171836390244','test','test','0.25'),('2018-10-28 15:59:59','2018-10-29 07:59:59','EOSBTC','4h','0.000836800000000','0.000835100000000','0.039787727269222','0.039706896561338','47.54747522612545','47.547475226125449','test','test','0.20'),('2018-10-29 11:59:59','2018-10-29 15:59:59','EOSBTC','4h','0.000837500000000','0.000829125000000','0.039769764889692','0.039372067240795','47.486286435453124','47.486286435453124','test','test','1.00'),('2018-11-02 15:59:59','2018-11-03 23:59:59','EOSBTC','4h','0.000839700000000','0.000834600000000','0.039681387634382','0.039440378849179','47.256624549698174','47.256624549698174','test','test','0.60'),('2018-11-04 07:59:59','2018-11-08 23:59:59','EOSBTC','4h','0.000847600000000','0.000852500000000','0.039627830126559','0.039856919753293','46.75298504785118','46.752985047851183','test','test','0.34'),('2018-11-12 19:59:59','2018-11-12 23:59:59','EOSBTC','4h','0.000846000000000','0.000845400000000','0.039678738932500','0.039650597982902','46.901582662529016','46.901582662529016','test','test','0.07'),('2018-11-19 23:59:59','2018-11-20 07:59:59','EOSBTC','4h','0.000839500000000','0.000831105000000','0.039672485388144','0.039275760534263','47.25727860410297','47.257278604102972','test','test','1.00'),('2018-11-20 23:59:59','2018-11-21 03:59:59','EOSBTC','4h','0.000835100000000','0.000826749000000','0.039584324309504','0.039188481066409','47.40069968806636','47.400699688066361','test','test','0.99'),('2018-11-23 03:59:59','2018-11-23 07:59:59','EOSBTC','4h','0.000833900000000','0.000838400000000','0.039496359144372','0.039709494551675','47.36342384503177','47.363423845031768','test','test','0.0'),('2018-11-24 23:59:59','2018-11-25 03:59:59','EOSBTC','4h','0.000840300000000','0.000835900000000','0.039543722568217','0.039336662733277','47.059053395474365','47.059053395474365','test','test','0.52'),('2018-11-25 07:59:59','2018-11-25 23:59:59','EOSBTC','4h','0.000835500000000','0.000833300000000','0.039497709271564','0.039393705728300','47.274337847473106','47.274337847473106','test','test','0.26'),('2018-11-26 15:59:59','2018-11-26 23:59:59','EOSBTC','4h','0.000846500000000','0.000842200000000','0.039474597373061','0.039274076677604','46.63271987366882','46.632719873668819','test','test','0.53'),('2018-12-15 23:59:59','2018-12-25 11:59:59','EOSBTC','4h','0.000586600000000','0.000658700000000','0.039430037218515','0.044276449907664','67.21792911441301','67.217929114413010','test','test','0.0'),('2018-12-26 03:59:59','2018-12-26 19:59:59','EOSBTC','4h','0.000675000000000','0.000668250000000','0.040507017816103','0.040101947637942','60.01039676459752','60.010396764597523','test','test','1.00'),('2018-12-28 19:59:59','2018-12-29 11:59:59','EOSBTC','4h','0.000684100000000','0.000677259000000','0.040417002220956','0.040012832198746','59.0805470266868','59.080547026686801','test','test','1.00'),('2018-12-29 23:59:59','2018-12-30 03:59:59','EOSBTC','4h','0.000689600000000','0.000682704000000','0.040327186660465','0.039923914793860','58.47909898559358','58.479098985593581','test','test','1.00'),('2019-01-01 11:59:59','2019-01-07 03:59:59','EOSBTC','4h','0.000693100000000','0.000694000000000','0.040237570690109','0.040289819735876','58.054495296650806','58.054495296650806','test','test','0.60'),('2019-01-09 15:59:59','2019-01-10 11:59:59','EOSBTC','4h','0.000703400000000','0.000696366000000','0.040249181589168','0.039846689773276','57.22090075230025','57.220900752300253','test','test','1.00'),('2019-01-17 11:59:59','2019-01-17 15:59:59','EOSBTC','4h','0.000672400000000','0.000673000000000','0.040159738963414','0.040195574542501','59.7259651448754','59.725965144875403','test','test','0.0'),('2019-01-17 19:59:59','2019-01-18 11:59:59','EOSBTC','4h','0.000682700000000','0.000676900000000','0.040167702425434','0.039826450522596','58.83653497207201','58.836534972072009','test','test','0.84'),('2019-01-22 19:59:59','2019-01-22 23:59:59','EOSBTC','4h','0.000687900000000','0.000681021000000','0.040091868669247','0.039690949982555','58.28153607973155','58.281536079731552','test','test','1.0'),('2019-01-25 07:59:59','2019-01-26 07:59:59','EOSBTC','4h','0.000684100000000','0.000677259000000','0.040002775627760','0.039602747871482','58.47504111644529','58.475041116445290','test','test','1.00'),('2019-01-27 03:59:59','2019-01-27 11:59:59','EOSBTC','4h','0.000677300000000','0.000670527000000','0.039913880570810','0.039514741765102','58.93087342508424','58.930873425084243','test','test','0.99'),('2019-02-02 23:59:59','2019-02-03 15:59:59','EOSBTC','4h','0.000695900000000','0.000688941000000','0.039825183058430','0.039426931227846','57.2283130599655','57.228313059965501','test','test','0.99'),('2019-02-04 11:59:59','2019-02-06 03:59:59','EOSBTC','4h','0.000692000000000','0.000685080000000','0.039736682651634','0.039339315825118','57.422951808719006','57.422951808719006','test','test','0.99'),('2019-02-07 03:59:59','2019-02-25 11:59:59','EOSBTC','4h','0.000693000000000','0.000896200000000','0.039648378912408','0.051273993046609','57.212667983272404','57.212667983272404','test','test','0.53'),('2019-02-25 15:59:59','2019-02-25 23:59:59','EOSBTC','4h','0.000935800000000','0.000926442000000','0.042231848720008','0.041809530232808','45.129139474255176','45.129139474255176','test','test','1.00'),('2019-02-27 23:59:59','2019-03-01 23:59:59','EOSBTC','4h','0.000917600000000','0.000908424000000','0.042138000167297','0.041716620165624','45.92197053977429','45.921970539774293','test','test','0.99'),('2019-03-03 11:59:59','2019-03-04 03:59:59','EOSBTC','4h','0.000926000000000','0.000916740000000','0.042044360166925','0.041623916565256','45.40427663814807','45.404276638148069','test','test','0.99'),('2019-03-05 15:59:59','2019-03-08 23:59:59','EOSBTC','4h','0.000946300000000','0.000936837000000','0.041950928255443','0.041531418972889','44.33153149682248','44.331531496822478','test','test','1.00'),('2019-03-09 07:59:59','2019-03-10 03:59:59','EOSBTC','4h','0.000958500000000','0.000948915000000','0.041857703970431','0.041439126930727','43.67000935882222','43.670009358822220','test','test','0.99'),('2019-03-12 11:59:59','2019-03-12 15:59:59','EOSBTC','4h','0.000942400000000','0.000935900000000','0.041764686850497','0.041476623963689','44.31736720129126','44.317367201291262','test','test','0.68'),('2019-03-15 11:59:59','2019-03-18 03:59:59','EOSBTC','4h','0.000941600000000','0.000935700000000','0.041700672875651','0.041439379364642','44.2870357642849','44.287035764284902','test','test','0.62'),('2019-03-25 23:59:59','2019-03-26 03:59:59','EOSBTC','4h','0.000927300000000','0.000921400000000','0.041642607650982','0.041377654146031','44.90737372045939','44.907373720459390','test','test','0.63'),('2019-03-26 11:59:59','2019-03-28 15:59:59','EOSBTC','4h','0.000924700000000','0.001065800000000','0.041583729094326','0.047928991531018','44.969967659052905','44.969967659052905','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 19:47:32
