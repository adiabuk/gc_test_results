-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-22 23:59:59','2018-03-23 07:59:59','MDAETH','4h','0.001660900000000','0.001644291000000','1.297777777777778','1.284800000000000','781.3702075849104','781.370207584910418','test','test','1.00'),('2018-03-24 11:59:59','2018-03-24 23:59:59','MDAETH','4h','0.001718800000000','0.001701612000000','1.294893827160494','1.281944888888889','753.3708559230241','753.370855923024124','test','test','1.00'),('2018-03-25 15:59:59','2018-03-26 15:59:59','MDAETH','4h','0.001754800000000','0.001737252000000','1.292016285322359','1.279096122469135','736.2755216106447','736.275521610644660','test','test','1.00'),('2018-03-31 15:59:59','2018-04-01 19:59:59','MDAETH','4h','0.001827400000000','0.001809126000000','1.289145138021643','1.276253686641426','705.4531782979329','705.453178297932936','test','test','0.99'),('2018-04-04 19:59:59','2018-04-04 23:59:59','MDAETH','4h','0.001820000000000','0.001801800000000','1.286280371048261','1.273417567337779','706.7474566199238','706.747456619923810','test','test','1.00'),('2018-04-06 11:59:59','2018-04-07 07:59:59','MDAETH','4h','0.001828300000000','0.001853000000000','1.283421970223710','1.300760767283561','701.9755894676529','701.975589467652867','test','test','0.28'),('2018-04-11 15:59:59','2018-04-11 19:59:59','MDAETH','4h','0.001912800000000','0.001893672000000','1.287275036237010','1.274402285874640','672.9794208683657','672.979420868365651','test','test','0.99'),('2018-04-12 19:59:59','2018-04-12 23:59:59','MDAETH','4h','0.001799700000000','0.001781703000000','1.284414425045372','1.271570280794918','713.682516555744','713.682516555743973','test','test','1.00'),('2018-04-14 07:59:59','2018-04-14 19:59:59','MDAETH','4h','0.001825200000000','0.001806948000000','1.281560170767494','1.268744569059819','702.1478034009937','702.147803400993666','test','test','1.00'),('2018-04-15 11:59:59','2018-04-15 15:59:59','MDAETH','4h','0.001852400000000','0.001856800000000','1.278712259276899','1.281749580557842','690.3002911233531','690.300291123353077','test','test','0.0'),('2018-04-17 19:59:59','2018-04-17 23:59:59','MDAETH','4h','0.001894000000000','0.001875060000000','1.279387219561553','1.266593347365937','675.4948360937451','675.494836093745107','test','test','1.00'),('2018-04-18 11:59:59','2018-04-21 03:59:59','MDAETH','4h','0.001892800000000','0.001894400000000','1.276544136851416','1.277623210508941','674.421035952777','674.421035952776947','test','test','0.0'),('2018-04-23 11:59:59','2018-04-23 23:59:59','MDAETH','4h','0.001935200000000','0.001915848000000','1.276783930997533','1.264016091687558','659.7684637234047','659.768463723404693','test','test','1.00'),('2018-04-30 15:59:59','2018-04-30 19:59:59','MDAETH','4h','0.001899800000000','0.001880802000000','1.273946633373094','1.261207167039363','670.568814282079','670.568814282078961','test','test','1.00'),('2018-05-01 15:59:59','2018-05-01 19:59:59','MDAETH','4h','0.001899900000000','0.001880901000000','1.271115640854487','1.258404484445942','669.0434448415638','669.043444841563769','test','test','1.00'),('2018-05-02 19:59:59','2018-05-03 03:59:59','MDAETH','4h','0.001818500000000','0.001800315000000','1.268290939430366','1.255608030036062','697.4379650428189','697.437965042818860','test','test','0.99'),('2018-06-01 15:59:59','2018-06-01 19:59:59','MDAETH','4h','0.001395800000000','0.001381842000000','1.265472515120521','1.252817789969316','906.6288258493485','906.628825849348459','test','test','1.00'),('2018-06-02 07:59:59','2018-06-02 11:59:59','MDAETH','4h','0.001381000000000','0.001367190000000','1.262660353975808','1.250033750436050','914.3087284401219','914.308728440121854','test','test','0.99'),('2018-06-06 11:59:59','2018-06-06 15:59:59','MDAETH','4h','0.001288900000000','0.001276011000000','1.259854442078084','1.247255897657303','977.4648476049999','977.464847604999932','test','test','1.00'),('2018-06-29 23:59:59','2018-06-30 03:59:59','MDAETH','4h','0.000976100000000','0.001002200000000','1.257054765540133','1.290667232890402','1287.8339980945939','1287.833998094593881','test','test','0.0'),('2018-06-30 07:59:59','2018-06-30 11:59:59','MDAETH','4h','0.001123000000000','0.001111770000000','1.264524202729082','1.251878960701791','1126.0233327952642','1126.023332795264196','test','test','1.00'),('2018-06-30 15:59:59','2018-07-01 11:59:59','MDAETH','4h','0.001109800000000','0.001098702000000','1.261714148945239','1.249097007455787','1136.8842574745354','1136.884257474535389','test','test','0.99'),('2018-07-01 15:59:59','2018-07-02 07:59:59','MDAETH','4h','0.001141400000000','0.001129986000000','1.258910339725361','1.246321236328107','1102.9528120951122','1102.952812095112222','test','test','0.99'),('2018-07-05 15:59:59','2018-07-05 19:59:59','MDAETH','4h','0.001219900000000','0.001207701000000','1.256112761192638','1.243551633580712','1029.685024340223','1029.685024340222981','test','test','1.00'),('2018-07-07 15:59:59','2018-07-07 23:59:59','MDAETH','4h','0.001176700000000','0.001164933000000','1.253321399501099','1.240788185506088','1065.1154920549834','1065.115492054983406','test','test','0.99'),('2018-07-09 15:59:59','2018-07-09 23:59:59','MDAETH','4h','0.001180100000000','0.001168299000000','1.250536240835541','1.238030878427185','1059.6866713291595','1059.686671329159481','test','test','1.00'),('2018-07-17 07:59:59','2018-07-30 19:59:59','MDAETH','4h','0.001150800000000','0.001346900000000','1.247757271411462','1.460379100507558','1084.2520606634182','1084.252060663418206','test','test','0.0'),('2018-07-31 07:59:59','2018-07-31 15:59:59','MDAETH','4h','0.001377400000000','0.001363626000000','1.295006566766150','1.282056501098488','940.1819128547626','940.181912854762572','test','test','1.00'),('2018-07-31 19:59:59','2018-07-31 23:59:59','MDAETH','4h','0.001363600000000','0.001349964000000','1.292128774395558','1.279207486651603','947.5863701932811','947.586370193281141','test','test','1.00'),('2018-08-10 03:59:59','2018-08-10 07:59:59','MDAETH','4h','0.001295000000000','0.001282050000000','1.289257377119124','1.276364803347933','995.5655421769296','995.565542176929625','test','test','1.00'),('2018-08-11 03:59:59','2018-08-11 07:59:59','MDAETH','4h','0.001298100000000','0.001285119000000','1.286392360725526','1.273528437118271','990.9809419347707','990.980941934770726','test','test','1.00'),('2018-08-13 23:59:59','2018-08-14 23:59:59','MDAETH','4h','0.001253000000000','0.001240470000000','1.283533711035025','1.270698373924675','1024.368484465303','1024.368484465303027','test','test','0.99'),('2018-08-15 03:59:59','2018-08-15 19:59:59','MDAETH','4h','0.001269400000000','0.001256706000000','1.280681413899391','1.267874599760397','1008.8872017483783','1008.887201748378288','test','test','0.99'),('2018-08-17 11:59:59','2018-08-18 23:59:59','MDAETH','4h','0.001309200000000','0.001296108000000','1.277835455201837','1.265057100649819','976.0429691428637','976.042969142863740','test','test','0.99'),('2018-08-19 07:59:59','2018-09-07 07:59:59','MDAETH','4h','0.001440900000000','0.002634200000000','1.274995820856944','2.330900125825083','884.8607265299079','884.860726529907879','test','test','0.49'),('2018-09-07 19:59:59','2018-09-07 23:59:59','MDAETH','4h','0.002686100000000','0.002659239000000','1.509641221960975','1.494544809741365','562.0197393846005','562.019739384600484','test','test','0.99'),('2018-09-17 03:59:59','2018-09-17 07:59:59','MDAETH','4h','0.002506200000000','0.002481138000000','1.506286463689951','1.491223599053051','601.0240458422913','601.024045842291343','test','test','1.00'),('2018-10-04 11:59:59','2018-10-04 15:59:59','MDAETH','4h','0.002020800000000','0.002000592000000','1.502939160437306','1.487909768832933','743.7347389337422','743.734738933742165','test','test','0.99'),('2018-10-07 15:59:59','2018-10-20 15:59:59','MDAETH','4h','0.002136500000000','0.009737700000000','1.499599295636335','6.834845804408118','701.8952940024969','701.895294002496939','test','test','0.0'),('2018-10-22 19:59:59','2018-10-22 23:59:59','MDAETH','4h','0.008790100000000','0.008702199000000','2.685209630918953','2.658357534609764','305.48112432383624','305.481124323836241','test','test','0.99'),('2018-11-12 07:59:59','2018-11-12 11:59:59','MDAETH','4h','0.006735100000000','0.006667749000000','2.679242498405800','2.652450073421742','397.80292770794796','397.802927707947958','test','test','1.00'),('2018-11-12 23:59:59','2018-11-13 03:59:59','MDAETH','4h','0.006653000000000','0.006586470000000','2.673288626187121','2.646555739925250','401.81701881664225','401.817018816642246','test','test','1.00'),('2018-11-22 11:59:59','2018-11-22 15:59:59','MDAETH','4h','0.005463500000000','0.005530700000000','2.667347984795593','2.700155852385648','488.212315328195','488.212315328195018','test','test','0.0'),('2018-11-22 23:59:59','2018-11-23 03:59:59','MDAETH','4h','0.005704500000000','0.005647455000000','2.674638622037828','2.647892235817450','468.8646896376243','468.864689637624281','test','test','1.00'),('2018-11-25 19:59:59','2018-11-30 15:59:59','MDAETH','4h','0.005917300000000','0.008283200000000','2.668694980655522','3.735712954179409','450.9987630600986','450.998763060098611','test','test','0.0'),('2018-12-07 15:59:59','2018-12-07 19:59:59','MDAETH','4h','0.007575600000000','0.007499844000000','2.905810085883052','2.876751985024221','383.57490969468455','383.574909694684550','test','test','0.99'),('2018-12-11 03:59:59','2018-12-11 07:59:59','MDAETH','4h','0.007458000000000','0.007383420000000','2.899352730136645','2.870359202835278','388.75740548895755','388.757405488957545','test','test','1.00'),('2018-12-11 15:59:59','2018-12-20 19:59:59','MDAETH','4h','0.007480200000000','0.009143600000000','2.892909724069675','3.536216859576412','386.74229620460346','386.742296204603463','test','test','0.91'),('2019-01-10 11:59:59','2019-01-10 15:59:59','MDAETH','4h','0.005887700000000','0.005828823000000','3.035866865293394','3.005508196640460','515.6286606473486','515.628660647348624','test','test','0.99'),('2019-01-17 03:59:59','2019-01-20 15:59:59','MDAETH','4h','0.005848500000000','0.005899800000000','3.029120494481631','3.055690363912581','517.9311779912167','517.931177991216714','test','test','0.0'),('2019-01-21 23:59:59','2019-01-31 03:59:59','MDAETH','4h','0.005962800000000','0.006341800000000','3.035024909910731','3.227933349042710','508.9932430922941','508.993243092294108','test','test','0.66'),('2019-01-31 15:59:59','2019-02-05 23:59:59','MDAETH','4h','0.006709000000000','0.006641910000000','3.077893451940060','3.047114517420659','458.77082306454906','458.770823064549063','test','test','0.99'),('2019-02-06 03:59:59','2019-02-06 23:59:59','MDAETH','4h','0.006657500000000','0.006697800000000','3.071053688713526','3.089643769623049','461.292330261138','461.292330261137977','test','test','0.0'),('2019-02-23 07:59:59','2019-02-23 15:59:59','MDAETH','4h','0.006221500000000','0.006159285000000','3.075184817804531','3.044432969626485','494.28350362525623','494.283503625256230','test','test','1.00'),('2019-02-24 23:59:59','2019-03-02 15:59:59','MDAETH','4h','0.006162200000000','0.006436200000000','3.068351073764966','3.204784197359072','497.9311080076865','497.931108007686476','test','test','0.04'),('2019-03-07 19:59:59','2019-03-07 23:59:59','MDAETH','4h','0.006495600000000','0.006430644000000','3.098669545674767','3.067682850218019','477.0413119149527','477.041311914952701','test','test','0.99'),('2019-03-08 07:59:59','2019-03-09 03:59:59','MDAETH','4h','0.006430000000000','0.006365700000000','3.091783613351045','3.060865777217535','480.83726490685','480.837264906850010','test','test','0.99'),('2019-03-09 19:59:59','2019-03-09 23:59:59','MDAETH','4h','0.006945000000000','0.006875550000000','3.084912983099155','3.054063853268163','444.19193421154137','444.191934211541366','test','test','1.00'),('2019-03-10 03:59:59','2019-03-10 07:59:59','MDAETH','4h','0.007412900000000','0.007338771000000','3.078057620914489','3.047277044705344','415.2298858630886','415.229885863088612','test','test','1.00'),('2019-03-10 19:59:59','2019-03-12 19:59:59','MDAETH','4h','0.007617800000000','0.007541622000000','3.071217492868012','3.040505317939332','403.16331393158293','403.163313931582934','test','test','0.99'),('2019-03-12 23:59:59','2019-03-13 03:59:59','MDAETH','4h','0.008161400000000','0.008079786000000','3.064392565106084','3.033748639455023','375.4738850082197','375.473885008219725','test','test','1.00'),('2019-03-13 07:59:59','2019-03-14 11:59:59','MDAETH','4h','0.008747000000000','0.008659530000000','3.057582803850293','3.027006975811791','349.5578831428253','349.557883142825290','test','test','0.99'),('2019-03-18 11:59:59','2019-03-18 19:59:59','MDAETH','4h','0.008097200000000','0.008016228000000','3.050788175397292','3.020280293643319','376.7707572243852','376.770757224385193','test','test','1.00');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 19:27:34
