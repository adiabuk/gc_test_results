-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-18 07:59:59','2018-03-18 15:59:59','IOTABTC','4h','0.000148070000000','0.000151180000000','0.033333333333333','0.034033452646271','225.1187501406992','225.118750140699206','test','test','0.0'),('2018-03-18 19:59:59','2018-03-18 23:59:59','IOTABTC','4h','0.000155520000000','0.000153964800000','0.033488915402875','0.033154026248846','215.33510418515374','215.335104185153739','test','test','0.99'),('2018-03-20 15:59:59','2018-03-20 23:59:59','IOTABTC','4h','0.000169160000000','0.000167468400000','0.033414495590869','0.033080350634960','197.53189637543548','197.531896375435480','test','test','0.99'),('2018-03-25 23:59:59','2018-03-26 11:59:59','IOTABTC','4h','0.000156180000000','0.000154618200000','0.033340241156222','0.033006838744660','213.47317938418635','213.473179384186352','test','test','0.99'),('2018-03-28 11:59:59','2018-03-28 15:59:59','IOTABTC','4h','0.000153230000000','0.000151697700000','0.033266151731431','0.032933490214117','217.09946963016816','217.099469630168159','test','test','0.99'),('2018-03-29 23:59:59','2018-03-31 19:59:59','IOTABTC','4h','0.000153490000000','0.000154090000000','0.033192226949805','0.033321977006290','216.25009414167263','216.250094141672633','test','test','0.0'),('2018-04-09 03:59:59','2018-04-09 11:59:59','IOTABTC','4h','0.000148010000000','0.000146590000000','0.033221060295691','0.032902339225359','224.45145798048034','224.451457980480342','test','test','0.95'),('2018-04-10 15:59:59','2018-04-10 23:59:59','IOTABTC','4h','0.000148000000000','0.000147490000000','0.033150233391173','0.033035999478812','223.98806345386936','223.988063453869358','test','test','0.34'),('2018-04-11 03:59:59','2018-04-25 03:59:59','IOTABTC','4h','0.000150850000000','0.000198590000000','0.033124848077315','0.043607978652131','219.5879885801436','219.587988580143588','test','test','0.69'),('2018-04-25 07:59:59','2018-04-25 11:59:59','IOTABTC','4h','0.000211880000000','0.000209761200000','0.035454432649496','0.035099888323001','167.33260642578819','167.332606425788185','test','test','1.00'),('2018-04-29 03:59:59','2018-04-29 11:59:59','IOTABTC','4h','0.000219530000000','0.000217334700000','0.035375645021386','0.035021888571172','161.14264574949206','161.142645749492061','test','test','0.99'),('2018-04-29 15:59:59','2018-04-30 03:59:59','IOTABTC','4h','0.000216630000000','0.000214463700000','0.035297032476894','0.034944062152125','162.93695460875225','162.936954608752245','test','test','1.0'),('2018-05-01 23:59:59','2018-05-07 03:59:59','IOTABTC','4h','0.000216090000000','0.000232870000000','0.035218594626945','0.037953418162695','162.98114039032504','162.981140390325038','test','test','0.0'),('2018-05-07 23:59:59','2018-05-10 23:59:59','IOTABTC','4h','0.000240660000000','0.000238253400000','0.035826333190445','0.035468069858541','148.86700403243304','148.867004032433044','test','test','1.00'),('2018-05-15 11:59:59','2018-05-15 15:59:59','IOTABTC','4h','0.000234900000000','0.000232551000000','0.035746719116689','0.035389251925522','152.17845515831795','152.178455158317945','test','test','1.00'),('2018-05-15 23:59:59','2018-05-16 03:59:59','IOTABTC','4h','0.000234560000000','0.000232214400000','0.035667281963096','0.035310609143465','152.06037671852073','152.060376718520729','test','test','0.99'),('2018-05-29 19:59:59','2018-05-29 23:59:59','IOTABTC','4h','0.000217120000000','0.000214948800000','0.035588021336512','0.035232141123147','163.9094571504769','163.909457150476896','test','test','0.99'),('2018-05-30 03:59:59','2018-05-30 15:59:59','IOTABTC','4h','0.000214020000000','0.000211879800000','0.035508936844653','0.035153847476206','165.91410543244865','165.914105432448650','test','test','0.99'),('2018-05-31 07:59:59','2018-06-04 07:59:59','IOTABTC','4h','0.000225250000000','0.000229150000000','0.035430028096109','0.036043466984344','157.29202262423476','157.292022624234761','test','test','0.0'),('2018-06-05 19:59:59','2018-06-05 23:59:59','IOTABTC','4h','0.000231490000000','0.000229175100000','0.035566347849050','0.035210684370559','153.6409687202471','153.640968720247088','test','test','1.00'),('2018-07-01 23:59:59','2018-07-02 07:59:59','IOTABTC','4h','0.000167900000000','0.000166221000000','0.035487311520496','0.035132438405291','211.3598065544755','211.359806554475512','test','test','1.00'),('2018-07-02 15:59:59','2018-07-05 19:59:59','IOTABTC','4h','0.000172630000000','0.000174070000000','0.035408450828229','0.035703811826854','205.11180460075684','205.111804600756841','test','test','0.0'),('2018-07-16 11:59:59','2018-07-16 19:59:59','IOTABTC','4h','0.000162310000000','0.000160686900000','0.035474086605701','0.035119345739644','218.5576157088342','218.557615708834192','test','test','1.00'),('2018-07-16 23:59:59','2018-07-17 07:59:59','IOTABTC','4h','0.000162650000000','0.000161023500000','0.035395255302133','0.035041302749112','217.61607932451682','217.616079324516818','test','test','0.99'),('2018-07-17 15:59:59','2018-07-17 19:59:59','IOTABTC','4h','0.000159990000000','0.000158390100000','0.035316599179239','0.034963433187447','220.74254127907437','220.742541279074374','test','test','1.00'),('2018-08-05 07:59:59','2018-08-05 11:59:59','IOTABTC','4h','0.000130990000000','0.000129680100000','0.035238117847730','0.034885736669253','269.01380141789275','269.013801417892751','test','test','0.99'),('2018-08-26 23:59:59','2018-09-03 11:59:59','IOTABTC','4h','0.000085530000000','0.000095620000000','0.035159810919179','0.039307624460328','411.08161953910115','411.081619539101155','test','test','0.0'),('2018-09-03 15:59:59','2018-09-03 19:59:59','IOTABTC','4h','0.000096610000000','0.000096200000000','0.036081547261657','0.035928421970514','373.47631985981656','373.476319859816556','test','test','0.42'),('2018-09-04 11:59:59','2018-09-04 19:59:59','IOTABTC','4h','0.000099100000000','0.000098109000000','0.036047519419181','0.035687044224989','363.7489346032357','363.748934603235682','test','test','1.00'),('2018-09-10 03:59:59','2018-09-10 07:59:59','IOTABTC','4h','0.000093110000000','0.000092178900000','0.035967413820471','0.035607739682266','386.28948362658497','386.289483626584968','test','test','1.00'),('2018-09-14 03:59:59','2018-09-14 07:59:59','IOTABTC','4h','0.000091590000000','0.000090674100000','0.035887486234204','0.035528611371862','391.8275601507102','391.827560150710212','test','test','0.99'),('2018-09-21 19:59:59','2018-09-22 11:59:59','IOTABTC','4h','0.000089740000000','0.000088842600000','0.035807736264794','0.035449658902146','399.01645046572554','399.016450465725541','test','test','1.00'),('2018-09-25 23:59:59','2018-09-26 03:59:59','IOTABTC','4h','0.000088490000000','0.000087605100000','0.035728163517539','0.035370881882364','403.75368423029835','403.753684230298347','test','test','0.99'),('2018-10-07 19:59:59','2018-10-10 07:59:59','IOTABTC','4h','0.000086130000000','0.000087690000000','0.035648767598611','0.036294443640104','413.89489839325825','413.894898393258245','test','test','0.0'),('2018-10-10 15:59:59','2018-10-11 03:59:59','IOTABTC','4h','0.000088070000000','0.000087189300000','0.035792251163388','0.035434328651754','406.406848681589','406.406848681588997','test','test','0.99'),('2018-11-02 11:59:59','2018-11-03 07:59:59','IOTABTC','4h','0.000075350000000','0.000074596500000','0.035712712827469','0.035355585699194','473.95770175804756','473.957701758047563','test','test','1.00'),('2018-11-04 19:59:59','2018-11-07 15:59:59','IOTABTC','4h','0.000077410000000','0.000076635900000','0.035633351243408','0.035277017730974','460.319742196199','460.319742196199002','test','test','0.99'),('2018-11-10 15:59:59','2018-11-10 19:59:59','IOTABTC','4h','0.000076490000000','0.000076390000000','0.035554166018422','0.035507683908318','464.82110103833753','464.821101038337531','test','test','0.13'),('2018-11-12 07:59:59','2018-11-14 11:59:59','IOTABTC','4h','0.000076300000000','0.000076150000000','0.035543836660622','0.035473960179638','465.84320656122605','465.843206561226054','test','test','0.19'),('2018-12-15 15:59:59','2019-01-06 07:59:59','IOTABTC','4h','0.000067190000000','0.000093400000000','0.035528308553736','0.049387468654844','528.7737543345172','528.773754334517207','test','test','0.0'),('2019-01-19 11:59:59','2019-01-19 19:59:59','IOTABTC','4h','0.000085130000000','0.000084920000000','0.038608121909538','0.038512882797580','453.51958075341236','453.519580753412356','test','test','0.24'),('2019-02-08 11:59:59','2019-02-09 19:59:59','IOTABTC','4h','0.000075090000000','0.000075110000000','0.038586957662436','0.038597235184786','513.8761174914931','513.876117491493119','test','test','0.06'),('2019-02-10 03:59:59','2019-02-10 15:59:59','IOTABTC','4h','0.000076270000000','0.000075507300000','0.038589241556292','0.038203349140729','505.9557041601123','505.955704160112305','test','test','0.99'),('2019-02-12 19:59:59','2019-02-12 23:59:59','IOTABTC','4h','0.000075220000000','0.000075310000000','0.038503487686167','0.038549556735512','511.8783260591154','511.878326059115409','test','test','0.0'),('2019-02-15 11:59:59','2019-02-16 03:59:59','IOTABTC','4h','0.000075640000000','0.000074883600000','0.038513725252688','0.038128588000161','509.1714073597008','509.171407359700822','test','test','1.00'),('2019-02-16 11:59:59','2019-02-16 15:59:59','IOTABTC','4h','0.000075710000000','0.000074990000000','0.038428139196571','0.038062688658709','507.5701914749789','507.570191474978913','test','test','0.95'),('2019-02-16 23:59:59','2019-02-18 03:59:59','IOTABTC','4h','0.000075730000000','0.000074972700000','0.038346927965935','0.037963458686276','506.3637655610018','506.363765561001799','test','test','1.00'),('2019-02-18 07:59:59','2019-02-21 19:59:59','IOTABTC','4h','0.000075440000000','0.000076050000000','0.038261712570455','0.038571092802003','507.1807074556585','507.180707455658478','test','test','0.0'),('2019-02-23 19:59:59','2019-02-24 07:59:59','IOTABTC','4h','0.000077130000000','0.000076770000000','0.038330463733021','0.038151558418048','496.9592082590575','496.959208259057505','test','test','0.46'),('2019-02-24 11:59:59','2019-02-24 15:59:59','IOTABTC','4h','0.000077510000000','0.000076734900000','0.038290706996360','0.037907799926396','494.0098954503991','494.009895450399085','test','test','0.99'),('2019-03-01 07:59:59','2019-03-02 07:59:59','IOTABTC','4h','0.000076390000000','0.000075626100000','0.038205616536368','0.037823560371004','500.13897809095994','500.138978090959938','test','test','1.00'),('2019-03-13 03:59:59','2019-03-13 11:59:59','IOTABTC','4h','0.000073980000000','0.000073240200000','0.038120715166288','0.037739508014625','515.2840655080771','515.284065508077106','test','test','0.99'),('2019-03-13 15:59:59','2019-03-17 11:59:59','IOTABTC','4h','0.000073190000000','0.000074870000000','0.038036002465918','0.038909079172336','519.6885157250716','519.688515725071625','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 19:09:51
