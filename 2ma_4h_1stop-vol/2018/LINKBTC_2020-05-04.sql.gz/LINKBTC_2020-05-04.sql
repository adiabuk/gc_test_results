-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-21 23:59:59','2018-03-22 03:59:59','LINKBTC','4h','0.000049890000000','0.000049391100000','0.033333333333333','0.033000000000000','668.1365671143182','668.136567114318154','test','test','1.00'),('2018-03-26 07:59:59','2018-03-26 11:59:59','LINKBTC','4h','0.000048650000000','0.000048163500000','0.033259259259259','0.032926666666666','683.6435613414047','683.643561341404734','test','test','1.00'),('2018-04-06 03:59:59','2018-04-06 07:59:59','LINKBTC','4h','0.000042610000000','0.000042183900000','0.033185349794239','0.032853496296297','778.816000803536','778.816000803535985','test','test','0.99'),('2018-04-07 07:59:59','2018-04-07 11:59:59','LINKBTC','4h','0.000042230000000','0.000042610000000','0.033111604572474','0.033409554128182','784.0777781783986','784.077778178398603','test','test','0.0'),('2018-04-08 15:59:59','2018-04-21 11:59:59','LINKBTC','4h','0.000044970000000','0.000051280000000','0.033177815584853','0.037833186195047','737.776641869098','737.776641869097944','test','test','0.0'),('2018-04-21 19:59:59','2018-04-25 03:59:59','LINKBTC','4h','0.000055220000000','0.000054667800000','0.034212342387119','0.033870218963248','619.5643315305806','619.564331530580603','test','test','0.99'),('2018-04-29 03:59:59','2018-05-04 11:59:59','LINKBTC','4h','0.000053030000000','0.000056750000000','0.034136314959592','0.036530942371428','643.717046192566','643.717046192566045','test','test','0.0'),('2018-05-04 19:59:59','2018-05-04 23:59:59','LINKBTC','4h','0.000060920000000','0.000060310800000','0.034668454384444','0.034321769840600','569.081654373674','569.081654373674041','test','test','1.00'),('2018-05-07 03:59:59','2018-05-07 07:59:59','LINKBTC','4h','0.000058030000000','0.000058530000000','0.034591413374701','0.034889461051547','596.0953536912134','596.095353691213404','test','test','0.0'),('2018-05-07 23:59:59','2018-05-08 23:59:59','LINKBTC','4h','0.000061310000000','0.000060696900000','0.034657646191778','0.034311069729860','565.2853725620291','565.285372562029124','test','test','1.00'),('2018-05-10 11:59:59','2018-05-10 23:59:59','LINKBTC','4h','0.000060820000000','0.000060211800000','0.034580629200241','0.034234822908239','568.5733179914612','568.573317991461181','test','test','0.99'),('2018-05-13 19:59:59','2018-05-13 23:59:59','LINKBTC','4h','0.000058130000000','0.000057860000000','0.034503783357574','0.034343521504718','593.562417986815','593.562417986815035','test','test','0.46'),('2018-05-14 23:59:59','2018-05-16 03:59:59','LINKBTC','4h','0.000059590000000','0.000058994100000','0.034468169612494','0.034123487916369','578.4220441767822','578.422044176782151','test','test','0.99'),('2018-06-02 15:59:59','2018-06-02 23:59:59','LINKBTC','4h','0.000048210000000','0.000048110000000','0.034391573680022','0.034320236667618','713.3701240411165','713.370124041116469','test','test','0.20'),('2018-06-30 03:59:59','2018-07-05 15:59:59','LINKBTC','4h','0.000032010000000','0.000034750000000','0.034375721010599','0.037318222590388','1073.90568605433','1073.905686054330090','test','test','0.46'),('2018-07-06 19:59:59','2018-07-09 23:59:59','LINKBTC','4h','0.000034850000000','0.000035090000000','0.035029610250552','0.035270847164760','1005.1538091980551','1005.153809198055114','test','test','0.0'),('2018-07-16 19:59:59','2018-07-16 23:59:59','LINKBTC','4h','0.000033330000000','0.000032996700000','0.035083218453710','0.034732386269173','1052.601813792666','1052.601813792666007','test','test','0.99'),('2018-07-17 19:59:59','2018-07-18 15:59:59','LINKBTC','4h','0.000034020000000','0.000033679800000','0.035005255746035','0.034655203188575','1028.9610742514599','1028.961074251459877','test','test','1.00'),('2018-07-25 19:59:59','2018-07-25 23:59:59','LINKBTC','4h','0.000030390000000','0.000030086100000','0.034927466288821','0.034578191625933','1149.3078739329167','1149.307873932916664','test','test','0.99'),('2018-07-26 03:59:59','2018-08-04 15:59:59','LINKBTC','4h','0.000030960000000','0.000036110000000','0.034849849697068','0.040646901568512','1125.64114008619','1125.641140086190035','test','test','0.0'),('2018-08-08 15:59:59','2018-08-08 19:59:59','LINKBTC','4h','0.000035950000000','0.000035650000000','0.036138083446278','0.035836513904306','1005.2318065724123','1005.231806572412324','test','test','0.83'),('2018-08-09 03:59:59','2018-08-11 15:59:59','LINKBTC','4h','0.000038880000000','0.000042130000000','0.036071067992507','0.039086267863280','927.7538063916323','927.753806391632338','test','test','0.0'),('2018-08-14 07:59:59','2018-08-14 11:59:59','LINKBTC','4h','0.000040900000000','0.000040491000000','0.036741112408234','0.036373701284152','898.3157068027874','898.315706802787417','test','test','1.00'),('2018-08-14 15:59:59','2018-08-14 19:59:59','LINKBTC','4h','0.000041160000000','0.000041850000000','0.036659465491771','0.037274019213572','890.6575678272919','890.657567827291928','test','test','0.0'),('2018-08-16 19:59:59','2018-08-17 11:59:59','LINKBTC','4h','0.000042830000000','0.000042401700000','0.036796032985505','0.036428072655650','859.1182111955379','859.118211195537924','test','test','0.99'),('2018-08-17 19:59:59','2018-08-18 07:59:59','LINKBTC','4h','0.000044430000000','0.000043985700000','0.036714264023315','0.036347121383082','826.3395008623653','826.339500862365298','test','test','0.99'),('2018-08-19 15:59:59','2018-08-25 23:59:59','LINKBTC','4h','0.000045760000000','0.000047000000000','0.036632676769930','0.037625345458626','800.5392650771366','800.539265077136633','test','test','0.24'),('2018-08-28 11:59:59','2018-08-28 15:59:59','LINKBTC','4h','0.000047750000000','0.000047272500000','0.036853269811862','0.036484737113743','771.796226426434','771.796226426434032','test','test','1.00'),('2018-08-28 23:59:59','2018-08-29 07:59:59','LINKBTC','4h','0.000047340000000','0.000046866600000','0.036771373656725','0.036403659920158','776.7506053385016','776.750605338501600','test','test','1.00'),('2018-09-02 03:59:59','2018-09-02 07:59:59','LINKBTC','4h','0.000046500000000','0.000046035000000','0.036689659493043','0.036322762898113','789.0249353342605','789.024935334260476','test','test','1.00'),('2018-09-12 03:59:59','2018-09-12 07:59:59','LINKBTC','4h','0.000041910000000','0.000041490900000','0.036608126916392','0.036242045647228','873.4938419563829','873.493841956382880','test','test','0.99'),('2018-09-15 03:59:59','2018-09-15 07:59:59','LINKBTC','4h','0.000041690000000','0.000041360000000','0.036526775523244','0.036237645373983','876.1519674560913','876.151967456091256','test','test','0.79'),('2018-09-16 11:59:59','2018-09-28 19:59:59','LINKBTC','4h','0.000042300000000','0.000050370000000','0.036462524378964','0.043418849951972','861.9982122686578','861.998212268657767','test','test','0.14'),('2018-10-05 15:59:59','2018-10-06 19:59:59','LINKBTC','4h','0.000052120000000','0.000051598800000','0.038008374506299','0.037628290761236','729.2474003510999','729.247400351099941','test','test','0.99'),('2018-10-09 15:59:59','2018-10-11 03:59:59','LINKBTC','4h','0.000051030000000','0.000051180000000','0.037923911451841','0.038035386794145','743.1689486937271','743.168948693727089','test','test','0.0'),('2018-10-14 15:59:59','2018-10-15 07:59:59','LINKBTC','4h','0.000051920000000','0.000051400800000','0.037948683750131','0.037569196912630','730.906851890036','730.906851890036023','test','test','1.00'),('2018-10-15 15:59:59','2018-10-15 19:59:59','LINKBTC','4h','0.000051370000000','0.000050856300000','0.037864353341797','0.037485709808379','737.0907794782385','737.090779478238460','test','test','1.00'),('2018-10-16 11:59:59','2018-10-29 15:59:59','LINKBTC','4h','0.000053810000000','0.000064690000000','0.037780210334371','0.045419100660295','702.1038902503417','702.103890250341692','test','test','0.0'),('2018-10-29 19:59:59','2018-11-06 03:59:59','LINKBTC','4h','0.000065990000000','0.000074100000000','0.039477741517910','0.044329453651722','598.2382409139196','598.238240913919640','test','test','0.0'),('2018-11-08 07:59:59','2018-11-08 11:59:59','LINKBTC','4h','0.000079020000000','0.000078229800000','0.040555899769868','0.040150340772169','513.2358867358615','513.235886735861527','test','test','0.99'),('2018-11-08 15:59:59','2018-11-08 23:59:59','LINKBTC','4h','0.000078990000000','0.000078200100000','0.040465775548157','0.040061117792675','512.2898537556259','512.289853755625927','test','test','1.00'),('2018-11-10 03:59:59','2018-11-17 07:59:59','LINKBTC','4h','0.000079760000000','0.000087820000000','0.040375851602494','0.044455958973558','506.21679541743003','506.216795417430035','test','test','0.66'),('2018-11-18 19:59:59','2018-11-19 03:59:59','LINKBTC','4h','0.000092780000000','0.000091852200000','0.041282542129397','0.040869716708103','444.9508744276497','444.950874427649694','test','test','1.00'),('2018-11-27 11:59:59','2018-11-27 15:59:59','LINKBTC','4h','0.000080690000000','0.000079883100000','0.041190803146888','0.040778895115419','510.48213095659383','510.482130956593835','test','test','1.00'),('2018-11-28 07:59:59','2018-11-28 11:59:59','LINKBTC','4h','0.000078660000000','0.000080750000000','0.041099268028783','0.042191277565780','522.4926014338081','522.492601433808090','test','test','0.0'),('2018-11-29 15:59:59','2018-11-29 23:59:59','LINKBTC','4h','0.000086030000000','0.000085169700000','0.041341936814783','0.040928517446635','480.552560906459','480.552560906459007','test','test','0.99'),('2018-11-30 03:59:59','2018-11-30 07:59:59','LINKBTC','4h','0.000087630000000','0.000086753700000','0.041250065844083','0.040837565185642','470.7299537154297','470.729953715429701','test','test','1.00'),('2018-12-01 15:59:59','2018-12-01 19:59:59','LINKBTC','4h','0.000081080000000','0.000080269200000','0.041158399031096','0.040746815040785','507.62702307716114','507.627023077161141','test','test','1.00'),('2018-12-18 03:59:59','2018-12-18 11:59:59','LINKBTC','4h','0.000066590000000','0.000068670000000','0.041066935922138','0.042349699501024','616.7132590800153','616.713259080015291','test','test','0.64'),('2018-12-18 15:59:59','2018-12-24 23:59:59','LINKBTC','4h','0.000069490000000','0.000075670000000','0.041351994495224','0.045029578694109','595.0783493340624','595.078349334062409','test','test','0.0'),('2018-12-25 03:59:59','2018-12-27 19:59:59','LINKBTC','4h','0.000076070000000','0.000075780000000','0.042169235428310','0.042008474572858','554.3477774196077','554.347777419607723','test','test','0.38'),('2018-12-29 15:59:59','2018-12-30 19:59:59','LINKBTC','4h','0.000078610000000','0.000077823900000','0.042133510793765','0.041712175685827','535.9815646071069','535.981564607106861','test','test','0.99'),('2019-01-02 15:59:59','2019-01-08 07:59:59','LINKBTC','4h','0.000079280000000','0.000092190000000','0.042039880769778','0.048885678710467','530.2709481556312','530.270948155631231','test','test','0.0'),('2019-01-08 15:59:59','2019-01-10 11:59:59','LINKBTC','4h','0.000095890000000','0.000094931100000','0.043561169201043','0.043125557509033','454.28271145106544','454.282711451065438','test','test','0.99'),('2019-01-10 19:59:59','2019-01-10 23:59:59','LINKBTC','4h','0.000099400000000','0.000098406000000','0.043464366602818','0.043029722936790','437.2672696460586','437.267269646058594','test','test','0.99'),('2019-01-11 15:59:59','2019-01-25 15:59:59','LINKBTC','4h','0.000109220000000','0.000137160000000','0.043367779121479','0.054461862152555','397.06811134845873','397.068111348458729','test','test','0.0'),('2019-01-29 19:59:59','2019-01-29 23:59:59','LINKBTC','4h','0.000132130000000','0.000132130000000','0.045833130906162','0.045833130906162','346.87906536110063','346.879065361100629','test','test','0.0'),('2019-02-05 23:59:59','2019-02-06 03:59:59','LINKBTC','4h','0.000121660000000','0.000120443400000','0.045833130906162','0.045374799597100','376.73130779354125','376.731307793541248','test','test','0.99'),('2019-02-08 03:59:59','2019-02-08 19:59:59','LINKBTC','4h','0.000121800000000','0.000121000000000','0.045731279504148','0.045430909852232','375.46206489448645','375.462064894486446','test','test','0.65'),('2019-02-09 15:59:59','2019-02-09 19:59:59','LINKBTC','4h','0.000131900000000','0.000130581000000','0.045664530692612','0.045207885385686','346.20569137688824','346.205691376888240','test','test','1.00'),('2019-02-10 07:59:59','2019-02-10 19:59:59','LINKBTC','4h','0.000127920000000','0.000126640800000','0.045563053957739','0.045107423418162','356.18397402860467','356.183974028604666','test','test','1.00'),('2019-02-13 23:59:59','2019-02-14 03:59:59','LINKBTC','4h','0.000122500000000','0.000121275000000','0.045461802726722','0.045007184699455','371.1167569528327','371.116756952832702','test','test','1.00'),('2019-02-15 23:59:59','2019-02-16 07:59:59','LINKBTC','4h','0.000120720000000','0.000120500000000','0.045360776498440','0.045278111067445','375.75195906594143','375.751959065941435','test','test','0.36'),('2019-02-17 11:59:59','2019-02-17 15:59:59','LINKBTC','4h','0.000123660000000','0.000122423400000','0.045342406402664','0.044888982338637','366.66995311874325','366.669953118743251','test','test','1.00'),('2019-02-17 19:59:59','2019-02-18 03:59:59','LINKBTC','4h','0.000124140000000','0.000122898600000','0.045241645499547','0.044789229044552','364.44051473776926','364.440514737769263','test','test','0.99'),('2019-02-18 07:59:59','2019-02-18 11:59:59','LINKBTC','4h','0.000126440000000','0.000125175600000','0.045141108509548','0.044689697424453','357.01604325804954','357.016043258049535','test','test','1.00'),('2019-02-18 15:59:59','2019-02-18 19:59:59','LINKBTC','4h','0.000124740000000','0.000123492600000','0.045040794935082','0.044590386985731','361.07740047364297','361.077400473642967','test','test','1.00'),('2019-02-19 03:59:59','2019-02-19 07:59:59','LINKBTC','4h','0.000121830000000','0.000120611700000','0.044940704279671','0.044491297236874','368.8804422529007','368.880442252900707','test','test','0.99'),('2019-02-25 15:59:59','2019-02-25 19:59:59','LINKBTC','4h','0.000120100000000','0.000118899000000','0.044840836047938','0.044392427687459','373.36249831755396','373.362498317553957','test','test','1.00'),('2019-02-25 23:59:59','2019-02-26 03:59:59','LINKBTC','4h','0.000123280000000','0.000122047200000','0.044741189745610','0.044293777848154','362.92334316685236','362.923343166852362','test','test','1.00'),('2019-03-07 15:59:59','2019-03-07 19:59:59','LINKBTC','4h','0.000112460000000','0.000120200000000','0.044641764879508','0.047714210728409','396.9568280233703','396.956828023370292','test','test','0.0'),('2019-03-08 03:59:59','2019-03-08 07:59:59','LINKBTC','4h','0.000125860000000','0.000124601400000','0.045324530623708','0.044871285317471','360.1186288233629','360.118628823362883','test','test','1.00'),('2019-03-10 11:59:59','2019-03-11 11:59:59','LINKBTC','4h','0.000125340000000','0.000124086600000','0.045223809444545','0.044771571350100','360.80907487270366','360.809074872703661','test','test','0.99'),('2019-03-11 15:59:59','2019-03-11 19:59:59','LINKBTC','4h','0.000126530000000','0.000125264700000','0.045123312090224','0.044672078969322','356.621450171687','356.621450171687002','test','test','0.99'),('2019-03-12 01:59:59','2019-03-15 19:59:59','LINKBTC','4h','0.000120940000000','0.000124770000000','0.045023038063356','0.046448854466388','372.2758232458777','372.275823245877689','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 19:14:38
