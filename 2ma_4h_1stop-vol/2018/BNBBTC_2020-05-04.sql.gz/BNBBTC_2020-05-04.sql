-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-01-02 03:59:59','2018-01-02 19:59:59','BNBBTC','4h','0.000627680000000','0.000621403200000','0.033333333333333','0.033000000000000','53.10561644999575','53.105616449995750','test','test','0.99'),('2018-01-03 19:59:59','2018-01-16 03:59:59','BNBBTC','4h','0.000597920000000','0.001372900000000','0.033259259259259','0.076367468954102','55.62493186255575','55.624931862555748','test','test','0.0'),('2018-01-19 03:59:59','2018-01-19 07:59:59','BNBBTC','4h','0.001314500000000','0.001301355000000','0.042838861413669','0.042410472799532','32.58947235729851','32.589472357298511','test','test','0.99'),('2018-01-20 19:59:59','2018-01-20 23:59:59','BNBBTC','4h','0.001278900000000','0.001266600000000','0.042743663943861','0.042332570764950','33.42220966757422','33.422209667574222','test','test','0.96'),('2018-02-07 11:59:59','2018-02-07 15:59:59','BNBBTC','4h','0.001086800000000','0.001075932000000','0.042652309904103','0.042225786805062','39.24577650359097','39.245776503590967','test','test','1.00'),('2018-02-09 15:59:59','2018-02-10 07:59:59','BNBBTC','4h','0.001144200000000','0.001132758000000','0.042557526993205','0.042131951723273','37.19413301276409','37.194133012764091','test','test','0.99'),('2018-02-11 15:59:59','2018-02-11 19:59:59','BNBBTC','4h','0.001097400000000','0.001086426000000','0.042462954710998','0.042038325163888','38.69414498906284','38.694144989062842','test','test','0.99'),('2018-02-14 23:59:59','2018-02-15 19:59:59','BNBBTC','4h','0.001101000000000','0.001089990000000','0.042368592589418','0.041944906663524','38.48191879147825','38.481918791478250','test','test','1.00'),('2018-02-16 15:59:59','2018-02-16 19:59:59','BNBBTC','4h','0.001084000000000','0.001080800000000','0.042274440161441','0.042149644766130','38.99856103453977','38.998561034539769','test','test','0.29'),('2018-02-16 23:59:59','2018-02-17 11:59:59','BNBBTC','4h','0.001103900000000','0.001092861000000','0.042246707851372','0.041824240772858','38.27041204037684','38.270412040376840','test','test','1.00'),('2018-02-26 07:59:59','2018-02-26 11:59:59','BNBBTC','4h','0.000978300000000','0.000968517000000','0.042152826278369','0.041731298015585','43.087832237932005','43.087832237932005','test','test','0.99'),('2018-02-27 07:59:59','2018-02-27 15:59:59','BNBBTC','4h','0.001012800000000','0.001002672000000','0.042059153331084','0.041638561797773','41.527600050437954','41.527600050437954','test','test','1.00'),('2018-02-28 03:59:59','2018-02-28 11:59:59','BNBBTC','4h','0.001008600000000','0.000998514000000','0.041965688545903','0.041546031660444','41.60786094180382','41.607860941803821','test','test','1.00'),('2018-02-28 15:59:59','2018-02-28 19:59:59','BNBBTC','4h','0.001008900000000','0.000998811000000','0.041872431460246','0.041453707145644','41.503054277178876','41.503054277178876','test','test','1.00'),('2018-02-28 23:59:59','2018-03-01 07:59:59','BNBBTC','4h','0.001012700000000','0.001002573000000','0.041779381612556','0.041361587796430','41.255437555600324','41.255437555600324','test','test','0.99'),('2018-03-13 15:59:59','2018-03-19 11:59:59','BNBBTC','4h','0.001063000000000','0.001052370000000','0.041686538542306','0.041269673156883','39.215934658801714','39.215934658801714','test','test','0.99'),('2018-03-20 03:59:59','2018-03-20 07:59:59','BNBBTC','4h','0.001051500000000','0.001040985000000','0.041593901789990','0.041177962772090','39.55673018543985','39.556730185439847','test','test','1.00'),('2018-03-21 11:59:59','2018-04-12 11:59:59','BNBBTC','4h','0.001099000000000','0.001626100000000','0.041501470897123','0.061406316493004','37.762939851795565','37.762939851795565','test','test','0.98'),('2018-04-14 03:59:59','2018-04-14 07:59:59','BNBBTC','4h','0.001711700000000','0.001694583000000','0.045924769918430','0.045465522219246','26.829917578097923','26.829917578097923','test','test','1.00'),('2018-04-24 15:59:59','2018-04-24 23:59:59','BNBBTC','4h','0.001592200000000','0.001576278000000','0.045822714874167','0.045364487725425','28.77949684346634','28.779496843466340','test','test','1.00'),('2018-04-26 07:59:59','2018-04-26 11:59:59','BNBBTC','4h','0.001613700000000','0.001597563000000','0.045720886618891','0.045263677752702','28.33295322481942','28.332953224819420','test','test','1.00'),('2018-04-28 03:59:59','2018-04-29 11:59:59','BNBBTC','4h','0.001627200000000','0.001610928000000','0.045619284648627','0.045163091802141','28.035450251122715','28.035450251122715','test','test','1.00'),('2018-05-09 15:59:59','2018-05-11 07:59:59','BNBBTC','4h','0.001513800000000','0.001506700000000','0.045517908460519','0.045304421110757','30.068640811546356','30.068640811546356','test','test','0.46'),('2018-05-13 11:59:59','2018-05-13 19:59:59','BNBBTC','4h','0.001537800000000','0.001522422000000','0.045470466827238','0.045015762158966','29.56851790040216','29.568517900402160','test','test','0.99'),('2018-05-17 15:59:59','2018-05-17 19:59:59','BNBBTC','4h','0.001509500000000','0.001546200000000','0.045369421345400','0.046472473855089','30.05592669453476','30.055926694534762','test','test','0.0'),('2018-05-17 23:59:59','2018-05-23 11:59:59','BNBBTC','4h','0.001536700000000','0.001651800000000','0.045614544125331','0.049031108209945','29.683441221664026','29.683441221664026','test','test','0.0'),('2018-05-29 23:59:59','2018-05-30 03:59:59','BNBBTC','4h','0.001688800000000','0.001671912000000','0.046373780588579','0.045910042782693','27.459604801384806','27.459604801384806','test','test','1.00'),('2018-05-30 11:59:59','2018-05-30 15:59:59','BNBBTC','4h','0.001686000000000','0.001678700000000','0.046270727742826','0.046070385920452','27.4440852567178','27.444085256717798','test','test','0.43'),('2018-05-30 23:59:59','2018-06-20 15:59:59','BNBBTC','4h','0.001705000000000','0.002362600000000','0.046226207337854','0.064055153933381','27.112145066190156','27.112145066190156','test','test','0.0'),('2018-06-21 15:59:59','2018-06-24 03:59:59','BNBBTC','4h','0.002474300000000','0.002449557000000','0.050188195470194','0.049686313515492','20.28379560691652','20.283795606916520','test','test','0.99'),('2018-06-28 23:59:59','2018-06-29 03:59:59','BNBBTC','4h','0.002419900000000','0.002416800000000','0.050076666146926','0.050012515700604','20.693692362050676','20.693692362050676','test','test','0.12'),('2018-06-29 19:59:59','2018-06-29 23:59:59','BNBBTC','4h','0.002394300000000','0.002370357000000','0.050062410492188','0.049561786387266','20.908996571936775','20.908996571936775','test','test','1.00'),('2018-07-28 07:59:59','2018-07-29 11:59:59','BNBBTC','4h','0.001755300000000','0.001737747000000','0.049951160691094','0.049451649084183','28.457335322220956','28.457335322220956','test','test','1.00'),('2018-07-31 15:59:59','2018-07-31 19:59:59','BNBBTC','4h','0.001775000000000','0.001757250000000','0.049840158111781','0.049341756530663','28.078962316496273','28.078962316496273','test','test','0.99'),('2018-07-31 23:59:59','2018-08-02 07:59:59','BNBBTC','4h','0.001789800000000','0.001771902000000','0.049729402204866','0.049232108182817','27.78489339862877','27.784893398628771','test','test','0.99'),('2018-08-02 11:59:59','2018-08-11 15:59:59','BNBBTC','4h','0.001795000000000','0.001899000000000','0.049618892422188','0.052493747470604','27.642837004004583','27.642837004004583','test','test','0.41'),('2018-08-27 11:59:59','2018-08-28 19:59:59','BNBBTC','4h','0.001588900000000','0.001613800000000','0.050257749099614','0.051045349296342','31.630529989057838','31.630529989057838','test','test','0.81'),('2018-08-28 23:59:59','2018-08-29 03:59:59','BNBBTC','4h','0.001626300000000','0.001610037000000','0.050432771365554','0.049928443651898','31.01074301515929','31.010743015159289','test','test','1.00'),('2018-09-01 03:59:59','2018-09-02 03:59:59','BNBBTC','4h','0.001600800000000','0.001584792000000','0.050320698540297','0.049817491554894','31.43471922807138','31.434719228071380','test','test','1.00'),('2018-09-06 23:59:59','2018-09-07 07:59:59','BNBBTC','4h','0.001578800000000','0.001563012000000','0.050208874765763','0.049706786018105','31.801922197721478','31.801922197721478','test','test','1.00'),('2018-09-15 03:59:59','2018-09-15 15:59:59','BNBBTC','4h','0.001559000000000','0.001543410000000','0.050097299488505','0.049596326493620','32.13425239801497','32.134252398014972','test','test','1.00'),('2018-09-15 23:59:59','2018-09-16 03:59:59','BNBBTC','4h','0.001552100000000','0.001536579000000','0.049985972156309','0.049486112434746','32.20538119728669','32.205381197286691','test','test','1.00'),('2018-09-16 23:59:59','2018-09-17 15:59:59','BNBBTC','4h','0.001528700000000','0.001513413000000','0.049874892218184','0.049376143296002','32.625689944517276','32.625689944517276','test','test','1.00'),('2018-09-20 19:59:59','2018-09-20 23:59:59','BNBBTC','4h','0.001517400000000','0.001546200000000','0.049764059124365','0.050708572702052','32.79561033634199','32.795610336341987','test','test','0.0'),('2018-09-21 07:59:59','2018-09-21 11:59:59','BNBBTC','4h','0.001537800000000','0.001528100000000','0.049973951030518','0.049658729724109','32.497041897852775','32.497041897852775','test','test','0.63'),('2018-09-23 11:59:59','2018-09-23 15:59:59','BNBBTC','4h','0.001534500000000','0.001523500000000','0.049903901851316','0.049546167787866','32.52127849548126','32.521278495481262','test','test','0.71'),('2018-09-24 03:59:59','2018-09-24 07:59:59','BNBBTC','4h','0.001535100000000','0.001519749000000','0.049824405392772','0.049326161338844','32.456781573038604','32.456781573038604','test','test','1.00'),('2018-09-29 19:59:59','2018-09-30 03:59:59','BNBBTC','4h','0.001518400000000','0.001505900000000','0.049713684491899','0.049304424049230','32.740835413526526','32.740835413526526','test','test','0.82'),('2018-10-02 19:59:59','2018-10-09 15:59:59','BNBBTC','4h','0.001527500000000','0.001557100000000','0.049622737726861','0.050584330549588','32.48624401103837','32.486244011038373','test','test','0.0'),('2018-10-10 15:59:59','2018-10-10 19:59:59','BNBBTC','4h','0.001568800000000','0.001566300000000','0.049836425020800','0.049757006954410','31.76722655583914','31.767226555839141','test','test','0.15'),('2018-10-15 23:59:59','2018-10-16 03:59:59','BNBBTC','4h','0.001563900000000','0.001548261000000','0.049818776561603','0.049320588795987','31.855474494278834','31.855474494278834','test','test','1.00'),('2018-11-01 23:59:59','2018-11-02 03:59:59','BNBBTC','4h','0.001499400000000','0.001507100000000','0.049708068169244','0.049963338360589','33.15197290198984','33.151972901989843','test','test','0.0'),('2018-11-02 23:59:59','2018-11-03 03:59:59','BNBBTC','4h','0.001501600000000','0.001494800000000','0.049764794878431','0.049539434859003','33.141179327671374','33.141179327671374','test','test','0.45'),('2018-11-03 23:59:59','2018-11-04 03:59:59','BNBBTC','4h','0.001501900000000','0.001497600000000','0.049714714874114','0.049572379649426','33.10121504368733','33.101215043687333','test','test','0.28'),('2018-11-04 11:59:59','2018-11-04 15:59:59','BNBBTC','4h','0.001503300000000','0.001497100000000','0.049683084824183','0.049478178866683','33.049347983891','33.049347983891003','test','test','0.41'),('2018-11-04 19:59:59','2018-11-05 19:59:59','BNBBTC','4h','0.001515800000000','0.001504800000000','0.049637550166961','0.049277335724530','32.746767493707026','32.746767493707026','test','test','0.97'),('2018-11-05 23:59:59','2018-11-06 03:59:59','BNBBTC','4h','0.001507900000000','0.001503300000000','0.049557502513088','0.049406322387377','32.86524471986707','32.865244719867071','test','test','0.30'),('2018-11-06 07:59:59','2018-11-06 19:59:59','BNBBTC','4h','0.001506600000000','0.001501600000000','0.049523906929596','0.049359550408523','32.871304214520265','32.871304214520265','test','test','0.33'),('2018-11-07 03:59:59','2018-11-07 07:59:59','BNBBTC','4h','0.001510900000000','0.001502100000000','0.049487383258247','0.049199151758695','32.753579494504386','32.753579494504386','test','test','0.58'),('2018-11-08 15:59:59','2018-11-08 19:59:59','BNBBTC','4h','0.001507000000000','0.001500800000000','0.049423331813902','0.049219997602060','32.79584061970921','32.795840619709210','test','test','0.41'),('2018-12-03 15:59:59','2018-12-06 19:59:59','BNBBTC','4h','0.001294800000000','0.001389200000000','0.049378146433492','0.052978159580945','38.13573249420177','38.135732494201768','test','test','0.0'),('2018-12-11 15:59:59','2018-12-11 19:59:59','BNBBTC','4h','0.001362400000000','0.001393000000000','0.050178149355149','0.051305168857694','36.83070269755481','36.830702697554813','test','test','0.0'),('2018-12-11 23:59:59','2018-12-12 03:59:59','BNBBTC','4h','0.001449500000000','0.001435005000000','0.050428598133492','0.049924312152157','34.790340209377035','34.790340209377035','test','test','1.00'),('2018-12-12 11:59:59','2018-12-12 19:59:59','BNBBTC','4h','0.001450100000000','0.001435599000000','0.050316534582084','0.049813369236263','34.69866532107043','34.698665321070429','test','test','1.00'),('2018-12-14 15:59:59','2018-12-14 19:59:59','BNBBTC','4h','0.001421800000000','0.001407582000000','0.050204720060791','0.049702672860183','35.310676649873876','35.310676649873876','test','test','1.00'),('2018-12-15 11:59:59','2018-12-20 19:59:59','BNBBTC','4h','0.001420400000000','0.001406196000000','0.050093154016211','0.049592222476049','35.26693467770425','35.266934677704249','test','test','1.00'),('2018-12-21 23:59:59','2018-12-22 03:59:59','BNBBTC','4h','0.001427600000000','0.001428100000000','0.049981835896175','0.049999341442510','35.011092670338414','35.011092670338414','test','test','0.0'),('2018-12-22 11:59:59','2018-12-25 03:59:59','BNBBTC','4h','0.001438900000000','0.001445500000000','0.049985726017583','0.050215002403514','34.73884635317458','34.738846353174580','test','test','0.0'),('2018-12-26 19:59:59','2018-12-27 07:59:59','BNBBTC','4h','0.001473200000000','0.001461700000000','0.050036676325568','0.049646083210075','33.96461873850636','33.964618738506360','test','test','0.78'),('2018-12-28 11:59:59','2019-01-02 19:59:59','BNBBTC','4h','0.001489000000000','0.001559500000000','0.049949877855458','0.052314865356338','33.54592199829282','33.545921998292819','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 18:55:24
