-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-19 23:59:59','2018-04-23 03:59:59','XRPETH','4h','0.001379080000000','0.001365289200000','1.297777777777778','1.284800000000000','941.0460435781664','941.046043578166405','test','test','0.99'),('2018-04-24 03:59:59','2018-04-24 07:59:59','XRPETH','4h','0.001358430000000','0.001344845700000','1.294893827160494','1.281944888888889','953.2282319740389','953.228231974038863','test','test','0.99'),('2018-05-23 19:59:59','2018-05-24 03:59:59','XRPETH','4h','0.001027800000000','0.001017522000000','1.292016285322359','1.279096122469135','1257.0697463731847','1257.069746373184671','test','test','1.00'),('2018-05-24 07:59:59','2018-05-25 19:59:59','XRPETH','4h','0.001022000000000','0.001034590000000','1.289145138021643','1.305026094271831','1261.3944599037602','1261.394459903760207','test','test','0.55'),('2018-05-27 15:59:59','2018-06-10 11:59:59','XRPETH','4h','0.001058700000000','0.001095710000000','1.292674239410574','1.337863503225238','1221.0014540574039','1221.001454057403862','test','test','0.37'),('2018-06-10 19:59:59','2018-06-10 23:59:59','XRPETH','4h','0.001101010000000','0.001109660000000','1.302716298036054','1.312950987982568','1183.2011498860634','1183.201149886063376','test','test','0.0'),('2018-06-11 19:59:59','2018-06-12 15:59:59','XRPETH','4h','0.001111530000000','0.001100414700000','1.304990673579724','1.291940766843927','1174.0489897526152','1174.048989752615171','test','test','1.00'),('2018-06-12 19:59:59','2018-06-13 03:59:59','XRPETH','4h','0.001129000000000','0.001117710000000','1.302090694305103','1.289069787362052','1153.3132810496925','1153.313281049692478','test','test','0.99'),('2018-06-13 11:59:59','2018-06-13 19:59:59','XRPETH','4h','0.001124740000000','0.001113492600000','1.299197159428869','1.286205187834580','1155.1088779885742','1155.108877988574250','test','test','0.99'),('2018-06-14 07:59:59','2018-06-14 19:59:59','XRPETH','4h','0.001131750000000','0.001120432500000','1.296310054630138','1.283346954083837','1145.4031850056444','1145.403185005644445','test','test','1.00'),('2018-06-24 19:59:59','2018-06-24 23:59:59','XRPETH','4h','0.001052870000000','0.001042341300000','1.293429365619849','1.280495071963651','1228.4796466988792','1228.479646698879151','test','test','0.99'),('2018-06-26 15:59:59','2018-06-27 03:59:59','XRPETH','4h','0.001060580000000','0.001059700000000','1.290555078140694','1.289484259844324','1216.838973147423','1216.838973147423076','test','test','0.54'),('2018-06-28 03:59:59','2018-06-28 07:59:59','XRPETH','4h','0.001073370000000','0.001062636300000','1.290317118519279','1.277413947334086','1202.117739939889','1202.117739939888907','test','test','0.99'),('2018-06-28 23:59:59','2018-06-29 11:59:59','XRPETH','4h','0.001060350000000','0.001049746500000','1.287449747144791','1.274575249673343','1214.17432653821','1214.174326538209925','test','test','1.00'),('2018-07-03 03:59:59','2018-07-03 23:59:59','XRPETH','4h','0.001052550000000','0.001051360000000','1.284588747706691','1.283136407571048','1220.453895498258','1220.453895498257907','test','test','0.11'),('2018-07-04 15:59:59','2018-07-04 19:59:59','XRPETH','4h','0.001048610000000','0.001065490000000','1.284266005454326','1.304939478120111','1224.7317929967542','1224.731792996754166','test','test','0.0'),('2018-07-10 19:59:59','2018-07-10 23:59:59','XRPETH','4h','0.001023610000000','0.001023710000000','1.288860110491167','1.288986023691555','1259.1320038795707','1259.132003879570675','test','test','0.0'),('2018-07-17 15:59:59','2018-07-17 19:59:59','XRPETH','4h','0.001014080000000','0.001013990000000','1.288888091202365','1.288773701875874','1270.9925165690722','1270.992516569072222','test','test','0.00'),('2018-07-17 23:59:59','2018-07-18 19:59:59','XRPETH','4h','0.001016060000000','0.001015460000000','1.288862671352033','1.288101576925708','1268.490710540749','1268.490710540748978','test','test','0.05'),('2018-07-19 15:59:59','2018-07-19 23:59:59','XRPETH','4h','0.001028700000000','0.001018880000000','1.288693539257294','1.276391633399895','1252.7399040121459','1252.739904012145871','test','test','0.95'),('2018-07-31 11:59:59','2018-08-06 23:59:59','XRPETH','4h','0.000999000000000','0.001017910000000','1.285959782400095','1.310301623726607','1287.2470294295242','1287.247029429524218','test','test','0.0'),('2018-08-14 03:59:59','2018-08-14 07:59:59','XRPETH','4h','0.000987780000000','0.000977902200000','1.291369080472653','1.278455389667926','1307.3448343483901','1307.344834348390123','test','test','0.99'),('2018-08-14 11:59:59','2018-08-14 23:59:59','XRPETH','4h','0.000995260000000','0.000985307400000','1.288499371404936','1.275614377690887','1294.6359457879707','1294.635945787970741','test','test','0.99'),('2018-08-15 03:59:59','2018-08-15 19:59:59','XRPETH','4h','0.000999340000000','0.000991860000000','1.285636039468480','1.276013130773517','1286.4851196474478','1286.485119647447846','test','test','0.74'),('2018-08-17 11:59:59','2018-08-31 15:59:59','XRPETH','4h','0.001052000000000','0.001186000000000','1.283497615314044','1.446984954146821','1220.0547674087873','1220.054767408787256','test','test','0.0'),('2018-08-31 19:59:59','2018-09-01 15:59:59','XRPETH','4h','0.001190000000000','0.001178100000000','1.319828135054661','1.306629853704114','1109.0992731551773','1109.099273155177343','test','test','1.00'),('2018-09-04 07:59:59','2018-09-04 11:59:59','XRPETH','4h','0.001169050000000','0.001168980000000','1.316895183643429','1.316816331017062','1126.4660909656805','1126.466090965680451','test','test','0.00'),('2018-09-05 11:59:59','2018-09-05 19:59:59','XRPETH','4h','0.001172280000000','0.001186520000000','1.316877660837569','1.332874127458451','1123.3473750619046','1123.347375061904586','test','test','0.22'),('2018-09-05 23:59:59','2018-09-13 23:59:59','XRPETH','4h','0.001222490000000','0.001321790000000','1.320432431197765','1.427688065532556','1080.1171634923521','1080.117163492352120','test','test','0.0'),('2018-09-17 19:59:59','2018-10-02 23:59:59','XRPETH','4h','0.001370000000000','0.002294530000000','1.344267016605497','2.251431385118110','981.2168004419685','981.216800441968530','test','test','0.0'),('2018-10-03 03:59:59','2018-10-05 11:59:59','XRPETH','4h','0.002368040000000','0.002344359600000','1.545859098497188','1.530400507512216','652.8010922523218','652.801092252321837','test','test','1.00'),('2018-10-16 07:59:59','2018-10-22 15:59:59','XRPETH','4h','0.002197600000000','0.002233800000000','1.542423856056083','1.567831456888459','701.8674263087383','701.867426308738345','test','test','0.46'),('2018-10-22 19:59:59','2018-10-23 11:59:59','XRPETH','4h','0.002233680000000','0.002211343200000','1.548069989574389','1.532589289678645','693.0580878077385','693.058087807738502','test','test','0.99'),('2018-10-23 23:59:59','2018-10-27 03:59:59','XRPETH','4h','0.002282400000000','0.002259576000000','1.544629834042002','1.529183535701582','676.756849825623','676.756849825623021','test','test','0.99'),('2018-10-29 15:59:59','2018-10-29 19:59:59','XRPETH','4h','0.002256860000000','0.002252630000000','1.541197323299686','1.538308679485910','682.8945186230809','682.894518623080899','test','test','0.18'),('2018-10-29 23:59:59','2018-10-31 15:59:59','XRPETH','4h','0.002263810000000','0.002286340000000','1.540555402452180','1.555887392865354','680.5144435496708','680.514443549670773','test','test','0.06'),('2018-10-31 19:59:59','2018-11-04 07:59:59','XRPETH','4h','0.002287640000000','0.002264763600000','1.543962511432886','1.528522886318557','674.9149828788121','674.914982878812111','test','test','0.99'),('2018-11-05 15:59:59','2018-11-08 19:59:59','XRPETH','4h','0.002333720000000','0.002361690000000','1.540531483629701','1.558994994932309','660.118387651347','660.118387651347007','test','test','0.0'),('2018-11-12 15:59:59','2018-11-13 19:59:59','XRPETH','4h','0.002478500000000','0.002453715000000','1.544634486141392','1.529188141279978','623.2134299541627','623.213429954162734','test','test','0.99'),('2018-11-13 23:59:59','2018-11-14 19:59:59','XRPETH','4h','0.002468760000000','0.002506570000000','1.541201965061078','1.564806060355460','624.2818115414532','624.281811541453180','test','test','0.0'),('2018-11-14 23:59:59','2018-11-29 15:59:59','XRPETH','4h','0.002586730000000','0.003208670000000','1.546447319570941','1.918267125246041','597.8387073915486','597.838707391548610','test','test','0.98'),('2018-11-29 23:59:59','2018-11-30 03:59:59','XRPETH','4h','0.003235330000000','0.003202976700000','1.629073943054296','1.612783203623753','503.52636146986436','503.526361469864355','test','test','0.99'),('2018-12-03 07:59:59','2018-12-04 11:59:59','XRPETH','4h','0.003196100000000','0.003203380000000','1.625453778736398','1.629156198406997','508.57413057676473','508.574130576764730','test','test','0.47'),('2018-12-05 19:59:59','2018-12-07 19:59:59','XRPETH','4h','0.003296690000000','0.003263723100000','1.626276538663197','1.610013773276565','493.30587306152455','493.305873061524551','test','test','1.00'),('2018-12-08 03:59:59','2018-12-09 15:59:59','XRPETH','4h','0.003298690000000','0.003272750000000','1.622662590799502','1.609902414000427','491.9112104500579','491.911210450057922','test','test','0.78'),('2018-12-10 15:59:59','2018-12-16 03:59:59','XRPETH','4h','0.003332930000000','0.003361590000000','1.619826995955263','1.633755953870394','486.0069056221591','486.006905622159081','test','test','0.0'),('2018-12-17 15:59:59','2018-12-17 19:59:59','XRPETH','4h','0.003380610000000','0.003446030000000','1.622922319936403','1.654328361499978','480.0678930537397','480.067893053739681','test','test','0.0'),('2018-12-17 23:59:59','2018-12-20 15:59:59','XRPETH','4h','0.003479410000000','0.003444615900000','1.629901440283864','1.613602425881025','468.4419025880434','468.441902588043376','test','test','0.99'),('2019-01-10 07:59:59','2019-01-14 19:59:59','XRPETH','4h','0.002576340000000','0.002596400000000','1.626279437083233','1.638942038101689','631.2363418971227','631.236341897122657','test','test','0.0'),('2019-01-15 23:59:59','2019-01-16 19:59:59','XRPETH','4h','0.002702650000000','0.002675623500000','1.629093348420668','1.612802414936461','602.7762930533617','602.776293053361655','test','test','1.00'),('2019-01-18 11:59:59','2019-01-19 11:59:59','XRPETH','4h','0.002681860000000','0.002655041400000','1.625473140979733','1.609218409569936','606.0991778018738','606.099177801873793','test','test','0.99'),('2019-01-20 11:59:59','2019-01-27 11:59:59','XRPETH','4h','0.002680000000000','0.002688090000000','1.621860978444222','1.626756819979899','605.1720068821725','605.172006882172468','test','test','0.00'),('2019-01-27 15:59:59','2019-01-27 23:59:59','XRPETH','4h','0.002713340000000','0.002735430000000','1.622948943229929','1.636161788710388','598.1369615418373','598.136961541837309','test','test','0.25'),('2019-01-28 03:59:59','2019-02-03 07:59:59','XRPETH','4h','0.002754280000000','0.002812130000000','1.625885131114475','1.660034692827508','590.3122163013473','590.312216301347348','test','test','0.93'),('2019-02-05 19:59:59','2019-02-05 23:59:59','XRPETH','4h','0.002815070000000','0.002793970000000','1.633473922606260','1.621230426079711','580.2604988885747','580.260498888574716','test','test','0.74'),('2019-02-06 03:59:59','2019-02-06 19:59:59','XRPETH','4h','0.002829350000000','0.002801056500000','1.630753145600360','1.614445614144356','576.3702424939863','576.370242493986325','test','test','1.00'),('2019-02-25 19:59:59','2019-02-26 03:59:59','XRPETH','4h','0.002380130000000','0.002356328700000','1.627129249721248','1.610857957224035','683.630410826824','683.630410826824004','test','test','1.00'),('2019-02-27 23:59:59','2019-02-28 03:59:59','XRPETH','4h','0.002300420000000','0.002287290000000','1.623513406944090','1.614246955151297','705.7465188722449','705.746518872244906','test','test','0.57'),('2019-03-04 03:59:59','2019-03-05 15:59:59','XRPETH','4h','0.002392200000000','0.002368278000000','1.621454195434580','1.605239653480234','677.8087933427724','677.808793342772447','test','test','1.00'),('2019-03-10 15:59:59','2019-03-10 23:59:59','XRPETH','4h','0.002319560000000','0.002310030000000','1.617850963889170','1.611203962006975','697.4818344380701','697.481834438070109','test','test','0.41'),('2019-03-11 07:59:59','2019-03-12 11:59:59','XRPETH','4h','0.002316800000000','0.002319890000000','1.616373852359793','1.618529668659772','697.6751779867893','697.675177986789322','test','test','0.0'),('2019-03-12 19:59:59','2019-03-15 07:59:59','XRPETH','4h','0.002341610000000','0.002332830000000','1.616852922648677','1.610790440569742','690.4877083069672','690.487708306967193','test','test','0.75'),('2019-04-02 03:59:59','2019-04-02 07:59:59','XRPETH','4h','0.002251270000000','0.002228757300000','1.615505704408914','1.599350647364825','717.5974913754966','717.597491375496588','test','test','0.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 19:33:05
