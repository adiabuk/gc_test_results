-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-31 07:59:59','2018-05-31 15:59:59','WABIETH','4h','0.001360300000000','0.001346697000000','1.297777777777778','1.284800000000000','954.0379164726734','954.037916472673373','test','test','1.00'),('2018-06-02 11:59:59','2018-06-02 15:59:59','WABIETH','4h','0.001382080000000','0.001368259200000','1.294893827160494','1.281944888888889','936.9166959658586','936.916695965858594','test','test','0.99'),('2018-06-02 19:59:59','2018-06-03 11:59:59','WABIETH','4h','0.001373490000000','0.001359755100000','1.292016285322359','1.279096122469136','940.6812465488348','940.681246548834793','test','test','0.99'),('2018-06-29 15:59:59','2018-06-29 23:59:59','WABIETH','4h','0.000814920000000','0.000806770800000','1.289145138021643','1.276253686641426','1581.928456807592','1581.928456807592056','test','test','1.00'),('2018-06-30 03:59:59','2018-06-30 07:59:59','WABIETH','4h','0.000872190000000','0.000863468100000','1.286280371048262','1.273417567337779','1474.7708309522714','1474.770830952271353','test','test','1.00'),('2018-07-01 23:59:59','2018-07-02 03:59:59','WABIETH','4h','0.000917490000000','0.000908315100000','1.283421970223710','1.270587750521473','1398.8402818817751','1398.840281881775127','test','test','1.00'),('2018-07-04 15:59:59','2018-07-04 23:59:59','WABIETH','4h','0.000896890000000','0.000887921100000','1.280569921400990','1.267764222186980','1427.7892733791105','1427.789273379110455','test','test','1.00'),('2018-07-05 11:59:59','2018-07-05 15:59:59','WABIETH','4h','0.000882820000000','0.000873991800000','1.277724210464544','1.264946968359899','1447.3213231061188','1447.321323106118825','test','test','0.99'),('2018-07-06 19:59:59','2018-07-07 03:59:59','WABIETH','4h','0.000905890000000','0.000896831100000','1.274884823330178','1.262135975096876','1407.3285093445984','1407.328509344598388','test','test','1.00'),('2018-07-16 11:59:59','2018-07-16 19:59:59','WABIETH','4h','0.000842230000000','0.000833807700000','1.272051745945000','1.259331228485550','1510.3377295335004','1510.337729533500351','test','test','1.00'),('2018-07-17 11:59:59','2018-07-17 15:59:59','WABIETH','4h','0.000874460000000','0.000865715400000','1.269224964287344','1.256532714644471','1451.4385612690626','1451.438561269062575','test','test','0.99'),('2018-07-17 19:59:59','2018-07-18 19:59:59','WABIETH','4h','0.000895660000000','0.000886703400000','1.266404464366706','1.253740419723039','1413.9343772935106','1413.934377293510579','test','test','1.00'),('2018-07-19 11:59:59','2018-07-20 03:59:59','WABIETH','4h','0.000877500000000','0.000868725000000','1.263590232223669','1.250954329901432','1439.9888686309616','1439.988868630961633','test','test','1.00'),('2018-08-17 15:59:59','2018-08-17 19:59:59','WABIETH','4h','0.000545810000000','0.000540351900000','1.260782253929839','1.248174431390541','2309.928828584743','2309.928828584742860','test','test','0.99'),('2018-08-18 03:59:59','2018-08-18 07:59:59','WABIETH','4h','0.000539660000000','0.000534263400000','1.257980515587772','1.245400710431894','2331.061252617893','2331.061252617892933','test','test','1.00'),('2018-08-20 15:59:59','2018-08-20 23:59:59','WABIETH','4h','0.000564280000000','0.000558637200000','1.255185003330910','1.242633153297601','2224.4010124954107','2224.401012495410669','test','test','0.99'),('2018-08-21 15:59:59','2018-08-21 19:59:59','WABIETH','4h','0.000560140000000','0.000554538600000','1.252395703323508','1.239871746290273','2235.861933308652','2235.861933308652169','test','test','0.99'),('2018-08-21 23:59:59','2018-08-22 19:59:59','WABIETH','4h','0.000559840000000','0.000554241600000','1.249612601760567','1.237116475742961','2232.088814233651','2232.088814233651192','test','test','1.00'),('2018-08-26 11:59:59','2018-09-13 19:59:59','WABIETH','4h','0.000619280000000','0.000851450000000','1.246835684867766','1.714278264889322','2013.3633976032904','2013.363397603290423','test','test','0.0'),('2018-09-15 15:59:59','2018-09-15 19:59:59','WABIETH','4h','0.000954220000000','0.000944677800000','1.350711813761445','1.337204695623830','1415.5140468250981','1415.514046825098148','test','test','1.00'),('2018-09-16 07:59:59','2018-09-16 19:59:59','WABIETH','4h','0.000989940000000','0.000980040600000','1.347710231953086','1.334233129633555','1361.4059760723744','1361.405976072374415','test','test','0.99'),('2018-09-20 15:59:59','2018-09-20 23:59:59','WABIETH','4h','0.000932570000000','0.000923244300000','1.344715320326524','1.331268167123259','1441.9457202424737','1441.945720242473726','test','test','1.00'),('2018-09-21 11:59:59','2018-09-21 15:59:59','WABIETH','4h','0.000940750000000','0.000931342500000','1.341727064059132','1.328309793418541','1426.2312666055082','1426.231266605508154','test','test','0.99'),('2018-09-23 11:59:59','2018-09-23 15:59:59','WABIETH','4h','0.000897730000000','0.000901560000000','1.338745448361222','1.344456959692272','1491.256222206256','1491.256222206256098','test','test','0.0'),('2018-09-25 03:59:59','2018-09-28 11:59:59','WABIETH','4h','0.000951300000000','0.000976880000000','1.340014673101456','1.376047023924472','1408.6141838552041','1408.614183855204146','test','test','0.27'),('2018-10-04 07:59:59','2018-10-04 11:59:59','WABIETH','4h','0.000945330000000','0.000941270000000','1.348021862173237','1.342232382562494','1425.9801996903063','1425.980199690306335','test','test','0.42'),('2018-10-04 19:59:59','2018-10-06 11:59:59','WABIETH','4h','0.000945280000000','0.000936360000000','1.346735311148628','1.334027035319830','1424.6945996409822','1424.694599640982233','test','test','0.94'),('2018-10-10 11:59:59','2018-10-11 07:59:59','WABIETH','4h','0.000970000000000','0.000960300000000','1.343911249853339','1.330472137354806','1385.4755153127207','1385.475515312720745','test','test','0.99'),('2018-10-11 23:59:59','2018-10-12 03:59:59','WABIETH','4h','0.000987380000000','0.000977506200000','1.340924780409221','1.327515532605129','1358.0635423132137','1358.063542313213702','test','test','0.99'),('2018-10-13 15:59:59','2018-10-13 19:59:59','WABIETH','4h','0.001232190000000','0.001219868100000','1.337944947563867','1.324565498088228','1085.8268185619643','1085.826818561964274','test','test','0.99'),('2018-10-13 23:59:59','2018-10-14 03:59:59','WABIETH','4h','0.001353800000000','0.001340262000000','1.334971736569281','1.321622019203588','986.0922858393267','986.092285839326678','test','test','1.00'),('2018-10-14 07:59:59','2018-10-15 23:59:59','WABIETH','4h','0.001331200000000','0.001317888000000','1.332005132710237','1.318685081383135','1000.6048172402624','1000.604817240262378','test','test','0.99'),('2018-10-20 11:59:59','2018-10-20 15:59:59','WABIETH','4h','0.001336700000000','0.001323333000000','1.329045121304215','1.315754670091173','994.2733008934055','994.273300893405462','test','test','1.00'),('2018-10-22 11:59:59','2018-10-22 15:59:59','WABIETH','4h','0.001225530000000','0.001215040000000','1.326091687701317','1.314740923702078','1082.055671996048','1082.055671996047977','test','test','0.85'),('2018-10-22 23:59:59','2018-10-26 11:59:59','WABIETH','4h','0.001256530000000','0.001266850000000','1.323569295701486','1.334439895791925','1053.352721941765','1053.352721941764912','test','test','0.10'),('2018-10-28 15:59:59','2018-10-28 19:59:59','WABIETH','4h','0.001315870000000','0.001302711300000','1.325984984610472','1.312725134764367','1007.6869178645854','1007.686917864585439','test','test','1.00'),('2018-10-28 23:59:59','2018-11-04 07:59:59','WABIETH','4h','0.001289570000000','0.001451890000000','1.323038351311338','1.489571060031963','1025.9531094173544','1025.953109417354426','test','test','0.86'),('2018-11-04 15:59:59','2018-11-04 19:59:59','WABIETH','4h','0.001494910000000','0.001479960900000','1.360045619915921','1.346445163716762','909.7842812717295','909.784281271729469','test','test','1.00'),('2018-11-07 15:59:59','2018-11-07 19:59:59','WABIETH','4h','0.001428640000000','0.001414353600000','1.357023296316108','1.343453063352947','949.8707136270214','949.870713627021360','test','test','0.99'),('2018-11-11 19:59:59','2018-11-11 23:59:59','WABIETH','4h','0.001510830000000','0.001495721700000','1.354007688990961','1.340467612101051','896.2012198533','896.201219853300017','test','test','1.00'),('2018-11-12 11:59:59','2018-11-12 15:59:59','WABIETH','4h','0.001500250000000','0.001485247500000','1.350998783015426','1.337488795185272','900.5157693820533','900.515769382053350','test','test','1.00'),('2018-11-25 11:59:59','2018-11-25 19:59:59','WABIETH','4h','0.001201740000000','0.001289150000000','1.347996563497613','1.446044710031245','1121.703998783109','1121.703998783109000','test','test','0.01'),('2018-11-25 23:59:59','2018-11-30 11:59:59','WABIETH','4h','0.001277660000000','0.001328700000000','1.369785040505087','1.424505254386229','1072.1045039408664','1072.104503940866380','test','test','0.76'),('2018-12-03 15:59:59','2018-12-06 15:59:59','WABIETH','4h','0.001353570000000','0.001380050000000','1.381945088034230','1.408980192189277','1020.9631478491914','1020.963147849191387','test','test','0.0'),('2018-12-06 23:59:59','2018-12-07 03:59:59','WABIETH','4h','0.001408350000000','0.001402200000000','1.387952888957574','1.381891959311471','985.5170156264945','985.517015626494526','test','test','0.43'),('2018-12-16 19:59:59','2018-12-16 23:59:59','WABIETH','4h','0.001411000000000','0.001396890000000','1.386606015702884','1.372739955545855','982.7115632196203','982.711563219620302','test','test','0.99'),('2018-12-17 03:59:59','2018-12-17 19:59:59','WABIETH','4h','0.001383710000000','0.001369872900000','1.383524669001322','1.369689422311309','999.8660622538844','999.866062253884365','test','test','1.00'),('2019-01-10 07:59:59','2019-01-10 11:59:59','WABIETH','4h','0.000883470000000','0.000889250000000','1.380450169736875','1.389481604851909','1562.532026822501','1562.532026822500939','test','test','0.0'),('2019-01-10 15:59:59','2019-01-10 19:59:59','WABIETH','4h','0.000901060000000','0.000893170000000','1.382457155317994','1.370351871590541','1534.256492706361','1534.256492706361087','test','test','0.87'),('2019-01-11 11:59:59','2019-01-12 03:59:59','WABIETH','4h','0.000895560000000','0.000894070000000','1.379767092267448','1.377471486202552','1540.6752113397743','1540.675211339774251','test','test','0.16'),('2019-01-12 15:59:59','2019-01-14 15:59:59','WABIETH','4h','0.000903010000000','0.000893979900000','1.379256957586360','1.365464388010496','1527.3994281196892','1527.399428119689219','test','test','0.99'),('2019-01-14 23:59:59','2019-01-15 15:59:59','WABIETH','4h','0.000910970000000','0.000901860300000','1.376191942125057','1.362430022703806','1510.6885431189362','1510.688543118936195','test','test','1.00'),('2019-01-15 23:59:59','2019-01-26 15:59:59','WABIETH','4h','0.000930000000000','0.001090140000000','1.373133737809224','1.609578508532632','1476.4878901174447','1476.487890117444749','test','test','0.69'),('2019-01-27 23:59:59','2019-01-28 03:59:59','WABIETH','4h','0.001104680000000','0.001093633200000','1.425677020192203','1.411420249990281','1290.5791905277574','1290.579190527757419','test','test','1.00'),('2019-01-30 11:59:59','2019-01-30 15:59:59','WABIETH','4h','0.001124740000000','0.001113492600000','1.422508849036221','1.408283760545859','1264.7446067857643','1264.744606785764290','test','test','0.99'),('2019-02-02 07:59:59','2019-02-02 11:59:59','WABIETH','4h','0.001106880000000','0.001095811200000','1.419347718260584','1.405154241077978','1282.2959293334277','1282.295929333427694','test','test','0.99'),('2019-02-06 03:59:59','2019-02-06 07:59:59','WABIETH','4h','0.001097280000000','0.001086307200000','1.416193612220005','1.402031676097805','1290.6401394539273','1290.640139453927304','test','test','0.99'),('2019-02-06 15:59:59','2019-02-06 19:59:59','WABIETH','4h','0.001099710000000','0.001088712900000','1.413046515303961','1.398916050150921','1284.926494533978','1284.926494533978030','test','test','1.00'),('2019-02-07 07:59:59','2019-02-08 11:59:59','WABIETH','4h','0.001097950000000','0.001086970500000','1.409906411936619','1.395807347817253','1284.126246128347','1284.126246128347020','test','test','1.00'),('2019-02-08 15:59:59','2019-02-08 19:59:59','WABIETH','4h','0.001156610000000','0.001145043900000','1.406773286576760','1.392705553710992','1216.2900948260517','1216.290094826051700','test','test','0.99'),('2019-02-08 23:59:59','2019-02-09 19:59:59','WABIETH','4h','0.001128740000000','0.001117452600000','1.403647123717700','1.389610652480523','1243.5522119511138','1243.552211951113804','test','test','0.99'),('2019-02-10 15:59:59','2019-02-10 19:59:59','WABIETH','4h','0.001186710000000','0.001174842900000','1.400527907887216','1.386522628808344','1180.1770507429924','1180.177050742992378','test','test','1.00'),('2019-02-24 23:59:59','2019-02-25 03:59:59','WABIETH','4h','0.001020000000000','0.001009800000000','1.397415623647467','1.383441467410992','1370.015317301438','1370.015317301438017','test','test','0.99'),('2019-02-26 11:59:59','2019-03-11 23:59:59','WABIETH','4h','0.001052200000000','0.001437200000000','1.394310255594917','1.904488404619858','1325.1380494154314','1325.138049415431396','test','test','0.0'),('2019-03-12 11:59:59','2019-03-21 15:59:59','WABIETH','4h','0.001504020000000','0.001668870000000','1.507683177600460','1.672934684779511','1002.4355910163824','1002.435591016382432','test','test','0.0'),('2019-03-24 11:59:59','2019-03-24 15:59:59','WABIETH','4h','0.001643980000000','0.001636520000000','1.544405734751360','1.537397579675723','939.4309752864145','939.430975286414537','test','test','0.45'),('2019-03-25 11:59:59','2019-03-25 15:59:59','WABIETH','4h','0.001647430000000','0.001630955700000','1.542848366956774','1.527419883287206','936.5183145607241','936.518314560724093','test','test','0.99'),('2019-03-27 15:59:59','2019-04-02 19:59:59','WABIETH','4h','0.001723340000000','0.002100820000000','1.539419815030203','1.876613979720630','893.2769012674243','893.276901267424250','test','test','0.77'),('2019-04-03 15:59:59','2019-04-03 19:59:59','WABIETH','4h','0.002088000000000','0.002067120000000','1.614351851628076','1.598208333111795','773.1570170632547','773.157017063254671','test','test','1.00'),('2019-04-12 15:59:59','2019-04-17 23:59:59','WABIETH','4h','0.001964150000000','0.002297230000000','1.610764403068902','1.883917373755555','820.0821745125893','820.082174512589290','test','test','0.0'),('2019-04-24 15:59:59','2019-04-24 19:59:59','WABIETH','4h','0.002275950000000','0.002274400000000','1.671465063221492','1.670326738193265','734.4032440174396','734.403244017439647','test','test','0.06'),('2019-04-25 03:59:59','2019-04-25 19:59:59','WABIETH','4h','0.002315670000000','0.002292513300000','1.671212102104108','1.654499981083067','721.697004367681','721.697004367680961','test','test','1.00'),('2019-04-28 11:59:59','2019-04-29 15:59:59','WABIETH','4h','0.002182100000000','0.002188890000000','1.667498297432766','1.672687020882456','764.1713475242957','764.171347524295697','test','test','0.0'),('2019-04-30 15:59:59','2019-04-30 19:59:59','WABIETH','4h','0.002225550000000','0.002203294500000','1.668651347088252','1.651964833617370','749.7703251278346','749.770325127834553','test','test','0.99'),('2019-05-05 11:59:59','2019-05-05 15:59:59','WABIETH','4h','0.002254760000000','0.002232212400000','1.664943232983612','1.648293800653776','738.412617300117','738.412617300116949','test','test','1.00'),('2019-05-22 23:59:59','2019-05-23 03:59:59','WABIETH','4h','0.001449850000000','0.001435351500000','1.661243359132537','1.644630925541211','1145.8036066714055','1145.803606671405532','test','test','1.00'),('2019-05-23 11:59:59','2019-05-23 15:59:59','WABIETH','4h','0.001420410000000','0.001434560000000','1.657551707223354','1.674064092138422','1166.9529975312435','1166.952997531243454','test','test','0.0'),('2019-05-24 03:59:59','2019-05-24 07:59:59','WABIETH','4h','0.001472840000000','0.001458111600000','1.661221126093369','1.644608914832435','1127.9033201796317','1127.903320179631692','test','test','1.00'),('2019-05-24 11:59:59','2019-05-24 15:59:59','WABIETH','4h','0.001432390000000','0.001418066100000','1.657529523590939','1.640954228355030','1157.1775309733655','1157.177530973365492','test','test','0.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 19:38:40
