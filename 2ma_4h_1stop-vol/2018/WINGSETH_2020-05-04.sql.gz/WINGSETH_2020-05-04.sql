-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 15:59:59','2018-07-01 19:59:59','WINGSETH','4h','0.000477900000000','0.000484900000000','1.297777777777778','1.316786868475506','2715.5843853897836','2715.584385389783620','test','test','0.0'),('2018-07-02 03:59:59','2018-07-02 11:59:59','WINGSETH','4h','0.000495600000000','0.000490644000000','1.302002020155051','1.288981999953501','2627.122720248286','2627.122720248285987','test','test','0.99'),('2018-07-02 15:59:59','2018-07-03 19:59:59','WINGSETH','4h','0.000483000000000','0.000478600000000','1.299108682332484','1.287274151893016','2689.6660089699462','2689.666008969946233','test','test','0.91'),('2018-07-04 15:59:59','2018-07-04 19:59:59','WINGSETH','4h','0.000529400000000','0.000524106000000','1.296478786679269','1.283513998812476','2448.9587961452007','2448.958796145200722','test','test','0.99'),('2018-07-09 19:59:59','2018-07-09 23:59:59','WINGSETH','4h','0.000503800000000','0.000498762000000','1.293597722708870','1.280661745481781','2567.681069291128','2567.681069291128097','test','test','0.99'),('2018-07-10 03:59:59','2018-07-10 07:59:59','WINGSETH','4h','0.000491100000000','0.000486189000000','1.290723061102851','1.277815830491823','2628.228591127776','2628.228591127775871','test','test','1.00'),('2018-07-16 19:59:59','2018-07-16 23:59:59','WINGSETH','4h','0.000461400000000','0.000456786000000','1.287854787633733','1.274976239757396','2791.189396692096','2791.189396692096125','test','test','1.00'),('2018-07-17 19:59:59','2018-07-21 11:59:59','WINGSETH','4h','0.000460600000000','0.000493500000000','1.284992888105658','1.376778094398920','2789.823899491226','2789.823899491225802','test','test','0.0'),('2018-07-22 03:59:59','2018-07-22 07:59:59','WINGSETH','4h','0.000507600000000','0.000502524000000','1.305389600615272','1.292335704609119','2571.689520518661','2571.689520518661084','test','test','1.00'),('2018-07-23 19:59:59','2018-07-24 03:59:59','WINGSETH','4h','0.000487500000000','0.000482625000000','1.302488734836127','1.289463847487766','2671.771763766415','2671.771763766415006','test','test','0.99'),('2018-07-27 23:59:59','2018-07-30 23:59:59','WINGSETH','4h','0.000482600000000','0.000511000000000','1.299594315425380','1.376072721057541','2692.901606766225','2692.901606766225086','test','test','0.0'),('2018-08-07 19:59:59','2018-08-07 23:59:59','WINGSETH','4h','0.000459300000000','0.000454707000000','1.316589516676971','1.303423621510201','2866.513208528133','2866.513208528132964','test','test','1.00'),('2018-08-08 15:59:59','2018-08-08 19:59:59','WINGSETH','4h','0.000463000000000','0.000458370000000','1.313663762195467','1.300527124573512','2837.2867434027366','2837.286743402736647','test','test','0.99'),('2018-08-12 15:59:59','2018-08-12 19:59:59','WINGSETH','4h','0.000463900000000','0.000459261000000','1.310744509390588','1.297637064296682','2825.4893498395954','2825.489349839595434','test','test','1.00'),('2018-08-13 23:59:59','2018-08-14 07:59:59','WINGSETH','4h','0.000477100000000','0.000472329000000','1.307831743814165','1.294753426376023','2741.2109490969706','2741.210949096970580','test','test','0.99'),('2018-08-17 07:59:59','2018-08-23 11:59:59','WINGSETH','4h','0.000461500000000','0.000518000000000','1.304925451050133','1.464683388177614','2827.5741084509928','2827.574108450992753','test','test','0.0'),('2018-08-23 15:59:59','2018-08-23 19:59:59','WINGSETH','4h','0.000527600000000','0.000522324000000','1.340427214856240','1.327022942707678','2540.612613450038','2540.612613450038225','test','test','1.00'),('2018-08-26 15:59:59','2018-08-26 19:59:59','WINGSETH','4h','0.000529100000000','0.000523809000000','1.337448487712115','1.324074002834994','2527.780169556067','2527.780169556066994','test','test','1.00'),('2018-08-27 07:59:59','2018-08-27 19:59:59','WINGSETH','4h','0.000531900000000','0.000526581000000','1.334476379961644','1.321131616162027','2508.8858431314984','2508.885843131498405','test','test','1.00'),('2018-08-29 07:59:59','2018-08-29 11:59:59','WINGSETH','4h','0.000523300000000','0.000518067000000','1.331510876895062','1.318195768126111','2544.45036670182','2544.450366701819803','test','test','0.99'),('2018-08-31 07:59:59','2018-08-31 19:59:59','WINGSETH','4h','0.000513100000000','0.000512800000000','1.328551963835295','1.327775184281308','2589.26517995575','2589.265179955750227','test','test','0.25'),('2018-09-01 11:59:59','2018-09-01 15:59:59','WINGSETH','4h','0.000511800000000','0.000508700000000','1.328379346156632','1.320333281340130','2595.5047795166697','2595.504779516669714','test','test','0.60'),('2018-09-03 19:59:59','2018-09-13 23:59:59','WINGSETH','4h','0.000537000000000','0.000573600000000','1.326591331752965','1.417007053805401','2470.374919465483','2470.374919465482890','test','test','0.0'),('2018-09-16 23:59:59','2018-09-21 15:59:59','WINGSETH','4h','0.000598000000000','0.000603300000000','1.346683714431284','1.358619205545809','2251.979455570708','2251.979455570708069','test','test','0.0'),('2018-09-23 07:59:59','2018-09-23 11:59:59','WINGSETH','4h','0.000625600000000','0.000619344000000','1.349336045790067','1.335842685332166','2156.867080866475','2156.867080866475135','test','test','1.00'),('2018-09-26 15:59:59','2018-09-26 19:59:59','WINGSETH','4h','0.000648800000000','0.000642312000000','1.346337521243867','1.332874146031428','2075.119484038019','2075.119484038018982','test','test','1.00'),('2018-09-28 07:59:59','2018-09-29 11:59:59','WINGSETH','4h','0.000625000000000','0.000619000000000','1.343345660085547','1.330449541748726','2149.353056136875','2149.353056136874784','test','test','0.96'),('2018-10-01 15:59:59','2018-10-03 19:59:59','WINGSETH','4h','0.000620700000000','0.000631900000000','1.340479856010698','1.364667667171194','2159.6259964728497','2159.625996472849693','test','test','0.0'),('2018-10-04 07:59:59','2018-10-11 15:59:59','WINGSETH','4h','0.000653500000000','0.000671200000000','1.345854925157475','1.382307307981174','2059.4566567061593','2059.456656706159265','test','test','0.0'),('2018-10-12 07:59:59','2018-10-17 07:59:59','WINGSETH','4h','0.000673600000000','0.000754800000000','1.353955454673852','1.517169799863158','2010.0288816417049','2010.028881641704857','test','test','0.0'),('2018-10-17 19:59:59','2018-10-27 15:59:59','WINGSETH','4h','0.000777000000000','0.000820300000000','1.390225309160365','1.467698611459778','1789.2217621111517','1789.221762111151747','test','test','0.41'),('2018-10-28 03:59:59','2018-11-03 11:59:59','WINGSETH','4h','0.000849800000000','0.000873200000000','1.407441598560234','1.446196756722519','1656.2033402685745','1656.203340268574493','test','test','0.0'),('2018-11-07 19:59:59','2018-11-07 23:59:59','WINGSETH','4h','0.001057500000000','0.001046925000000','1.416053855929631','1.401893317370335','1339.058019791613','1339.058019791613106','test','test','1.00'),('2018-11-08 03:59:59','2018-11-08 19:59:59','WINGSETH','4h','0.001000600000000','0.000990594000000','1.412907069583121','1.398777998887290','1412.059833682911','1412.059833682910948','test','test','0.99'),('2018-11-10 19:59:59','2018-11-11 03:59:59','WINGSETH','4h','0.000936100000000','0.000926739000000','1.409767276095158','1.395669603334206','1506.0007222467236','1506.000722246723626','test','test','1.00'),('2018-11-26 15:59:59','2018-11-26 19:59:59','WINGSETH','4h','0.000778700000000','0.000770913000000','1.406634459926058','1.392568115326797','1806.3881596584793','1806.388159658479253','test','test','0.99'),('2018-11-30 07:59:59','2018-11-30 11:59:59','WINGSETH','4h','0.000765200000000','0.000757548000000','1.403508605570666','1.389473519514959','1834.1722498309805','1834.172249830980491','test','test','1.00'),('2018-11-30 15:59:59','2018-11-30 19:59:59','WINGSETH','4h','0.000751400000000','0.000743886000000','1.400389697558287','1.386385800582704','1863.7073430373794','1863.707343037379360','test','test','1.00'),('2018-11-30 23:59:59','2018-12-05 23:59:59','WINGSETH','4h','0.000774000000000','0.000766260000000','1.397277720452602','1.383304943248076','1805.2683726777807','1805.268372677780690','test','test','1.00'),('2018-12-07 15:59:59','2018-12-07 19:59:59','WINGSETH','4h','0.000804500000000','0.000796455000000','1.394172658851596','1.380230932263080','1732.9678792437494','1732.967879243749394','test','test','1.00'),('2018-12-08 11:59:59','2018-12-08 15:59:59','WINGSETH','4h','0.000788800000000','0.000780912000000','1.391074497387482','1.377163752413607','1763.5325778238866','1763.532577823886641','test','test','1.00'),('2018-12-12 23:59:59','2018-12-13 03:59:59','WINGSETH','4h','0.000866300000000','0.000857637000000','1.387983220726620','1.374103388519354','1602.196953395614','1602.196953395613946','test','test','1.00'),('2018-12-15 07:59:59','2018-12-15 19:59:59','WINGSETH','4h','0.000768300000000','0.000761500000000','1.384898813569450','1.372641476679860','1802.549542586815','1802.549542586815051','test','test','0.88'),('2018-12-16 23:59:59','2018-12-17 19:59:59','WINGSETH','4h','0.000773800000000','0.000766062000000','1.382174960927319','1.368353211318046','1786.2173183346072','1786.217318334607171','test','test','0.99'),('2019-01-08 15:59:59','2019-01-10 19:59:59','WINGSETH','4h','0.000580000000000','0.000574200000000','1.379103461014147','1.365312426404006','2377.7645879554266','2377.764587955426578','test','test','1.00'),('2019-01-11 15:59:59','2019-01-14 15:59:59','WINGSETH','4h','0.000587300000000','0.000581427000000','1.376038786656338','1.362278398789775','2342.991293472396','2342.991293472396137','test','test','0.99'),('2019-01-14 19:59:59','2019-01-26 15:59:59','WINGSETH','4h','0.000600700000000','0.000818200000000','1.372980922685991','1.870106527287628','2285.634963685685','2285.634963685684852','test','test','0.41'),('2019-01-27 19:59:59','2019-01-27 23:59:59','WINGSETH','4h','0.000845300000000','0.000836847000000','1.483453279264133','1.468618746471492','1754.9429542933071','1754.942954293307139','test','test','0.99'),('2019-01-28 15:59:59','2019-01-29 07:59:59','WINGSETH','4h','0.000851200000000','0.000842688000000','1.480156716421323','1.465355149257110','1738.9059168483593','1738.905916848359311','test','test','1.00'),('2019-02-02 07:59:59','2019-02-02 11:59:59','WINGSETH','4h','0.000813300000000','0.000805167000000','1.476867479273721','1.462098804480984','1815.895093168229','1815.895093168229096','test','test','1.00'),('2019-02-02 15:59:59','2019-02-02 19:59:59','WINGSETH','4h','0.000826000000000','0.000817740000000','1.473585551542001','1.458849696026581','1784.0018783801465','1784.001878380146536','test','test','1.00'),('2019-02-03 07:59:59','2019-02-03 11:59:59','WINGSETH','4h','0.000812100000000','0.000838200000000','1.470310916983019','1.517565091263597','1810.504761707941','1810.504761707941043','test','test','0.0'),('2019-02-03 15:59:59','2019-02-03 19:59:59','WINGSETH','4h','0.000831300000000','0.000822987000000','1.480811844600925','1.466003726154916','1781.3206358726393','1781.320635872639286','test','test','1.00'),('2019-02-07 19:59:59','2019-02-07 23:59:59','WINGSETH','4h','0.000824100000000','0.000815859000000','1.477521151612923','1.462745940096794','1792.8906098931236','1792.890609893123610','test','test','0.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 19:20:56
