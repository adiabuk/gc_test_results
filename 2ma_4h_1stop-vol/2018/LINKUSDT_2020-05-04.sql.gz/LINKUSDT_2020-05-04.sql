-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-07-05 03:59:59','2019-07-05 07:59:59','LINKUSDT','4h','3.633000000000000','3.596670000000000','222.222222222222200','219.999999999999972','61.167691225494686','61.167691225494686','test','test','0.99'),('2019-07-07 15:59:59','2019-07-07 19:59:59','LINKUSDT','4h','3.405100000000000','3.371049000000000','221.728395061728406','219.511111111111148','65.11655900318006','65.116559003180058','test','test','0.99'),('2019-07-08 07:59:59','2019-07-08 11:59:59','LINKUSDT','4h','3.434500000000000','3.400155000000000','221.235665294924530','219.023308641975291','64.41568359147607','64.415683591476068','test','test','1.00'),('2019-07-08 23:59:59','2019-07-09 03:59:59','LINKUSDT','4h','3.336200000000000','3.302838000000000','220.744030483158070','218.536590178326492','66.16630612168278','66.166306121682780','test','test','0.99'),('2019-07-12 19:59:59','2019-07-12 23:59:59','LINKUSDT','4h','3.288700000000000','3.255813000000000','220.253488193195494','218.050953311263527','66.97281241621172','66.972812416211724','test','test','1.00'),('2019-07-13 19:59:59','2019-07-13 23:59:59','LINKUSDT','4h','3.228900000000000','3.196611000000000','219.764035997210613','217.566395637238514','68.06158010381573','68.061580103815729','test','test','1.00'),('2019-08-02 19:59:59','2019-08-02 23:59:59','LINKUSDT','4h','2.360500000000000','2.427100000000000','219.275671472772359','225.462394506064726','92.89373923862416','92.893739238624164','test','test','0.0'),('2019-08-03 03:59:59','2019-08-03 23:59:59','LINKUSDT','4h','2.523800000000000','2.498562000000000','220.650498813503987','218.443993825368977','87.42788605020365','87.427886050203654','test','test','0.99'),('2019-08-04 15:59:59','2019-08-05 23:59:59','LINKUSDT','4h','2.514900000000000','2.489751000000000','220.160164371696254','217.958562727979313','87.54231355986173','87.542313559861725','test','test','0.99'),('2019-08-06 19:59:59','2019-08-06 23:59:59','LINKUSDT','4h','2.428000000000000','2.478500000000000','219.670919561981350','224.239857551223565','90.47401958895443','90.474019588954434','test','test','0.0'),('2019-08-11 03:59:59','2019-08-11 07:59:59','LINKUSDT','4h','2.374800000000000','2.362500000000000','220.686239115146265','219.543220443630190','92.92834727772707','92.928347277727070','test','test','0.51'),('2019-08-11 19:59:59','2019-08-12 15:59:59','LINKUSDT','4h','2.433200000000000','2.408868000000000','220.432234965920514','218.227912616261335','90.59355374236418','90.593553742364179','test','test','0.99'),('2019-08-13 19:59:59','2019-08-14 19:59:59','LINKUSDT','4h','2.438900000000000','2.414511000000000','219.942385554885135','217.742961699336263','90.18097730734559','90.180977307345586','test','test','1.00'),('2019-08-15 23:59:59','2019-08-16 03:59:59','LINKUSDT','4h','2.423200000000000','2.398968000000000','219.453624698096490','217.259088451115531','90.56356251984833','90.563562519848332','test','test','1.00'),('2019-08-18 07:59:59','2019-08-20 11:59:59','LINKUSDT','4h','2.442800000000000','2.418372000000000','218.965949976545147','216.776290476779707','89.63728097942736','89.637280979427359','test','test','0.99'),('2019-09-18 07:59:59','2019-09-18 11:59:59','LINKUSDT','4h','1.741500000000000','1.724085000000000','218.479358976597268','216.294565386831295','125.45469938363323','125.454699383633226','test','test','0.99'),('2019-09-18 15:59:59','2019-09-18 19:59:59','LINKUSDT','4h','1.779300000000000','1.761507000000000','217.993849289982592','215.813910797082769','122.51663535659112','122.516635356591124','test','test','0.99'),('2019-09-18 23:59:59','2019-09-19 03:59:59','LINKUSDT','4h','1.801000000000000','1.782990000000000','217.509418513782634','215.334324328644811','120.77147057955727','120.771470579557274','test','test','1.00'),('2019-09-19 07:59:59','2019-09-20 19:59:59','LINKUSDT','4h','1.800500000000000','1.782495000000000','217.026064250418699','214.855803607914510','120.53655331875518','120.536553318755182','test','test','1.00'),('2019-09-23 19:59:59','2019-09-23 23:59:59','LINKUSDT','4h','1.852700000000000','1.834173000000000','216.543784107639993','214.378346266563597','116.88011232667998','116.880112326679978','test','test','0.99'),('2019-09-24 07:59:59','2019-09-24 19:59:59','LINKUSDT','4h','1.882600000000000','1.863774000000000','216.062575698511893','213.901949941526766','114.76818001620731','114.768180016207310','test','test','1.00'),('2019-09-30 19:59:59','2019-10-15 19:59:59','LINKUSDT','4h','1.741000000000000','2.433200000000000','215.582436641404115','301.295338791421273','123.82678727248943','123.826787272489426','test','test','0.0'),('2019-10-17 15:59:59','2019-10-17 23:59:59','LINKUSDT','4h','2.450000000000000','2.425500000000000','234.629748230296769','232.283450747993783','95.76724417563133','95.767244175631333','test','test','1.00'),('2019-10-20 19:59:59','2019-10-23 15:59:59','LINKUSDT','4h','2.434800000000000','2.503500000000000','234.108348789785055','240.713919498614587','96.15095646040129','96.150956460401289','test','test','0.0'),('2019-10-23 19:59:59','2019-10-29 19:59:59','LINKUSDT','4h','2.601600000000000','2.672800000000000','235.576253391747144','242.023450978421693','90.55052790273184','90.550527902731844','test','test','0.0'),('2019-10-31 19:59:59','2019-11-01 11:59:59','LINKUSDT','4h','2.719200000000000','2.692008000000000','237.008963966563698','234.638874326898048','87.16128418893929','87.161284188939291','test','test','0.99'),('2019-11-04 15:59:59','2019-11-04 19:59:59','LINKUSDT','4h','2.721300000000000','2.694087000000000','236.482277379971350','234.117454606171634','86.90048042478645','86.900480424786451','test','test','1.00'),('2019-11-05 11:59:59','2019-11-06 03:59:59','LINKUSDT','4h','2.667500000000000','2.657700000000000','235.956761208015877','235.089891007514098','88.45614290834709','88.456142908347090','test','test','0.36'),('2019-11-06 19:59:59','2019-11-07 07:59:59','LINKUSDT','4h','2.699200000000000','2.682400000000000','235.764123385682097','234.296711829339671','87.34592597276308','87.345925972763084','test','test','0.75'),('2019-11-07 15:59:59','2019-11-07 19:59:59','LINKUSDT','4h','2.679800000000000','2.687100000000000','235.438031928717123','236.079384877847502','87.85656837402684','87.856568374026835','test','test','0.0'),('2019-11-08 03:59:59','2019-11-08 11:59:59','LINKUSDT','4h','2.716300000000000','2.689137000000000','235.580554806301620','233.224749258238631','86.72847432400752','86.728474324007522','test','test','0.99'),('2019-11-08 23:59:59','2019-11-11 07:59:59','LINKUSDT','4h','2.710000000000000','2.729600000000000','235.057042462287683','236.757086016627483','86.73691603774454','86.736916037744535','test','test','0.0'),('2019-11-12 15:59:59','2019-11-15 15:59:59','LINKUSDT','4h','2.778800000000000','2.929900000000000','235.434829918807623','248.236831790382354','84.72535983835023','84.725359838350229','test','test','0.0'),('2019-12-10 03:59:59','2019-12-11 23:59:59','LINKUSDT','4h','2.171400000000000','2.178600000000000','238.279719223602001','239.069815004393121','109.73552510988394','109.735525109883937','test','test','0.93'),('2019-12-27 15:59:59','2019-12-27 19:59:59','LINKUSDT','4h','1.925800000000000','1.906542000000000','238.455296063777809','236.070743103140018','123.82142281845353','123.821422818453527','test','test','0.99'),('2019-12-29 23:59:59','2019-12-30 03:59:59','LINKUSDT','4h','1.897600000000000','1.878624000000000','237.925395405858268','235.546141451799684','125.38226992298603','125.382269922986026','test','test','1.00'),('2020-01-06 11:59:59','2020-01-23 07:59:59','LINKUSDT','4h','1.896400000000000','2.529300000000000','237.396672304956411','316.624869890806963','125.18280547614238','125.182805476142377','test','test','0.99'),('2020-01-24 15:59:59','2020-01-24 19:59:59','LINKUSDT','4h','2.519200000000000','2.519900000000000','255.002938435145410','255.073795078883336','101.22377676847626','101.223776768476256','test','test','0.0'),('2020-01-26 19:59:59','2020-02-04 07:59:59','LINKUSDT','4h','2.542300000000000','2.741100000000000','255.018684355976035','274.960357034246897','100.31022473979311','100.310224739793114','test','test','0.0'),('2020-02-05 07:59:59','2020-02-16 15:59:59','LINKUSDT','4h','2.793000000000000','4.496100000000000','259.450167173369550','417.656246555025689','92.89300650675601','92.893006506756009','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 19:33:32
