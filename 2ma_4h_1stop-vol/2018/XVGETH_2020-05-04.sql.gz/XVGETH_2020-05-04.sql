-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-19 15:59:59','2018-03-19 19:59:59','XVGETH','4h','0.000056730000000','0.000056162700000','1.297777777777778','1.284800000000000','22876.39305090389','22876.393050903890980','test','test','1.00'),('2018-03-19 23:59:59','2018-04-14 19:59:59','XVGETH','4h','0.000057000000000','0.000172950000000','1.294893827160494','3.928980480831709','22717.435564219188','22717.435564219187654','test','test','0.0'),('2018-04-16 23:59:59','2018-04-17 11:59:59','XVGETH','4h','0.000183780000000','0.000208460000000','1.880246416865208','2.132746588637073','10230.963199832453','10230.963199832453029','test','test','0.0'),('2018-04-30 23:59:59','2018-05-01 03:59:59','XVGETH','4h','0.000115250000000','0.000114097500000','1.936357566147844','1.916993990486366','16801.367168311015','16801.367168311015121','test','test','0.99'),('2018-05-01 11:59:59','2018-05-01 19:59:59','XVGETH','4h','0.000121250000000','0.000120037500000','1.932054549334183','1.912734003840841','15934.470509972645','15934.470509972645232','test','test','0.99'),('2018-07-01 23:59:59','2018-07-05 11:59:59','XVGETH','4h','0.000055360000000','0.000054806400000','1.927761094780107','1.908483483832306','34822.27411091234','34822.274110912338074','test','test','1.00'),('2018-07-16 15:59:59','2018-07-16 19:59:59','XVGETH','4h','0.000051710000000','0.000051860000000','1.923477181236152','1.929056790154841','37197.392791261875','37197.392791261874663','test','test','0.0'),('2018-07-16 23:59:59','2018-07-17 03:59:59','XVGETH','4h','0.000052200000000','0.000051678000000','1.924717094329193','1.905469923385901','36871.97498714929','36871.974987149289518','test','test','0.99'),('2018-07-17 11:59:59','2018-07-17 15:59:59','XVGETH','4h','0.000051800000000','0.000052000000000','1.920439945230684','1.927854771274046','37074.130216808575','37074.130216808574914','test','test','0.0'),('2018-07-17 19:59:59','2018-07-20 07:59:59','XVGETH','4h','0.000052160000000','0.000051638400000','1.922087684351431','1.902866807507917','36849.84057422222','36849.840574222216674','test','test','0.99'),('2018-07-25 07:59:59','2018-07-25 19:59:59','XVGETH','4h','0.000051960000000','0.000051440400000','1.917816378386206','1.898638214602344','36909.47610443045','36909.476104430446867','test','test','1.00'),('2018-07-26 03:59:59','2018-07-26 07:59:59','XVGETH','4h','0.000053570000000','0.000053034300000','1.913554564212014','1.894419018569894','35720.63774896424','35720.637748964240018','test','test','1.00'),('2018-07-30 07:59:59','2018-07-30 15:59:59','XVGETH','4h','0.000052400000000','0.000052000000000','1.909302220735987','1.894727394623499','36437.06528122113','36437.065281221126497','test','test','0.76'),('2018-07-30 23:59:59','2018-08-02 11:59:59','XVGETH','4h','0.000053110000000','0.000052578900000','1.906063370488768','1.887002736783880','35888.973272241914','35888.973272241913946','test','test','0.99'),('2018-08-17 03:59:59','2018-08-22 19:59:59','XVGETH','4h','0.000044330000000','0.000045950000000','1.901827674109904','1.971328256831719','42901.59427272511','42901.594272725109477','test','test','0.0'),('2018-08-24 19:59:59','2018-08-30 15:59:59','XVGETH','4h','0.000046810000000','0.000050000000000','1.917272248048085','2.047930194454267','40958.60388908534','40958.603889085337869','test','test','0.0'),('2018-09-01 03:59:59','2018-09-13 23:59:59','XVGETH','4h','0.000051930000000','0.000063800000000','1.946307347249459','2.391188306460919','37479.440540139774','37479.440540139774384','test','test','0.0'),('2018-09-17 19:59:59','2018-09-18 03:59:59','XVGETH','4h','0.000064960000000','0.000064310400000','2.045169782629783','2.024718084803486','31483.52497890676','31483.524978906760225','test','test','1.00'),('2018-09-18 23:59:59','2018-09-19 03:59:59','XVGETH','4h','0.000063760000000','0.000064400000000','2.040624960890606','2.061108021978592','32004.782949978136','32004.782949978136458','test','test','0.0'),('2018-09-19 19:59:59','2018-09-19 23:59:59','XVGETH','4h','0.000065010000000','0.000064359900000','2.045176752243492','2.024724984721058','31459.417816389654','31459.417816389654035','test','test','0.99'),('2018-09-20 15:59:59','2018-09-20 23:59:59','XVGETH','4h','0.000066920000000','0.000066250800000','2.040631915016284','2.020225595866121','30493.603033716136','30493.603033716135542','test','test','1.00'),('2018-09-21 03:59:59','2018-09-21 15:59:59','XVGETH','4h','0.000065480000000','0.000064825200000','2.036097177427359','2.015736205653085','31094.947731022585','31094.947731022584776','test','test','0.99'),('2018-09-21 23:59:59','2018-09-22 03:59:59','XVGETH','4h','0.000064400000000','0.000063756000000','2.031572517033076','2.011256791862745','31546.15709678689','31546.157096786890179','test','test','1.00'),('2018-09-25 07:59:59','2018-09-25 11:59:59','XVGETH','4h','0.000064350000000','0.000064930000000','2.027057911439669','2.045328208077354','31500.511444283893','31500.511444283893070','test','test','0.0'),('2018-09-25 15:59:59','2018-09-25 23:59:59','XVGETH','4h','0.000064770000000','0.000064122300000','2.031117977359155','2.010806797585563','31358.931254580122','31358.931254580122186','test','test','1.00'),('2018-09-26 03:59:59','2018-09-26 19:59:59','XVGETH','4h','0.000064950000000','0.000064360000000','2.026604381853912','2.008194888623830','31202.530898443598','31202.530898443597835','test','test','0.90'),('2018-09-27 15:59:59','2018-09-27 23:59:59','XVGETH','4h','0.000065550000000','0.000064894500000','2.022513383358338','2.002288249524755','30854.513857488004','30854.513857488003850','test','test','0.99'),('2018-09-28 07:59:59','2018-09-28 11:59:59','XVGETH','4h','0.000064950000000','0.000064440000000','2.018018909173098','2.002173033211923','31070.345021910663','31070.345021910663490','test','test','0.78'),('2018-09-28 19:59:59','2018-09-29 03:59:59','XVGETH','4h','0.000064590000000','0.000064400000000','2.014497603403947','2.008571693129186','31189.00144610539','31189.001446105390642','test','test','0.55'),('2018-09-30 15:59:59','2018-10-10 07:59:59','XVGETH','4h','0.000065880000000','0.000069190000000','2.013180734454001','2.114328703959811','30558.298944353384','30558.298944353384286','test','test','0.65'),('2018-10-10 11:59:59','2018-10-15 03:59:59','XVGETH','4h','0.000070300000000','0.000070410000000','2.035658061010847','2.038843301220110','28956.729175118737','28956.729175118736748','test','test','0.0'),('2018-10-19 19:59:59','2018-10-20 03:59:59','XVGETH','4h','0.000070520000000','0.000069814800000','2.036365892168461','2.016002233246776','28876.430688718967','28876.430688718966849','test','test','1.00'),('2018-10-21 11:59:59','2018-10-22 07:59:59','XVGETH','4h','0.000070710000000','0.000070430000000','2.031840634630309','2.023794879041333','28734.84138919967','28734.841389199671539','test','test','0.66'),('2018-10-23 15:59:59','2018-10-27 23:59:59','XVGETH','4h','0.000070180000000','0.000071810000000','2.030052688943870','2.077202673027349','28926.37060336093','28926.370603360930545','test','test','0.0'),('2018-10-28 15:59:59','2018-10-29 03:59:59','XVGETH','4h','0.000072440000000','0.000071715600000','2.040530463184643','2.020125158552796','28168.55967952296','28168.559679522961233','test','test','1.00'),('2018-11-27 23:59:59','2018-12-04 07:59:59','XVGETH','4h','0.000055290000000','0.000064780000000','2.035995951044233','2.385455194585737','36823.9455786622','36823.945578662198386','test','test','0.0'),('2018-12-05 03:59:59','2018-12-05 07:59:59','XVGETH','4h','0.000065830000000','0.000065171700000','2.113653560720123','2.092517025112922','32107.755745406692','32107.755745406691858','test','test','1.00'),('2018-12-06 07:59:59','2018-12-06 11:59:59','XVGETH','4h','0.000065040000000','0.000064389600000','2.108956552807411','2.087866987279337','32425.53125472649','32425.531254726491170','test','test','1.00'),('2018-12-07 07:59:59','2018-12-07 11:59:59','XVGETH','4h','0.000065220000000','0.000064567800000','2.104269982690062','2.083227282863161','32264.182500614254','32264.182500614253513','test','test','1.00'),('2018-12-07 15:59:59','2018-12-07 19:59:59','XVGETH','4h','0.000069710000000','0.000069012900000','2.099593827172973','2.078597888901243','30118.97614650657','30118.976146506571240','test','test','1.00'),('2018-12-12 11:59:59','2018-12-12 15:59:59','XVGETH','4h','0.000064700000000','0.000064700000000','2.094928063112588','2.094928063112588','32379.10453033366','32379.104530333661387','test','test','0.0'),('2018-12-13 03:59:59','2018-12-13 11:59:59','XVGETH','4h','0.000065250000000','0.000064597500000','2.094928063112588','2.073978782481462','32106.177212453455','32106.177212453454558','test','test','1.00'),('2018-12-13 19:59:59','2018-12-13 23:59:59','XVGETH','4h','0.000064960000000','0.000064310400000','2.090272667416782','2.069369940742614','32177.842786588397','32177.842786588396848','test','test','1.00'),('2018-12-14 19:59:59','2018-12-14 23:59:59','XVGETH','4h','0.000069210000000','0.000068517900000','2.085627617044745','2.064771340874298','30134.77267800528','30134.772678005279886','test','test','1.00'),('2018-12-15 15:59:59','2018-12-16 03:59:59','XVGETH','4h','0.000066820000000','0.000066151800000','2.080992889006868','2.060182960116799','31143.26382829793','31143.263828297931468','test','test','1.00'),('2018-12-17 15:59:59','2018-12-18 03:59:59','XVGETH','4h','0.000066180000000','0.000065518200000','2.076368460364630','2.055604775760984','31374.561202245848','31374.561202245848108','test','test','1.00'),('2018-12-18 19:59:59','2018-12-18 23:59:59','XVGETH','4h','0.000065930000000','0.000065270700000','2.071754308230487','2.051036765148182','31423.54479342465','31423.544793424651289','test','test','1.00'),('2018-12-19 03:59:59','2018-12-22 23:59:59','XVGETH','4h','0.000067260000000','0.000068960000000','2.067150409767752','2.119397743942673','30733.72598524758','30733.725985247579956','test','test','0.98'),('2019-01-10 15:59:59','2019-01-10 19:59:59','XVGETH','4h','0.000057520000000','0.000056944800000','2.078760928473291','2.057973319188558','36139.79361045359','36139.793610453591100','test','test','1.00'),('2019-01-10 23:59:59','2019-01-11 23:59:59','XVGETH','4h','0.000059140000000','0.000058548600000','2.074141459743350','2.053400045145917','35071.7189675913','35071.718967591303226','test','test','1.00'),('2019-01-15 15:59:59','2019-01-17 19:59:59','XVGETH','4h','0.000055350000000','0.000054796500000','2.069532256499476','2.048836933934481','37389.923333323866','37389.923333323866245','test','test','1.00'),('2019-01-18 11:59:59','2019-01-27 11:59:59','XVGETH','4h','0.000054790000000','0.000056570000000','2.064933295929477','2.132018188551387','37688.14192242155','37688.141922421549680','test','test','0.0'),('2019-01-28 03:59:59','2019-01-28 07:59:59','XVGETH','4h','0.000057070000000','0.000056520000000','2.079841049845457','2.059797023607241','36443.68406948409','36443.684069484086649','test','test','0.96'),('2019-01-28 11:59:59','2019-01-29 07:59:59','XVGETH','4h','0.000057450000000','0.000056875500000','2.075386821792520','2.054632953574595','36125.09698507432','36125.096985074320401','test','test','0.99'),('2019-01-29 11:59:59','2019-01-30 15:59:59','XVGETH','4h','0.000057470000000','0.000057030000000','2.070774851077425','2.054920650025153','36032.275118799815','36032.275118799814663','test','test','0.95'),('2019-03-02 15:59:59','2019-03-03 03:59:59','XVGETH','4h','0.000045280000000','0.000045260000000','2.067251695288032','2.066338598249477','45654.85192773922','45654.851927739218809','test','test','0.04'),('2019-03-03 11:59:59','2019-03-05 23:59:59','XVGETH','4h','0.000045220000000','0.000046020000000','2.067048784835019','2.103617538215559','45710.941725674915','45710.941725674914778','test','test','0.0'),('2019-03-08 11:59:59','2019-03-08 19:59:59','XVGETH','4h','0.000047270000000','0.000046797300000','2.075175174475139','2.054423422730387','43900.46910249925','43900.469102499249857','test','test','0.99'),('2019-03-09 07:59:59','2019-03-10 07:59:59','XVGETH','4h','0.000046840000000','0.000046371600000','2.070563674087417','2.049858037346543','44205.03147069635','44205.031470696347242','test','test','0.99'),('2019-03-12 11:59:59','2019-03-18 19:59:59','XVGETH','4h','0.000049210000000','0.000049580000000','2.065962421478333','2.081495973519524','41982.57308429859','41982.573084298586764','test','test','0.22'),('2019-03-19 15:59:59','2019-03-19 15:59:59','XVGETH','4h','0.000049680000000','0.000049680000000','2.069414321931931','2.069414321931931','41654.87765563469','41654.877655634692928','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 20:04:53
