-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-25 15:59:59','2018-05-25 19:59:59','XLMBTC','4h','0.000039240000000','0.000038847600000','0.033333333333333','0.033000000000000','849.4733265375468','849.473326537546768','test','test','0.99'),('2018-05-26 03:59:59','2018-05-26 07:59:59','XLMBTC','4h','0.000038790000000','0.000038810000000','0.033259259259259','0.033276407627013','857.4183877097018','857.418387709701847','test','test','0.0'),('2018-05-26 15:59:59','2018-05-26 19:59:59','XLMBTC','4h','0.000038790000000','0.000038590000000','0.033263070007649','0.033091566682010','857.5166281940992','857.516628194099212','test','test','0.51'),('2018-05-31 11:59:59','2018-06-01 19:59:59','XLMBTC','4h','0.000038600000000','0.000038214000000','0.033224958157507','0.032892708575932','860.750211334381','860.750211334380992','test','test','0.99'),('2018-06-02 07:59:59','2018-06-04 15:59:59','XLMBTC','4h','0.000038830000000','0.000038500000000','0.033151124917157','0.032869387311629','853.7503197825679','853.750319782567885','test','test','0.84'),('2018-06-06 15:59:59','2018-06-06 19:59:59','XLMBTC','4h','0.000038730000000','0.000038560000000','0.033088516560373','0.032943279074825','854.3381502807415','854.338150280741502','test','test','0.43'),('2018-06-07 07:59:59','2018-06-07 15:59:59','XLMBTC','4h','0.000038980000000','0.000038590200000','0.033056241563585','0.032725679147949','848.0308251304428','848.030825130442850','test','test','1.00'),('2018-06-07 19:59:59','2018-06-07 23:59:59','XLMBTC','4h','0.000038900000000','0.000038511000000','0.032982783248999','0.032652955416509','847.8864588431591','847.886458843159062','test','test','0.99'),('2018-07-02 15:59:59','2018-07-03 19:59:59','XLMBTC','4h','0.000032210000000','0.000031887900000','0.032909488175112','0.032580393293361','1021.7164910000691','1021.716491000069141','test','test','1.00'),('2018-07-04 19:59:59','2018-07-04 23:59:59','XLMBTC','4h','0.000032110000000','0.000031940000000','0.032836355979168','0.032662510432097','1022.6208651251183','1022.620865125118257','test','test','0.52'),('2018-07-08 19:59:59','2018-07-08 23:59:59','XLMBTC','4h','0.000031800000000','0.000031482000000','0.032797723635374','0.032469746399020','1031.3749570872326','1031.374957087232588','test','test','0.99'),('2018-07-09 11:59:59','2018-07-09 15:59:59','XLMBTC','4h','0.000031750000000','0.000031590000000','0.032724839805073','0.032559927226528','1030.7036159078145','1030.703615907814537','test','test','0.50'),('2018-07-13 23:59:59','2018-07-14 03:59:59','XLMBTC','4h','0.000033070000000','0.000032739300000','0.032688192565396','0.032361310639742','988.4545680494842','988.454568049484237','test','test','1.00'),('2018-07-15 11:59:59','2018-07-23 19:59:59','XLMBTC','4h','0.000034270000000','0.000036490000000','0.032615552137473','0.034728377516673','951.7231437838732','951.723143783873184','test','test','0.0'),('2018-07-24 07:59:59','2018-07-24 11:59:59','XLMBTC','4h','0.000036830000000','0.000036461700000','0.033085068888407','0.032754218199523','898.3184601793827','898.318460179382669','test','test','1.00'),('2018-07-24 15:59:59','2018-07-24 19:59:59','XLMBTC','4h','0.000036770000000','0.000036402300000','0.033011546513099','0.032681431047968','897.7847841473784','897.784784147378446','test','test','0.99'),('2018-07-25 11:59:59','2018-07-26 23:59:59','XLMBTC','4h','0.000037250000000','0.000038850000000','0.032938187520848','0.034352982152616','884.2466448549741','884.246644854974079','test','test','0.0'),('2018-08-10 19:59:59','2018-08-11 03:59:59','XLMBTC','4h','0.000035980000000','0.000035620200000','0.033252586327907','0.032920060464628','924.1963959952011','924.196395995201101','test','test','1.00'),('2018-08-12 03:59:59','2018-08-12 15:59:59','XLMBTC','4h','0.000035570000000','0.000035214300000','0.033178691691623','0.032846904774707','932.771765297248','932.771765297247953','test','test','1.00'),('2018-08-13 11:59:59','2018-08-13 15:59:59','XLMBTC','4h','0.000036900000000','0.000036531000000','0.033104961265642','0.032773911652986','897.1534218331105','897.153421833110542','test','test','1.00'),('2018-08-14 03:59:59','2018-08-14 07:59:59','XLMBTC','4h','0.000035810000000','0.000035451900000','0.033031394685052','0.032701080738201','922.4070004203172','922.407000420317218','test','test','0.99'),('2018-08-17 15:59:59','2018-08-18 07:59:59','XLMBTC','4h','0.000035500000000','0.000035145000000','0.032957991585751','0.032628411669893','928.3941291760939','928.394129176093884','test','test','0.99'),('2018-09-06 23:59:59','2018-09-07 03:59:59','XLMBTC','4h','0.000031930000000','0.000032050000000','0.032884751604450','0.033008339772083','1029.9013969448656','1029.901396944865610','test','test','0.0'),('2018-09-11 23:59:59','2018-09-12 03:59:59','XLMBTC','4h','0.000031880000000','0.000031561200000','0.032912215641701','0.032583093485284','1032.3781568915101','1032.378156891510116','test','test','1.00'),('2018-09-12 19:59:59','2018-09-12 23:59:59','XLMBTC','4h','0.000031760000000','0.000031442400000','0.032839077384720','0.032510686610873','1033.9759881838722','1033.975988183872232','test','test','0.99'),('2018-09-16 11:59:59','2018-09-17 07:59:59','XLMBTC','4h','0.000031780000000','0.000031610000000','0.032766101657198','0.032590826726999','1031.0290011704917','1031.029001170491711','test','test','0.53'),('2018-09-17 11:59:59','2018-09-17 19:59:59','XLMBTC','4h','0.000032180000000','0.000031858200000','0.032727151672710','0.032399880155983','1017.0028487479664','1017.002848747966368','test','test','1.00'),('2018-09-18 11:59:59','2018-10-02 23:59:59','XLMBTC','4h','0.000032350000000','0.000037790000000','0.032654424668992','0.038145616947178','1009.4103452547897','1009.410345254789718','test','test','0.71'),('2018-10-08 23:59:59','2018-10-09 03:59:59','XLMBTC','4h','0.000037490000000','0.000037140000000','0.033874689619700','0.033558441517089','903.5660074606682','903.566007460668175','test','test','0.93'),('2018-10-17 07:59:59','2018-10-18 19:59:59','XLMBTC','4h','0.000035690000000','0.000036470000000','0.033804412263565','0.034543203005106','947.1676173596153','947.167617359615292','test','test','0.0'),('2018-10-18 23:59:59','2018-10-19 05:59:59','XLMBTC','4h','0.000036970000000','0.000036600300000','0.033968587983907','0.033628902104068','918.8149305898596','918.814930589859614','test','test','0.99'),('2018-10-19 19:59:59','2018-10-21 19:59:59','XLMBTC','4h','0.000037810000000','0.000037431900000','0.033893102232832','0.033554171210504','896.4057718283995','896.405771828399452','test','test','1.00'),('2018-10-23 03:59:59','2018-10-23 11:59:59','XLMBTC','4h','0.000038170000000','0.000037788300000','0.033817784227870','0.033479606385591','885.9781039525805','885.978103952580454','test','test','1.00'),('2018-10-23 23:59:59','2018-10-24 11:59:59','XLMBTC','4h','0.000037480000000','0.000037105200000','0.033742633596252','0.033405207260289','900.2837138808017','900.283713880801656','test','test','1.00'),('2018-11-02 23:59:59','2018-11-14 01:59:59','XLMBTC','4h','0.000037030000000','0.000040050000000','0.033667649966038','0.036413431842825','909.1992969494584','909.199296949458358','test','test','0.24'),('2018-11-14 23:59:59','2018-11-15 03:59:59','XLMBTC','4h','0.000040760000000','0.000040352400000','0.034277823716436','0.033935045479272','840.9672158104895','840.967215810489506','test','test','0.99'),('2018-11-15 23:59:59','2018-11-17 03:59:59','XLMBTC','4h','0.000042680000000','0.000042253200000','0.034201650774844','0.033859634267096','801.3507679204208','801.350767920420822','test','test','1.00'),('2018-11-18 07:59:59','2018-11-19 03:59:59','XLMBTC','4h','0.000044720000000','0.000044272800000','0.034125647106455','0.033784390635390','763.0958655289604','763.095865528960417','test','test','0.99'),('2018-11-19 15:59:59','2018-11-20 07:59:59','XLMBTC','4h','0.000045550000000','0.000045094500000','0.034049812335107','0.033709314211756','747.5260666324333','747.526066632433299','test','test','1.00'),('2018-12-01 11:59:59','2018-12-01 15:59:59','XLMBTC','4h','0.000039980000000','0.000039730000000','0.033974146085474','0.033761701450122','849.7785414075482','849.778541407548232','test','test','0.62'),('2018-12-24 03:59:59','2018-12-24 07:59:59','XLMBTC','4h','0.000031810000000','0.000033080000000','0.033926936166507','0.035281453894626','1066.5493922196374','1066.549392219637411','test','test','0.0'),('2018-12-24 11:59:59','2018-12-24 19:59:59','XLMBTC','4h','0.000032700000000','0.000032373000000','0.034227940106089','0.033885660705028','1046.725997128094','1046.725997128093923','test','test','0.99'),('2019-01-07 11:59:59','2019-01-08 03:59:59','XLMBTC','4h','0.000030480000000','0.000030175200000','0.034151878016964','0.033810359236794','1120.4684388767719','1120.468438876771870','test','test','1.00'),('2019-01-08 11:59:59','2019-01-09 19:59:59','XLMBTC','4h','0.000030530000000','0.000030460000000','0.034075984954704','0.033997854625623','1116.1475582936127','1116.147558293612747','test','test','0.45'),('2019-01-09 23:59:59','2019-01-10 07:59:59','XLMBTC','4h','0.000030870000000','0.000030561300000','0.034058622659353','0.033718036432759','1103.2919552754345','1103.291955275434475','test','test','0.99'),('2019-01-13 03:59:59','2019-01-13 07:59:59','XLMBTC','4h','0.000030740000000','0.000030432600000','0.033982936831221','0.033643107462909','1105.495667899176','1105.495667899175942','test','test','0.99'),('2019-01-17 15:59:59','2019-01-17 19:59:59','XLMBTC','4h','0.000029880000000','0.000029581200000','0.033907419193818','0.033568345001880','1134.7864522696786','1134.786452269678648','test','test','1.00'),('2019-02-19 11:59:59','2019-02-20 03:59:59','XLMBTC','4h','0.000022370000000','0.000022480000000','0.033832069373387','0.033998431806604','1512.3857565215617','1512.385756521561689','test','test','0.0'),('2019-02-20 11:59:59','2019-02-20 15:59:59','XLMBTC','4h','0.000022780000000','0.000022552200000','0.033869038802991','0.033530348414961','1486.7883583402597','1486.788358340259720','test','test','1.00'),('2019-02-21 07:59:59','2019-02-21 11:59:59','XLMBTC','4h','0.000023190000000','0.000022958100000','0.033793774272318','0.033455836529595','1457.2563291210772','1457.256329121077215','test','test','1.00'),('2019-02-23 19:59:59','2019-02-24 15:59:59','XLMBTC','4h','0.000022870000000','0.000022641300000','0.033718676996157','0.033381490226195','1474.3627895127727','1474.362789512772679','test','test','1.00'),('2019-02-25 19:59:59','2019-02-25 23:59:59','XLMBTC','4h','0.000022620000000','0.000022470000000','0.033643746602832','0.033420644834909','1487.345119488604','1487.345119488604041','test','test','0.66'),('2019-03-01 19:59:59','2019-03-01 23:59:59','XLMBTC','4h','0.000022290000000','0.000022170000000','0.033594168432183','0.033413311536182','1507.1408000081954','1507.140800008195356','test','test','0.53'),('2019-03-03 15:59:59','2019-03-04 03:59:59','XLMBTC','4h','0.000022850000000','0.000022621500000','0.033553978010849','0.033218438230741','1468.4454271706397','1468.445427170639732','test','test','0.99'),('2019-03-08 07:59:59','2019-03-21 15:59:59','XLMBTC','4h','0.000022390000000','0.000026230000000','0.033479413615270','0.039221305007974','1495.2842168499133','1495.284216849913264','test','test','0.31'),('2019-03-22 15:59:59','2019-03-23 07:59:59','XLMBTC','4h','0.000027200000000','0.000026928000000','0.034755389480315','0.034407835585512','1277.7716720704004','1277.771672070400427','test','test','1.00'),('2019-03-27 15:59:59','2019-03-28 07:59:59','XLMBTC','4h','0.000026410000000','0.000026340000000','0.034678155281470','0.034586240443541','1313.069113270344','1313.069113270343905','test','test','0.26'),('2019-04-01 03:59:59','2019-04-02 07:59:59','XLMBTC','4h','0.000026650000000','0.000026383500000','0.034657729761930','0.034311152464311','1300.477664612758','1300.477664612757962','test','test','1.00'),('2019-04-07 23:59:59','2019-04-08 03:59:59','XLMBTC','4h','0.000025560000000','0.000025304400000','0.034580712584681','0.034234905458834','1352.9230275696925','1352.923027569692522','test','test','1.00'),('2019-05-15 19:59:59','2019-05-15 23:59:59','XLMBTC','4h','0.000015500000000','0.000017320000000','0.034503866556715','0.038555288307245','2226.05590688486','2226.055906884860178','test','test','0.0'),('2019-05-16 03:59:59','2019-05-16 11:59:59','XLMBTC','4h','0.000018420000000','0.000018235800000','0.035404182501278','0.035050140676265','1922.051167278912','1922.051167278912089','test','test','1.00'),('2019-05-16 15:59:59','2019-05-16 19:59:59','XLMBTC','4h','0.000018910000000','0.000018720900000','0.035325506540164','0.034972251474762','1868.0860148156294','1868.086014815629369','test','test','1.00'),('2019-05-18 03:59:59','2019-05-18 07:59:59','XLMBTC','4h','0.000018890000000','0.000018701100000','0.035247005414519','0.034894535360374','1865.9081744054354','1865.908174405435375','test','test','1.00'),('2019-05-21 11:59:59','2019-05-22 11:59:59','XLMBTC','4h','0.000016880000000','0.000016711200000','0.035168678735820','0.034816991948462','2083.452531742878','2083.452531742877909','test','test','1.00');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 19:42:56
