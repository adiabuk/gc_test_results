-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-10 07:59:59','2018-04-12 11:59:59','OAXBTC','4h','0.000071170000000','0.000070990000000','0.033333333333333','0.033249028148564','468.36213760479603','468.362137604796033','test','test','0.25'),('2018-04-12 15:59:59','2018-04-12 23:59:59','OAXBTC','4h','0.000072730000000','0.000072002700000','0.033314598847829','0.032981452859351','458.0585569617641','458.058556961764111','test','test','1.00'),('2018-04-13 11:59:59','2018-04-14 15:59:59','OAXBTC','4h','0.000073090000000','0.000072540000000','0.033240566405945','0.032990432167017','454.7895253241907','454.789525324190720','test','test','0.75'),('2018-04-15 15:59:59','2018-04-15 19:59:59','OAXBTC','4h','0.000077400000000','0.000076626000000','0.033184981019517','0.032853131209322','428.7465247999569','428.746524799956887','test','test','1.00'),('2018-04-17 07:59:59','2018-04-17 23:59:59','OAXBTC','4h','0.000075770000000','0.000075012300000','0.033111236617251','0.032780124251078','436.9966558961476','436.996655896147615','test','test','1.00'),('2018-04-18 15:59:59','2018-04-21 11:59:59','OAXBTC','4h','0.000077020000000','0.000076249800000','0.033037656091435','0.032707279530521','428.94905338139296','428.949053381392957','test','test','0.99'),('2018-04-21 23:59:59','2018-04-22 03:59:59','OAXBTC','4h','0.000085560000000','0.000084704400000','0.032964239077898','0.032634596687119','385.27628655795274','385.276286557952744','test','test','1.00'),('2018-04-23 19:59:59','2018-04-25 03:59:59','OAXBTC','4h','0.000081660000000','0.000080843400000','0.032890985213281','0.032562075361148','402.77963768406676','402.779637684066756','test','test','1.00'),('2018-04-26 15:59:59','2018-05-03 19:59:59','OAXBTC','4h','0.000082050000000','0.000094540000000','0.032817894135029','0.037813573571306','399.97433436964184','399.974334369641838','test','test','0.30'),('2018-05-06 19:59:59','2018-05-06 23:59:59','OAXBTC','4h','0.000093470000000','0.000092535300000','0.033928045120868','0.033588764669659','362.98325795301645','362.983257953016448','test','test','0.99'),('2018-05-13 19:59:59','2018-05-13 23:59:59','OAXBTC','4h','0.000086900000000','0.000086031000000','0.033852649465044','0.033514122970394','389.5586819913029','389.558681991302876','test','test','0.99'),('2018-05-15 11:59:59','2018-05-15 19:59:59','OAXBTC','4h','0.000086960000000','0.000086090400000','0.033777421355122','0.033439647141571','388.4248085915593','388.424808591559326','test','test','0.99'),('2018-05-17 15:59:59','2018-05-17 19:59:59','OAXBTC','4h','0.000082440000000','0.000081615600000','0.033702360418777','0.033365336814589','408.8107765499434','408.810776549943398','test','test','1.00'),('2018-05-21 03:59:59','2018-05-21 15:59:59','OAXBTC','4h','0.000080890000000','0.000081130000000','0.033627466284513','0.033727238715077','415.71846068133675','415.718460681336751','test','test','0.27'),('2018-05-30 11:59:59','2018-05-30 15:59:59','OAXBTC','4h','0.000074200000000','0.000073458000000','0.033649637935750','0.033313141556392','453.49916355457924','453.499163554579241','test','test','1.00'),('2018-05-31 07:59:59','2018-06-04 11:59:59','OAXBTC','4h','0.000074400000000','0.000074100000000','0.033574860962559','0.033439478458678','451.27501293762236','451.275012937622364','test','test','0.40'),('2018-06-07 03:59:59','2018-06-07 07:59:59','OAXBTC','4h','0.000075010000000','0.000074259900000','0.033544775961697','0.033209328202080','447.2040522823178','447.204052282317775','test','test','0.99'),('2018-06-07 11:59:59','2018-06-07 15:59:59','OAXBTC','4h','0.000076450000000','0.000075685500000','0.033470232015115','0.033135529694964','437.8055201453905','437.805520145390517','test','test','1.00'),('2018-07-01 23:59:59','2018-07-02 07:59:59','OAXBTC','4h','0.000053950000000','0.000053410500000','0.033395853721748','0.033061895184531','619.0148975300876','619.014897530087637','test','test','0.99'),('2018-07-02 15:59:59','2018-07-03 23:59:59','OAXBTC','4h','0.000053700000000','0.000053470000000','0.033321640713478','0.033178922326809','620.5147246457686','620.514724645768638','test','test','0.42'),('2018-07-04 15:59:59','2018-07-05 19:59:59','OAXBTC','4h','0.000056930000000','0.000056360700000','0.033289925516440','0.032957026261276','584.7518973553526','584.751897355352639','test','test','1.00'),('2018-07-06 15:59:59','2018-07-06 23:59:59','OAXBTC','4h','0.000058370000000','0.000057786300000','0.033215947904182','0.032883788425140','569.0585558365865','569.058555836586493','test','test','0.99'),('2018-07-09 15:59:59','2018-07-09 19:59:59','OAXBTC','4h','0.000057790000000','0.000057212100000','0.033142134686617','0.032810713339751','573.4925538435137','573.492553843513747','test','test','1.0'),('2018-07-16 15:59:59','2018-07-16 19:59:59','OAXBTC','4h','0.000053930000000','0.000053730000000','0.033068485498424','0.032945850655114','613.1742165478254','613.174216547825381','test','test','0.37'),('2018-07-18 11:59:59','2018-07-18 15:59:59','OAXBTC','4h','0.000052550000000','0.000052670000000','0.033041233311022','0.033116684271961','628.7580078215415','628.758007821541469','test','test','0.0'),('2018-08-24 07:59:59','2018-08-24 11:59:59','OAXBTC','4h','0.000025720000000','0.000025462800000','0.033058000191231','0.032727420189319','1285.3032733759978','1285.303273375997833','test','test','1.00'),('2018-08-24 15:59:59','2018-08-24 19:59:59','OAXBTC','4h','0.000026400000000','0.000026136000000','0.032984537968584','0.032654692588898','1249.4143169918016','1249.414316991801570','test','test','0.99'),('2018-08-25 19:59:59','2018-08-26 03:59:59','OAXBTC','4h','0.000025400000000','0.000025320000000','0.032911238995320','0.032807581549665','1295.71807068189','1295.718070681889913','test','test','0.35'),('2018-08-28 03:59:59','2018-08-28 19:59:59','OAXBTC','4h','0.000026200000000','0.000025938000000','0.032888204007397','0.032559321967323','1255.2749621143764','1255.274962114376422','test','test','1.00'),('2018-08-31 23:59:59','2018-09-01 11:59:59','OAXBTC','4h','0.000025450000000','0.000025520000000','0.032815119109602','0.032905376804599','1289.3956428134557','1289.395642813455652','test','test','0.0'),('2018-09-03 15:59:59','2018-09-03 19:59:59','OAXBTC','4h','0.000026500000000','0.000026235000000','0.032835176375157','0.032506824611405','1239.0632594398994','1239.063259439899412','test','test','1.00'),('2018-09-03 23:59:59','2018-09-04 23:59:59','OAXBTC','4h','0.000026530000000','0.000026264700000','0.032762209316546','0.032434587223381','1234.911772203007','1234.911772203007104','test','test','0.99'),('2018-09-15 15:59:59','2018-09-15 23:59:59','OAXBTC','4h','0.000023710000000','0.000023472900000','0.032689404406954','0.032362510362884','1378.7180264425795','1378.718026442579458','test','test','1.00'),('2018-09-16 23:59:59','2018-09-18 03:59:59','OAXBTC','4h','0.000023730000000','0.000023492700000','0.032616761286049','0.032290593673189','1374.4947866013108','1374.494786601310807','test','test','0.99'),('2018-09-19 11:59:59','2018-09-19 23:59:59','OAXBTC','4h','0.000030320000000','0.000030016800000','0.032544279594302','0.032218836798359','1073.3601449308194','1073.360144930819388','test','test','1.00'),('2018-09-20 19:59:59','2018-09-21 03:59:59','OAXBTC','4h','0.000028410000000','0.000028125900000','0.032471958972982','0.032147239383252','1142.9763806047793','1142.976380604779251','test','test','0.99'),('2018-09-25 15:59:59','2018-09-25 19:59:59','OAXBTC','4h','0.000026960000000','0.000026690400000','0.032399799064153','0.032075801073511','1201.772962320211','1201.772962320211036','test','test','1.00'),('2018-09-25 23:59:59','2018-09-29 07:59:59','OAXBTC','4h','0.000026450000000','0.000028000000000','0.032327799510677','0.034222245228694','1222.223043881924','1222.223043881924013','test','test','0.0'),('2018-10-01 03:59:59','2018-10-01 11:59:59','OAXBTC','4h','0.000029060000000','0.000028769400000','0.032748787448014','0.032421299573534','1126.9369390231932','1126.936939023193190','test','test','1.00'),('2018-10-04 03:59:59','2018-10-04 07:59:59','OAXBTC','4h','0.000028720000000','0.000028490000000','0.032676012364796','0.032414331207278','1137.7441631196455','1137.744163119645464','test','test','0.80'),('2018-10-04 15:59:59','2018-10-04 19:59:59','OAXBTC','4h','0.000029310000000','0.000029016900000','0.032617860996459','0.032291682386494','1112.8577617352062','1112.857761735206168','test','test','0.99'),('2018-10-04 23:59:59','2018-10-05 03:59:59','OAXBTC','4h','0.000029470000000','0.000029175300000','0.032545376860911','0.032219923092302','1104.3561880187008','1104.356188018700777','test','test','0.99'),('2018-10-05 19:59:59','2018-10-14 23:59:59','OAXBTC','4h','0.000029420000000','0.000035900000000','0.032473053801220','0.039625514325758','1103.7747723052419','1103.774772305241868','test','test','0.0'),('2018-10-16 15:59:59','2018-10-16 19:59:59','OAXBTC','4h','0.000037290000000','0.000036917100000','0.034062489473340','0.033721864578607','913.4483634577574','913.448363457757409','test','test','0.99'),('2018-10-17 19:59:59','2018-10-17 23:59:59','OAXBTC','4h','0.000039420000000','0.000039025800000','0.033986795052288','0.033646927101765','862.1713610423136','862.171361042313606','test','test','0.99'),('2018-10-18 03:59:59','2018-10-18 07:59:59','OAXBTC','4h','0.000040990000000','0.000040580100000','0.033911268841061','0.033572156152650','827.3059000014799','827.305900001479927','test','test','0.99'),('2018-10-20 11:59:59','2018-10-20 23:59:59','OAXBTC','4h','0.000040180000000','0.000039778200000','0.033835910465858','0.033497551361199','842.1082744116032','842.108274411603247','test','test','1.00'),('2018-10-22 11:59:59','2018-10-22 23:59:59','OAXBTC','4h','0.000041340000000','0.000040926600000','0.033760719553712','0.033423112358175','816.6598827699993','816.659882769999285','test','test','0.99'),('2018-10-23 11:59:59','2018-10-24 03:59:59','OAXBTC','4h','0.000042920000000','0.000042490800000','0.033685695732481','0.033348838775156','784.8484560223982','784.848456022398182','test','test','0.99'),('2018-10-24 23:59:59','2018-10-25 07:59:59','OAXBTC','4h','0.000043290000000','0.000042857100000','0.033610838630854','0.033274730244545','776.4111487838657','776.411148783865656','test','test','1.00'),('2018-10-26 03:59:59','2018-10-26 07:59:59','OAXBTC','4h','0.000042560000000','0.000042134400000','0.033536147878340','0.033200786399557','787.9733993970967','787.973399397096728','test','test','0.99'),('2018-10-28 19:59:59','2018-10-29 11:59:59','OAXBTC','4h','0.000042660000000','0.000042233400000','0.033461623105278','0.033127006874225','784.3793508035055','784.379350803505531','test','test','1.00'),('2018-10-29 15:59:59','2018-10-29 19:59:59','OAXBTC','4h','0.000047330000000','0.000046856700000','0.033387263942821','0.033053391303393','705.41440825737','705.414408257370042','test','test','1.00'),('2018-10-30 11:59:59','2018-10-30 15:59:59','OAXBTC','4h','0.000043410000000','0.000042975900000','0.033313070022948','0.032979939322719','767.4054370640047','767.405437064004673','test','test','1.00'),('2018-11-06 15:59:59','2018-11-13 11:59:59','OAXBTC','4h','0.000040860000000','0.000044180000000','0.033239040978453','0.035939814743712','813.486073873057','813.486073873056966','test','test','0.0'),('2018-12-17 11:59:59','2018-12-17 15:59:59','OAXBTC','4h','0.000026080000000','0.000025819200000','0.033839212926288','0.033500820797025','1297.515833063207','1297.515833063207083','test','test','0.99'),('2018-12-17 23:59:59','2018-12-18 15:59:59','OAXBTC','4h','0.000025990000000','0.000025730100000','0.033764014675341','0.033426374528588','1299.1156089011583','1299.115608901158339','test','test','1.00'),('2018-12-24 07:59:59','2018-12-25 03:59:59','OAXBTC','4h','0.000024780000000','0.000024532200000','0.033688983531618','0.033352093696302','1359.5231449402027','1359.523144940202656','test','test','1.00'),('2018-12-26 15:59:59','2018-12-26 19:59:59','OAXBTC','4h','0.000024480000000','0.000024340000000','0.033614119123770','0.033421881514402','1373.1257811997639','1373.125781199763878','test','test','0.57'),('2019-01-02 07:59:59','2019-01-07 11:59:59','OAXBTC','4h','0.000023730000000','0.000024190000000','0.033571399655022','0.034222172678255','1414.7239635491687','1414.723963549168730','test','test','0.0'),('2019-01-14 19:59:59','2019-01-27 11:59:59','OAXBTC','4h','0.000023820000000','0.000039560000000','0.033716015882407','0.055995196822335','1415.4498691186773','1415.449869118677270','test','test','0.0'),('2019-01-27 23:59:59','2019-01-28 03:59:59','OAXBTC','4h','0.000042060000000','0.000041639400000','0.038666944980169','0.038280275530367','919.3282211167063','919.328221116706345','test','test','1.00'),('2019-02-02 11:59:59','2019-02-02 15:59:59','OAXBTC','4h','0.000040000000000','0.000039600000000','0.038581018435768','0.038195208251410','964.5254608942055','964.525460894205480','test','test','1.00'),('2019-02-10 23:59:59','2019-02-11 03:59:59','OAXBTC','4h','0.000036180000000','0.000035818200000','0.038495282839244','0.038110330010852','1063.9934449763468','1063.993444976346836','test','test','1.00'),('2019-02-11 15:59:59','2019-02-11 19:59:59','OAXBTC','4h','0.000037480000000','0.000037105200000','0.038409737766268','0.038025640388605','1024.8062370936025','1024.806237093602476','test','test','1.00'),('2019-02-12 19:59:59','2019-02-12 23:59:59','OAXBTC','4h','0.000037340000000','0.000036966600000','0.038324382793454','0.037941138965519','1026.3626886302684','1026.362688630268394','test','test','0.99'),('2019-02-13 15:59:59','2019-02-14 15:59:59','OAXBTC','4h','0.000036040000000','0.000035880000000','0.038239217498358','0.038069454046645','1061.0215732063693','1061.021573206369339','test','test','0.44'),('2019-02-25 15:59:59','2019-02-25 19:59:59','OAXBTC','4h','0.000033860000000','0.000033521400000','0.038201492286866','0.037819477363997','1128.2189098306492','1128.218909830649181','test','test','0.99'),('2019-03-01 19:59:59','2019-03-01 23:59:59','OAXBTC','4h','0.000033160000000','0.000033270000000','0.038116600081784','0.038243042361911','1149.4752738776774','1149.475273877677409','test','test','0.0'),('2019-03-02 23:59:59','2019-03-04 03:59:59','OAXBTC','4h','0.000033720000000','0.000033382800000','0.038144698366256','0.037763251382593','1131.218812759681','1131.218812759680986','test','test','1.00'),('2019-03-06 19:59:59','2019-03-07 11:59:59','OAXBTC','4h','0.000033860000000','0.000033521400000','0.038059932369887','0.037679333046188','1124.0381680415505','1124.038168041550534','test','test','0.99'),('2019-03-08 11:59:59','2019-03-09 19:59:59','OAXBTC','4h','0.000034730000000','0.000034382700000','0.037975354742398','0.037595601194974','1093.4452848372653','1093.445284837265262','test','test','1.00'),('2019-03-10 07:59:59','2019-03-10 19:59:59','OAXBTC','4h','0.000035410000000','0.000035055900000','0.037890965065193','0.037512055414541','1070.0639668227304','1070.063966822730436','test','test','0.99'),('2019-03-12 11:59:59','2019-03-18 07:59:59','OAXBTC','4h','0.000035100000000','0.000037600000000','0.037806762920604','0.040499552302413','1077.1157527237478','1077.115752723747846','test','test','0.0'),('2019-03-18 11:59:59','2019-03-18 19:59:59','OAXBTC','4h','0.000040500000000','0.000040095000000','0.038405160561006','0.038021108955396','948.2755694075445','948.275569407544481','test','test','1.00'),('2019-03-19 07:59:59','2019-03-19 11:59:59','OAXBTC','4h','0.000040490000000','0.000040085100000','0.038319815759759','0.037936617602161','946.4019698631486','946.401969863148565','test','test','1.00'),('2019-03-19 19:59:59','2019-03-20 03:59:59','OAXBTC','4h','0.000039730000000','0.000039332700000','0.038234660613626','0.037852314007490','962.3624619588724','962.362461958872359','test','test','0.99'),('2019-03-21 11:59:59','2019-03-21 15:59:59','OAXBTC','4h','0.000039480000000','0.000039085200000','0.038149694701151','0.037768197754139','966.3043237373691','966.304323737369145','test','test','0.99'),('2019-03-26 11:59:59','2019-03-26 15:59:59','OAXBTC','4h','0.000038230000000','0.000088340000000','0.038064917601815','0.087958535729645','995.681862459203','995.681862459202989','test','test','0.0'),('2019-03-26 19:59:59','2019-03-27 03:59:59','OAXBTC','4h','0.000091990000000','0.000091070100000','0.049152388296889','0.048660864413920','534.3231687888756','534.323168788875591','test','test','1.00'),('2019-03-27 07:59:59','2019-03-27 11:59:59','OAXBTC','4h','0.000109800000000','0.000108702000000','0.049043160767340','0.048552729159667','446.6590233819672','446.659023381967188','test','test','0.99'),('2019-04-01 03:59:59','2019-04-02 03:59:59','OAXBTC','4h','0.000054970000000','0.000054420300000','0.048934175965635','0.048444834205979','890.1978527494066','890.197852749406593','test','test','0.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 19:29:29
