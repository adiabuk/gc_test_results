-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-21 07:59:59','2018-03-21 11:59:59','BQXBTC','4h','0.000336980000000','0.000333610200000','0.033333333333333','0.033000000000000','98.91783884305696','98.917838843056956','test','test','1.00'),('2018-03-21 15:59:59','2018-03-21 19:59:59','BQXBTC','4h','0.000336710000000','0.000333342900000','0.033259259259259','0.032926666666666','98.777165095362','98.777165095361994','test','test','0.99'),('2018-03-24 19:59:59','2018-03-24 23:59:59','BQXBTC','4h','0.000331340000000','0.000328026600000','0.033185349794239','0.032853496296297','100.15497614003341','100.154976140033412','test','test','0.99'),('2018-03-25 15:59:59','2018-03-28 03:59:59','BQXBTC','4h','0.000347060000000','0.000343589400000','0.033111604572474','0.032780488526749','95.40599484951817','95.405994849518166','test','test','0.99'),('2018-04-11 15:59:59','2018-04-12 11:59:59','BQXBTC','4h','0.000295720000000','0.000296240000000','0.033038023228979','0.033096117953986','111.7206250134564','111.720625013456399','test','test','0.0'),('2018-04-13 15:59:59','2018-04-21 11:59:59','BQXBTC','4h','0.000304190000000','0.000325790000000','0.033050933167870','0.035397822139980','108.65226722729142','108.652267227291418','test','test','0.74'),('2018-04-23 03:59:59','2018-04-25 15:59:59','BQXBTC','4h','0.000342080000000','0.000356310000000','0.033572464050561','0.034969026736013','98.14214233676594','98.142142336765943','test','test','0.0'),('2018-04-28 03:59:59','2018-05-03 19:59:59','BQXBTC','4h','0.000371940000000','0.000375610000000','0.033882811313995','0.034217139209683','91.0975192611568','91.097519261156805','test','test','0.0'),('2018-05-08 07:59:59','2018-05-11 15:59:59','BQXBTC','4h','0.000381490000000','0.000398170000000','0.033957106401925','0.035441822999435','89.01178642146671','89.011786421466709','test','test','0.0'),('2018-05-31 15:59:59','2018-05-31 19:59:59','BQXBTC','4h','0.000342300000000','0.000338877000000','0.034287043423594','0.033944172989358','100.16664745426297','100.166647454262971','test','test','1.00'),('2018-06-02 11:59:59','2018-06-02 19:59:59','BQXBTC','4h','0.000318870000000','0.000320380000000','0.034210849993764','0.034372854520658','107.28776615474644','107.287766154746436','test','test','0.78'),('2018-06-03 07:59:59','2018-06-03 19:59:59','BQXBTC','4h','0.000325610000000','0.000322353900000','0.034246850999740','0.033904382489743','105.17751604600731','105.177516046007312','test','test','1.00'),('2018-06-03 23:59:59','2018-06-04 03:59:59','BQXBTC','4h','0.000321970000000','0.000318750300000','0.034170746886408','0.033829039417544','106.13021985404782','106.130219854047823','test','test','1.00'),('2018-06-09 03:59:59','2018-06-09 07:59:59','BQXBTC','4h','0.000319120000000','0.000315928800000','0.034094811893327','0.033753863774394','106.84009743459163','106.840097434591627','test','test','1.00'),('2018-06-09 11:59:59','2018-06-10 03:59:59','BQXBTC','4h','0.000322350000000','0.000319126500000','0.034019045644675','0.033678855188228','105.53449866503834','105.534498665038342','test','test','1.00'),('2018-06-28 15:59:59','2018-06-28 19:59:59','BQXBTC','4h','0.000242090000000','0.000239669100000','0.033943447765465','0.033604013287810','140.2100366205323','140.210036620532293','test','test','1.00'),('2018-06-29 07:59:59','2018-06-30 15:59:59','BQXBTC','4h','0.000227610000000','0.000225333900000','0.033868017881541','0.033529337702726','148.79846176152776','148.798461761527761','test','test','1.00'),('2018-07-02 19:59:59','2018-07-02 23:59:59','BQXBTC','4h','0.000260250000000','0.000257647500000','0.033792755619582','0.033454828063386','129.84728384085471','129.847283840854715','test','test','0.99'),('2018-07-04 11:59:59','2018-07-07 23:59:59','BQXBTC','4h','0.000238620000000','0.000254330000000','0.033717660607094','0.035937526704393','141.30274330355564','141.302743303555644','test','test','0.0'),('2018-08-17 11:59:59','2018-08-17 15:59:59','BQXBTC','4h','0.000080770000000','0.000079962300000','0.034210964184272','0.033868854542429','423.56028456446694','423.560284564466940','test','test','1.00'),('2018-08-17 19:59:59','2018-08-18 03:59:59','BQXBTC','4h','0.000081640000000','0.000080823600000','0.034134939819418','0.033793590421224','418.11538240345425','418.115382403454248','test','test','1.00'),('2018-08-19 19:59:59','2018-08-19 23:59:59','BQXBTC','4h','0.000076880000000','0.000076111200000','0.034059084397597','0.033718493553621','443.0161862330529','443.016186233052906','test','test','1.00'),('2018-08-26 15:59:59','2018-08-26 19:59:59','BQXBTC','4h','0.000073090000000','0.000072359100000','0.033983397543380','0.033643563567946','464.95276430948445','464.952764309484451','test','test','0.99'),('2018-08-27 03:59:59','2018-08-27 15:59:59','BQXBTC','4h','0.000077010000000','0.000076239900000','0.033907878882173','0.033568800093351','440.30488095276803','440.304880952768031','test','test','1.00'),('2018-08-28 11:59:59','2018-08-29 07:59:59','BQXBTC','4h','0.000077600000000','0.000076824000000','0.033832528040212','0.033494202759810','435.98618608520894','435.986186085208942','test','test','1.00'),('2018-09-26 19:59:59','2018-09-26 23:59:59','BQXBTC','4h','0.000052020000000','0.000051499800000','0.033757344644567','0.033419771198121','648.9301161969883','648.930116196988251','test','test','1.00'),('2018-09-27 11:59:59','2018-09-27 19:59:59','BQXBTC','4h','0.000054500000000','0.000053955000000','0.033682328323135','0.033345505039904','618.0243729015576','618.024372901557626','test','test','1.00'),('2018-10-02 03:59:59','2018-10-02 07:59:59','BQXBTC','4h','0.000051730000000','0.000051212700000','0.033607478704639','0.033271403917593','649.6709589143459','649.670958914345874','test','test','1.00'),('2018-10-05 03:59:59','2018-10-05 23:59:59','BQXBTC','4h','0.000051080000000','0.000050710000000','0.033532795418629','0.033289899288933','656.4760262065171','656.476026206517076','test','test','0.72'),('2018-10-06 03:59:59','2018-10-09 11:59:59','BQXBTC','4h','0.000051330000000','0.000050816700000','0.033478818500919','0.033144030315910','652.2271284028574','652.227128402857375','test','test','1.00'),('2018-10-13 15:59:59','2018-10-15 07:59:59','BQXBTC','4h','0.000053100000000','0.000054200000000','0.033404421126472','0.034096414784459','629.0851436247121','629.085143624712146','test','test','0.0'),('2018-10-19 15:59:59','2018-10-26 15:59:59','BQXBTC','4h','0.000058270000000','0.000060550000000','0.033558197494914','0.034871269234890','575.9086578842247','575.908657884224681','test','test','0.0'),('2018-11-01 07:59:59','2018-11-01 11:59:59','BQXBTC','4h','0.000060980000000','0.000060370200000','0.033849991214908','0.033511491302759','555.0998887325097','555.099888732509726','test','test','1.00'),('2018-11-01 19:59:59','2018-11-02 15:59:59','BQXBTC','4h','0.000061560000000','0.000061530000000','0.033774769012209','0.033758309573119','548.6479696590102','548.647969659010187','test','test','0.40'),('2018-11-12 03:59:59','2018-11-12 07:59:59','BQXBTC','4h','0.000055370000000','0.000055060000000','0.033771111359078','0.033582037049500','609.9171276698131','609.917127669813112','test','test','0.55'),('2018-12-15 15:59:59','2018-12-15 19:59:59','BQXBTC','4h','0.000028200000000','0.000027918000000','0.033729094845838','0.033391803897380','1196.0671931148229','1196.067193114822885','test','test','1.00'),('2018-12-15 23:59:59','2018-12-16 15:59:59','BQXBTC','4h','0.000028040000000','0.000027759600000','0.033654141301736','0.033317599888719','1200.2190193201222','1200.219019320122243','test','test','1.00'),('2018-12-21 03:59:59','2018-12-25 11:59:59','BQXBTC','4h','0.000027980000000','0.000028720000000','0.033579354321066','0.034467443034347','1200.1198828115002','1200.119882811500247','test','test','0.0'),('2018-12-28 03:59:59','2019-01-01 23:59:59','BQXBTC','4h','0.000028880000000','0.000030720000000','0.033776707368462','0.035928685954264','1169.5535792403584','1169.553579240358431','test','test','0.0'),('2019-01-09 07:59:59','2019-01-09 11:59:59','BQXBTC','4h','0.000032010000000','0.000031689900000','0.034254924831973','0.033912375583653','1070.131984753924','1070.131984753923916','test','test','0.99'),('2019-01-15 03:59:59','2019-01-15 07:59:59','BQXBTC','4h','0.000029610000000','0.000029313900000','0.034178802776791','0.033837014749023','1154.2993170142142','1154.299317014214239','test','test','0.99'),('2019-01-15 15:59:59','2019-01-15 19:59:59','BQXBTC','4h','0.000029430000000','0.000029280000000','0.034102849881731','0.033929033113730','1158.7784533377958','1158.778453337795781','test','test','0.50'),('2019-01-15 23:59:59','2019-01-24 07:59:59','BQXBTC','4h','0.000029500000000','0.000047060000000','0.034064223933287','0.054341097569508','1154.7194553656498','1154.719455365649765','test','test','0.0'),('2019-01-25 03:59:59','2019-01-25 07:59:59','BQXBTC','4h','0.000050120000000','0.000049618800000','0.038570195852447','0.038184493893923','769.5569802962267','769.556980296226698','test','test','1.00'),('2019-01-25 19:59:59','2019-01-26 03:59:59','BQXBTC','4h','0.000050100000000','0.000049599000000','0.038484484306108','0.038099639463047','768.1533793634376','768.153379363437580','test','test','1.00'),('2019-01-26 11:59:59','2019-01-26 19:59:59','BQXBTC','4h','0.000049760000000','0.000049262400000','0.038398963229872','0.038014973597573','771.6833446517774','771.683344651777361','test','test','1.00'),('2019-01-29 11:59:59','2019-01-29 15:59:59','BQXBTC','4h','0.000047280000000','0.000046807200000','0.038313632200473','0.037930495878468','810.3560110083051','810.356011008305131','test','test','0.99'),('2019-02-12 23:59:59','2019-02-13 03:59:59','BQXBTC','4h','0.000041550000000','0.000041134500000','0.038228490795583','0.037846205887627','920.0599469454313','920.059946945431307','test','test','1.00'),('2019-02-13 19:59:59','2019-02-13 23:59:59','BQXBTC','4h','0.000040520000000','0.000040170000000','0.038143538593815','0.037814065777728','941.3509031050019','941.350903105001862','test','test','0.86'),('2019-02-16 07:59:59','2019-02-16 11:59:59','BQXBTC','4h','0.000040480000000','0.000040075200000','0.038070322412462','0.037689619188337','940.4723916122035','940.472391612203523','test','test','0.99'),('2019-02-17 03:59:59','2019-02-17 15:59:59','BQXBTC','4h','0.000040660000000','0.000040320000000','0.037985721695990','0.037668084082202','934.2282758482484','934.228275848248359','test','test','0.83'),('2019-02-17 23:59:59','2019-02-18 15:59:59','BQXBTC','4h','0.000040540000000','0.000040134600000','0.037915135559592','0.037535984203996','935.2524805030205','935.252480503020479','test','test','1.00'),('2019-02-18 19:59:59','2019-02-18 23:59:59','BQXBTC','4h','0.000040340000000','0.000040580000000','0.037830879702793','0.038055951867609','937.8006867326061','937.800686732606096','test','test','0.0'),('2019-02-24 19:59:59','2019-02-24 23:59:59','BQXBTC','4h','0.000040120000000','0.000039718800000','0.037880895739419','0.037502086782025','944.1898240134375','944.189824013437487','test','test','0.99'),('2019-03-08 03:59:59','2019-03-08 07:59:59','BQXBTC','4h','0.000038300000000','0.000038190000000','0.037796715971109','0.037688161434377','986.8594248331418','986.859424833141816','test','test','0.28'),('2019-03-08 11:59:59','2019-03-08 19:59:59','BQXBTC','4h','0.000039030000000','0.000038639700000','0.037772592740724','0.037394866813317','967.783570092863','967.783570092862988','test','test','1.00'),('2019-03-09 03:59:59','2019-03-09 15:59:59','BQXBTC','4h','0.000038660000000','0.000039170000000','0.037688653645745','0.038185839712981','974.8746416385184','974.874641638518369','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 18:48:32
