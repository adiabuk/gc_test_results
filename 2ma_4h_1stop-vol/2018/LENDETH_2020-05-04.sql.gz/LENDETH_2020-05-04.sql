-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-30 07:59:59','2018-05-30 11:59:59','LENDETH','4h','0.000081700000000','0.000080883000000','1.297777777777778','1.284800000000000','15884.672922616619','15884.672922616618962','test','test','1.00'),('2018-06-01 19:59:59','2018-06-02 03:59:59','LENDETH','4h','0.000080600000000','0.000080630000000','1.294893827160494','1.295375797567626','16065.680237723249','16065.680237723248865','test','test','0.23'),('2018-06-02 15:59:59','2018-06-03 11:59:59','LENDETH','4h','0.000080830000000','0.000080021700000','1.295000931695412','1.282050922378458','16021.290754613534','16021.290754613533863','test','test','1.00'),('2018-06-09 07:59:59','2018-06-09 11:59:59','LENDETH','4h','0.000077580000000','0.000077610000000','1.292123151847200','1.292622812772122','16655.364164052593','16655.364164052592969','test','test','0.0'),('2018-06-09 19:59:59','2018-06-09 23:59:59','LENDETH','4h','0.000077810000000','0.000077031900000','1.292234187608294','1.279311845732211','16607.559280404752','16607.559280404751917','test','test','1.00'),('2018-06-28 11:59:59','2018-06-28 15:59:59','LENDETH','4h','0.000059100000000','0.000058509000000','1.289362556080275','1.276468930519472','21816.62531438706','21816.625314387059916','test','test','1.00'),('2018-06-30 19:59:59','2018-06-30 23:59:59','LENDETH','4h','0.000061610000000','0.000060993900000','1.286497305955652','1.273632332896095','20881.30670273742','20881.306702737419982','test','test','1.00'),('2018-07-01 15:59:59','2018-07-01 19:59:59','LENDETH','4h','0.000064410000000','0.000063765900000','1.283638423053529','1.270802038822994','19929.17905687826','19929.179056878259871','test','test','0.99'),('2018-07-01 23:59:59','2018-07-02 11:59:59','LENDETH','4h','0.000072260000000','0.000071537400000','1.280785893224521','1.267978034292276','17724.687146755066','17724.687146755066351','test','test','0.99'),('2018-07-03 15:59:59','2018-07-03 23:59:59','LENDETH','4h','0.000077040000000','0.000076269600000','1.277939702350689','1.265160305327182','16588.002366961176','16588.002366961176449','test','test','0.99'),('2018-07-07 19:59:59','2018-07-07 23:59:59','LENDETH','4h','0.000065610000000','0.000065960000000','1.275099836345465','1.281901923568768','19434.534923722982','19434.534923722982057','test','test','0.0'),('2018-07-17 19:59:59','2018-07-20 03:59:59','LENDETH','4h','0.000061040000000','0.000061200000000','1.276611411283977','1.279957705940030','20914.341600327272','20914.341600327272317','test','test','0.0'),('2018-07-30 15:59:59','2018-07-31 11:59:59','LENDETH','4h','0.000059700000000','0.000059103000000','1.277355032318655','1.264581481995469','21396.2316971299','21396.231697129900567','test','test','1.00'),('2018-08-17 11:59:59','2018-08-17 15:59:59','LENDETH','4h','0.000048690000000','0.000048203100000','1.274516465580170','1.261771300924368','26176.144292055236','26176.144292055236292','test','test','1.00'),('2018-08-26 11:59:59','2018-08-30 11:59:59','LENDETH','4h','0.000047950000000','0.000048010000000','1.271684206767769','1.273275469591670','26521.047065021252','26521.047065021251910','test','test','0.66'),('2018-08-31 07:59:59','2018-08-31 11:59:59','LENDETH','4h','0.000051430000000','0.000050915700000','1.272037820728636','1.259317442521350','24733.381698009634','24733.381698009634420','test','test','1.00'),('2018-09-01 19:59:59','2018-09-02 11:59:59','LENDETH','4h','0.000051500000000','0.000050985000000','1.269211070015906','1.256518959315747','24644.875145939917','24644.875145939917275','test','test','0.99'),('2018-09-03 15:59:59','2018-09-12 11:59:59','LENDETH','4h','0.000050320000000','0.000057810000000','1.266390600971426','1.454889519915702','25166.744852373326','25166.744852373325557','test','test','0.0'),('2018-09-16 15:59:59','2018-09-21 19:59:59','LENDETH','4h','0.000056340000000','0.000058450000000','1.308279249625709','1.357275863340836','23221.14394081841','23221.143940818408737','test','test','0.0'),('2018-09-25 03:59:59','2018-09-25 07:59:59','LENDETH','4h','0.000059960000000','0.000059360400000','1.319167386006849','1.305975712146780','22000.79029364324','22000.790293643240148','test','test','1.00'),('2018-09-25 11:59:59','2018-09-25 15:59:59','LENDETH','4h','0.000064640000000','0.000063993600000','1.316235902926833','1.303073543897565','20362.560379437396','20362.560379437396477','test','test','0.99'),('2018-09-26 11:59:59','2018-09-26 15:59:59','LENDETH','4h','0.000062390000000','0.000061766100000','1.313310934253663','1.300177824911126','21050.022988518394','21050.022988518394413','test','test','1.00'),('2018-09-27 15:59:59','2018-09-27 19:59:59','LENDETH','4h','0.000062950000000','0.000062320500000','1.310392465510877','1.297288540855768','20816.401358393596','20816.401358393595729','test','test','1.00'),('2018-09-27 23:59:59','2018-09-28 03:59:59','LENDETH','4h','0.000062910000000','0.000062280900000','1.307480482254186','1.294405677431644','20783.348946974813','20783.348946974812861','test','test','1.00'),('2018-09-28 07:59:59','2018-09-29 15:59:59','LENDETH','4h','0.000064360000000','0.000063716400000','1.304574970071399','1.291529220370685','20269.965352259147','20269.965352259147039','test','test','1.00'),('2018-09-30 03:59:59','2018-09-30 11:59:59','LENDETH','4h','0.000065790000000','0.000065132100000','1.301675914582351','1.288659155436528','19785.31561912678','19785.315619126780803','test','test','0.99'),('2018-10-02 03:59:59','2018-10-02 07:59:59','LENDETH','4h','0.000062840000000','0.000062211600000','1.298783301438835','1.285795468424447','20668.09836789998','20668.098367899980076','test','test','0.99'),('2018-10-02 15:59:59','2018-10-02 19:59:59','LENDETH','4h','0.000064770000000','0.000064122300000','1.295897116324526','1.282938145161281','20007.67510150573','20007.675101505730709','test','test','1.00'),('2018-10-02 23:59:59','2018-10-11 23:59:59','LENDETH','4h','0.000064380000000','0.000073780000000','1.293017344954916','1.481808321074459','20084.14639569612','20084.146395696119725','test','test','0.0'),('2018-10-12 07:59:59','2018-10-13 11:59:59','LENDETH','4h','0.000074550000000','0.000073804500000','1.334970895203704','1.321621186251667','17907.054261619098','17907.054261619097815','test','test','1.00'),('2018-10-13 15:59:59','2018-10-15 07:59:59','LENDETH','4h','0.000075280000000','0.000074527200000','1.332004293214362','1.318684250282218','17693.999644186533','17693.999644186533260','test','test','0.99'),('2018-10-15 15:59:59','2018-10-15 19:59:59','LENDETH','4h','0.000075400000000','0.000074646000000','1.329044283673886','1.315753840837147','17626.582011589995','17626.582011589995091','test','test','0.99'),('2018-10-17 19:59:59','2018-10-26 11:59:59','LENDETH','4h','0.000075080000000','0.000090340000000','1.326090851932388','1.595618640963931','17662.371496169257','17662.371496169256716','test','test','0.0'),('2018-10-27 07:59:59','2018-11-04 07:59:59','LENDETH','4h','0.000099100000000','0.000102640000000','1.385985916161620','1.435495402975062','13985.730738260545','13985.730738260544967','test','test','0.0'),('2018-11-28 19:59:59','2018-11-30 11:59:59','LENDETH','4h','0.000076150000000','0.000075388500000','1.396988024342385','1.383018144098961','18345.21371427951','18345.213714279510896','test','test','0.99'),('2018-12-01 15:59:59','2018-12-02 11:59:59','LENDETH','4h','0.000081950000000','0.000081130500000','1.393883606510513','1.379944770445408','17008.95187932291','17008.951879322910827','test','test','1.00'),('2018-12-02 15:59:59','2018-12-04 07:59:59','LENDETH','4h','0.000081830000000','0.000081011700000','1.390786087384934','1.376878226511085','16996.041639801224','16996.041639801223937','test','test','0.99'),('2018-12-06 07:59:59','2018-12-06 11:59:59','LENDETH','4h','0.000079820000000','0.000079021800000','1.387695451635190','1.373818497118838','17385.310093149455','17385.310093149455497','test','test','1.00'),('2018-12-12 19:59:59','2018-12-13 03:59:59','LENDETH','4h','0.000078200000000','0.000077418000000','1.384611683964889','1.370765567125240','17706.0317642569','17706.031764256898896','test','test','1.00'),('2018-12-13 19:59:59','2018-12-13 23:59:59','LENDETH','4h','0.000078380000000','0.000077596200000','1.381534769111634','1.367719421420518','17626.113410457183','17626.113410457182908','test','test','0.99'),('2018-12-14 11:59:59','2018-12-14 15:59:59','LENDETH','4h','0.000076590000000','0.000077700000000','1.378464691846941','1.398442441004143','17997.972213695542','17997.972213695542450','test','test','0.0'),('2018-12-14 23:59:59','2018-12-19 15:59:59','LENDETH','4h','0.000078520000000','0.000080500000000','1.382904191659653','1.417776202605732','17612.126740443877','17612.126740443876770','test','test','0.02'),('2018-12-20 11:59:59','2018-12-20 19:59:59','LENDETH','4h','0.000081650000000','0.000080833500000','1.390653527425448','1.376746992151194','17031.886435094282','17031.886435094282206','test','test','0.99'),('2019-01-11 11:59:59','2019-01-11 15:59:59','LENDETH','4h','0.000056430000000','0.000056130000000','1.387563186253392','1.380186454800689','24589.10484234258','24589.104842342578195','test','test','0.53'),('2019-01-12 19:59:59','2019-01-27 19:59:59','LENDETH','4h','0.000057470000000','0.000071400000000','1.385923912597236','1.721854312849185','24115.6066225376','24115.606622537601652','test','test','0.0'),('2019-01-28 15:59:59','2019-01-28 19:59:59','LENDETH','4h','0.000070110000000','0.000069690000000','1.460575112653224','1.451825411507676','20832.621775113737','20832.621775113737385','test','test','0.59'),('2019-01-29 11:59:59','2019-01-30 15:59:59','LENDETH','4h','0.000070100000000','0.000070520000000','1.458630734620880','1.467370034314757','20807.856413992587','20807.856413992587477','test','test','0.0'),('2019-02-01 19:59:59','2019-02-02 07:59:59','LENDETH','4h','0.000072100000000','0.000071379000000','1.460572801219520','1.445967073207325','20257.5977977742','20257.597797774200444','test','test','0.99'),('2019-02-02 19:59:59','2019-02-02 23:59:59','LENDETH','4h','0.000073720000000','0.000072982800000','1.457327083883476','1.442753813044641','19768.408625657572','19768.408625657571974','test','test','1.00'),('2019-02-28 07:59:59','2019-02-28 11:59:59','LENDETH','4h','0.000057260000000','0.000056687400000','1.454088579252624','1.439547693460098','25394.491429490467','25394.491429490466544','test','test','1.00'),('2019-03-01 19:59:59','2019-03-01 23:59:59','LENDETH','4h','0.000057900000000','0.000057321000000','1.450857271298729','1.436348698585742','25057.983960254394','25057.983960254394333','test','test','1.00'),('2019-03-02 11:59:59','2019-03-06 15:59:59','LENDETH','4h','0.000058620000000','0.000061610000000','1.447633144029177','1.521471818554036','24695.208871190323','24695.208871190323407','test','test','0.0'),('2019-03-08 07:59:59','2019-03-16 23:59:59','LENDETH','4h','0.000063930000000','0.000066770000000','1.464041738368034','1.529079725806876','22900.699802409417','22900.699802409417316','test','test','0.67'),('2019-03-26 19:59:59','2019-04-02 07:59:59','LENDETH','4h','0.000065560000000','0.000071990000000','1.478494624465555','1.623502562771130','22551.778896668005','22551.778896668005473','test','test','0.0'),('2019-04-04 15:59:59','2019-04-05 07:59:59','LENDETH','4h','0.000070120000000','0.000069418800000','1.510718610755682','1.495611424648125','21544.760564114127','21544.760564114127192','test','test','1.00'),('2019-04-05 15:59:59','2019-04-06 03:59:59','LENDETH','4h','0.000072970000000','0.000072240300000','1.507361458287336','1.492287843704463','20657.276391494262','20657.276391494262498','test','test','0.99'),('2019-04-07 23:59:59','2019-04-08 03:59:59','LENDETH','4h','0.000070280000000','0.000069577200000','1.504011766157809','1.488971648496231','21400.281248688236','21400.281248688235792','test','test','0.99'),('2019-04-14 15:59:59','2019-04-15 11:59:59','LENDETH','4h','0.000066910000000','0.000066740000000','1.500669517788570','1.496856727203844','22428.179910156476','22428.179910156475671','test','test','0.40'),('2019-04-18 23:59:59','2019-04-19 03:59:59','LENDETH','4h','0.000066800000000','0.000066132000000','1.499822230991964','1.484824008682044','22452.428607664133','22452.428607664132869','test','test','1.00'),('2019-04-19 07:59:59','2019-04-19 15:59:59','LENDETH','4h','0.000067210000000','0.000066537900000','1.496489292700870','1.481524399773861','22265.872529398457','22265.872529398457118','test','test','1.00'),('2019-05-20 15:59:59','2019-05-20 19:59:59','LENDETH','4h','0.000039490000000','0.000039095100000','1.493163760939313','1.478232123329920','37811.18665331256','37811.186653312557610','test','test','0.99'),('2019-05-22 19:59:59','2019-05-22 23:59:59','LENDETH','4h','0.000041190000000','0.000040778100000','1.489845619248337','1.474947163055853','36170.080583839204','36170.080583839204337','test','test','1.00'),('2019-05-26 11:59:59','2019-05-26 15:59:59','LENDETH','4h','0.000038600000000','0.000038980000000','1.486534851205563','1.501169132124167','38511.26557527364','38511.265575273639115','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 18:51:53
