-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-27 19:59:59','2018-02-27 23:59:59','MCOBTC','4h','0.000812000000000','0.000803880000000','0.033333333333333','0.033000000000000','41.050903119868636','41.050903119868636','test','test','1.00'),('2018-03-03 03:59:59','2018-03-06 03:59:59','MCOBTC','4h','0.000789000000000','0.000781110000000','0.033259259259259','0.032926666666666','42.153687274092945','42.153687274092945','test','test','0.99'),('2018-03-07 11:59:59','2018-03-07 15:59:59','MCOBTC','4h','0.000803000000000','0.000794970000000','0.033185349794239','0.032853496296297','41.32671207252636','41.326712072526362','test','test','1.00'),('2018-03-11 07:59:59','2018-03-15 03:59:59','MCOBTC','4h','0.000788000000000','0.000824000000000','0.033111604572474','0.034624317471724','42.01980275694641','42.019802756946412','test','test','0.0'),('2018-04-03 07:59:59','2018-04-06 03:59:59','MCOBTC','4h','0.000719000000000','0.000711810000000','0.033447762994529','0.033113285364584','46.519837266382936','46.519837266382936','test','test','1.00'),('2018-04-07 11:59:59','2018-04-09 15:59:59','MCOBTC','4h','0.000728000000000','0.000720720000000','0.033373434632319','0.033039700285996','45.84262998944963','45.842629989449627','test','test','1.00'),('2018-04-10 07:59:59','2018-04-12 11:59:59','MCOBTC','4h','0.000764000000000','0.000756360000000','0.033299271444248','0.032966278729806','43.58543382754915','43.585433827549153','test','test','1.00'),('2018-04-12 15:59:59','2018-04-25 03:59:59','MCOBTC','4h','0.000776000000000','0.001274000000000','0.033225273063260','0.054547677683754','42.81607353512944','42.816073535129441','test','test','0.0'),('2018-04-27 07:59:59','2018-04-27 11:59:59','MCOBTC','4h','0.001367000000000','0.001353330000000','0.037963585201148','0.037583949349137','27.771459547291883','27.771459547291883','test','test','0.99'),('2018-04-28 19:59:59','2018-04-28 23:59:59','MCOBTC','4h','0.001355000000000','0.001341450000000','0.037879221678479','0.037500429461694','27.95514515016892','27.955145150168921','test','test','0.99'),('2018-05-07 23:59:59','2018-05-08 03:59:59','MCOBTC','4h','0.001288000000000','0.001275120000000','0.037795045630304','0.037417095174001','29.343979526633884','29.343979526633884','test','test','1.00'),('2018-05-13 15:59:59','2018-05-13 19:59:59','MCOBTC','4h','0.001253000000000','0.001240470000000','0.037711056640015','0.037333946073615','30.096613439756496','30.096613439756496','test','test','0.99'),('2018-05-14 11:59:59','2018-05-14 15:59:59','MCOBTC','4h','0.001244000000000','0.001258000000000','0.037627254291926','0.038050712137655','30.24698898064791','30.246988980647910','test','test','0.0'),('2018-05-14 19:59:59','2018-05-14 23:59:59','MCOBTC','4h','0.001292000000000','0.001279080000000','0.037721356035421','0.037344142475067','29.196096002648094','29.196096002648094','test','test','1.00'),('2018-05-15 11:59:59','2018-05-15 15:59:59','MCOBTC','4h','0.001309000000000','0.001295910000000','0.037637530799787','0.037261155491789','28.752888311525677','28.752888311525677','test','test','1.00'),('2018-05-16 07:59:59','2018-05-16 11:59:59','MCOBTC','4h','0.001282000000000','0.001269180000000','0.037553891842454','0.037178352924029','29.29320736540891','29.293207365408911','test','test','0.99'),('2018-05-17 03:59:59','2018-05-17 11:59:59','MCOBTC','4h','0.001206000000000','0.001193940000000','0.037470438749471','0.037095734361976','31.070015546824948','31.070015546824948','test','test','0.99'),('2018-06-03 19:59:59','2018-06-04 07:59:59','MCOBTC','4h','0.000945000000000','0.000935550000000','0.037387171107805','0.037013299396727','39.56314402942363','39.563144029423633','test','test','1.00'),('2018-06-22 23:59:59','2018-06-23 03:59:59','MCOBTC','4h','0.000807000000000','0.000798930000000','0.037304088505344','0.036931047620291','46.225636313932526','46.225636313932526','test','test','0.99'),('2018-06-25 15:59:59','2018-07-10 15:59:59','MCOBTC','4h','0.000795000000000','0.001326000000000','0.037221190530887','0.062082136659064','46.819107586021794','46.819107586021794','test','test','0.0'),('2018-07-16 07:59:59','2018-07-17 07:59:59','MCOBTC','4h','0.001144000000000','0.001146000000000','0.042745845226038','0.042820575724685','37.365249323459594','37.365249323459594','test','test','0.78'),('2018-07-22 23:59:59','2018-07-23 03:59:59','MCOBTC','4h','0.001083000000000','0.001072170000000','0.042762452003515','0.042334827483480','39.485181905369245','39.485181905369245','test','test','1.00'),('2018-09-04 07:59:59','2018-09-04 11:59:59','MCOBTC','4h','0.000681000000000','0.000674190000000','0.042667424332396','0.042240750089072','62.65407390953892','62.654073909538923','test','test','0.99'),('2018-09-04 15:59:59','2018-09-04 19:59:59','MCOBTC','4h','0.000683000000000','0.000676170000000','0.042572607833880','0.042146881755541','62.33178306570945','62.331783065709452','test','test','0.99'),('2018-09-04 23:59:59','2018-09-05 11:59:59','MCOBTC','4h','0.000694000000000','0.000687060000000','0.042478002038693','0.042053222018306','61.2074957329872','61.207495732987198','test','test','0.99'),('2018-09-06 15:59:59','2018-09-06 19:59:59','MCOBTC','4h','0.000759000000000','0.000751410000000','0.042383606478607','0.041959770413821','55.84137875969316','55.841378759693157','test','test','1.00'),('2018-09-10 07:59:59','2018-09-11 15:59:59','MCOBTC','4h','0.000693000000000','0.000686070000000','0.042289420686432','0.041866526479568','61.02369507421708','61.023695074217081','test','test','1.00'),('2018-09-13 11:59:59','2018-09-13 19:59:59','MCOBTC','4h','0.000689000000000','0.000682110000000','0.042195444196018','0.041773489754058','61.24157357912659','61.241573579126587','test','test','0.99'),('2018-09-14 19:59:59','2018-09-14 23:59:59','MCOBTC','4h','0.000692000000000','0.000685080000000','0.042101676542249','0.041680659776827','60.84057303793255','60.840573037932550','test','test','0.99'),('2018-09-18 15:59:59','2018-09-18 23:59:59','MCOBTC','4h','0.000682000000000','0.000675180000000','0.042008117261044','0.041588036088434','61.59547985490387','61.595479854903871','test','test','1.00'),('2018-09-20 03:59:59','2018-09-20 11:59:59','MCOBTC','4h','0.000684000000000','0.000677160000000','0.041914765889353','0.041495618230459','61.278897499054565','61.278897499054565','test','test','1.00'),('2018-09-20 23:59:59','2018-09-21 03:59:59','MCOBTC','4h','0.000680000000000','0.000673200000000','0.041821621965155','0.041403405745503','61.502385242874496','61.502385242874496','test','test','1.00'),('2018-09-21 07:59:59','2018-09-21 11:59:59','MCOBTC','4h','0.000680000000000','0.000676000000000','0.041728685027454','0.041483222174351','61.365713275667964','61.365713275667964','test','test','0.58'),('2018-09-25 23:59:59','2018-09-26 03:59:59','MCOBTC','4h','0.000678000000000','0.000671220000000','0.041674137726765','0.041257396349497','61.46627983298622','61.466279832986217','test','test','0.99'),('2018-09-26 15:59:59','2018-09-27 03:59:59','MCOBTC','4h','0.000682000000000','0.000681000000000','0.041581528531816','0.041520558548632','60.96998318448126','60.969983184481258','test','test','0.43'),('2018-09-27 15:59:59','2018-09-27 23:59:59','MCOBTC','4h','0.000677000000000','0.000671000000000','0.041567979646664','0.041199578054522','61.4002653569634','61.400265356963402','test','test','0.88'),('2018-09-29 03:59:59','2018-09-30 11:59:59','MCOBTC','4h','0.000678000000000','0.000676000000000','0.041486112626188','0.041363734712836','61.18895667579382','61.188956675793818','test','test','0.29'),('2018-09-30 19:59:59','2018-09-30 23:59:59','MCOBTC','4h','0.000678000000000','0.000673000000000','0.041458917534332','0.041153173304728','61.148845920843975','61.148845920843975','test','test','0.73'),('2018-10-01 07:59:59','2018-10-01 15:59:59','MCOBTC','4h','0.000682000000000','0.000675180000000','0.041390974372198','0.040977064628476','60.69057825835484','60.690578258354840','test','test','1.00'),('2018-10-02 07:59:59','2018-10-02 15:59:59','MCOBTC','4h','0.000702000000000','0.000694980000000','0.041298994429149','0.040886004484858','58.83047639479866','58.830476394798659','test','test','1.00'),('2018-10-02 19:59:59','2018-10-05 11:59:59','MCOBTC','4h','0.000693000000000','0.000686070000000','0.041207218885973','0.040795146697113','59.46207631453518','59.462076314535182','test','test','1.00'),('2018-10-08 23:59:59','2018-10-09 07:59:59','MCOBTC','4h','0.000693000000000','0.000686070000000','0.041115647288448','0.040704490815564','59.32993836716945','59.329938367169447','test','test','1.00'),('2018-10-09 19:59:59','2018-10-11 03:59:59','MCOBTC','4h','0.000692000000000','0.000686000000000','0.041024279183363','0.040668577340733','59.28364043838599','59.283640438385987','test','test','0.86'),('2018-10-18 07:59:59','2018-10-27 19:59:59','MCOBTC','4h','0.000675000000000','0.000727000000000','0.040945234329445','0.044099533862973','60.65960641399307','60.659606413993068','test','test','0.0'),('2018-10-28 15:59:59','2018-10-28 19:59:59','MCOBTC','4h','0.000732000000000','0.000724680000000','0.041646189781340','0.041229727883527','56.8937018870771','56.893701887077100','test','test','1.00'),('2018-11-03 23:59:59','2018-11-04 07:59:59','MCOBTC','4h','0.000708000000000','0.000700920000000','0.041553642692938','0.041138106266009','58.691585724488064','58.691585724488064','test','test','1.00'),('2018-11-16 07:59:59','2018-11-16 11:59:59','MCOBTC','4h','0.000690000000000','0.000683100000000','0.041461301264731','0.041046688252084','60.08884241265379','60.088842412653790','test','test','1.00'),('2018-11-16 15:59:59','2018-11-16 19:59:59','MCOBTC','4h','0.000697000000000','0.000690030000000','0.041369165039698','0.040955473389301','59.35317796226462','59.353177962264617','test','test','1.00'),('2018-12-01 03:59:59','2018-12-01 07:59:59','MCOBTC','4h','0.000585000000000','0.000579150000000','0.041277233561832','0.040864461226214','70.55937360996998','70.559373609969981','test','test','0.99'),('2018-12-01 19:59:59','2018-12-02 03:59:59','MCOBTC','4h','0.000583000000000','0.000577170000000','0.041185506376140','0.040773651312379','70.6440932695361','70.644093269536100','test','test','0.99'),('2018-12-02 11:59:59','2018-12-02 15:59:59','MCOBTC','4h','0.000626000000000','0.000619740000000','0.041093983028637','0.040683043198351','65.64534030133723','65.645340301337228','test','test','1.00'),('2018-12-03 11:59:59','2018-12-03 15:59:59','MCOBTC','4h','0.000601000000000','0.000594990000000','0.041002663066351','0.040592636435687','68.22406500224847','68.224065002248466','test','test','0.99'),('2018-12-04 11:59:59','2018-12-06 07:59:59','MCOBTC','4h','0.000614000000000','0.000607860000000','0.040911546037315','0.040502430576942','66.63118247119687','66.631182471196865','test','test','0.99'),('2018-12-19 11:59:59','2018-12-19 15:59:59','MCOBTC','4h','0.000557000000000','0.000551430000000','0.040820631490565','0.040412425175659','73.28659154500059','73.286591545000590','test','test','0.99'),('2018-12-20 07:59:59','2018-12-20 11:59:59','MCOBTC','4h','0.000565000000000','0.000559350000000','0.040729918976142','0.040322619786381','72.08835217016242','72.088352170162423','test','test','1.00'),('2018-12-23 03:59:59','2018-12-27 07:59:59','MCOBTC','4h','0.000551000000000','0.000578000000000','0.040639408045084','0.042630812795025','73.7557314792809','73.755731479280897','test','test','0.0'),('2018-12-30 03:59:59','2019-01-01 03:59:59','MCOBTC','4h','0.000579000000000','0.000580000000000','0.041081942433960','0.041152895702412','70.95326845243446','70.953268452434457','test','test','0.0'),('2019-01-02 11:59:59','2019-01-02 15:59:59','MCOBTC','4h','0.000604000000000','0.000597960000000','0.041097709826949','0.040686732728680','68.04256593865708','68.042565938657077','test','test','1.00'),('2019-01-03 15:59:59','2019-01-10 07:59:59','MCOBTC','4h','0.000605000000000','0.000638000000000','0.041006381582889','0.043243093305592','67.77914311221339','67.779143112213390','test','test','0.99'),('2019-01-12 03:59:59','2019-01-12 11:59:59','MCOBTC','4h','0.000641000000000','0.000634590000000','0.041503428632379','0.041088394346055','64.74793858405407','64.747938584054069','test','test','0.99'),('2019-01-17 23:59:59','2019-01-18 07:59:59','MCOBTC','4h','0.000627000000000','0.000622000000000','0.041411198790973','0.041080965945750','66.04656904461456','66.046569044614557','test','test','0.79'),('2019-01-18 23:59:59','2019-01-19 07:59:59','MCOBTC','4h','0.000631000000000','0.000624690000000','0.041337813714257','0.040924435577114','65.51159067235675','65.511590672356746','test','test','1.00'),('2019-01-19 11:59:59','2019-01-20 11:59:59','MCOBTC','4h','0.000635000000000','0.000628650000000','0.041245951906003','0.040833492386943','64.95425497008362','64.954254970083625','test','test','1.00'),('2019-01-26 11:59:59','2019-01-26 19:59:59','MCOBTC','4h','0.000629000000000','0.000624000000000','0.041154294235101','0.040827153581404','65.42813073942905','65.428130739429051','test','test','0.79'),('2019-02-08 15:59:59','2019-02-08 15:59:59','MCOBTC','4h','0.000584000000000','0.000584000000000','0.041081596312057','0.041081596312057','70.34519916448134','70.345199164481343','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 19:17:04
