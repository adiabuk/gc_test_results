-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 23:59:59','2018-07-02 03:59:59','VIBEBTC','4h','0.000012480000000','0.000012870000000','0.033333333333333','0.034375000000000','2670.940170940171','2670.940170940170901','test','test','0.0'),('2018-07-02 15:59:59','2018-07-03 11:59:59','VIBEBTC','4h','0.000012860000000','0.000012731400000','0.033564814814815','0.033229166666667','2610.0167041069117','2610.016704106911675','test','test','1.00'),('2018-07-03 19:59:59','2018-07-03 23:59:59','VIBEBTC','4h','0.000012750000000','0.000012622500000','0.033490226337449','0.033155324074075','2626.6844186234252','2626.684418623425245','test','test','1.00'),('2018-07-04 15:59:59','2018-07-05 03:59:59','VIBEBTC','4h','0.000012750000000','0.000012800000000','0.033415803612254','0.033546845979361','2620.8473421376034','2620.847342137603391','test','test','0.31'),('2018-07-07 03:59:59','2018-07-07 07:59:59','VIBEBTC','4h','0.000012500000000','0.000012375000000','0.033444924138278','0.033110474896895','2675.5939310622575','2675.593931062257525','test','test','0.99'),('2018-07-18 03:59:59','2018-07-18 07:59:59','VIBEBTC','4h','0.000011510000000','0.000011510000000','0.033370602084638','0.033370602084638','2899.270380941577','2899.270380941577059','test','test','0.0'),('2018-07-18 11:59:59','2018-07-18 15:59:59','VIBEBTC','4h','0.000011730000000','0.000011612700000','0.033370602084638','0.033036896063792','2844.8936133535854','2844.893613353585351','test','test','0.99'),('2018-08-27 19:59:59','2018-08-27 23:59:59','VIBEBTC','4h','0.000004920000000','0.000004900000000','0.033296445191116','0.033161093787900','6767.570160795979','6767.570160795979064','test','test','0.40'),('2018-08-28 07:59:59','2018-08-30 11:59:59','VIBEBTC','4h','0.000005200000000','0.000005148000000','0.033266367101513','0.032933703430498','6397.378288752437','6397.378288752436674','test','test','0.99'),('2018-09-01 03:59:59','2018-09-01 07:59:59','VIBEBTC','4h','0.000005610000000','0.000005553900000','0.033192441841287','0.032860517422874','5916.656299694673','5916.656299694673180','test','test','1.00'),('2018-09-01 15:59:59','2018-09-02 11:59:59','VIBEBTC','4h','0.000005570000000','0.000005514300000','0.033118680859418','0.032787494050824','5945.903206358627','5945.903206358627358','test','test','1.00'),('2018-09-04 19:59:59','2018-09-05 11:59:59','VIBEBTC','4h','0.000005320000000','0.000005266800000','0.033045083790841','0.032714632952933','6211.481915571638','6211.481915571637728','test','test','0.99'),('2018-09-10 07:59:59','2018-09-10 11:59:59','VIBEBTC','4h','0.000005280000000','0.000005227200000','0.032971650271306','0.032641933768593','6244.630733201893','6244.630733201893236','test','test','0.99'),('2018-09-14 07:59:59','2018-09-14 11:59:59','VIBEBTC','4h','0.000004830000000','0.000004781700000','0.032898379937370','0.032569396137996','6811.258786204922','6811.258786204922217','test','test','1.00'),('2018-09-15 03:59:59','2018-09-28 07:59:59','VIBEBTC','4h','0.000004990000000','0.000011880000000','0.032825272426398','0.078149145576274','6578.210907093744','6578.210907093744026','test','test','0.20'),('2018-09-30 07:59:59','2018-09-30 11:59:59','VIBEBTC','4h','0.000012600000000','0.000012474000000','0.042897244237481','0.042468271795106','3404.5431934508997','3404.543193450899707','test','test','1.00'),('2018-09-30 19:59:59','2018-09-30 23:59:59','VIBEBTC','4h','0.000011920000000','0.000011800800000','0.042801917028065','0.042373897857784','3590.764851347707','3590.764851347707008','test','test','1.00'),('2018-10-01 03:59:59','2018-10-01 07:59:59','VIBEBTC','4h','0.000012360000000','0.000012236400000','0.042706801656891','0.042279733640322','3455.242852499281','3455.242852499281071','test','test','0.99'),('2018-10-07 11:59:59','2018-10-07 15:59:59','VIBEBTC','4h','0.000012290000000','0.000012167100000','0.042611897653209','0.042185778676677','3467.200785452328','3467.200785452328091','test','test','1.00'),('2018-10-07 19:59:59','2018-10-08 11:59:59','VIBEBTC','4h','0.000011980000000','0.000011860200000','0.042517204547313','0.042092032501840','3549.0154046171206','3549.015404617120566','test','test','1.00'),('2018-10-10 11:59:59','2018-10-10 15:59:59','VIBEBTC','4h','0.000012600000000','0.000012474000000','0.042422721870541','0.041998494651836','3366.882688138201','3366.882688138201047','test','test','1.00'),('2018-10-14 15:59:59','2018-10-14 19:59:59','VIBEBTC','4h','0.000011430000000','0.000011315700000','0.042328449155274','0.041905164663721','3703.2763915374935','3703.276391537493510','test','test','0.99'),('2018-10-17 11:59:59','2018-10-17 15:59:59','VIBEBTC','4h','0.000011270000000','0.000011157300000','0.042234385934928','0.041812042075579','3747.5054068259487','3747.505406825948739','test','test','0.99'),('2018-10-18 11:59:59','2018-10-18 15:59:59','VIBEBTC','4h','0.000011480000000','0.000011365200000','0.042140531743962','0.041719126426522','3670.7780264775265','3670.778026477526510','test','test','0.99'),('2018-10-20 11:59:59','2018-10-20 15:59:59','VIBEBTC','4h','0.000011240000000','0.000011370000000','0.042046886117864','0.042533193519583','3740.8261670697707','3740.826167069770690','test','test','0.0'),('2018-10-20 19:59:59','2018-10-20 23:59:59','VIBEBTC','4h','0.000011940000000','0.000011820600000','0.042154954429357','0.041733404885063','3530.5656976011164','3530.565697601116426','test','test','1.00'),('2018-10-21 07:59:59','2018-10-21 11:59:59','VIBEBTC','4h','0.000012220000000','0.000012097800000','0.042061276752848','0.041640663985320','3442.0030075979994','3442.003007597999385','test','test','1.00'),('2018-10-24 11:59:59','2018-10-25 03:59:59','VIBEBTC','4h','0.000012000000000','0.000011880000000','0.041967807248952','0.041548129176462','3497.317270746037','3497.317270746037138','test','test','1.00'),('2018-11-27 19:59:59','2018-11-27 23:59:59','VIBEBTC','4h','0.000007530000000','0.000007454700000','0.041874545455066','0.041455800000515','5561.028612890542','5561.028612890541808','test','test','0.99'),('2018-11-28 03:59:59','2018-11-28 07:59:59','VIBEBTC','4h','0.000007100000000','0.000007029000000','0.041781490909610','0.041363676000514','5884.717029522536','5884.717029522535995','test','test','0.99'),('2018-11-28 15:59:59','2018-11-28 19:59:59','VIBEBTC','4h','0.000007120000000','0.000007280000000','0.041688643152033','0.042625466593652','5855.14651011701','5855.146510117009711','test','test','0.0'),('2018-11-29 07:59:59','2018-11-29 11:59:59','VIBEBTC','4h','0.000007350000000','0.000007276500000','0.041896826139060','0.041477857877669','5700.2484542938155','5700.248454293815485','test','test','1.00'),('2018-11-29 15:59:59','2018-11-29 23:59:59','VIBEBTC','4h','0.000007520000000','0.000007444800000','0.041803722080973','0.041385684860163','5559.005595874025','5559.005595874024948','test','test','0.99'),('2018-12-01 15:59:59','2018-12-01 19:59:59','VIBEBTC','4h','0.000007740000000','0.000007662600000','0.041710824920793','0.041293716671585','5388.99546780267','5388.995467802669737','test','test','1.00'),('2018-12-01 23:59:59','2018-12-02 23:59:59','VIBEBTC','4h','0.000008450000000','0.000008365500000','0.041618134198746','0.041201952856759','4925.222982100171','4925.222982100171066','test','test','1.00'),('2018-12-03 11:59:59','2018-12-03 15:59:59','VIBEBTC','4h','0.000008290000000','0.000008207100000','0.041525649456083','0.041110392961522','5009.125386740972','5009.125386740972317','test','test','1.00'),('2018-12-17 23:59:59','2018-12-25 07:59:59','VIBEBTC','4h','0.000006870000000','0.000007180000000','0.041433370235069','0.043302998295167','6031.058258379783','6031.058258379783183','test','test','0.0'),('2018-12-27 23:59:59','2018-12-28 03:59:59','VIBEBTC','4h','0.000007310000000','0.000007320000000','0.041848843137313','0.041906091896735','5724.8759421768955','5724.875942176895478','test','test','0.0'),('2018-12-28 07:59:59','2018-12-29 03:59:59','VIBEBTC','4h','0.000007650000000','0.000007573500000','0.041861565083851','0.041442949433012','5472.100010960959','5472.100010960958571','test','test','1.00'),('2019-01-03 03:59:59','2019-01-03 07:59:59','VIBEBTC','4h','0.000007600000000','0.000007524000000','0.041768539383665','0.041350853989828','5495.860445219063','5495.860445219062967','test','test','0.99'),('2019-01-04 07:59:59','2019-01-07 11:59:59','VIBEBTC','4h','0.000007740000000','0.000007820000000','0.041675720407257','0.042106477207332','5384.460000937554','5384.460000937553559','test','test','0.0'),('2019-01-08 15:59:59','2019-01-08 23:59:59','VIBEBTC','4h','0.000008530000000','0.000008444700000','0.041771444140607','0.041353729699201','4897.004002415787','4897.004002415786999','test','test','1.00'),('2019-01-11 19:59:59','2019-01-11 23:59:59','VIBEBTC','4h','0.000008140000000','0.000008058600000','0.041678618709183','0.041261832522091','5120.223428646574','5120.223428646573666','test','test','1.00'),('2019-01-14 15:59:59','2019-01-27 11:59:59','VIBEBTC','4h','0.000009810000000','0.000011120000000','0.041585999556496','0.047139277784733','4239.143685677473','4239.143685677472604','test','test','0.0'),('2019-02-03 03:59:59','2019-02-03 07:59:59','VIBEBTC','4h','0.000010750000000','0.000010642500000','0.042820061384993','0.042391860771143','3983.261524185405','3983.261524185405051','test','test','1.00'),('2019-02-11 19:59:59','2019-02-12 03:59:59','VIBEBTC','4h','0.000010080000000','0.000010340000000','0.042724905693026','0.043826936990664','4238.581913990718','4238.581913990718022','test','test','0.0'),('2019-02-12 15:59:59','2019-02-13 07:59:59','VIBEBTC','4h','0.000010150000000','0.000010050000000','0.042969801536946','0.042546453738552','4233.477983935566','4233.477983935566044','test','test','0.98'),('2019-02-17 15:59:59','2019-02-17 19:59:59','VIBEBTC','4h','0.000010150000000','0.000010048500000','0.042875724248414','0.042446967005930','4224.2092855580295','4224.209285558029478','test','test','1.00'),('2019-02-17 23:59:59','2019-02-18 03:59:59','VIBEBTC','4h','0.000010050000000','0.000009949500000','0.042780444861195','0.042352640412583','4256.760682706003','4256.760682706002626','test','test','1.00'),('2019-02-19 19:59:59','2019-02-19 23:59:59','VIBEBTC','4h','0.000010140000000','0.000010038600000','0.042685377205948','0.042258523433889','4209.603274748345','4209.603274748345029','test','test','1.00'),('2019-02-20 15:59:59','2019-02-20 19:59:59','VIBEBTC','4h','0.000010230000000','0.000010127700000','0.042590520812157','0.042164615604035','4163.296267073053','4163.296267073053059','test','test','1.00'),('2019-02-23 15:59:59','2019-02-23 19:59:59','VIBEBTC','4h','0.000009950000000','0.000009850500000','0.042495875210352','0.042070916458248','4270.942232196226','4270.942232196225632','test','test','0.99'),('2019-02-26 19:59:59','2019-02-26 23:59:59','VIBEBTC','4h','0.000009880000000','0.000009781200000','0.042401439932107','0.041977425532786','4291.643717824606','4291.643717824606028','test','test','0.99'),('2019-02-28 03:59:59','2019-02-28 07:59:59','VIBEBTC','4h','0.000009810000000','0.000009711900000','0.042307214510036','0.041884142364936','4312.662029565318','4312.662029565318335','test','test','0.99'),('2019-03-02 15:59:59','2019-03-02 19:59:59','VIBEBTC','4h','0.000010190000000','0.000010088100000','0.042213198477791','0.041791066493013','4142.610252972653','4142.610252972653143','test','test','0.99'),('2019-03-03 03:59:59','2019-03-03 07:59:59','VIBEBTC','4h','0.000010460000000','0.000010355400000','0.042119391370063','0.041698197456362','4026.7104560289563','4026.710456028956287','test','test','1.00'),('2019-03-05 15:59:59','2019-03-07 03:59:59','VIBEBTC','4h','0.000010110000000','0.000010030000000','0.042025792722574','0.041693244412207','4156.853879581976','4156.853879581975889','test','test','0.79'),('2019-03-08 15:59:59','2019-03-08 23:59:59','VIBEBTC','4h','0.000010130000000','0.000010028700000','0.041951893098048','0.041532374167068','4141.351737220906','4141.351737220906216','test','test','1.00'),('2019-03-10 11:59:59','2019-03-11 15:59:59','VIBEBTC','4h','0.000010310000000','0.000010380000000','0.041858666668941','0.042142867121591','4060.006466434637','4060.006466434636877','test','test','0.0'),('2019-03-12 11:59:59','2019-03-13 11:59:59','VIBEBTC','4h','0.000010690000000','0.000010640000000','0.041921822325086','0.041725742707101','3921.5923596899497','3921.592359689949717','test','test','0.46'),('2019-03-15 15:59:59','2019-03-15 19:59:59','VIBEBTC','4h','0.000011360000000','0.000011246400000','0.041878249076644','0.041459466585878','3686.4655877327855','3686.465587732785480','test','test','1.00'),('2019-03-17 11:59:59','2019-03-17 15:59:59','VIBEBTC','4h','0.000011300000000','0.000011187000000','0.041785186300919','0.041367334437910','3697.80409742643','3697.804097426429962','test','test','1.00'),('2019-03-18 11:59:59','2019-03-20 23:59:59','VIBEBTC','4h','0.000011110000000','0.000010998900000','0.041692330331361','0.041275407028047','3752.6849983223315','3752.684998322331467','test','test','0.99'),('2019-03-26 15:59:59','2019-03-26 19:59:59','VIBEBTC','4h','0.000010900000000','0.000011170000000','0.041599680708402','0.042630131514940','3816.4844686607744','3816.484468660774382','test','test','0.0'),('2019-03-27 11:59:59','2019-03-27 15:59:59','VIBEBTC','4h','0.000011580000000','0.000011464200000','0.041828669776522','0.041410383078757','3612.147649095164','3612.147649095164070','test','test','0.99'),('2019-03-31 07:59:59','2019-03-31 11:59:59','VIBEBTC','4h','0.000011880000000','0.000011761200000','0.041735717177019','0.041318360005249','3513.1075064830525','3513.107506483052475','test','test','0.99'),('2019-03-31 15:59:59','2019-03-31 19:59:59','VIBEBTC','4h','0.000012210000000','0.000012087900000','0.041642971138848','0.041226541427460','3410.5627468343614','3410.562746834361405','test','test','1.00'),('2019-05-06 11:59:59','2019-05-06 23:59:59','VIBEBTC','4h','0.000007120000000','0.000007060000000','0.041550431202984','0.041200287119813','5835.734719520162','5835.734719520161889','test','test','0.84'),('2019-05-16 07:59:59','2019-05-16 11:59:59','VIBEBTC','4h','0.000006150000000','0.000006088500000','0.041472621406723','0.041057895192656','6743.515675889972','6743.515675889972044','test','test','1.00'),('2019-05-16 15:59:59','2019-05-16 19:59:59','VIBEBTC','4h','0.000005810000000','0.000005751900000','0.041380460025820','0.040966655425562','7122.282276388908','7122.282276388908031','test','test','1.00'),('2019-05-21 19:59:59','2019-05-21 23:59:59','VIBEBTC','4h','0.000005500000000','0.000005680000000','0.041288503447984','0.042639763560827','7507.0006269062615','7507.000626906261459','test','test','0.0'),('2019-05-22 15:59:59','2019-05-22 23:59:59','VIBEBTC','4h','0.000005930000000','0.000005870700000','0.041588783473061','0.041172895638330','7013.285577244631','7013.285577244630986','test','test','1.00'),('2019-05-23 07:59:59','2019-05-24 15:59:59','VIBEBTC','4h','0.000006080000000','0.000006019200000','0.041496363954232','0.041081400314690','6825.059860893348','6825.059860893347832','test','test','1.00'),('2019-05-28 11:59:59','2019-05-28 15:59:59','VIBEBTC','4h','0.000005760000000','0.000005702400000','0.041404149812111','0.040990108313990','7188.220453491512','7188.220453491511762','test','test','1.00'),('2019-05-29 19:59:59','2019-05-30 15:59:59','VIBEBTC','4h','0.000005940000000','0.000005880600000','0.041312140590306','0.040899019184403','6954.905823283913','6954.905823283913378','test','test','0.99'),('2019-05-30 19:59:59','2019-05-30 23:59:59','VIBEBTC','4h','0.000005800000000','0.000005742000000','0.041220335833439','0.040808132475105','7106.954454041226','7106.954454041226199','test','test','1.00'),('2019-05-31 19:59:59','2019-06-01 03:59:59','VIBEBTC','4h','0.000005990000000','0.000005930100000','0.041128735087143','0.040717447736272','6866.232902694936','6866.232902694935547','test','test','1.00'),('2019-06-03 11:59:59','2019-06-03 19:59:59','VIBEBTC','4h','0.000005950000000','0.000005890500000','0.041037337898060','0.040626964519079','6897.0315795059205','6897.031579505920490','test','test','1.00'),('2019-06-07 11:59:59','2019-06-09 15:59:59','VIBEBTC','4h','0.000005910000000','0.000005930000000','0.040946143813842','0.041084709444346','6928.281525184809','6928.281525184808743','test','test','0.16'),('2019-06-10 07:59:59','2019-06-12 15:59:59','VIBEBTC','4h','0.000006000000000','0.000006010000000','0.040976936176176','0.041045231069803','6829.489362696075','6829.489362696074750','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 19:03:50
