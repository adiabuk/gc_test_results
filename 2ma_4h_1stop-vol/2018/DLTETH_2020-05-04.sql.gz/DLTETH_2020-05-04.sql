-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-28 15:59:59','2018-04-28 19:59:59','DLTETH','4h','0.000423680000000','0.000421320000000','1.297777777777778','1.290548841893253','3063.1084256461895','3063.108425646189517','test','test','0.55'),('2018-04-29 07:59:59','2018-04-29 11:59:59','DLTETH','4h','0.000422050000000','0.000417829500000','1.296171347581217','1.283209634105405','3071.132206092209','3071.132206092208889','test','test','0.99'),('2018-04-29 15:59:59','2018-04-29 19:59:59','DLTETH','4h','0.000419160000000','0.000430070000000','1.293290966808814','1.326953063497153','3085.4350768413346','3085.435076841334649','test','test','0.0'),('2018-04-29 23:59:59','2018-04-30 03:59:59','DLTETH','4h','0.000433500000000','0.000429165000000','1.300771432739556','1.287763718412160','3000.6261424211207','3000.626142421120676','test','test','1.00'),('2018-04-30 19:59:59','2018-04-30 23:59:59','DLTETH','4h','0.000460010000000','0.000455409900000','1.297880829555690','1.284902021260133','2821.4187290617383','2821.418729061738304','test','test','0.99'),('2018-05-01 11:59:59','2018-05-03 07:59:59','DLTETH','4h','0.000455190000000','0.000450638100000','1.294996649934455','1.282046683435110','2844.958478732958','2844.958478732958156','test','test','1.00'),('2018-05-13 23:59:59','2018-05-15 07:59:59','DLTETH','4h','0.000402820000000','0.000398791800000','1.292118879601267','1.279197690805254','3207.6830336161743','3207.683033616174271','test','test','1.00'),('2018-05-31 23:59:59','2018-06-01 03:59:59','DLTETH','4h','0.000359990000000','0.000356390100000','1.289247504313265','1.276355029270132','3581.342549274326','3581.342549274325847','test','test','0.99'),('2018-07-01 23:59:59','2018-07-06 07:59:59','DLTETH','4h','0.000200310000000','0.000207660000000','1.286382509859235','1.333583904934196','6421.958513600094','6421.958513600094193','test','test','0.0'),('2018-07-08 07:59:59','2018-07-09 03:59:59','DLTETH','4h','0.000220800000000','0.000218592000000','1.296871708764782','1.283902991677134','5873.513173753542','5873.513173753542105','test','test','0.99'),('2018-07-17 19:59:59','2018-07-18 23:59:59','DLTETH','4h','0.000203180000000','0.000201148200000','1.293989771634193','1.281049873917851','6368.686739020542','6368.686739020541609','test','test','0.99'),('2018-07-19 07:59:59','2018-07-20 07:59:59','DLTETH','4h','0.000200710000000','0.000198702900000','1.291114238808340','1.278203096420257','6432.734984845498','6432.734984845497820','test','test','1.00'),('2018-07-23 15:59:59','2018-07-23 19:59:59','DLTETH','4h','0.000200100000000','0.000198099000000','1.288245096055432','1.275362645094878','6438.0064770386425','6438.006477038642515','test','test','1.00'),('2018-07-30 07:59:59','2018-07-30 11:59:59','DLTETH','4h','0.000190390000000','0.000192350000000','1.285382329175309','1.298614901081311','6751.312196939489','6751.312196939488786','test','test','0.0'),('2018-08-13 19:59:59','2018-08-14 03:59:59','DLTETH','4h','0.000148830000000','0.000147341700000','1.288322900709976','1.275439671702876','8656.338780554837','8656.338780554837285','test','test','1.00'),('2018-08-17 15:59:59','2018-08-17 19:59:59','DLTETH','4h','0.000144550000000','0.000144260000000','1.285459960930621','1.282881037453140','8892.839577520726','8892.839577520726380','test','test','0.20'),('2018-08-20 11:59:59','2018-08-20 23:59:59','DLTETH','4h','0.000150560000000','0.000149054400000','1.284886866824514','1.272037998156269','8534.05198475368','8534.051984753679790','test','test','0.99'),('2018-08-21 11:59:59','2018-08-21 15:59:59','DLTETH','4h','0.000145380000000','0.000143926200000','1.282031562676015','1.269211247049255','8818.486467712308','8818.486467712307785','test','test','1.00'),('2018-08-22 11:59:59','2018-08-22 15:59:59','DLTETH','4h','0.000153230000000','0.000151697700000','1.279182603647846','1.266390777611368','8348.121148912394','8348.121148912394347','test','test','0.99'),('2018-08-23 11:59:59','2018-08-30 15:59:59','DLTETH','4h','0.000146870000000','0.000162000000000','1.276339975639740','1.407823762876271','8690.270141211548','8690.270141211547525','test','test','0.0'),('2018-08-31 07:59:59','2018-08-31 11:59:59','DLTETH','4h','0.000167160000000','0.000165488400000','1.305558595025636','1.292503009075380','7810.233279646063','7810.233279646063238','test','test','1.00'),('2018-08-31 19:59:59','2018-09-01 07:59:59','DLTETH','4h','0.000167490000000','0.000165815100000','1.302657353703357','1.289630780166323','7777.523157820507','7777.523157820506640','test','test','0.99'),('2018-09-01 11:59:59','2018-09-01 15:59:59','DLTETH','4h','0.000172500000000','0.000170775000000','1.299762559584016','1.286764933988176','7534.855417878352','7534.855417878351545','test','test','1.00'),('2018-09-01 19:59:59','2018-09-02 03:59:59','DLTETH','4h','0.000170150000000','0.000168448500000','1.296874198340496','1.283905456357091','7621.946508025247','7621.946508025246658','test','test','1.00'),('2018-09-02 15:59:59','2018-09-06 03:59:59','DLTETH','4h','0.000172280000000','0.000170557200000','1.293992255677517','1.281052333120742','7510.983606208016','7510.983606208015772','test','test','1.00'),('2018-09-07 19:59:59','2018-09-07 23:59:59','DLTETH','4h','0.000170310000000','0.000169470000000','1.291116717331567','1.284748694064827','7580.980079452568','7580.980079452568134','test','test','0.49'),('2018-09-08 19:59:59','2018-09-12 11:59:59','DLTETH','4h','0.000173190000000','0.000175460000000','1.289701601050069','1.306605710030863','7446.744044402501','7446.744044402500549','test','test','0.0'),('2018-09-16 03:59:59','2018-09-19 07:59:59','DLTETH','4h','0.000182150000000','0.000189040000000','1.293458069712468','1.342384372761158','7101.059949011625','7101.059949011624667','test','test','0.0'),('2018-09-20 15:59:59','2018-09-20 23:59:59','DLTETH','4h','0.000213590000000','0.000211454100000','1.304330581501066','1.291287275686055','6106.702474371767','6106.702474371766584','test','test','1.00'),('2018-09-22 07:59:59','2018-10-06 23:59:59','DLTETH','4h','0.000201350000000','0.000295720000000','1.301432069097730','1.911395537489847','6463.531507810925','6463.531507810925177','test','test','0.82'),('2018-10-07 03:59:59','2018-10-07 07:59:59','DLTETH','4h','0.000329690000000','0.000326393100000','1.436979506518200','1.422609711453018','4358.577774631321','4358.577774631320608','test','test','0.99'),('2018-10-07 19:59:59','2018-10-07 23:59:59','DLTETH','4h','0.000308750000000','0.000305662500000','1.433786218725937','1.419448356538678','4643.842003970647','4643.842003970647056','test','test','0.99'),('2018-10-08 19:59:59','2018-10-09 11:59:59','DLTETH','4h','0.000305050000000','0.000301999500000','1.430600027128769','1.416294026857481','4689.72308516233','4689.723085162329880','test','test','1.00'),('2018-10-10 11:59:59','2018-10-10 19:59:59','DLTETH','4h','0.000410000000000','0.000405900000000','1.427420915957372','1.413146706797798','3481.514429164321','3481.514429164320973','test','test','0.99'),('2018-10-10 23:59:59','2018-10-13 15:59:59','DLTETH','4h','0.000425970000000','0.000421710300000','1.424248869477466','1.410006380782691','3343.5426660972985','3343.542666097298479','test','test','1.00'),('2018-10-14 15:59:59','2018-10-14 19:59:59','DLTETH','4h','0.000443080000000','0.000438649200000','1.421083871989738','1.406873033269841','3207.285077163804','3207.285077163804090','test','test','0.99'),('2018-10-16 07:59:59','2018-10-22 03:59:59','DLTETH','4h','0.000418170000000','0.000435980000000','1.417925907829761','1.478315845937344','3390.7882149120246','3390.788214912024614','test','test','0.0'),('2018-10-22 19:59:59','2018-10-23 11:59:59','DLTETH','4h','0.000451610000000','0.000447093900000','1.431345894075891','1.417032435135132','3169.4291403553743','3169.429140355374329','test','test','1.00'),('2018-10-23 23:59:59','2018-10-26 23:59:59','DLTETH','4h','0.000452510000000','0.000454420000000','1.428165125422389','1.434193269307732','3156.096275048925','3156.096275048924781','test','test','0.30'),('2018-10-27 07:59:59','2018-10-27 11:59:59','DLTETH','4h','0.000475370000000','0.000470616300000','1.429504712952465','1.415209665822940','3007.141201490344','3007.141201490343974','test','test','0.99'),('2018-10-28 15:59:59','2018-10-28 19:59:59','DLTETH','4h','0.000483570000000','0.000478734300000','1.426328035812571','1.412064755454445','2949.579245636765','2949.579245636764881','test','test','0.99'),('2018-10-30 15:59:59','2018-10-30 19:59:59','DLTETH','4h','0.000465500000000','0.000461920000000','1.423158417955209','1.412213397254286','3057.268352213124','3057.268352213124217','test','test','0.76'),('2018-10-30 23:59:59','2018-10-31 07:59:59','DLTETH','4h','0.000521990000000','0.000516770100000','1.420726191132782','1.406518929221454','2721.749824963662','2721.749824963661922','test','test','0.99'),('2018-10-31 11:59:59','2018-10-31 15:59:59','DLTETH','4h','0.000540260000000','0.000534857400000','1.417569021819154','1.403393331600962','2623.8644760284933','2623.864476028493300','test','test','1.00'),('2018-11-28 07:59:59','2018-12-05 23:59:59','DLTETH','4h','0.000356500000000','0.000376320000000','1.414418868437333','1.493055003002348','3967.514357467975','3967.514357467975060','test','test','0.0'),('2018-12-19 15:59:59','2018-12-19 19:59:59','DLTETH','4h','0.000355990000000','0.000356480000000','1.431893565007337','1.433864485108614','4022.2859209734447','4022.285920973444718','test','test','0.0'),('2018-12-20 11:59:59','2018-12-20 15:59:59','DLTETH','4h','0.000376780000000','0.000373012200000','1.432331547252065','1.418008231779544','3801.5063093902663','3801.506309390266324','test','test','1.00'),('2019-01-01 03:59:59','2019-01-01 07:59:59','DLTETH','4h','0.000301060000000','0.000298049400000','1.429148588258171','1.414857102375589','4747.055697396436','4747.055697396435789','test','test','1.00'),('2019-01-01 23:59:59','2019-01-05 03:59:59','DLTETH','4h','0.000295300000000','0.000308540000000','1.425972702506486','1.489907272710299','4828.895030499445','4828.895030499445056','test','test','0.0'),('2019-01-07 15:59:59','2019-01-28 07:59:59','DLTETH','4h','0.000350440000000','0.001133500000000','1.440180384774000','4.658270934086659','4109.634701443899','4109.634701443898848','test','test','0.0'),('2019-01-28 15:59:59','2019-01-29 03:59:59','DLTETH','4h','0.001159220000000','0.001147627800000','2.155311617954591','2.133758501775045','1859.2774606671646','1859.277460667164632','test','test','1.00'),('2019-01-29 07:59:59','2019-01-29 11:59:59','DLTETH','4h','0.001187050000000','0.001175179500000','2.150522036581358','2.129016816215545','1811.6524464692795','1811.652446469279539','test','test','0.99'),('2019-02-01 19:59:59','2019-02-01 23:59:59','DLTETH','4h','0.001092900000000','0.001085690000000','2.145743098722289','2.131587359183642','1963.348063612672','1963.348063612671922','test','test','0.65'),('2019-02-02 07:59:59','2019-02-02 15:59:59','DLTETH','4h','0.001231970000000','0.001219650300000','2.142597378824811','2.121171405036563','1739.1635988090711','1739.163598809071118','test','test','1.00'),('2019-02-03 11:59:59','2019-02-03 15:59:59','DLTETH','4h','0.001164100000000','0.001152459000000','2.137836051316312','2.116457690803149','1836.471137631056','1836.471137631056081','test','test','0.99'),('2019-02-20 11:59:59','2019-02-20 15:59:59','DLTETH','4h','0.000822440000000','0.000814215600000','2.133085304535610','2.111754451490254','2593.6059828505536','2593.605982850553573','test','test','0.99'),('2019-03-02 19:59:59','2019-03-02 23:59:59','DLTETH','4h','0.000726550000000','0.000732570000000','2.128345114969975','2.145980016342378','2929.3856100336866','2929.385610033686589','test','test','0.0'),('2019-03-03 23:59:59','2019-03-04 07:59:59','DLTETH','4h','0.000726790000000','0.000738290000000','2.132263981941620','2.166002800296755','2933.8102917508763','2933.810291750876331','test','test','0.0'),('2019-03-04 19:59:59','2019-03-04 23:59:59','DLTETH','4h','0.000734000000000','0.000726660000000','2.139761497131650','2.118363882160334','2915.2063993619213','2915.206399361921285','test','test','0.99'),('2019-03-05 15:59:59','2019-03-05 19:59:59','DLTETH','4h','0.000737110000000','0.000729738900000','2.135006471582468','2.113656406866643','2896.455714320072','2896.455714320071820','test','test','0.99'),('2019-03-06 15:59:59','2019-03-06 23:59:59','DLTETH','4h','0.000780780000000','0.000772972200000','2.130262012756730','2.108959392629163','2728.3767677921173','2728.376767792117334','test','test','1.00'),('2019-03-07 15:59:59','2019-03-07 19:59:59','DLTETH','4h','0.000734160000000','0.000727170000000','2.125528097172826','2.105290762805334','2895.183743561112','2895.183743561111896','test','test','0.95'),('2019-03-09 03:59:59','2019-03-09 07:59:59','DLTETH','4h','0.000726960000000','0.000734720000000','2.121030911757828','2.143672047274556','2917.6721026711616','2917.672102671161610','test','test','0.0'),('2019-03-09 15:59:59','2019-03-10 15:59:59','DLTETH','4h','0.000729000000000','0.000728780000000','2.126062275205989','2.125420665191523','2916.4091566611646','2916.409156661164616','test','test','0.03'),('2019-03-10 19:59:59','2019-03-11 11:59:59','DLTETH','4h','0.000738650000000','0.000731263500000','2.125919695202775','2.104660498250747','2878.1150683040337','2878.115068304033684','test','test','1.00'),('2019-03-12 11:59:59','2019-03-18 11:59:59','DLTETH','4h','0.000763090000000','0.000761580000000','2.121195429213435','2.116998014625231','2779.7447603997366','2779.744760399736606','test','test','0.26'),('2019-03-20 15:59:59','2019-03-20 23:59:59','DLTETH','4h','0.000782480000000','0.000774655200000','2.120262670416056','2.099060043711895','2709.6701135058483','2709.670113505848349','test','test','0.99'),('2019-03-21 07:59:59','2019-03-21 11:59:59','DLTETH','4h','0.000778600000000','0.000783820000000','2.115550975592909','2.129734351000814','2717.121725652337','2717.121725652336863','test','test','0.0'),('2019-03-26 19:59:59','2019-03-27 03:59:59','DLTETH','4h','0.000830370000000','0.000822066300000','2.118702836794666','2.097515808426719','2551.5165971731467','2551.516597173146693','test','test','1.0'),('2019-03-27 07:59:59','2019-03-27 15:59:59','DLTETH','4h','0.000822280000000','0.000814057200000','2.113994608268456','2.092854662185771','2570.893866162932','2570.893866162932227','test','test','1.00'),('2019-03-28 11:59:59','2019-03-28 15:59:59','DLTETH','4h','0.000892810000000','0.000883881900000','2.109296842472304','2.088203874047581','2362.5372055334324','2362.537205533432370','test','test','0.99'),('2019-03-29 07:59:59','2019-03-29 11:59:59','DLTETH','4h','0.000876230000000','0.000867467700000','2.104609516155699','2.083563420994142','2401.891645065449','2401.891645065449211','test','test','1.00'),('2019-03-30 19:59:59','2019-04-02 07:59:59','DLTETH','4h','0.000857810000000','0.000861450000000','2.099932606119797','2.108843384364719','2448.016001352044','2448.016001352043986','test','test','0.91');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 18:57:46
