-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-20 03:59:59','2018-04-09 11:59:59','ZRXETH','4h','0.000893000000000','0.001362800000000','1.297777777777778','1.980528057732985','1453.278586537265','1453.278586537265028','test','test','0.0'),('2018-04-11 07:59:59','2018-04-11 11:59:59','ZRXETH','4h','0.001400000000000','0.001436990000000','1.449500062212268','1.487797924570291','1035.3571872944772','1035.357187294477171','test','test','0.0'),('2018-04-11 15:59:59','2018-04-11 23:59:59','ZRXETH','4h','0.001424860000000','0.001410611400000','1.458010698291829','1.443430591308910','1023.2659337000329','1023.265933700032861','test','test','1.00'),('2018-04-12 03:59:59','2018-04-12 07:59:59','ZRXETH','4h','0.001444240000000','0.001429797600000','1.454770674517847','1.440222967772669','1007.2914990014449','1007.291499001444890','test','test','1.00'),('2018-04-12 19:59:59','2018-04-12 23:59:59','ZRXETH','4h','0.001382620000000','0.001401240000000','1.451537850796696','1.471085980276838','1049.8458367423416','1049.845836742341589','test','test','0.0'),('2018-04-13 15:59:59','2018-04-13 23:59:59','ZRXETH','4h','0.001388970000000','0.001388000000000','1.455881879570061','1.454865151042315','1048.1737399440312','1048.173739944031240','test','test','0.06'),('2018-04-14 11:59:59','2018-04-21 03:59:59','ZRXETH','4h','0.001437570000000','0.001523810000000','1.455655939897229','1.542980917642130','1012.5809107711128','1012.580910771112826','test','test','0.95'),('2018-04-22 15:59:59','2018-04-23 15:59:59','ZRXETH','4h','0.001594820000000','0.001578871800000','1.475061490507207','1.460310875602135','924.9078206363141','924.907820636314113','test','test','1.00'),('2018-04-24 11:59:59','2018-04-25 07:59:59','ZRXETH','4h','0.001602350000000','0.001605000000000','1.471783576083857','1.474217642596555','918.5156651691935','918.515665169193539','test','test','0.0'),('2018-04-26 07:59:59','2018-04-26 15:59:59','ZRXETH','4h','0.001756590000000','0.001739024100000','1.472324479753346','1.457601234955813','838.1719580285359','838.171958028535869','test','test','1.00'),('2018-04-29 15:59:59','2018-04-30 07:59:59','ZRXETH','4h','0.001810420000000','0.001792315800000','1.469052647576116','1.454362121100355','811.443006361019','811.443006361019002','test','test','0.99'),('2018-04-30 11:59:59','2018-04-30 23:59:59','ZRXETH','4h','0.001806240000000','0.001788177600000','1.465788086137058','1.451130205275687','811.5134678321032','811.513467832103174','test','test','1.00'),('2018-05-02 03:59:59','2018-05-02 07:59:59','ZRXETH','4h','0.001786950000000','0.001769080500000','1.462530779278976','1.447905471486186','818.4508683952968','818.450868395296766','test','test','0.99'),('2018-05-02 11:59:59','2018-05-06 11:59:59','ZRXETH','4h','0.001880100000000','0.001878430000000','1.459280710880578','1.457984503877136','776.1718583482677','776.171858348267733','test','test','0.08'),('2018-05-07 11:59:59','2018-05-07 15:59:59','ZRXETH','4h','0.002217220000000','0.002195047800000','1.458992664879813','1.444402738231015','658.0279200439347','658.027920043934728','test','test','1.00'),('2018-05-07 19:59:59','2018-05-07 23:59:59','ZRXETH','4h','0.002327520000000','0.002304244800000','1.455750458957858','1.441192954368279','625.4513211305843','625.451321130584347','test','test','1.00'),('2018-05-08 03:59:59','2018-05-08 11:59:59','ZRXETH','4h','0.002324210000000','0.002300967900000','1.452515457937952','1.437990303358572','624.9501800344855','624.950180034485470','test','test','1.00'),('2018-05-09 15:59:59','2018-05-09 23:59:59','ZRXETH','4h','0.002399360000000','0.002375366400000','1.449287645809200','1.434794769351108','604.0309273344559','604.030927334455896','test','test','1.00'),('2018-05-10 11:59:59','2018-05-11 07:59:59','ZRXETH','4h','0.002455380000000','0.002430826200000','1.446067006596291','1.431606336530328','588.9381711166055','588.938171116605531','test','test','0.99'),('2018-05-11 15:59:59','2018-05-11 23:59:59','ZRXETH','4h','0.002498380000000','0.002473396200000','1.442853524359410','1.428424989115816','577.5156398784053','577.515639878405295','test','test','0.99'),('2018-05-19 23:59:59','2018-05-20 03:59:59','ZRXETH','4h','0.002104750000000','0.002083702500000','1.439647183194167','1.425250711362225','683.9991368068262','683.999136806826186','test','test','0.99'),('2018-05-23 19:59:59','2018-05-23 23:59:59','ZRXETH','4h','0.002354770000000','0.002331222300000','1.436447967231514','1.422083487559199','610.0162509423484','610.016250942348393','test','test','0.99'),('2018-05-24 19:59:59','2018-05-24 23:59:59','ZRXETH','4h','0.002320000000000','0.002296800000000','1.433255860637666','1.418923302031289','617.782698550718','617.782698550718010','test','test','1.00'),('2018-05-28 07:59:59','2018-05-28 11:59:59','ZRXETH','4h','0.002125350000000','0.002104096500000','1.430070847614026','1.415770139137886','672.8636919161673','672.863691916167340','test','test','0.99'),('2018-05-29 11:59:59','2018-06-01 15:59:59','ZRXETH','4h','0.002177980000000','0.002167680000000','1.426892912397106','1.420144917926225','655.1450942603266','655.145094260326573','test','test','0.94'),('2018-06-03 15:59:59','2018-06-03 19:59:59','ZRXETH','4h','0.002183070000000','0.002161239300000','1.425393358070244','1.411139424489542','652.9306701435337','652.930670143533689','test','test','0.99'),('2018-06-06 11:59:59','2018-06-06 15:59:59','ZRXETH','4h','0.002158050000000','0.002150460000000','1.422225817274532','1.417223758029791','659.0328385693252','659.032838569325236','test','test','0.35'),('2018-06-06 23:59:59','2018-06-07 03:59:59','ZRXETH','4h','0.002211310000000','0.002189196900000','1.421114248553479','1.406903106067944','642.6571799311173','642.657179931117298','test','test','0.99'),('2018-06-07 15:59:59','2018-06-07 19:59:59','ZRXETH','4h','0.002199630000000','0.002177633700000','1.417956216890026','1.403776654721126','644.6339688447722','644.633968844772198','test','test','0.99'),('2018-06-30 03:59:59','2018-07-10 03:59:59','ZRXETH','4h','0.001605700000000','0.001910000000000','1.414805203074716','1.682928279175878','881.1142822910354','881.114282291035352','test','test','0.0'),('2018-07-10 19:59:59','2018-07-10 23:59:59','ZRXETH','4h','0.001930100000000','0.001910799000000','1.474388108874974','1.459644227786224','763.8920827288607','763.892082728860714','test','test','0.99'),('2018-07-11 15:59:59','2018-07-11 19:59:59','ZRXETH','4h','0.001948990000000','0.001929500100000','1.471111690855252','1.456400573946699','754.8072031438086','754.807203143808579','test','test','1.00'),('2018-07-13 03:59:59','2018-07-13 07:59:59','ZRXETH','4h','0.001956070000000','0.001936509300000','1.467842553764462','1.453164128226817','750.4038985130707','750.403898513070658','test','test','1.00'),('2018-07-13 19:59:59','2018-07-21 03:59:59','ZRXETH','4h','0.002087150000000','0.002319540000000','1.464580681422763','1.627651809303287','701.7131885215548','701.713188521554798','test','test','0.0'),('2018-07-24 07:59:59','2018-07-24 11:59:59','ZRXETH','4h','0.002486400000000','0.002461536000000','1.500818709840657','1.485810522742250','603.6111284751677','603.611128475167675','test','test','0.99'),('2018-07-27 19:59:59','2018-07-27 23:59:59','ZRXETH','4h','0.002471310000000','0.002446596900000','1.497483557152123','1.482508721580602','605.9472737746873','605.947273774687346','test','test','1.00'),('2018-07-28 11:59:59','2018-07-29 11:59:59','ZRXETH','4h','0.002575840000000','0.002550081600000','1.494155815914007','1.479214257754867','580.0654605542296','580.065460554229617','test','test','0.99'),('2018-07-30 19:59:59','2018-07-31 11:59:59','ZRXETH','4h','0.002508630000000','0.002483543700000','1.490835469656420','1.475927114959856','594.2827238996664','594.282723899666394','test','test','1.00'),('2018-07-31 23:59:59','2018-08-01 03:59:59','ZRXETH','4h','0.002588100000000','0.002562219000000','1.487522501946072','1.472647276926611','574.7546470175313','574.754647017531283','test','test','1.00'),('2018-08-01 23:59:59','2018-08-02 11:59:59','ZRXETH','4h','0.002517650000000','0.002492473500000','1.484216896386192','1.469374727422330','589.5247140731205','589.524714073120549','test','test','1.00'),('2018-08-07 11:59:59','2018-08-07 23:59:59','ZRXETH','4h','0.002460000000000','0.002435400000000','1.480918636616445','1.466109450250280','601.9994457790427','601.999445779042730','test','test','1.00'),('2018-08-09 15:59:59','2018-08-10 11:59:59','ZRXETH','4h','0.002466000000000','0.002441340000000','1.477627706312853','1.462851429249724','599.2002053174587','599.200205317458654','test','test','1.00'),('2018-08-10 23:59:59','2018-08-14 03:59:59','ZRXETH','4h','0.002604410000000','0.002578365900000','1.474344089187713','1.459600648295836','566.095234309388','566.095234309388047','test','test','0.99'),('2018-08-14 15:59:59','2018-08-14 19:59:59','ZRXETH','4h','0.002626280000000','0.002600017200000','1.471067768989518','1.456357091299623','560.1336373081006','560.133637308100560','test','test','0.99'),('2018-08-15 07:59:59','2018-08-15 11:59:59','ZRXETH','4h','0.002561390000000','0.002535776100000','1.467798729502875','1.453120742207846','573.0477317014883','573.047731701488260','test','test','1.00'),('2018-08-17 15:59:59','2018-08-17 19:59:59','ZRXETH','4h','0.002701320000000','0.002674306800000','1.464536954548424','1.449891585002940','542.1560402130899','542.156040213089909','test','test','0.99'),('2018-08-18 15:59:59','2018-08-18 19:59:59','ZRXETH','4h','0.002540000000000','0.002514600000000','1.461282427982761','1.446669603702933','575.3080425128979','575.308042512897941','test','test','1.00'),('2018-08-19 11:59:59','2018-08-19 15:59:59','ZRXETH','4h','0.002598570000000','0.002572584300000','1.458035133698355','1.443454782361372','561.0913439693195','561.091343969319496','test','test','0.99'),('2018-08-23 23:59:59','2018-08-24 19:59:59','ZRXETH','4h','0.002588850000000','0.002562961500000','1.454795055623469','1.440247105067234','561.9464455736985','561.946445573698497','test','test','1.00'),('2018-08-25 15:59:59','2018-08-26 07:59:59','ZRXETH','4h','0.002573660000000','0.002547923400000','1.451562177722084','1.437046555944863','564.0069697326314','564.006969732631433','test','test','0.99'),('2018-08-26 15:59:59','2018-08-30 19:59:59','ZRXETH','4h','0.002617520000000','0.002632000000000','1.448336483993813','1.456348614670266','553.3239417440221','553.323941744022136','test','test','0.78'),('2018-09-01 03:59:59','2018-09-02 11:59:59','ZRXETH','4h','0.002738100000000','0.002710719000000','1.450116957477469','1.435615787902694','529.6070112404475','529.607011240447491','test','test','0.99'),('2018-09-03 15:59:59','2018-09-03 19:59:59','ZRXETH','4h','0.002754040000000','0.002736120000000','1.446894475349741','1.437479815795680','525.3716269007499','525.371626900749902','test','test','0.65'),('2018-09-04 07:59:59','2018-09-05 11:59:59','ZRXETH','4h','0.002804180000000','0.002776138200000','1.444802328782172','1.430354305494350','515.2316644374371','515.231664437437075','test','test','1.00'),('2018-09-06 03:59:59','2018-09-06 07:59:59','ZRXETH','4h','0.002793960000000','0.002766020400000','1.441591656940434','1.427175740371029','515.9671781057831','515.967178105783091','test','test','1.00'),('2018-09-06 15:59:59','2018-09-10 23:59:59','ZRXETH','4h','0.002858290000000','0.002829707100000','1.438388119925010','1.424004238725760','503.233793605621','503.233793605620974','test','test','0.99'),('2018-09-21 07:59:59','2018-09-21 19:59:59','ZRXETH','4h','0.002662500000000','0.002635875000000','1.435191701880733','1.420839784861926','539.0391368566133','539.039136856613254','test','test','1.00'),('2018-09-24 07:59:59','2018-09-24 11:59:59','ZRXETH','4h','0.002694850000000','0.002667901500000','1.432002386987665','1.417682363117788','531.3848217851327','531.384821785132658','test','test','0.99'),('2018-09-24 15:59:59','2018-09-24 23:59:59','ZRXETH','4h','0.002931780000000','0.002902462200000','1.428820159461025','1.414531957866415','487.3558587141687','487.355858714168676','test','test','0.99'),('2018-09-25 23:59:59','2018-09-28 15:59:59','ZRXETH','4h','0.002983000000000','0.002953170000000','1.425645003551112','1.411388553515601','477.92323283644384','477.923232836443844','test','test','1.00'),('2018-10-04 15:59:59','2018-10-05 19:59:59','ZRXETH','4h','0.002827900000000','0.002812290000000','1.422476903543221','1.414624835059785','503.015277606429','503.015277606428981','test','test','0.55'),('2018-10-07 03:59:59','2018-10-15 07:59:59','ZRXETH','4h','0.002898240000000','0.003421700000000','1.420731999435790','1.677334755737773','490.20508979097326','490.205089790973261','test','test','0.0'),('2018-10-15 19:59:59','2018-10-15 23:59:59','ZRXETH','4h','0.003615410000000','0.003579255900000','1.477754834169564','1.462977285827868','408.737828951506','408.737828951506003','test','test','1.00'),('2018-10-16 19:59:59','2018-10-25 07:59:59','ZRXETH','4h','0.004069980000000','0.004171840000000','1.474470934538076','1.511372739802978','362.27965113786223','362.279651137862231','test','test','0.0'),('2018-11-01 19:59:59','2018-11-02 19:59:59','ZRXETH','4h','0.004095010000000','0.004054059900000','1.482671335708055','1.467844622350974','362.06781807811336','362.067818078113362','test','test','1.00'),('2018-11-03 23:59:59','2018-11-04 03:59:59','ZRXETH','4h','0.004062670000000','0.004052540000000','1.479376510517592','1.475687782648594','364.138980157776','364.138980157776018','test','test','0.24'),('2018-11-27 11:59:59','2018-11-27 23:59:59','ZRXETH','4h','0.003287520000000','0.003262630000000','1.478556793213370','1.467362556042773','449.7483796945327','449.748379694532673','test','test','0.75'),('2018-11-28 15:59:59','2018-12-03 11:59:59','ZRXETH','4h','0.003405150000000','0.003442700000000','1.476069184953238','1.492346411476297','433.4813987499046','433.481398749904599','test','test','0.0'),('2018-12-03 19:59:59','2018-12-03 23:59:59','ZRXETH','4h','0.003555140000000','0.003519588600000','1.479686346402806','1.464889482938778','416.21042951973936','416.210429519739364','test','test','1.00'),('2018-12-05 19:59:59','2018-12-05 23:59:59','ZRXETH','4h','0.003437140000000','0.003420110000000','1.476398154521911','1.469083043536758','429.54262977996564','429.542629779965637','test','test','0.49'),('2018-12-06 15:59:59','2018-12-06 19:59:59','ZRXETH','4h','0.003439330000000','0.003432420000000','1.474772574302988','1.471809590672911','428.79647323838896','428.796473238388955','test','test','0.20'),('2018-12-06 23:59:59','2018-12-07 03:59:59','ZRXETH','4h','0.003501490000000','0.003549080000000','1.474114133496305','1.494149344681569','420.9962425985237','420.996242598523679','test','test','0.0'),('2018-12-08 03:59:59','2018-12-08 07:59:59','ZRXETH','4h','0.003582000000000','0.003546180000000','1.478566402648585','1.463780738622099','412.7767734920674','412.776773492067377','test','test','1.00'),('2018-12-11 11:59:59','2018-12-11 15:59:59','ZRXETH','4h','0.003497130000000','0.003491340000000','1.475280699531589','1.472838160864085','421.85469214229624','421.854692142296244','test','test','0.16'),('2018-12-11 19:59:59','2018-12-11 23:59:59','ZRXETH','4h','0.003505340000000','0.003470286600000','1.474737913161032','1.459990534029422','420.7118034658641','420.711803465864079','test','test','0.99'),('2019-01-13 19:59:59','2019-01-14 15:59:59','ZRXETH','4h','0.002310750000000','0.002287642500000','1.471460717798452','1.456746110620468','636.7892319802887','636.789231980288719','test','test','0.99'),('2019-01-15 23:59:59','2019-01-26 15:59:59','ZRXETH','4h','0.002330220000000','0.002482570000000','1.468190805092233','1.564181256275298','630.0653179065639','630.065317906563905','test','test','0.0'),('2019-02-08 03:59:59','2019-02-08 07:59:59','ZRXETH','4h','0.002354000000000','0.002330460000000','1.489522016466248','1.474626796301586','632.7621140468342','632.762114046834199','test','test','0.99'),('2019-02-26 11:59:59','2019-02-26 15:59:59','ZRXETH','4h','0.001777610000000','0.001827560000000','1.486211967540767','1.527973820691155','836.0731361439052','836.073136143905231','test','test','0.0'),('2019-02-26 19:59:59','2019-02-26 23:59:59','ZRXETH','4h','0.001827100000000','0.001808829000000','1.495492379351965','1.480537455558445','818.5060365343794','818.506036534379405','test','test','1.00'),('2019-02-27 07:59:59','2019-02-28 11:59:59','ZRXETH','4h','0.001824730000000','0.001813540000000','1.492169062953405','1.483018464336377','817.747865686104','817.747865686103978','test','test','0.61');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 19:47:33
