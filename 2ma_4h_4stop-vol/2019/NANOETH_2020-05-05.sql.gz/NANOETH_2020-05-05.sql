-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 11:59:59','2019-01-09 15:59:59','NANOETH','4h','0.006674000000000','0.006763000000000','1.297777777777778','1.315084074185063','194.45276862118334','194.452768621183338','test','test','0.0'),('2019-01-09 19:59:59','2019-01-14 15:59:59','NANOETH','4h','0.006715000000000','0.006798000000000','1.301623621423841','1.317712193364002','193.83821614651393','193.838216146513929','test','test','0.0'),('2019-01-15 23:59:59','2019-01-27 19:59:59','NANOETH','4h','0.007035000000000','0.008213000000000','1.305198859632766','1.523752414237940','185.5293332811323','185.529333281132295','test','test','0.0'),('2019-02-27 23:59:59','2019-02-28 03:59:59','NANOETH','4h','0.006418000000000','0.006387000000000','1.353766316211693','1.347227401315688','210.93273858081852','210.932738580818523','test','test','0.5'),('2019-03-01 11:59:59','2019-03-05 15:59:59','NANOETH','4h','0.006545000000000','0.006532000000000','1.352313224012581','1.349627193162747','206.61775767953878','206.617757679538784','test','test','0.4'),('2019-03-09 03:59:59','2019-03-09 07:59:59','NANOETH','4h','0.006510000000000','0.006486000000000','1.351716328268173','1.346733042265341','207.63691678466566','207.636916784665658','test','test','0.4'),('2019-03-09 15:59:59','2019-03-09 19:59:59','NANOETH','4h','0.006552000000000','0.006610000000000','1.350608931378655','1.362564871247392','206.13689428856156','206.136894288561564','test','test','0.0'),('2019-03-09 23:59:59','2019-03-16 07:59:59','NANOETH','4h','0.006633000000000','0.007230000000000','1.353265806905041','1.475065850131682','204.02017290894636','204.020172908946364','test','test','0.0'),('2019-03-17 19:59:59','2019-03-21 15:59:59','NANOETH','4h','0.007329000000000','0.007176000000000','1.380332483177628','1.351516700679855','188.33844769786165','188.338447697861653','test','test','2.2'),('2019-03-21 23:59:59','2019-03-22 03:59:59','NANOETH','4h','0.007230000000000','0.007180000000000','1.373928975955901','1.364427392443066','190.0316702566944','190.031670256694412','test','test','0.7'),('2019-03-24 03:59:59','2019-03-24 07:59:59','NANOETH','4h','0.007249000000000','0.007158000000000','1.371817512953049','1.354596462645596','189.24231107091305','189.242311070913047','test','test','1.3'),('2019-03-24 11:59:59','2019-03-24 15:59:59','NANOETH','4h','0.007188000000000','0.007216000000000','1.367990612884726','1.373319457787449','190.3158893829613','190.315889382961302','test','test','0.0'),('2019-03-24 23:59:59','2019-03-25 03:59:59','NANOETH','4h','0.007244000000000','0.007158000000000','1.369174800640886','1.352920102565911','189.0081171508678','189.008117150867804','test','test','1.2'),('2019-03-27 07:59:59','2019-03-29 11:59:59','NANOETH','4h','0.007222000000000','0.007276000000000','1.365562645513114','1.375773166540213','189.08372272405344','189.083722724053445','test','test','0.4'),('2019-03-29 19:59:59','2019-03-30 03:59:59','NANOETH','4h','0.007227000000000','0.007183000000000','1.367831650185803','1.359503908023332','189.2668673288782','189.266867328878192','test','test','0.6'),('2019-03-31 11:59:59','2019-04-07 23:59:59','NANOETH','4h','0.007498000000000','0.008035000000000','1.365981040816365','1.463811371426980','182.17938661194515','182.179386611945148','test','test','0.0'),('2019-04-08 03:59:59','2019-04-12 03:59:59','NANOETH','4h','0.008190000000000','0.008932000000000','1.387721114285391','1.513446275066803','169.44091749516372','169.440917495163717','test','test','0.0'),('2019-04-12 11:59:59','2019-04-13 11:59:59','NANOETH','4h','0.009923000000000','0.009526080000000','1.415660038903482','1.359033637347343','142.66452069973616','142.664520699736158','test','test','4.0'),('2019-04-13 19:59:59','2019-04-16 15:59:59','NANOETH','4h','0.009546000000000','0.009164160000000','1.403076394113229','1.346953338348700','146.98055668481342','146.980556684813422','test','test','4.0'),('2019-04-16 23:59:59','2019-04-21 11:59:59','NANOETH','4h','0.009181000000000','0.009556000000000','1.390604603943334','1.447404160252968','151.46548349235744','151.465483492357436','test','test','0.0'),('2019-04-21 15:59:59','2019-04-26 03:59:59','NANOETH','4h','0.009910000000000','0.010386000000000','1.403226727567697','1.470626921545721','141.59704617232055','141.597046172320546','test','test','1.0'),('2019-06-08 11:59:59','2019-06-08 15:59:59','NANOETH','4h','0.006482000000000','0.006424000000000','1.418204548451702','1.405514658940718','218.79119846524253','218.791198465242530','test','test','0.9'),('2019-06-08 19:59:59','2019-06-09 19:59:59','NANOETH','4h','0.006592000000000','0.006454000000000','1.415384573004817','1.385754252756840','214.71246556505108','214.712465565051076','test','test','2.1'),('2019-06-13 11:59:59','2019-06-13 15:59:59','NANOETH','4h','0.006472000000000','0.006360000000000','1.408800057394155','1.384420328341599','217.67615225496834','217.676152254968343','test','test','1.7'),('2019-06-13 23:59:59','2019-06-14 11:59:59','NANOETH','4h','0.006924000000000','0.006647040000000','1.403382339826920','1.347247046233843','202.68375791838827','202.683757918388267','test','test','4.0'),('2019-07-07 15:59:59','2019-07-07 19:59:59','NANOETH','4h','0.004472000000000','0.004293120000000','1.390907830139570','1.335271516933987','311.0259011940004','311.025901194000426','test','test','4.0'),('2019-07-08 03:59:59','2019-07-08 07:59:59','NANOETH','4h','0.004561000000000','0.004426000000000','1.378544204982774','1.337740989093128','302.2460436270059','302.246043627005918','test','test','3.0'),('2019-07-09 03:59:59','2019-07-09 07:59:59','NANOETH','4h','0.004488000000000','0.004401000000000','1.369476823673964','1.342929478830017','305.1418947580133','305.141894758013279','test','test','1.9'),('2019-07-13 03:59:59','2019-07-13 11:59:59','NANOETH','4h','0.004450000000000','0.004371000000000','1.363577413708642','1.339370084341680','306.42189072104316','306.421890721043155','test','test','1.8'),('2019-07-14 15:59:59','2019-07-15 23:59:59','NANOETH','4h','0.004497000000000','0.004444000000000','1.358198007182650','1.342190781391972','302.0231281260063','302.023128126006327','test','test','1.9'),('2019-07-16 11:59:59','2019-07-31 15:59:59','NANOETH','4h','0.004481000000000','0.005844000000000','1.354640845895833','1.766686253830674','302.3077094166108','302.307709416610805','test','test','0.0'),('2019-08-09 23:59:59','2019-08-10 03:59:59','NANOETH','4h','0.005367000000000','0.005434000000000','1.446206492103576','1.464260495265666','269.46273376254436','269.462733762544360','test','test','0.0'),('2019-08-10 07:59:59','2019-08-10 11:59:59','NANOETH','4h','0.005276000000000','0.005330000000000','1.450218492806262','1.465061517562050','274.87082881089117','274.870828810891169','test','test','0.0'),('2019-08-10 15:59:59','2019-08-11 15:59:59','NANOETH','4h','0.005360000000000','0.005254000000000','1.453516942751993','1.424772018137868','271.178534095521','271.178534095521002','test','test','2.0'),('2019-08-12 15:59:59','2019-08-12 23:59:59','NANOETH','4h','0.005403000000000','0.005241000000000','1.447129181726632','1.403739411702624','267.8380865679496','267.838086567949574','test','test','3.0'),('2019-08-13 03:59:59','2019-08-13 07:59:59','NANOETH','4h','0.005316000000000','0.005216000000000','1.437487010610186','1.410446246678467','270.4076393171907','270.407639317190672','test','test','1.9'),('2019-08-14 19:59:59','2019-08-14 23:59:59','NANOETH','4h','0.005355000000000','0.005290000000000','1.431477951958692','1.414102402588512','267.3161441566185','267.316144156618520','test','test','1.2'),('2019-08-15 01:59:59','2019-08-18 15:59:59','NANOETH','4h','0.005571000000000','0.005357000000000','1.427616718765319','1.372777376131002','256.2586104407322','256.258610440732184','test','test','3.8'),('2019-08-21 19:59:59','2019-08-22 03:59:59','NANOETH','4h','0.005419000000000','0.005346000000000','1.415430198179916','1.396362767940548','261.197674511887','261.197674511886987','test','test','1.3'),('2019-08-22 07:59:59','2019-08-22 11:59:59','NANOETH','4h','0.005392000000000','0.005358000000000','1.411192991460056','1.402294519332897','261.71976844585606','261.719768445856062','test','test','0.6'),('2019-08-23 11:59:59','2019-08-23 15:59:59','NANOETH','4h','0.005395000000000','0.005331000000000','1.409215553209576','1.392498260270667','261.20770217044964','261.207702170449636','test','test','1.2'),('2019-08-23 19:59:59','2019-08-23 23:59:59','NANOETH','4h','0.005347000000000','0.005300000000000','1.405500599223152','1.393146283127493','262.85778926933824','262.857789269338241','test','test','0.9'),('2019-08-24 19:59:59','2019-08-25 15:59:59','NANOETH','4h','0.005452000000000','0.005430000000000','1.402755195646339','1.397094774827517','257.29185540101594','257.291855401015937','test','test','1.1'),('2019-08-25 23:59:59','2019-08-26 07:59:59','NANOETH','4h','0.005535000000000','0.005386000000000','1.401497324353267','1.363769573435717','253.2063819969769','253.206381996976887','test','test','2.7'),('2019-08-28 19:59:59','2019-09-01 03:59:59','NANOETH','4h','0.005550000000000','0.005548000000000','1.393113379704923','1.392611356865390','251.01141976665275','251.011419766652750','test','test','0.0'),('2019-09-02 03:59:59','2019-09-03 15:59:59','NANOETH','4h','0.005657000000000','0.005486000000000','1.393001819073915','1.350894109853191','246.24391357148937','246.243913571489372','test','test','3.0'),('2019-09-26 07:59:59','2019-09-26 19:59:59','NANOETH','4h','0.004554000000000','0.004533000000000','1.383644550358199','1.377264107767614','303.8305995516466','303.830599551646628','test','test','0.5'),('2019-09-26 23:59:59','2019-09-27 03:59:59','NANOETH','4h','0.004540000000000','0.004477000000000','1.382226674226958','1.363045995707950','304.45521458743565','304.455214587435648','test','test','1.4'),('2019-10-08 15:59:59','2019-10-08 19:59:59','NANOETH','4h','0.004278000000000','0.004370000000000','1.377964301222734','1.407597942109244','322.10479224467826','322.104792244678265','test','test','0.0'),('2019-10-08 23:59:59','2019-10-09 15:59:59','NANOETH','4h','0.004403000000000','0.004226880000000','1.384549554753069','1.329167572562946','314.45595156781036','314.455951567810359','test','test','4.0'),('2019-10-12 03:59:59','2019-10-12 11:59:59','NANOETH','4h','0.004282000000000','0.004229000000000','1.372242447599709','1.355257662517321','320.4676430639207','320.467643063920718','test','test','1.2'),('2019-10-13 19:59:59','2019-10-14 07:59:59','NANOETH','4h','0.004308000000000','0.004301000000000','1.368468050914734','1.366244449160694','317.6573934342464','317.657393434246387','test','test','0.2'),('2019-10-15 07:59:59','2019-10-23 03:59:59','NANOETH','4h','0.004297000000000','0.004531000000000','1.367973917191613','1.442469122363323','318.35557765688003','318.355577656880030','test','test','0.0'),('2019-10-23 07:59:59','2019-10-23 15:59:59','NANOETH','4h','0.004593000000000','0.004550000000000','1.384528407229771','1.371566351599273','301.44315419764234','301.443154197642343','test','test','0.9'),('2019-10-24 11:59:59','2019-10-24 15:59:59','NANOETH','4h','0.004572000000000','0.004596000000000','1.381647950422994','1.388900695569572','302.1977144407248','302.197714440724781','test','test','0.0'),('2019-10-25 15:59:59','2019-10-25 19:59:59','NANOETH','4h','0.004575000000000','0.004513000000000','1.383259671566678','1.364513857438343','302.35184077960173','302.351840779601730','test','test','1.4'),('2019-10-27 19:59:59','2019-10-27 23:59:59','NANOETH','4h','0.004618000000000','0.004615000000000','1.379093935093715','1.378198031714486','298.6344597431171','298.634459743117077','test','test','0.1'),('2019-10-28 07:59:59','2019-10-28 23:59:59','NANOETH','4h','0.004666000000000','0.004574000000000','1.378894845453886','1.351707034527663','295.51968398068703','295.519683980687034','test','test','2.0'),('2019-10-29 15:59:59','2019-10-29 19:59:59','NANOETH','4h','0.004658000000000','0.004542000000000','1.372853109692503','1.338664410524549','294.7301652409839','294.730165240983922','test','test','2.5'),('2019-10-31 11:59:59','2019-11-04 11:59:59','NANOETH','4h','0.004754000000000','0.004671000000000','1.365255620988513','1.341419647799189','287.1803998713742','287.180399871374220','test','test','2.2'),('2019-11-04 15:59:59','2019-11-13 23:59:59','NANOETH','4h','0.004673000000000','0.005272000000000','1.359958738057552','1.534282573729812','291.0247673994334','291.024767399433415','test','test','0.0'),('2019-11-14 23:59:59','2019-11-15 03:59:59','NANOETH','4h','0.005300000000000','0.005174000000000','1.398697368206943','1.365445317566552','263.90516381263086','263.905163812630860','test','test','2.4'),('2019-11-20 19:59:59','2019-11-20 23:59:59','NANOETH','4h','0.005193000000000','0.005154000000000','1.391308023620190','1.380859147648461','267.9198967109936','267.919896710993612','test','test','0.8'),('2019-11-21 07:59:59','2019-11-21 11:59:59','NANOETH','4h','0.005291000000000','0.005233000000000','1.388986051182028','1.373759970862890','262.51862619202944','262.518626192029444','test','test','1.1'),('2019-11-21 15:59:59','2019-11-22 11:59:59','NANOETH','4h','0.005317000000000','0.005287000000000','1.385602477777775','1.377784521348711','260.59854763546645','260.598547635466446','test','test','1.4'),('2019-11-22 15:59:59','2019-11-23 03:59:59','NANOETH','4h','0.005244000000000','0.005175000000000','1.383865154126872','1.365656402098887','263.8949569273211','263.894956927321118','test','test','1.3'),('2019-11-24 03:59:59','2019-11-25 07:59:59','NANOETH','4h','0.005284000000000','0.005383000000000','1.379818764787320','1.405670781765735','261.13148463045417','261.131484630454167','test','test','0.1'),('2019-11-25 11:59:59','2019-12-04 03:59:59','NANOETH','4h','0.005310000000000','0.005662000000000','1.385563657449190','1.477412698394975','260.93477541416','260.934775414160015','test','test','0.6'),('2019-12-05 03:59:59','2019-12-05 07:59:59','NANOETH','4h','0.005591000000000','0.005632000000000','1.405974555437142','1.416284867862991','251.47103477680952','251.471034776809518','test','test','0.0'),('2019-12-07 19:59:59','2019-12-07 23:59:59','NANOETH','4h','0.005587000000000','0.005593000000000','1.408265735976220','1.409778102973868','252.06116627460526','252.061166274605256','test','test','0.0'),('2019-12-09 15:59:59','2019-12-09 19:59:59','NANOETH','4h','0.005583000000000','0.005578000000000','1.408601817531252','1.407340307753774','252.30195549547778','252.301955495477785','test','test','0.1'),('2019-12-20 19:59:59','2019-12-21 11:59:59','NANOETH','4h','0.005443000000000','0.005272000000000','1.408321482025146','1.364076952643132','258.73993790651224','258.739937906512239','test','test','3.1'),('2019-12-30 19:59:59','2019-12-30 23:59:59','NANOETH','4h','0.005211000000000','0.005156000000000','1.398489364384699','1.383728874067839','268.3725512156397','268.372551215639703','test','test','1.1');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:21:07
