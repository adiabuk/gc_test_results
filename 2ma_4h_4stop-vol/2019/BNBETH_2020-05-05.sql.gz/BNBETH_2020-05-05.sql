-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 11:59:59','2019-01-30 15:59:59','BNBETH','4h','0.043388000000000','0.056441000000000','1.297777777777778','1.688205853128873','29.910984091863593','29.910984091863593','test','test','0.0'),('2019-02-01 07:59:59','2019-02-13 23:59:59','BNBETH','4h','0.061007000000000','0.073157000000000','1.384539572300243','1.660280975802267','22.694765720331162','22.694765720331162','test','test','0.0'),('2019-02-15 03:59:59','2019-02-17 03:59:59','BNBETH','4h','0.074730000000000','0.072892000000000','1.445815439745137','1.410255306221096','19.34718907728004','19.347189077280039','test','test','2.5'),('2019-02-19 19:59:59','2019-02-21 07:59:59','BNBETH','4h','0.074288000000000','0.071316480000000','1.437913187850906','1.380396660336870','19.35592811558941','19.355928115589411','test','test','4.0'),('2019-02-24 23:59:59','2019-02-25 03:59:59','BNBETH','4h','0.075142000000000','0.072136320000000','1.425131737292231','1.368126467800542','18.965847825347094','18.965847825347094','test','test','4.0'),('2019-02-25 07:59:59','2019-02-25 15:59:59','BNBETH','4h','0.072100000000000','0.071733000000000','1.412463899627412','1.405274242884510','19.590345348507793','19.590345348507793','test','test','0.5'),('2019-02-27 23:59:59','2019-03-16 07:59:59','BNBETH','4h','0.072951000000000','0.108480000000000','1.410866198128989','2.097994066880957','19.339915808268415','19.339915808268415','test','test','1.0'),('2019-03-16 11:59:59','2019-03-19 15:59:59','BNBETH','4h','0.111620000000000','0.111646000000000','1.563561280073871','1.563925485353229','14.007895359916422','14.007895359916422','test','test','0.4'),('2019-03-19 19:59:59','2019-03-20 23:59:59','BNBETH','4h','0.110699000000000','0.108921000000000','1.563642214580395','1.538527661987111','14.125170187448802','14.125170187448802','test','test','1.6'),('2019-03-24 11:59:59','2019-03-26 15:59:59','BNBETH','4h','0.124743000000000','0.119753280000000','1.558061202892999','1.495738754777279','12.490169411453937','12.490169411453937','test','test','4.0'),('2019-03-29 11:59:59','2019-03-29 19:59:59','BNBETH','4h','0.118494000000000','0.116447000000000','1.544211769978394','1.517535301185495','13.03198280063458','13.031982800634580','test','test','1.7'),('2019-03-31 03:59:59','2019-04-02 23:59:59','BNBETH','4h','0.121413000000000','0.120740000000000','1.538283665802195','1.529756861365398','12.669843145315532','12.669843145315532','test','test','0.6'),('2019-04-04 19:59:59','2019-04-05 07:59:59','BNBETH','4h','0.122672000000000','0.117765120000000','1.536388820371795','1.474933267556923','12.524364324147278','12.524364324147278','test','test','4.0'),('2019-04-12 19:59:59','2019-04-13 03:59:59','BNBETH','4h','0.111895000000000','0.110279000000000','1.522732030857379','1.500740565985262','13.608579747597116','13.608579747597116','test','test','1.4'),('2019-04-13 11:59:59','2019-04-18 03:59:59','BNBETH','4h','0.111510000000000','0.113702000000000','1.517845038663575','1.547681970999245','13.611739204228995','13.611739204228995','test','test','0.0'),('2019-04-18 07:59:59','2019-04-24 07:59:59','BNBETH','4h','0.120381000000000','0.131157000000000','1.524475468071502','1.660940089929922','12.663754812399814','12.663754812399814','test','test','0.0'),('2019-04-24 11:59:59','2019-04-30 03:59:59','BNBETH','4h','0.134610000000000','0.138262000000000','1.554800939595595','1.596983043684467','11.550411853469988','11.550411853469988','test','test','0.0'),('2019-04-30 07:59:59','2019-04-30 11:59:59','BNBETH','4h','0.138620000000000','0.136224000000000','1.564174740504233','1.537138507072924','11.2839037693279','11.283903769327900','test','test','1.7'),('2019-04-30 15:59:59','2019-04-30 19:59:59','BNBETH','4h','0.138448000000000','0.139236000000000','1.558166688630609','1.567035255534002','11.254526527148167','11.254526527148167','test','test','0.0'),('2019-05-02 11:59:59','2019-05-03 11:59:59','BNBETH','4h','0.141443000000000','0.140481000000000','1.560137481275808','1.549526477147026','11.030149822018815','11.030149822018815','test','test','0.7'),('2019-05-03 23:59:59','2019-05-04 03:59:59','BNBETH','4h','0.140953000000000','0.139561000000000','1.557779480358300','1.542395423001176','11.051765342761776','11.051765342761776','test','test','1.0'),('2019-05-18 19:59:59','2019-05-19 03:59:59','BNBETH','4h','0.116093000000000','0.114000000000000','1.554360800945606','1.526337774954554','13.38892785047855','13.388927850478550','test','test','1.8'),('2019-05-20 23:59:59','2019-05-21 03:59:59','BNBETH','4h','0.116999000000000','0.114067000000000','1.548133461836484','1.509337170328825','13.23202302444024','13.232023024440240','test','test','2.5'),('2019-05-21 15:59:59','2019-05-26 23:59:59','BNBETH','4h','0.124170000000000','0.125118000000000','1.539512063723670','1.551265767810084','12.39842203208239','12.398422032082390','test','test','0.6'),('2019-05-27 03:59:59','2019-05-27 15:59:59','BNBETH','4h','0.128441000000000','0.126001000000000','1.542123997965096','1.512828192458795','12.00647766651689','12.006477666516890','test','test','1.9'),('2019-06-01 23:59:59','2019-06-02 03:59:59','BNBETH','4h','0.125969000000000','0.123630000000000','1.535613818963696','1.507100448828535','12.19041048959423','12.190410489594230','test','test','1.9'),('2019-06-04 11:59:59','2019-06-04 15:59:59','BNBETH','4h','0.124561000000000','0.123617000000000','1.529277514489215','1.517687707296933','12.277338127417211','12.277338127417211','test','test','0.8'),('2019-06-06 03:59:59','2019-06-14 07:59:59','BNBETH','4h','0.126974000000000','0.131103000000000','1.526702001779819','1.576348012501297','12.023737157054352','12.023737157054352','test','test','1.5'),('2019-06-18 03:59:59','2019-06-21 03:59:59','BNBETH','4h','0.128230000000000','0.130000000000000','1.537734448606815','1.558960292590548','11.992002250696517','11.992002250696517','test','test','0.0'),('2019-06-21 07:59:59','2019-06-21 19:59:59','BNBETH','4h','0.130827000000000','0.128840000000000','1.542451302825422','1.519024558050153','11.790007435968276','11.790007435968276','test','test','1.5'),('2019-06-21 23:59:59','2019-06-22 03:59:59','BNBETH','4h','0.131288000000000','0.126428000000000','1.537245359542029','1.480339835447106','11.708955575087053','11.708955575087053','test','test','3.7'),('2019-07-04 23:59:59','2019-07-05 03:59:59','BNBETH','4h','0.116810000000000','0.115648000000000','1.524599687520935','1.509433307614255','13.05196205394174','13.051962053941740','test','test','1.0'),('2019-07-12 03:59:59','2019-07-25 03:59:59','BNBETH','4h','0.114090000000000','0.132219000000000','1.521229380875006','1.762954049521539','13.333590856998914','13.333590856998914','test','test','0.0'),('2019-07-27 03:59:59','2019-07-27 07:59:59','BNBETH','4h','0.131819000000000','0.131477000000000','1.574945973907569','1.570859829094785','11.947791850245933','11.947791850245933','test','test','0.3'),('2019-07-27 11:59:59','2019-07-28 07:59:59','BNBETH','4h','0.133344000000000','0.131584000000000','1.574037941726950','1.553262302947257','11.804340215734868','11.804340215734868','test','test','1.3'),('2019-08-01 11:59:59','2019-08-02 03:59:59','BNBETH','4h','0.131630000000000','0.130976000000000','1.569421133109240','1.561623507787859','11.922974497525187','11.922974497525187','test','test','0.5'),('2019-08-07 19:59:59','2019-08-18 15:59:59','BNBETH','4h','0.133648000000000','0.144352000000000','1.567688327482267','1.693246030234050','11.729979704015525','11.729979704015525','test','test','1.8'),('2019-08-19 07:59:59','2019-08-19 19:59:59','BNBETH','4h','0.143887000000000','0.143865000000000','1.595590039204885','1.595346077061936','11.089188315865126','11.089188315865126','test','test','0.3'),('2019-08-21 03:59:59','2019-08-22 03:59:59','BNBETH','4h','0.143400000000000','0.143184000000000','1.595535825395341','1.593132507834076','11.126470191041431','11.126470191041431','test','test','0.2'),('2019-09-05 19:59:59','2019-09-06 03:59:59','BNBETH','4h','0.133079000000000','0.128751000000000','1.595001754826171','1.543129050681357','11.985375264513344','11.985375264513344','test','test','3.3'),('2019-09-06 23:59:59','2019-09-07 03:59:59','BNBETH','4h','0.130289000000000','0.130426000000000','1.583474487238435','1.585139524231210','12.153554691788521','12.153554691788521','test','test','0.0'),('2019-10-09 07:59:59','2019-10-09 15:59:59','BNBETH','4h','0.093589000000000','0.090726000000000','1.583844495459052','1.535392788629197','16.923404411405738','16.923404411405738','test','test','3.1'),('2019-10-09 19:59:59','2019-10-10 03:59:59','BNBETH','4h','0.091546000000000','0.090997000000000','1.573077449496862','1.563643727436108','17.183464591537167','17.183464591537167','test','test','0.6'),('2019-10-11 11:59:59','2019-10-11 15:59:59','BNBETH','4h','0.091645000000000','0.091498000000000','1.570981066816694','1.568461188843841','17.14202702620649','17.142027026206492','test','test','0.2'),('2019-10-12 19:59:59','2019-10-24 07:59:59','BNBETH','4h','0.096199000000000','0.103161000000000','1.570421093933837','1.684073747869610','16.324713291550196','16.324713291550196','test','test','0.6'),('2019-10-25 03:59:59','2019-10-25 19:59:59','BNBETH','4h','0.106911000000000','0.103276000000000','1.595677239252898','1.541423825060867','14.925285885015558','14.925285885015558','test','test','3.4'),('2019-10-26 03:59:59','2019-10-26 07:59:59','BNBETH','4h','0.103708000000000','0.102166000000000','1.583620924988002','1.560074588482318','15.269997733906763','15.269997733906763','test','test','1.5'),('2019-10-27 11:59:59','2019-10-27 15:59:59','BNBETH','4h','0.104917000000000','0.104360000000000','1.578388405764517','1.570008807205553','15.044162583418485','15.044162583418485','test','test','0.5'),('2019-10-27 19:59:59','2019-10-28 03:59:59','BNBETH','4h','0.103999000000000','0.111132000000000','1.576526272751414','1.684655792300023','15.159052228881182','15.159052228881182','test','test','0.0'),('2019-10-29 07:59:59','2019-10-30 03:59:59','BNBETH','4h','0.111850000000000','0.107376000000000','1.600555054873327','1.536532852678394','14.309835090508063','14.309835090508063','test','test','4.0'),('2019-10-31 11:59:59','2019-11-05 15:59:59','BNBETH','4h','0.110461000000000','0.108555000000000','1.586327898830009','1.558955876349948','14.360977166873454','14.360977166873454','test','test','1.7'),('2019-11-05 19:59:59','2019-11-05 23:59:59','BNBETH','4h','0.109260000000000','0.109479000000000','1.580245227167773','1.583412659940514','14.463163345851848','14.463163345851848','test','test','0.0'),('2019-11-11 23:59:59','2019-11-12 03:59:59','BNBETH','4h','0.108600000000000','0.109105000000000','1.580949101117271','1.588300660012890','14.557542367562345','14.557542367562345','test','test','0.0'),('2019-11-12 07:59:59','2019-11-16 11:59:59','BNBETH','4h','0.109271000000000','0.110842000000000','1.582582780871853','1.605335730407866','14.4830996410013','14.483099641001299','test','test','0.0'),('2019-11-24 07:59:59','2019-11-24 11:59:59','BNBETH','4h','0.107656000000000','0.106797000000000','1.587638991879856','1.574971031951707','14.747334025784495','14.747334025784495','test','test','0.8'),('2019-12-04 11:59:59','2019-12-04 15:59:59','BNBETH','4h','0.104297000000000','0.104092000000000','1.584823889673600','1.581708853791618','15.195296985278583','15.195296985278583','test','test','0.2'),('2019-12-05 03:59:59','2019-12-06 11:59:59','BNBETH','4h','0.105446000000000','0.104906000000000','1.584131659477604','1.576019155483921','15.023155543857563','15.023155543857563','test','test','0.8'),('2019-12-06 15:59:59','2019-12-08 03:59:59','BNBETH','4h','0.105118000000000','0.104823000000000','1.582328880812342','1.577888280536084','15.052882292398463','15.052882292398463','test','test','0.3'),('2019-12-18 11:59:59','2019-12-18 19:59:59','BNBETH','4h','0.103794000000000','0.102347000000000','1.581342080750951','1.559296471266331','15.235390106855416','15.235390106855416','test','test','1.4'),('2019-12-19 11:59:59','2019-12-22 11:59:59','BNBETH','4h','0.104980000000000','0.103542000000000','1.576443056421035','1.554849180300503','15.016603699952707','15.016603699952707','test','test','1.4'),('2019-12-22 15:59:59','2019-12-22 19:59:59','BNBETH','4h','0.103843000000000','0.103529000000000','1.571644417283139','1.566892085907631','15.134813297797052','15.134813297797052','test','test','0.3'),('2019-12-23 03:59:59','2019-12-23 07:59:59','BNBETH','4h','0.103381000000000','0.103891000000000','1.570588343644138','1.578336382986556','15.192234004741081','15.192234004741081','test','test','0.0'),('2019-12-23 15:59:59','2019-12-23 19:59:59','BNBETH','4h','0.103788000000000','0.104312000000000','1.572310130164675','1.580248336009342','15.149247795165868','15.149247795165868','test','test','0.0'),('2019-12-23 23:59:59','2019-12-26 19:59:59','BNBETH','4h','0.103955000000000','0.103488000000000','1.574074175907934','1.567002917765959','15.141880389667973','15.141880389667973','test','test','0.4'),('2019-12-26 23:59:59','2019-12-29 19:59:59','BNBETH','4h','0.104535000000000','0.104526000000000','1.572502785209718','1.572367399692265','15.042835272489764','15.042835272489764','test','test','0.2'),('2019-12-29 23:59:59','2019-12-30 03:59:59','BNBETH','4h','0.104919000000000','0.106623000000000','1.572472699539172','1.598011386335794','14.987492251538544','14.987492251538544','test','test','0.0'),('2019-12-30 15:59:59','2019-12-30 23:59:59','BNBETH','4h','0.106329000000000','0.105284000000000','1.578147963271755','1.562637946045796','14.842121747329093','14.842121747329093','test','test','1.0'),('2019-12-31 15:59:59','2020-01-01 11:59:59','BNBETH','4h','0.105931000000000','0.104850000000000','1.574701292777098','1.558631850427908','14.865349074181283','14.865349074181283','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:37:37
