-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-11 15:59:59','CMTETH','4h','0.000183550000000','0.000181860000000','1.297777777777778','1.285828747843458','7070.431913798844','7070.431913798844107','test','test','0.9'),('2019-01-13 07:59:59','2019-01-14 15:59:59','CMTETH','4h','0.000189330000000','0.000181756800000','1.295122437792373','1.243317540280678','6840.555843196395','6840.555843196394562','test','test','4.0'),('2019-01-15 23:59:59','2019-01-27 19:59:59','CMTETH','4h','0.000187730000000','0.000227580000000','1.283610238345330','1.556085964111385','6837.533896262345','6837.533896262344570','test','test','0.7'),('2019-02-05 23:59:59','2019-02-06 03:59:59','CMTETH','4h','0.000215820000000','0.000213580000000','1.344160399626676','1.330209332556137','6228.154942204965','6228.154942204964755','test','test','1.0'),('2019-02-07 19:59:59','2019-02-07 23:59:59','CMTETH','4h','0.000216230000000','0.000215410000000','1.341060162499889','1.335974516043570','6202.007873560047','6202.007873560047301','test','test','0.4'),('2019-02-08 07:59:59','2019-02-08 11:59:59','CMTETH','4h','0.000214390000000','0.000216070000000','1.339930018842930','1.350429960219189','6249.965104915945','6249.965104915944721','test','test','0.0'),('2019-02-10 07:59:59','2019-02-10 15:59:59','CMTETH','4h','0.000220300000000','0.000214460000000','1.342263339148765','1.306680870239874','6092.888511796482','6092.888511796481907','test','test','2.7'),('2019-02-11 03:59:59','2019-02-11 11:59:59','CMTETH','4h','0.000216880000000','0.000210440000000','1.334356123835678','1.294733966709609','6152.5088705075505','6152.508870507550455','test','test','3.0'),('2019-02-16 03:59:59','2019-02-16 11:59:59','CMTETH','4h','0.000213290000000','0.000208490000000','1.325551200029885','1.295720238615175','6214.783628064534','6214.783628064534241','test','test','2.3'),('2019-02-16 19:59:59','2019-02-17 11:59:59','CMTETH','4h','0.000210590000000','0.000203070000000','1.318922097493282','1.271824447210033','6262.985410006564','6262.985410006564052','test','test','3.6'),('2019-02-25 15:59:59','2019-02-25 19:59:59','CMTETH','4h','0.000193790000000','0.000191180000000','1.308455952985894','1.290833423251165','6751.927101428835','6751.927101428835158','test','test','1.3'),('2019-02-26 03:59:59','2019-03-05 15:59:59','CMTETH','4h','0.000201420000000','0.000205520000000','1.304539835267065','1.331094364730847','6476.71450336146','6476.714503361459720','test','test','0.9'),('2019-03-08 03:59:59','2019-03-16 03:59:59','CMTETH','4h','0.000212910000000','0.000237970000000','1.310440841814572','1.464682763264355','6154.905085785414','6154.905085785413576','test','test','0.4'),('2019-03-17 15:59:59','2019-03-18 15:59:59','CMTETH','4h','0.000239420000000','0.000239550000000','1.344716824358968','1.345446977174801','5616.560121790028','5616.560121790027551','test','test','0.9'),('2019-03-19 11:59:59','2019-03-21 15:59:59','CMTETH','4h','0.000242390000000','0.000241470000000','1.344879080540265','1.339774543413746','5548.40992012981','5548.409920129810416','test','test','0.4'),('2019-03-21 19:59:59','2019-03-21 23:59:59','CMTETH','4h','0.000244590000000','0.000242790000000','1.343744738956594','1.333855779759072','5493.866220845472','5493.866220845471616','test','test','0.7'),('2019-03-22 03:59:59','2019-03-22 07:59:59','CMTETH','4h','0.000243920000000','0.000242340000000','1.341547192468256','1.332857275429473','5499.947492900359','5499.947492900359066','test','test','0.6'),('2019-03-22 15:59:59','2019-03-22 19:59:59','CMTETH','4h','0.000242180000000','0.000243180000000','1.339616099792970','1.345147589180174','5531.489387203611','5531.489387203610931','test','test','0.0'),('2019-03-23 07:59:59','2019-03-24 11:59:59','CMTETH','4h','0.000247080000000','0.000243860000000','1.340845319656794','1.323371133444657','5426.765904390455','5426.765904390455034','test','test','1.3'),('2019-03-24 23:59:59','2019-03-25 07:59:59','CMTETH','4h','0.000242850000000','0.000240460000000','1.336962167165207','1.323804499553410','5505.300255981912','5505.300255981912414','test','test','1.0'),('2019-03-27 15:59:59','2019-03-27 23:59:59','CMTETH','4h','0.000243660000000','0.000238650000000','1.334038241029253','1.306608496354064','5474.9989371634765','5474.998937163476512','test','test','2.1'),('2019-03-28 07:59:59','2019-03-29 15:59:59','CMTETH','4h','0.000242980000000','0.000241030000000','1.327942742212544','1.317285534428716','5465.234760937295','5465.234760937294595','test','test','0.8'),('2019-03-30 15:59:59','2019-04-03 03:59:59','CMTETH','4h','0.000252750000000','0.000244460000000','1.325574473816138','1.282096679996412','5244.607215889763','5244.607215889763211','test','test','3.3'),('2019-04-03 07:59:59','2019-04-07 23:59:59','CMTETH','4h','0.000261660000000','0.000275150000000','1.315912741856199','1.383755220216056','5029.094022228078','5029.094022228077847','test','test','0.0'),('2019-05-24 11:59:59','2019-05-24 19:59:59','CMTETH','4h','0.000165310000000','0.000169570000000','1.330988848158389','1.365288119183461','8051.472071613265','8051.472071613265143','test','test','1.6'),('2019-05-24 23:59:59','2019-05-25 07:59:59','CMTETH','4h','0.000168100000000','0.000163150000000','1.338610908386183','1.299193157068446','7963.182084391333','7963.182084391332864','test','test','2.9'),('2019-05-26 15:59:59','2019-05-26 19:59:59','CMTETH','4h','0.000168090000000','0.000161366400000','1.329851408093352','1.276657351769618','7911.54386396188','7911.543863961879651','test','test','4.0'),('2019-05-27 15:59:59','2019-05-27 19:59:59','CMTETH','4h','0.000165250000000','0.000164360000000','1.318030506688078','1.310931885502284','7975.978860442227','7975.978860442227415','test','test','0.5'),('2019-05-28 15:59:59','2019-05-28 19:59:59','CMTETH','4h','0.000165040000000','0.000162570000000','1.316453035313457','1.296750908573126','7976.569530498408','7976.569530498408312','test','test','1.5'),('2019-06-08 11:59:59','2019-06-09 15:59:59','CMTETH','4h','0.000148210000000','0.000149640000000','1.312074784926717','1.324734301440078','8852.808750601966','8852.808750601965585','test','test','0.0'),('2019-06-10 07:59:59','2019-06-11 07:59:59','CMTETH','4h','0.000153230000000','0.000148790000000','1.314888010818575','1.276787751286927','8581.139534155029','8581.139534155028741','test','test','2.9'),('2019-06-13 19:59:59','2019-06-18 07:59:59','CMTETH','4h','0.000167940000000','0.000167170000000','1.306421286478209','1.300431382997274','7779.0954297856915','7779.095429785691522','test','test','3.1'),('2019-06-18 19:59:59','2019-06-19 15:59:59','CMTETH','4h','0.000182500000000','0.000175200000000','1.305090196815779','1.252886588943148','7151.179160634405','7151.179160634404980','test','test','4.0'),('2019-07-03 07:59:59','2019-07-07 19:59:59','CMTETH','4h','0.000153910000000','0.000180160000000','1.293489395066305','1.514099469918430','8404.19332769999','8404.193327699989823','test','test','0.0'),('2019-07-09 15:59:59','2019-07-09 19:59:59','CMTETH','4h','0.000233600000000','0.000224256000000','1.342513856144555','1.288813301898773','5747.0627403448425','5747.062740344842496','test','test','4.0'),('2019-07-09 23:59:59','2019-07-10 07:59:59','CMTETH','4h','0.000214630000000','0.000206044800000','1.330580399645493','1.277357183659673','6199.414805225237','6199.414805225236705','test','test','4.0'),('2019-07-10 11:59:59','2019-07-16 19:59:59','CMTETH','4h','0.000203530000000','0.000206600000000','1.318753018315310','1.338644787421722','6479.4036177237285','6479.403617723728530','test','test','3.2'),('2019-07-19 15:59:59','2019-07-19 19:59:59','CMTETH','4h','0.000208700000000','0.000204870000000','1.323173411450069','1.298890928623745','6340.073844993141','6340.073844993141392','test','test','1.8'),('2019-07-23 03:59:59','2019-07-23 07:59:59','CMTETH','4h','0.000208660000000','0.000200440000000','1.317777304155330','1.265864482147486','6315.4284681075915','6315.428468107591470','test','test','3.9'),('2019-07-28 19:59:59','2019-07-28 23:59:59','CMTETH','4h','0.000203240000000','0.000198770000000','1.306241121486920','1.277512043485313','6427.086801254281','6427.086801254281454','test','test','2.2'),('2019-08-19 11:59:59','2019-08-20 19:59:59','CMTETH','4h','0.000170960000000','0.000164121600000','1.299856881931008','1.247862606653767','7603.280778726063','7603.280778726062636','test','test','4.0'),('2019-08-25 07:59:59','2019-08-25 15:59:59','CMTETH','4h','0.000166610000000','0.000163770000000','1.288302598536065','1.266342455808483','7732.444622388003','7732.444622388003154','test','test','1.7'),('2019-09-22 03:59:59','2019-09-22 07:59:59','CMTETH','4h','0.000113060000000','0.000112630000000','1.283422566818825','1.278541338234603','11351.694381910707','11351.694381910707307','test','test','0.4'),('2019-10-03 03:59:59','2019-10-03 15:59:59','CMTETH','4h','0.000106100000000','0.000103630000000','1.282337849355664','1.252485120911663','12086.124876113707','12086.124876113706705','test','test','2.8'),('2019-10-04 03:59:59','2019-10-05 15:59:59','CMTETH','4h','0.000105740000000','0.000103080000000','1.275703909701442','1.243612247134714','12064.534799521864','12064.534799521863533','test','test','2.5'),('2019-10-08 19:59:59','2019-10-09 03:59:59','CMTETH','4h','0.000104310000000','0.000102670000000','1.268572429131058','1.248627469071860','12161.561011706048','12161.561011706047793','test','test','1.6'),('2019-10-09 07:59:59','2019-10-09 15:59:59','CMTETH','4h','0.000104130000000','0.000099964800000','1.264140215784569','1.213574607153186','12140.019358346004','12140.019358346004083','test','test','4.0'),('2019-10-22 11:59:59','2019-10-23 03:59:59','CMTETH','4h','0.000095550000000','0.000096390000000','1.252903413866484','1.263917949373003','13112.542269664931','13112.542269664931155','test','test','0.0'),('2019-10-23 07:59:59','2019-10-23 15:59:59','CMTETH','4h','0.000097750000000','0.000094040000000','1.255351088423488','1.207705538162095','12842.466377733896','12842.466377733895570','test','test','3.8'),('2019-10-27 15:59:59','2019-11-04 19:59:59','CMTETH','4h','0.000099330000000','0.000106670000000','1.244763188365401','1.336745085099540','12531.593560509424','12531.593560509423696','test','test','3.7'),('2019-11-05 03:59:59','2019-11-05 15:59:59','CMTETH','4h','0.000117800000000','0.000113088000000','1.265203609861876','1.214595465467401','10740.268334990462','10740.268334990461881','test','test','4.0'),('2019-11-14 11:59:59','2019-11-14 15:59:59','CMTETH','4h','0.000106670000000','0.000111490000000','1.253957355551993','1.310618782886394','11755.482849460892','11755.482849460891885','test','test','0.0'),('2019-11-14 19:59:59','2019-11-16 19:59:59','CMTETH','4h','0.000111390000000','0.000107800000000','1.266548783848527','1.225729050173904','11370.399352262559','11370.399352262558750','test','test','3.2'),('2019-11-28 15:59:59','2019-11-28 19:59:59','CMTETH','4h','0.000102160000000','0.000099780000000','1.257477731920833','1.228182538087908','12308.904971817077','12308.904971817077239','test','test','2.3'),('2019-11-29 11:59:59','2019-11-29 15:59:59','CMTETH','4h','0.000100180000000','0.000098640000000','1.250967688846849','1.231737400956810','12487.199928597018','12487.199928597017788','test','test','1.5'),('2019-12-04 15:59:59','2019-12-04 19:59:59','CMTETH','4h','0.000098250000000','0.000096490000000','1.246694291537952','1.224361650793862','12689.000422778137','12689.000422778137363','test','test','1.8'),('2019-12-19 15:59:59','2019-12-19 19:59:59','CMTETH','4h','0.000091710000000','0.000089370000000','1.241731482483710','1.210048441713763','13539.761012798053','13539.761012798053343','test','test','2.6'),('2019-12-22 03:59:59','2019-12-22 07:59:59','CMTETH','4h','0.000092160000000','0.000090940000000','1.234690806757055','1.218346158490523','13397.252677485401','13397.252677485401364','test','test','1.3'),('2019-12-27 03:59:59','2019-12-27 11:59:59','CMTETH','4h','0.000094120000000','0.000090355200000','1.231058662697825','1.181816316189912','13079.67129938191','13079.671299381909193','test','test','4.0'),('2019-12-27 15:59:59','2019-12-27 19:59:59','CMTETH','4h','0.000091650000000','0.000089840000000','1.220115919029400','1.196019794496468','13312.775985045282','13312.775985045282141','test','test','2.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:39:35
