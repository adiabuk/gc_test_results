-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-10 07:59:59','MCOBTC','4h','0.000604000000000','0.000638000000000','0.033333333333333','0.035209713024282','55.187637969094915','55.187637969094915','test','test','1.7'),('2019-01-12 03:59:59','2019-01-12 11:59:59','MCOBTC','4h','0.000641000000000','0.000623000000000','0.033750306597989','0.032802560078857','52.65258439623817','52.652584396238169','test','test','2.8'),('2019-01-17 23:59:59','2019-01-18 07:59:59','MCOBTC','4h','0.000627000000000','0.000622000000000','0.033539696260404','0.033272234567737','53.49233853333936','53.492338533339357','test','test','0.8'),('2019-01-18 23:59:59','2019-01-19 11:59:59','MCOBTC','4h','0.000631000000000','0.000635000000000','0.033480260328700','0.033692496527297','53.059049649286834','53.059049649286834','test','test','1.1'),('2019-01-19 15:59:59','2019-01-20 11:59:59','MCOBTC','4h','0.000638000000000','0.000626000000000','0.033527423928388','0.032896814073936','52.55082120437025','52.550821204370251','test','test','1.9'),('2019-01-20 15:59:59','2019-01-20 19:59:59','MCOBTC','4h','0.000632000000000','0.000633000000000','0.033387288405177','0.033440116393160','52.82798798287447','52.827987982874468','test','test','0.0'),('2019-01-23 23:59:59','2019-01-24 03:59:59','MCOBTC','4h','0.000626000000000','0.000621000000000','0.033399027958062','0.033132262559036','53.353079805210506','53.353079805210506','test','test','0.8'),('2019-01-26 11:59:59','2019-01-26 19:59:59','MCOBTC','4h','0.000629000000000','0.000624000000000','0.033339746758278','0.033074724923951','53.00436686530719','53.004366865307190','test','test','0.8'),('2019-02-08 15:59:59','2019-02-08 19:59:59','MCOBTC','4h','0.000584000000000','0.000578000000000','0.033280853017317','0.032938926445221','56.9877620159532','56.987762015953201','test','test','1.0'),('2019-02-09 03:59:59','2019-02-10 07:59:59','MCOBTC','4h','0.000582000000000','0.000572000000000','0.033204869334629','0.032634338933690','57.05304009386368','57.053040093863679','test','test','1.7'),('2019-02-10 11:59:59','2019-02-10 19:59:59','MCOBTC','4h','0.000586000000000','0.000580000000000','0.033078084801087','0.032739401338960','56.447243687861196','56.447243687861196','test','test','1.0'),('2019-02-11 19:59:59','2019-02-12 11:59:59','MCOBTC','4h','0.000587000000000','0.000579000000000','0.033002821809503','0.032553038888760','56.2228650928499','56.222865092849901','test','test','1.4'),('2019-02-12 19:59:59','2019-02-13 03:59:59','MCOBTC','4h','0.000583000000000','0.000579000000000','0.032902870049338','0.032677121369754','56.43716989594815','56.437169895948152','test','test','0.7'),('2019-02-15 03:59:59','2019-02-24 07:59:59','MCOBTC','4h','0.000684000000000','0.000719000000000','0.032852703676097','0.034533763074728','48.03026853230539','48.030268532305392','test','test','2.9'),('2019-02-24 11:59:59','2019-02-24 15:59:59','MCOBTC','4h','0.000726000000000','0.000714000000000','0.033226272431348','0.032677077845706','45.766215470176604','45.766215470176604','test','test','1.7'),('2019-03-06 11:59:59','2019-03-06 15:59:59','MCOBTC','4h','0.000693000000000','0.000684000000000','0.033104229190094','0.032674304135677','47.769450490756775','47.769450490756775','test','test','1.3'),('2019-03-09 15:59:59','2019-03-21 15:59:59','MCOBTC','4h','0.000708000000000','0.000801000000000','0.033008690289113','0.037344577572852','46.6224439111764','46.622443911176397','test','test','0.8'),('2019-03-24 15:59:59','2019-03-24 19:59:59','MCOBTC','4h','0.000801000000000','0.000800000000000','0.033972220796610','0.033929808535940','42.41226066992565','42.412260669925651','test','test','0.1'),('2019-03-25 11:59:59','2019-03-25 15:59:59','MCOBTC','4h','0.000808000000000','0.000823000000000','0.033962795849795','0.034593293297502','42.03316318043921','42.033163180439210','test','test','0.0'),('2019-03-25 19:59:59','2019-03-25 23:59:59','MCOBTC','4h','0.000804000000000','0.000799000000000','0.034102906393730','0.033890823642525','42.41655024095743','42.416550240957427','test','test','0.6'),('2019-03-26 07:59:59','2019-03-26 15:59:59','MCOBTC','4h','0.000808000000000','0.000812000000000','0.034055776893462','0.034224369848380','42.148238729532174','42.148238729532174','test','test','0.0'),('2019-03-26 19:59:59','2019-03-30 19:59:59','MCOBTC','4h','0.000822000000000','0.000837000000000','0.034093241994555','0.034715381447010','41.475963497025404','41.475963497025404','test','test','0.0'),('2019-03-31 15:59:59','2019-04-02 03:59:59','MCOBTC','4h','0.000868000000000','0.000833280000000','0.034231495206212','0.032862235397964','39.437206458769076','39.437206458769076','test','test','4.0'),('2019-04-11 07:59:59','2019-04-11 11:59:59','MCOBTC','4h','0.000788000000000','0.000756480000000','0.033927215248823','0.032570126638870','43.05484168632374','43.054841686323741','test','test','4.0'),('2019-04-12 03:59:59','2019-04-12 07:59:59','MCOBTC','4h','0.000772000000000','0.000790000000000','0.033625640002167','0.034409657515171','43.55652850021617','43.556528500216167','test','test','0.0'),('2019-04-12 11:59:59','2019-04-13 23:59:59','MCOBTC','4h','0.000783000000000','0.000782000000000','0.033799866116168','0.033756698981920','43.167134247979284','43.167134247979284','test','test','0.1'),('2019-04-14 23:59:59','2019-04-15 23:59:59','MCOBTC','4h','0.000798000000000','0.000790000000000','0.033790273419668','0.033451523811451','42.34370102715316','42.343701027153159','test','test','1.4'),('2019-04-16 11:59:59','2019-04-23 19:59:59','MCOBTC','4h','0.000810000000000','0.000866000000000','0.033714995728953','0.036045909013918','41.623451517226336','41.623451517226336','test','test','1.1'),('2019-04-25 11:59:59','2019-04-25 23:59:59','MCOBTC','4h','0.000878000000000','0.000846000000000','0.034232976458946','0.032985305335158','38.98972261838902','38.989722618389017','test','test','3.6'),('2019-04-26 03:59:59','2019-04-26 07:59:59','MCOBTC','4h','0.000896000000000','0.000874000000000','0.033955716209215','0.033121982105864','37.89700469778447','37.897004697784467','test','test','2.5'),('2019-04-30 03:59:59','2019-05-01 19:59:59','MCOBTC','4h','0.000897000000000','0.000881000000000','0.033770441964026','0.033168070646942','37.64820731775448','37.648207317754483','test','test','1.8'),('2019-05-23 11:59:59','2019-05-23 15:59:59','MCOBTC','4h','0.000674000000000','0.000664000000000','0.033636581671340','0.033137522596098','49.90590752424398','49.905907524243979','test','test','1.5'),('2019-05-26 03:59:59','2019-05-26 19:59:59','MCOBTC','4h','0.000705000000000','0.000676800000000','0.033525679654620','0.032184652468435','47.55415553846807','47.554155538468073','test','test','4.0'),('2019-05-26 23:59:59','2019-05-27 03:59:59','MCOBTC','4h','0.000672000000000','0.000783000000000','0.033227673613246','0.038716173272577','49.44594287685349','49.445942876853493','test','test','0.0'),('2019-05-27 07:59:59','2019-06-03 23:59:59','MCOBTC','4h','0.000782000000000','0.000750720000000','0.034447340204208','0.033069446596040','44.050307166506386','44.050307166506386','test','test','4.0'),('2019-06-04 03:59:59','2019-06-05 23:59:59','MCOBTC','4h','0.000765000000000','0.000752000000000','0.034141141624615','0.033560965361713','44.62894330015046','44.628943300150461','test','test','1.7'),('2019-06-06 11:59:59','2019-06-06 15:59:59','MCOBTC','4h','0.000761000000000','0.000754000000000','0.034012213566192','0.033699354834309','44.694104554786385','44.694104554786385','test','test','0.9'),('2019-06-06 23:59:59','2019-06-07 03:59:59','MCOBTC','4h','0.000758000000000','0.000753000000000','0.033942689403552','0.033718793035455','44.77927361946144','44.779273619461442','test','test','0.7'),('2019-06-08 03:59:59','2019-06-09 19:59:59','MCOBTC','4h','0.000766000000000','0.000770000000000','0.033892934655086','0.034069921259029','44.24665098575166','44.246650985751657','test','test','0.7'),('2019-06-10 07:59:59','2019-06-14 07:59:59','MCOBTC','4h','0.000777000000000','0.000780000000000','0.033932265011518','0.034063277617740','43.67086874069182','43.670868740691823','test','test','1.0'),('2019-07-01 11:59:59','2019-07-02 15:59:59','MCOBTC','4h','0.000580000000000','0.000575000000000','0.033961378924011','0.033668608416045','58.55410159312299','58.554101593122986','test','test','0.9'),('2019-07-14 07:59:59','2019-07-14 11:59:59','MCOBTC','4h','0.000527000000000','0.000505920000000','0.033896318811130','0.032540466058685','64.3193905334535','64.319390533453500','test','test','4.0'),('2019-07-14 15:59:59','2019-07-14 19:59:59','MCOBTC','4h','0.000515000000000','0.000511000000000','0.033595018199476','0.033334086019286','65.23304504752532','65.233045047525323','test','test','0.8'),('2019-07-24 03:59:59','2019-07-24 11:59:59','MCOBTC','4h','0.000519000000000','0.000498240000000','0.033537033270544','0.032195551939722','64.61856121492184','64.618561214921840','test','test','4.0'),('2019-07-28 11:59:59','2019-07-28 15:59:59','MCOBTC','4h','0.000466000000000','0.000472000000000','0.033238926308140','0.033666895316399','71.32816804321791','71.328168043217914','test','test','0.0'),('2019-07-28 23:59:59','2019-07-29 03:59:59','MCOBTC','4h','0.000465000000000','0.000458000000000','0.033334030532197','0.032832227922035','71.68608716601527','71.686087166015270','test','test','1.5'),('2019-07-29 15:59:59','2019-07-29 19:59:59','MCOBTC','4h','0.000468000000000','0.000465000000000','0.033222518841050','0.033009553976684','70.98828812190169','70.988288121901689','test','test','0.6'),('2019-07-29 23:59:59','2019-07-30 07:59:59','MCOBTC','4h','0.000469000000000','0.000465000000000','0.033175193315635','0.032892249236184','70.73601986276189','70.736019862761893','test','test','0.9'),('2019-08-22 07:59:59','2019-08-22 11:59:59','MCOBTC','4h','0.000334000000000','0.000333000000000','0.033112316853535','0.033013178180321','99.13867321417698','99.138673214176976','test','test','0.3'),('2019-08-22 15:59:59','2019-08-25 15:59:59','MCOBTC','4h','0.000333000000000','0.000340000000000','0.033090286037265','0.033785877635646','99.37022834013611','99.370228340136109','test','test','0.0'),('2019-08-26 15:59:59','2019-08-27 07:59:59','MCOBTC','4h','0.000355000000000','0.000346000000000','0.033244861948017','0.032402034462011','93.64749844511735','93.647498445117350','test','test','3.7'),('2019-08-28 19:59:59','2019-08-29 07:59:59','MCOBTC','4h','0.000347000000000','0.000335000000000','0.033057566951126','0.031914365788551','95.26676354791482','95.266763547914820','test','test','3.5'),('2019-09-10 11:59:59','2019-09-10 15:59:59','MCOBTC','4h','0.000320000000000','0.000319000000000','0.032803522248332','0.032701011241306','102.51100702603748','102.511007026037475','test','test','0.3'),('2019-09-10 19:59:59','2019-09-11 03:59:59','MCOBTC','4h','0.000323000000000','0.000322000000000','0.032780742024548','0.032679253659147','101.48836540107875','101.488365401078752','test','test','1.2'),('2019-09-11 07:59:59','2019-09-11 11:59:59','MCOBTC','4h','0.000324000000000','0.000319000000000','0.032758189054459','0.032252661445594','101.1055217730226','101.105521773022602','test','test','1.5'),('2019-09-14 07:59:59','2019-09-15 03:59:59','MCOBTC','4h','0.000320000000000','0.000319000000000','0.032645849585823','0.032543831305867','102.0182799556958','102.018279955695803','test','test','0.3'),('2019-09-16 15:59:59','2019-09-19 07:59:59','MCOBTC','4h','0.000326000000000','0.000327800000000','0.032623178856944','0.032803306838363','100.07110078817038','100.071100788170384','test','test','1.2'),('2019-09-19 23:59:59','2019-09-23 03:59:59','MCOBTC','4h','0.000331700000000','0.000326100000000','0.032663207297259','0.032111763339271','98.47213535501626','98.472135355016263','test','test','1.7'),('2019-09-23 15:59:59','2019-09-24 19:59:59','MCOBTC','4h','0.000330600000000','0.000327200000000','0.032540664195484','0.032206005217067','98.42911129910397','98.429111299103965','test','test','1.0'),('2019-09-25 11:59:59','2019-10-26 03:59:59','MCOBTC','4h','0.000331500000000','0.000434400000000','0.032466295533613','0.042544068717350','97.93754308782303','97.937543087823030','test','test','0.0'),('2019-10-29 07:59:59','2019-11-04 23:59:59','MCOBTC','4h','0.000438500000000','0.000451800000000','0.034705800685555','0.035758450968606','79.14663782338627','79.146637823386271','test','test','0.0'),('2019-11-05 11:59:59','2019-11-29 23:59:59','MCOBTC','4h','0.000459900000000','0.000532400000000','0.034939722970677','0.040447724526176','75.97243524826555','75.972435248265555','test','test','0.0'),('2019-11-30 23:59:59','2019-12-01 03:59:59','MCOBTC','4h','0.000538700000000','0.000534200000000','0.036163723316344','0.035861631697774','67.13147079328714','67.131470793287136','test','test','0.8'),('2019-12-02 15:59:59','2019-12-03 03:59:59','MCOBTC','4h','0.000536700000000','0.000532900000000','0.036096591845550','0.035841016945209','67.25655272135353','67.256552721353529','test','test','0.7'),('2019-12-04 03:59:59','2019-12-16 15:59:59','MCOBTC','4h','0.000541000000000','0.000582600000000','0.036039797423252','0.038811064655798','66.61700078235201','66.617000782352008','test','test','0.5'),('2019-12-16 19:59:59','2019-12-17 07:59:59','MCOBTC','4h','0.000582300000000','0.000577800000000','0.036655634586040','0.036372360748435','62.94974168992004','62.949741689920039','test','test','0.8'),('2019-12-22 11:59:59','2019-12-22 15:59:59','MCOBTC','4h','0.000567600000000','0.000564700000000','0.036592684844350','0.036405724333341','64.46914172718542','64.469141727185416','test','test','0.5'),('2019-12-31 15:59:59','2020-01-01 15:59:59','MCOBTC','4h','0.000554300000000','0.000556200000000','0.036551138064126','0.036676426107283','65.9410753457085','65.941075345708498','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:19:30
