-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 11:59:59','2019-01-26 19:59:59','LINKETH','4h','0.002312050000000','0.004074820000000','1.297777777777778','2.287238963017428','561.3104291766085','561.310429176608523','test','test','0.0'),('2019-01-26 23:59:59','2019-01-27 03:59:59','LINKETH','4h','0.004049580000000','0.003904210000000','1.517658041164367','1.463177835947020','374.76924549320347','374.769245493203471','test','test','3.6'),('2019-01-29 07:59:59','2019-01-29 15:59:59','LINKETH','4h','0.004022410000000','0.004109550000000','1.505551328893845','1.538167035099779','374.29086763752207','374.290867637522069','test','test','0.0'),('2019-01-29 19:59:59','2019-01-30 15:59:59','LINKETH','4h','0.004291500000000','0.004119840000000','1.512799263606275','1.452287293062024','352.5106055240067','352.510605524006678','test','test','4.0'),('2019-02-05 19:59:59','2019-02-06 07:59:59','LINKETH','4h','0.003894150000000','0.003935530000000','1.499352159040886','1.515284568511788','385.0268117665949','385.026811766594903','test','test','0.0'),('2019-02-06 11:59:59','2019-02-06 15:59:59','LINKETH','4h','0.003969940000000','0.003840810000000','1.502892694478864','1.454008194048617','378.568112988827','378.568112988827011','test','test','3.3'),('2019-02-08 03:59:59','2019-02-08 11:59:59','LINKETH','4h','0.003946080000000','0.003885270000000','1.492029472161031','1.469036954978888','378.1042128291954','378.104212829195376','test','test','1.5'),('2019-02-09 15:59:59','2019-02-09 19:59:59','LINKETH','4h','0.004048190000000','0.003886262400000','1.486920023898333','1.427443222942400','367.3049001895496','367.304900189549585','test','test','4.0'),('2019-02-10 07:59:59','2019-02-10 19:59:59','LINKETH','4h','0.003979650000000','0.003836520000000','1.473702957019237','1.420700531117923','370.3096898016751','370.309689801675120','test','test','3.6'),('2019-02-25 15:59:59','2019-02-25 19:59:59','LINKETH','4h','0.003348290000000','0.003214830000000','1.461924640152278','1.403653563729769','436.6182857973108','436.618285797310818','test','test','4.0'),('2019-02-25 23:59:59','2019-02-26 07:59:59','LINKETH','4h','0.003429610000000','0.003292425600000','1.448975512058387','1.391016491576051','422.48987845801327','422.489878458013266','test','test','4.0'),('2019-03-03 15:59:59','2019-03-03 19:59:59','LINKETH','4h','0.003199200000000','0.003236060000000','1.436095729728979','1.452641893956852','448.8921385749497','448.892138574949684','test','test','0.0'),('2019-03-03 23:59:59','2019-03-04 07:59:59','LINKETH','4h','0.003220140000000','0.003198670000000','1.439772655112951','1.430173097669711','447.1149251625553','447.114925162555323','test','test','0.7'),('2019-03-04 11:59:59','2019-03-04 15:59:59','LINKETH','4h','0.003220300000000','0.003249100000000','1.437639420125564','1.450496612095137','446.430276721288','446.430276721288010','test','test','0.0'),('2019-03-04 19:59:59','2019-03-04 23:59:59','LINKETH','4h','0.003264070000000','0.003208290000000','1.440496573896580','1.415879792120469','441.319142633761','441.319142633760976','test','test','1.7'),('2019-03-05 07:59:59','2019-03-05 15:59:59','LINKETH','4h','0.003274870000000','0.003143875200000','1.435026177946334','1.377625130828481','438.1933261309101','438.193326130910123','test','test','4.0'),('2019-03-07 19:59:59','2019-03-16 03:59:59','LINKETH','4h','0.003401970000000','0.003471800000000','1.422270389697921','1.451464398261373','418.0725843255295','418.072584325529476','test','test','3.0'),('2019-03-25 19:59:59','2019-03-26 15:59:59','LINKETH','4h','0.003439950000000','0.003412920000000','1.428757947156466','1.417531235340411','415.3426495025993','415.342649502599272','test','test','0.8'),('2019-03-27 19:59:59','2019-03-30 03:59:59','LINKETH','4h','0.003515940000000','0.003450000000000','1.426263122308454','1.399514147557742','405.656274654418','405.656274654417984','test','test','1.9'),('2019-03-31 03:59:59','2019-04-02 23:59:59','LINKETH','4h','0.003501720000000','0.003570170000000','1.420318905697185','1.448082641545560','405.60607521366217','405.606075213662166','test','test','0.0'),('2019-04-13 19:59:59','2019-04-14 07:59:59','LINKETH','4h','0.003268570000000','0.003169790000000','1.426488624774602','1.383378473743651','436.42590636718865','436.425906367188645','test','test','3.0'),('2019-04-30 15:59:59','2019-04-30 19:59:59','LINKETH','4h','0.002925320000000','0.002952000000000','1.416908591212168','1.429831321448019','484.36020374255406','484.360203742554063','test','test','0.0'),('2019-05-01 07:59:59','2019-05-01 15:59:59','LINKETH','4h','0.002981150000000','0.002953940000000','1.419780309042357','1.406821476977871','476.2525565779505','476.252556577950486','test','test','0.9'),('2019-05-01 19:59:59','2019-05-02 11:59:59','LINKETH','4h','0.002954280000000','0.002928340000000','1.416900568583582','1.404459499778642','479.6094373531223','479.609437353122303','test','test','0.9'),('2019-05-03 07:59:59','2019-05-03 11:59:59','LINKETH','4h','0.002958000000000','0.002909380000000','1.414135886626929','1.390892043892716','478.0716317197191','478.071631719719107','test','test','1.6'),('2019-05-03 19:59:59','2019-05-12 07:59:59','LINKETH','4h','0.002985500000000','0.003419910000000','1.408970588241549','1.613985129604139','471.93789591075154','471.937895910751536','test','test','0.0'),('2019-05-14 15:59:59','2019-05-14 23:59:59','LINKETH','4h','0.004178870000000','0.004011715200000','1.454529375211013','1.396348200202572','348.0676295771376','348.067629577137609','test','test','4.0'),('2019-05-15 02:59:59','2019-05-15 15:59:59','LINKETH','4h','0.003575290000000','0.003432278400000','1.441600225209137','1.383936216200772','403.21211012509116','403.212110125091158','test','test','4.0'),('2019-05-15 19:59:59','2019-05-15 23:59:59','LINKETH','4h','0.003453090000000','0.003402300000000','1.428786000985056','1.407770608687134','413.77027560389564','413.770275603895641','test','test','1.5'),('2019-05-17 03:59:59','2019-05-25 15:59:59','LINKETH','4h','0.003537770000000','0.004581860000000','1.424115913807740','1.844410388702242','402.5462123902176','402.546212390217590','test','test','0.0'),('2019-05-27 07:59:59','2019-05-27 11:59:59','LINKETH','4h','0.004651490000000','0.004505950000000','1.517514686006518','1.470033322529140','326.242706317012','326.242706317011994','test','test','3.1'),('2019-05-27 23:59:59','2019-05-28 03:59:59','LINKETH','4h','0.004490750000000','0.004386690000000','1.506963271900434','1.472043804534413','335.5705109169814','335.570510916981391','test','test','2.3'),('2019-05-28 19:59:59','2019-05-29 03:59:59','LINKETH','4h','0.004887510000000','0.004692009600000','1.499203390263541','1.439235254652999','306.7417540349873','306.741754034987309','test','test','4.0'),('2019-06-05 07:59:59','2019-06-12 07:59:59','LINKETH','4h','0.004069090000000','0.004446760000000','1.485877137905643','1.623787879293232','365.1620234267717','365.162023426771725','test','test','0.0'),('2019-06-12 15:59:59','2019-06-12 19:59:59','LINKETH','4h','0.004525500000000','0.004441760000000','1.516523969325107','1.488462160200970','335.10639030496225','335.106390304962247','test','test','1.9'),('2019-06-13 19:59:59','2019-06-14 03:59:59','LINKETH','4h','0.006918550000000','0.006641808000000','1.510288011741965','1.449876491272286','218.29545377889372','218.295453778893716','test','test','4.0'),('2019-06-14 07:59:59','2019-06-21 03:59:59','LINKETH','4h','0.006090710000000','0.006006820000000','1.496863229415370','1.476246280600592','245.7616976371178','245.761697637117805','test','test','1.4'),('2019-06-25 03:59:59','2019-06-26 03:59:59','LINKETH','4h','0.006425000000000','0.006220000000000','1.492281685234308','1.444668028351346','232.2617408924993','232.261740892499290','test','test','3.2'),('2019-06-26 07:59:59','2019-06-26 15:59:59','LINKETH','4h','0.006490600000000','0.006230976000000','1.481700872593650','1.422432837689904','228.28411434900468','228.284114349004682','test','test','4.0'),('2019-06-26 19:59:59','2019-07-07 19:59:59','LINKETH','4h','0.006632350000000','0.010966680000000','1.468530198170595','2.428234449881792','221.4192854976886','221.419285497688605','test','test','0.0'),('2019-07-08 07:59:59','2019-07-08 11:59:59','LINKETH','4h','0.011201500000000','0.011000030000000','1.681797809661972','1.651549021132525','150.1404106291097','150.140410629109709','test','test','1.8'),('2019-07-10 19:59:59','2019-07-10 23:59:59','LINKETH','4h','0.011111730000000','0.010818280000000','1.675075856655429','1.630838729751199','150.74843041141466','150.748430411414660','test','test','2.6'),('2019-07-11 07:59:59','2019-07-11 11:59:59','LINKETH','4h','0.010840590000000','0.010594380000000','1.665245384010044','1.627424558206549','153.61206207503872','153.612062075038722','test','test','2.3'),('2019-07-12 19:59:59','2019-07-12 23:59:59','LINKETH','4h','0.012013940000000','0.011533382400000','1.656840756053712','1.590567125811563','137.9098577197582','137.909857719758207','test','test','4.0'),('2019-07-14 11:59:59','2019-07-16 19:59:59','LINKETH','4h','0.012193870000000','0.011706115200000','1.642113282666568','1.576428751359905','134.6671141045925','134.667114104592514','test','test','4.0'),('2019-07-17 15:59:59','2019-07-17 19:59:59','LINKETH','4h','0.011569380000000','0.011424460000000','1.627516720153976','1.607130171947874','140.67449769598505','140.674497695985053','test','test','1.3'),('2019-07-18 11:59:59','2019-07-18 19:59:59','LINKETH','4h','0.012472020000000','0.011973139200000','1.622986376108176','1.558066921063849','130.13019351381536','130.130193513815357','test','test','4.0'),('2019-07-24 07:59:59','2019-07-24 11:59:59','LINKETH','4h','0.011574670000000','0.011335640000000','1.608559830542769','1.575341254436959','138.97241394724594','138.972413947245940','test','test','2.1'),('2019-07-24 19:59:59','2019-07-24 23:59:59','LINKETH','4h','0.011424470000000','0.011109880000000','1.601177924741478','1.557087077345982','140.1533659540861','140.153365954086098','test','test','2.8'),('2019-08-02 19:59:59','2019-08-05 19:59:59','LINKETH','4h','0.010892850000000','0.010835450000000','1.591379958653590','1.582994163418485','146.09399364294836','146.093993642948362','test','test','0.5'),('2019-08-06 23:59:59','2019-08-07 03:59:59','LINKETH','4h','0.010970120000000','0.010749840000000','1.589516448601344','1.557598959704422','144.89508306211277','144.895083062112775','test','test','2.0'),('2019-08-10 07:59:59','2019-08-10 11:59:59','LINKETH','4h','0.011107090000000','0.011089990000000','1.582423673290918','1.579987441585469','142.46969037713006','142.469690377130064','test','test','0.2'),('2019-08-10 15:59:59','2019-08-20 15:59:59','LINKETH','4h','0.011200650000000','0.012089680000000','1.581882288467485','1.707441145401346','141.23129358273712','141.231293582737123','test','test','1.7'),('2019-08-20 19:59:59','2019-08-20 23:59:59','LINKETH','4h','0.012073800000000','0.012028110000000','1.609784256675009','1.603692467620405','133.32871645008277','133.328716450082766','test','test','0.4'),('2019-09-23 11:59:59','2019-09-23 15:59:59','LINKETH','4h','0.008806250000000','0.008836640000000','1.608430525773986','1.613981152167544','182.6464756024399','182.646475602439892','test','test','0.0'),('2019-09-23 23:59:59','2019-10-15 19:59:59','LINKETH','4h','0.008960940000000','0.013548630000000','1.609663998305888','2.433756049852706','179.63115457819023','179.631154578190234','test','test','0.0'),('2019-10-16 23:59:59','2019-10-17 03:59:59','LINKETH','4h','0.013595980000000','0.013620690000000','1.792795565316292','1.796053879790053','131.86218024123986','131.862180241239855','test','test','0.0'),('2019-10-17 11:59:59','2019-10-18 23:59:59','LINKETH','4h','0.013575230000000','0.013638600000000','1.793519635199350','1.801891894032724','132.11707169597494','132.117071695974943','test','test','0.2'),('2019-10-20 19:59:59','2019-10-26 03:59:59','LINKETH','4h','0.013871250000000','0.015358970000000','1.795380137162322','1.987938337588320','129.43174819589598','129.431748195895977','test','test','0.0'),('2019-10-26 11:59:59','2019-10-26 19:59:59','LINKETH','4h','0.015554070000000','0.015408160000000','1.838170848368099','1.820927290348533','118.17941210037627','118.179412100376268','test','test','1.9'),('2019-10-31 19:59:59','2019-11-01 11:59:59','LINKETH','4h','0.014931840000000','0.014721240000000','1.834338946585973','1.808467266863246','122.84748206423141','122.847482064231414','test','test','1.4'),('2019-11-08 23:59:59','2019-11-10 19:59:59','LINKETH','4h','0.014775770000000','0.014727770000000','1.828589684425367','1.822649398074644','123.75596564005579','123.755965640055791','test','test','0.7'),('2019-11-12 15:59:59','2019-11-17 19:59:59','LINKETH','4h','0.015029520000000','0.015580500000000','1.827269620791873','1.894257057227894','121.57870782246361','121.578707822463613','test','test','0.2'),('2019-11-17 23:59:59','2019-11-18 15:59:59','LINKETH','4h','0.015844380000000','0.015739180000000','1.842155717777656','1.829924580837604','116.26556026664694','116.265560266646943','test','test','0.7'),('2019-11-18 23:59:59','2019-11-19 03:59:59','LINKETH','4h','0.015673730000000','0.015412040000000','1.839437687346533','1.808726270957345','117.35800523210065','117.358005232100652','test','test','1.7'),('2019-11-20 07:59:59','2019-11-20 11:59:59','LINKETH','4h','0.015605560000000','0.015812590000000','1.832612928148936','1.856925151133224','117.43333325743745','117.433333257437454','test','test','0.0'),('2019-11-21 15:59:59','2019-11-22 07:59:59','LINKETH','4h','0.016019970000000','0.015479940000000','1.838015644367666','1.776056502844438','114.73277692577865','114.732776925778651','test','test','3.4'),('2019-11-22 15:59:59','2019-11-22 23:59:59','LINKETH','4h','0.015711740000000','0.015699910000000','1.824246946251393','1.822873397467226','116.10725140890784','116.107251408907842','test','test','0.1'),('2019-12-10 03:59:59','2019-12-12 07:59:59','LINKETH','4h','0.014754620000000','0.014520610000000','1.823941713188245','1.795013784152920','123.61834552080943','123.618345520809427','test','test','1.6'),('2019-12-12 11:59:59','2019-12-12 15:59:59','LINKETH','4h','0.014540170000000','0.014525060000000','1.817513284513729','1.815624542791383','124.99945217378674','124.999452173786736','test','test','0.1'),('2019-12-15 15:59:59','2019-12-15 23:59:59','LINKETH','4h','0.014574440000000','0.014580070000000','1.817093564130985','1.817795494137631','124.67673297437055','124.676732974370552','test','test','0.0'),('2019-12-16 11:59:59','2019-12-16 15:59:59','LINKETH','4h','0.014614260000000','0.014467430000000','1.817249548576907','1.798991576485433','124.34769523581123','124.347695235811230','test','test','1.0'),('2019-12-16 19:59:59','2019-12-17 07:59:59','LINKETH','4h','0.015055820000000','0.014453587200000','1.813192221445467','1.740664532587648','120.43131635775849','120.431316357758490','test','test','4.0'),('2019-12-18 03:59:59','2019-12-18 07:59:59','LINKETH','4h','0.014609280000000','0.014476310000000','1.797074957254841','1.780718432014297','123.00913920842376','123.009139208423761','test','test','0.9'),('2019-12-23 15:59:59','2019-12-23 19:59:59','LINKETH','4h','0.014554100000000','0.014749900000000','1.793440173868054','1.817567779562901','123.22576963660093','123.225769636600930','test','test','0.0'),('2019-12-24 03:59:59','2019-12-24 07:59:59','LINKETH','4h','0.014613800000000','0.014554850000000','1.798801864022464','1.791545751999299','123.089262479469','123.089262479468999','test','test','0.4'),('2019-12-25 11:59:59','2019-12-25 15:59:59','LINKETH','4h','0.014645470000000','0.014416920000000','1.797189394683983','1.769143341115540','122.71298870462898','122.712988704628984','test','test','1.6'),('2019-12-26 19:59:59','2019-12-28 19:59:59','LINKETH','4h','0.014805500000000','0.014665560000000','1.790956938335440','1.774029005205815','120.96565049038804','120.965650490388043','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:39:15
