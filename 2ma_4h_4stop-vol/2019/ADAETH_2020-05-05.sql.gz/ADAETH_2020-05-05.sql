-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 15:59:59','2019-01-14 19:59:59','ADAETH','4h','0.000308000000000','0.000339920000000','1.297777777777778','1.432274747474748','4213.564213564213','4213.564213564212878','test','test','0.0'),('2019-01-14 23:59:59','2019-01-27 07:59:59','ADAETH','4h','0.000341380000000','0.000360010000000','1.327665993265993','1.400120201053636','3889.1147497392735','3889.114749739273520','test','test','0.8'),('2019-01-27 15:59:59','2019-01-27 19:59:59','ADAETH','4h','0.000363000000000','0.000362290000000','1.343766928329914','1.341138623869544','3701.8372681264846','3701.837268126484560','test','test','0.2'),('2019-01-28 11:59:59','2019-01-28 15:59:59','ADAETH','4h','0.000364960000000','0.000365140000000','1.343182860672054','1.343845324818593','3680.3563696625765','3680.356369662576526','test','test','0.0'),('2019-01-28 19:59:59','2019-01-28 23:59:59','ADAETH','4h','0.000366700000000','0.000365480000000','1.343330074926840','1.338860855697468','3663.294450304991','3663.294450304991187','test','test','0.3'),('2019-01-29 19:59:59','2019-01-30 03:59:59','ADAETH','4h','0.000365170000000','0.000364590000000','1.342336915098091','1.340204879578314','3675.923309959994','3675.923309959994185','test','test','0.4'),('2019-03-03 15:59:59','2019-03-04 07:59:59','ADAETH','4h','0.000319330000000','0.000318480000000','1.341863129427029','1.338291327028216','4202.120469191837','4202.120469191837401','test','test','0.3'),('2019-03-04 11:59:59','2019-03-04 15:59:59','ADAETH','4h','0.000320580000000','0.000318970000000','1.341069395560627','1.334334347438933','4183.259702915425','4183.259702915424896','test','test','0.5'),('2019-03-05 03:59:59','2019-03-05 07:59:59','ADAETH','4h','0.000318400000000','0.000314890000000','1.339572718200250','1.324805443574361','4207.200748116364','4207.200748116363684','test','test','1.1'),('2019-03-05 11:59:59','2019-03-05 15:59:59','ADAETH','4h','0.000319660000000','0.000317350000000','1.336291101616719','1.326634490077162','4180.351315825313','4180.351315825312668','test','test','0.7'),('2019-03-08 23:59:59','2019-04-07 23:59:59','ADAETH','4h','0.000317500000000','0.000515610000000','1.334145187941262','2.166609764895729','4202.032088003975','4202.032088003975332','test','test','0.0'),('2019-04-10 23:59:59','2019-04-11 03:59:59','ADAETH','4h','0.000504110000000','0.000493860000000','1.519137316153366','1.488248903920774','3013.5036324480097','3013.503632448009739','test','test','2.0'),('2019-04-11 19:59:59','2019-04-11 23:59:59','ADAETH','4h','0.000507480000000','0.000505450000000','1.512273224546123','1.506223893250646','2979.9661554073527','2979.966155407352744','test','test','0.4'),('2019-04-13 11:59:59','2019-04-14 07:59:59','ADAETH','4h','0.000510560000000','0.000504530000000','1.510928928702684','1.493084010495074','2959.3562533349345','2959.356253334934536','test','test','1.2'),('2019-04-15 19:59:59','2019-04-16 07:59:59','ADAETH','4h','0.000511810000000','0.000503420000000','1.506963391323215','1.482260038803331','2944.38051488485','2944.380514884850072','test','test','1.6'),('2019-05-14 23:59:59','2019-05-15 02:59:59','ADAETH','4h','0.000390490000000','0.000384110000000','1.501473757429908','1.476942008672186','3845.1016861633016','3845.101686163301565','test','test','1.6'),('2019-05-28 19:59:59','2019-05-29 03:59:59','ADAETH','4h','0.000336780000000','0.000334780000000','1.496022257705969','1.487137987513523','4442.135096222963','4442.135096222962602','test','test','0.6'),('2019-05-29 15:59:59','2019-05-29 19:59:59','ADAETH','4h','0.000338610000000','0.000343520000000','1.494047975440981','1.515712354990951','4412.29726068628','4412.297260686280424','test','test','0.0'),('2019-05-30 07:59:59','2019-05-30 11:59:59','ADAETH','4h','0.000335800000000','0.000337820000000','1.498862282007641','1.507878666193631','4463.556527717813','4463.556527717812969','test','test','0.0'),('2019-06-01 23:59:59','2019-06-04 07:59:59','ADAETH','4h','0.000342000000000','0.000344290000000','1.500865922937861','1.510915580725954','4388.496850695501','4388.496850695501053','test','test','0.0'),('2019-06-07 11:59:59','2019-06-07 23:59:59','ADAETH','4h','0.000340650000000','0.000341740000000','1.503099180224104','1.507908744605270','4412.44438639103','4412.444386391030093','test','test','0.0'),('2019-06-08 07:59:59','2019-06-08 15:59:59','ADAETH','4h','0.000340550000000','0.000340040000000','1.504167972308808','1.501915364275105','4416.87849745649','4416.878497456489640','test','test','0.1'),('2019-06-09 19:59:59','2019-06-09 23:59:59','ADAETH','4h','0.000341420000000','0.000341420000000','1.503667392745763','1.503667392745763','4404.157321614911','4404.157321614910870','test','test','0.0'),('2019-06-10 07:59:59','2019-06-10 11:59:59','ADAETH','4h','0.000345530000000','0.000342800000000','1.503667392745763','1.491787058238786','4351.770881676737','4351.770881676737190','test','test','0.8'),('2019-06-10 15:59:59','2019-06-11 07:59:59','ADAETH','4h','0.000343010000000','0.000340010000000','1.501027318410879','1.487899182335451','4376.045358476076','4376.045358476076217','test','test','0.9'),('2019-06-11 11:59:59','2019-06-13 19:59:59','ADAETH','4h','0.000345430000000','0.000348810000000','1.498109954838562','1.512768819579188','4336.9422309543515','4336.942230954351544','test','test','0.0'),('2019-06-13 23:59:59','2019-06-14 11:59:59','ADAETH','4h','0.000351580000000','0.000347030000000','1.501367480336478','1.481937415954172','4270.343820286929','4270.343820286929258','test','test','1.3'),('2019-07-14 23:59:59','2019-07-15 03:59:59','ADAETH','4h','0.000261070000000','0.000261540000000','1.497049688251522','1.499744802027437','5734.284629607086','5734.284629607085662','test','test','0.0'),('2019-07-16 15:59:59','2019-07-16 19:59:59','ADAETH','4h','0.000261410000000','0.000259470000000','1.497648602423947','1.486534114498074','5729.117487563395','5729.117487563395116','test','test','0.7'),('2019-07-17 11:59:59','2019-07-17 15:59:59','ADAETH','4h','0.000260840000000','0.000264460000000','1.495178716218198','1.515929164587735','5732.1680578829855','5732.168057882985522','test','test','0.0'),('2019-07-18 15:59:59','2019-07-18 19:59:59','ADAETH','4h','0.000260690000000','0.000258660000000','1.499789926966984','1.488111022706203','5753.154808266461','5753.154808266461259','test','test','0.8'),('2019-07-20 19:59:59','2019-07-23 07:59:59','ADAETH','4h','0.000279990000000','0.000268790400000','1.497194614909032','1.437306830312671','5347.3146001965515','5347.314600196551510','test','test','4.0'),('2019-07-24 15:59:59','2019-07-24 23:59:59','ADAETH','4h','0.000272020000000','0.000272230000000','1.483886218332063','1.485031781547451','5455.062930417114','5455.062930417114330','test','test','1.5'),('2019-07-25 03:59:59','2019-07-25 07:59:59','ADAETH','4h','0.000268730000000','0.000266100000000','1.484140787935483','1.469615836228304','5522.795325923726','5522.795325923725613','test','test','1.0'),('2019-07-25 15:59:59','2019-07-25 23:59:59','ADAETH','4h','0.000267090000000','0.000267300000000','1.480913020889443','1.482077391455120','5544.621741321065','5544.621741321065201','test','test','0.0'),('2019-07-26 07:59:59','2019-07-31 15:59:59','ADAETH','4h','0.000273540000000','0.000276670000000','1.481171769904038','1.498120178326205','5414.82697193843','5414.826971938429779','test','test','0.0'),('2019-08-11 11:59:59','2019-08-11 15:59:59','ADAETH','4h','0.000249970000000','0.000251430000000','1.484938082886742','1.493611162060301','5940.46518736945','5940.465187369450177','test','test','0.0'),('2019-08-11 19:59:59','2019-08-12 03:59:59','ADAETH','4h','0.000256730000000','0.000248780000000','1.486865433814199','1.440822586469428','5791.553125128343','5791.553125128342799','test','test','3.1'),('2019-08-13 23:59:59','2019-08-14 03:59:59','ADAETH','4h','0.000251540000000','0.000254700000000','1.476633689959806','1.495184069463157','5870.373260554208','5870.373260554208173','test','test','0.0'),('2019-08-14 15:59:59','2019-08-16 03:59:59','ADAETH','4h','0.000253500000000','0.000245360000000','1.480755996516106','1.433208249724622','5841.246534580299','5841.246534580299340','test','test','3.2'),('2019-08-17 19:59:59','2019-08-19 07:59:59','ADAETH','4h','0.000258550000000','0.000252290000000','1.470189830562443','1.434593666032097','5686.288263633505','5686.288263633505267','test','test','2.4'),('2019-08-21 07:59:59','2019-08-21 11:59:59','ADAETH','4h','0.000252390000000','0.000249720000000','1.462279571777921','1.446810312074101','5793.730226149694','5793.730226149694317','test','test','1.1'),('2019-08-21 15:59:59','2019-08-22 03:59:59','ADAETH','4h','0.000253760000000','0.000257100000000','1.458841958510406','1.478043298916399','5748.904313171523','5748.904313171523427','test','test','0.6'),('2019-08-22 15:59:59','2019-08-23 15:59:59','ADAETH','4h','0.000260890000000','0.000254460000000','1.463108923045071','1.427048551335999','5608.144900322246','5608.144900322246031','test','test','2.5'),('2019-08-23 19:59:59','2019-08-26 15:59:59','ADAETH','4h','0.000255420000000','0.000264590000000','1.455095507109722','1.507335839895706','5696.8738043603535','5696.873804360353461','test','test','0.0'),('2019-08-27 15:59:59','2019-08-28 19:59:59','ADAETH','4h','0.000260180000000','0.000267440000000','1.466704469951051','1.507631037911096','5637.268314055852','5637.268314055851988','test','test','0.1'),('2019-08-29 03:59:59','2019-08-29 07:59:59','ADAETH','4h','0.000260630000000','0.000260770000000','1.475799262831061','1.476592003101930','5662.430506200597','5662.430506200596938','test','test','0.0'),('2019-08-29 15:59:59','2019-08-31 23:59:59','ADAETH','4h','0.000262730000000','0.000260950000000','1.475975427335699','1.465975669939674','5617.841233721689','5617.841233721688695','test','test','0.7'),('2019-09-06 23:59:59','2019-09-07 03:59:59','ADAETH','4h','0.000262030000000','0.000259080000000','1.473753259025471','1.457161372164710','5624.368427376527','5624.368427376526597','test','test','1.1'),('2019-09-08 15:59:59','2019-09-08 23:59:59','ADAETH','4h','0.000260280000000','0.000256690000000','1.470066173056413','1.449789787774130','5648.018184479842','5648.018184479841693','test','test','1.4'),('2019-09-10 03:59:59','2019-09-10 15:59:59','ADAETH','4h','0.000259610000000','0.000261780000000','1.465560309660350','1.477810476726191','5645.238279189362','5645.238279189362402','test','test','0.0'),('2019-09-18 15:59:59','2019-09-18 19:59:59','ADAETH','4h','0.000259050000000','0.000250860000000','1.468282569008315','1.421862054666767','5667.950469053522','5667.950469053522284','test','test','3.2'),('2019-10-05 11:59:59','2019-10-05 15:59:59','ADAETH','4h','0.000225520000000','0.000224750000000','1.457966899154638','1.452988917102717','6464.911755740678','6464.911755740678018','test','test','0.3'),('2019-10-05 19:59:59','2019-10-05 23:59:59','ADAETH','4h','0.000226590000000','0.000224800000000','1.456860680920878','1.445351873741177','6429.5012177098615','6429.501217709861521','test','test','0.8'),('2019-10-06 11:59:59','2019-10-06 19:59:59','ADAETH','4h','0.000226500000000','0.000227720000000','1.454303168214277','1.462136500952562','6420.764539577383','6420.764539577383403','test','test','0.0'),('2019-10-07 03:59:59','2019-10-08 07:59:59','ADAETH','4h','0.000226260000000','0.000226540000000','1.456043908822785','1.457845784074577','6435.268756398767','6435.268756398767437','test','test','0.0'),('2019-10-09 11:59:59','2019-10-09 15:59:59','ADAETH','4h','0.000234280000000','0.000224908800000','1.456444325545405','1.398186552523589','6216.68228421293','6216.682284212930426','test','test','4.0'),('2019-10-13 15:59:59','2019-10-14 19:59:59','ADAETH','4h','0.000225260000000','0.000223940000000','1.443498153762780','1.435039405813890','6408.142385522417','6408.142385522416589','test','test','0.6'),('2019-10-19 15:59:59','2019-10-20 11:59:59','ADAETH','4h','0.000225570000000','0.000224020000000','1.441618431996360','1.431712378134613','6391.002491449925','6391.002491449925401','test','test','0.7'),('2019-10-20 15:59:59','2019-10-20 19:59:59','ADAETH','4h','0.000225560000000','0.000223460000000','1.439417086693749','1.426015881329071','6381.526364132601','6381.526364132600975','test','test','0.9'),('2019-10-21 15:59:59','2019-10-23 23:59:59','ADAETH','4h','0.000223720000000','0.000224240000000','1.436439041057154','1.439777805143287','6420.700165640775','6420.700165640774685','test','test','0.0'),('2019-10-24 03:59:59','2019-10-24 07:59:59','ADAETH','4h','0.000225920000000','0.000228340000000','1.437180988631851','1.452575721247330','6361.459758462511','6361.459758462510763','test','test','0.0'),('2019-10-24 11:59:59','2019-10-25 19:59:59','ADAETH','4h','0.000231510000000','0.000228630000000','1.440602040324179','1.422680853869453','6222.634185668779','6222.634185668778628','test','test','1.5'),('2019-10-27 15:59:59','2019-10-29 19:59:59','ADAETH','4h','0.000231690000000','0.000226390000000','1.436619554445351','1.403756316331663','6200.610964846784','6200.610964846783645','test','test','2.3'),('2019-10-30 03:59:59','2019-10-30 11:59:59','ADAETH','4h','0.000228710000000','0.000226930000000','1.429316612642309','1.418192553482223','6249.4714382506645','6249.471438250664505','test','test','0.8'),('2019-11-01 03:59:59','2019-11-01 23:59:59','ADAETH','4h','0.000232290000000','0.000230710000000','1.426844599495624','1.417139427223020','6142.514096584544','6142.514096584543950','test','test','0.9'),('2019-11-04 11:59:59','2019-11-04 15:59:59','ADAETH','4h','0.000229630000000','0.000230010000000','1.424687894546156','1.427045519420639','6204.2759854816695','6204.275985481669522','test','test','0.0'),('2019-11-04 19:59:59','2019-11-04 23:59:59','ADAETH','4h','0.000229270000000','0.000232600000000','1.425211811184930','1.445912100499911','6216.303097592054','6216.303097592053746','test','test','0.0'),('2019-11-05 03:59:59','2019-11-06 07:59:59','ADAETH','4h','0.000239390000000','0.000232270000000','1.429811875477148','1.387286036664343','5972.730170337724','5972.730170337724303','test','test','3.5'),('2019-11-06 11:59:59','2019-11-07 07:59:59','ADAETH','4h','0.000236880000000','0.000230870000000','1.420361689074302','1.384324987996387','5996.123307473415','5996.123307473414570','test','test','2.5'),('2019-11-10 23:59:59','2019-11-11 03:59:59','ADAETH','4h','0.000231930000000','0.000230440000000','1.412353533279210','1.403280076785501','6089.568116583496','6089.568116583495794','test','test','0.6'),('2019-11-11 15:59:59','2019-11-13 11:59:59','ADAETH','4h','0.000232500000000','0.000232430000000','1.410337209613941','1.409912591959434','6065.966492963189','6065.966492963189012','test','test','0.0'),('2019-11-13 19:59:59','2019-11-13 23:59:59','ADAETH','4h','0.000231760000000','0.000230130000000','1.410242850135162','1.400324417939268','6084.927727542123','6084.927727542122739','test','test','0.7'),('2019-11-15 11:59:59','2019-11-19 11:59:59','ADAETH','4h','0.000236520000000','0.000236920000000','1.408038754091630','1.410420013611487','5953.148799643287','5953.148799643287020','test','test','0.4'),('2019-11-19 19:59:59','2019-11-20 07:59:59','ADAETH','4h','0.000240930000000','0.000236740000000','1.408567922873821','1.384071597813259','5846.378296076954','5846.378296076954030','test','test','1.7'),('2019-11-21 19:59:59','2019-11-22 03:59:59','ADAETH','4h','0.000239990000000','0.000235500000000','1.403124295082584','1.376873084261630','5846.5948376290025','5846.594837629002541','test','test','1.9'),('2019-11-22 07:59:59','2019-11-22 11:59:59','ADAETH','4h','0.000239680000000','0.000240510000000','1.397290692677928','1.402129441321631','5829.817643015388','5829.817643015388057','test','test','0.0'),('2019-11-22 15:59:59','2019-12-02 07:59:59','ADAETH','4h','0.000245800000000','0.000255180000000','1.398365970154307','1.451729162994207','5689.039748390181','5689.039748390180648','test','test','0.1'),('2019-12-03 11:59:59','2019-12-04 03:59:59','ADAETH','4h','0.000257070000000','0.000253360000000','1.410224457452062','1.389872285914554','5485.760522239321','5485.760522239321290','test','test','1.4'),('2019-12-04 23:59:59','2019-12-05 03:59:59','ADAETH','4h','0.000255070000000','0.000254800000000','1.405701752665949','1.404213771040435','5511.043057458539','5511.043057458538897','test','test','0.1'),('2019-12-06 19:59:59','2019-12-06 23:59:59','ADAETH','4h','0.000254850000000','0.000257390000000','1.405371090082502','1.419377927707809','5514.503002089472','5514.503002089471920','test','test','0.0'),('2019-12-07 03:59:59','2019-12-08 19:59:59','ADAETH','4h','0.000259160000000','0.000256410000000','1.408483720665903','1.393538010556969','5434.803675975858','5434.803675975857914','test','test','1.1'),('2019-12-12 03:59:59','2019-12-12 07:59:59','ADAETH','4h','0.000254800000000','0.000256180000000','1.405162451752807','1.412772829238752','5514.766294163292','5514.766294163291604','test','test','0.0'),('2019-12-13 11:59:59','2019-12-14 11:59:59','ADAETH','4h','0.000257010000000','0.000254320000000','1.406853646749683','1.392128786589547','5473.925710087869','5473.925710087869447','test','test','1.0'),('2019-12-14 19:59:59','2019-12-14 23:59:59','ADAETH','4h','0.000255280000000','0.000255440000000','1.403581455602987','1.404461168204431','5498.203759021415','5498.203759021414953','test','test','0.0'),('2019-12-16 03:59:59','2019-12-16 07:59:59','ADAETH','4h','0.000255300000000','0.000255030000000','1.403776947292196','1.402292341825024','5498.538767301983','5498.538767301983171','test','test','0.1'),('2019-12-16 11:59:59','2019-12-16 15:59:59','ADAETH','4h','0.000255000000000','0.000254950000000','1.403447034966158','1.403171849273027','5503.713862612384','5503.713862612384219','test','test','0.0'),('2019-12-16 19:59:59','2019-12-17 07:59:59','ADAETH','4h','0.000256510000000','0.000256000000000','1.403385882589907','1.400595633476341','5471.076693266956','5471.076693266955772','test','test','0.5'),('2019-12-17 11:59:59','2019-12-17 15:59:59','ADAETH','4h','0.000256290000000','0.000257320000000','1.402765827231337','1.408403381572311','5473.353729101161','5473.353729101160752','test','test','0.0'),('2019-12-17 23:59:59','2019-12-18 15:59:59','ADAETH','4h','0.000259740000000','0.000257510000000','1.404018617084886','1.391964403193690','5405.477081253894','5405.477081253893630','test','test','0.9'),('2019-12-18 23:59:59','2019-12-19 23:59:59','ADAETH','4h','0.000258720000000','0.000257990000000','1.401339902886843','1.397385905789180','5416.434380360401','5416.434380360400610','test','test','0.3'),('2019-12-22 19:59:59','2019-12-22 23:59:59','ADAETH','4h','0.000258510000000','0.000260010000000','1.400461236865140','1.408587390032513','5417.435444915632','5417.435444915631706','test','test','0.0'),('2019-12-23 19:59:59','2019-12-23 23:59:59','ADAETH','4h','0.000259170000000','0.000258460000000','1.402267048680112','1.398425517621105','5410.607125362163','5410.607125362163060','test','test','0.3'),('2019-12-24 11:59:59','2019-12-27 11:59:59','ADAETH','4h','0.000263370000000','0.000260010000000','1.401413375111443','1.383534539479540','5321.08203330464','5321.082033304640390','test','test','1.3'),('2019-12-28 07:59:59','2019-12-28 11:59:59','ADAETH','4h','0.000262520000000','0.000262440000000','1.397440300526576','1.397014446404825','5323.17652189005','5323.176521890050026','test','test','0.0'),('2019-12-28 15:59:59','2019-12-28 19:59:59','ADAETH','4h','0.000265720000000','0.000261990000000','1.397345666277298','1.377730660499734','5258.71468567401','5258.714685674010070','test','test','1.4');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:21:51
