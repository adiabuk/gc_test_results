-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-08 03:59:59','ETHBTC','4h','0.036629000000000','0.037143000000000','0.033333333333333','0.033801086570750','0.9100257537288304','0.910025753728830','test','test','0.0'),('2019-01-08 11:59:59','2019-01-08 15:59:59','ETHBTC','4h','0.037406000000000','0.037186000000000','0.033437278497204','0.033240620173155','0.8939014729509643','0.893901472950964','test','test','0.6'),('2019-01-09 03:59:59','2019-01-09 23:59:59','ETHBTC','4h','0.037759000000000','0.037337000000000','0.033393576647415','0.033020365244962','0.8843872096034087','0.884387209603409','test','test','1.1'),('2019-02-08 11:59:59','2019-02-24 19:59:59','ETHBTC','4h','0.031576000000000','0.036752000000000','0.033310640780203','0.038770986507285','1.0549354186788487','1.054935418678849','test','test','0.0'),('2019-02-25 03:59:59','2019-02-25 07:59:59','ETHBTC','4h','0.036534000000000','0.036269000000000','0.034524050941777','0.034273630141986','0.9449841501553925','0.944984150155392','test','test','0.7'),('2019-03-05 19:59:59','2019-03-05 23:59:59','ETHBTC','4h','0.035449000000000','0.035450000000000','0.034468401875157','0.034469374212935','0.97233777751578','0.972337777515780','test','test','0.0'),('2019-03-06 03:59:59','2019-03-06 07:59:59','ETHBTC','4h','0.035308000000000','0.035618000000000','0.034468617950219','0.034771248276620','0.9762268593581814','0.976226859358181','test','test','0.0'),('2019-03-06 11:59:59','2019-03-07 11:59:59','ETHBTC','4h','0.035893000000000','0.035317000000000','0.034535869133863','0.033981647959230','0.9621895392935482','0.962189539293548','test','test','1.6'),('2019-03-15 15:59:59','2019-03-15 23:59:59','ETHBTC','4h','0.034832000000000','0.034804000000000','0.034412708872834','0.034385045923579','0.9879624733817689','0.987962473381769','test','test','0.1'),('2019-03-16 03:59:59','2019-03-17 03:59:59','ETHBTC','4h','0.035075000000000','0.034702000000000','0.034406561550777','0.034040669962511','0.9809425958881571','0.980942595888157','test','test','1.1'),('2019-03-17 07:59:59','2019-03-18 07:59:59','ETHBTC','4h','0.034891000000000','0.034651000000000','0.034325252308940','0.034089143841021','0.9837852829939017','0.983785282993902','test','test','0.7'),('2019-03-27 11:59:59','2019-03-27 15:59:59','ETHBTC','4h','0.034359000000000','0.034336000000000','0.034272783760514','0.034249841473879','0.9974907232606819','0.997490723260682','test','test','0.1'),('2019-03-30 03:59:59','2019-03-31 07:59:59','ETHBTC','4h','0.034965000000000','0.034388000000000','0.034267685474595','0.033702192709863','0.9800567846301984','0.980056784630198','test','test','1.7'),('2019-04-07 23:59:59','2019-04-10 19:59:59','ETHBTC','4h','0.033702000000000','0.033582000000000','0.034142020415766','0.034020453670472','1.0130562107817205','1.013056210781720','test','test','0.4'),('2019-04-18 19:59:59','2019-04-18 23:59:59','ETHBTC','4h','0.033074000000000','0.032962000000000','0.034115005583478','0.033999480378624','1.0314750433415372','1.031475043341537','test','test','0.3'),('2019-04-19 03:59:59','2019-04-19 15:59:59','ETHBTC','4h','0.032825000000000','0.032692000000000','0.034089333315733','0.033951210502908','1.0385173896643616','1.038517389664362','test','test','0.4'),('2019-05-06 19:59:59','2019-05-07 15:59:59','ETHBTC','4h','0.030215000000000','0.029302000000000','0.034058639357327','0.033029496953447','1.1272096428041407','1.127209642804141','test','test','3.0'),('2019-05-15 15:59:59','2019-05-23 07:59:59','ETHBTC','4h','0.029813000000000','0.030991000000000','0.033829941045354','0.035166662292844','1.1347379010952863','1.134737901095286','test','test','0.7'),('2019-05-23 11:59:59','2019-05-23 19:59:59','ETHBTC','4h','0.031100000000000','0.031077000000000','0.034126990211463','0.034101751601339','1.0973308749666453','1.097330874966645','test','test','0.1'),('2019-05-24 11:59:59','2019-05-26 03:59:59','ETHBTC','4h','0.031482000000000','0.031070000000000','0.034121381631435','0.033674840457680','1.0838378003759326','1.083837800375933','test','test','1.3'),('2019-05-28 15:59:59','2019-05-29 03:59:59','ETHBTC','4h','0.031169000000000','0.031048000000000','0.034022150259490','0.033890074152416','1.0915380749940502','1.091538074994050','test','test','0.4'),('2019-05-29 07:59:59','2019-05-29 11:59:59','ETHBTC','4h','0.031023000000000','0.031040000000000','0.033992800013473','0.034011427406060','1.095728975710702','1.095728975710702','test','test','0.0'),('2019-05-29 15:59:59','2019-05-30 03:59:59','ETHBTC','4h','0.031298000000000','0.032502000000000','0.033996939434048','0.035304764696959','1.086233607069078','1.086233607069078','test','test','0.6'),('2019-05-30 07:59:59','2019-05-30 19:59:59','ETHBTC','4h','0.032545000000000','0.031243200000000','0.034287567270250','0.032916064579440','1.0535433175679965','1.053543317567996','test','test','4.0'),('2019-06-01 03:59:59','2019-06-01 15:59:59','ETHBTC','4h','0.031525000000000','0.031134000000000','0.033982788894515','0.033561305295538','1.0779631687395683','1.077963168739568','test','test','1.2'),('2019-06-04 15:59:59','2019-06-04 19:59:59','ETHBTC','4h','0.031330000000000','0.031103000000000','0.033889125872520','0.033643583849760','1.0816829196463456','1.081682919646346','test','test','0.7'),('2019-06-05 11:59:59','2019-06-07 07:59:59','ETHBTC','4h','0.031474000000000','0.031223000000000','0.033834560978573','0.033564735891021','1.0750003488140476','1.075000348814048','test','test','0.8'),('2019-06-07 19:59:59','2019-06-07 23:59:59','ETHBTC','4h','0.031224000000000','0.031196000000000','0.033774599848006','0.033744312607558','1.0816871588523644','1.081687158852364','test','test','0.1'),('2019-06-12 11:59:59','2019-06-12 15:59:59','ETHBTC','4h','0.031110000000000','0.031134000000000','0.033767869350129','0.033793919779714','1.0854345660600737','1.085434566060074','test','test','0.0'),('2019-06-12 19:59:59','2019-06-13 23:59:59','ETHBTC','4h','0.031514000000000','0.030996000000000','0.033773658334481','0.033218516016233','1.071703317080698','1.071703317080698','test','test','1.6'),('2019-07-01 19:59:59','2019-07-02 15:59:59','ETHBTC','4h','0.027624000000000','0.027285000000000','0.033650293374870','0.033237339079544','1.2181542634980613','1.218154263498061','test','test','1.2'),('2019-07-07 19:59:59','2019-07-08 11:59:59','ETHBTC','4h','0.026690000000000','0.025777000000000','0.033558525753687','0.032410570189314','1.2573445392913782','1.257344539291378','test','test','3.4'),('2019-07-25 03:59:59','2019-07-26 03:59:59','ETHBTC','4h','0.021985000000000','0.022153000000000','0.033303424517160','0.033557915093411','1.514824858638142','1.514824858638142','test','test','0.0'),('2019-07-28 23:59:59','2019-07-29 11:59:59','ETHBTC','4h','0.022165000000000','0.022031000000000','0.033359977978549','0.033158297985356','1.505074576068065','1.505074576068065','test','test','0.6'),('2019-08-14 03:59:59','2019-08-14 19:59:59','ETHBTC','4h','0.019593000000000','0.018809280000000','0.033315160202284','0.031982553794193','1.7003603430961851','1.700360343096185','test','test','4.0'),('2019-08-19 07:59:59','2019-08-19 11:59:59','ETHBTC','4h','0.018760000000000','0.018740000000000','0.033019025444930','0.032983823925266','1.7600759832052237','1.760075983205224','test','test','0.1'),('2019-08-22 15:59:59','2019-08-23 15:59:59','ETHBTC','4h','0.018903000000000','0.018712000000000','0.033011202885005','0.032677650551987','1.7463472932870265','1.746347293287027','test','test','1.0'),('2019-08-24 11:59:59','2019-08-25 11:59:59','ETHBTC','4h','0.018882000000000','0.018722000000000','0.032937080144334','0.032657981911991','1.7443639521414045','1.744363952141404','test','test','0.8'),('2019-09-08 03:59:59','2019-09-08 07:59:59','ETHBTC','4h','0.017357000000000','0.017220000000000','0.032875058314924','0.032615573208676','1.8940518704225642','1.894051870422564','test','test','0.8'),('2019-09-08 11:59:59','2019-09-09 07:59:59','ETHBTC','4h','0.017322000000000','0.017463000000000','0.032817394957980','0.033084526506824','1.894549991801203','1.894549991801203','test','test','0.1'),('2019-09-09 11:59:59','2019-09-12 15:59:59','ETHBTC','4h','0.017554000000000','0.017409000000000','0.032876757524390','0.032605188090584','1.8728926469403109','1.872892646940311','test','test','0.8'),('2019-09-12 19:59:59','2019-09-12 23:59:59','ETHBTC','4h','0.017409000000000','0.017352000000000','0.032816408761322','0.032708962308373','1.8850254903396073','1.885025490339607','test','test','0.3'),('2019-09-13 19:59:59','2019-09-14 11:59:59','ETHBTC','4h','0.017485000000000','0.017520000000000','0.032792531771778','0.032858173099317','1.875466501102545','1.875466501102545','test','test','0.0'),('2019-09-14 15:59:59','2019-09-24 11:59:59','ETHBTC','4h','0.017868000000000','0.020317000000000','0.032807118733453','0.037303684313161','1.8360823110282818','1.836082311028282','test','test','0.0'),('2019-09-24 15:59:59','2019-09-24 19:59:59','ETHBTC','4h','0.020214000000000','0.019729000000000','0.033806355528944','0.032995230445757','1.6724228519315325','1.672422851931533','test','test','2.4'),('2019-09-25 19:59:59','2019-09-25 23:59:59','ETHBTC','4h','0.020207000000000','0.020163000000000','0.033626105510458','0.033552885901290','1.6640820265481266','1.664082026548127','test','test','0.2'),('2019-09-26 15:59:59','2019-09-26 19:59:59','ETHBTC','4h','0.020179000000000','0.020305000000000','0.033609834486198','0.033819698163549','1.6655847408790545','1.665584740879055','test','test','0.0'),('2019-09-28 15:59:59','2019-10-11 19:59:59','ETHBTC','4h','0.021072000000000','0.021802000000000','0.033656470858943','0.034822436297773','1.5972129299042859','1.597212929904286','test','test','0.4'),('2019-10-14 19:59:59','2019-10-15 23:59:59','ETHBTC','4h','0.022311000000000','0.022119000000000','0.033915574289794','0.033623709726859','1.5201279319525889','1.520127931952589','test','test','1.3'),('2019-10-16 11:59:59','2019-10-16 15:59:59','ETHBTC','4h','0.021939000000000','0.021810000000000','0.033850715498031','0.033651675327593','1.5429470576612832','1.542947057661283','test','test','0.6'),('2019-10-24 03:59:59','2019-10-24 23:59:59','ETHBTC','4h','0.021602000000000','0.021636000000000','0.033806484349045','0.033859693332837','1.5649701115195198','1.564970111519520','test','test','0.0'),('2019-11-05 15:59:59','2019-11-07 11:59:59','ETHBTC','4h','0.020321000000000','0.020291000000000','0.033818308567665','0.033768382419492','1.6642049391105314','1.664204939110531','test','test','0.5'),('2019-11-08 11:59:59','2019-11-21 11:59:59','ETHBTC','4h','0.020405000000000','0.021376000000000','0.033807213868071','0.035415976654932','1.6568102851296795','1.656810285129680','test','test','0.0'),('2019-12-14 19:59:59','2019-12-14 23:59:59','ETHBTC','4h','0.020096000000000','0.020072000000000','0.034164716709596','0.034123914898239','1.7000754732083885','1.700075473208388','test','test','0.1'),('2019-12-29 19:59:59','2019-12-31 15:59:59','ETHBTC','4h','0.018054000000000','0.018033000000000','0.034155649640405','0.034115920569703','1.8918605096048149','1.891860509604815','test','test','0.4');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:46:27
