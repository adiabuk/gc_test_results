-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-05 03:59:59','2019-01-07 11:59:59','WANBTC','4h','0.000093100000000','0.000092200000000','0.033333333333333','0.033011099176512','358.03795202291445','358.037952022914453','test','test','1.0'),('2019-01-16 15:59:59','2019-01-16 19:59:59','WANBTC','4h','0.000087800000000','0.000087700000000','0.033261725742929','0.033223842228415','378.83514513586175','378.835145135861751','test','test','0.1'),('2019-01-17 03:59:59','2019-01-20 11:59:59','WANBTC','4h','0.000091700000000','0.000088032000000','0.033253307184148','0.031923174896782','362.6314851052102','362.631485105210174','test','test','4.0'),('2019-01-21 23:59:59','2019-01-22 11:59:59','WANBTC','4h','0.000090700000000','0.000090800000000','0.032957722231400','0.032994059301115','363.3706971488399','363.370697148839895','test','test','0.0'),('2019-01-22 15:59:59','2019-01-23 19:59:59','WANBTC','4h','0.000091300000000','0.000089000000000','0.032965797135781','0.032135333462043','361.0711624948618','361.071162494861824','test','test','2.5'),('2019-01-26 11:59:59','2019-01-27 15:59:59','WANBTC','4h','0.000091100000000','0.000087800000000','0.032781249652728','0.031593783968271','359.83808619899014','359.838086198990140','test','test','3.6'),('2019-02-06 19:59:59','2019-02-06 23:59:59','WANBTC','4h','0.000082600000000','0.000082900000000','0.032517368389515','0.032635470211753','393.6727407931638','393.672740793163825','test','test','0.0'),('2019-02-07 07:59:59','2019-02-07 15:59:59','WANBTC','4h','0.000083000000000','0.000080100000000','0.032543613238902','0.031406547234169','392.0917257698983','392.091725769898289','test','test','3.5'),('2019-02-11 23:59:59','2019-02-12 03:59:59','WANBTC','4h','0.000080700000000','0.000079800000000','0.032290931904516','0.031930809987365','400.13546350082333','400.135463500823334','test','test','1.1'),('2019-02-12 07:59:59','2019-02-12 11:59:59','WANBTC','4h','0.000081100000000','0.000081000000000','0.032210904811816','0.032171187296635','397.175151810311','397.175151810310979','test','test','0.1'),('2019-02-12 15:59:59','2019-02-12 23:59:59','WANBTC','4h','0.000081600000000','0.000081100000000','0.032202078697332','0.032004762038647','394.63331736925926','394.633317369259260','test','test','0.6'),('2019-02-17 23:59:59','2019-02-18 03:59:59','WANBTC','4h','0.000079900000000','0.000079600000000','0.032158230550957','0.032037486256022','402.4809831158587','402.480983115858692','test','test','0.4'),('2019-02-24 03:59:59','2019-02-24 15:59:59','WANBTC','4h','0.000079400000000','0.000076900000000','0.032131398485416','0.031119704578444','404.6775627886145','404.677562788614523','test','test','3.1'),('2019-02-26 07:59:59','2019-02-26 11:59:59','WANBTC','4h','0.000078200000000','0.000078200000000','0.031906577617200','0.031906577617200','408.0125014987212','408.012501498721178','test','test','0.0'),('2019-02-26 15:59:59','2019-03-04 07:59:59','WANBTC','4h','0.000078200000000','0.000078500000000','0.031906577617200','0.032028981367650','408.0125014987212','408.012501498721178','test','test','0.0'),('2019-03-07 19:59:59','2019-03-17 03:59:59','WANBTC','4h','0.000081400000000','0.000101100000000','0.031933778450633','0.039662223603919','392.3068605728911','392.306860572891082','test','test','1.4'),('2019-03-19 07:59:59','2019-03-19 11:59:59','WANBTC','4h','0.000103900000000','0.000100900000000','0.033651210706919','0.032679568434342','323.8807575256892','323.880757525689205','test','test','2.9'),('2019-03-19 19:59:59','2019-03-19 23:59:59','WANBTC','4h','0.000102500000000','0.000100600000000','0.033435290201902','0.032815514090842','326.1979531892878','326.197953189287773','test','test','1.9'),('2019-03-23 07:59:59','2019-03-23 11:59:59','WANBTC','4h','0.000101900000000','0.000101100000000','0.033297562177222','0.033036148538932','326.7670478628263','326.767047862826303','test','test','0.8'),('2019-03-23 19:59:59','2019-03-24 11:59:59','WANBTC','4h','0.000104500000000','0.000102200000000','0.033239470257602','0.032507883830880','318.0810550966698','318.081055096669786','test','test','2.2'),('2019-03-24 19:59:59','2019-03-24 23:59:59','WANBTC','4h','0.000101600000000','0.000101600000000','0.033076895496108','0.033076895496108','325.55999504043524','325.559995040435240','test','test','0.0'),('2019-03-27 03:59:59','2019-03-27 07:59:59','WANBTC','4h','0.000101600000000','0.000103400000000','0.033076895496108','0.033662903487181','325.55999504043524','325.559995040435240','test','test','0.0'),('2019-03-27 11:59:59','2019-03-27 15:59:59','WANBTC','4h','0.000102700000000','0.000100000000000','0.033207119494124','0.032334098825827','323.340988258271','323.340988258271011','test','test','2.6'),('2019-03-28 07:59:59','2019-03-29 11:59:59','WANBTC','4h','0.000102200000000','0.000101200000000','0.033013114901170','0.032690090293526','323.02460764353765','323.024607643537649','test','test','1.0'),('2019-03-29 15:59:59','2019-03-30 03:59:59','WANBTC','4h','0.000103500000000','0.000101600000000','0.032941331655026','0.032336611557011','318.27373579735695','318.273735797356949','test','test','1.8'),('2019-03-31 11:59:59','2019-04-02 03:59:59','WANBTC','4h','0.000103500000000','0.000103500000000','0.032806949411023','0.032806949411023','316.97535662824265','316.975356628242650','test','test','0.0'),('2019-04-19 07:59:59','2019-04-19 19:59:59','WANBTC','4h','0.000085300000000','0.000084600000000','0.032806949411023','0.032537724738248','384.6066753930025','384.606675393002490','test','test','1.6'),('2019-05-16 03:59:59','2019-05-16 07:59:59','WANBTC','4h','0.000053200000000','0.000053000000000','0.032747121705962','0.032624012225864','615.5474004880074','615.547400488007384','test','test','0.4'),('2019-05-18 03:59:59','2019-05-18 11:59:59','WANBTC','4h','0.000054600000000','0.000053000000000','0.032719764043718','0.031760943119360','599.2630777237728','599.263077723772767','test','test','2.9'),('2019-05-18 23:59:59','2019-05-19 03:59:59','WANBTC','4h','0.000054500000000','0.000052320000000','0.032506692727194','0.031206425018106','596.4530775631926','596.453077563192551','test','test','4.0'),('2019-05-22 07:59:59','2019-05-22 11:59:59','WANBTC','4h','0.000053000000000','0.000050880000000','0.032217744347397','0.030929034573501','607.8819688188049','607.881968818804921','test','test','4.0'),('2019-05-22 19:59:59','2019-05-22 23:59:59','WANBTC','4h','0.000053600000000','0.000052200000000','0.031931364397642','0.031097336223077','595.7344104037685','595.734410403768493','test','test','2.6'),('2019-05-23 03:59:59','2019-05-23 07:59:59','WANBTC','4h','0.000053300000000','0.000051168000000','0.031746024803294','0.030476183811162','595.6102214501728','595.610221450172844','test','test','4.0'),('2019-05-23 11:59:59','2019-05-24 15:59:59','WANBTC','4h','0.000053300000000','0.000053200000000','0.031463837916154','0.031404806325317','590.3159083706148','590.315908370614807','test','test','0.2'),('2019-05-30 07:59:59','2019-05-30 15:59:59','WANBTC','4h','0.000051300000000','0.000049248000000','0.031450719784857','0.030192690993463','613.0744597437946','613.074459743794591','test','test','4.0'),('2019-06-02 11:59:59','2019-06-11 19:59:59','WANBTC','4h','0.000054600000000','0.000056600000000','0.031171157831214','0.032312958484372','570.9003265790028','570.900326579002808','test','test','3.7'),('2019-06-12 11:59:59','2019-06-12 23:59:59','WANBTC','4h','0.000057300000000','0.000057500000000','0.031424891309693','0.031534576794195','548.4274225077331','548.427422507733127','test','test','0.3'),('2019-06-13 11:59:59','2019-06-13 19:59:59','WANBTC','4h','0.000058800000000','0.000056600000000','0.031449265861805','0.030272592649288','534.8514602347733','534.851460234773299','test','test','3.7'),('2019-06-14 03:59:59','2019-06-14 11:59:59','WANBTC','4h','0.000060300000000','0.000057888000000','0.031187782925690','0.029940271608662','517.2103304426165','517.210330442616510','test','test','4.0'),('2019-07-07 07:59:59','2019-07-07 15:59:59','WANBTC','4h','0.000034300000000','0.000032928000000','0.030910558188572','0.029674135861029','901.1824544773307','901.182454477330680','test','test','4.0'),('2019-07-07 23:59:59','2019-07-08 07:59:59','WANBTC','4h','0.000034100000000','0.000032736000000','0.030635797671341','0.029410365764487','898.4104888956207','898.410488895620688','test','test','4.0'),('2019-07-23 23:59:59','2019-07-24 03:59:59','WANBTC','4h','0.000025900000000','0.000025600000000','0.030363479469818','0.030011778935419','1172.3351146647701','1172.335114664770117','test','test','1.2'),('2019-07-24 07:59:59','2019-07-30 23:59:59','WANBTC','4h','0.000026200000000','0.000028600000000','0.030285323795507','0.033059551929447','1155.9283891414755','1155.928389141475463','test','test','0.0'),('2019-07-31 07:59:59','2019-07-31 11:59:59','WANBTC','4h','0.000028600000000','0.000029200000000','0.030901818936382','0.031550108844138','1080.483179593784','1080.483179593783916','test','test','0.0'),('2019-08-22 15:59:59','2019-08-29 03:59:59','WANBTC','4h','0.000021800000000','0.000034700000000','0.031045883360328','0.049417071220339','1424.1230899233026','1424.123089923302587','test','test','0.0'),('2019-08-30 15:59:59','2019-08-31 07:59:59','WANBTC','4h','0.000039580000000','0.000037996800000','0.035128369551442','0.033723234769384','887.5282857868002','887.528285786800211','test','test','4.0'),('2019-08-31 11:59:59','2019-08-31 15:59:59','WANBTC','4h','0.000040660000000','0.000039033600000','0.034816117377651','0.033423472682545','856.2744067302234','856.274406730223404','test','test','4.0'),('2019-08-31 19:59:59','2019-08-31 23:59:59','WANBTC','4h','0.000036100000000','0.000035300000000','0.034506640778738','0.033741950678378','955.8626254498182','955.862625449818211','test','test','2.2'),('2019-09-01 19:59:59','2019-09-02 11:59:59','WANBTC','4h','0.000041540000000','0.000039878400000','0.034336709645325','0.032963241259512','826.593876873498','826.593876873497948','test','test','4.0'),('2019-09-02 15:59:59','2019-09-02 19:59:59','WANBTC','4h','0.000039830000000','0.000038236800000','0.034031494448478','0.032670234670539','854.4186404337878','854.418640433787800','test','test','4.0'),('2019-09-22 15:59:59','2019-09-22 19:59:59','WANBTC','4h','0.000026540000000','0.000026310000000','0.033728992275602','0.033436691287532','1270.8738611756758','1270.873861175675756','test','test','0.9'),('2019-09-23 15:59:59','2019-09-23 19:59:59','WANBTC','4h','0.000026040000000','0.000025680000000','0.033664036500476','0.033198635074202','1292.7817396496073','1292.781739649607289','test','test','1.4'),('2019-10-02 11:59:59','2019-10-02 15:59:59','WANBTC','4h','0.000024120000000','0.000024000000000','0.033560613961304','0.033393645732641','1391.4019055266904','1391.401905526690371','test','test','0.5'),('2019-10-02 23:59:59','2019-10-06 23:59:59','WANBTC','4h','0.000024870000000','0.000024200000000','0.033523509910490','0.032620383588012','1347.949735041808','1347.949735041808026','test','test','2.7'),('2019-10-07 11:59:59','2019-10-08 07:59:59','WANBTC','4h','0.000024810000000','0.000024380000000','0.033322815172161','0.032745273433990','1343.1203213285498','1343.120321328549835','test','test','1.7'),('2019-10-08 11:59:59','2019-10-11 03:59:59','WANBTC','4h','0.000024910000000','0.000024560000000','0.033194472563679','0.032728070901805','1332.5761767835766','1332.576176783576557','test','test','1.4'),('2019-10-14 15:59:59','2019-10-14 23:59:59','WANBTC','4h','0.000025070000000','0.000025630000000','0.033090827749929','0.033829992629864','1319.9372855974914','1319.937285597491382','test','test','0.0'),('2019-10-15 07:59:59','2019-10-15 15:59:59','WANBTC','4h','0.000025390000000','0.000024700000000','0.033255086612137','0.032351344597077','1309.7710363189005','1309.771036318900542','test','test','2.7'),('2019-10-21 19:59:59','2019-10-21 23:59:59','WANBTC','4h','0.000024610000000','0.000024540000000','0.033054255053235','0.032960236448858','1343.1229196763375','1343.122919676337460','test','test','0.3'),('2019-10-22 03:59:59','2019-10-22 11:59:59','WANBTC','4h','0.000024590000000','0.000024260000000','0.033033362030040','0.032590051356192','1343.36567832614','1343.365678326139914','test','test','1.3'),('2019-10-27 19:59:59','2019-10-27 23:59:59','WANBTC','4h','0.000024530000000','0.000023910000000','0.032934848546962','0.032102414543737','1342.6354890730715','1342.635489073071540','test','test','2.5'),('2019-10-28 03:59:59','2019-10-28 15:59:59','WANBTC','4h','0.000026230000000','0.000025180800000','0.032749863212912','0.031439868684396','1248.5651243962043','1248.565124396204283','test','test','4.0'),('2019-10-31 15:59:59','2019-11-02 15:59:59','WANBTC','4h','0.000024780000000','0.000024130000000','0.032458753317687','0.031607333234697','1309.8770507541028','1309.877050754102811','test','test','2.6'),('2019-11-04 15:59:59','2019-11-04 23:59:59','WANBTC','4h','0.000024440000000','0.000024360000000','0.032269548854800','0.032163920216977','1320.357972782324','1320.357972782323941','test','test','0.3'),('2019-11-05 19:59:59','2019-11-06 07:59:59','WANBTC','4h','0.000026940000000','0.000025862400000','0.032246075824173','0.030956232791206','1196.9590135179164','1196.959013517916446','test','test','4.0'),('2019-11-06 11:59:59','2019-11-07 07:59:59','WANBTC','4h','0.000026380000000','0.000025324800000','0.031959444039069','0.030681066277506','1211.5028066364246','1211.502806636424566','test','test','4.0'),('2019-11-11 19:59:59','2019-11-15 15:59:59','WANBTC','4h','0.000025370000000','0.000025120000000','0.031675360092055','0.031363226074593','1248.5360698484385','1248.536069848438501','test','test','1.0'),('2019-11-16 11:59:59','2019-11-21 11:59:59','WANBTC','4h','0.000026110000000','0.000026990000000','0.031605996977063','0.032671231651127','1210.4939478002043','1210.493947800204296','test','test','0.0'),('2019-11-21 19:59:59','2019-11-21 23:59:59','WANBTC','4h','0.000027030000000','0.000027310000000','0.031842715793522','0.032172570045175','1178.05089876145','1178.050898761450071','test','test','0.0'),('2019-11-23 15:59:59','2019-11-24 15:59:59','WANBTC','4h','0.000028040000000','0.000026918400000','0.031916016738334','0.030639376068801','1138.2316953756697','1138.231695375669688','test','test','4.0'),('2019-11-26 19:59:59','2019-11-27 11:59:59','WANBTC','4h','0.000028880000000','0.000028070000000','0.031632318811771','0.030745124274460','1095.3018979145043','1095.301897914504252','test','test','2.8'),('2019-11-27 15:59:59','2019-11-27 19:59:59','WANBTC','4h','0.000029370000000','0.000028195200000','0.031435164470146','0.030177757891340','1070.3154399096434','1070.315439909643374','test','test','4.0'),('2019-11-27 23:59:59','2019-11-30 07:59:59','WANBTC','4h','0.000027510000000','0.000027890000000','0.031155740785967','0.031586099982574','1132.524201598223','1132.524201598223044','test','test','0.0'),('2019-12-16 11:59:59','2019-12-16 19:59:59','WANBTC','4h','0.000025700000000','0.000025140000000','0.031251376162991','0.030570412324420','1216.0068545910851','1216.006854591085130','test','test','2.2'),('2019-12-16 23:59:59','2019-12-20 23:59:59','WANBTC','4h','0.000025540000000','0.000026260000000','0.031100050865531','0.031976794664403','1217.699720655077','1217.699720655077044','test','test','0.0'),('2019-12-31 03:59:59','2019-12-31 15:59:59','WANBTC','4h','0.000025200000000','0.000024290000000','0.031294882820836','0.030164789830084','1241.8604293982364','1241.860429398236420','test','test','3.6'),('2020-01-01 15:59:59','2020-01-01 15:59:59','WANBTC','4h','0.000024690000000','0.000024690000000','0.031043751045113','0.031043751045113','1257.3410710859819','1257.341071085981866','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:59:04
