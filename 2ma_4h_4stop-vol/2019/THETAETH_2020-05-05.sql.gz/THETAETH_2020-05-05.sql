-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 15:59:59','2019-01-10 23:59:59','THETAETH','4h','0.000353100000000','0.000349670000000','1.297777777777778','1.285171213694578','3675.3831146354505','3675.383114635450511','test','test','1.0'),('2019-01-11 03:59:59','2019-01-11 07:59:59','THETAETH','4h','0.000348730000000','0.000351980000000','1.294976319092622','1.307044890873229','3713.4067017251805','3713.406701725180483','test','test','0.0'),('2019-01-11 11:59:59','2019-01-14 15:59:59','THETAETH','4h','0.000363560000000','0.000358480000000','1.297658223932757','1.279526130804859','3569.3096708459598','3569.309670845959772','test','test','1.4'),('2019-01-14 23:59:59','2019-01-15 03:59:59','THETAETH','4h','0.000358330000000','0.000358150000000','1.293628869904335','1.292979040985230','3610.1606616926724','3610.160661692672420','test','test','0.1'),('2019-01-15 07:59:59','2019-01-15 15:59:59','THETAETH','4h','0.000370510000000','0.000365510000000','1.293484463477868','1.276029003929166','3491.0919097402707','3491.091909740270694','test','test','1.3'),('2019-01-15 19:59:59','2019-02-17 23:59:59','THETAETH','4h','0.000367640000000','0.000672760000000','1.289605472467045','2.359903649376915','3507.7942347596695','3507.794234759669507','test','test','0.0'),('2019-02-20 19:59:59','2019-02-20 23:59:59','THETAETH','4h','0.000678530000000','0.000659270000000','1.527449511780349','1.484093024083579','2251.1156644221323','2251.115664422132340','test','test','2.8'),('2019-02-24 23:59:59','2019-03-04 07:59:59','THETAETH','4h','0.000662050000000','0.000976200000000','1.517814736736623','2.238034507971137','2292.59834866947','2292.598348669469942','test','test','0.0'),('2019-03-04 11:59:59','2019-03-05 19:59:59','THETAETH','4h','0.000968470000000','0.000929731200000','1.677863574788737','1.610749031797187','1732.4889514272377','1732.488951427237680','test','test','4.0'),('2019-03-06 03:59:59','2019-03-08 07:59:59','THETAETH','4h','0.000928220000000','0.000932940000000','1.662949231901726','1.671405331074957','1791.5464350064917','1791.546435006491720','test','test','0.0'),('2019-03-09 03:59:59','2019-03-09 11:59:59','THETAETH','4h','0.000955730000000','0.000946430000000','1.664828365051333','1.648628283652844','1741.944236396611','1741.944236396610904','test','test','1.0'),('2019-03-09 23:59:59','2019-03-12 19:59:59','THETAETH','4h','0.001012890000000','0.000976950000000','1.661228346962780','1.602283597987233','1640.087617572273','1640.087617572273075','test','test','3.5'),('2019-03-14 19:59:59','2019-03-14 23:59:59','THETAETH','4h','0.001090000000000','0.001046400000000','1.648129513857103','1.582204333302819','1512.0454255569748','1512.045425556974806','test','test','4.0'),('2019-04-05 03:59:59','2019-04-05 07:59:59','THETAETH','4h','0.000789050000000','0.000757488000000','1.633479473733928','1.568140294784571','2070.184999345958','2070.184999345958204','test','test','4.0'),('2019-04-14 03:59:59','2019-04-14 23:59:59','THETAETH','4h','0.000740530000000','0.000722470000000','1.618959656189627','1.579476567873442','2186.2175147389394','2186.217514738939371','test','test','2.4'),('2019-04-15 19:59:59','2019-04-18 07:59:59','THETAETH','4h','0.000740730000000','0.000731410000000','1.610185636563808','1.589925987119645','2173.7821292020144','2173.782129202014403','test','test','1.3'),('2019-05-18 07:59:59','2019-05-18 11:59:59','THETAETH','4h','0.000490570000000','0.000483100000000','1.605683492242883','1.581233453131127','3273.0976053221416','3273.097605322141590','test','test','1.5'),('2019-05-24 03:59:59','2019-05-24 07:59:59','THETAETH','4h','0.000559060000000','0.000536697600000','1.600250150218048','1.536240144209326','2862.394287228648','2862.394287228647954','test','test','4.0'),('2019-05-24 11:59:59','2019-05-24 15:59:59','THETAETH','4h','0.000477090000000','0.000497010000000','1.586025704438332','1.652247239227180','3324.3742363879605','3324.374236387960536','test','test','0.0'),('2019-05-25 03:59:59','2019-05-26 19:59:59','THETAETH','4h','0.000493010000000','0.000473289600000','1.600741601058076','1.536711937015753','3246.8745077342774','3246.874507734277358','test','test','4.0'),('2019-05-29 11:59:59','2019-05-29 15:59:59','THETAETH','4h','0.000577350000000','0.000554256000000','1.586512786826449','1.523052275353391','2747.9220348600475','2747.922034860047461','test','test','4.0'),('2019-05-29 19:59:59','2019-05-30 03:59:59','THETAETH','4h','0.000581710000000','0.000558441600000','1.572410450943547','1.509514032905805','2703.083067067004','2703.083067067003867','test','test','4.0'),('2019-05-30 07:59:59','2019-05-30 15:59:59','THETAETH','4h','0.000529000000000','0.000507840000000','1.558433469157382','1.496096130391087','2945.998996516791','2945.998996516791067','test','test','4.0'),('2019-05-30 23:59:59','2019-05-31 23:59:59','THETAETH','4h','0.000515000000000','0.000511070000000','1.544580727209317','1.532793926708477','2999.1858780763428','2999.185878076342760','test','test','2.2'),('2019-06-02 03:59:59','2019-06-03 07:59:59','THETAETH','4h','0.000523000000000','0.000511100000000','1.541961438209130','1.506876655963071','2948.301029080554','2948.301029080554144','test','test','2.3'),('2019-06-03 15:59:59','2019-06-04 07:59:59','THETAETH','4h','0.000519440000000','0.000505520000000','1.534164819932228','1.493052132627714','2953.4976511863306','2953.497651186330586','test','test','2.7'),('2019-06-04 15:59:59','2019-06-04 19:59:59','THETAETH','4h','0.000518620000000','0.000513870000000','1.525028667197891','1.511061048962594','2940.5512074310504','2940.551207431050443','test','test','0.9'),('2019-06-05 03:59:59','2019-06-12 19:59:59','THETAETH','4h','0.000526840000000','0.000547800000000','1.521924752034492','1.582473576730117','2888.7798041805713','2888.779804180571318','test','test','2.3'),('2019-07-02 03:59:59','2019-07-02 07:59:59','THETAETH','4h','0.000417370000000','0.000407050000000','1.535380046411298','1.497415837007257','3678.7024616318795','3678.702461631879487','test','test','2.5'),('2019-07-04 03:59:59','2019-07-04 07:59:59','THETAETH','4h','0.000418760000000','0.000402009600000','1.526943555432622','1.465865813215317','3646.3452942798303','3646.345294279830341','test','test','4.0'),('2019-07-06 11:59:59','2019-07-06 15:59:59','THETAETH','4h','0.000410170000000','0.000399890000000','1.513370723828776','1.475441448062728','3689.618265179746','3689.618265179745777','test','test','2.5'),('2019-07-06 23:59:59','2019-07-07 15:59:59','THETAETH','4h','0.000413470000000','0.000411970000000','1.504941995880766','1.499482318047257','3639.7852223396276','3639.785222339627580','test','test','0.4'),('2019-07-10 15:59:59','2019-07-12 03:59:59','THETAETH','4h','0.000405870000000','0.000393520000000','1.503728734139986','1.457972581020443','3704.951669598605','3704.951669598604894','test','test','3.0'),('2019-07-12 15:59:59','2019-07-31 15:59:59','THETAETH','4h','0.000407000000000','0.000584000000000','1.493560700113421','2.143094468958815','3669.6823098609843','3669.682309860984333','test','test','0.0'),('2019-07-31 19:59:59','2019-08-02 15:59:59','THETAETH','4h','0.000593440000000','0.000583100000000','1.637901537634619','1.609363013269659','2760.01202755901','2760.012027559010221','test','test','1.7'),('2019-08-11 03:59:59','2019-08-11 11:59:59','THETAETH','4h','0.000558500000000','0.000555660000000','1.631559643331295','1.623263082208536','2921.324338999633','2921.324338999632801','test','test','0.5'),('2019-08-11 15:59:59','2019-08-11 19:59:59','THETAETH','4h','0.000567510000000','0.000560310000000','1.629715963081793','1.609039754849006','2871.695587887073','2871.695587887073088','test','test','1.3'),('2019-08-12 03:59:59','2019-08-14 03:59:59','THETAETH','4h','0.000584130000000','0.000563980000000','1.625121250141174','1.569061480585861','2782.122558576299','2782.122558576299070','test','test','3.4'),('2019-08-14 19:59:59','2019-08-26 03:59:59','THETAETH','4h','0.000587410000000','0.000649750000000','1.612663523573326','1.783810497679251','2745.379757874953','2745.379757874953157','test','test','2.8'),('2019-08-27 15:59:59','2019-08-28 15:59:59','THETAETH','4h','0.000656810000000','0.000654500000000','1.650696184485754','1.644890687940083','2513.2019678228926','2513.201967822892584','test','test','0.4'),('2019-08-28 19:59:59','2019-08-29 03:59:59','THETAETH','4h','0.000684460000000','0.000657081600000','1.649406074142272','1.583429831176581','2409.791768901428','2409.791768901427986','test','test','4.0'),('2019-08-29 15:59:59','2019-08-30 11:59:59','THETAETH','4h','0.000666340000000','0.000646440000000','1.634744686816562','1.585923635599991','2453.3191566115834','2453.319156611583367','test','test','3.0'),('2019-09-01 23:59:59','2019-09-02 03:59:59','THETAETH','4h','0.000663670000000','0.000644730000000','1.623895564323991','1.577552378722267','2446.8419008302185','2446.841900830218492','test','test','2.9'),('2019-09-05 15:59:59','2019-09-06 07:59:59','THETAETH','4h','0.000661920000000','0.000643900000000','1.613597078634719','1.569668780113753','2437.7524151479315','2437.752415147931515','test','test','2.7'),('2019-10-06 03:59:59','2019-10-06 07:59:59','THETAETH','4h','0.000496230000000','0.000484490000000','1.603835234518949','1.565891084319944','3232.0400510226086','3232.040051022608623','test','test','2.4'),('2019-10-06 15:59:59','2019-10-07 03:59:59','THETAETH','4h','0.000486150000000','0.000477650000000','1.595403201141392','1.567508668158358','3281.7097627098474','3281.709762709847382','test','test','1.7'),('2019-10-08 15:59:59','2019-10-09 15:59:59','THETAETH','4h','0.000494630000000','0.000474844800000','1.589204416034051','1.525636239392689','3212.9155450216354','3212.915545021635353','test','test','4.0'),('2019-10-12 19:59:59','2019-10-13 03:59:59','THETAETH','4h','0.000484660000000','0.000473120000000','1.575078154558193','1.537574746182009','3249.8620776589632','3249.862077658963244','test','test','2.4'),('2019-10-13 11:59:59','2019-10-13 15:59:59','THETAETH','4h','0.000482170000000','0.000474240000000','1.566744063807930','1.540976636498066','3249.3603165023333','3249.360316502333262','test','test','1.6'),('2019-10-15 03:59:59','2019-10-16 11:59:59','THETAETH','4h','0.000486730000000','0.000477830000000','1.561017968850183','1.532474300034276','3207.1537995401613','3207.153799540161344','test','test','1.8'),('2019-10-16 19:59:59','2019-10-17 03:59:59','THETAETH','4h','0.000485140000000','0.000480660000000','1.554674931335537','1.540318366854391','3204.590285970105','3204.590285970105015','test','test','1.1'),('2019-10-17 11:59:59','2019-10-18 07:59:59','THETAETH','4h','0.000482690000000','0.000477630000000','1.551484583673060','1.535220497005870','3214.2463769149135','3214.246376914913526','test','test','1.0'),('2019-10-20 15:59:59','2019-10-20 19:59:59','THETAETH','4h','0.000481890000000','0.000483680000000','1.547870342191462','1.553619969518285','3212.0823054876882','3212.082305487688245','test','test','0.0'),('2019-10-21 11:59:59','2019-10-26 03:59:59','THETAETH','4h','0.000484400000000','0.000527100000000','1.549148037152978','1.685705884358659','3198.076046971466','3198.076046971465985','test','test','0.0'),('2019-10-28 23:59:59','2019-10-29 23:59:59','THETAETH','4h','0.000540910000000','0.000530450000000','1.579494225420907','1.548950309431366','2920.068450242937','2920.068450242937161','test','test','1.9'),('2019-11-15 15:59:59','2019-11-16 15:59:59','THETAETH','4h','0.000504510000000','0.000489530000000','1.572706688534343','1.526009603849710','3117.295372805975','3117.295372805975148','test','test','3.0'),('2019-11-18 07:59:59','2019-11-18 11:59:59','THETAETH','4h','0.000495040000000','0.000514220000000','1.562329558604424','1.622860992294697','3155.966302933953','3155.966302933953102','test','test','0.0'),('2019-11-18 15:59:59','2019-11-20 23:59:59','THETAETH','4h','0.000514880000000','0.000508380000000','1.575780988313374','1.555887855109449','3060.4820313730843','3060.482031373084283','test','test','2.6'),('2019-11-21 19:59:59','2019-11-22 11:59:59','THETAETH','4h','0.000509140000000','0.000502860000000','1.571360292045835','1.551978309420137','3086.302965875466','3086.302965875465816','test','test','1.4'),('2019-11-26 15:59:59','2019-11-26 19:59:59','THETAETH','4h','0.000502000000000','0.000500770000000','1.567053184795680','1.563213592330942','3121.6198900312347','3121.619890031234718','test','test','0.2'),('2019-11-26 23:59:59','2019-11-27 03:59:59','THETAETH','4h','0.000497370000000','0.000504400000000','1.566199942025738','1.588337154950605','3148.963431702229','3148.963431702229173','test','test','0.0'),('2019-11-27 15:59:59','2019-11-27 19:59:59','THETAETH','4h','0.000510120000000','0.000498920000000','1.571119322675709','1.536624426545450','3079.901440201734','3079.901440201734204','test','test','2.2'),('2019-11-30 03:59:59','2019-11-30 07:59:59','THETAETH','4h','0.000502260000000','0.000492560000000','1.563453790202318','1.533259265922139','3112.8375546575826','3112.837554657582587','test','test','1.9'),('2019-12-03 23:59:59','2019-12-04 03:59:59','THETAETH','4h','0.000497180000000','0.000491440000000','1.556743895917833','1.538771109477171','3131.147463529976','3131.147463529975994','test','test','1.2'),('2019-12-04 15:59:59','2019-12-04 19:59:59','THETAETH','4h','0.000495470000000','0.000489390000000','1.552749943375464','1.533695874197264','3133.892956940811','3133.892956940811018','test','test','1.2'),('2019-12-05 11:59:59','2019-12-10 03:59:59','THETAETH','4h','0.000502700000000','0.000550400000000','1.548515705780308','1.695450655383890','3080.397266322475','3080.397266322474934','test','test','0.0'),('2019-12-10 07:59:59','2019-12-10 15:59:59','THETAETH','4h','0.000547680000000','0.000525772800000','1.581167916803326','1.517921200131193','2887.0287700907943','2887.028770090794296','test','test','4.0'),('2019-12-11 19:59:59','2019-12-12 03:59:59','THETAETH','4h','0.000594470000000','0.000570691200000','1.567113090876186','1.504428567241138','2636.151682803482','2636.151682803481890','test','test','4.0'),('2019-12-12 07:59:59','2019-12-17 23:59:59','THETAETH','4h','0.000566820000000','0.000778510000000','1.553183196735064','2.133249797978573','2740.1700658675845','2740.170065867584526','test','test','0.0'),('2019-12-18 07:59:59','2019-12-22 19:59:59','THETAETH','4h','0.000790190000000','0.000758582400000','1.682086885900288','1.614803410464276','2128.7119375090656','2128.711937509065592','test','test','4.0'),('2019-12-25 03:59:59','2019-12-25 19:59:59','THETAETH','4h','0.000763910000000','0.000733353600000','1.667135002470064','1.600449602371261','2182.370963163283','2182.370963163282795','test','test','4.0'),('2019-12-31 11:59:59','2019-12-31 15:59:59','THETAETH','4h','0.000708700000000','0.000696490000000','1.652316024670329','1.623848720223843','2331.47456564178','2331.474565641779918','test','test','1.7');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:17:48
