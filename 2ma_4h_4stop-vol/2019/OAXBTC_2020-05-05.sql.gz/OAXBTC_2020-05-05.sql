-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 07:59:59','2019-01-07 11:59:59','OAXBTC','4h','0.000023730000000','0.000024190000000','0.033333333333333','0.033979491501615','1404.6916701783957','1404.691670178395725','test','test','0.0'),('2019-01-14 19:59:59','2019-01-27 11:59:59','OAXBTC','4h','0.000023820000000','0.000039560000000','0.033476924037396','0.055598115655726','1405.412428102267','1405.412428102267086','test','test','0.0'),('2019-01-27 23:59:59','2019-01-28 03:59:59','OAXBTC','4h','0.000042060000000','0.000040377600000','0.038392744397025','0.036857034621144','912.8089490495693','912.808949049569264','test','test','4.0'),('2019-02-02 11:59:59','2019-02-02 15:59:59','OAXBTC','4h','0.000040000000000','0.000038910000000','0.038051475557940','0.037014572848986','951.2868889485053','951.286888948505293','test','test','2.7'),('2019-02-10 23:59:59','2019-02-11 03:59:59','OAXBTC','4h','0.000036180000000','0.000035420000000','0.037821052733728','0.037026580647558','1045.3580081185244','1045.358008118524367','test','test','2.1'),('2019-02-11 15:59:59','2019-02-12 03:59:59','OAXBTC','4h','0.000037480000000','0.000035980800000','0.037644503381246','0.036138723245996','1004.3890976853254','1004.389097685325396','test','test','4.0'),('2019-02-12 19:59:59','2019-02-12 23:59:59','OAXBTC','4h','0.000037340000000','0.000035846400000','0.037309885573413','0.035817490150476','999.1935075900552','999.193507590055219','test','test','4.0'),('2019-02-13 15:59:59','2019-02-14 15:59:59','OAXBTC','4h','0.000036040000000','0.000035880000000','0.036978242146093','0.036814076809151','1026.0333558849427','1026.033355884942694','test','test','0.4'),('2019-02-15 15:59:59','2019-02-15 19:59:59','OAXBTC','4h','0.000036110000000','0.000036000000000','0.036941760960106','0.036829227210297','1023.0340891749162','1023.034089174916176','test','test','0.3'),('2019-02-25 15:59:59','2019-02-25 19:59:59','OAXBTC','4h','0.000033860000000','0.000033120000000','0.036916753460149','0.036109949043123','1090.2762392247096','1090.276239224709570','test','test','2.2'),('2019-02-26 15:59:59','2019-02-26 19:59:59','OAXBTC','4h','0.000033580000000','0.000033910000000','0.036737463589698','0.037098492862616','1094.0280997527825','1094.028099752782509','test','test','0.0'),('2019-03-01 19:59:59','2019-03-01 23:59:59','OAXBTC','4h','0.000033160000000','0.000033270000000','0.036817692317014','0.036939825795750','1110.3043521415425','1110.304352141542495','test','test','0.0'),('2019-03-02 23:59:59','2019-03-04 03:59:59','OAXBTC','4h','0.000033720000000','0.000033010000000','0.036844833090066','0.036069037375536','1092.6700204645906','1092.670020464590607','test','test','2.1'),('2019-03-06 19:59:59','2019-03-11 11:59:59','OAXBTC','4h','0.000033860000000','0.000033840000000','0.036672434042393','0.036650772829137','1083.0606627995473','1083.060662799547345','test','test','1.2'),('2019-03-12 11:59:59','2019-03-18 07:59:59','OAXBTC','4h','0.000035100000000','0.000037600000000','0.036667620439447','0.039279274316900','1044.6615509813928','1044.661550981392793','test','test','0.0'),('2019-03-18 11:59:59','2019-03-18 19:59:59','OAXBTC','4h','0.000040500000000','0.000038880000000','0.037247987967770','0.035758068449059','919.7034066115993','919.703406611599348','test','test','4.0'),('2019-03-19 07:59:59','2019-03-19 11:59:59','OAXBTC','4h','0.000040490000000','0.000038870400000','0.036916894741390','0.035440218951734','911.7533895132023','911.753389513202251','test','test','4.0'),('2019-03-19 19:59:59','2019-03-21 15:59:59','OAXBTC','4h','0.000039730000000','0.000038140800000','0.036588744565910','0.035125194783274','920.9349248907739','920.934924890773914','test','test','4.0'),('2019-03-26 11:59:59','2019-03-26 15:59:59','OAXBTC','4h','0.000038230000000','0.000088340000000','0.036263511280880','0.083795934777738','948.5616343416224','948.561634341622380','test','test','0.0'),('2019-03-26 19:59:59','2019-03-27 03:59:59','OAXBTC','4h','0.000091990000000','0.000088310400000','0.046826272057960','0.044953221175642','509.0365480808759','509.036548080875889','test','test','4.0'),('2019-03-27 07:59:59','2019-03-27 11:59:59','OAXBTC','4h','0.000109800000000','0.000105408000000','0.046410038528556','0.044553636987414','422.6779465260089','422.677946526008895','test','test','4.0'),('2019-03-27 15:59:59','2019-03-28 03:59:59','OAXBTC','4h','0.000068150000000','0.000065424000000','0.045997504852746','0.044157604658636','674.9450455281944','674.945045528194441','test','test','4.0'),('2019-03-31 15:59:59','2019-04-02 03:59:59','OAXBTC','4h','0.000054120000000','0.000053860000000','0.045588638142944','0.045369623990742','842.3621238533672','842.362123853367166','test','test','0.5'),('2019-04-09 19:59:59','2019-04-10 07:59:59','OAXBTC','4h','0.000054850000000','0.000052656000000','0.045539968331344','0.043718369598090','830.2637799698045','830.263779969804546','test','test','4.0'),('2019-04-10 11:59:59','2019-04-10 15:59:59','OAXBTC','4h','0.000047570000000','0.000053010000000','0.045135168612843','0.050296726679983','948.8158211655013','948.815821165501347','test','test','0.0'),('2019-04-11 23:59:59','2019-04-12 03:59:59','OAXBTC','4h','0.000052690000000','0.000052420000000','0.046282181516652','0.046045017177888','878.3864398681303','878.386439868130310','test','test','0.5'),('2019-04-12 11:59:59','2019-04-12 19:59:59','OAXBTC','4h','0.000057250000000','0.000054960000000','0.046229478330260','0.044380299197050','807.5018048953673','807.501804895367286','test','test','4.0'),('2019-04-20 11:59:59','2019-04-20 15:59:59','OAXBTC','4h','0.000047010000000','0.000046460000000','0.045818549633991','0.045282489172415','974.655384683916','974.655384683916054','test','test','1.2'),('2019-04-20 23:59:59','2019-04-21 07:59:59','OAXBTC','4h','0.000047450000000','0.000045552000000','0.045699425086974','0.043871448083495','963.1069565221076','963.106956522107566','test','test','4.0'),('2019-05-15 23:59:59','2019-05-16 03:59:59','OAXBTC','4h','0.000028040000000','0.000026918400000','0.045293207975090','0.043481479656086','1615.3069891258838','1615.306989125883774','test','test','4.0'),('2019-05-20 11:59:59','2019-05-20 15:59:59','OAXBTC','4h','0.000027360000000','0.000026790000000','0.044890601681978','0.043955380813603','1640.7383655693634','1640.738365569363395','test','test','2.1'),('2019-05-21 03:59:59','2019-05-21 23:59:59','OAXBTC','4h','0.000027770000000','0.000026960000000','0.044682774822339','0.043379460180420','1609.0304221223944','1609.030422122394384','test','test','2.9'),('2019-05-22 15:59:59','2019-05-22 23:59:59','OAXBTC','4h','0.000030580000000','0.000029356800000','0.044393149346357','0.042617423372503','1451.7053416074853','1451.705341607485252','test','test','4.0'),('2019-06-07 07:59:59','2019-06-07 11:59:59','OAXBTC','4h','0.000025900000000','0.000025580000000','0.043998543574389','0.043454932225207','1698.7854661926388','1698.785466192638751','test','test','1.2'),('2019-06-07 15:59:59','2019-06-09 19:59:59','OAXBTC','4h','0.000026830000000','0.000025756800000','0.043877741052349','0.042122631410255','1635.3984738109916','1635.398473810991618','test','test','4.0'),('2019-06-10 07:59:59','2019-06-10 11:59:59','OAXBTC','4h','0.000026520000000','0.000026000000000','0.043487716687439','0.042635016360234','1639.8083215474783','1639.808321547478272','test','test','2.0'),('2019-06-10 15:59:59','2019-06-11 07:59:59','OAXBTC','4h','0.000026080000000','0.000026020000000','0.043298227725838','0.043198615238739','1660.2081183220098','1660.208118322009796','test','test','0.2'),('2019-06-11 11:59:59','2019-06-13 07:59:59','OAXBTC','4h','0.000027690000000','0.000026582400000','0.043276091617594','0.041545047952890','1562.8779926902778','1562.877992690277779','test','test','4.0'),('2019-06-14 07:59:59','2019-06-14 11:59:59','OAXBTC','4h','0.000027370000000','0.000026275200000','0.042891415247660','0.041175758637754','1567.0959169769662','1567.095916976966237','test','test','4.0'),('2019-06-15 07:59:59','2019-06-15 15:59:59','OAXBTC','4h','0.000027880000000','0.000026764800000','0.042510158223236','0.040809751894307','1524.754599111765','1524.754599111764946','test','test','4.0'),('2019-07-26 11:59:59','2019-07-27 03:59:59','OAXBTC','4h','0.000010620000000','0.000010270000000','0.042132290150141','0.040743749514308','3967.258959523604','3967.258959523604062','test','test','3.3'),('2019-07-27 15:59:59','2019-07-30 15:59:59','OAXBTC','4h','0.000010560000000','0.000010840000000','0.041823725564400','0.042932687984668','3960.5800723863645','3960.580072386364463','test','test','0.6'),('2019-08-14 03:59:59','2019-08-14 11:59:59','OAXBTC','4h','0.000008240000000','0.000008050000000','0.042070161657793','0.041100097250635','5105.602142936031','5105.602142936030759','test','test','2.3'),('2019-08-21 15:59:59','2019-08-22 07:59:59','OAXBTC','4h','0.000007590000000','0.000007470000000','0.041854591789536','0.041192859113022','5514.4389709533025','5514.438970953302487','test','test','1.6'),('2019-08-22 15:59:59','2019-08-23 03:59:59','OAXBTC','4h','0.000007680000000','0.000007420000000','0.041707540083644','0.040295566070396','5430.669281724422','5430.669281724422035','test','test','3.4'),('2019-08-24 11:59:59','2019-08-26 03:59:59','OAXBTC','4h','0.000007900000000','0.000007750000000','0.041393768080700','0.040607810458915','5239.717478569564','5239.717478569564264','test','test','1.9'),('2019-08-26 07:59:59','2019-08-29 07:59:59','OAXBTC','4h','0.000008200000000','0.000007930000000','0.041219110831414','0.039861896206477','5026.72083309927','5026.720833099269839','test','test','3.8'),('2019-08-31 07:59:59','2019-08-31 11:59:59','OAXBTC','4h','0.000008880000000','0.000008524800000','0.040917507581428','0.039280807278171','4607.827430340992','4607.827430340991668','test','test','4.0'),('2019-09-10 07:59:59','2019-09-10 11:59:59','OAXBTC','4h','0.000007380000000','0.000007190000000','0.040553796402926','0.039509728473853','5495.09436354017','5495.094363540169979','test','test','2.6'),('2019-09-10 15:59:59','2019-09-11 03:59:59','OAXBTC','4h','0.000007210000000','0.000007060000000','0.040321781307577','0.039482909297017','5592.480070399015','5592.480070399014949','test','test','2.1'),('2019-09-11 15:59:59','2019-09-11 19:59:59','OAXBTC','4h','0.000007340000000','0.000007046400000','0.040135365305230','0.038529950693021','5468.033420331094','5468.033420331094021','test','test','4.0'),('2019-09-15 23:59:59','2019-09-16 07:59:59','OAXBTC','4h','0.000007390000000','0.000007094400000','0.039778606502517','0.038187462242416','5382.761367052383','5382.761367052383321','test','test','4.0'),('2019-09-16 15:59:59','2019-09-16 23:59:59','OAXBTC','4h','0.000007100000000','0.000007150000000','0.039425018889161','0.039702659867254','5552.81956185371','5552.819561853710184','test','test','0.0'),('2019-09-17 15:59:59','2019-09-23 23:59:59','OAXBTC','4h','0.000007640000000','0.000007420000000','0.039486716884293','0.038349664827415','5168.418440352502','5168.418440352502330','test','test','2.9'),('2019-09-27 11:59:59','2019-09-27 15:59:59','OAXBTC','4h','0.000007500000000','0.000007390000000','0.039234038649431','0.038658606082573','5231.2051532575115','5231.205153257511483','test','test','1.5'),('2019-09-27 19:59:59','2019-09-27 23:59:59','OAXBTC','4h','0.000007580000000','0.000007560000000','0.039106164745685','0.039002982252952','5159.12463663392','5159.124636633920090','test','test','0.3'),('2019-09-28 11:59:59','2019-09-29 15:59:59','OAXBTC','4h','0.000007700000000','0.000007460000000','0.039083235302856','0.037865056540170','5075.7448445266955','5075.744844526695488','test','test','3.1'),('2019-09-30 23:59:59','2019-10-09 15:59:59','OAXBTC','4h','0.000008150000000','0.000008690000000','0.038812528911148','0.041384156593604','4762.273486030376','4762.273486030376262','test','test','2.0'),('2019-10-16 19:59:59','2019-10-18 03:59:59','OAXBTC','4h','0.000009010000000','0.000008740000000','0.039384001729471','0.038203793020597','4371.143366201012','4371.143366201012213','test','test','3.0'),('2019-10-24 15:59:59','2019-10-25 07:59:59','OAXBTC','4h','0.000008540000000','0.000008570000000','0.039121733127499','0.039259163103357','4580.999195257508','4580.999195257508291','test','test','0.0'),('2019-10-28 15:59:59','2019-10-28 19:59:59','OAXBTC','4h','0.000008040000000','0.000007930000000','0.039152273122134','0.038616607693846','4869.685711708238','4869.685711708238159','test','test','1.4'),('2019-11-01 19:59:59','2019-11-02 15:59:59','OAXBTC','4h','0.000008400000000','0.000008190000000','0.039033236360292','0.038057405451285','4646.813852415768','4646.813852415768451','test','test','2.5'),('2019-11-02 19:59:59','2019-11-04 07:59:59','OAXBTC','4h','0.000008470000000','0.000008270000000','0.038816385047180','0.037899823416786','4582.808151969279','4582.808151969278697','test','test','2.4'),('2019-11-07 23:59:59','2019-11-08 03:59:59','OAXBTC','4h','0.000008220000000','0.000008220000000','0.038612704684870','0.038612704684870','4697.409329059613','4697.409329059612901','test','test','0.0'),('2019-11-13 15:59:59','2019-11-13 23:59:59','OAXBTC','4h','0.000008220000000','0.000008170000000','0.038612704684870','0.038377834218417','4697.409329059613','4697.409329059612901','test','test','0.6'),('2019-11-17 11:59:59','2019-11-17 23:59:59','OAXBTC','4h','0.000008310000000','0.000008300000000','0.038560511247880','0.038514108707269','4640.2540611167815','4640.254061116781486','test','test','0.7'),('2019-11-18 11:59:59','2019-11-18 15:59:59','OAXBTC','4h','0.000008400000000','0.000008160000000','0.038550199572189','0.037448765298698','4589.309472879657','4589.309472879656823','test','test','2.9'),('2019-11-20 03:59:59','2019-11-20 07:59:59','OAXBTC','4h','0.000008190000000','0.000008110000000','0.038305436400302','0.037931268523376','4677.098461575364','4677.098461575364126','test','test','1.0'),('2019-11-20 15:59:59','2019-11-20 19:59:59','OAXBTC','4h','0.000008310000000','0.000008240000000','0.038222287983208','0.037900319251701','4599.553307245195','4599.553307245195356','test','test','0.8'),('2019-11-21 07:59:59','2019-11-21 11:59:59','OAXBTC','4h','0.000008560000000','0.000008217600000','0.038150739376206','0.036624709801158','4456.86207665958','4456.862076659580453','test','test','4.0'),('2019-11-26 03:59:59','2019-11-26 07:59:59','OAXBTC','4h','0.000008060000000','0.000007980000000','0.037811621692862','0.037436320236853','4691.268200106949','4691.268200106948825','test','test','1.0'),('2019-11-26 11:59:59','2019-11-27 11:59:59','OAXBTC','4h','0.000008310000000','0.000008130000000','0.037728221369304','0.036911003577911','4540.098841071534','4540.098841071533570','test','test','2.2'),('2019-11-29 19:59:59','2019-11-30 07:59:59','OAXBTC','4h','0.000008200000000','0.000008070000000','0.037546617415662','0.036951366163950','4578.855782397753','4578.855782397752591','test','test','1.6'),('2019-11-30 23:59:59','2019-12-04 15:59:59','OAXBTC','4h','0.000008440000000','0.000008330000000','0.037414339359726','0.036926711714042','4432.978597123882','4432.978597123881627','test','test','1.7'),('2019-12-06 15:59:59','2019-12-07 07:59:59','OAXBTC','4h','0.000008520000000','0.000008250000000','0.037305977660685','0.036123745974255','4378.635875667216','4378.635875667216169','test','test','3.2'),('2019-12-09 11:59:59','2019-12-10 03:59:59','OAXBTC','4h','0.000008680000000','0.000008332800000','0.037043259508145','0.035561529127819','4267.65662536229','4267.656625362289560','test','test','4.0'),('2019-12-21 19:59:59','2019-12-21 23:59:59','OAXBTC','4h','0.000007670000000','0.000007363200000','0.036713986090294','0.035245426646682','4786.699620638129','4786.699620638129090','test','test','4.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:37:31
