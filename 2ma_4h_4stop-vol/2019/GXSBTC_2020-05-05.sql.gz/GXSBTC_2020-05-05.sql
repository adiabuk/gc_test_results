-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-02 03:59:59','GXSBTC','4h','0.000144500000000','0.000143400000000','0.033333333333333','0.033079584775086','230.6805074971165','230.680507497116508','test','test','0.8'),('2019-01-02 11:59:59','2019-01-02 23:59:59','GXSBTC','4h','0.000144300000000','0.000142800000000','0.033276944764834','0.032931030578089','230.60945782975742','230.609457829757417','test','test','1.0'),('2019-01-04 15:59:59','2019-01-06 19:59:59','GXSBTC','4h','0.000148500000000','0.000144800000000','0.033200074945557','0.032372867691021','223.56952825291134','223.569528252911340','test','test','2.5'),('2019-01-12 03:59:59','2019-01-13 11:59:59','GXSBTC','4h','0.000146900000000','0.000144400000000','0.033016251111216','0.032454368008574','224.75324105660994','224.753241056609937','test','test','1.7'),('2019-01-14 15:59:59','2019-01-15 03:59:59','GXSBTC','4h','0.000147600000000','0.000143200000000','0.032891388199518','0.031910886112269','222.8413834655676','222.841383465567588','test','test','3.0'),('2019-01-16 03:59:59','2019-01-16 07:59:59','GXSBTC','4h','0.000144200000000','0.000144900000000','0.032673498846796','0.032832108064499','226.5845967184173','226.584596718417288','test','test','0.0'),('2019-01-16 11:59:59','2019-01-16 15:59:59','GXSBTC','4h','0.000144800000000','0.000146200000000','0.032708745339619','0.033024990115002','225.8891252736096','225.889125273609608','test','test','0.0'),('2019-01-17 07:59:59','2019-01-25 19:59:59','GXSBTC','4h','0.000147100000000','0.000156200000000','0.032779021956370','0.034806820051564','222.83495551577462','222.834955515774624','test','test','0.0'),('2019-01-27 15:59:59','2019-01-27 19:59:59','GXSBTC','4h','0.000156900000000','0.000154700000000','0.033229643755302','0.032763708661219','211.78867912876','211.788679128760009','test','test','1.4'),('2019-01-30 15:59:59','2019-01-31 11:59:59','GXSBTC','4h','0.000163200000000','0.000156800000000','0.033126102623284','0.031827039775312','202.97856999561276','202.978569995612759','test','test','3.9'),('2019-02-03 23:59:59','2019-02-04 19:59:59','GXSBTC','4h','0.000158400000000','0.000157000000000','0.032837421990401','0.032547192250587','207.3069570101094','207.306957010109386','test','test','0.9'),('2019-02-07 11:59:59','2019-02-09 19:59:59','GXSBTC','4h','0.000159400000000','0.000158400000000','0.032772926492665','0.032567324695346','205.6017973191022','205.601797319102189','test','test','0.6'),('2019-02-10 15:59:59','2019-02-10 23:59:59','GXSBTC','4h','0.000161800000000','0.000164200000000','0.032727237204372','0.033212684480580','202.2696984200975','202.269698420097512','test','test','0.0'),('2019-02-15 15:59:59','2019-02-15 19:59:59','GXSBTC','4h','0.000159100000000','0.000158600000000','0.032835114376862','0.032731924199688','206.38035434860117','206.380354348601173','test','test','0.3'),('2019-02-16 03:59:59','2019-02-16 11:59:59','GXSBTC','4h','0.000159500000000','0.000158400000000','0.032812183226379','0.032585892307576','205.71901709328736','205.719017093287363','test','test','0.7'),('2019-02-16 15:59:59','2019-02-16 19:59:59','GXSBTC','4h','0.000159700000000','0.000159100000000','0.032761896355534','0.032638808454386','205.14650191317605','205.146501913176053','test','test','0.4'),('2019-02-17 03:59:59','2019-02-18 15:59:59','GXSBTC','4h','0.000165700000000','0.000160400000000','0.032734543488612','0.031687512224341','197.55306873031046','197.553068730310457','test','test','3.2'),('2019-02-19 03:59:59','2019-02-19 15:59:59','GXSBTC','4h','0.000161600000000','0.000160300000000','0.032501869874330','0.032240406812222','201.1254323906559','201.125432390655902','test','test','0.8'),('2019-02-20 15:59:59','2019-02-21 11:59:59','GXSBTC','4h','0.000162300000000','0.000159000000000','0.032443766971639','0.031784097033214','199.8999813409694','199.899981340969390','test','test','2.0'),('2019-02-23 07:59:59','2019-02-24 15:59:59','GXSBTC','4h','0.000162100000000','0.000161300000000','0.032297173651989','0.032137779827673','199.24228039475219','199.242280394752186','test','test','0.5'),('2019-02-26 19:59:59','2019-03-04 07:59:59','GXSBTC','4h','0.000168900000000','0.000169000000000','0.032261752802141','0.032280853899123','191.0109698172962','191.010969817296200','test','test','2.0'),('2019-03-05 15:59:59','2019-03-07 07:59:59','GXSBTC','4h','0.000171900000000','0.000168700000000','0.032265997490360','0.031665350649353','187.70213781477344','187.702137814773437','test','test','2.0'),('2019-03-07 11:59:59','2019-03-25 15:59:59','GXSBTC','4h','0.000173900000000','0.000248400000000','0.032132520414580','0.045898321282241','184.77585057262922','184.775850572629224','test','test','0.1'),('2019-03-27 15:59:59','2019-04-02 07:59:59','GXSBTC','4h','0.000268000000000','0.000262500000000','0.035191587274060','0.034469371863585','131.31189281365837','131.311892813658375','test','test','2.2'),('2019-04-12 19:59:59','2019-04-13 07:59:59','GXSBTC','4h','0.000245400000000','0.000253200000000','0.035031094960622','0.036144552746656','142.75099820954176','142.750998209541763','test','test','1.7'),('2019-04-13 11:59:59','2019-04-18 19:59:59','GXSBTC','4h','0.000256900000000','0.000251900000000','0.035278530024185','0.034591910132706','137.32397829577525','137.323978295775248','test','test','1.9'),('2019-04-22 07:59:59','2019-04-22 11:59:59','GXSBTC','4h','0.000250000000000','0.000249900000000','0.035125947826078','0.035111897446948','140.50379130431287','140.503791304312870','test','test','0.0'),('2019-04-22 15:59:59','2019-04-22 19:59:59','GXSBTC','4h','0.000249700000000','0.000248400000000','0.035122825519605','0.034939967397156','140.66009419144928','140.660094191449275','test','test','0.5'),('2019-04-22 23:59:59','2019-04-23 03:59:59','GXSBTC','4h','0.000250100000000','0.000248500000000','0.035082190381283','0.034857754137340','140.2726524641459','140.272652464145892','test','test','0.6'),('2019-05-16 07:59:59','2019-05-16 11:59:59','GXSBTC','4h','0.000161500000000','0.000155040000000','0.035032315660407','0.033631023033991','216.91836322233232','216.918363222332317','test','test','4.0'),('2019-05-31 11:59:59','2019-05-31 15:59:59','GXSBTC','4h','0.000142700000000','0.000136992000000','0.034720917298981','0.033332080607022','243.31406656608885','243.314066566088854','test','test','4.0'),('2019-06-04 15:59:59','2019-06-18 11:59:59','GXSBTC','4h','0.000154000000000','0.000278400000000','0.034412286922990','0.062210264151691','223.45640859084412','223.456408590844120','test','test','2.3'),('2019-06-18 15:59:59','2019-06-20 11:59:59','GXSBTC','4h','0.000264000000000','0.000253440000000','0.040589615196035','0.038966030588194','153.7485424092222','153.748542409222210','test','test','4.0'),('2019-06-23 11:59:59','2019-06-23 15:59:59','GXSBTC','4h','0.000247500000000','0.000244000000000','0.040228818616514','0.039659926232038','162.54068127884622','162.540681278846222','test','test','1.4'),('2019-07-24 19:59:59','2019-07-27 03:59:59','GXSBTC','4h','0.000151100000000','0.000152000000000','0.040102398086631','0.040341260815142','265.40303167856314','265.403031678563138','test','test','0.5'),('2019-07-29 19:59:59','2019-07-29 23:59:59','GXSBTC','4h','0.000153000000000','0.000152800000000','0.040155478692967','0.040102987871146','262.45410910435726','262.454109104357258','test','test','0.1'),('2019-07-30 03:59:59','2019-07-30 15:59:59','GXSBTC','4h','0.000155700000000','0.000152700000000','0.040143814065895','0.039370330172525','257.82796445661745','257.827964456617451','test','test','1.9'),('2019-07-31 07:59:59','2019-08-05 03:59:59','GXSBTC','4h','0.000171400000000','0.000164544000000','0.039971928756258','0.038373051606008','233.20845248691694','233.208452486916940','test','test','4.0'),('2019-08-05 07:59:59','2019-08-05 11:59:59','GXSBTC','4h','0.000168500000000','0.000164900000000','0.039616622722869','0.038770214166179','235.11348796954698','235.113487969546981','test','test','2.1'),('2019-09-27 19:59:59','2019-10-05 15:59:59','GXSBTC','4h','0.000052100000000','0.000051990000000','0.039428531932493','0.039345285511906','756.7856416985242','756.785641698524159','test','test','1.9'),('2019-10-06 23:59:59','2019-10-07 03:59:59','GXSBTC','4h','0.000052510000000','0.000051690000000','0.039410032727918','0.038794602774825','750.5243330397682','750.524333039768180','test','test','1.6'),('2019-10-07 15:59:59','2019-10-07 19:59:59','GXSBTC','4h','0.000051440000000','0.000051420000000','0.039273270516120','0.039258000970818','763.477265087865','763.477265087865021','test','test','0.0'),('2019-10-08 11:59:59','2019-10-09 15:59:59','GXSBTC','4h','0.000052710000000','0.000051720000000','0.039269877283830','0.038532309867571','745.0175921804296','745.017592180429574','test','test','1.9'),('2019-10-09 19:59:59','2019-10-20 19:59:59','GXSBTC','4h','0.000052640000000','0.000056580000000','0.039105973413551','0.042032978262514','742.8946317163881','742.894631716388062','test','test','0.0'),('2019-10-27 15:59:59','2019-10-27 19:59:59','GXSBTC','4h','0.000057990000000','0.000063000000000','0.039756418935542','0.043191143178809','685.5737012509475','685.573701250947465','test','test','0.0'),('2019-10-27 23:59:59','2019-10-28 15:59:59','GXSBTC','4h','0.000062680000000','0.000060172800000','0.040519690989602','0.038898903350018','646.4532704148336','646.453270414833582','test','test','4.0'),('2019-11-02 03:59:59','2019-11-02 07:59:59','GXSBTC','4h','0.000060620000000','0.000058195200000','0.040159515958583','0.038553135320240','662.4796429987317','662.479642998731720','test','test','4.0'),('2019-11-02 11:59:59','2019-11-04 07:59:59','GXSBTC','4h','0.000058080000000','0.000056320000000','0.039802542483396','0.038596404832384','685.3054835295417','685.305483529541675','test','test','3.0'),('2019-11-06 03:59:59','2019-11-18 11:59:59','GXSBTC','4h','0.000059550000000','0.000066420000000','0.039534511894282','0.044095420319365','663.8876892406716','663.887689240671648','test','test','0.4'),('2019-11-28 19:59:59','2019-11-29 03:59:59','GXSBTC','4h','0.000063250000000','0.000062610000000','0.040548047099856','0.040137758560031','641.0758434759841','641.075843475984129','test','test','1.2'),('2019-12-03 07:59:59','2019-12-03 19:59:59','GXSBTC','4h','0.000061820000000','0.000061890000000','0.040456871868784','0.040502681979279','654.4301499317984','654.430149931798383','test','test','0.1'),('2019-12-16 15:59:59','2019-12-16 19:59:59','GXSBTC','4h','0.000059620000000','0.000058310000000','0.040467051893338','0.039577889901049','678.7496124343883','678.749612434388268','test','test','2.2'),('2019-12-18 15:59:59','2019-12-18 19:59:59','GXSBTC','4h','0.000058550000000','0.000058470000000','0.040269460339496','0.040214438019647','687.7789981126597','687.778998112659679','test','test','0.1');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:48:08
