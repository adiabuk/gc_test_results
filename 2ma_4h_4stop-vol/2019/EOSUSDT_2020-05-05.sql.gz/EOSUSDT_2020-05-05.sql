-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-04 15:59:59','EOSUSDT','4h','2.618400000000000','2.616900000000000','222.222222222222200','222.094918016091242','84.86947075398038','84.869470753980380','test','test','0.9'),('2019-01-05 03:59:59','2019-01-06 07:59:59','EOSUSDT','4h','2.713900000000000','2.643900000000000','222.193932398637571','216.462853409763738','81.87255698391155','81.872556983911551','test','test','2.9'),('2019-01-06 19:59:59','2019-01-08 03:59:59','EOSUSDT','4h','2.835900000000000','2.722464000000000','220.920359289998942','212.083544918398985','77.90132208117315','77.901322081173149','test','test','4.0'),('2019-01-08 11:59:59','2019-01-10 07:59:59','EOSUSDT','4h','2.768000000000000','2.659100000000000','218.956622762976735','210.342324996037377','79.10282614269391','79.102826142693914','test','test','3.9'),('2019-01-19 11:59:59','2019-01-19 19:59:59','EOSUSDT','4h','2.479700000000000','2.444000000000000','217.042334370323516','213.917596967806872','87.52765833379986','87.527658333799863','test','test','1.4'),('2019-01-22 19:59:59','2019-01-23 07:59:59','EOSUSDT','4h','2.461900000000000','2.419100000000000','216.347948280875386','212.586750756028124','87.87844684222567','87.878446842225671','test','test','1.7'),('2019-01-25 11:59:59','2019-01-25 15:59:59','EOSUSDT','4h','2.423800000000000','2.432600000000000','215.512126608687112','216.294578425733249','88.91497920978922','88.914979209789223','test','test','0.0'),('2019-02-02 23:59:59','2019-02-03 15:59:59','EOSUSDT','4h','2.438900000000000','2.369900000000000','215.686004790252923','209.583936509254357','88.43577218838531','88.435772188385315','test','test','2.8'),('2019-02-03 19:59:59','2019-02-03 23:59:59','EOSUSDT','4h','2.357800000000000','2.370700000000000','214.329989616697702','215.502632277676327','90.90253185880808','90.902531858808075','test','test','0.0'),('2019-02-04 03:59:59','2019-02-05 15:59:59','EOSUSDT','4h','2.386200000000000','2.377700000000000','214.590576874692943','213.826173260815267','89.9298369267844','89.929836926784404','test','test','0.4'),('2019-02-07 03:59:59','2019-02-07 07:59:59','EOSUSDT','4h','2.366300000000000','2.358000000000000','214.420709404942357','213.668610394647402','90.61433858975717','90.614338589757168','test','test','0.4'),('2019-02-08 11:59:59','2019-02-24 15:59:59','EOSUSDT','4h','2.428500000000000','3.570400000000000','214.253576291543453','314.997310599681555','88.22465566874344','88.224655668743438','test','test','0.0'),('2019-02-24 19:59:59','2019-02-25 11:59:59','EOSUSDT','4h','3.562000000000000','3.419520000000000','236.641072804462993','227.175429892284455','66.43488849086553','66.434888490865532','test','test','4.0'),('2019-02-25 15:59:59','2019-02-25 23:59:59','EOSUSDT','4h','3.563800000000000','3.546100000000000','234.537596601756690','233.372740139595209','65.81109955714594','65.811099557145937','test','test','0.5'),('2019-02-27 23:59:59','2019-02-28 15:59:59','EOSUSDT','4h','3.502100000000000','3.550100000000000','234.278739610165275','237.489778558592775','66.89664475890616','66.896644758906163','test','test','0.0'),('2019-03-01 19:59:59','2019-03-01 23:59:59','EOSUSDT','4h','3.622300000000000','3.477408000000000','234.992303820926935','225.592611668089859','64.87378290614441','64.873782906144413','test','test','4.0'),('2019-03-03 11:59:59','2019-03-03 15:59:59','EOSUSDT','4h','3.537900000000000','3.497700000000000','232.903483342518683','230.257077273842583','65.83099673323686','65.830996733236859','test','test','1.1'),('2019-03-05 15:59:59','2019-03-08 23:59:59','EOSUSDT','4h','3.627600000000000','3.589700000000000','232.315393105035099','229.888236472914457','64.0410720876158','64.041072087615802','test','test','1.0'),('2019-03-09 15:59:59','2019-03-11 07:59:59','EOSUSDT','4h','3.757400000000000','3.607104000000000','231.776024964563817','222.504983965981268','61.68521450060249','61.685214500602491','test','test','4.0'),('2019-03-12 11:59:59','2019-03-12 15:59:59','EOSUSDT','4h','3.662000000000000','3.623500000000000','229.715793631545495','227.300704048035243','62.729599571694564','62.729599571694564','test','test','1.1'),('2019-03-15 11:59:59','2019-03-20 11:59:59','EOSUSDT','4h','3.688400000000000','3.711600000000000','229.179107057432105','230.620641403959695','62.13510114343133','62.135101143431328','test','test','0.1'),('2019-03-23 07:59:59','2019-03-23 11:59:59','EOSUSDT','4h','3.684600000000000','3.658400000000000','229.499448023327176','227.867551606291073','62.28612278763697','62.286122787636970','test','test','0.7'),('2019-03-26 23:59:59','2019-04-11 11:59:59','EOSUSDT','4h','3.743900000000000','5.246600000000000','229.136804375096887','321.106108024889352','61.20270423224362','61.202704232243619','test','test','0.0'),('2019-04-11 15:59:59','2019-04-11 19:59:59','EOSUSDT','4h','5.168400000000000','5.238000000000000','249.574427408384082','252.935308947665817','48.2885278632428','48.288527863242798','test','test','0.0'),('2019-04-12 03:59:59','2019-04-13 11:59:59','EOSUSDT','4h','5.280400000000000','5.239100000000000','250.321289972668950','248.363432750513169','47.405743877863216','47.405743877863216','test','test','0.8'),('2019-04-14 23:59:59','2019-04-15 19:59:59','EOSUSDT','4h','5.542200000000000','5.320512000000000','249.886210589967646','239.890762166368944','45.08790924000715','45.087909240007150','test','test','4.0'),('2019-04-16 11:59:59','2019-04-21 07:59:59','EOSUSDT','4h','5.383300000000000','5.337300000000000','247.664999829167954','245.548716138468620','46.006167189115956','46.006167189115956','test','test','0.9'),('2019-05-03 11:59:59','2019-05-04 15:59:59','EOSUSDT','4h','5.034500000000000','4.847800000000000','247.194714564568102','238.027716211364236','49.10015186504481','49.100151865044808','test','test','3.7'),('2019-05-04 23:59:59','2019-05-05 11:59:59','EOSUSDT','4h','4.947200000000000','4.869300000000000','245.157603819411662','241.297283367937666','49.55481965948651','49.554819659486512','test','test','1.6'),('2019-05-06 19:59:59','2019-05-07 15:59:59','EOSUSDT','4h','4.933100000000000','4.852100000000000','244.299754830195212','240.288427238772840','49.522562857066596','49.522562857066596','test','test','1.6'),('2019-05-09 03:59:59','2019-05-09 07:59:59','EOSUSDT','4h','4.944800000000000','4.888100000000000','243.408348698768037','240.617284677731760','49.22511500945802','49.225115009458023','test','test','1.1'),('2019-05-11 03:59:59','2019-05-11 07:59:59','EOSUSDT','4h','4.898300000000000','4.923700000000000','242.788112249648862','244.047083331685712','49.565790631371875','49.565790631371875','test','test','0.0'),('2019-05-11 11:59:59','2019-05-22 23:59:59','EOSUSDT','4h','5.276000000000000','5.928500000000000','243.067883601212571','273.128875650073724','46.07048589863771','46.070485898637713','test','test','0.4'),('2019-05-24 07:59:59','2019-05-30 23:59:59','EOSUSDT','4h','6.224100000000000','7.300000000000000','249.748104056515075','292.919644545004132','40.12597870479508','40.125978704795081','test','test','0.0'),('2019-05-31 03:59:59','2019-06-03 07:59:59','EOSUSDT','4h','7.352700000000000','7.260200000000000','259.341779720623776','256.079153117585804','35.271638951762455','35.271638951762455','test','test','1.3'),('2019-06-15 03:59:59','2019-06-18 19:59:59','EOSUSDT','4h','6.668300000000000','6.758900000000000','258.616751586615294','262.130492374184428','38.78301090032171','38.783010900321713','test','test','0.2'),('2019-06-21 03:59:59','2019-06-21 15:59:59','EOSUSDT','4h','6.992600000000000','6.909200000000000','259.397582872741793','256.303775360287659','37.09601333877839','37.096013338778391','test','test','1.2'),('2019-06-21 19:59:59','2019-06-25 15:59:59','EOSUSDT','4h','6.974600000000000','7.079900000000000','258.710070092196418','262.615981596900383','37.093176682848686','37.093176682848686','test','test','0.0'),('2019-06-26 03:59:59','2019-06-26 23:59:59','EOSUSDT','4h','7.316600000000000','7.023936000000000','259.578050426575089','249.194928409512073','35.477961133118534','35.477961133118534','test','test','4.0'),('2019-07-24 15:59:59','2019-07-24 19:59:59','EOSUSDT','4h','4.640900000000000','4.455264000000000','257.270689978338851','246.979862379205258','55.43551681319116','55.435516813191157','test','test','4.0'),('2019-07-25 03:59:59','2019-07-27 11:59:59','EOSUSDT','4h','4.570000000000000','4.387200000000000','254.983839400753624','244.784485824723475','55.795150853556585','55.795150853556585','test','test','4.0'),('2019-08-05 03:59:59','2019-08-05 11:59:59','EOSUSDT','4h','4.357100000000000','4.422800000000000','252.717316383858048','256.527999564510139','58.00126606776481','58.001266067764810','test','test','0.6'),('2019-08-05 15:59:59','2019-08-06 11:59:59','EOSUSDT','4h','4.419000000000000','4.335800000000000','253.564134868447383','248.790082815708132','57.38043332619312','57.380433326193121','test','test','1.9'),('2019-09-07 15:59:59','2019-09-19 03:59:59','EOSUSDT','4h','3.427400000000000','3.887800000000000','252.503234412283149','286.421799249598678','73.67194795246634','73.671947952466340','test','test','0.0'),('2019-09-19 19:59:59','2019-09-20 03:59:59','EOSUSDT','4h','3.945200000000000','3.922000000000000','260.040693265019911','258.511507397700541','65.91318393618066','65.913183936180658','test','test','0.6'),('2019-10-07 15:59:59','2019-10-10 11:59:59','EOSUSDT','4h','3.127300000000000','3.110000000000000','259.700874183393353','258.264227515861364','83.04315997294579','83.043159972945787','test','test','0.6'),('2019-10-10 15:59:59','2019-10-10 19:59:59','EOSUSDT','4h','3.113800000000000','3.153900000000000','259.381619368386225','262.721976146815223','83.30066779124742','83.300667791247420','test','test','0.0'),('2019-10-11 03:59:59','2019-10-11 07:59:59','EOSUSDT','4h','3.138600000000000','3.061000000000000','260.123920874703799','253.692513157926555','82.878965422387','82.878965422386997','test','test','2.5'),('2019-10-13 23:59:59','2019-10-14 19:59:59','EOSUSDT','4h','3.102700000000000','3.158800000000000','258.694719159864405','263.372185155567593','83.37729047599329','83.377290475993291','test','test','0.0'),('2019-10-15 03:59:59','2019-10-15 07:59:59','EOSUSDT','4h','3.128000000000000','3.113000000000000','259.734156047798479','258.488627805881265','83.03521612781282','83.035216127812816','test','test','0.5'),('2019-10-15 11:59:59','2019-10-15 15:59:59','EOSUSDT','4h','3.108000000000000','3.106700000000000','259.457371994039079','259.348847353243627','83.48049291957498','83.480492919574985','test','test','0.0'),('2019-10-22 15:59:59','2019-10-22 19:59:59','EOSUSDT','4h','2.992200000000000','2.969600000000000','259.433255407195645','257.473763537600462','86.70318007058206','86.703180070582064','test','test','0.8'),('2019-10-25 15:59:59','2019-11-03 19:59:59','EOSUSDT','4h','3.056300000000000','3.225400000000000','258.997812769507789','273.327731344033793','84.74227424320512','84.742274243205117','test','test','0.0'),('2019-11-04 11:59:59','2019-11-08 15:59:59','EOSUSDT','4h','3.369100000000000','3.403000000000000','262.182239119402482','264.820325820939331','77.81966671200098','77.819666712000981','test','test','0.0'),('2019-11-10 07:59:59','2019-11-11 11:59:59','EOSUSDT','4h','3.544500000000000','3.460800000000000','262.768480608632956','256.563452585796824','74.1341460314947','74.134146031494694','test','test','2.4'),('2019-11-12 03:59:59','2019-11-12 11:59:59','EOSUSDT','4h','3.469200000000000','3.467900000000000','261.389585492447111','261.291635976379951','75.34578159012081','75.345781590120808','test','test','0.0'),('2019-11-12 15:59:59','2019-11-13 01:59:59','EOSUSDT','4h','3.463700000000000','3.441900000000000','261.367818933321075','259.722809708288196','75.45913876297632','75.459138762976323','test','test','0.6'),('2019-11-13 11:59:59','2019-11-13 15:59:59','EOSUSDT','4h','3.477800000000000','3.450400000000000','261.002261327758220','258.945943552043559','75.04809400418604','75.048094004186041','test','test','0.8'),('2019-12-08 19:59:59','2019-12-09 03:59:59','EOSUSDT','4h','2.750700000000000','2.735000000000000','260.545301822043882','259.058203542112892','94.71963566439229','94.719635664392285','test','test','0.6'),('2019-12-22 19:59:59','2019-12-23 19:59:59','EOSUSDT','4h','2.515500000000000','2.516600000000000','260.214835537614704','260.328624573230400','103.44457783248448','103.444577832484484','test','test','0.0'),('2019-12-23 23:59:59','2019-12-24 07:59:59','EOSUSDT','4h','2.513600000000000','2.487200000000000','260.240121989973773','257.506855272701614','103.53283019970313','103.532830199703128','test','test','1.1'),('2019-12-24 11:59:59','2019-12-25 15:59:59','EOSUSDT','4h','2.515000000000000','2.474800000000000','259.632729386135509','255.482735063542009','103.23368961675368','103.233689616753679','test','test','1.6'),('2019-12-26 19:59:59','2019-12-26 23:59:59','EOSUSDT','4h','2.574200000000000','2.516900000000000','258.710508425559226','252.951782556246656','100.50132407177347','100.501324071773467','test','test','2.2'),('2019-12-27 07:59:59','2019-12-27 15:59:59','EOSUSDT','4h','2.548100000000000','2.576100000000000','257.430791565711957','260.259590342777187','101.02852775232996','101.028527752329964','test','test','0.8'),('2019-12-28 03:59:59','2019-12-31 19:59:59','EOSUSDT','4h','2.620700000000000','2.574800000000000','258.059413516170878','253.539656550325077','98.46965067202308','98.469650672023079','test','test','1.8');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:16:21
