-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-07 03:59:59','EOSBTC','4h','0.000689700000000','0.000694000000000','0.033333333333333','0.033541153158378','48.330191870861725','48.330191870861725','test','test','0.1'),('2019-01-09 15:59:59','2019-01-10 11:59:59','EOSBTC','4h','0.000703400000000','0.000677800000000','0.033379515516677','0.032164679580898','47.45452874136575','47.454528741365749','test','test','3.6'),('2019-01-17 11:59:59','2019-01-17 15:59:59','EOSBTC','4h','0.000672400000000','0.000673000000000','0.033109551975392','0.033139096489350','49.24085659635997','49.240856596359968','test','test','0.0'),('2019-01-17 19:59:59','2019-01-18 11:59:59','EOSBTC','4h','0.000682700000000','0.000676900000000','0.033116117422939','0.032834773522173','48.507569097610464','48.507569097610464','test','test','0.8'),('2019-01-22 19:59:59','2019-01-26 23:59:59','EOSBTC','4h','0.000687900000000','0.000674500000000','0.033053596556102','0.032409726525790','48.05000226210463','48.050002262104627','test','test','1.9'),('2019-01-27 03:59:59','2019-01-27 11:59:59','EOSBTC','4h','0.000677300000000','0.000669500000000','0.032910514327144','0.032531506484605','48.59074904347195','48.590749043471952','test','test','1.2'),('2019-02-02 23:59:59','2019-02-06 03:59:59','EOSBTC','4h','0.000695900000000','0.000679200000000','0.032826290362135','0.032038534867024','47.170987731189676','47.170987731189676','test','test','2.4'),('2019-02-07 03:59:59','2019-02-25 11:59:59','EOSBTC','4h','0.000693000000000','0.000896200000000','0.032651233585444','0.042225159508333','47.11577717957222','47.115777179572220','test','test','0.5'),('2019-02-25 15:59:59','2019-02-25 23:59:59','EOSBTC','4h','0.000935800000000','0.000925700000000','0.034778772679419','0.034403408708419','37.164749603995396','37.164749603995396','test','test','1.1'),('2019-02-27 23:59:59','2019-03-01 23:59:59','EOSBTC','4h','0.000917600000000','0.000907400000000','0.034695358463641','0.034309686431896','37.81098350440401','37.810983504404007','test','test','1.1'),('2019-03-02 03:59:59','2019-03-02 07:59:59','EOSBTC','4h','0.000913400000000','0.000910200000000','0.034609653567698','0.034488402318063','37.89101551094567','37.891015510945671','test','test','0.4'),('2019-03-03 11:59:59','2019-03-04 03:59:59','EOSBTC','4h','0.000926000000000','0.000909000000000','0.034582708845557','0.033947821102172','37.346337846173505','37.346337846173505','test','test','1.8'),('2019-03-05 15:59:59','2019-03-08 23:59:59','EOSBTC','4h','0.000946300000000','0.000928400000000','0.034441622680360','0.033790132618035','36.39609286733594','36.396092867335938','test','test','1.9'),('2019-03-09 07:59:59','2019-03-11 07:59:59','EOSBTC','4h','0.000958500000000','0.000926900000000','0.034296847110954','0.033166142500932','35.78179145639483','35.781791456394828','test','test','3.3'),('2019-03-12 11:59:59','2019-03-12 15:59:59','EOSBTC','4h','0.000942400000000','0.000935900000000','0.034045579419838','0.033810757405588','36.126463730728396','36.126463730728396','test','test','0.7'),('2019-03-15 11:59:59','2019-03-18 03:59:59','EOSBTC','4h','0.000941600000000','0.000935700000000','0.033993396750005','0.033780396494243','36.10173826466133','36.101738264661329','test','test','0.6'),('2019-03-25 23:59:59','2019-03-26 03:59:59','EOSBTC','4h','0.000927300000000','0.000921400000000','0.033946063359836','0.033730079564060','36.607423012871536','36.607423012871536','test','test','0.6'),('2019-03-26 11:59:59','2019-04-02 07:59:59','EOSBTC','4h','0.000924700000000','0.000975800000000','0.033898066960774','0.035771313658833','36.65844810292467','36.658448102924673','test','test','0.0'),('2019-04-02 23:59:59','2019-04-03 23:59:59','EOSBTC','4h','0.001033500000000','0.001056400000000','0.034314344004788','0.035074671511038','33.202074508744616','33.202074508744616','test','test','0.0'),('2019-04-04 03:59:59','2019-04-04 15:59:59','EOSBTC','4h','0.001037800000000','0.001033200000000','0.034483305672843','0.034330460031973','33.22731323264898','33.227313232648982','test','test','0.4'),('2019-04-06 15:59:59','2019-04-08 07:59:59','EOSBTC','4h','0.001086200000000','0.001042752000000','0.034449339974872','0.033071366375877','31.715466741734485','31.715466741734485','test','test','4.0'),('2019-04-08 15:59:59','2019-04-09 03:59:59','EOSBTC','4h','0.001046600000000','0.001040600000000','0.034143123619540','0.033947386239722','32.622896636288715','32.622896636288715','test','test','0.6'),('2019-04-09 11:59:59','2019-04-10 23:59:59','EOSBTC','4h','0.001072600000000','0.001100600000000','0.034099626424025','0.034989790082306','31.791559224337746','31.791559224337746','test','test','0.5'),('2019-04-11 03:59:59','2019-04-11 11:59:59','EOSBTC','4h','0.001075000000000','0.001049000000000','0.034297440570309','0.033467921077446','31.90459587935752','31.904595879357519','test','test','2.4'),('2019-04-14 23:59:59','2019-04-15 15:59:59','EOSBTC','4h','0.001080600000000','0.001068400000000','0.034113102905229','0.033727965152644','31.568668244705414','31.568668244705414','test','test','2.0'),('2019-04-15 19:59:59','2019-04-15 23:59:59','EOSBTC','4h','0.001052600000000','0.001059900000000','0.034027516737988','0.034263504646203','32.327110714409606','32.327110714409606','test','test','0.0'),('2019-04-16 15:59:59','2019-04-16 19:59:59','EOSBTC','4h','0.001057700000000','0.001057400000000','0.034079958495369','0.034070292250168','32.22081733513158','32.220817335131578','test','test','0.0'),('2019-05-16 03:59:59','2019-05-19 03:59:59','EOSBTC','4h','0.000818900000000','0.000790200000000','0.034077810440880','0.032883484931473','41.61412924762432','41.614129247624319','test','test','3.5'),('2019-05-24 11:59:59','2019-05-25 15:59:59','EOSBTC','4h','0.000798600000000','0.000792100000000','0.033812404772122','0.033537197370395','42.33960026561789','42.339600265617889','test','test','0.8'),('2019-05-27 03:59:59','2019-05-27 07:59:59','EOSBTC','4h','0.000798400000000','0.000794200000000','0.033751247571739','0.033573698423691','42.27360667802939','42.273606678029388','test','test','0.5'),('2019-05-27 15:59:59','2019-05-30 23:59:59','EOSBTC','4h','0.000844500000000','0.000882500000000','0.033711792205506','0.035228723056671','39.91923292540648','39.919232925406483','test','test','0.0'),('2019-05-31 11:59:59','2019-06-01 23:59:59','EOSBTC','4h','0.000924500000000','0.000902400000000','0.034048887950209','0.033234955636851','36.82951644154581','36.829516441545813','test','test','2.4'),('2019-06-02 03:59:59','2019-06-02 19:59:59','EOSBTC','4h','0.000890100000000','0.000869400000000','0.033868014102796','0.033080385867847','38.04967318592991','38.049673185929912','test','test','2.3'),('2019-07-23 19:59:59','2019-07-28 23:59:59','EOSBTC','4h','0.000419500000000','0.000448200000000','0.033692985606141','0.035998083787062','80.31700978817852','80.317009788178524','test','test','0.0'),('2019-07-29 11:59:59','2019-07-29 15:59:59','EOSBTC','4h','0.000438900000000','0.000439600000000','0.034205229646346','0.034259783441635','77.93399327032479','77.933993270324791','test','test','0.0'),('2019-07-30 15:59:59','2019-07-30 19:59:59','EOSBTC','4h','0.000439000000000','0.000436600000000','0.034217352711965','0.034030287457959','77.94385583591192','77.943855835911918','test','test','0.5'),('2019-08-14 03:59:59','2019-08-14 19:59:59','EOSBTC','4h','0.000386600000000','0.000371136000000','0.034175782655520','0.032808751349299','88.40088633088347','88.400886330883466','test','test','4.0'),('2019-08-22 15:59:59','2019-08-23 15:59:59','EOSBTC','4h','0.000359600000000','0.000356600000000','0.033871997920804','0.033589417292989','94.19354260512729','94.193542605127291','test','test','0.8'),('2019-08-24 11:59:59','2019-08-24 19:59:59','EOSBTC','4h','0.000360700000000','0.000361200000000','0.033809202225734','0.033856068322526','93.73219358395833','93.732193583958335','test','test','0.2'),('2019-09-07 19:59:59','2019-09-22 19:59:59','EOSBTC','4h','0.000338900000000','0.000376700000000','0.033819616913910','0.037591766572646','99.7923190141923','99.792319014192302','test','test','0.0'),('2019-09-23 15:59:59','2019-09-23 23:59:59','EOSBTC','4h','0.000387300000000','0.000380700000000','0.034657872393629','0.034067265737812','89.48585694198009','89.485856941980089','test','test','1.7'),('2019-09-30 11:59:59','2019-09-30 15:59:59','EOSBTC','4h','0.000362600000000','0.000354200000000','0.034526626470114','0.033726781841463','95.21959864896303','95.219598648963029','test','test','2.3'),('2019-10-01 03:59:59','2019-10-01 15:59:59','EOSBTC','4h','0.000360800000000','0.000352500000000','0.034348883219303','0.033558706582052','95.20200448808943','95.202004488089429','test','test','2.3'),('2019-10-02 19:59:59','2019-10-03 03:59:59','EOSBTC','4h','0.000363700000000','0.000358000000000','0.034173288411025','0.033637715840382','93.96010011279807','93.960100112798074','test','test','1.6'),('2019-10-04 11:59:59','2019-10-06 19:59:59','EOSBTC','4h','0.000364400000000','0.000369100000000','0.034054272284215','0.034493501372403','93.45299748686911','93.452997486869108','test','test','0.0'),('2019-10-07 03:59:59','2019-10-10 07:59:59','EOSBTC','4h','0.000377100000000','0.000369600000000','0.034151878748257','0.033472644882938','90.56451537591325','90.564515375913246','test','test','2.0'),('2019-10-13 23:59:59','2019-10-15 11:59:59','EOSBTC','4h','0.000374700000000','0.000374700000000','0.034000937889297','0.034000937889297','90.74176111368324','90.741761113683239','test','test','0.0'),('2019-10-24 15:59:59','2019-10-26 03:59:59','EOSBTC','4h','0.000369700000000','0.000354912000000','0.034000937889297','0.032640900373725','91.96899618419559','91.968996184195589','test','test','4.0'),('2019-10-30 11:59:59','2019-10-30 15:59:59','EOSBTC','4h','0.000359500000000','0.000356900000000','0.033698707330281','0.033454989280048','93.73771162804202','93.737711628042021','test','test','0.7'),('2019-11-01 23:59:59','2019-11-02 15:59:59','EOSBTC','4h','0.000362000000000','0.000358800000000','0.033644547763563','0.033347137396592','92.94073967834989','92.940739678349885','test','test','0.9'),('2019-11-04 11:59:59','2019-11-15 15:59:59','EOSBTC','4h','0.000363900000000','0.000391800000000','0.033578456570902','0.036152897181862','92.27385702363956','92.273857023639565','test','test','0.0'),('2019-11-16 15:59:59','2019-11-18 19:59:59','EOSBTC','4h','0.000396000000000','0.000385700000000','0.034150554484449','0.033262295112758','86.23877395062908','86.238773950629081','test','test','2.6'),('2019-12-01 03:59:59','2019-12-02 15:59:59','EOSBTC','4h','0.000368700000000','0.000368400000000','0.033953163512962','0.033925536854286','92.08886225376244','92.088862253762443','test','test','0.1'),('2019-12-03 15:59:59','2019-12-03 19:59:59','EOSBTC','4h','0.000369200000000','0.000370400000000','0.033947024255479','0.034057361279061','91.94751965189238','91.947519651892378','test','test','0.0'),('2019-12-14 15:59:59','2019-12-14 19:59:59','EOSBTC','4h','0.000362700000000','0.000363200000000','0.033971543594052','0.034018375057512','93.66292692046443','93.662926920464429','test','test','0.0'),('2019-12-24 19:59:59','2019-12-25 15:59:59','EOSBTC','4h','0.000350900000000','0.000344300000000','0.033981950585932','0.033342791640742','96.84226442271996','96.842264422719964','test','test','1.9'),('2019-12-26 19:59:59','2020-01-01 15:59:59','EOSBTC','4h','0.000352700000000','0.000363100000000','0.033839915264779','0.034837746619340','95.94532255395266','95.945322553952664','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:47:20
