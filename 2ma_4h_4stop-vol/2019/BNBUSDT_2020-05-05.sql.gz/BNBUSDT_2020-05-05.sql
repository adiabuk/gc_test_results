-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 07:59:59','2019-01-04 03:59:59','BNBUSDT','4h','5.894100000000000','5.893500000000000','222.222222222222200','222.199600730674177','37.7024859134087','37.702485913408701','test','test','1.7'),('2019-01-04 07:59:59','2019-01-10 07:59:59','BNBUSDT','4h','5.865900000000000','6.059900000000000','222.217195224100436','229.566474256043591','37.88288160795452','37.882881607954523','test','test','0.0'),('2019-01-14 23:59:59','2019-01-15 03:59:59','BNBUSDT','4h','6.058300000000000','5.892900000000000','223.850368342310020','217.738942542363162','36.94937001177063','36.949370011770633','test','test','2.7'),('2019-01-16 23:59:59','2019-01-28 07:59:59','BNBUSDT','4h','6.091100000000000','6.739800000000000','222.492273720099632','246.187622337299899','36.527437362725884','36.527437362725884','test','test','1.6'),('2019-02-01 11:59:59','2019-02-24 15:59:59','BNBUSDT','4h','6.574400000000000','9.786300000000001','227.757906746144130','339.028231137410330','34.64314716873694','34.643147168736938','test','test','0.8'),('2019-02-24 19:59:59','2019-02-24 23:59:59','BNBUSDT','4h','9.932499999999999','9.947600000000000','252.484645499758841','252.868488253048184','25.420049886711187','25.420049886711187','test','test','0.0'),('2019-02-28 11:59:59','2019-03-21 15:59:59','BNBUSDT','4h','10.347600000000000','14.458200000000000','252.569943889378663','352.903742195428379','24.408553083746828','24.408553083746828','test','test','1.3'),('2019-03-22 23:59:59','2019-03-24 03:59:59','BNBUSDT','4h','15.150200000000000','14.700400000000000','274.866343512945321','266.705733005353181','18.142753462854966','18.142753462854966','test','test','3.0'),('2019-03-24 11:59:59','2019-03-26 07:59:59','BNBUSDT','4h','17.040199999999999','16.358591999999998','273.052874511258153','262.130759530807836','16.024041649232885','16.024041649232885','test','test','4.0'),('2019-03-26 15:59:59','2019-03-30 07:59:59','BNBUSDT','4h','15.904299999999999','16.367000000000001','270.625737848935842','278.498987781514018','17.01588487697892','17.015884876978919','test','test','0.0'),('2019-03-30 15:59:59','2019-04-08 11:59:59','BNBUSDT','4h','16.510999999999999','17.836900000000000','272.375348945064331','294.248189788517834','16.49659917297949','16.496599172979490','test','test','0.0'),('2019-04-09 23:59:59','2019-04-10 03:59:59','BNBUSDT','4h','18.298400000000001','18.105000000000000','277.235980243609561','274.305809377352716','15.150831780025005','15.150831780025005','test','test','1.1'),('2019-04-10 07:59:59','2019-04-10 23:59:59','BNBUSDT','4h','18.302099999999999','18.239999999999998','276.584831162219132','275.646364100233143','15.112191014267168','15.112191014267168','test','test','0.3'),('2019-04-12 19:59:59','2019-04-12 23:59:59','BNBUSDT','4h','18.270399999999999','18.333300000000001','276.376282926222245','277.327771026978667','15.126996832374894','15.126996832374894','test','test','0.0'),('2019-04-13 03:59:59','2019-04-13 11:59:59','BNBUSDT','4h','18.185700000000001','18.054700000000000','276.587724726390377','274.595335544826980','15.209077721857854','15.209077721857854','test','test','0.7'),('2019-04-13 19:59:59','2019-04-24 07:59:59','BNBUSDT','4h','18.371700000000001','21.444099999999999','276.144971574931844','322.326207425006658','15.030997217183595','15.030997217183595','test','test','0.0'),('2019-04-24 11:59:59','2019-04-24 15:59:59','BNBUSDT','4h','22.004500000000000','22.086600000000001','286.407468430504025','287.476070450915472','13.015858957508874','13.015858957508874','test','test','0.0'),('2019-04-25 07:59:59','2019-04-25 23:59:59','BNBUSDT','4h','22.868300000000001','22.486300000000000','286.644935546151032','281.856719308886795','12.534597479749305','12.534597479749305','test','test','1.7'),('2019-04-26 03:59:59','2019-04-26 15:59:59','BNBUSDT','4h','23.489899999999999','22.550303999999997','285.580887493425621','274.157651993688603','12.157603373936272','12.157603373936272','test','test','4.0'),('2019-04-26 23:59:59','2019-04-29 11:59:59','BNBUSDT','4h','23.055499999999999','22.133279999999999','283.042390715706290','271.720695087078070','12.276567010722227','12.276567010722227','test','test','4.0'),('2019-05-02 11:59:59','2019-05-04 15:59:59','BNBUSDT','4h','22.739300000000000','22.677000000000000','280.526458353788883','279.757885954663095','12.336635619996608','12.336635619996608','test','test','0.3'),('2019-05-05 23:59:59','2019-05-06 03:59:59','BNBUSDT','4h','22.977699999999999','22.419300000000000','280.355664487316460','273.542510731730943','12.2012065823523','12.201206582352301','test','test','2.4'),('2019-05-13 03:59:59','2019-05-29 07:59:59','BNBUSDT','4h','21.890100000000000','32.824399999999997','278.841630319408580','418.125509260185822','12.738252923440669','12.738252923440669','test','test','0.0'),('2019-05-29 19:59:59','2019-05-30 23:59:59','BNBUSDT','4h','33.473199999999999','32.134271999999996','309.793603417359122','297.401859280664723','9.25497423064897','9.254974230648971','test','test','4.0'),('2019-05-31 19:59:59','2019-06-03 03:59:59','BNBUSDT','4h','31.916899999999998','32.081499999999998','307.039882498093732','308.623330911291362','9.619978208976866','9.619978208976866','test','test','0.0'),('2019-06-06 11:59:59','2019-06-06 15:59:59','BNBUSDT','4h','31.897099999999998','30.668399999999998','307.391759923248685','295.550800857449758','9.636981415967242','9.636981415967242','test','test','3.9'),('2019-06-08 11:59:59','2019-06-08 15:59:59','BNBUSDT','4h','32.249200000000002','31.722100000000001','304.760435686404492','299.779250861655214','9.450170413108061','9.450170413108061','test','test','1.6'),('2019-06-08 23:59:59','2019-06-09 03:59:59','BNBUSDT','4h','31.733300000000000','31.401900000000001','303.653505725349135','300.482364627594393','9.568923046936472','9.568923046936472','test','test','1.0'),('2019-06-10 15:59:59','2019-06-11 11:59:59','BNBUSDT','4h','31.620000000000001','31.108499999999999','302.948807703625846','298.048165226067169','9.580923709792089','9.580923709792089','test','test','1.6'),('2019-06-11 23:59:59','2019-06-14 11:59:59','BNBUSDT','4h','31.888900000000000','31.729299999999999','301.859776041946134','300.349005201424973','9.46598271003221','9.465982710032209','test','test','0.5'),('2019-06-15 07:59:59','2019-06-15 19:59:59','BNBUSDT','4h','33.049999999999997','32.847499999999997','301.524049188496974','299.676587162455462','9.12326926440233','9.123269264402330','test','test','1.5'),('2019-06-15 23:59:59','2019-06-16 07:59:59','BNBUSDT','4h','32.674300000000002','33.170000000000002','301.113502071598873','305.681678374592082','9.215606824678687','9.215606824678687','test','test','0.1'),('2019-06-17 07:59:59','2019-06-25 23:59:59','BNBUSDT','4h','33.579999999999998','36.094099999999997','302.128652361152888','324.748713257554755','8.99727970104684','8.997279701046841','test','test','1.3'),('2019-06-26 07:59:59','2019-06-26 19:59:59','BNBUSDT','4h','37.454900000000002','36.088200000000001','307.155332560353315','295.947474763102889','8.200671542584637','8.200671542584637','test','test','3.6'),('2019-06-26 23:59:59','2019-06-27 03:59:59','BNBUSDT','4h','36.118899999999996','35.316299999999998','304.664697494297684','297.894727029833859','8.435049170774795','8.435049170774795','test','test','2.2'),('2019-07-08 07:59:59','2019-07-08 19:59:59','BNBUSDT','4h','33.718499999999999','33.413400000000003','303.160259613305698','300.417130612667506','8.990917733982998','8.990917733982998','test','test','0.9'),('2019-07-22 07:59:59','2019-07-22 15:59:59','BNBUSDT','4h','31.940000000000001','30.662400000000002','302.550675390941649','290.448648375303947','9.472469486253651','9.472469486253651','test','test','4.0'),('2019-07-22 19:59:59','2019-07-23 07:59:59','BNBUSDT','4h','30.199999999999999','29.858599999999999','299.861336054133233','296.471512871057712','9.92918331305077','9.929183313050769','test','test','1.1'),('2019-08-01 15:59:59','2019-08-01 19:59:59','BNBUSDT','4h','28.489899999999999','28.284800000000001','299.108042013449847','296.954750516569959','10.498739623987793','10.498739623987793','test','test','0.7'),('2019-08-01 23:59:59','2019-08-02 03:59:59','BNBUSDT','4h','28.708800000000000','28.239999999999998','298.629532791920951','293.753065472741696','10.402020732037597','10.402020732037597','test','test','1.6'),('2019-08-05 11:59:59','2019-08-05 15:59:59','BNBUSDT','4h','28.300000000000001','28.049800000000001','297.545873387658901','294.915273475235153','10.513988458927876','10.513988458927876','test','test','0.9'),('2019-08-07 15:59:59','2019-08-13 15:59:59','BNBUSDT','4h','28.730000000000000','29.267199999999999','296.961295629342487','302.513944707382223','10.336278998584842','10.336278998584842','test','test','0.0'),('2019-08-19 07:59:59','2019-08-19 19:59:59','BNBUSDT','4h','28.968299999999999','28.480599999999999','298.195217646684682','293.174908976645781','10.293845950459112','10.293845950459112','test','test','1.7'),('2019-08-19 23:59:59','2019-08-20 03:59:59','BNBUSDT','4h','28.793099999999999','28.420100000000001','297.079593497787130','293.231078111299610','10.317735620610048','10.317735620610048','test','test','1.3'),('2019-09-18 03:59:59','2019-09-19 03:59:59','BNBUSDT','4h','21.640699999999999','20.775071999999998','296.224367856345509','284.375393142091696','13.68829880070171','13.688298800701711','test','test','4.0'),('2019-10-09 07:59:59','2019-10-16 15:59:59','BNBUSDT','4h','16.963500000000000','17.608799999999999','293.591262364289094','304.759620403825465','17.307233905991634','17.307233905991634','test','test','2.3'),('2019-10-17 07:59:59','2019-10-20 07:59:59','BNBUSDT','4h','18.095300000000002','17.768100000000000','296.073119706408249','290.719512705256705','16.36187958787134','16.361879587871339','test','test','1.8'),('2019-10-20 15:59:59','2019-10-23 03:59:59','BNBUSDT','4h','18.205200000000001','17.800100000000000','294.883429261707931','288.321717377525488','16.197758292230127','16.197758292230127','test','test','2.2'),('2019-10-25 15:59:59','2019-11-07 11:59:59','BNBUSDT','4h','18.433199999999999','20.150900000000000','293.425271065222944','320.768140892964936','15.918303445154555','15.918303445154555','test','test','1.3'),('2019-11-08 03:59:59','2019-11-08 11:59:59','BNBUSDT','4h','20.440100000000001','20.014500000000002','299.501464360276714','293.265299995536111','14.652641834446833','14.652641834446833','test','test','2.1'),('2019-11-10 07:59:59','2019-11-10 15:59:59','BNBUSDT','4h','20.195900000000002','20.069600000000001','298.115650057001062','296.251310928653254','14.761196582326168','14.761196582326168','test','test','0.6'),('2019-11-10 19:59:59','2019-11-11 07:59:59','BNBUSDT','4h','20.541799999999999','20.082100000000001','297.701352472923759','291.039165530601167','14.492466700723588','14.492466700723588','test','test','2.2'),('2019-11-12 03:59:59','2019-11-12 15:59:59','BNBUSDT','4h','20.250000000000000','20.219999999999999','296.220866485740942','295.782020757613907','14.628190937567453','14.628190937567453','test','test','0.1'),('2019-11-12 23:59:59','2019-11-15 15:59:59','BNBUSDT','4h','20.979800000000001','20.140608000000000','296.123345212823835','284.278411404310873','14.114688663038915','14.114688663038915','test','test','4.0'),('2019-12-28 19:59:59','2019-12-31 19:59:59','BNBUSDT','4h','13.693400000000000','13.668100000000001','293.491137699820968','292.948881884332820','21.433036185302477','21.433036185302477','test','test','0.6'),('2020-01-01 03:59:59','2020-01-01 15:59:59','BNBUSDT','4h','13.817000000000000','13.822300000000000','293.370636407490281','293.483169111619986','21.232585684844054','21.232585684844054','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:37:08
