-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-03 07:59:59','ONTUSDT','4h','0.619100000000000','0.613500000000000','222.222222222222200','220.212135896193388','358.9439867908613','358.943986790861288','test','test','1.1'),('2019-01-05 23:59:59','2019-01-06 03:59:59','ONTUSDT','4h','0.616000000000000','0.608500000000000','221.775536371993581','219.075347211620311','360.02522138310644','360.025221383106441','test','test','1.2'),('2019-01-06 11:59:59','2019-01-08 03:59:59','ONTUSDT','4h','0.615300000000000','0.607000000000000','221.175494336355086','218.191979623220448','359.45960399212595','359.459603992125949','test','test','1.3'),('2019-01-08 15:59:59','2019-01-10 07:59:59','ONTUSDT','4h','0.643600000000000','0.638600000000000','220.512491066769627','218.799373516530608','342.6235100478086','342.623510047808622','test','test','2.0'),('2019-01-11 23:59:59','2019-01-12 03:59:59','ONTUSDT','4h','0.628900000000000','0.627600000000000','220.131798277827585','219.676763554085852','350.0267105705638','350.026710570563807','test','test','0.2'),('2019-01-16 11:59:59','2019-01-16 15:59:59','ONTUSDT','4h','0.619000000000000','0.604700000000000','220.030679450329444','214.947579747357395','355.4615176903545','355.461517690354526','test','test','2.3'),('2019-01-19 11:59:59','2019-01-19 23:59:59','ONTUSDT','4h','0.620200000000000','0.611100000000000','218.901101738557855','215.689234557292338','352.9524375017057','352.952437501705674','test','test','1.5'),('2019-01-22 19:59:59','2019-01-23 03:59:59','ONTUSDT','4h','0.601500000000000','0.610700000000000','218.187353476054454','221.524549904948373','362.73874227107973','362.738742271079730','test','test','0.1'),('2019-01-25 15:59:59','2019-01-26 15:59:59','ONTUSDT','4h','0.616300000000000','0.604600000000000','218.928952682475284','214.772748323583613','355.2311417856163','355.231141785616273','test','test','1.9'),('2019-02-08 15:59:59','2019-02-14 11:59:59','ONTUSDT','4h','0.551900000000000','0.564300000000000','218.005351713832738','222.903460721355003','395.0087909292132','395.008790929213205','test','test','0.0'),('2019-02-15 11:59:59','2019-03-04 03:59:59','ONTUSDT','4h','0.619900000000000','0.834400000000000','219.093820382170975','294.905442372775383','353.4341351543329','353.434135154332921','test','test','0.0'),('2019-03-05 15:59:59','2019-03-11 07:59:59','ONTUSDT','4h','0.882200000000000','0.924000000000000','235.940847491194177','247.120089641649770','267.44598446065993','267.445984460659929','test','test','0.0'),('2019-03-12 11:59:59','2019-03-13 11:59:59','ONTUSDT','4h','0.943800000000000','0.953400000000000','238.425123524628788','240.850299606252491','252.62250850246747','252.622508502467468','test','test','0.0'),('2019-03-13 15:59:59','2019-03-14 07:59:59','ONTUSDT','4h','1.026900000000000','0.985824000000000','238.964051542767379','229.405489481056662','232.70430571892823','232.704305718928225','test','test','4.0'),('2019-03-14 15:59:59','2019-03-25 15:59:59','ONTUSDT','4h','0.986100000000000','1.165700000000000','236.839926640164975','279.975968445837452','240.1784064903813','240.178406490381292','test','test','0.2'),('2019-03-25 19:59:59','2019-03-25 23:59:59','ONTUSDT','4h','1.180700000000000','1.191600000000000','246.425713708092189','248.700669479599100','208.7115386703584','208.711538670358408','test','test','0.0'),('2019-03-27 03:59:59','2019-04-08 11:59:59','ONTUSDT','4h','1.214500000000000','1.422600000000000','246.931259435093722','289.242000553614162','203.3192749568495','203.319274956849512','test','test','0.0'),('2019-04-08 15:59:59','2019-04-09 03:59:59','ONTUSDT','4h','1.482900000000000','1.424400000000000','256.333646350320521','246.221354009978114','172.85969812551116','172.859698125511159','test','test','3.9'),('2019-04-09 11:59:59','2019-04-09 15:59:59','ONTUSDT','4h','1.444000000000000','1.429100000000000','254.086470274688850','251.464663898585769','175.96015947000615','175.960159470006147','test','test','1.0'),('2019-05-03 15:59:59','2019-05-03 19:59:59','ONTUSDT','4h','1.139100000000000','1.137100000000000','253.503846635554851','253.058751654191383','222.54749068172666','222.547490681726657','test','test','0.2'),('2019-05-04 03:59:59','2019-05-04 07:59:59','ONTUSDT','4h','1.166700000000000','1.139100000000000','253.404936639696302','247.410271129063204','217.19802574757546','217.198025747575457','test','test','2.4'),('2019-05-11 07:59:59','2019-05-17 11:59:59','ONTUSDT','4h','1.106100000000000','1.292100000000000','252.072788748444509','294.460944165866636','227.89330869581818','227.893308695818178','test','test','0.0'),('2019-05-20 03:59:59','2019-05-20 15:59:59','ONTUSDT','4h','1.377400000000000','1.352100000000000','261.492378841204925','256.689302621746208','189.84490986002973','189.844909860029730','test','test','3.2'),('2019-05-20 19:59:59','2019-05-22 23:59:59','ONTUSDT','4h','1.382600000000000','1.327296000000000','260.425028570214124','250.008027427405551','188.35890971373797','188.358909713737972','test','test','4.0'),('2019-05-24 11:59:59','2019-05-25 15:59:59','ONTUSDT','4h','1.364400000000000','1.340000000000000','258.110139427367812','253.494273550771680','189.17483100803855','189.174831008038552','test','test','2.1'),('2019-05-26 19:59:59','2019-05-30 23:59:59','ONTUSDT','4h','1.362100000000000','1.441700000000000','257.084391454790875','272.108191146297600','188.7412021546075','188.741202154607493','test','test','0.0'),('2019-06-10 03:59:59','2019-06-11 07:59:59','ONTUSDT','4h','1.412500000000000','1.387100000000000','260.423013608459030','255.740008620384799','184.37027512103293','184.370275121032932','test','test','1.8'),('2019-06-11 11:59:59','2019-06-14 15:59:59','ONTUSDT','4h','1.384900000000000','1.384300000000000','259.382345833331442','259.269969916297725','187.29319505620003','187.293195056200034','test','test','0.0'),('2019-06-14 23:59:59','2019-06-18 19:59:59','ONTUSDT','4h','1.417700000000000','1.431000000000000','259.357373407323962','261.790506698088848','182.94235268909077','182.942352689090768','test','test','0.0'),('2019-06-21 07:59:59','2019-06-21 11:59:59','ONTUSDT','4h','1.435700000000000','1.437700000000000','259.898069694160597','260.260120358915344','181.02533237734946','181.025332377349457','test','test','0.0'),('2019-06-22 03:59:59','2019-06-27 07:59:59','ONTUSDT','4h','1.458800000000000','1.596900000000000','259.978525397439455','284.589873325453141','178.21396037663794','178.213960376637942','test','test','0.0'),('2019-06-27 11:59:59','2019-06-27 15:59:59','ONTUSDT','4h','1.574200000000000','1.539900000000000','265.447713825886865','259.663914699836880','168.62388122594768','168.623881225947684','test','test','2.2'),('2019-06-29 19:59:59','2019-06-29 23:59:59','ONTUSDT','4h','1.558900000000000','1.557400000000000','264.162425131209091','263.908243568763226','169.45437496389061','169.454374963890615','test','test','0.1'),('2019-06-30 07:59:59','2019-06-30 15:59:59','ONTUSDT','4h','1.594900000000000','1.531104000000000','264.105940339554479','253.541702725972300','165.5940437266001','165.594043726600091','test','test','4.0'),('2019-07-20 19:59:59','2019-07-20 23:59:59','ONTUSDT','4h','1.067900000000000','1.026000000000000','261.758331980980699','251.488012559683654','245.11502198799576','245.115021987995760','test','test','3.9'),('2019-07-24 23:59:59','2019-07-26 03:59:59','ONTUSDT','4h','1.022200000000000','1.014100000000000','259.476038776248004','257.419928510069553','253.84077360227744','253.840773602277437','test','test','1.0'),('2019-07-26 07:59:59','2019-07-27 11:59:59','ONTUSDT','4h','1.037900000000000','1.004000000000000','259.019125383763878','250.559015208882272','249.56077212040069','249.560772120400685','test','test','3.3'),('2019-08-05 11:59:59','2019-08-05 15:59:59','ONTUSDT','4h','1.005700000000000','0.987400000000000','257.139100900456867','252.460125513683124','255.68171512424863','255.681715124248626','test','test','1.8'),('2019-08-05 19:59:59','2019-08-06 03:59:59','ONTUSDT','4h','1.009600000000000','0.987400000000000','256.099328592284905','250.467984401765165','253.6641527261142','253.664152726114196','test','test','2.2'),('2019-08-06 07:59:59','2019-08-06 11:59:59','ONTUSDT','4h','0.988400000000000','0.973200000000000','254.847918772169436','250.928768260901762','257.8388494255053','257.838849425505316','test','test','1.5'),('2019-08-24 07:59:59','2019-08-24 11:59:59','ONTUSDT','4h','0.816600000000000','0.795000000000000','253.976996436332200','247.259015634195578','311.0176297285479','311.017629728547888','test','test','2.6'),('2019-08-24 15:59:59','2019-08-25 19:59:59','ONTUSDT','4h','0.816500000000000','0.791000000000000','252.484111813635110','244.598814996430349','309.227326164893','309.227326164892986','test','test','3.1'),('2019-08-26 03:59:59','2019-08-26 07:59:59','ONTUSDT','4h','0.806000000000000','0.797600000000000','250.731823632034065','248.118737628921025','311.0816670372631','311.081667037263117','test','test','1.0'),('2019-09-08 15:59:59','2019-09-09 07:59:59','ONTUSDT','4h','0.765900000000000','0.735264000000000','250.151137853564506','240.145092339421922','326.61070355603147','326.610703556031467','test','test','4.0'),('2019-09-09 11:59:59','2019-09-11 07:59:59','ONTUSDT','4h','0.755500000000000','0.742000000000000','247.927572183755075','243.497364077228696','328.16356344639985','328.163563446399849','test','test','1.8'),('2019-09-13 07:59:59','2019-09-14 03:59:59','ONTUSDT','4h','0.749600000000000','0.739300000000000','246.943081493415889','243.549920154859052','329.4331396657095','329.433139665709518','test','test','1.4'),('2019-09-14 15:59:59','2019-09-22 03:59:59','ONTUSDT','4h','0.756200000000000','0.783200000000000','246.189045640403236','254.979186122142067','325.5607585829189','325.560758582918879','test','test','0.3'),('2019-10-07 15:59:59','2019-10-08 11:59:59','ONTUSDT','4h','0.633800000000000','0.623400000000000','248.142410191900723','244.070650857732545','391.51532059309045','391.515320593090451','test','test','1.6'),('2019-10-08 19:59:59','2019-10-08 23:59:59','ONTUSDT','4h','0.629600000000000','0.636800000000000','247.237574784307839','250.064942221485410','392.6899218302221','392.689921830222090','test','test','0.0'),('2019-10-09 03:59:59','2019-10-09 07:59:59','ONTUSDT','4h','0.629300000000000','0.640700000000000','247.865878659236188','252.356059839460755','393.8755421249582','393.875542124958201','test','test','0.0'),('2019-10-09 11:59:59','2019-10-10 11:59:59','ONTUSDT','4h','0.655100000000000','0.636400000000000','248.863696699286066','241.759817706343540','379.886577162702','379.886577162701997','test','test','2.9'),('2019-10-11 03:59:59','2019-10-11 07:59:59','ONTUSDT','4h','0.655200000000000','0.629800000000000','247.285056923076610','237.698609356156368','377.4191955480412','377.419195548041216','test','test','3.9'),('2019-10-11 15:59:59','2019-10-12 19:59:59','ONTUSDT','4h','0.640800000000000','0.633400000000000','245.154735241538788','242.323672443805634','382.5760537477197','382.576053747719698','test','test','1.2'),('2019-10-13 19:59:59','2019-10-13 23:59:59','ONTUSDT','4h','0.647300000000000','0.636600000000000','244.525610175375874','240.483552352300762','377.76241337150606','377.762413371506057','test','test','1.7'),('2019-10-14 07:59:59','2019-10-14 11:59:59','ONTUSDT','4h','0.635600000000000','0.634000000000000','243.627375103581358','243.014090333024797','383.3029815978309','383.302981597830922','test','test','0.3'),('2019-10-15 03:59:59','2019-10-15 07:59:59','ONTUSDT','4h','0.640900000000000','0.633900000000000','243.491089599013293','240.831645649577979','379.9205642050449','379.920564205044911','test','test','1.1'),('2019-10-15 15:59:59','2019-10-15 19:59:59','ONTUSDT','4h','0.646100000000000','0.632600000000000','242.900102054694315','237.824801980807365','375.94815362125723','375.948153621257234','test','test','2.1'),('2019-10-25 19:59:59','2019-11-08 11:59:59','ONTUSDT','4h','0.605800000000000','0.859400000000000','241.772257593830545','342.982961664143261','399.09583623940335','399.095836239403354','test','test','0.0'),('2019-11-10 19:59:59','2019-11-11 07:59:59','ONTUSDT','4h','0.854900000000000','0.823400000000000','264.263525165011117','254.526361704141010','309.1163003450826','309.116300345082607','test','test','3.7'),('2019-11-12 11:59:59','2019-11-14 11:59:59','ONTUSDT','4h','0.895200000000000','0.873100000000000','262.099711062595532','255.629197641590878','292.78341271514245','292.783412715142447','test','test','2.5'),('2019-11-14 15:59:59','2019-11-15 03:59:59','ONTUSDT','4h','0.877400000000000','0.862900000000000','260.661819191261202','256.354095942716299','297.08436196861317','297.084361968613166','test','test','1.7'),('2019-11-29 15:59:59','2019-11-30 03:59:59','ONTUSDT','4h','0.693000000000000','0.671600000000000','259.704547358251261','251.684810975182614','374.7540365919932','374.754036591993213','test','test','3.1'),('2019-12-08 15:59:59','2019-12-09 03:59:59','ONTUSDT','4h','0.646800000000000','0.638800000000000','257.922383717569289','254.732249101396519','398.7668270215975','398.766827021597521','test','test','1.2'),('2019-12-09 07:59:59','2019-12-09 15:59:59','ONTUSDT','4h','0.639900000000000','0.616600000000000','257.213464913975372','247.847823825530867','401.9588449976174','401.958844997617405','test','test','3.6'),('2019-12-13 15:59:59','2019-12-13 19:59:59','ONTUSDT','4h','0.623900000000000','0.613700000000000','255.132211338765472','250.961112515788386','408.9312571546169','408.931257154616901','test','test','1.6'),('2019-12-29 15:59:59','2019-12-30 03:59:59','ONTUSDT','4h','0.542600000000000','0.535300000000000','254.205300489215006','250.785288153108723','468.49484056250463','468.494840562504635','test','test','1.3');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:24:11
