-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 03:59:59','2019-01-03 23:59:59','VIBEBTC','4h','0.000007600000000','0.000007380000000','0.033333333333333','0.032368421052631','4385.964912280701','4385.964912280701355','test','test','2.9'),('2019-01-04 07:59:59','2019-01-07 11:59:59','VIBEBTC','4h','0.000007740000000','0.000007820000000','0.033118908382066','0.033461222680589','4278.928731533103','4278.928731533103019','test','test','0.0'),('2019-01-08 15:59:59','2019-01-10 07:59:59','VIBEBTC','4h','0.000008530000000','0.000008240000000','0.033194978226182','0.032066426797625','3891.556650197238','3891.556650197238014','test','test','3.4'),('2019-01-11 19:59:59','2019-01-11 23:59:59','VIBEBTC','4h','0.000008140000000','0.000007960000000','0.032944189019836','0.032215693439545','4047.1976682845752','4047.197668284575229','test','test','2.2'),('2019-01-14 15:59:59','2019-01-27 11:59:59','VIBEBTC','4h','0.000009810000000','0.000011120000000','0.032782301113105','0.037159958040543','3341.722845372591','3341.722845372591109','test','test','0.0'),('2019-02-03 03:59:59','2019-02-03 07:59:59','VIBEBTC','4h','0.000010750000000','0.000010430000000','0.033755113763647','0.032750310377194','3140.010582664827','3140.010582664826870','test','test','3.0'),('2019-02-11 19:59:59','2019-02-12 03:59:59','VIBEBTC','4h','0.000010080000000','0.000010340000000','0.033531824122213','0.034396732284095','3326.569853394136','3326.569853394135862','test','test','0.0'),('2019-02-12 07:59:59','2019-02-12 11:59:59','VIBEBTC','4h','0.000010120000000','0.000010070000000','0.033724025935964','0.033557405254462','3332.4136300360124','3332.413630036012364','test','test','0.5'),('2019-02-12 15:59:59','2019-02-13 07:59:59','VIBEBTC','4h','0.000010150000000','0.000010050000000','0.033686999117853','0.033355107500928','3318.9161692465905','3318.916169246590471','test','test','1.0'),('2019-02-17 15:59:59','2019-02-18 03:59:59','VIBEBTC','4h','0.000010150000000','0.000009810000000','0.033613245425203','0.032487284494704','3311.649795586492','3311.649795586492019','test','test','3.3'),('2019-02-19 19:59:59','2019-02-19 23:59:59','VIBEBTC','4h','0.000010140000000','0.000009950000000','0.033363031885092','0.032737886317225','3290.2398308769234','3290.239830876923406','test','test','1.9'),('2019-02-20 15:59:59','2019-02-21 07:59:59','VIBEBTC','4h','0.000010230000000','0.000009820800000','0.033224110647788','0.031895146221876','3247.7136508101876','3247.713650810187573','test','test','4.0'),('2019-02-23 15:59:59','2019-02-23 19:59:59','VIBEBTC','4h','0.000009950000000','0.000009700000000','0.032928785219808','0.032101428807250','3309.4256502319377','3309.425650231937652','test','test','2.5'),('2019-02-26 19:59:59','2019-02-26 23:59:59','VIBEBTC','4h','0.000009880000000','0.000009770000000','0.032744928239239','0.032380359200138','3314.2639918258437','3314.263991825843732','test','test','1.1'),('2019-02-28 03:59:59','2019-02-28 07:59:59','VIBEBTC','4h','0.000009810000000','0.000009660000000','0.032663912897217','0.032164464687779','3329.6547295837813','3329.654729583781318','test','test','1.5'),('2019-03-02 15:59:59','2019-03-04 03:59:59','VIBEBTC','4h','0.000010190000000','0.000009782400000','0.032552924406231','0.031250807429982','3194.595133094275','3194.595133094274843','test','test','4.0'),('2019-03-05 15:59:59','2019-03-07 03:59:59','VIBEBTC','4h','0.000010110000000','0.000010030000000','0.032263565078175','0.032008264859950','3191.2527278116054','3191.252727811605382','test','test','0.8'),('2019-03-07 15:59:59','2019-03-07 19:59:59','VIBEBTC','4h','0.000009970000000','0.000009970000000','0.032206831696348','0.032206831696348','3230.3742925122933','3230.374292512293323','test','test','0.0'),('2019-03-08 15:59:59','2019-03-08 23:59:59','VIBEBTC','4h','0.000010130000000','0.000009860000000','0.032206831696348','0.031348406764659','3179.35159884971','3179.351598849710172','test','test','2.7'),('2019-03-10 11:59:59','2019-03-11 15:59:59','VIBEBTC','4h','0.000010310000000','0.000010380000000','0.032016070600417','0.032233444503621','3105.341474337213','3105.341474337213185','test','test','0.0'),('2019-03-11 19:59:59','2019-03-12 11:59:59','VIBEBTC','4h','0.000010450000000','0.000010690000000','0.032064375912240','0.032800782631756','3068.361331314811','3068.361331314811196','test','test','2.5'),('2019-03-12 15:59:59','2019-03-13 11:59:59','VIBEBTC','4h','0.000011010000000','0.000010640000000','0.032228021849910','0.031144972977570','2927.1591144332433','2927.159114433243303','test','test','3.4'),('2019-03-15 15:59:59','2019-03-16 03:59:59','VIBEBTC','4h','0.000011360000000','0.000010905600000','0.031987344322723','0.030707850549814','2815.7873523524063','2815.787352352406288','test','test','4.0'),('2019-03-17 11:59:59','2019-03-18 07:59:59','VIBEBTC','4h','0.000011300000000','0.000010848000000','0.031703012373188','0.030434891878260','2805.576316211327','2805.576316211327139','test','test','4.0'),('2019-03-18 11:59:59','2019-03-21 15:59:59','VIBEBTC','4h','0.000011110000000','0.000010665600000','0.031421207818760','0.030164359506010','2828.1915228406438','2828.191522840643756','test','test','4.0'),('2019-03-26 15:59:59','2019-03-26 19:59:59','VIBEBTC','4h','0.000010900000000','0.000011170000000','0.031141908193704','0.031913313259053','2857.0557975875236','2857.055797587523557','test','test','0.0'),('2019-03-27 11:59:59','2019-04-02 07:59:59','VIBEBTC','4h','0.000011580000000','0.000011116800000','0.031313331541559','0.030060798279897','2704.087352466264','2704.087352466263837','test','test','4.0'),('2019-05-06 11:59:59','2019-05-06 23:59:59','VIBEBTC','4h','0.000007120000000','0.000007060000000','0.031034990816746','0.030773459995257','4358.8470248238145','4358.847024823814536','test','test','0.8'),('2019-05-16 07:59:59','2019-05-16 11:59:59','VIBEBTC','4h','0.000006150000000','0.000005904000000','0.030976872856415','0.029737797942158','5036.889895351978','5036.889895351978339','test','test','4.0'),('2019-05-16 15:59:59','2019-05-16 19:59:59','VIBEBTC','4h','0.000005810000000','0.000005577600000','0.030701522875469','0.029473461960450','5284.255228135744','5284.255228135743891','test','test','4.0'),('2019-05-21 19:59:59','2019-05-21 23:59:59','VIBEBTC','4h','0.000005500000000','0.000005680000000','0.030428620449909','0.031424466210088','5532.47644543798','5532.476445437980146','test','test','0.0'),('2019-05-22 15:59:59','2019-05-24 19:59:59','VIBEBTC','4h','0.000005930000000','0.000005890000000','0.030649919507726','0.030443174688112','5168.620490341727','5168.620490341727418','test','test','2.0'),('2019-05-28 11:59:59','2019-05-28 15:59:59','VIBEBTC','4h','0.000005760000000','0.000005660000000','0.030603976214479','0.030072657182978','5313.190315013697','5313.190315013696818','test','test','1.7'),('2019-05-29 19:59:59','2019-05-30 15:59:59','VIBEBTC','4h','0.000005940000000','0.000005702400000','0.030485905318590','0.029266469105846','5132.307292691883','5132.307292691883049','test','test','4.0'),('2019-05-30 19:59:59','2019-05-30 23:59:59','VIBEBTC','4h','0.000005800000000','0.000005670000000','0.030214919493536','0.029537688539371','5209.468878195785','5209.468878195784782','test','test','2.2'),('2019-05-31 19:59:59','2019-06-04 03:59:59','VIBEBTC','4h','0.000005990000000','0.000005830000000','0.030064423725943','0.029261367332596','5019.102458421258','5019.102458421258234','test','test','3.5'),('2019-06-07 11:59:59','2019-06-09 15:59:59','VIBEBTC','4h','0.000005910000000','0.000005930000000','0.029885966749644','0.029987103692959','5056.847165760407','5056.847165760406824','test','test','0.2'),('2019-06-10 07:59:59','2019-06-12 15:59:59','VIBEBTC','4h','0.000006000000000','0.000006010000000','0.029908441625936','0.029958289028646','4984.74027098937','4984.740270989370401','test','test','0.0'),('2019-07-05 19:59:59','2019-07-06 15:59:59','VIBEBTC','4h','0.000003380000000','0.000003244800000','0.029919518826538','0.028722738073476','8851.928646904867','8851.928646904867492','test','test','4.0'),('2019-07-26 07:59:59','2019-07-27 03:59:59','VIBEBTC','4h','0.000002190000000','0.000002140000000','0.029653567548080','0.028976545457941','13540.441802776357','13540.441802776356781','test','test','2.3'),('2019-07-28 03:59:59','2019-07-28 07:59:59','VIBEBTC','4h','0.000002210000000','0.000002200000000','0.029503118194716','0.029369619922342','13349.827237428055','13349.827237428055014','test','test','0.5'),('2019-07-28 19:59:59','2019-07-28 23:59:59','VIBEBTC','4h','0.000002230000000','0.000002240000000','0.029473451911966','0.029605619857760','13216.794579357052','13216.794579357052498','test','test','0.0'),('2019-07-29 07:59:59','2019-07-31 15:59:59','VIBEBTC','4h','0.000002280000000','0.000002188800000','0.029502822566587','0.028322709663924','12939.834459029436','12939.834459029436402','test','test','4.0'),('2019-08-14 07:59:59','2019-08-14 11:59:59','VIBEBTC','4h','0.000001590000000','0.000001600000000','0.029240575254884','0.029424478243908','18390.29890244291','18390.298902442911640','test','test','0.0'),('2019-08-19 03:59:59','2019-08-19 07:59:59','VIBEBTC','4h','0.000001510000000','0.000001449600000','0.029281442585778','0.028110184882347','19391.683831641356','19391.683831641355937','test','test','4.0'),('2019-08-21 19:59:59','2019-08-21 23:59:59','VIBEBTC','4h','0.000001510000000','0.000001500000000','0.029021163096127','0.028828969963040','19219.313308693458','19219.313308693457657','test','test','0.7'),('2019-08-22 15:59:59','2019-08-23 15:59:59','VIBEBTC','4h','0.000001570000000','0.000001507200000','0.028978453510997','0.027819315370557','18457.613701271766','18457.613701271766331','test','test','4.0'),('2019-08-24 07:59:59','2019-08-28 19:59:59','VIBEBTC','4h','0.000001640000000','0.000001670000000','0.028720867257566','0.029246248975692','17512.723937539977','17512.723937539976760','test','test','1.8'),('2019-08-29 19:59:59','2019-08-29 23:59:59','VIBEBTC','4h','0.000001660000000','0.000001650000000','0.028837618750482','0.028663898155600','17372.05948824244','17372.059488242441148','test','test','0.6'),('2019-09-01 11:59:59','2019-09-02 03:59:59','VIBEBTC','4h','0.000001650000000','0.000001620000000','0.028799014173842','0.028275395734318','17453.947984146667','17453.947984146667295','test','test','1.8'),('2019-09-09 19:59:59','2019-09-12 03:59:59','VIBEBTC','4h','0.000001490000000','0.000001490000000','0.028682654520614','0.028682654520614','19250.103705110367','19250.103705110366718','test','test','0.0'),('2019-09-14 19:59:59','2019-09-24 03:59:59','VIBEBTC','4h','0.000001560000000','0.000001740000000','0.028682654520614','0.031992191580685','18386.317000393876','18386.317000393875787','test','test','0.0'),('2019-09-24 11:59:59','2019-09-24 15:59:59','VIBEBTC','4h','0.000001810000000','0.000001737600000','0.029418107200630','0.028241382912605','16253.097900900675','16253.097900900675086','test','test','4.0'),('2019-09-26 07:59:59','2019-09-26 11:59:59','VIBEBTC','4h','0.000001760000000','0.000001760000000','0.029156612914402','0.029156612914402','16566.257337728664','16566.257337728664425','test','test','0.0'),('2019-09-27 15:59:59','2019-10-09 15:59:59','VIBEBTC','4h','0.000001900000000','0.000002700000000','0.029156612914402','0.041433081509940','15345.585744422342','15345.585744422342032','test','test','0.0'),('2019-10-16 03:59:59','2019-10-16 07:59:59','VIBEBTC','4h','0.000002540000000','0.000002510000000','0.031884717046744','0.031508125900523','12553.038207379617','12553.038207379617234','test','test','1.2'),('2019-10-23 11:59:59','2019-10-23 15:59:59','VIBEBTC','4h','0.000002470000000','0.000002371200000','0.031801030125362','0.030528988920348','12874.910981927847','12874.910981927847388','test','test','4.0'),('2019-11-08 03:59:59','2019-11-08 07:59:59','VIBEBTC','4h','0.000002100000000','0.000002060000000','0.031518354302025','0.030918004696272','15008.740143821593','15008.740143821592937','test','test','1.9'),('2019-11-09 11:59:59','2019-11-09 15:59:59','VIBEBTC','4h','0.000002110000000','0.000002090000000','0.031384943278525','0.031087455664511','14874.38070072259','14874.380700722589609','test','test','0.9'),('2019-11-09 19:59:59','2019-11-09 23:59:59','VIBEBTC','4h','0.000002100000000','0.000002120000000','0.031318834919855','0.031617109538139','14913.73091421662','14913.730914216619567','test','test','0.0'),('2019-11-10 19:59:59','2019-11-11 03:59:59','VIBEBTC','4h','0.000002120000000','0.000002090000000','0.031385118168362','0.030940989137678','14804.301022812475','14804.301022812474912','test','test','1.4'),('2019-11-11 23:59:59','2019-11-12 15:59:59','VIBEBTC','4h','0.000002100000000','0.000002100000000','0.031286422828210','0.031286422828210','14898.296584862119','14898.296584862118834','test','test','0.0'),('2019-11-13 15:59:59','2019-11-13 19:59:59','VIBEBTC','4h','0.000002110000000','0.000002100000000','0.031286422828210','0.031138145942768','14827.688544175566','14827.688544175565767','test','test','0.5'),('2019-11-16 19:59:59','2019-11-16 23:59:59','VIBEBTC','4h','0.000002100000000','0.000002110000000','0.031253472409223','0.031402298468315','14882.605909153974','14882.605909153973698','test','test','0.0'),('2019-11-17 11:59:59','2019-11-17 15:59:59','VIBEBTC','4h','0.000002110000000','0.000002120000000','0.031286544866799','0.031434822330623','14827.746382369354','14827.746382369354251','test','test','0.0'),('2019-11-18 03:59:59','2019-11-18 19:59:59','VIBEBTC','4h','0.000002110000000','0.000002130000000','0.031319495414316','0.031616362669428','14843.362755599897','14843.362755599897355','test','test','0.0'),('2019-11-19 07:59:59','2019-11-20 23:59:59','VIBEBTC','4h','0.000002190000000','0.000002110000000','0.031385465915452','0.030238964877445','14331.262975092139','14331.262975092138731','test','test','3.7'),('2019-11-26 15:59:59','2019-11-27 11:59:59','VIBEBTC','4h','0.000002090000000','0.000002050000000','0.031130687907006','0.030534885267637','14895.065984213292','14895.065984213291813','test','test','1.9'),('2019-11-29 15:59:59','2019-12-03 23:59:59','VIBEBTC','4h','0.000002080000000','0.000002080000000','0.030998287320479','0.030998287320479','14903.022750230451','14903.022750230451493','test','test','1.0'),('2019-12-04 15:59:59','2019-12-04 19:59:59','VIBEBTC','4h','0.000002070000000','0.000002090000000','0.030998287320479','0.031297787681063','14975.018029217072','14975.018029217071671','test','test','0.0'),('2019-12-08 11:59:59','2019-12-08 23:59:59','VIBEBTC','4h','0.000002080000000','0.000002070000000','0.031064842956165','0.030915492749645','14935.020652002246','14935.020652002245697','test','test','0.5'),('2019-12-09 11:59:59','2019-12-09 19:59:59','VIBEBTC','4h','0.000002050000000','0.000002060000000','0.031031654021382','0.031183027943438','15137.392205552418','15137.392205552418091','test','test','0.0'),('2019-12-15 11:59:59','2019-12-15 15:59:59','VIBEBTC','4h','0.000002000000000','0.000001970000000','0.031065292670728','0.030599313280667','15532.646335364116','15532.646335364115657','test','test','1.5'),('2019-12-30 11:59:59','2019-12-30 15:59:59','VIBEBTC','4h','0.000001750000000','0.000001680000000','0.030961741695159','0.029723272027353','17692.42382580521','17692.423825805210072','test','test','4.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:45:03
