-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-05-03 03:59:59','2019-05-03 11:59:59','BCHABCUSDT','4h','272.220000000000027','289.709999999999980','222.222222222222200','236.499889795018674','0.8163331945566901','0.816333194556690','test','test','0.0'),('2019-05-03 15:59:59','2019-05-04 15:59:59','BCHABCUSDT','4h','290.589999999999975','278.966399999999965','225.395037238399226','216.379235748863238','0.7756462274627456','0.775646227462746','test','test','4.0'),('2019-05-04 23:59:59','2019-05-06 07:59:59','BCHABCUSDT','4h','290.629999999999995','279.004799999999989','223.391525796280092','214.455864764428867','0.7686457894789942','0.768645789478994','test','test','4.0'),('2019-05-07 03:59:59','2019-05-08 03:59:59','BCHABCUSDT','4h','296.720000000000027','284.851200000000006','221.405823344757636','212.549590410967312','0.746177619792254','0.746177619792254','test','test','4.0'),('2019-05-10 07:59:59','2019-05-17 11:59:59','BCHABCUSDT','4h','292.420000000000016','351.100000000000023','219.437771581693113','263.472408187991448','0.7504198467331','0.750419846733100','test','test','2.0'),('2019-05-19 03:59:59','2019-05-23 07:59:59','BCHABCUSDT','4h','390.639999999999986','378.160000000000025','229.223246383092714','221.900119937104108','0.5867889780439605','0.586788978043960','test','test','3.2'),('2019-05-23 11:59:59','2019-05-26 11:59:59','BCHABCUSDT','4h','382.800000000000011','393.449999999999989','227.595884950650799','233.927902126001982','0.5945556033193594','0.594555603319359','test','test','0.0'),('2019-05-26 15:59:59','2019-05-30 23:59:59','BCHABCUSDT','4h','403.379999999999995','420.990000000000009','229.002999878506643','239.000379093788780','0.5677103472619035','0.567710347261904','test','test','0.0'),('2019-05-31 03:59:59','2019-05-31 07:59:59','BCHABCUSDT','4h','422.670000000000016','424.290000000000020','231.224639704124883','232.110872264563710','0.5470571360733548','0.547057136073355','test','test','0.0'),('2019-05-31 15:59:59','2019-06-03 07:59:59','BCHABCUSDT','4h','427.250000000000000','425.300000000000011','231.421580273111289','230.365355389477457','0.5416537864789029','0.541653786478903','test','test','0.5'),('2019-06-13 07:59:59','2019-06-13 11:59:59','BCHABCUSDT','4h','400.759999999999991','398.670000000000016','231.186863632303783','229.981203024978925','0.5768711039831914','0.576871103983191','test','test','0.5'),('2019-06-13 15:59:59','2019-06-14 19:59:59','BCHABCUSDT','4h','417.519999999999982','404.160000000000025','230.918939052898281','223.529886969772406','0.5530727607130157','0.553072760713016','test','test','3.2'),('2019-06-14 23:59:59','2019-06-18 07:59:59','BCHABCUSDT','4h','419.769999999999982','415.870000000000005','229.276927478870249','227.146760918211839','0.546196554014985','0.546196554014985','test','test','0.9'),('2019-06-18 11:59:59','2019-06-18 15:59:59','BCHABCUSDT','4h','413.860000000000014','413.829999999999984','228.803557132057307','228.786971555500088','0.5528525519065802','0.552852551906580','test','test','0.0'),('2019-06-21 03:59:59','2019-06-26 23:59:59','BCHABCUSDT','4h','422.740000000000009','488.550000000000011','228.799871448377900','264.418264645183854','0.5412307126091165','0.541230712609116','test','test','0.0'),('2019-06-27 03:59:59','2019-06-27 07:59:59','BCHABCUSDT','4h','484.360000000000014','464.985599999999977','236.715069936557029','227.246467139094733','0.48871721433759396','0.488717214337594','test','test','4.0'),('2019-07-09 03:59:59','2019-07-09 11:59:59','BCHABCUSDT','4h','423.000000000000000','414.930000000000007','234.610935981565376','230.135025217094380','0.5546357824623295','0.554635782462329','test','test','1.9'),('2019-07-10 03:59:59','2019-07-10 07:59:59','BCHABCUSDT','4h','417.930000000000007','414.240000000000009','233.616289145016282','231.553637248897047','0.5589842536908484','0.558984253690848','test','test','0.9'),('2019-07-20 19:59:59','2019-07-20 23:59:59','BCHABCUSDT','4h','334.230000000000018','324.069999999999993','233.157922056989747','226.070334204017172','0.6975972296232825','0.697597229623283','test','test','3.0'),('2019-07-26 19:59:59','2019-07-26 23:59:59','BCHABCUSDT','4h','319.560000000000002','317.160000000000025','231.582902534106978','229.843639278124215','0.7246930233261578','0.724693023326158','test','test','0.8'),('2019-07-27 03:59:59','2019-07-27 07:59:59','BCHABCUSDT','4h','320.790000000000020','318.850000000000023','231.196399588333065','229.798223163876685','0.7207094971424703','0.720709497142470','test','test','0.6'),('2019-07-30 15:59:59','2019-08-07 19:59:59','BCHABCUSDT','4h','319.509999999999991','336.759999999999991','230.885693716231657','243.350963086846008','0.7226243113399633','0.722624311339963','test','test','0.4'),('2019-08-11 19:59:59','2019-08-12 11:59:59','BCHABCUSDT','4h','338.730000000000018','330.269999999999982','233.655753576368170','227.820050582077471','0.6897994083085884','0.689799408308588','test','test','2.5'),('2019-08-13 11:59:59','2019-08-14 19:59:59','BCHABCUSDT','4h','339.509999999999991','325.929599999999994','232.358930688747961','223.064573461198023','0.6843949535764718','0.684394953576472','test','test','4.0'),('2019-08-19 07:59:59','2019-08-19 11:59:59','BCHABCUSDT','4h','322.800000000000011','323.000000000000000','230.293517971514689','230.436202926887347','0.7134247768634284','0.713424776863428','test','test','0.0'),('2019-08-19 15:59:59','2019-08-19 19:59:59','BCHABCUSDT','4h','323.639999999999986','320.540000000000020','230.325225739375270','228.119045416201203','0.7116710719916428','0.711671071991643','test','test','1.0'),('2019-09-03 03:59:59','2019-09-03 11:59:59','BCHABCUSDT','4h','296.120000000000005','296.379999999999995','229.834963445336598','230.036763696909532','0.7761548137421876','0.776154813742188','test','test','0.5'),('2019-09-03 15:59:59','2019-09-04 11:59:59','BCHABCUSDT','4h','301.129999999999995','297.220000000000027','229.879807945686139','226.894950744252782','0.7633905886018867','0.763390588601887','test','test','1.3'),('2019-09-06 11:59:59','2019-09-06 19:59:59','BCHABCUSDT','4h','299.000000000000000','288.199999999999989','229.216506345367605','220.937114142926220','0.7666103891149418','0.766610389114942','test','test','3.6'),('2019-09-07 15:59:59','2019-09-07 19:59:59','BCHABCUSDT','4h','298.930000000000007','299.160000000000025','227.376641411491732','227.551587477542796','0.7606350697872135','0.760635069787214','test','test','0.0'),('2019-09-08 03:59:59','2019-09-08 11:59:59','BCHABCUSDT','4h','309.209999999999980','300.230000000000018','227.415518315058648','220.810973331166736','0.7354727153554499','0.735472715355450','test','test','2.9'),('2019-09-08 15:59:59','2019-09-11 07:59:59','BCHABCUSDT','4h','305.680000000000007','301.490000000000009','225.947841651971544','222.850741885805093','0.7391646219967664','0.739164621996766','test','test','2.1'),('2019-09-12 15:59:59','2019-09-12 19:59:59','BCHABCUSDT','4h','299.290000000000020','299.829999999999984','225.259597259490107','225.666026416896329','0.7526465877894019','0.752646587789402','test','test','0.0'),('2019-09-14 15:59:59','2019-09-19 03:59:59','BCHABCUSDT','4h','303.959999999999980','310.240000000000009','225.349914850024817','230.005782284089037','0.7413801646599053','0.741380164659905','test','test','1.0'),('2019-09-19 07:59:59','2019-09-20 19:59:59','BCHABCUSDT','4h','310.149999999999977','313.579999999999984','226.384552057594647','228.888176154185146','0.7299195616881982','0.729919561688198','test','test','0.0'),('2019-10-07 15:59:59','2019-10-08 11:59:59','BCHABCUSDT','4h','233.599999999999994','233.139999999999986','226.940912967948094','226.494025896179011','0.9714936342805998','0.971493634280600','test','test','0.4'),('2019-10-09 15:59:59','2019-10-10 11:59:59','BCHABCUSDT','4h','237.879999999999995','231.240000000000009','226.841604729777174','220.509722035117193','0.9535967913644576','0.953596791364458','test','test','2.8'),('2019-10-20 19:59:59','2019-10-23 03:59:59','BCHABCUSDT','4h','225.120000000000005','218.460000000000008','225.434519686519451','218.765214866369234','1.001397120142677','1.001397120142677','test','test','3.0'),('2019-10-25 15:59:59','2019-11-08 15:59:59','BCHABCUSDT','4h','235.370000000000005','279.550000000000011','223.952451948708244','265.989327196590011','0.9514910649135754','0.951491064913575','test','test','0.0'),('2019-11-10 19:59:59','2019-11-11 11:59:59','BCHABCUSDT','4h','293.430000000000007','286.120000000000005','233.293979781570869','227.482103040258522','0.7950583777445076','0.795058377744508','test','test','2.5'),('2019-11-11 15:59:59','2019-11-12 15:59:59','BCHABCUSDT','4h','286.899999999999977','286.949999999999989','232.002451616834804','232.042884250438306','0.808652672069832','0.808652672069832','test','test','0.2');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:19:09
