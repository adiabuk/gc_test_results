-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 15:59:59','2019-01-08 19:59:59','XLMETH','4h','0.000826140000000','0.000821090000000','1.297777777777778','1.289844766692759','1570.8932841622216','1570.893284162221562','test','test','0.6'),('2019-01-10 03:59:59','2019-01-10 19:59:59','XLMETH','4h','0.000845590000000','0.000838510000000','1.296014886425551','1.285163545473207','1532.6752757548593','1532.675275754859285','test','test','0.8'),('2019-01-11 15:59:59','2019-01-12 03:59:59','XLMETH','4h','0.000838510000000','0.000829270000000','1.293603477325030','1.279348553554910','1542.7406677618997','1542.740667761899658','test','test','1.1'),('2019-01-12 07:59:59','2019-01-14 15:59:59','XLMETH','4h','0.000830940000000','0.000841350000000','1.290435716487226','1.306602269798695','1552.9830270383256','1552.983027038325645','test','test','0.0'),('2019-01-15 23:59:59','2019-01-19 19:59:59','XLMETH','4h','0.000871000000000','0.000857130000000','1.294028283889775','1.273421886303608','1485.681152571498','1485.681152571497933','test','test','1.6'),('2019-01-20 03:59:59','2019-01-22 19:59:59','XLMETH','4h','0.000876270000000','0.000868190000000','1.289449084426182','1.277559200483831','1471.520289894875','1471.520289894875077','test','test','0.9'),('2019-01-23 03:59:59','2019-01-23 07:59:59','XLMETH','4h','0.000868160000000','0.000862540000000','1.286806887994549','1.278476793644971','1482.223193875033','1482.223193875033076','test','test','0.6'),('2019-01-23 19:59:59','2019-01-23 23:59:59','XLMETH','4h','0.000868370000000','0.000864010000000','1.284955755916865','1.278504119983107','1479.7330123298416','1479.733012329841586','test','test','0.5'),('2019-01-26 07:59:59','2019-01-26 15:59:59','XLMETH','4h','0.000877000000000','0.000868340000000','1.283522059042696','1.270847827536071','1463.5371254762783','1463.537125476278334','test','test','1.0'),('2019-02-25 19:59:59','2019-02-25 23:59:59','XLMETH','4h','0.000624170000000','0.000625000000000','1.280705563152335','1.282408601775493','2051.853762840789','2051.853762840788931','test','test','0.0'),('2019-02-27 23:59:59','2019-02-28 03:59:59','XLMETH','4h','0.000623190000000','0.000616450000000','1.281084016179703','1.267228681098827','2055.687697459368','2055.687697459367882','test','test','1.1'),('2019-03-01 23:59:59','2019-03-03 11:59:59','XLMETH','4h','0.000626160000000','0.000623630000000','1.278005052828398','1.272841272351114','2041.0199514954609','2041.019951495460873','test','test','0.4'),('2019-03-03 15:59:59','2019-03-05 15:59:59','XLMETH','4h','0.000660150000000','0.000633744000000','1.276857546055668','1.225783244213441','1934.1930562079344','1934.193056207934433','test','test','4.0'),('2019-03-08 07:59:59','2019-03-21 15:59:59','XLMETH','4h','0.000639150000000','0.000772780000000','1.265507701201840','1.530093157059780','1979.9854513053897','1979.985451305389688','test','test','0.3'),('2019-03-22 15:59:59','2019-03-24 03:59:59','XLMETH','4h','0.000796010000000','0.000774900000000','1.324304469170271','1.289184222761075','1663.678181392534','1663.678181392534043','test','test','2.7'),('2019-04-01 03:59:59','2019-04-02 07:59:59','XLMETH','4h','0.000771150000000','0.000775680000000','1.316499969968227','1.324233543026589','1707.1905206097742','1707.190520609774239','test','test','0.3'),('2019-04-05 07:59:59','2019-04-05 15:59:59','XLMETH','4h','0.000772350000000','0.000766430000000','1.318218541758974','1.308114503735781','1706.7631795934153','1706.763179593415316','test','test','0.8'),('2019-05-15 23:59:59','2019-05-16 07:59:59','XLMETH','4h','0.000569580000000','0.000566480000000','1.315973199976043','1.308810875245670','2310.4273323783186','2310.427332378318624','test','test','0.8'),('2019-05-16 11:59:59','2019-05-16 15:59:59','XLMETH','4h','0.000559750000000','0.000546420000000','1.314381572258182','1.283080622980466','2348.1582353875515','2348.158235387551485','test','test','2.4'),('2019-06-03 03:59:59','2019-06-03 07:59:59','XLMETH','4h','0.000514910000000','0.000510000000000','1.307425805752023','1.294958654781480','2539.134617218587','2539.134617218587209','test','test','1.0'),('2019-06-03 23:59:59','2019-06-04 03:59:59','XLMETH','4h','0.000510000000000','0.000506790000000','1.304655327758569','1.296443673636794','2558.14770148739','2558.147701487389895','test','test','0.6'),('2019-06-05 03:59:59','2019-06-05 07:59:59','XLMETH','4h','0.000510330000000','0.000504210000000','1.302830515731508','1.287206659097023','2552.9177507328745','2552.917750732874538','test','test','1.2'),('2019-06-07 07:59:59','2019-06-08 19:59:59','XLMETH','4h','0.000512970000000','0.000507300000000','1.299358547590511','1.284996376381984','2533.010795154709','2533.010795154708831','test','test','1.1'),('2019-06-08 23:59:59','2019-06-10 03:59:59','XLMETH','4h','0.000509530000000','0.000505000000000','1.296166953988616','1.284643321814714','2543.8481620093344','2543.848162009334374','test','test','0.9'),('2019-07-12 07:59:59','2019-07-13 15:59:59','XLMETH','4h','0.000359660000000','0.000353740000000','1.293606146838860','1.272313402610183','3596.747335925208','3596.747335925208063','test','test','3.0'),('2019-07-14 11:59:59','2019-07-24 23:59:59','XLMETH','4h','0.000360310000000','0.000396380000000','1.288874425899154','1.417901376420046','3577.1264352894846','3577.126435289484562','test','test','0.0'),('2019-07-26 23:59:59','2019-07-28 23:59:59','XLMETH','4h','0.000401140000000','0.000398200000000','1.317547081570464','1.307890631403896','3284.5068593769342','3284.506859376934244','test','test','0.9'),('2019-07-29 19:59:59','2019-07-29 23:59:59','XLMETH','4h','0.000396060000000','0.000395920000000','1.315401203755671','1.314936233376118','3321.2169968077333','3321.216996807733267','test','test','0.0'),('2019-07-30 19:59:59','2019-07-30 23:59:59','XLMETH','4h','0.000396500000000','0.000397000000000','1.315297877004659','1.316956512410718','3317.2708121176775','3317.270812117677451','test','test','0.0'),('2019-08-11 15:59:59','2019-08-11 23:59:59','XLMETH','4h','0.000369410000000','0.000361390000000','1.315666462650450','1.287102955895201','3561.5345081358114','3561.534508135811393','test','test','2.2'),('2019-08-14 19:59:59','2019-08-17 23:59:59','XLMETH','4h','0.000367900000000','0.000363850000000','1.309319016704839','1.294905474933557','3558.8992027856457','3558.899202785645684','test','test','1.1'),('2019-08-18 11:59:59','2019-08-18 15:59:59','XLMETH','4h','0.000368000000000','0.000365680000000','1.306116007422332','1.297881797810322','3549.2282810389447','3549.228281038944715','test','test','0.6'),('2019-08-24 11:59:59','2019-08-27 15:59:59','XLMETH','4h','0.000360460000000','0.000361960000000','1.304286183064107','1.309713773572336','3618.393672152548','3618.393672152547879','test','test','0.0'),('2019-08-28 19:59:59','2019-08-29 03:59:59','XLMETH','4h','0.000371480000000','0.000368850000000','1.305492314288158','1.296249704224150','3514.3004045659486','3514.300404565948611','test','test','0.7'),('2019-08-29 11:59:59','2019-08-29 19:59:59','XLMETH','4h','0.000370930000000','0.000362720000000','1.303438400940601','1.274588673844593','3513.974067723292','3513.974067723292137','test','test','2.2'),('2019-08-30 07:59:59','2019-08-30 23:59:59','XLMETH','4h','0.000373590000000','0.000367760000000','1.297027350474821','1.276786794107498','3471.793544995373','3471.793544995372940','test','test','1.6'),('2019-09-18 07:59:59','2019-09-20 15:59:59','XLMETH','4h','0.000327170000000','0.000336960000000','1.292529449059861','1.331206171578112','3950.6355994127234','3950.635599412723423','test','test','0.0'),('2019-09-25 23:59:59','2019-09-27 23:59:59','XLMETH','4h','0.000337630000000','0.000338480000000','1.301124276286139','1.304399920141375','3853.698653218431','3853.698653218430991','test','test','0.0'),('2019-09-30 07:59:59','2019-10-01 03:59:59','XLMETH','4h','0.000344060000000','0.000336610000000','1.301852197142858','1.273662931117414','3783.7940973750456','3783.794097375045567','test','test','2.2'),('2019-10-06 15:59:59','2019-10-09 03:59:59','XLMETH','4h','0.000340200000000','0.000341250000000','1.295587915803870','1.299586643939067','3808.3125097115526','3808.312509711552593','test','test','0.0'),('2019-10-09 11:59:59','2019-10-09 15:59:59','XLMETH','4h','0.000345860000000','0.000332025600000','1.296476522056137','1.244617461173891','3748.558729127787','3748.558729127787046','test','test','4.0'),('2019-10-13 07:59:59','2019-10-25 15:59:59','XLMETH','4h','0.000340580000000','0.000357020000000','1.284952286304526','1.346977700559169','3772.835416949105','3772.835416949104911','test','test','0.8'),('2019-10-29 07:59:59','2019-10-29 11:59:59','XLMETH','4h','0.000361470000000','0.000361040000000','1.298735711694447','1.297190752621692','3592.9280761735326','3592.928076173532645','test','test','0.1'),('2019-10-29 15:59:59','2019-10-29 19:59:59','XLMETH','4h','0.000362680000000','0.000353000000000','1.298392387456057','1.263738041171248','3579.9944509100496','3579.994450910049636','test','test','2.7'),('2019-11-01 03:59:59','2019-11-08 15:59:59','XLMETH','4h','0.000383780000000','0.000383990000000','1.290691421614988','1.291397673109436','3363.1023545129715','3363.102354512971488','test','test','3.2'),('2019-11-10 03:59:59','2019-11-13 23:59:59','XLMETH','4h','0.000407510000000','0.000404900000000','1.290848366391532','1.282580804279481','3167.6483187934823','3167.648318793482304','test','test','0.6'),('2019-11-15 19:59:59','2019-11-15 23:59:59','XLMETH','4h','0.000402510000000','0.000400170000000','1.289011130366632','1.281517438172505','3202.4325615925864','3202.432561592586353','test','test','0.6'),('2019-11-22 19:59:59','2019-11-23 03:59:59','XLMETH','4h','0.000391490000000','0.000385710000000','1.287345865434603','1.268339354151526','3288.3237513974905','3288.323751397490469','test','test','1.5'),('2019-11-25 07:59:59','2019-11-25 19:59:59','XLMETH','4h','0.000410540000000','0.000394118400000','1.283122196260587','1.231797308410163','3125.4498861513775','3125.449886151377541','test','test','4.0'),('2019-11-26 11:59:59','2019-11-26 23:59:59','XLMETH','4h','0.000391080000000','0.000390050000000','1.271716665627159','1.268367304459122','3251.806959259382','3251.806959259381983','test','test','0.3'),('2019-12-27 15:59:59','2019-12-28 19:59:59','XLMETH','4h','0.000359060000000','0.000358640000000','1.270972363145373','1.269485680160577','3539.7213923727872','3539.721392372787250','test','test','0.1');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:21:35
