-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 07:59:59','2019-01-14 15:59:59','LTCETH','4h','0.232610000000000','0.251430000000000','1.297777777777778','1.402778327099723','5.579200282781383','5.579200282781383','test','test','0.0'),('2019-01-15 23:59:59','2019-01-16 15:59:59','LTCETH','4h','0.258350000000000','0.256340000000000','1.321111233182654','1.310832798583478','5.113649054316448','5.113649054316448','test','test','0.8'),('2019-01-16 19:59:59','2019-01-17 11:59:59','LTCETH','4h','0.257580000000000','0.254460000000000','1.318827136605060','1.302852524188693','5.120068082168879','5.120068082168879','test','test','1.5'),('2019-01-17 15:59:59','2019-02-13 15:59:59','LTCETH','4h','0.255040000000000','0.338760000000000','1.315277222734756','1.747033061377141','5.15714092979437','5.157140929794370','test','test','0.0'),('2019-02-15 11:59:59','2019-02-17 11:59:59','LTCETH','4h','0.346280000000000','0.342220000000000','1.411222964655286','1.394676917420388','4.075381092339397','4.075381092339397','test','test','1.2'),('2019-02-20 11:59:59','2019-02-21 11:59:59','LTCETH','4h','0.346600000000000','0.337550000000000','1.407546065269753','1.370793924788820','4.061009997893113','4.061009997893113','test','test','2.6'),('2019-02-27 23:59:59','2019-02-28 03:59:59','LTCETH','4h','0.335070000000000','0.334360000000000','1.399378922940657','1.396413694674062','4.176377840274142','4.176377840274142','test','test','0.2'),('2019-02-28 15:59:59','2019-03-20 11:59:59','LTCETH','4h','0.336440000000000','0.432480000000000','1.398719983325858','1.797997914602208','4.157412862102776','4.157412862102776','test','test','0.0'),('2019-03-20 19:59:59','2019-03-29 07:59:59','LTCETH','4h','0.435300000000000','0.433750000000000','1.487448412498380','1.482151961684292','3.4170650413470707','3.417065041347071','test','test','1.4'),('2019-03-29 11:59:59','2019-03-29 15:59:59','LTCETH','4h','0.435560000000000','0.432430000000000','1.486271423428583','1.475590852312476','3.412323040289703','3.412323040289703','test','test','0.7'),('2019-04-02 07:59:59','2019-04-08 07:59:59','LTCETH','4h','0.448070000000000','0.493540000000000','1.483897963180559','1.634483452916136','3.311754777558326','3.311754777558326','test','test','0.4'),('2019-04-10 23:59:59','2019-04-11 07:59:59','LTCETH','4h','0.498150000000000','0.493730000000000','1.517361405344021','1.503898116351508','3.045992984731548','3.045992984731548','test','test','0.9'),('2019-04-14 23:59:59','2019-04-15 11:59:59','LTCETH','4h','0.499060000000000','0.485620000000000','1.514369563345684','1.473586637582517','3.034443881188002','3.034443881188002','test','test','2.7'),('2019-04-15 23:59:59','2019-04-16 03:59:59','LTCETH','4h','0.488330000000000','0.485630000000000','1.505306690953869','1.496983778035196','3.082560340249154','3.082560340249154','test','test','0.6'),('2019-04-26 03:59:59','2019-04-27 07:59:59','LTCETH','4h','0.471700000000000','0.464160000000000','1.503457154749720','1.479424788951940','3.1873164188037313','3.187316418803731','test','test','1.6'),('2019-04-30 23:59:59','2019-05-01 03:59:59','LTCETH','4h','0.459000000000000','0.454640000000000','1.498116629016880','1.483886152976545','3.2638706514528972','3.263870651452897','test','test','0.9'),('2019-05-02 15:59:59','2019-05-02 19:59:59','LTCETH','4h','0.456460000000000','0.454490000000000','1.494954301007917','1.488502344707287','3.2751047211320095','3.275104721132009','test','test','0.4'),('2019-05-03 07:59:59','2019-05-03 11:59:59','LTCETH','4h','0.456860000000000','0.470640000000000','1.493520532941110','1.538568716069264','3.2690989207659022','3.269098920765902','test','test','0.0'),('2019-05-03 15:59:59','2019-05-06 03:59:59','LTCETH','4h','0.468990000000000','0.450230400000000','1.503531240302922','1.443389990690805','3.2058918959954843','3.205891895995484','test','test','4.0'),('2019-05-11 11:59:59','2019-05-12 03:59:59','LTCETH','4h','0.457700000000000','0.457310000000000','1.490166518166896','1.488896767364875','3.2557712872337694','3.255771287233769','test','test','0.7'),('2019-05-12 11:59:59','2019-05-13 07:59:59','LTCETH','4h','0.460670000000000','0.452100000000000','1.489884351322002','1.462167528236432','3.2341683880478485','3.234168388047848','test','test','2.3'),('2019-05-24 11:59:59','2019-05-30 23:59:59','LTCETH','4h','0.395420000000000','0.424110000000000','1.483725057302987','1.591377861647792','3.7522762058140384','3.752276205814038','test','test','0.0'),('2019-05-31 15:59:59','2019-06-04 07:59:59','LTCETH','4h','0.422760000000000','0.418310000000000','1.507647902712944','1.491778300179420','3.5662028165222432','3.566202816522243','test','test','1.1'),('2019-06-04 11:59:59','2019-06-04 19:59:59','LTCETH','4h','0.423440000000000','0.421230000000000','1.504121324372161','1.496271078465155','3.5521474692333284','3.552147469233328','test','test','1.2'),('2019-06-04 23:59:59','2019-06-05 19:59:59','LTCETH','4h','0.423070000000000','0.420430000000000','1.502376825281715','1.493001840483115','3.551130605530325','3.551130605530325','test','test','0.6'),('2019-06-06 07:59:59','2019-06-16 11:59:59','LTCETH','4h','0.424310000000000','0.497010000000000','1.500293495326470','1.757349273201689','3.5358428868668432','3.535842886866843','test','test','0.1'),('2019-06-18 15:59:59','2019-06-20 19:59:59','LTCETH','4h','0.500760000000000','0.499320000000000','1.557417001520964','1.552938447958000','3.110106640947687','3.110106640947687','test','test','0.3'),('2019-06-20 23:59:59','2019-06-21 03:59:59','LTCETH','4h','0.499180000000000','0.491820000000000','1.556421767395860','1.533473603991810','3.117956984245884','3.117956984245884','test','test','1.5'),('2019-07-15 03:59:59','2019-07-15 07:59:59','LTCETH','4h','0.401160000000000','0.392760000000000','1.551322175528294','1.518838612175922','3.867090875282415','3.867090875282415','test','test','2.1'),('2019-07-15 15:59:59','2019-07-15 23:59:59','LTCETH','4h','0.398590000000000','0.396490000000000','1.544103605894433','1.535968385310930','3.873914563572677','3.873914563572677','test','test','1.1'),('2019-07-16 15:59:59','2019-07-16 19:59:59','LTCETH','4h','0.398680000000000','0.390380000000000','1.542295779098099','1.510187183315732','3.8685055159478767','3.868505515947877','test','test','2.1'),('2019-07-17 15:59:59','2019-07-23 19:59:59','LTCETH','4h','0.421170000000000','0.428760000000000','1.535160535590906','1.562826011444207','3.644990231001511','3.644990231001511','test','test','0.1'),('2019-07-23 23:59:59','2019-07-24 03:59:59','LTCETH','4h','0.424760000000000','0.432000000000000','1.541308419113862','1.567579897017582','3.6286571690221825','3.628657169022182','test','test','0.0'),('2019-07-24 15:59:59','2019-07-25 03:59:59','LTCETH','4h','0.448760000000000','0.430809600000000','1.547146525314689','1.485260664302101','3.4476034524349073','3.447603452434907','test','test','4.0'),('2019-07-27 11:59:59','2019-07-27 15:59:59','LTCETH','4h','0.431760000000000','0.426660000000000','1.533394111756336','1.515281479808130','3.5514964604325','3.551496460432500','test','test','1.2'),('2019-07-27 23:59:59','2019-07-28 03:59:59','LTCETH','4h','0.428250000000000','0.426110000000000','1.529369082434513','1.521726701030170','3.571206263711646','3.571206263711646','test','test','0.5'),('2019-07-29 11:59:59','2019-07-29 15:59:59','LTCETH','4h','0.426630000000000','0.426500000000000','1.527670775455770','1.527205273262279','3.5807861037802535','3.580786103780254','test','test','0.0'),('2019-07-29 19:59:59','2019-08-02 19:59:59','LTCETH','4h','0.430430000000000','0.430160000000000','1.527567330523883','1.526609118551573','3.5489332307782524','3.548933230778252','test','test','0.5'),('2019-08-26 19:59:59','2019-08-26 23:59:59','LTCETH','4h','0.393910000000000','0.390000000000000','1.527354394530036','1.512193683498043','3.877419701277033','3.877419701277033','test','test','1.0'),('2019-09-01 19:59:59','2019-09-02 03:59:59','LTCETH','4h','0.389520000000000','0.385320000000000','1.523985347634038','1.507552973275692','3.9124700853204915','3.912470085320491','test','test','1.1'),('2019-09-03 23:59:59','2019-09-04 03:59:59','LTCETH','4h','0.386390000000000','0.379910000000000','1.520333708887739','1.494836769439015','3.934712877889538','3.934712877889538','test','test','1.7'),('2019-09-06 23:59:59','2019-09-07 03:59:59','LTCETH','4h','0.384260000000000','0.382010000000000','1.514667722343578','1.505798721210821','3.9417782812251545','3.941778281225155','test','test','0.6'),('2019-09-07 15:59:59','2019-09-08 11:59:59','LTCETH','4h','0.396130000000000','0.385720000000000','1.512696833202965','1.472944292285481','3.8186878883269766','3.818687888326977','test','test','2.6'),('2019-09-09 11:59:59','2019-09-09 15:59:59','LTCETH','4h','0.385590000000000','0.383420000000000','1.503862935221302','1.495399586666022','3.9001606245527687','3.900160624552769','test','test','0.6'),('2019-09-10 03:59:59','2019-09-11 23:59:59','LTCETH','4h','0.393820000000000','0.391000000000000','1.501982191097906','1.491227049716320','3.8138799225481343','3.813879922548134','test','test','0.9'),('2019-10-20 03:59:59','2019-10-20 11:59:59','LTCETH','4h','0.313190000000000','0.310500000000000','1.499592159679776','1.486712109520005','4.788122735974252','4.788122735974252','test','test','0.9'),('2019-10-20 15:59:59','2019-10-21 11:59:59','LTCETH','4h','0.312500000000000','0.311750000000000','1.496729926310938','1.493137774487792','4.789535764195002','4.789535764195002','test','test','0.7'),('2019-10-21 15:59:59','2019-10-22 23:59:59','LTCETH','4h','0.314380000000000','0.311540000000000','1.495931670350239','1.482417941920330','4.758355080953748','4.758355080953748','test','test','0.9'),('2019-10-23 03:59:59','2019-10-23 15:59:59','LTCETH','4h','0.315060000000000','0.305550000000000','1.492928619588037','1.447864977195216','4.738553353608954','4.738553353608954','test','test','3.0'),('2019-10-25 19:59:59','2019-10-26 03:59:59','LTCETH','4h','0.314080000000000','0.314510000000000','1.482914476834077','1.484944702334072','4.7214546511528175','4.721454651152817','test','test','0.1'),('2019-10-27 15:59:59','2019-10-29 19:59:59','LTCETH','4h','0.326630000000000','0.313564800000000','1.483365638056298','1.424031012534046','4.541424970322071','4.541424970322071','test','test','4.0'),('2019-10-30 03:59:59','2019-10-30 07:59:59','LTCETH','4h','0.315060000000000','0.316810000000000','1.470180165718020','1.478346277855411','4.666349792795086','4.666349792795086','test','test','0.0'),('2019-10-31 03:59:59','2019-11-01 23:59:59','LTCETH','4h','0.318440000000000','0.318490000000000','1.471994857304106','1.472225983239495','4.622518707775739','4.622518707775739','test','test','0.0'),('2019-11-02 19:59:59','2019-11-03 03:59:59','LTCETH','4h','0.319080000000000','0.317290000000000','1.472046218623082','1.463788218336836','4.613407981142918','4.613407981142918','test','test','0.6'),('2019-11-03 23:59:59','2019-11-08 15:59:59','LTCETH','4h','0.321250000000000','0.328600000000000','1.470211107448361','1.503848622280254','4.576532630189449','4.576532630189449','test','test','0.0'),('2019-11-08 23:59:59','2019-11-11 11:59:59','LTCETH','4h','0.329020000000000','0.331400000000000','1.477686110744337','1.488375105162827','4.491174125415893','4.491174125415893','test','test','0.0'),('2019-11-12 15:59:59','2019-11-12 23:59:59','LTCETH','4h','0.330240000000000','0.328210000000000','1.480061442837335','1.470963439176483','4.481775202390185','4.481775202390185','test','test','0.6'),('2019-11-25 07:59:59','2019-11-25 11:59:59','LTCETH','4h','0.320120000000000','0.317430000000000','1.478039664246034','1.465619550860985','4.617142522322985','4.617142522322985','test','test','0.8'),('2019-11-26 15:59:59','2019-11-26 19:59:59','LTCETH','4h','0.320020000000000','0.320920000000000','1.475279639049356','1.479428603723890','4.609960749482395','4.609960749482395','test','test','0.0'),('2019-12-01 15:59:59','2019-12-01 19:59:59','LTCETH','4h','0.315680000000000','0.315390000000000','1.476201631199253','1.474845515914636','4.676259602126371','4.676259602126371','test','test','0.1'),('2019-12-14 07:59:59','2019-12-14 11:59:59','LTCETH','4h','0.306730000000000','0.305800000000000','1.475900272247116','1.471425368412506','4.8117245533437085','4.811724553343709','test','test','0.3'),('2019-12-18 15:59:59','2019-12-29 23:59:59','LTCETH','4h','0.309940000000000','0.321130000000000','1.474905849172758','1.528155498950919','4.758681838977732','4.758681838977732','test','test','0.8'),('2019-12-30 07:59:59','2019-12-30 19:59:59','LTCETH','4h','0.323710000000000','0.320720000000000','1.486739104679016','1.473006597425640','4.592811790426666','4.592811790426666','test','test','0.9'),('2019-12-31 15:59:59','2019-12-31 19:59:59','LTCETH','4h','0.320660000000000','0.320510000000000','1.483687436400488','1.482993389386641','4.6269800923111335','4.626980092311133','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:54:00
