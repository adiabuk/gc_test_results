-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-06 19:59:59','BNBBTC','4h','0.001584200000000','0.001570800000000','0.033333333333333','0.033051382401212','21.04111433741531','21.041114337415308','test','test','3.2'),('2019-01-07 19:59:59','2019-01-13 19:59:59','BNBBTC','4h','0.001555200000000','0.001596000000000','0.033270677570640','0.034143519420487','21.39318259428998','21.393182594289978','test','test','0.0'),('2019-01-14 15:59:59','2019-01-15 11:59:59','BNBBTC','4h','0.001627500000000','0.001624100000000','0.033464642426161','0.033394731652429','20.561992274139065','20.561992274139065','test','test','0.3'),('2019-01-16 07:59:59','2019-01-28 15:59:59','BNBBTC','4h','0.001643700000000','0.001800900000000','0.033449106698665','0.036648108689923','20.349885440570258','20.349885440570258','test','test','0.0'),('2019-02-01 11:59:59','2019-02-14 15:59:59','BNBBTC','4h','0.001899200000000','0.002378400000000','0.034159996030056','0.042779135719190','17.986518549945238','17.986518549945238','test','test','0.9'),('2019-02-16 15:59:59','2019-02-18 19:59:59','BNBBTC','4h','0.002514300000000','0.002485900000000','0.036075360405419','0.035667875127006','14.348073183557693','14.348073183557693','test','test','2.5'),('2019-02-19 15:59:59','2019-02-23 19:59:59','BNBBTC','4h','0.002630500000000','0.002635100000000','0.035984808121327','0.036047735366093','13.679835818790089','13.679835818790089','test','test','0.6'),('2019-02-24 03:59:59','2019-02-24 07:59:59','BNBBTC','4h','0.002612600000000','0.002597700000000','0.035998791953498','0.035793486127843','13.778914473512039','13.778914473512039','test','test','0.6'),('2019-02-24 11:59:59','2019-02-24 15:59:59','BNBBTC','4h','0.002630000000000','0.002591100000000','0.035953168436685','0.035421389633572','13.670406249690242','13.670406249690242','test','test','1.5'),('2019-02-24 19:59:59','2019-02-25 15:59:59','BNBBTC','4h','0.002628400000000','0.002585600000000','0.035834995369327','0.035251470106122','13.633767831885136','13.633767831885136','test','test','1.6'),('2019-02-27 15:59:59','2019-02-27 23:59:59','BNBBTC','4h','0.002584600000000','0.002582400000000','0.035705323088615','0.035674930876747','13.814641758343521','13.814641758343521','test','test','0.3'),('2019-02-28 11:59:59','2019-03-19 15:59:59','BNBBTC','4h','0.002699300000000','0.003857300000000','0.035698569263755','0.051013259445442','13.225121054997633','13.225121054997633','test','test','1.1'),('2019-03-22 23:59:59','2019-03-23 15:59:59','BNBBTC','4h','0.003800000000000','0.003779400000000','0.039101833748574','0.038889860649832','10.289956249624852','10.289956249624852','test','test','0.7'),('2019-03-23 19:59:59','2019-03-23 23:59:59','BNBBTC','4h','0.003773800000000','0.003780800000000','0.039054728615521','0.039127171007886','10.348913195060858','10.348913195060858','test','test','0.0'),('2019-03-24 11:59:59','2019-03-26 15:59:59','BNBBTC','4h','0.004268000000000','0.004097280000000','0.039070826924935','0.037507993847938','9.154364321681141','9.154364321681141','test','test','4.0'),('2019-03-27 23:59:59','2019-03-30 03:59:59','BNBBTC','4h','0.004111900000000','0.003947424000000','0.038723530685602','0.037174589458178','9.417430065323195','9.417430065323195','test','test','4.0'),('2019-03-30 11:59:59','2019-04-02 07:59:59','BNBBTC','4h','0.004026000000000','0.004032700000000','0.038379321523953','0.038443191731159','9.53286674713181','9.532866747131809','test','test','0.0'),('2019-04-13 23:59:59','2019-04-14 03:59:59','BNBBTC','4h','0.003687700000000','0.003674800000000','0.038393514903332','0.038259209959260','10.411235974545592','10.411235974545592','test','test','0.3'),('2019-04-14 07:59:59','2019-04-16 07:59:59','BNBBTC','4h','0.003783100000000','0.003771400000000','0.038363669360205','0.038245021972741','10.14080234733543','10.140802347335431','test','test','0.9'),('2019-04-16 11:59:59','2019-04-17 19:59:59','BNBBTC','4h','0.003825700000000','0.003738000000000','0.038337303274102','0.037458462409126','10.020990478631768','10.020990478631768','test','test','2.3'),('2019-04-17 23:59:59','2019-04-18 03:59:59','BNBBTC','4h','0.003744400000000','0.003718400000000','0.038142005304107','0.037877158562865','10.186413124694715','10.186413124694715','test','test','0.7'),('2019-04-18 07:59:59','2019-04-23 19:59:59','BNBBTC','4h','0.003929900000000','0.004150000000000','0.038083150472720','0.040216054978953','9.690615657579018','9.690615657579018','test','test','0.0'),('2019-04-25 03:59:59','2019-04-25 11:59:59','BNBBTC','4h','0.004271200000000','0.004203400000000','0.038557129251883','0.037945082669359','9.027235730446401','9.027235730446401','test','test','1.6'),('2019-04-25 19:59:59','2019-04-25 23:59:59','BNBBTC','4h','0.004185000000000','0.004305500000000','0.038421118900211','0.039527390065677','9.180673572332298','9.180673572332298','test','test','0.0'),('2019-04-26 03:59:59','2019-04-29 11:59:59','BNBBTC','4h','0.004394300000000','0.004218528000000','0.038666956936981','0.037120278659502','8.79934390846799','8.799343908467989','test','test','4.0'),('2019-05-02 15:59:59','2019-05-03 03:59:59','BNBBTC','4h','0.004283300000000','0.004191900000000','0.038323250653097','0.037505482784936','8.947132036769936','8.947132036769936','test','test','2.1'),('2019-05-17 11:59:59','2019-05-26 19:59:59','BNBBTC','4h','0.003506400000000','0.003871200000000','0.038141524460172','0.042109704965269','10.877687788093771','10.877687788093771','test','test','2.3'),('2019-05-27 03:59:59','2019-05-27 07:59:59','BNBBTC','4h','0.003947800000000','0.003914600000000','0.039023342350194','0.038695165906092','9.8848326536789','9.884832653678901','test','test','0.8'),('2019-05-30 03:59:59','2019-05-30 11:59:59','BNBBTC','4h','0.003989700000000','0.003877300000000','0.038950414251504','0.037853081980439','9.762742625135779','9.762742625135779','test','test','2.8'),('2019-06-01 07:59:59','2019-06-01 15:59:59','BNBBTC','4h','0.003899300000000','0.003873900000000','0.038706562635712','0.038454428485750','9.92654133708922','9.926541337089221','test','test','0.9'),('2019-06-04 15:59:59','2019-06-04 19:59:59','BNBBTC','4h','0.003876400000000','0.003825000000000','0.038650532824609','0.038138037368210','9.970728723715132','9.970728723715132','test','test','1.3'),('2019-06-05 15:59:59','2019-06-14 07:59:59','BNBBTC','4h','0.003900600000000','0.004064800000000','0.038536644945410','0.040158886933831','9.879671062249281','9.879671062249281','test','test','0.5'),('2019-06-19 15:59:59','2019-06-19 19:59:59','BNBBTC','4h','0.003874900000000','0.003878100000000','0.038897143165059','0.038929265505798','10.038231480827546','10.038231480827546','test','test','0.0'),('2019-06-20 11:59:59','2019-06-20 15:59:59','BNBBTC','4h','0.003921300000000','0.003859400000000','0.038904281463001','0.038290154764569','9.921271380154709','9.921271380154709','test','test','1.6'),('2019-07-02 07:59:59','2019-07-02 11:59:59','BNBBTC','4h','0.003251400000000','0.003121344000000','0.038767808863349','0.037217096508815','11.923420330734178','11.923420330734178','test','test','4.0'),('2019-07-17 15:59:59','2019-07-18 15:59:59','BNBBTC','4h','0.002813600000000','0.002781700000000','0.038423206117897','0.037987571956978','13.656243288988167','13.656243288988167','test','test','1.1'),('2019-07-19 11:59:59','2019-07-19 15:59:59','BNBBTC','4h','0.002784300000000','0.002788500000000','0.038326398526582','0.038384212294427','13.765182820307357','13.765182820307357','test','test','0.0'),('2019-07-22 11:59:59','2019-07-27 07:59:59','BNBBTC','4h','0.002940800000000','0.002879000000000','0.038339246030547','0.037533558664970','13.037012387971753','13.037012387971753','test','test','2.1'),('2019-07-27 11:59:59','2019-07-28 23:59:59','BNBBTC','4h','0.002908400000000','0.002905500000000','0.038160204393752','0.038122154403124','13.120686423377954','13.120686423377954','test','test','0.3'),('2019-08-08 11:59:59','2019-08-08 15:59:59','BNBBTC','4h','0.002644900000000','0.002629300000000','0.038151748840280','0.037926724347139','14.424646996211408','14.424646996211408','test','test','0.6'),('2019-08-08 19:59:59','2019-08-08 23:59:59','BNBBTC','4h','0.002641700000000','0.002595600000000','0.038101743397359','0.037436834296924','14.423190898799762','14.423190898799762','test','test','1.7'),('2019-08-09 03:59:59','2019-08-09 07:59:59','BNBBTC','4h','0.002638800000000','0.002589600000000','0.037953985819485','0.037246339881059','14.383047528984722','14.383047528984722','test','test','1.9'),('2019-08-10 23:59:59','2019-08-16 19:59:59','BNBBTC','4h','0.002623000000000','0.002659600000000','0.037796731166501','0.038324127415336','14.409733574724106','14.409733574724106','test','test','1.1'),('2019-08-17 19:59:59','2019-08-18 11:59:59','BNBBTC','4h','0.002687400000000','0.002663700000000','0.037913930332909','0.037579569929214','14.10803391118148','14.108033911181479','test','test','0.9'),('2019-08-18 23:59:59','2019-08-19 19:59:59','BNBBTC','4h','0.002706300000000','0.002665700000000','0.037839628020977','0.037271956699375','13.982052256208432','13.982052256208432','test','test','1.5'),('2019-08-21 19:59:59','2019-08-21 23:59:59','BNBBTC','4h','0.002670600000000','0.002656200000000','0.037713478838399','0.037510125998111','14.121725019995006','14.121725019995006','test','test','0.5'),('2019-08-22 03:59:59','2019-08-22 07:59:59','BNBBTC','4h','0.002673100000000','0.002664800000000','0.037668289318335','0.037551328934757','14.091612479269262','14.091612479269262','test','test','0.3'),('2019-08-22 19:59:59','2019-08-22 23:59:59','BNBBTC','4h','0.002662400000000','0.002670000000000','0.037642298121984','0.037749750595589','14.138483369134613','14.138483369134613','test','test','0.0'),('2019-08-23 03:59:59','2019-08-23 07:59:59','BNBBTC','4h','0.002661800000000','0.002647900000000','0.037666176449452','0.037469482538321','14.150641088530987','14.150641088530987','test','test','0.5'),('2019-09-18 03:59:59','2019-09-19 07:59:59','BNBBTC','4h','0.002120800000000','0.002094900000000','0.037622466691423','0.037163007106687','17.7397523064045','17.739752306404501','test','test','1.2'),('2019-09-19 15:59:59','2019-09-19 23:59:59','BNBBTC','4h','0.002117400000000','0.002101200000000','0.037520364561481','0.037233300281753','17.720017267158465','17.720017267158465','test','test','0.8'),('2019-09-21 03:59:59','2019-09-21 15:59:59','BNBBTC','4h','0.002110700000000','0.002091000000000','0.037456572499320','0.037106975456521','17.746042781693063','17.746042781693063','test','test','0.9'),('2019-09-21 23:59:59','2019-09-22 03:59:59','BNBBTC','4h','0.002100000000000','0.002065600000000','0.037378884267586','0.036766582544346','17.79946869885069','17.799468698850688','test','test','1.6'),('2019-10-06 03:59:59','2019-10-06 07:59:59','BNBBTC','4h','0.001929600000000','0.001917100000000','0.037242817217978','0.037001557259839','19.300796651107767','19.300796651107767','test','test','0.6'),('2019-10-07 11:59:59','2019-10-07 15:59:59','BNBBTC','4h','0.001945000000000','0.001932500000000','0.037189203893947','0.036950198727533','19.12041331308312','19.120413313083120','test','test','0.6'),('2019-10-08 03:59:59','2019-10-21 07:59:59','BNBBTC','4h','0.001944600000000','0.002195700000000','0.037136091634744','0.041931356784124','19.09703364946187','19.097033649461871','test','test','0.4'),('2019-10-22 03:59:59','2019-10-23 15:59:59','BNBBTC','4h','0.002236500000000','0.002218400000000','0.038201706112384','0.037892539610871','17.081022183046525','17.081022183046525','test','test','0.8'),('2019-10-24 03:59:59','2019-10-25 15:59:59','BNBBTC','4h','0.002235100000000','0.002231500000000','0.038133002445381','0.038071582907641','17.060982705642104','17.060982705642104','test','test','0.6'),('2019-10-28 23:59:59','2019-10-29 03:59:59','BNBBTC','4h','0.002165000000000','0.002187200000000','0.038119353659216','0.038510231096276','17.60709175945322','17.607091759453219','test','test','0.0'),('2019-10-29 07:59:59','2019-10-30 03:59:59','BNBBTC','4h','0.002203600000000','0.002189900000000','0.038206215311896','0.037968683477728','17.338090085267844','17.338090085267844','test','test','0.6'),('2019-10-30 23:59:59','2019-10-31 07:59:59','BNBBTC','4h','0.002189600000000','0.002175700000000','0.038153430459859','0.037911225178807','17.42484036347227','17.424840363472271','test','test','0.6'),('2019-11-01 03:59:59','2019-11-01 07:59:59','BNBBTC','4h','0.002179900000000','0.002169400000000','0.038099607064070','0.037916091364188','17.477685703045807','17.477685703045807','test','test','0.5'),('2019-11-02 03:59:59','2019-11-02 07:59:59','BNBBTC','4h','0.002173300000000','0.002180900000000','0.038058825797429','0.038191916984131','17.51199825032398','17.511998250323980','test','test','0.0'),('2019-11-02 23:59:59','2019-11-03 03:59:59','BNBBTC','4h','0.002173100000000','0.002183100000000','0.038088401616696','0.038263673815935','17.527219923931813','17.527219923931813','test','test','0.0'),('2019-11-03 07:59:59','2019-11-03 15:59:59','BNBBTC','4h','0.002198900000000','0.002173300000000','0.038127350994305','0.037683465330812','17.339283730185493','17.339283730185493','test','test','1.2'),('2019-11-03 23:59:59','2019-11-04 23:59:59','BNBBTC','4h','0.002193300000000','0.002195500000000','0.038028709735751','0.038066854613980','17.338581012971726','17.338581012971726','test','test','0.0'),('2019-11-05 03:59:59','2019-11-07 11:59:59','BNBBTC','4h','0.002201100000000','0.002190400000000','0.038037186375357','0.037852279785826','17.280989675779075','17.280989675779075','test','test','0.5'),('2019-11-08 03:59:59','2019-11-18 07:59:59','BNBBTC','4h','0.002210700000000','0.002326700000000','0.037996096022128','0.039989829743830','17.187359669845847','17.187359669845847','test','test','0.4'),('2019-12-29 15:59:59','2020-01-01 15:59:59','BNBBTC','4h','0.001910400000000','0.001910800000000','0.038439147960284','0.038447196358098','20.12099453532465','20.120994535324652','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:37:36
