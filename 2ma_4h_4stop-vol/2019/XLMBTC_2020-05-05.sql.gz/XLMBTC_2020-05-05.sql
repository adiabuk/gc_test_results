-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 11:59:59','2019-01-08 03:59:59','XLMBTC','4h','0.000030480000000','0.000030050000000','0.033333333333333','0.032863079615048','1093.6132983377079','1093.613298337707874','test','test','1.4'),('2019-01-08 11:59:59','2019-01-09 19:59:59','XLMBTC','4h','0.000030530000000','0.000030460000000','0.033228832507048','0.033152644551742','1088.3993615148306','1088.399361514830616','test','test','0.5'),('2019-01-09 23:59:59','2019-01-10 07:59:59','XLMBTC','4h','0.000030870000000','0.000030400000000','0.033211901850313','0.032706246072223','1075.8633576389086','1075.863357638908610','test','test','1.5'),('2019-01-13 03:59:59','2019-01-13 19:59:59','XLMBTC','4h','0.000030740000000','0.000029510400000','0.033099533899626','0.031775552543641','1076.7577716208993','1076.757771620899348','test','test','4.0'),('2019-01-17 15:59:59','2019-01-17 19:59:59','XLMBTC','4h','0.000029880000000','0.000029570000000','0.032805315820519','0.032464966158392','1097.902135894199','1097.902135894199091','test','test','1.0'),('2019-02-19 11:59:59','2019-02-20 03:59:59','XLMBTC','4h','0.000022370000000','0.000022480000000','0.032729682562268','0.032890624228868','1463.1060600030496','1463.106060003049606','test','test','0.0'),('2019-02-20 11:59:59','2019-02-24 15:59:59','XLMBTC','4h','0.000022780000000','0.000021910000000','0.032765447377068','0.031514089202439','1438.3427294586577','1438.342729458657686','test','test','3.8'),('2019-02-25 19:59:59','2019-02-25 23:59:59','XLMBTC','4h','0.000022620000000','0.000022470000000','0.032487367782706','0.032271934309346','1436.2231557341388','1436.223155734138800','test','test','0.7'),('2019-03-01 19:59:59','2019-03-01 23:59:59','XLMBTC','4h','0.000022290000000','0.000022170000000','0.032439493677515','0.032264853065523','1455.3384332667165','1455.338433266716493','test','test','0.5'),('2019-03-03 15:59:59','2019-03-04 07:59:59','XLMBTC','4h','0.000022850000000','0.000022260000000','0.032400684652628','0.031564080541247','1417.9730701368928','1417.973070136892829','test','test','2.6'),('2019-03-08 07:59:59','2019-03-21 15:59:59','XLMBTC','4h','0.000022390000000','0.000026230000000','0.032214772627877','0.037739771595767','1438.8018145545627','1438.801814554562725','test','test','0.3'),('2019-03-22 15:59:59','2019-03-23 11:59:59','XLMBTC','4h','0.000027200000000','0.000026620000000','0.033442550176297','0.032729436974008','1229.5055211873773','1229.505521187377326','test','test','2.1'),('2019-03-27 15:59:59','2019-03-28 07:59:59','XLMBTC','4h','0.000026410000000','0.000026340000000','0.033284080575788','0.033195860748438','1260.2832478526316','1260.283247852631575','test','test','0.3'),('2019-04-01 03:59:59','2019-04-02 07:59:59','XLMBTC','4h','0.000026650000000','0.000025584000000','0.033264476169710','0.031933897122922','1248.1979801016967','1248.197980101696658','test','test','4.0'),('2019-04-07 23:59:59','2019-04-08 03:59:59','XLMBTC','4h','0.000025560000000','0.000025130000000','0.032968791937091','0.032414152636115','1289.8588394792905','1289.858839479290509','test','test','1.7'),('2019-05-15 19:59:59','2019-05-15 23:59:59','XLMBTC','4h','0.000015500000000','0.000017320000000','0.032845538759096','0.036702240729519','2119.0670167158705','2119.067016715870523','test','test','0.0'),('2019-05-16 03:59:59','2019-05-16 23:59:59','XLMBTC','4h','0.000018420000000','0.000017683200000','0.033702583641412','0.032354480295756','1829.673379012607','1829.673379012607029','test','test','4.0'),('2019-05-17 03:59:59','2019-05-22 11:59:59','XLMBTC','4h','0.000017310000000','0.000016617600000','0.033403005120155','0.032066884915349','1929.6941143937227','1929.694114393722657','test','test','4.0'),('2019-05-30 07:59:59','2019-05-30 11:59:59','XLMBTC','4h','0.000016190000000','0.000016280000000','0.033106089519087','0.033290125841306','2044.848024650237','2044.848024650236994','test','test','0.0'),('2019-06-03 03:59:59','2019-06-03 07:59:59','XLMBTC','4h','0.000015980000000','0.000015770000000','0.033146986479580','0.032711387783666','2074.2795043542205','2074.279504354220535','test','test','1.3'),('2019-06-06 19:59:59','2019-06-06 23:59:59','XLMBTC','4h','0.000015860000000','0.000016030000000','0.033050186769377','0.033404444761230','2083.870540313829','2083.870540313829224','test','test','0.0'),('2019-06-07 15:59:59','2019-06-08 15:59:59','XLMBTC','4h','0.000016240000000','0.000015840000000','0.033128910767567','0.032312927743735','2039.957559579242','2039.957559579241888','test','test','2.5'),('2019-07-18 11:59:59','2019-07-18 15:59:59','XLMBTC','4h','0.000009100000000','0.000008736000000','0.032947581206715','0.031629677958446','3620.613319419268','3620.613319419268009','test','test','4.0'),('2019-07-19 23:59:59','2019-07-21 15:59:59','XLMBTC','4h','0.000008890000000','0.000008610000000','0.032654713818211','0.031626218894803','3673.1961550293718','3673.196155029371766','test','test','3.1'),('2019-07-24 15:59:59','2019-07-25 07:59:59','XLMBTC','4h','0.000008720000000','0.000008560000000','0.032426159390787','0.031831183989121','3718.5962604113665','3718.596260411366529','test','test','1.8'),('2019-07-25 19:59:59','2019-07-30 07:59:59','XLMBTC','4h','0.000008700000000','0.000008740000000','0.032293942634861','0.032442420532033','3711.947429294406','3711.947429294405993','test','test','0.5'),('2019-07-30 11:59:59','2019-07-30 15:59:59','XLMBTC','4h','0.000008780000000','0.000008670000000','0.032326937723122','0.031921930530691','3681.883567553732','3681.883567553732064','test','test','1.3'),('2019-08-14 11:59:59','2019-08-14 15:59:59','XLMBTC','4h','0.000007000000000','0.000007010000000','0.032236936124804','0.032282988890697','4605.276589257683','4605.276589257682645','test','test','0.0'),('2019-08-22 19:59:59','2019-08-23 03:59:59','XLMBTC','4h','0.000006780000000','0.000006700000000','0.032247170072780','0.031866672490800','4756.2197747463115','4756.219774746311487','test','test','1.2'),('2019-08-24 11:59:59','2019-08-26 03:59:59','XLMBTC','4h','0.000006790000000','0.000006790000000','0.032162615054562','0.032162615054562','4736.762158256585','4736.762158256585280','test','test','0.0'),('2019-09-17 15:59:59','2019-09-23 03:59:59','XLMBTC','4h','0.000006060000000','0.000006570000000','0.032162615054562','0.034869369786877','5307.362220224788','5307.362220224787961','test','test','0.0'),('2019-09-25 23:59:59','2019-10-01 19:59:59','XLMBTC','4h','0.000006800000000','0.000007070000000','0.032764116106188','0.034065044245698','4818.252368557025','4818.252368557024965','test','test','0.0'),('2019-10-04 11:59:59','2019-10-09 15:59:59','XLMBTC','4h','0.000007240000000','0.000007360000000','0.033053211248301','0.033601054528660','4565.3606696548495','4565.360669654849517','test','test','0.6'),('2019-10-13 15:59:59','2019-10-20 19:59:59','XLMBTC','4h','0.000007390000000','0.000007690000000','0.033174954199492','0.034521704708267','4489.168362583491','4489.168362583491216','test','test','0.0'),('2019-10-21 23:59:59','2019-10-23 15:59:59','XLMBTC','4h','0.000007790000000','0.000007830000000','0.033474232090331','0.033646115181937','4297.077290158008','4297.077290158007600','test','test','0.9'),('2019-10-23 19:59:59','2019-10-25 15:59:59','XLMBTC','4h','0.000007870000000','0.000007590000000','0.033512428332910','0.032320118303277','4258.250105833545','4258.250105833544694','test','test','3.6'),('2019-11-01 03:59:59','2019-11-04 23:59:59','XLMBTC','4h','0.000007610000000','0.000008450000000','0.033247470548547','0.036917362172828','4368.918600334706','4368.918600334705843','test','test','2.2'),('2019-11-05 03:59:59','2019-11-06 15:59:59','XLMBTC','4h','0.000008860000000','0.000008505600000','0.034063002020610','0.032700481939786','3844.5826208362932','3844.582620836293245','test','test','4.0'),('2019-11-08 15:59:59','2019-11-15 11:59:59','XLMBTC','4h','0.000008000000000','0.000008470000000','0.033760219780426','0.035743632692526','4220.027472553305','4220.027472553305415','test','test','0.0'),('2019-11-15 15:59:59','2019-11-16 15:59:59','XLMBTC','4h','0.000008480000000','0.000008420000000','0.034200978205338','0.033958990151998','4033.1342223275415','4033.134222327541465','test','test','0.7'),('2019-11-17 07:59:59','2019-11-17 19:59:59','XLMBTC','4h','0.000008510000000','0.000008420000000','0.034147203082373','0.033786069324745','4012.597306976863','4012.597306976862910','test','test','1.1'),('2019-11-23 11:59:59','2019-11-24 15:59:59','XLMBTC','4h','0.000008360000000','0.000008080000000','0.034066951136234','0.032925952772819','4074.994155051861','4074.994155051861071','test','test','3.3'),('2019-11-25 07:59:59','2019-11-25 15:59:59','XLMBTC','4h','0.000008330000000','0.000008140000000','0.033813395944364','0.033042142015261','4059.2312058059483','4059.231205805948321','test','test','2.3');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:27:48
