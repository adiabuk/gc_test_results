-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 07:59:59','2019-01-10 11:59:59','WABIETH','4h','0.000883470000000','0.000889250000000','1.297777777777778','1.306268338357713','1468.9551176358877','1468.955117635887746','test','test','0.0'),('2019-01-10 15:59:59','2019-01-10 19:59:59','WABIETH','4h','0.000901060000000','0.000893170000000','1.299664569017763','1.288284246453727','1442.372948547004','1442.372948547003944','test','test','0.9'),('2019-01-11 11:59:59','2019-01-12 03:59:59','WABIETH','4h','0.000895560000000','0.000894070000000','1.297135608447977','1.294977481626114','1448.4072629951957','1448.407262995195651','test','test','0.2'),('2019-01-12 15:59:59','2019-01-14 15:59:59','WABIETH','4h','0.000903010000000','0.000882180000000','1.296656024709786','1.266745674885637','1435.9265398055234','1435.926539805523362','test','test','2.3'),('2019-01-14 23:59:59','2019-01-15 15:59:59','WABIETH','4h','0.000910970000000','0.000898390000000','1.290009280304419','1.272194954095839','1416.0831644339762','1416.083164433976208','test','test','1.4'),('2019-01-15 23:59:59','2019-01-26 15:59:59','WABIETH','4h','0.000930000000000','0.001090140000000','1.286050541146957','1.507500147232198','1382.85004424404','1382.850044244039964','test','test','0.7'),('2019-01-27 23:59:59','2019-01-28 03:59:59','WABIETH','4h','0.001104680000000','0.001060492800000','1.335261564721455','1.281851102132597','1208.731546440105','1208.731546440104921','test','test','4.0'),('2019-01-30 11:59:59','2019-01-30 15:59:59','WABIETH','4h','0.001124740000000','0.001090000000000','1.323392573035042','1.282516763525967','1176.620883968777','1176.620883968776980','test','test','3.1'),('2019-02-02 07:59:59','2019-02-02 15:59:59','WABIETH','4h','0.001106880000000','0.001080970000000','1.314309059810803','1.283543531714083','1187.3997721621165','1187.399772162116506','test','test','2.3'),('2019-02-06 03:59:59','2019-02-06 19:59:59','WABIETH','4h','0.001097280000000','0.001066450000000','1.307472275789310','1.270736556316993','1191.5575566758805','1191.557556675880505','test','test','2.8'),('2019-02-07 07:59:59','2019-02-08 15:59:59','WABIETH','4h','0.001097950000000','0.001156610000000','1.299308782573239','1.368726746219804','1183.3952207051682','1183.395220705168185','test','test','1.7'),('2019-02-08 19:59:59','2019-02-08 23:59:59','WABIETH','4h','0.001124600000000','0.001128740000000','1.314734996716921','1.319574942374407','1169.0689993926026','1169.068999392602564','test','test','0.0'),('2019-02-09 03:59:59','2019-02-09 19:59:59','WABIETH','4h','0.001159900000000','0.001113504000000','1.315810540196362','1.263178118588508','1134.4172257921907','1134.417225792190720','test','test','4.0'),('2019-02-09 23:59:59','2019-02-12 11:59:59','WABIETH','4h','0.001108850000000','0.001112500000000','1.304114446505728','1.308407198212222','1176.0963579435704','1176.096357943570410','test','test','0.0'),('2019-02-24 23:59:59','2019-02-25 03:59:59','WABIETH','4h','0.001020000000000','0.000980460000000','1.305068391329393','1.254477798983154','1279.4788150288166','1279.478815028816598','test','test','3.9'),('2019-02-26 11:59:59','2019-03-11 23:59:59','WABIETH','4h','0.001052200000000','0.001437200000000','1.293826037474673','1.767237009179433','1229.6388875448329','1229.638887544832869','test','test','0.0'),('2019-03-12 11:59:59','2019-03-21 15:59:59','WABIETH','4h','0.001504020000000','0.001668870000000','1.399028475631287','1.552370747813717','930.1927338940218','930.192733894021785','test','test','0.0'),('2019-03-24 11:59:59','2019-03-24 15:59:59','WABIETH','4h','0.001643980000000','0.001636520000000','1.433104536116271','1.426601440069222','871.7286926338954','871.728692633895434','test','test','0.5'),('2019-03-25 11:59:59','2019-03-25 15:59:59','WABIETH','4h','0.001647430000000','0.001593230000000','1.431659403661371','1.384558197735507','869.0259395915887','869.025939591588667','test','test','3.3'),('2019-03-27 15:59:59','2019-04-02 19:59:59','WABIETH','4h','0.001723340000000','0.002100820000000','1.421192469011179','1.732490142831981','824.673290825478','824.673290825478034','test','test','0.8'),('2019-04-03 15:59:59','2019-04-03 19:59:59','WABIETH','4h','0.002088000000000','0.002004480000000','1.490369729860247','1.430754940665837','713.7786062549073','713.778606254907345','test','test','4.0'),('2019-04-12 15:59:59','2019-04-17 23:59:59','WABIETH','4h','0.001964150000000','0.002297230000000','1.477121998928155','1.727611928619365','752.0413404924041','752.041340492404061','test','test','0.0'),('2019-04-24 15:59:59','2019-04-24 19:59:59','WABIETH','4h','0.002275950000000','0.002274400000000','1.532786427748424','1.531742547626712','673.4710462657018','673.471046265701830','test','test','0.1'),('2019-04-24 23:59:59','2019-04-25 23:59:59','WABIETH','4h','0.002228580000000','0.002188160000000','1.532554454388044','1.504758346083041','687.6820461406114','687.682046140611419','test','test','1.8'),('2019-04-28 11:59:59','2019-04-29 15:59:59','WABIETH','4h','0.002182100000000','0.002188890000000','1.526377541431376','1.531127142048359','699.4993544894259','699.499354489425855','test','test','0.0'),('2019-04-29 19:59:59','2019-04-29 23:59:59','WABIETH','4h','0.002208760000000','0.002191000000000','1.527433008235150','1.515151361416909','691.5341676937061','691.534167693706081','test','test','0.8'),('2019-04-30 15:59:59','2019-04-30 23:59:59','WABIETH','4h','0.002225550000000','0.002191720000000','1.524703753386652','1.501527132786319','685.0907656025038','685.090765602503780','test','test','1.5'),('2019-05-05 11:59:59','2019-05-05 19:59:59','WABIETH','4h','0.002254760000000','0.002164569600000','1.519553393253245','1.458771257523115','673.9313245104778','673.931324510477793','test','test','4.0'),('2019-05-22 23:59:59','2019-05-23 03:59:59','WABIETH','4h','0.001449850000000','0.001417310000000','1.506046251979883','1.472245000099050','1038.760045508075','1038.760045508075109','test','test','2.2'),('2019-05-23 11:59:59','2019-05-23 15:59:59','WABIETH','4h','0.001420410000000','0.001434560000000','1.498534862673031','1.513463135711677','1055.0016281728733','1055.001628172873325','test','test','0.0'),('2019-05-24 03:59:59','2019-05-24 07:59:59','WABIETH','4h','0.001472840000000','0.001413926400000','1.501852256681619','1.441778166414354','1019.6981727014606','1019.698172701460635','test','test','4.0'),('2019-05-24 11:59:59','2019-05-24 15:59:59','WABIETH','4h','0.001432390000000','0.001375094400000','1.488502458844449','1.428962360490671','1039.1740090648839','1039.174009064883876','test','test','4.0'),('2019-06-08 03:59:59','2019-06-13 07:59:59','WABIETH','4h','0.001291660000000','0.001269100000000','1.475271325876943','1.449504389444922','1142.151437589569','1142.151437589569014','test','test','2.9'),('2019-07-20 23:59:59','2019-07-27 03:59:59','WABIETH','4h','0.000651430000000','0.000692960000000','1.469545340003160','1.563231872662588','2255.876057294199','2255.876057294199200','test','test','1.3'),('2019-07-28 19:59:59','2019-07-28 23:59:59','WABIETH','4h','0.000733970000000','0.000704611200000','1.490364569483033','1.430749986703712','2030.552433318846','2030.552433318845942','test','test','4.0'),('2019-07-29 07:59:59','2019-07-29 23:59:59','WABIETH','4h','0.000702460000000','0.000699300000000','1.477116884420962','1.470472108412691','2102.7772178073656','2102.777217807365560','test','test','1.4'),('2019-08-15 15:59:59','2019-08-16 03:59:59','WABIETH','4h','0.000597260000000','0.000573369600000','1.475640267530235','1.416614656829025','2470.6832326461426','2470.683232646142642','test','test','4.0'),('2019-08-17 19:59:59','2019-08-18 11:59:59','WABIETH','4h','0.000575570000000','0.000562110000000','1.462523465152188','1.428321602927005','2541.0001653181857','2541.000165318185736','test','test','2.3'),('2019-08-21 19:59:59','2019-08-21 23:59:59','WABIETH','4h','0.000566150000000','0.000567330000000','1.454923051324370','1.457955479480447','2569.854369556425','2569.854369556424899','test','test','0.0'),('2019-08-22 19:59:59','2019-08-23 15:59:59','WABIETH','4h','0.000576070000000','0.000560180000000','1.455596924247943','1.415446534319115','2526.7709206310737','2526.770920631073750','test','test','2.8'),('2019-08-24 03:59:59','2019-09-10 19:59:59','WABIETH','4h','0.000602270000000','0.000958300000000','1.446674615374870','2.301871725162698','2402.0366536185925','2402.036653618592482','test','test','0.0'),('2019-09-11 11:59:59','2019-09-11 19:59:59','WABIETH','4h','0.000989690000000','0.000950102400000','1.636718417549943','1.571249680847945','1653.7687736058183','1653.768773605818296','test','test','4.0'),('2019-09-29 07:59:59','2019-09-29 15:59:59','WABIETH','4h','0.000749980000000','0.000719980800000','1.622169809393943','1.557283017018185','2162.950757878801','2162.950757878801141','test','test','4.0'),('2019-09-30 07:59:59','2019-09-30 19:59:59','WABIETH','4h','0.000694750000000','0.000682330000000','1.607750522199330','1.579008871985993','2314.142529254164','2314.142529254163946','test','test','1.8'),('2019-10-01 11:59:59','2019-10-02 19:59:59','WABIETH','4h','0.000713490000000','0.000693950000000','1.601363488818589','1.557507733907497','2244.4091561459704','2244.409156145970428','test','test','2.7'),('2019-10-03 07:59:59','2019-10-03 23:59:59','WABIETH','4h','0.000694070000000','0.000691400000000','1.591617765505013','1.585495012131580','2293.1660574654034','2293.166057465403355','test','test','0.4'),('2019-10-04 15:59:59','2019-10-06 11:59:59','WABIETH','4h','0.000712200000000','0.000717200000000','1.590257153644250','1.601421553768121','2232.8800247742906','2232.880024774290632','test','test','0.0'),('2019-10-06 15:59:59','2019-10-09 15:59:59','WABIETH','4h','0.000736930000000','0.000707452800000','1.592738131449554','1.529028606191572','2161.315364348791','2161.315364348790808','test','test','4.0'),('2019-10-12 19:59:59','2019-10-13 03:59:59','WABIETH','4h','0.000737850000000','0.000708336000000','1.578580459170003','1.515437240803203','2139.432756210616','2139.432756210615935','test','test','4.0'),('2019-10-14 15:59:59','2019-10-14 23:59:59','WABIETH','4h','0.000715580000000','0.000696360000000','1.564548632866270','1.522525903438827','2186.4063177649873','2186.406317764987307','test','test','2.7'),('2019-10-15 07:59:59','2019-10-15 19:59:59','WABIETH','4h','0.000707480000000','0.000705990000000','1.555210248549060','1.551934872184586','2198.239170787952','2198.239170787951934','test','test','0.2'),('2019-10-19 11:59:59','2019-10-19 23:59:59','WABIETH','4h','0.000690340000000','0.000699630000000','1.554482387134732','1.575401269680263','2251.763460229354','2251.763460229354223','test','test','0.0'),('2019-10-20 11:59:59','2019-10-23 15:59:59','WABIETH','4h','0.000700070000000','0.000744490000000','1.559131027700406','1.658059135247440','2227.1073288391244','2227.107328839124420','test','test','0.8'),('2019-10-24 15:59:59','2019-10-25 03:59:59','WABIETH','4h','0.000845150000000','0.000811344000000','1.581115051599747','1.517870449535757','1870.8099764535846','1870.809976453584568','test','test','4.0'),('2019-10-25 11:59:59','2019-10-26 03:59:59','WABIETH','4h','0.000770850000000','0.000740016000000','1.567060695585527','1.504378267762106','2032.8996504968889','2032.899650496888853','test','test','4.0'),('2019-10-27 15:59:59','2019-10-27 23:59:59','WABIETH','4h','0.000821270000000','0.000788419200000','1.553131267180322','1.491006016493109','1891.1335701782873','1891.133570178287300','test','test','4.0'),('2019-10-28 03:59:59','2019-10-28 07:59:59','WABIETH','4h','0.000861050000000','0.000826608000000','1.539325655916497','1.477752629679837','1787.7308587381651','1787.730858738165125','test','test','4.0'),('2019-10-29 07:59:59','2019-11-05 15:59:59','WABIETH','4h','0.000836230000000','0.000881740000000','1.525642761197240','1.608672552118501','1824.429596160434','1824.429596160433903','test','test','1.3'),('2019-11-05 19:59:59','2019-11-06 11:59:59','WABIETH','4h','0.000946680000000','0.000942870000000','1.544093825846409','1.537879479418392','1631.0620545975498','1631.062054597549832','test','test','2.5'),('2019-11-06 15:59:59','2019-11-08 03:59:59','WABIETH','4h','0.000942970000000','0.000920100000000','1.542712859973516','1.505297201885142','1636.0147830509095','1636.014783050909500','test','test','2.4'),('2019-11-10 11:59:59','2019-11-11 07:59:59','WABIETH','4h','0.000913630000000','0.001036930000000','1.534398269287210','1.741474773564776','1679.4525894368733','1679.452589436873268','test','test','0.6'),('2019-11-11 11:59:59','2019-11-12 07:59:59','WABIETH','4h','0.001111970000000','0.001067491200000','1.580415270237781','1.517198659428270','1421.2750975635859','1421.275097563585859','test','test','4.0'),('2019-11-12 19:59:59','2019-11-13 19:59:59','WABIETH','4h','0.001175180000000','0.001128172800000','1.566367134502334','1.503712449122241','1332.8742273543917','1332.874227354391678','test','test','4.0'),('2019-11-15 15:59:59','2019-11-21 11:59:59','WABIETH','4h','0.001088070000000','0.001100650000000','1.552443871084535','1.570392848538415','1426.7867610397634','1426.786761039763405','test','test','3.1'),('2019-11-23 11:59:59','2019-11-24 15:59:59','WABIETH','4h','0.001180270000000','0.001133059200000','1.556432532740953','1.494175231431315','1318.7088824937964','1318.708882493796409','test','test','4.0'),('2019-11-25 07:59:59','2019-11-25 11:59:59','WABIETH','4h','0.001189190000000','0.001141622400000','1.542597576894367','1.480893673818592','1297.183441581553','1297.183441581553097','test','test','4.0'),('2019-11-26 11:59:59','2019-11-30 07:59:59','WABIETH','4h','0.001186240000000','0.001166710000000','1.528885598433084','1.503714355061255','1288.8501470470424','1288.850147047042356','test','test','1.7'),('2019-12-03 23:59:59','2019-12-04 03:59:59','WABIETH','4h','0.001164080000000','0.001143930000000','1.523291988794899','1.496924098637678','1308.5801566858802','1308.580156685880183','test','test','1.7'),('2019-12-04 11:59:59','2019-12-04 15:59:59','WABIETH','4h','0.001174070000000','0.001129440000000','1.517432457648850','1.459750198000901','1292.4548431088867','1292.454843108886735','test','test','3.8'),('2019-12-07 03:59:59','2019-12-07 07:59:59','WABIETH','4h','0.001133850000000','0.001136250000000','1.504614177727084','1.507798967625699','1326.9957910897242','1326.995791089724207','test','test','0.0'),('2019-12-15 03:59:59','2019-12-15 07:59:59','WABIETH','4h','0.001066460000000','0.001116990000000','1.505321908815665','1.576645649089520','1411.5127701138956','1411.512770113895613','test','test','0.0'),('2019-12-15 11:59:59','2019-12-18 15:59:59','WABIETH','4h','0.001117000000000','0.001120910000000','1.521171628876522','1.526496410495955','1361.836731312911','1361.836731312911070','test','test','2.5'),('2019-12-19 11:59:59','2019-12-21 23:59:59','WABIETH','4h','0.001146510000000','0.001150000000000','1.522354913680840','1.526988993321442','1327.8165159316884','1327.816515931688400','test','test','0.0'),('2019-12-22 23:59:59','2019-12-23 03:59:59','WABIETH','4h','0.001156290000000','0.001110038400000','1.523384709156529','1.462449320790268','1317.4763330622332','1317.476333062233152','test','test','4.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:25:53
