-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 23:59:59','2019-01-04 03:59:59','LENDBTC','4h','0.000002090000000','0.000002090000000','0.033333333333333','0.033333333333333','15948.96331738437','15948.963317384370384','test','test','0.0'),('2019-01-04 07:59:59','2019-01-04 11:59:59','LENDBTC','4h','0.000002090000000','0.000002090000000','0.033333333333333','0.033333333333333','15948.96331738437','15948.963317384370384','test','test','0.0'),('2019-01-09 11:59:59','2019-01-09 15:59:59','LENDBTC','4h','0.000002110000000','0.000002080000000','0.033333333333333','0.032859399684044','15797.78830963665','15797.788309636649501','test','test','1.4'),('2019-01-13 11:59:59','2019-01-13 19:59:59','LENDBTC','4h','0.000002080000000','0.000002060000000','0.033228014744602','0.032908514602827','15975.007088751174','15975.007088751173796','test','test','1.0'),('2019-01-13 23:59:59','2019-01-20 11:59:59','LENDBTC','4h','0.000002100000000','0.000002220000000','0.033157014713097','0.035051701268131','15789.054625284232','15789.054625284232316','test','test','0.0'),('2019-01-20 15:59:59','2019-01-20 19:59:59','LENDBTC','4h','0.000002240000000','0.000002230000000','0.033578056169771','0.033428154133299','14990.203647219247','14990.203647219246704','test','test','0.4'),('2019-01-22 07:59:59','2019-01-23 23:59:59','LENDBTC','4h','0.000002260000000','0.000002290000000','0.033544744606111','0.033990028826546','14842.807347836577','14842.807347836576810','test','test','0.0'),('2019-01-25 07:59:59','2019-01-27 15:59:59','LENDBTC','4h','0.000002330000000','0.000002280000000','0.033643696655096','0.032921728915716','14439.354787594944','14439.354787594944355','test','test','2.1'),('2019-02-02 19:59:59','2019-02-03 03:59:59','LENDBTC','4h','0.000002290000000','0.000002198400000','0.033483259379678','0.032143929004491','14621.510646147792','14621.510646147791704','test','test','4.0'),('2019-02-09 19:59:59','2019-02-10 03:59:59','LENDBTC','4h','0.000002170000000','0.000002130000000','0.033185630407415','0.032573913717877','15292.917238439937','15292.917238439937137','test','test','1.8'),('2019-02-15 07:59:59','2019-02-15 11:59:59','LENDBTC','4h','0.000002110000000','0.000002120000000','0.033049693365295','0.033206326983140','15663.361784500052','15663.361784500051726','test','test','0.0'),('2019-02-21 23:59:59','2019-02-22 23:59:59','LENDBTC','4h','0.000002190000000','0.000002102400000','0.033084500835927','0.031761120802490','15107.078007272752','15107.078007272752075','test','test','4.0'),('2019-03-01 19:59:59','2019-03-01 23:59:59','LENDBTC','4h','0.000002070000000','0.000002020000000','0.032790416384052','0.031998377340959','15840.780861861083','15840.780861861083395','test','test','2.4'),('2019-03-02 11:59:59','2019-03-07 07:59:59','LENDBTC','4h','0.000002050000000','0.000002170000000','0.032614407707810','0.034523543768755','15909.467174541249','15909.467174541248824','test','test','0.0'),('2019-03-08 03:59:59','2019-03-11 19:59:59','LENDBTC','4h','0.000002260000000','0.000002250000000','0.033038660165797','0.032892471404001','14618.876179556344','14618.876179556344141','test','test','1.8'),('2019-03-12 11:59:59','2019-03-16 23:59:59','LENDBTC','4h','0.000002340000000','0.000002340000000','0.033006173774287','0.033006173774287','14105.202467644065','14105.202467644065109','test','test','0.9'),('2019-03-26 23:59:59','2019-03-27 03:59:59','LENDBTC','4h','0.000002240000000','0.000002260000000','0.033006173774287','0.033300871754415','14734.899006378175','14734.899006378174818','test','test','0.0'),('2019-03-27 07:59:59','2019-04-02 07:59:59','LENDBTC','4h','0.000002270000000','0.000002310000000','0.033071662214316','0.033654422781969','14569.014191328439','14569.014191328438756','test','test','0.0'),('2019-04-05 15:59:59','2019-04-06 11:59:59','LENDBTC','4h','0.000002390000000','0.000002310000000','0.033201164562683','0.032089828510376','13891.700653842212','13891.700653842211977','test','test','3.3'),('2019-04-07 23:59:59','2019-04-08 03:59:59','LENDBTC','4h','0.000002370000000','0.000002280000000','0.032954200995504','0.031702775641244','13904.726158440315','13904.726158440314975','test','test','3.8'),('2019-04-14 19:59:59','2019-04-14 23:59:59','LENDBTC','4h','0.000002210000000','0.000002170000000','0.032676106472335','0.032084683730754','14785.56853951795','14785.568539517949830','test','test','1.8'),('2019-05-20 15:59:59','2019-05-20 19:59:59','LENDBTC','4h','0.000001250000000','0.000001200000000','0.032544679196428','0.031242892028571','26035.74335714222','26035.743357142218883','test','test','4.0'),('2019-05-21 07:59:59','2019-05-21 11:59:59','LENDBTC','4h','0.000001180000000','0.000001160000000','0.032255393159126','0.031708691580158','27335.07894841205','27335.078948412050522','test','test','1.7'),('2019-05-21 19:59:59','2019-05-22 11:59:59','LENDBTC','4h','0.000001180000000','0.000001150000000','0.032133903919356','0.031316940260389','27232.121965555558','27232.121965555557836','test','test','2.5'),('2019-05-22 15:59:59','2019-05-24 15:59:59','LENDBTC','4h','0.000001240000000','0.000001200000000','0.031952356439585','0.030921635264115','25768.029386762188','25768.029386762187642','test','test','3.2'),('2019-05-26 11:59:59','2019-05-26 15:59:59','LENDBTC','4h','0.000001200000000','0.000001220000000','0.031723307289481','0.032252029077639','26436.089407900552','26436.089407900552033','test','test','0.0'),('2019-06-06 15:59:59','2019-06-06 19:59:59','LENDBTC','4h','0.000001090000000','0.000001060000000','0.031840801020182','0.030964448698526','29211.74405521325','29211.744055213250249','test','test','2.8'),('2019-06-07 11:59:59','2019-06-07 15:59:59','LENDBTC','4h','0.000001080000000','0.000001080000000','0.031646056059814','0.031646056059814','29301.903759087447','29301.903759087446815','test','test','0.0'),('2019-06-07 19:59:59','2019-06-07 23:59:59','LENDBTC','4h','0.000001080000000','0.000001070000000','0.031646056059814','0.031353037022223','29301.903759087447','29301.903759087446815','test','test','0.9'),('2019-06-08 07:59:59','2019-06-12 15:59:59','LENDBTC','4h','0.000001130000000','0.000001180000000','0.031580940718128','0.032978327475567','27947.735148785447','27947.735148785446654','test','test','0.0'),('2019-06-16 11:59:59','2019-06-16 15:59:59','LENDBTC','4h','0.000001140000000','0.000001180000000','0.031891471108670','0.033010470094939','27974.974656727678','27974.974656727677939','test','test','0.0'),('2019-06-16 19:59:59','2019-06-16 23:59:59','LENDBTC','4h','0.000001160000000','0.000001170000000','0.032140137550063','0.032417207701357','27707.015129364365','27707.015129364364839','test','test','0.0'),('2019-06-17 03:59:59','2019-06-17 11:59:59','LENDBTC','4h','0.000001170000000','0.000001150000000','0.032201708694795','0.031651252135910','27522.82794426894','27522.827944268941792','test','test','1.7'),('2019-06-19 15:59:59','2019-06-19 19:59:59','LENDBTC','4h','0.000001460000000','0.000001401600000','0.032079385015042','0.030796209614440','21972.181517152356','21972.181517152355809','test','test','4.0'),('2019-07-26 15:59:59','2019-07-26 19:59:59','LENDBTC','4h','0.000000490000000','0.000000490000000','0.031794234926020','0.031794234926020','64886.19372657097','64886.193726570971194','test','test','0.0'),('2019-08-21 11:59:59','2019-08-22 19:59:59','LENDBTC','4h','0.000000350000000','0.000000350000000','0.031794234926020','0.031794234926020','90840.67121719936','90840.671217199356761','test','test','0.0'),('2019-08-23 07:59:59','2019-08-23 19:59:59','LENDBTC','4h','0.000000390000000','0.000000374400000','0.031794234926020','0.030522465528979','81523.6792974866','81523.679297486596624','test','test','4.0'),('2019-08-25 03:59:59','2019-08-25 11:59:59','LENDBTC','4h','0.000000410000000','0.000000393600000','0.031511619504455','0.030251154724277','76857.6085474515','76857.608547451498453','test','test','4.0'),('2019-08-25 15:59:59','2019-08-26 03:59:59','LENDBTC','4h','0.000000380000000','0.000000380000000','0.031231516219971','0.031231516219971','82188.20057887134','82188.200578871343168','test','test','0.0'),('2019-08-26 07:59:59','2019-08-28 15:59:59','LENDBTC','4h','0.000000420000000','0.000000403200000','0.031231516219971','0.029982255571172','74360.75290469312','74360.752904693115852','test','test','4.0'),('2019-09-09 15:59:59','2019-09-11 15:59:59','LENDBTC','4h','0.000000380000000','0.000000380000000','0.030953902742460','0.030953902742460','81457.63879594795','81457.638795947947074','test','test','0.0'),('2019-09-13 15:59:59','2019-09-24 03:59:59','LENDBTC','4h','0.000000390000000','0.000000500000000','0.030953902742460','0.039684490695462','79368.98139092364','79368.981390923639992','test','test','0.0'),('2019-09-26 07:59:59','2019-09-26 15:59:59','LENDBTC','4h','0.000000540000000','0.000000518400000','0.032894033398683','0.031578272062736','60914.876664227566','60914.876664227565925','test','test','4.0'),('2019-09-28 11:59:59','2019-10-09 15:59:59','LENDBTC','4h','0.000000540000000','0.000000580000000','0.032601641990695','0.035016578434450','60373.41109387901','60373.411093879010878','test','test','3.7'),('2019-10-11 07:59:59','2019-10-31 11:59:59','LENDBTC','4h','0.000000620000000','0.000001360000000','0.033138294533751','0.072690452525647','53448.862151211826','53448.862151211826131','test','test','0.0'),('2019-11-03 15:59:59','2019-11-04 07:59:59','LENDBTC','4h','0.000001500000000','0.000001440000000','0.041927662976395','0.040250556457339','27951.775317596595','27951.775317596595414','test','test','4.0'),('2019-11-04 11:59:59','2019-11-04 19:59:59','LENDBTC','4h','0.000001550000000','0.000001488000000','0.041554972638827','0.039892773733274','26809.65976698509','26809.659766985088936','test','test','4.0'),('2019-11-04 23:59:59','2019-11-07 11:59:59','LENDBTC','4h','0.000001380000000','0.000001380000000','0.041185595104260','0.041185595104260','29844.63413352142','29844.634133521420154','test','test','0.0'),('2019-11-08 15:59:59','2019-11-08 19:59:59','LENDBTC','4h','0.000001380000000','0.000001380000000','0.041185595104260','0.041185595104260','29844.63413352142','29844.634133521420154','test','test','0.0'),('2019-11-09 11:59:59','2019-11-21 03:59:59','LENDBTC','4h','0.000001450000000','0.000002000000000','0.041185595104260','0.056807717385186','28403.858692592796','28403.858692592795705','test','test','0.0'),('2019-11-22 03:59:59','2019-11-22 07:59:59','LENDBTC','4h','0.000002220000000','0.000002131200000','0.044657177833354','0.042870890720020','20115.84587088028','20115.845870880279108','test','test','4.0'),('2019-11-28 19:59:59','2019-11-29 15:59:59','LENDBTC','4h','0.000002050000000','0.000002010000000','0.044260225141502','0.043396610992400','21590.35372756206','21590.353727562058339','test','test','2.0'),('2019-12-04 23:59:59','2019-12-05 07:59:59','LENDBTC','4h','0.000002030000000','0.000001960000000','0.044068310886146','0.042548713959038','21708.52753012129','21708.527530121289601','test','test','3.4'),('2019-12-06 11:59:59','2019-12-10 03:59:59','LENDBTC','4h','0.000001990000000','0.000001970000000','0.043730622680122','0.043291118934593','21975.18727644333','21975.187276443328301','test','test','1.0'),('2019-12-30 23:59:59','2020-01-01 15:59:59','LENDBTC','4h','0.000001370000000','0.000002770000000','0.043632955181116','0.088221376534081','31848.872394975013','31848.872394975012867','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:13:22
