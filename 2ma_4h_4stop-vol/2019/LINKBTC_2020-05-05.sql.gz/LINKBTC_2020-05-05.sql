-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-08 07:59:59','LINKBTC','4h','0.000077840000000','0.000092190000000','0.033333333333333','0.039478417266187','428.22884549503254','428.228845495032544','test','test','0.0'),('2019-01-08 15:59:59','2019-01-10 11:59:59','LINKBTC','4h','0.000095890000000','0.000093490000000','0.034698907540634','0.033830439732755','361.8615866162709','361.861586616270927','test','test','2.5'),('2019-01-10 19:59:59','2019-01-25 15:59:59','LINKBTC','4h','0.000099400000000','0.000137160000000','0.034505914694439','0.047613996574339','347.14199893801697','347.141998938016968','test','test','2.7'),('2019-01-29 19:59:59','2019-01-29 23:59:59','LINKBTC','4h','0.000132130000000','0.000132130000000','0.037418821778861','0.037418821778861','283.1970164146001','283.197016414600114','test','test','0.0'),('2019-02-05 23:59:59','2019-02-06 03:59:59','LINKBTC','4h','0.000121660000000','0.000120220000000','0.037418821778861','0.036975922688268','307.5688129118947','307.568812911894724','test','test','1.2'),('2019-02-08 03:59:59','2019-02-08 19:59:59','LINKBTC','4h','0.000121800000000','0.000121000000000','0.037320399758729','0.037075273980347','306.40722297807326','306.407222978073264','test','test','0.7'),('2019-02-09 15:59:59','2019-02-09 19:59:59','LINKBTC','4h','0.000131900000000','0.000126624000000','0.037265927363533','0.035775290268992','282.5316706863785','282.531670686378504','test','test','4.0'),('2019-02-09 23:59:59','2019-02-10 23:59:59','LINKBTC','4h','0.000126320000000','0.000122400000000','0.036934674675858','0.035788506810679','292.38976152515477','292.389761525154768','test','test','3.1'),('2019-02-13 23:59:59','2019-02-14 03:59:59','LINKBTC','4h','0.000122500000000','0.000119920000000','0.036679970705818','0.035907445608504','299.42833229239005','299.428332292390053','test','test','2.1'),('2019-02-14 11:59:59','2019-02-14 15:59:59','LINKBTC','4h','0.000121410000000','0.000120100000000','0.036508298461970','0.036114378101331','300.7025653732824','300.702565373282425','test','test','1.1'),('2019-02-15 23:59:59','2019-02-16 07:59:59','LINKBTC','4h','0.000120720000000','0.000120500000000','0.036420760604050','0.036354387448542','301.6961613986948','301.696161398694812','test','test','0.4'),('2019-02-17 11:59:59','2019-02-18 23:59:59','LINKBTC','4h','0.000123660000000','0.000121060000000','0.036406011013938','0.035640560353771','294.4041000641886','294.404100064188583','test','test','2.1'),('2019-02-19 03:59:59','2019-02-19 07:59:59','LINKBTC','4h','0.000121830000000','0.000120250000000','0.036235910867234','0.035765971286094','297.43011464527433','297.430114645274330','test','test','1.3'),('2019-02-25 15:59:59','2019-02-25 19:59:59','LINKBTC','4h','0.000120100000000','0.000116640000000','0.036131479849203','0.035090556283189','300.8449612756258','300.844961275625792','test','test','2.9'),('2019-02-25 23:59:59','2019-02-26 03:59:59','LINKBTC','4h','0.000123280000000','0.000118348800000','0.035900163501200','0.034464156961152','291.2083346949996','291.208334694999621','test','test','4.0'),('2019-03-07 15:59:59','2019-03-07 19:59:59','LINKBTC','4h','0.000112460000000','0.000120200000000','0.035581050936744','0.038029897942350','316.388502016223','316.388502016223015','test','test','0.0'),('2019-03-07 23:59:59','2019-03-16 03:59:59','LINKBTC','4h','0.000116660000000','0.000121660000000','0.036125239160212','0.037673552170679','309.6626020933692','309.662602093369173','test','test','0.0'),('2019-03-25 23:59:59','2019-03-26 15:59:59','LINKBTC','4h','0.000120260000000','0.000115800000000','0.036469308718094','0.035116796520500','303.2538559628638','303.253855962863781','test','test','3.7'),('2019-03-27 15:59:59','2019-03-30 11:59:59','LINKBTC','4h','0.000118130000000','0.000119090000000','0.036168750451962','0.036462680871279','306.1775201215779','306.177520121577913','test','test','0.0'),('2019-03-31 07:59:59','2019-04-02 07:59:59','LINKBTC','4h','0.000122840000000','0.000127310000000','0.036234068322921','0.037552582531676','294.9696216454032','294.969621645403208','test','test','0.0'),('2019-04-02 11:59:59','2019-04-02 15:59:59','LINKBTC','4h','0.000122240000000','0.000124270000000','0.036527071480422','0.037133664699542','298.81439365528837','298.814393655288370','test','test','0.0'),('2019-05-01 03:59:59','2019-05-01 07:59:59','LINKBTC','4h','0.000089060000000','0.000089820000000','0.036661869973560','0.036974726712611','411.653604014824','411.653604014823998','test','test','0.0'),('2019-05-05 07:59:59','2019-05-05 19:59:59','LINKBTC','4h','0.000088380000000','0.000087790000000','0.036731393693349','0.036486185249368','415.60753217186385','415.607532171863852','test','test','0.7'),('2019-05-06 11:59:59','2019-05-11 23:59:59','LINKBTC','4h','0.000092640000000','0.000095480000000','0.036676902928020','0.037801281212946','395.9078468050542','395.907846805054191','test','test','0.1'),('2019-05-14 15:59:59','2019-05-15 02:59:59','LINKBTC','4h','0.000107050000000','0.000102768000000','0.036926764769115','0.035449694178350','344.948760103829','344.948760103828988','test','test','4.0'),('2019-05-15 15:59:59','2019-05-25 15:59:59','LINKBTC','4h','0.000100350000000','0.000142980000000','0.036598526860056','0.052146062485808','364.7087878431091','364.708787843109121','test','test','0.0'),('2019-05-25 19:59:59','2019-05-25 23:59:59','LINKBTC','4h','0.000143830000000','0.000138860000000','0.040053534776890','0.038669497595209','278.478306173189','278.478306173189026','test','test','3.5'),('2019-05-28 19:59:59','2019-05-29 03:59:59','LINKBTC','4h','0.000151910000000','0.000145833600000','0.039745970958738','0.038156132120388','261.64157039522377','261.641570395223766','test','test','4.0'),('2019-06-05 07:59:59','2019-06-09 19:59:59','LINKBTC','4h','0.000127060000000','0.000136520000000','0.039392673439105','0.042325576718925','310.03205917759414','310.032059177594135','test','test','0.0'),('2019-06-10 23:59:59','2019-06-11 11:59:59','LINKBTC','4h','0.000151270000000','0.000145219200000','0.040044429723510','0.038442652534570','264.72155565220834','264.721555652208338','test','test','4.0'),('2019-06-11 15:59:59','2019-06-12 07:59:59','LINKBTC','4h','0.000143560000000','0.000138090000000','0.039688479237078','0.038176247547005','276.45917551601036','276.459175516010362','test','test','3.8'),('2019-06-12 15:59:59','2019-06-12 23:59:59','LINKBTC','4h','0.000140670000000','0.000140860000000','0.039352427750396','0.039405580243981','279.74996623583957','279.749966235839565','test','test','0.8'),('2019-06-13 19:59:59','2019-06-14 03:59:59','LINKBTC','4h','0.000217740000000','0.000209030400000','0.039364239415637','0.037789669839012','180.7855213357062','180.785521335706193','test','test','4.0'),('2019-06-14 07:59:59','2019-06-16 15:59:59','LINKBTC','4h','0.000188400000000','0.000180864000000','0.039014335065276','0.037453761662665','207.0824578836282','207.082457883628194','test','test','4.0'),('2019-06-17 11:59:59','2019-06-18 11:59:59','LINKBTC','4h','0.000204000000000','0.000195840000000','0.038667540975806','0.037120839336774','189.54676948924728','189.546769489247282','test','test','4.0'),('2019-06-25 03:59:59','2019-06-26 03:59:59','LINKBTC','4h','0.000179250000000','0.000172080000000','0.038323829500466','0.036790876320447','213.80100139729987','213.801001397299871','test','test','4.0'),('2019-06-27 03:59:59','2019-07-07 23:59:59','LINKBTC','4h','0.000184050000000','0.000286990000000','0.037983173238240','0.059227334352852','206.37420939005463','206.374209390054631','test','test','0.0'),('2019-07-08 07:59:59','2019-07-08 11:59:59','LINKBTC','4h','0.000300720000000','0.000288691200000','0.042704097930376','0.040995934013161','142.0061782733957','142.006178273395705','test','test','4.0'),('2019-07-12 19:59:59','2019-07-12 23:59:59','LINKBTC','4h','0.000284190000000','0.000272822400000','0.042324505948772','0.040631525710821','148.93031404613893','148.930314046138932','test','test','4.0'),('2019-07-13 19:59:59','2019-07-14 15:59:59','LINKBTC','4h','0.000288010000000','0.000276489600000','0.041948288118116','0.040270356593391','145.6487209406494','145.648720940649412','test','test','4.0'),('2019-07-18 11:59:59','2019-07-18 15:59:59','LINKBTC','4h','0.000276240000000','0.000265190400000','0.041575414445955','0.039912397868117','150.50468594684088','150.504685946840880','test','test','4.0'),('2019-08-03 03:59:59','2019-08-03 19:59:59','LINKBTC','4h','0.000234210000000','0.000233520000000','0.041205855206436','0.041084459706276','175.93550747805722','175.935507478057218','test','test','0.3'),('2019-08-04 19:59:59','2019-08-04 23:59:59','LINKBTC','4h','0.000231790000000','0.000229380000000','0.041178878428622','0.040750727529045','177.65597492826458','177.655974928264584','test','test','1.0'),('2019-08-11 19:59:59','2019-08-11 23:59:59','LINKBTC','4h','0.000213680000000','0.000210030000000','0.041083733784272','0.040381957163565','192.26756731688505','192.267567316885049','test','test','1.7'),('2019-08-13 15:59:59','2019-08-20 11:59:59','LINKBTC','4h','0.000213200000000','0.000225240000000','0.040927783424115','0.043239089767578','191.96896540391597','191.968965403915973','test','test','0.0'),('2019-09-18 07:59:59','2019-10-15 19:59:59','LINKBTC','4h','0.000170760000000','0.000297510000000','0.041441407055996','0.072202114155712','242.6880244553499','242.688024455349904','test','test','2.0'),('2019-10-15 23:59:59','2019-10-16 03:59:59','LINKBTC','4h','0.000293710000000','0.000281961600000','0.048277119744821','0.046346034955028','164.37002398563664','164.370023985636635','test','test','4.0'),('2019-10-16 23:59:59','2019-10-17 03:59:59','LINKBTC','4h','0.000297050000000','0.000296270000000','0.047847989791534','0.047722349555758','161.07722535443193','161.077225354431931','test','test','0.3'),('2019-10-17 11:59:59','2019-10-18 23:59:59','LINKBTC','4h','0.000296020000000','0.000296150000000','0.047820069739139','0.047841070377833','161.54337456637842','161.543374566378418','test','test','0.0'),('2019-10-20 19:59:59','2019-10-20 23:59:59','LINKBTC','4h','0.000295530000000','0.000297460000000','0.047824736547738','0.048137062678882','161.82701095569993','161.827010955699933','test','test','0.0'),('2019-10-21 03:59:59','2019-10-26 03:59:59','LINKBTC','4h','0.000302500000000','0.000297940000000','0.047894142354659','0.047172167845114','158.32774332118643','158.327743321186432','test','test','1.5'),('2019-11-08 11:59:59','2019-11-19 07:59:59','LINKBTC','4h','0.000296720000000','0.000330580000000','0.047733703574760','0.053180802533514','160.87120374346188','160.871203743461876','test','test','0.0'),('2019-11-19 15:59:59','2019-11-19 19:59:59','LINKBTC','4h','0.000333270000000','0.000328490000000','0.048944170010039','0.048242177233467','146.86041350868268','146.860413508682683','test','test','1.4'),('2019-11-20 11:59:59','2019-11-20 19:59:59','LINKBTC','4h','0.000341150000000','0.000327504000000','0.048788171615245','0.046836644750635','143.01090902900452','143.010909029004523','test','test','4.0'),('2019-11-21 15:59:59','2019-11-21 19:59:59','LINKBTC','4h','0.000338250000000','0.000334850000000','0.048354498978665','0.047868452277919','142.95491198422732','142.954911984227323','test','test','1.0'),('2019-11-23 15:59:59','2019-11-23 19:59:59','LINKBTC','4h','0.000335170000000','0.000334680000000','0.048246488600721','0.048175954903152','143.9463215703116','143.946321570311596','test','test','0.1'),('2019-12-10 03:59:59','2019-12-12 07:59:59','LINKBTC','4h','0.000294170000000','0.000288270000000','0.048230814445706','0.047263476494081','163.95558502126664','163.955585021266643','test','test','2.0'),('2019-12-15 15:59:59','2019-12-15 23:59:59','LINKBTC','4h','0.000293250000000','0.000291000000000','0.048015850456456','0.047647442396688','163.73691545253538','163.736915452535385','test','test','0.8'),('2019-12-16 11:59:59','2019-12-16 15:59:59','LINKBTC','4h','0.000291230000000','0.000287630000000','0.047933981998730','0.047341452605483','164.59149812426529','164.591498124265286','test','test','1.2'),('2019-12-27 15:59:59','2019-12-27 19:59:59','LINKBTC','4h','0.000266090000000','0.000261920000000','0.047802308800230','0.047053180205781','179.64714495182247','179.647144951822469','test','test','1.6');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:11:46
