-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-03 19:59:59','BTCUSDT','4h','3797.139999999999873','3756.000000000000000','222.222222222222200','219.814562188032738','0.05852357885730371','0.058523578857304','test','test','1.1'),('2019-01-04 23:59:59','2019-01-05 23:59:59','BTCUSDT','4h','3792.010000000000218','3770.960000000000036','221.687186659068999','220.456568786443796','0.05846165665677806','0.058461656656778','test','test','0.6'),('2019-01-06 11:59:59','2019-01-10 07:59:59','BTCUSDT','4h','3814.239999999999782','3777.019999999999982','221.413716020707852','219.253123475327726','0.05804923550188448','0.058049235501884','test','test','1.0'),('2019-01-19 11:59:59','2019-01-20 11:59:59','BTCUSDT','4h','3695.380000000000109','3580.000000000000000','220.933584343956710','214.035425842907898','0.05978643179969494','0.059786431799695','test','test','3.1'),('2019-01-26 07:59:59','2019-01-26 11:59:59','BTCUSDT','4h','3620.579999999999927','3589.929999999999836','219.400660232612523','217.543325154771509','0.06059820808616645','0.060598208086166','test','test','0.8'),('2019-02-08 15:59:59','2019-02-24 15:59:59','BTCUSDT','4h','3507.340000000000146','3778.650000000000091','218.987919104203428','235.927711748247475','0.0624370374997016','0.062437037499702','test','test','0.0'),('2019-02-25 19:59:59','2019-02-25 23:59:59','BTCUSDT','4h','3855.389999999999873','3827.920000000000073','222.752317469546568','221.165187202339268','0.05777685719720873','0.057776857197209','test','test','0.7'),('2019-02-28 15:59:59','2019-02-28 19:59:59','BTCUSDT','4h','3852.880000000000109','3821.110000000000127','222.399621854611581','220.565763549571983','0.05772295577713595','0.057722955777136','test','test','0.8'),('2019-03-05 19:59:59','2019-03-08 23:59:59','BTCUSDT','4h','3855.710000000000036','3864.889999999999873','221.992097786825042','222.520635321464056','0.05757489484085293','0.057574894840853','test','test','0.8'),('2019-03-09 07:59:59','2019-03-11 07:59:59','BTCUSDT','4h','3915.690000000000055','3885.500000000000000','222.109550572300350','220.397084230026650','0.05672296595805601','0.056722965958056','test','test','0.8'),('2019-03-11 11:59:59','2019-03-11 15:59:59','BTCUSDT','4h','3873.489999999999782','3848.119999999999891','221.729002496239531','220.276755351331559','0.057242693926211126','0.057242693926211','test','test','0.7'),('2019-03-12 11:59:59','2019-03-13 11:59:59','BTCUSDT','4h','3885.179999999999836','3856.119999999999891','221.406280908482159','219.750227257634435','0.056987393353327816','0.056987393353328','test','test','0.7'),('2019-03-13 15:59:59','2019-03-13 19:59:59','BTCUSDT','4h','3872.000000000000000','3870.119999999999891','221.038268986071586','220.930946686047349','0.05708632980012179','0.057086329800122','test','test','0.0'),('2019-03-14 15:59:59','2019-03-21 15:59:59','BTCUSDT','4h','3882.099999999999909','3968.659999999999854','221.014419586066197','225.942424572895476','0.0569316657443307','0.056931665744331','test','test','0.2'),('2019-03-21 19:59:59','2019-03-24 23:59:59','BTCUSDT','4h','3979.420000000000073','3992.179999999999836','222.109531805361598','222.821725448112659','0.05581454880494183','0.055814548804942','test','test','0.0'),('2019-03-25 07:59:59','2019-03-25 15:59:59','BTCUSDT','4h','3993.719999999999800','3962.920000000000073','222.267797059306275','220.553643801334601','0.05565432655752188','0.055654326557522','test','test','0.8'),('2019-03-27 03:59:59','2019-04-12 03:59:59','BTCUSDT','4h','3991.590000000000146','4984.880000000000109','221.886874113090357','277.102468196598807','0.05558859354620348','0.055588593546203','test','test','0.0'),('2019-04-12 11:59:59','2019-04-15 23:59:59','BTCUSDT','4h','5041.359999999999673','5024.949999999999818','234.157006131647790','233.394807742597948','0.04644719007006994','0.046447190070070','test','test','0.7'),('2019-04-16 15:59:59','2019-04-25 23:59:59','BTCUSDT','4h','5069.119999999999891','5219.899999999999636','233.987628711858946','240.947545750156365','0.04615941794864966','0.046159417948650','test','test','0.0'),('2019-04-26 03:59:59','2019-04-26 07:59:59','BTCUSDT','4h','5344.390000000000327','5293.359999999999673','235.534276942591674','233.285317912210189','0.0440713115888982','0.044071311588898','test','test','1.0'),('2019-04-30 15:59:59','2019-04-30 19:59:59','BTCUSDT','4h','5312.189999999999600','5292.529999999999745','235.034508269173585','234.164663923890032','0.0442443715810567','0.044244371581057','test','test','0.4'),('2019-05-01 03:59:59','2019-05-17 15:59:59','BTCUSDT','4h','5348.949999999999818','7094.430000000000291','234.841209525777231','311.475059982979815','0.043904169888628095','0.043904169888628','test','test','0.0'),('2019-05-19 03:59:59','2019-05-22 23:59:59','BTCUSDT','4h','7903.220000000000255','7628.430000000000291','251.870954071822297','243.113559051894214','0.03186940943967424','0.031869409439674','test','test','3.5'),('2019-05-23 23:59:59','2019-05-30 23:59:59','BTCUSDT','4h','7851.510000000000218','8269.540000000000873','249.924866289616006','263.231362983251756','0.031831439594373054','0.031831439594373','test','test','0.1'),('2019-05-31 03:59:59','2019-05-31 07:59:59','BTCUSDT','4h','8263.840000000000146','8311.719999999999345','252.881865554868426','254.347042001020185','0.030601011824390165','0.030601011824390','test','test','0.0'),('2019-05-31 15:59:59','2019-06-03 07:59:59','BTCUSDT','4h','8349.520000000000437','8470.000000000000000','253.207460320679871','256.861135600149282','0.03032599003543675','0.030325990035437','test','test','0.0'),('2019-06-03 15:59:59','2019-06-03 23:59:59','BTCUSDT','4h','8473.659999999999854','8134.713599999999133','254.019388160562016','243.858612634139519','0.02997752897337892','0.029977528973379','test','test','4.0'),('2019-06-12 15:59:59','2019-06-27 23:59:59','BTCUSDT','4h','8140.569999999999709','11329.989999999999782','251.761438043579204','350.399858415242704','0.030926757959648922','0.030926757959649','test','test','0.7'),('2019-06-30 15:59:59','2019-06-30 19:59:59','BTCUSDT','4h','11164.450000000000728','11301.000000000000000','273.681087015059973','277.028421853041777','0.02451362019759683','0.024513620197597','test','test','0.0'),('2019-07-03 03:59:59','2019-07-03 11:59:59','BTCUSDT','4h','11289.479999999999563','11162.350000000000364','274.424939201278164','271.334660240630001','0.02430802297371342','0.024308022973713','test','test','1.1'),('2019-07-03 23:59:59','2019-07-04 23:59:59','BTCUSDT','4h','11940.000000000000000','11462.399999999999636','273.738210543356388','262.788682121622116','0.022926148286713265','0.022926148286713','test','test','4.0'),('2019-07-07 19:59:59','2019-07-10 23:59:59','BTCUSDT','4h','11474.180000000000291','12108.370000000000800','271.304982005193153','286.300293786764769','0.023644825338733848','0.023644825338734','test','test','1.1'),('2019-07-20 19:59:59','2019-07-20 23:59:59','BTCUSDT','4h','10898.659999999999854','10740.229999999999563','274.637273512209106','270.644967738605828','0.025199178019335324','0.025199178019335','test','test','1.5'),('2019-07-31 15:59:59','2019-08-01 07:59:59','BTCUSDT','4h','10049.639999999999418','9960.190000000000509','273.750094451408415','271.313495135544542','0.027239791122011178','0.027239791122011','test','test','0.9'),('2019-08-01 15:59:59','2019-08-11 11:59:59','BTCUSDT','4h','10013.860000000000582','11469.940000000000509','273.208627936771961','312.934929179866515','0.027283048488472173','0.027283048488472','test','test','0.0'),('2019-08-13 11:59:59','2019-08-13 15:59:59','BTCUSDT','4h','11280.389999999999418','10951.090000000000146','282.036694879681875','273.803408297934311','0.025002388647882023','0.025002388647882','test','test','2.9'),('2019-08-19 15:59:59','2019-08-19 19:59:59','BTCUSDT','4h','10707.799999999999272','10685.879999999999200','280.207075639293521','279.633462096080791','0.026168501058975096','0.026168501058975','test','test','0.2'),('2019-08-20 03:59:59','2019-08-20 11:59:59','BTCUSDT','4h','10788.840000000000146','10708.819999999999709','280.079605963023994','278.002276975926065','0.025960122308146566','0.025960122308147','test','test','0.7'),('2019-08-20 15:59:59','2019-08-20 19:59:59','BTCUSDT','4h','10744.540000000000873','10734.100000000000364','279.617977299224492','279.346284729509648','0.026024192501421604','0.026024192501422','test','test','0.1'),('2019-09-02 19:59:59','2019-09-06 23:59:59','BTCUSDT','4h','10163.680000000000291','10298.729999999999563','279.557601172621219','283.272225603768447','0.027505549286540035','0.027505549286540','test','test','0.0'),('2019-09-07 19:59:59','2019-09-08 11:59:59','BTCUSDT','4h','10465.719999999999345','10387.000000000000000','280.383073268431701','278.274116070294269','0.026790614813737776','0.026790614813738','test','test','0.8'),('2019-09-09 11:59:59','2019-09-09 15:59:59','BTCUSDT','4h','10413.260000000000218','10321.100000000000364','279.914416113290031','277.437102324044304','0.02688057497011407','0.026880574970114','test','test','0.9'),('2019-09-12 15:59:59','2019-09-12 19:59:59','BTCUSDT','4h','10326.520000000000437','10300.629999999999200','279.363901937902085','278.663498372986453','0.027053053878547863','0.027053053878548','test','test','0.3'),('2019-09-12 23:59:59','2019-09-13 11:59:59','BTCUSDT','4h','10415.010000000000218','10305.450000000000728','279.208256701254129','276.271144148871599','0.026808256228390958','0.026808256228391','test','test','1.3'),('2019-09-13 23:59:59','2019-09-14 15:59:59','BTCUSDT','4h','10342.059999999999491','10356.319999999999709','278.555565022946951','278.939647338967859','0.026934243760232193','0.026934243760232','test','test','0.6'),('2019-09-14 19:59:59','2019-09-15 07:59:59','BTCUSDT','4h','10363.729999999999563','10308.420000000000073','278.640916648729387','277.153843066163915','0.026886161319209338','0.026886161319209','test','test','0.6'),('2019-09-15 15:59:59','2019-09-15 23:59:59','BTCUSDT','4h','10307.969999999999345','10302.010000000000218','278.310455852603695','278.149538589856377','0.02699954072941653','0.026999540729417','test','test','0.1'),('2019-10-09 15:59:59','2019-10-11 11:59:59','BTCUSDT','4h','8550.000000000000000','8297.500000000000000','278.274696460882126','270.056642559551960','0.03254674812407978','0.032546748124080','test','test','3.0'),('2019-10-13 15:59:59','2019-10-13 23:59:59','BTCUSDT','4h','8403.799999999999272','8275.010000000000218','276.448462260586496','272.211831515621043','0.03289564985608731','0.032895649856087','test','test','1.5'),('2019-10-20 19:59:59','2019-10-21 15:59:59','BTCUSDT','4h','8235.000000000000000','8191.250000000000000','275.506988761705259','274.043305609510412','0.0334556149073109','0.033455614907311','test','test','0.5'),('2019-10-22 11:59:59','2019-10-22 19:59:59','BTCUSDT','4h','8276.159999999999854','8167.909999999999854','275.181725838995305','271.582421110465248','0.033249928208129775','0.033249928208130','test','test','1.3'),('2019-10-25 15:59:59','2019-11-07 15:59:59','BTCUSDT','4h','8263.159999999999854','9191.930000000000291','274.381880343766454','305.222098735626219','0.03320544202747695','0.033205442027477','test','test','0.0'),('2019-11-08 07:59:59','2019-11-08 11:59:59','BTCUSDT','4h','9144.399999999999636','9026.270000000000437','281.235262208624135','277.602183873828608','0.030754916911839392','0.030754916911839','test','test','1.3'),('2019-11-29 15:59:59','2019-11-30 15:59:59','BTCUSDT','4h','7807.989999999999782','7539.399999999999636','280.427911467558431','270.781365718771383','0.0359155059711345','0.035915505971134','test','test','3.4'),('2019-12-18 23:59:59','2019-12-19 07:59:59','BTCUSDT','4h','7277.829999999999927','7092.539999999999964','278.284234634494680','271.199253831779345','0.03823725404887098','0.038237254048871','test','test','2.5'),('2019-12-19 11:59:59','2019-12-19 15:59:59','BTCUSDT','4h','7150.000000000000000','7145.840000000000146','276.709794456113457','276.548799666611728','0.038700670553302584','0.038700670553303','test','test','0.1'),('2019-12-22 19:59:59','2019-12-24 19:59:59','BTCUSDT','4h','7398.350000000000364','7253.770000000000437','276.674017836224209','271.267200167587077','0.03739671924634874','0.037396719246349','test','test','2.0'),('2019-12-26 19:59:59','2019-12-26 23:59:59','BTCUSDT','4h','7301.380000000000109','7202.000000000000000','275.472502798749304','271.723011972612369','0.0377288269886993','0.037728826988699','test','test','1.4'),('2019-12-28 03:59:59','2019-12-30 15:59:59','BTCUSDT','4h','7288.000000000000000','7262.079999999999927','274.639282615163324','273.662519414643953','0.037683765452135476','0.037683765452135','test','test','0.4');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:49:24
