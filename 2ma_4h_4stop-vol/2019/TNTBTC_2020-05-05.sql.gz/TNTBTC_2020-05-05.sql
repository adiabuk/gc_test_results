-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 11:59:59','2019-01-07 23:59:59','TNTBTC','4h','0.000003240000000','0.000003180000000','0.033333333333333','0.032716049382716','10288.0658436214','10288.065843621399836','test','test','1.9'),('2019-01-09 11:59:59','2019-01-10 07:59:59','TNTBTC','4h','0.000003410000000','0.000003273600000','0.033196159122085','0.031868312757202','9734.94402407188','9734.944024071879539','test','test','4.0'),('2019-01-12 15:59:59','2019-01-13 19:59:59','TNTBTC','4h','0.000003280000000','0.000003148800000','0.032901082152111','0.031585038866027','10030.817729302167','10030.817729302167209','test','test','4.0'),('2019-01-14 19:59:59','2019-01-20 15:59:59','TNTBTC','4h','0.000003300000000','0.000004210000000','0.032608628088537','0.041600704319012','9881.402451071786','9881.402451071786345','test','test','0.0'),('2019-01-21 15:59:59','2019-01-23 23:59:59','TNTBTC','4h','0.000004500000000','0.000004390000000','0.034606867250865','0.033760921606955','7690.414944636593','7690.414944636592736','test','test','3.3'),('2019-01-24 15:59:59','2019-01-27 03:59:59','TNTBTC','4h','0.000004500000000','0.000004320000000','0.034418879329996','0.033042124156796','7648.639851110173','7648.639851110173367','test','test','4.0'),('2019-02-01 15:59:59','2019-02-01 19:59:59','TNTBTC','4h','0.000004230000000','0.000004150000000','0.034112933735951','0.033467771868604','8064.523341832466','8064.523341832466031','test','test','1.9'),('2019-02-09 19:59:59','2019-02-09 23:59:59','TNTBTC','4h','0.000004060000000','0.000004000000000','0.033969564432096','0.033467551164627','8366.88779115676','8366.887791156759704','test','test','1.5'),('2019-02-10 03:59:59','2019-02-10 07:59:59','TNTBTC','4h','0.000004140000000','0.000004130000000','0.033858005928214','0.033776223305199','8178.262301501072','8178.262301501072216','test','test','0.2'),('2019-02-10 11:59:59','2019-02-11 19:59:59','TNTBTC','4h','0.000004150000000','0.000004050000000','0.033839832011989','0.033024414373146','8154.176388431058','8154.176388431057603','test','test','2.7'),('2019-02-18 15:59:59','2019-02-18 19:59:59','TNTBTC','4h','0.000004020000000','0.000003910000000','0.033658628092246','0.032737620855891','8372.793057772637','8372.793057772636530','test','test','2.7'),('2019-02-18 23:59:59','2019-02-19 03:59:59','TNTBTC','4h','0.000003950000000','0.000003900000000','0.033453959817500','0.033030491971709','8469.356915822898','8469.356915822898372','test','test','1.3'),('2019-02-19 19:59:59','2019-02-20 07:59:59','TNTBTC','4h','0.000003960000000','0.000003900000000','0.033359855851769','0.032854403490379','8424.206023174018','8424.206023174017901','test','test','1.5'),('2019-02-20 23:59:59','2019-02-21 11:59:59','TNTBTC','4h','0.000004070000000','0.000003930000000','0.033247533104794','0.032103883317406','8168.927052774829','8168.927052774828553','test','test','3.4'),('2019-02-21 23:59:59','2019-02-24 07:59:59','TNTBTC','4h','0.000004020000000','0.000004040000000','0.032993388707596','0.033157534920072','8207.310623780157','8207.310623780156675','test','test','0.2'),('2019-02-26 11:59:59','2019-02-27 15:59:59','TNTBTC','4h','0.000004160000000','0.000004000000000','0.033029865643702','0.031759486195867','7939.871548966826','7939.871548966825685','test','test','3.8'),('2019-03-02 03:59:59','2019-03-02 07:59:59','TNTBTC','4h','0.000004100000000','0.000004020000000','0.032747559099739','0.032108582336817','7987.209536521626','7987.209536521626433','test','test','2.0'),('2019-03-04 03:59:59','2019-03-04 07:59:59','TNTBTC','4h','0.000004060000000','0.000004040000000','0.032605564263534','0.032444945720364','8030.927158505856','8030.927158505855914','test','test','0.5'),('2019-03-04 11:59:59','2019-03-04 15:59:59','TNTBTC','4h','0.000004040000000','0.000004190000000','0.032569871253940','0.033779148651982','8061.849320282288','8061.849320282288318','test','test','0.0'),('2019-03-04 19:59:59','2019-03-05 19:59:59','TNTBTC','4h','0.000004130000000','0.000004210000000','0.032838599564616','0.033474698345529','7951.23476140834','7951.234761408340091','test','test','0.0'),('2019-03-08 11:59:59','2019-03-11 15:59:59','TNTBTC','4h','0.000004250000000','0.000004270000000','0.032979954849264','0.033135154636790','7759.989376297358','7759.989376297357921','test','test','0.5'),('2019-03-11 23:59:59','2019-03-12 01:59:59','TNTBTC','4h','0.000004710000000','0.000004521600000','0.033014443690936','0.031693865943299','7009.436027799623','7009.436027799622934','test','test','4.0'),('2019-03-12 11:59:59','2019-03-21 15:59:59','TNTBTC','4h','0.000004610000000','0.000004570000000','0.032720981969239','0.032437068893584','7097.826891375078','7097.826891375078048','test','test','0.9'),('2019-03-26 03:59:59','2019-03-26 07:59:59','TNTBTC','4h','0.000004740000000','0.000004670000000','0.032657890174649','0.032175600657302','6889.850247816267','6889.850247816267256','test','test','1.5'),('2019-03-26 15:59:59','2019-04-02 07:59:59','TNTBTC','4h','0.000004820000000','0.000004880000000','0.032550714726350','0.032955910345350','6753.260316670078','6753.260316670078282','test','test','0.2'),('2019-04-20 15:59:59','2019-04-20 19:59:59','TNTBTC','4h','0.000004070000000','0.000004030000000','0.032640758197239','0.032319964504883','8019.842308903848','8019.842308903847879','test','test','1.0'),('2019-05-21 19:59:59','2019-05-26 23:59:59','TNTBTC','4h','0.000003550000000','0.000003520000000','0.032569470710048','0.032294235746301','9174.49879156294','9174.498791562940823','test','test','0.8'),('2019-05-28 03:59:59','2019-05-28 07:59:59','TNTBTC','4h','0.000003570000000','0.000003640000000','0.032508307384771','0.033145725176629','9105.96845511802','9105.968455118019847','test','test','0.0'),('2019-05-28 11:59:59','2019-05-29 07:59:59','TNTBTC','4h','0.000003950000000','0.000003792000000','0.032649955782962','0.031343957551644','8265.81159062329','8265.811590623290613','test','test','4.0'),('2019-05-31 11:59:59','2019-06-01 03:59:59','TNTBTC','4h','0.000003770000000','0.000003619200000','0.032359733953780','0.031065344595629','8583.483807368757','8583.483807368756970','test','test','4.0'),('2019-06-01 15:59:59','2019-06-01 23:59:59','TNTBTC','4h','0.000003640000000','0.000003670000000','0.032072091874191','0.032336422301726','8811.014251151404','8811.014251151404096','test','test','0.0'),('2019-06-02 15:59:59','2019-06-02 19:59:59','TNTBTC','4h','0.000004180000000','0.000004012800000','0.032130831969199','0.030845598690431','7686.801906506909','7686.801906506909290','test','test','4.0'),('2019-06-03 11:59:59','2019-06-03 15:59:59','TNTBTC','4h','0.000003690000000','0.000003630000000','0.031845224573917','0.031327416044260','8630.142160953146','8630.142160953146231','test','test','1.6'),('2019-06-05 11:59:59','2019-06-13 23:59:59','TNTBTC','4h','0.000003810000000','0.000004100000000','0.031730156011771','0.034145312243638','8328.124937472732','8328.124937472732199','test','test','2.4'),('2019-06-14 07:59:59','2019-06-14 11:59:59','TNTBTC','4h','0.000004140000000','0.000003974400000','0.032266857396630','0.030976183100765','7793.926907398657','7793.926907398657022','test','test','4.0'),('2019-06-20 15:59:59','2019-06-20 19:59:59','TNTBTC','4h','0.000003990000000','0.000004100000000','0.031980040886438','0.032861696148971','8015.047841212588','8015.047841212587628','test','test','0.0'),('2019-06-20 23:59:59','2019-06-22 03:59:59','TNTBTC','4h','0.000004870000000','0.000004675200000','0.032175964278112','0.030888925706988','6606.974184417294','6606.974184417294055','test','test','4.0'),('2019-06-25 11:59:59','2019-06-25 15:59:59','TNTBTC','4h','0.000004280000000','0.000004210000000','0.031889955706751','0.031368391010613','7450.924230549376','7450.924230549376261','test','test','1.6'),('2019-06-25 19:59:59','2019-06-25 23:59:59','TNTBTC','4h','0.000004500000000','0.000004320000000','0.031774052440943','0.030503090343305','7060.900542431752','7060.900542431752001','test','test','4.0'),('2019-06-26 03:59:59','2019-06-26 07:59:59','TNTBTC','4h','0.000004930000000','0.000004770000000','0.031491616419246','0.030469576129778','6387.7518091775955','6387.751809177595533','test','test','3.2'),('2019-06-26 11:59:59','2019-06-26 19:59:59','TNTBTC','4h','0.000004800000000','0.000004608000000','0.031264496354919','0.030013916500722','6513.436740608193','6513.436740608192849','test','test','4.0'),('2019-06-26 23:59:59','2019-07-04 07:59:59','TNTBTC','4h','0.000004500000000','0.000005480000000','0.030986589720653','0.037734780370929','6885.90882681185','6885.908826811850304','test','test','0.4'),('2019-07-22 03:59:59','2019-07-23 07:59:59','TNTBTC','4h','0.000004470000000','0.000004350000000','0.032486187642937','0.031614075222992','7267.6034995384525','7267.603499538452525','test','test','2.7'),('2019-07-23 15:59:59','2019-07-23 19:59:59','TNTBTC','4h','0.000004420000000','0.000004370000000','0.032292384882949','0.031927086411422','7305.9694305314715','7305.969430531471517','test','test','1.1'),('2019-07-29 07:59:59','2019-07-29 11:59:59','TNTBTC','4h','0.000004350000000','0.000004330000000','0.032211207444832','0.032063109939339','7404.875274674021','7404.875274674021057','test','test','0.5'),('2019-07-29 19:59:59','2019-07-30 03:59:59','TNTBTC','4h','0.000004320000000','0.000004290000000','0.032178296888056','0.031954836493000','7448.679835198094','7448.679835198094224','test','test','0.7'),('2019-08-19 03:59:59','2019-08-19 07:59:59','TNTBTC','4h','0.000003080000000','0.000002956800000','0.032128639022488','0.030843493461588','10431.376306002521','10431.376306002521233','test','test','4.0'),('2019-08-19 15:59:59','2019-08-19 19:59:59','TNTBTC','4h','0.000003160000000','0.000003050000000','0.031843051120066','0.030734590479811','10076.914911413147','10076.914911413146910','test','test','3.5'),('2019-08-21 11:59:59','2019-08-23 15:59:59','TNTBTC','4h','0.000003130000000','0.000003110000000','0.031596726533342','0.031394830517155','10094.80080937451','10094.800809374510209','test','test','0.6'),('2019-08-24 07:59:59','2019-08-25 15:59:59','TNTBTC','4h','0.000003300000000','0.000003400000000','0.031551860751967','0.032507977744451','9561.169924838585','9561.169924838584848','test','test','0.0'),('2019-08-26 15:59:59','2019-08-26 19:59:59','TNTBTC','4h','0.000003290000000','0.000003240000000','0.031764331194742','0.031281590599077','9654.811913295303','9654.811913295303384','test','test','1.5'),('2019-08-31 07:59:59','2019-09-01 03:59:59','TNTBTC','4h','0.000003260000000','0.000003240000000','0.031657055506816','0.031462840442357','9710.75322294969','9710.753222949690098','test','test','1.8'),('2019-09-10 15:59:59','2019-09-10 19:59:59','TNTBTC','4h','0.000002920000000','0.000002850000000','0.031613896603603','0.030856029219270','10826.676919042084','10826.676919042083682','test','test','2.4'),('2019-09-16 07:59:59','2019-09-16 11:59:59','TNTBTC','4h','0.000002790000000','0.000002770000000','0.031445481629307','0.031220065990387','11270.78194598805','11270.781945988050211','test','test','0.7'),('2019-09-17 11:59:59','2019-09-17 15:59:59','TNTBTC','4h','0.000002790000000','0.000002770000000','0.031395389265102','0.031170332711230','11252.827693585023','11252.827693585022644','test','test','0.7'),('2019-09-17 19:59:59','2019-09-18 03:59:59','TNTBTC','4h','0.000002810000000','0.000002830000000','0.031345376697575','0.031568475464106','11154.938326539183','11154.938326539182526','test','test','0.0'),('2019-09-18 07:59:59','2019-10-10 11:59:59','TNTBTC','4h','0.000002940000000','0.000006620000000','0.031394954201249','0.070692039732064','10678.555850764851','10678.555850764851129','test','test','0.0'),('2019-10-11 15:59:59','2019-10-13 07:59:59','TNTBTC','4h','0.000007120000000','0.000006835200000','0.040127639874763','0.038522534279772','5635.904476792572','5635.904476792571586','test','test','4.0'),('2019-10-14 19:59:59','2019-10-23 15:59:59','TNTBTC','4h','0.000006840000000','0.000009090000000','0.039770949742543','0.052853498999958','5814.466336629076','5814.466336629076068','test','test','0.0'),('2019-10-24 03:59:59','2019-10-25 15:59:59','TNTBTC','4h','0.000009960000000','0.000009561600000','0.042678182910857','0.040971055594423','4284.958123580054','4284.958123580054234','test','test','4.0'),('2019-10-25 19:59:59','2019-10-25 23:59:59','TNTBTC','4h','0.000009310000000','0.000009760000000','0.042298821284983','0.044343340036674','4543.375003757584','4543.375003757583727','test','test','0.0'),('2019-11-07 11:59:59','2019-11-07 15:59:59','TNTBTC','4h','0.000007720000000','0.000007700000000','0.042753158785359','0.042642399306640','5537.973935927316','5537.973935927316234','test','test','0.3'),('2019-11-08 07:59:59','2019-11-08 15:59:59','TNTBTC','4h','0.000007650000000','0.000007344000000','0.042728545567866','0.041019403745151','5585.430793185068','5585.430793185068069','test','test','4.0'),('2019-11-11 07:59:59','2019-11-11 11:59:59','TNTBTC','4h','0.000007570000000','0.000007530000000','0.042348736273929','0.042124964880143','5594.284844640569','5594.284844640568735','test','test','0.5'),('2019-11-11 15:59:59','2019-11-12 19:59:59','TNTBTC','4h','0.000007750000000','0.000007560000000','0.042299009297532','0.041262001327657','5457.936683552543','5457.936683552543400','test','test','3.2'),('2019-11-13 11:59:59','2019-11-18 19:59:59','TNTBTC','4h','0.000007860000000','0.000008490000000','0.042068563082004','0.045440470809951','5352.2344888046355','5352.234488804635475','test','test','0.0'),('2019-11-21 03:59:59','2019-11-21 07:59:59','TNTBTC','4h','0.000008340000000','0.000008170000000','0.042817875910437','0.041945089471016','5134.037878949294','5134.037878949294281','test','test','2.0'),('2019-11-23 11:59:59','2019-11-24 11:59:59','TNTBTC','4h','0.000008470000000','0.000008360000000','0.042623923368344','0.042070365922002','5032.340421292037','5032.340421292036808','test','test','1.3'),('2019-11-25 07:59:59','2019-12-04 07:59:59','TNTBTC','4h','0.000008420000000','0.000009260000000','0.042500910602490','0.046740906434567','5047.614085806386','5047.614085806386356','test','test','0.0'),('2019-12-04 15:59:59','2019-12-05 11:59:59','TNTBTC','4h','0.000009240000000','0.000009100000000','0.043443131898507','0.042784902627318','4701.637651353559','4701.637651353558795','test','test','1.5'),('2020-01-01 03:59:59','2020-01-01 15:59:59','TNTBTC','4h','0.000006190000000','0.000006640000000','0.043296858727132','0.046444449426197','6994.64599792109','6994.645997921090384','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:18:16
