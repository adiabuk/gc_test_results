-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 19:59:59','2019-01-02 23:59:59','MDABTC','4h','0.000224100000000','0.000223340000000','0.033333333333333','0.033220288561654','148.74312063067083','148.743120630670830','test','test','0.3'),('2019-01-03 03:59:59','2019-01-03 07:59:59','MDABTC','4h','0.000219770000000','0.000218340000000','0.033308212272960','0.033091482311863','151.55941335469','151.559413354690008','test','test','0.7'),('2019-01-03 15:59:59','2019-01-03 19:59:59','MDABTC','4h','0.000225740000000','0.000216990000000','0.033260050059383','0.031970843724575','147.33786683522246','147.337866835222457','test','test','3.9'),('2019-01-05 15:59:59','2019-01-05 19:59:59','MDABTC','4h','0.000225110000000','0.000216105600000','0.032973559762759','0.031654617372249','146.47754325778115','146.477543257781150','test','test','4.0'),('2019-01-17 07:59:59','2019-01-18 03:59:59','MDABTC','4h','0.000211360000000','0.000202905600000','0.032680461453757','0.031373242995607','154.61989711277863','154.619897112778631','test','test','4.0'),('2019-01-19 19:59:59','2019-01-19 23:59:59','MDABTC','4h','0.000201460000000','0.000199400000000','0.032389968463057','0.032058769540026','160.77617622881405','160.776176228814052','test','test','1.0'),('2019-01-23 11:59:59','2019-01-23 15:59:59','MDABTC','4h','0.000203190000000','0.000199900000000','0.032316368702383','0.031793110407040','159.04507457248553','159.045074572485532','test','test','1.6'),('2019-01-23 19:59:59','2019-01-23 23:59:59','MDABTC','4h','0.000200400000000','0.000201290000000','0.032200089081196','0.032343093468832','160.67908723151697','160.679087231516974','test','test','0.0'),('2019-01-24 03:59:59','2019-01-24 07:59:59','MDABTC','4h','0.000199150000000','0.000197500000000','0.032231867834004','0.031964819970956','161.84718972635704','161.847189726357044','test','test','0.8'),('2019-01-24 15:59:59','2019-01-24 19:59:59','MDABTC','4h','0.000200030000000','0.000199290000000','0.032172523864438','0.032053503379212','160.83849354815663','160.838493548156634','test','test','0.4'),('2019-01-25 19:59:59','2019-01-25 23:59:59','MDABTC','4h','0.000201260000000','0.000197130000000','0.032146074867721','0.031486414283384','159.72411243029356','159.724112430293559','test','test','2.1'),('2019-01-26 07:59:59','2019-01-27 03:59:59','MDABTC','4h','0.000205880000000','0.000198260000000','0.031999483626757','0.030815123488638','155.4278396481305','155.427839648130487','test','test','3.7'),('2019-01-27 07:59:59','2019-01-28 11:59:59','MDABTC','4h','0.000207390000000','0.000203510000000','0.031736292484953','0.031142547295495','153.02711068495535','153.027110684955346','test','test','1.9'),('2019-01-31 15:59:59','2019-02-05 15:59:59','MDABTC','4h','0.000207030000000','0.000209070000000','0.031604349109518','0.031915767127117','152.65589097965406','152.655890979654060','test','test','0.5'),('2019-02-14 19:59:59','2019-02-15 15:59:59','MDABTC','4h','0.000209920000000','0.000201523200000','0.031673553113429','0.030406610988892','150.88392298698867','150.883922986988665','test','test','4.0'),('2019-02-18 03:59:59','2019-02-18 11:59:59','MDABTC','4h','0.000203080000000','0.000200400000000','0.031392010419087','0.030977737285725','154.5795273738778','154.579527373877795','test','test','1.3'),('2019-02-20 15:59:59','2019-02-20 23:59:59','MDABTC','4h','0.000202610000000','0.000203410000000','0.031299949722784','0.031423536711473','154.48373586093697','154.483735860936974','test','test','0.0'),('2019-02-21 15:59:59','2019-02-21 19:59:59','MDABTC','4h','0.000200540000000','0.000198720000000','0.031327413498049','0.031043101677133','156.2152862174562','156.215286217456196','test','test','0.9'),('2019-02-23 03:59:59','2019-02-24 19:59:59','MDABTC','4h','0.000207080000000','0.000207280000000','0.031264233093401','0.031294428412209','150.97659403805613','150.976594038056135','test','test','0.0'),('2019-02-24 23:59:59','2019-03-02 11:59:59','MDABTC','4h','0.000217700000000','0.000227270000000','0.031270943164247','0.032645600610650','143.64236639525438','143.642366395254385','test','test','0.0'),('2019-03-07 19:59:59','2019-03-08 23:59:59','MDABTC','4h','0.000230410000000','0.000221193600000','0.031576422596781','0.030313365692910','137.0444971866711','137.044497186671094','test','test','4.0'),('2019-03-09 19:59:59','2019-03-12 19:59:59','MDABTC','4h','0.000240210000000','0.000253770000000','0.031295743284810','0.033062406949695','130.28493103871426','130.284931038714262','test','test','1.4'),('2019-03-12 23:59:59','2019-03-13 03:59:59','MDABTC','4h','0.000281530000000','0.000270268800000','0.031688335210340','0.030420801801926','112.55757898035576','112.557578980355757','test','test','4.0'),('2019-03-13 07:59:59','2019-03-14 15:59:59','MDABTC','4h','0.000297500000000','0.000285600000000','0.031406661119581','0.030150394674798','105.56860880531389','105.568608805313886','test','test','4.0'),('2019-03-18 11:59:59','2019-03-18 19:59:59','MDABTC','4h','0.000279460000000','0.000268281600000','0.031127490798518','0.029882391166577','111.38442281012667','111.384422810126665','test','test','4.0'),('2019-03-22 19:59:59','2019-03-28 03:59:59','MDABTC','4h','0.000262010000000','0.000279870000000','0.030850801991420','0.032953757312082','117.74665849173694','117.746658491736937','test','test','0.0'),('2019-03-29 15:59:59','2019-04-02 07:59:59','MDABTC','4h','0.000291830000000','0.000280156800000','0.031318125396012','0.030065400380172','107.31633278282409','107.316332782824091','test','test','4.0'),('2019-05-22 19:59:59','2019-05-22 23:59:59','MDABTC','4h','0.000129390000000','0.000124214400000','0.031039742059158','0.029798152376792','239.89289789905104','239.892897899051036','test','test','4.0'),('2019-05-23 11:59:59','2019-05-23 15:59:59','MDABTC','4h','0.000127800000000','0.000130970000000','0.030763833240855','0.031526911107627','240.71856995973917','240.718569959739170','test','test','0.0'),('2019-05-30 07:59:59','2019-05-30 11:59:59','MDABTC','4h','0.000121100000000','0.000119690000000','0.030933406100137','0.030573240100127','255.4368794396146','255.436879439614586','test','test','1.2'),('2019-06-01 19:59:59','2019-06-01 23:59:59','MDABTC','4h','0.000119600000000','0.000116550000000','0.030853369211246','0.030066556702096','257.97131447530285','257.971314475302847','test','test','2.6'),('2019-06-02 11:59:59','2019-06-02 15:59:59','MDABTC','4h','0.000119510000000','0.000123930000000','0.030678521986991','0.031813147266737','256.7025519788358','256.702551978835800','test','test','0.0'),('2019-06-02 19:59:59','2019-06-03 03:59:59','MDABTC','4h','0.000122400000000','0.000118860000000','0.030930660938045','0.030036097705033','252.70147825200436','252.701478252004364','test','test','2.9'),('2019-06-04 23:59:59','2019-06-12 15:59:59','MDABTC','4h','0.000120960000000','0.000126300000000','0.030731869108487','0.032088583568137','254.06637821169898','254.066378211698975','test','test','0.4'),('2019-07-08 11:59:59','2019-07-08 15:59:59','MDABTC','4h','0.000079550000000','0.000077470000000','0.031033361210632','0.030221929515873','390.1113917112703','390.111391711270301','test','test','2.6'),('2019-07-23 19:59:59','2019-07-23 23:59:59','MDABTC','4h','0.000070100000000','0.000067296000000','0.030853043056241','0.029618921333991','440.1290022288254','440.129002228825414','test','test','4.0'),('2019-07-24 11:59:59','2019-07-24 23:59:59','MDABTC','4h','0.000069800000000','0.000067008000000','0.030578793784630','0.029355642033245','438.0916014989907','438.091601498990713','test','test','4.0'),('2019-07-26 15:59:59','2019-07-26 19:59:59','MDABTC','4h','0.000066640000000','0.000073690000000','0.030306982284322','0.033513228159239','454.78664892439633','454.786648924396331','test','test','0.0'),('2019-07-26 23:59:59','2019-07-27 03:59:59','MDABTC','4h','0.000066860000000','0.000066730000000','0.031019481367637','0.030959168286904','463.9467748674344','463.946774867434385','test','test','0.2'),('2019-07-28 19:59:59','2019-07-29 15:59:59','MDABTC','4h','0.000069590000000','0.000066806400000','0.031006078460807','0.029765835322375','445.5536493865082','445.553649386508198','test','test','4.0'),('2019-07-29 19:59:59','2019-07-29 23:59:59','MDABTC','4h','0.000067030000000','0.000067020000000','0.030730468874489','0.030725884290143','458.45843464849895','458.458434648498951','test','test','0.0'),('2019-07-30 19:59:59','2019-07-31 15:59:59','MDABTC','4h','0.000069960000000','0.000067161600000','0.030729450077968','0.029500272074849','439.24314005099416','439.243140050994157','test','test','4.0'),('2019-07-31 19:59:59','2019-07-31 23:59:59','MDABTC','4h','0.000067390000000','0.000066150000000','0.030456299410608','0.029895892654870','451.94093204641297','451.940932046412968','test','test','1.8'),('2019-08-01 23:59:59','2019-08-02 03:59:59','MDABTC','4h','0.000067680000000','0.000068940000000','0.030331764575999','0.030896451682467','448.164370212756','448.164370212756012','test','test','0.0'),('2019-08-03 15:59:59','2019-08-03 23:59:59','MDABTC','4h','0.000068000000000','0.000067500000000','0.030457250599659','0.030233300227603','447.90074411263066','447.900744112630662','test','test','0.7'),('2019-08-04 19:59:59','2019-08-04 23:59:59','MDABTC','4h','0.000067510000000','0.000067220000000','0.030407483850313','0.030276863641209','450.4145141506904','450.414514150690422','test','test','0.4'),('2019-08-15 11:59:59','2019-08-15 15:59:59','MDABTC','4h','0.000060510000000','0.000058620000000','0.030378457137179','0.029429601014401','502.04027660186557','502.040276601865571','test','test','3.1'),('2019-08-20 19:59:59','2019-08-20 23:59:59','MDABTC','4h','0.000064940000000','0.000062342400000','0.030167600221006','0.028960896212166','464.54573792740985','464.545737927409846','test','test','4.0'),('2019-08-21 03:59:59','2019-08-26 11:59:59','MDABTC','4h','0.000059890000000','0.000061030000000','0.029899443774597','0.030468576616525','499.2393350241627','499.239335024162699','test','test','0.0'),('2019-08-26 15:59:59','2019-08-28 07:59:59','MDABTC','4h','0.000064200000000','0.000062950000000','0.030025917739470','0.029441300961054','467.6934227331775','467.693422733177499','test','test','1.9'),('2019-09-01 19:59:59','2019-09-01 23:59:59','MDABTC','4h','0.000062290000000','0.000060250000000','0.029896002899822','0.028916907604981','479.9486739415957','479.948673941595700','test','test','3.3'),('2019-09-09 19:59:59','2019-09-12 23:59:59','MDABTC','4h','0.000061770000000','0.000060260000000','0.029678426167635','0.028952921496870','480.4666693805263','480.466669380526298','test','test','2.4'),('2019-09-17 11:59:59','2019-09-17 15:59:59','MDABTC','4h','0.000063310000000','0.000061980000000','0.029517202907465','0.028897113192303','466.23286854312283','466.232868543122834','test','test','2.1'),('2019-09-18 07:59:59','2019-09-18 11:59:59','MDABTC','4h','0.000063800000000','0.000062540000000','0.029379405192985','0.028799184965036','460.4922444041483','460.492244404148323','test','test','2.0'),('2019-09-18 15:59:59','2019-09-18 19:59:59','MDABTC','4h','0.000063550000000','0.000064130000000','0.029250467364552','0.029517426783457','460.2748601817711','460.274860181771089','test','test','0.0'),('2019-09-24 19:59:59','2019-09-24 23:59:59','MDABTC','4h','0.000063670000000','0.000061870000000','0.029309791679864','0.028481181266424','460.33911857803946','460.339118578039461','test','test','2.8'),('2019-09-25 03:59:59','2019-10-07 23:59:59','MDABTC','4h','0.000064500000000','0.000111790000000','0.029125656032433','0.050479954850631','451.5605586423669','451.560558642366914','test','test','0.0'),('2019-10-08 03:59:59','2019-10-08 07:59:59','MDABTC','4h','0.000115390000000','0.000113040000000','0.033871055769810','0.033181247458353','293.5354516839414','293.535451683941403','test','test','2.0'),('2019-10-09 11:59:59','2019-10-09 15:59:59','MDABTC','4h','0.000120840000000','0.000116006400000','0.033717765033931','0.032369054432574','279.0281780365','279.028178036499980','test','test','4.0'),('2019-10-11 15:59:59','2019-10-15 19:59:59','MDABTC','4h','0.000114160000000','0.000109593600000','0.033418051566962','0.032081329504284','292.72995416049787','292.729954160497869','test','test','4.0'),('2019-11-06 19:59:59','2019-11-06 23:59:59','MDABTC','4h','0.000082730000000','0.000080650000000','0.033121002219701','0.032288273045073','400.3505647250171','400.350564725017080','test','test','2.5'),('2019-11-09 11:59:59','2019-11-12 19:59:59','MDABTC','4h','0.000083070000000','0.000081260000000','0.032935951292006','0.032218314698308','396.4843059107445','396.484305910744524','test','test','2.2'),('2019-11-22 15:59:59','2019-11-22 19:59:59','MDABTC','4h','0.000080790000000','0.000079760000000','0.032776476493406','0.032358605831341','405.6996719074885','405.699671907488494','test','test','1.3'),('2019-11-23 19:59:59','2019-11-24 15:59:59','MDABTC','4h','0.000081070000000','0.000079200000000','0.032683616346280','0.031929720175470','403.15303251856966','403.153032518569660','test','test','2.3'),('2019-11-26 03:59:59','2019-11-26 23:59:59','MDABTC','4h','0.000082700000000','0.000081270000000','0.032516083863878','0.031953834771673','393.1811833600751','393.181183360075124','test','test','1.7'),('2019-11-27 19:59:59','2019-11-27 23:59:59','MDABTC','4h','0.000080310000000','0.000080080000000','0.032391139621166','0.032298374559370','403.32635563648364','403.326355636483640','test','test','0.3'),('2019-12-12 23:59:59','2019-12-13 15:59:59','MDABTC','4h','0.000075710000000','0.000073760000000','0.032370525162989','0.031536784256004','427.5594394794493','427.559439479449281','test','test','2.6'),('2019-12-17 19:59:59','2019-12-17 23:59:59','MDABTC','4h','0.000073280000000','0.000072520000000','0.032185249405881','0.031851450421868','439.20918949073854','439.209189490738538','test','test','1.0'),('2019-12-18 03:59:59','2019-12-18 11:59:59','MDABTC','4h','0.000073470000000','0.000072840000000','0.032111071853878','0.031835721707316','437.0637247023062','437.063724702306217','test','test','0.9'),('2019-12-26 11:59:59','2019-12-26 15:59:59','MDABTC','4h','0.000071990000000','0.000069120000000','0.032049882932420','0.030772161526446','445.1990961580806','445.199096158080579','test','test','4.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:56:27
