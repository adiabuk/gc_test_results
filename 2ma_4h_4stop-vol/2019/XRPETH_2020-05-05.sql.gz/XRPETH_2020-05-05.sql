-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 07:59:59','2019-01-14 19:59:59','XRPETH','4h','0.002576340000000','0.002596400000000','1.297777777777778','1.307882586235599','503.7292351854871','503.729235185487084','test','test','0.0'),('2019-01-15 15:59:59','2019-01-15 19:59:59','XRPETH','4h','0.002590000000000','0.002603960000000','1.300023290768405','1.307030366111698','501.93949450517556','501.939494505175560','test','test','0.0'),('2019-01-15 23:59:59','2019-01-19 11:59:59','XRPETH','4h','0.002702650000000','0.002648540000000','1.301580418622470','1.275521359383700','481.59414597616035','481.594145976160348','test','test','2.0'),('2019-01-20 11:59:59','2019-01-27 11:59:59','XRPETH','4h','0.002680000000000','0.002688090000000','1.295789516569410','1.299701060296666','483.503550958735','483.503550958734991','test','test','0.0'),('2019-01-27 15:59:59','2019-01-27 23:59:59','XRPETH','4h','0.002713340000000','0.002735430000000','1.296658748508800','1.307215181449220','477.88288548755406','477.882885487554063','test','test','0.3'),('2019-01-28 03:59:59','2019-02-03 07:59:59','XRPETH','4h','0.002754280000000','0.002812130000000','1.299004622495560','1.326288492476596','471.6312874854989','471.631287485498888','test','test','0.9'),('2019-02-03 19:59:59','2019-02-03 23:59:59','XRPETH','4h','0.002805030000000','0.002816620000000','1.305067704713568','1.310460065828291','465.2598028233452','465.259802823345183','test','test','0.0'),('2019-02-05 19:59:59','2019-02-05 23:59:59','XRPETH','4h','0.002815070000000','0.002793970000000','1.306266007183507','1.296475056069832','464.0261191314982','464.026119131498206','test','test','0.7'),('2019-02-06 03:59:59','2019-02-06 19:59:59','XRPETH','4h','0.002829350000000','0.002793490000000','1.304090240269356','1.287561823489509','460.9151360804978','460.915136080497803','test','test','1.3'),('2019-02-25 19:59:59','2019-02-27 03:59:59','XRPETH','4h','0.002380130000000','0.002309270000000','1.300417258762724','1.261701908359206','546.3639627930928','546.363962793092810','test','test','3.0'),('2019-02-27 23:59:59','2019-02-28 03:59:59','XRPETH','4h','0.002300420000000','0.002287290000000','1.291813847561942','1.284440621882071','561.5556496474305','561.555649647430528','test','test','0.6'),('2019-03-01 11:59:59','2019-03-05 15:59:59','XRPETH','4h','0.002343980000000','0.002341950000000','1.290175352966415','1.289057998737061','550.4208026375717','550.420802637571683','test','test','0.4'),('2019-03-10 15:59:59','2019-03-10 23:59:59','XRPETH','4h','0.002319560000000','0.002310030000000','1.289927052026559','1.284627337940347','556.1085085216847','556.108508521684712','test','test','0.4'),('2019-03-11 07:59:59','2019-03-12 11:59:59','XRPETH','4h','0.002316800000000','0.002319890000000','1.288749337785178','1.290468189414044','556.2626630633539','556.262663063353898','test','test','0.0'),('2019-03-12 15:59:59','2019-03-15 07:59:59','XRPETH','4h','0.002324780000000','0.002332830000000','1.289131304813815','1.293595171073741','554.5175478169183','554.517547816918295','test','test','0.0'),('2019-04-02 03:59:59','2019-04-02 07:59:59','XRPETH','4h','0.002251270000000','0.002201400000000','1.290123275093799','1.261544540544443','573.0646591007736','573.064659100773611','test','test','2.2'),('2019-04-26 19:59:59','2019-04-26 23:59:59','XRPETH','4h','0.001921600000000','0.001921710000000','1.283772445193942','1.283845933416762','668.0747529110854','668.074752911085397','test','test','0.0'),('2019-04-30 11:59:59','2019-05-01 03:59:59','XRPETH','4h','0.001933450000000','0.001894390000000','1.283788775910124','1.257853380845835','663.9886089167674','663.988608916767362','test','test','2.0'),('2019-05-14 07:59:59','2019-05-15 19:59:59','XRPETH','4h','0.001834520000000','0.001787590000000','1.278025354784726','1.245331391295613','696.6538139593606','696.653813959360605','test','test','2.6'),('2019-05-15 23:59:59','2019-05-16 03:59:59','XRPETH','4h','0.001842670000000','0.001768963200000','1.270760029564923','1.219929628382326','689.629738132668','689.629738132667967','test','test','4.0'),('2019-05-27 23:59:59','2019-05-28 03:59:59','XRPETH','4h','0.001600790000000','0.001589290000000','1.259464384857680','1.250416452008360','786.7767695061061','786.776769506106120','test','test','0.7'),('2019-05-28 07:59:59','2019-05-28 11:59:59','XRPETH','4h','0.001584000000000','0.001590700000000','1.257453733113386','1.262772508373398','793.8470537331985','793.847053733198550','test','test','0.0'),('2019-05-28 15:59:59','2019-05-30 03:59:59','XRPETH','4h','0.001638620000000','0.001601300000000','1.258635683171167','1.229969925584937','768.1071164584632','768.107116458463224','test','test','2.3'),('2019-05-30 07:59:59','2019-06-01 03:59:59','XRPETH','4h','0.001638090000000','0.001618740000000','1.252265514818671','1.237473081123489','764.4668576321637','764.466857632163737','test','test','1.2'),('2019-06-02 15:59:59','2019-06-04 19:59:59','XRPETH','4h','0.001635040000000','0.001650030000000','1.248978307330853','1.260428904763876','763.8824171462797','763.882417146279749','test','test','0.0'),('2019-06-04 23:59:59','2019-06-05 07:59:59','XRPETH','4h','0.001652930000000','0.001632710000000','1.251522884538191','1.236213226703097','757.1541956030754','757.154195603075436','test','test','1.2'),('2019-06-06 15:59:59','2019-06-09 19:59:59','XRPETH','4h','0.001675050000000','0.001634780000000','1.248120738352615','1.218114576068827','745.1244669428465','745.124466942846539','test','test','2.4'),('2019-06-10 03:59:59','2019-06-10 07:59:59','XRPETH','4h','0.001656150000000','0.001649190000000','1.241452702289551','1.236235475101232','749.6016075171639','749.601607517163870','test','test','0.4'),('2019-06-17 07:59:59','2019-06-17 11:59:59','XRPETH','4h','0.001598430000000','0.001591290000000','1.240293318469925','1.234753073170553','775.9447198000067','775.944719800006737','test','test','0.4'),('2019-06-17 23:59:59','2019-06-18 19:59:59','XRPETH','4h','0.001638130000000','0.001613210000000','1.239062152847842','1.220212959652572','756.388169954669','756.388169954669024','test','test','1.5'),('2019-07-14 15:59:59','2019-07-25 03:59:59','XRPETH','4h','0.001300820000000','0.001435720000000','1.234873443248893','1.362934533556757','949.3038569893554','949.303856989355381','test','test','0.0'),('2019-07-26 19:59:59','2019-07-31 19:59:59','XRPETH','4h','0.001472340000000','0.001465690000000','1.263331463317307','1.257625475412978','858.0432938840943','858.043293884094282','test','test','1.5'),('2019-08-01 03:59:59','2019-08-01 11:59:59','XRPETH','4h','0.001477350000000','0.001461720000000','1.262063466005234','1.248711144636796','854.2751995161839','854.275199516183875','test','test','1.1'),('2019-08-10 11:59:59','2019-08-11 03:59:59','XRPETH','4h','0.001438460000000','0.001420800000000','1.259096283478915','1.243638335140944','875.3085129088851','875.308512908885064','test','test','1.2'),('2019-08-13 15:59:59','2019-08-13 19:59:59','XRPETH','4h','0.001433330000000','0.001415350000000','1.255661183848255','1.239909899715786','876.0447237190699','876.044723719069907','test','test','1.3'),('2019-08-15 11:59:59','2019-08-15 15:59:59','XRPETH','4h','0.001435060000000','0.001420810000000','1.252160898485484','1.239727067981242','872.5495090696442','872.549509069644159','test','test','1.0'),('2019-08-15 19:59:59','2019-08-15 23:59:59','XRPETH','4h','0.001421640000000','0.001403940000000','1.249397825040097','1.233842310631942','878.8426219296703','878.842621929670258','test','test','1.2'),('2019-08-18 11:59:59','2019-08-19 11:59:59','XRPETH','4h','0.001484760000000','0.001426240000000','1.245941044060507','1.196833801207507','839.1531588004167','839.153158800416691','test','test','3.9'),('2019-08-21 15:59:59','2019-08-21 23:59:59','XRPETH','4h','0.001432120000000','0.001418480000000','1.235028323426506','1.223265491868021','862.3776802408363','862.377680240836298','test','test','1.0'),('2019-08-23 15:59:59','2019-08-23 19:59:59','XRPETH','4h','0.001421050000000','0.001419960000000','1.232414360857954','1.231469051647627','867.2561562632942','867.256156263294201','test','test','0.1'),('2019-08-25 07:59:59','2019-08-26 07:59:59','XRPETH','4h','0.001448830000000','0.001429220000000','1.232204292144548','1.215526333951416','850.482314795075','850.482314795075013','test','test','1.4'),('2019-08-26 19:59:59','2019-08-27 15:59:59','XRPETH','4h','0.001434360000000','0.001427240000000','1.228498079212741','1.222399954387736','856.4782057591826','856.478205759182629','test','test','0.5'),('2019-08-28 19:59:59','2019-09-02 19:59:59','XRPETH','4h','0.001481320000000','0.001465270000000','1.227142940362740','1.213846931267594','828.4117816290471','828.411781629047141','test','test','1.1'),('2019-09-05 11:59:59','2019-09-05 23:59:59','XRPETH','4h','0.001490250000000','0.001473790000000','1.224188271674930','1.210666957162754','821.4650371916994','821.465037191699366','test','test','1.1'),('2019-09-06 19:59:59','2019-09-07 11:59:59','XRPETH','4h','0.001477450000000','0.001468380000000','1.221183535116668','1.213686743574817','826.5481303033392','826.548130303339235','test','test','0.6'),('2019-09-07 15:59:59','2019-09-07 19:59:59','XRPETH','4h','0.001487280000000','0.001465280000000','1.219517581440702','1.201478350904626','819.9650243671008','819.965024367100796','test','test','1.5'),('2019-09-18 03:59:59','2019-09-19 03:59:59','XRPETH','4h','0.001441180000000','0.001424280000000','1.215508863543796','1.201255196552934','843.4122479799858','843.412247979985750','test','test','1.4'),('2019-09-24 19:59:59','2019-09-27 23:59:59','XRPETH','4h','0.001417480000000','0.001392240000000','1.212341381990271','1.190754131036865','855.2793563156241','855.279356315624113','test','test','1.8'),('2019-09-30 11:59:59','2019-09-30 15:59:59','XRPETH','4h','0.001499870000000','0.001439875200000','1.207544215111736','1.159242446507266','805.099252009665','805.099252009664951','test','test','4.0'),('2019-09-30 23:59:59','2019-10-01 03:59:59','XRPETH','4h','0.001419120000000','0.001410980000000','1.196810488755187','1.189945644782537','843.3469253869914','843.346925386991416','test','test','0.6'),('2019-10-01 15:59:59','2019-10-01 19:59:59','XRPETH','4h','0.001413530000000','0.001408490000000','1.195284967872376','1.191023129610665','845.6028297046233','845.602829704623332','test','test','0.4'),('2019-10-02 15:59:59','2019-10-02 23:59:59','XRPETH','4h','0.001419830000000','0.001401270000000','1.194337892703107','1.178725522709115','841.1837281245693','841.183728124569257','test','test','1.3'),('2019-10-03 15:59:59','2019-10-03 23:59:59','XRPETH','4h','0.001414710000000','0.001413020000000','1.190868477148886','1.189445876243837','841.775683460841','841.775683460841037','test','test','0.1'),('2019-10-04 11:59:59','2019-10-09 15:59:59','XRPETH','4h','0.001442560000000','0.001472330000000','1.190552343614431','1.215121680951804','825.3052515073421','825.305251507342064','test','test','1.2'),('2019-10-13 07:59:59','2019-10-23 19:59:59','XRPETH','4h','0.001531070000000','0.001662010000000','1.196012196356070','1.298297419755956','781.1610157315275','781.161015731527527','test','test','0.5'),('2019-10-24 03:59:59','2019-10-25 15:59:59','XRPETH','4h','0.001683660000000','0.001655970000000','1.218742246000489','1.198698429082730','723.8648218764412','723.864821876441169','test','test','1.6'),('2019-11-05 07:59:59','2019-11-05 11:59:59','XRPETH','4h','0.001620680000000','0.001607000000000','1.214288064463209','1.204038378700531','749.2460352834669','749.246035283466881','test','test','0.8'),('2019-11-06 23:59:59','2019-11-07 03:59:59','XRPETH','4h','0.001625170000000','0.001596750000000','1.212010356515947','1.190815445009961','745.774507599788','745.774507599787967','test','test','1.7'),('2019-11-21 15:59:59','2019-11-25 03:59:59','XRPETH','4h','0.001497950000000','0.001529670000000','1.207300376181284','1.232865694070713','805.9684076112579','805.968407611257931','test','test','0.0'),('2019-11-25 07:59:59','2019-11-25 11:59:59','XRPETH','4h','0.001551880000000','0.001517620000000','1.212981557934490','1.186203232178094','781.6207167657874','781.620716765787392','test','test','2.2'),('2019-11-27 03:59:59','2019-11-27 07:59:59','XRPETH','4h','0.001509540000000','0.001491990000000','1.207030818877513','1.192997808244273','799.6017454837324','799.601745483732429','test','test','1.2'),('2019-12-05 19:59:59','2019-12-10 15:59:59','XRPETH','4h','0.001492250000000','0.001519640000000','1.203912372070127','1.226009982973796','806.7765937812878','806.776593781287829','test','test','0.0'),('2019-12-10 19:59:59','2019-12-12 23:59:59','XRPETH','4h','0.001519510000000','0.001509510000000','1.208822952270942','1.200867605137518','795.5347133424209','795.534713342420901','test','test','0.7'),('2019-12-13 03:59:59','2019-12-13 07:59:59','XRPETH','4h','0.001516890000000','0.001513760000000','1.207055097352403','1.204564420734644','795.7433283576287','795.743328357628684','test','test','0.2'),('2019-12-14 15:59:59','2019-12-14 23:59:59','XRPETH','4h','0.001520200000000','0.001524310000000','1.206501613659568','1.209763501327073','793.6466344293962','793.646634429396158','test','test','0.1'),('2019-12-15 11:59:59','2019-12-16 03:59:59','XRPETH','4h','0.001525420000000','0.001507610000000','1.207226477585680','1.193131537460468','791.4059587429562','791.405958742956159','test','test','1.2'),('2019-12-16 19:59:59','2019-12-17 03:59:59','XRPETH','4h','0.001570440000000','0.001507622400000','1.204094268668966','1.155930497922207','766.7241465251562','766.724146525156243','test','test','4.0'),('2019-12-20 19:59:59','2019-12-20 23:59:59','XRPETH','4h','0.001510890000000','0.001522910000000','1.193391208503020','1.202885322784143','789.8597571649955','789.859757164995472','test','test','0.0'),('2019-12-25 03:59:59','2019-12-25 07:59:59','XRPETH','4h','0.001505980000000','0.001503020000000','1.195501011676603','1.193151257367407','793.8359152688633','793.835915268863346','test','test','0.2'),('2019-12-28 19:59:59','2019-12-29 03:59:59','XRPETH','4h','0.001504540000000','0.001498490000000','1.194978844052337','1.190173639799531','794.248636827427','794.248636827427049','test','test','0.4');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:00:51
