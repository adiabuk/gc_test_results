-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 23:59:59','2019-01-14 03:59:59','WAVESBNB','4h','0.476700000000000','0.461900000000000','3.111111111111111','3.014521129058574','6.526350138684941','6.526350138684941','test','test','3.1'),('2019-01-14 07:59:59','2019-01-14 15:59:59','WAVESBNB','4h','0.468500000000000','0.468900000000000','3.089646670654992','3.092284576030151','6.5947634378975275','6.594763437897528','test','test','0.0'),('2019-01-22 23:59:59','2019-01-24 23:59:59','WAVESBNB','4h','0.427900000000000','0.422000000000000','3.090232871849471','3.047623911943157','7.221857611239709','7.221857611239709','test','test','1.4'),('2019-01-28 19:59:59','2019-02-01 03:59:59','WAVESBNB','4h','0.451700000000000','0.433800000000000','3.080764214092513','2.958679468836246','6.820376829959073','6.820376829959073','test','test','4.0'),('2019-03-21 11:59:59','2019-03-22 11:59:59','WAVESBNB','4h','0.187300000000000','0.183900000000000','3.053634270702231','2.998202575451897','16.303439779510043','16.303439779510043','test','test','1.8'),('2019-03-30 03:59:59','2019-03-30 07:59:59','WAVESBNB','4h','0.173900000000000','0.171000000000000','3.041316116202157','2.990598366133231','17.48887933411246','17.488879334112461','test','test','1.7'),('2019-04-07 03:59:59','2019-04-07 15:59:59','WAVESBNB','4h','0.163400000000000','0.159400000000000','3.030045505075729','2.955870584510840','18.54373014122233','18.543730141222330','test','test','2.4'),('2019-04-08 19:59:59','2019-04-08 23:59:59','WAVESBNB','4h','0.163900000000000','0.158800000000000','3.013562189394642','2.919790577644107','18.38659053932058','18.386590539320579','test','test','3.1'),('2019-04-11 15:59:59','2019-04-11 19:59:59','WAVESBNB','4h','0.164900000000000','0.158304000000000','2.992724053450079','2.873015091312075','18.148720760764583','18.148720760764583','test','test','4.0'),('2019-05-07 15:59:59','2019-05-07 23:59:59','WAVESBNB','4h','0.110200000000000','0.105792000000000','2.966122061863856','2.847477179389302','26.91580818388254','26.915808183882540','test','test','4.0'),('2019-05-08 03:59:59','2019-05-08 07:59:59','WAVESBNB','4h','0.099800000000000','0.099900000000000','2.939756532425067','2.942702180253149','29.45647828081229','29.456478280812291','test','test','0.0'),('2019-05-08 11:59:59','2019-05-13 07:59:59','WAVESBNB','4h','0.106300000000000','0.105800000000000','2.940411120831307','2.926580400601621','27.661440459372592','27.661440459372592','test','test','3.9'),('2019-05-23 23:59:59','2019-05-24 03:59:59','WAVESBNB','4h','0.105000000000000','0.100800000000000','2.937337627446932','2.819844122349055','27.97464407092317','27.974644070923169','test','test','4.0'),('2019-07-06 15:59:59','2019-07-06 23:59:59','WAVESBNB','4h','0.061900000000000','0.059424000000000','2.911227959647404','2.794778841261508','47.03114635940879','47.031146359408787','test','test','4.0'),('2019-07-07 03:59:59','2019-07-08 03:59:59','WAVESBNB','4h','0.064400000000000','0.061824000000000','2.885350377783872','2.769936362672517','44.803577294780624','44.803577294780624','test','test','4.0'),('2019-07-16 15:59:59','2019-07-17 03:59:59','WAVESBNB','4h','0.058390000000000','0.056054400000000','2.859702818870237','2.745314706115427','48.975900306049624','48.975900306049624','test','test','4.0'),('2019-07-29 11:59:59','2019-07-31 07:59:59','WAVESBNB','4h','0.051870000000000','0.050420000000000','2.834283238258057','2.755052262829598','54.642052019627094','54.642052019627094','test','test','3.9'),('2019-07-31 15:59:59','2019-07-31 23:59:59','WAVESBNB','4h','0.050140000000000','0.049560000000000','2.816676354829511','2.784094139316924','56.17623364239152','56.176233642391523','test','test','1.2'),('2019-08-05 03:59:59','2019-08-05 11:59:59','WAVESBNB','4h','0.050360000000000','0.048800000000000','2.809435862493380','2.722408063734649','55.78705048636577','55.787050486365771','test','test','3.1'),('2019-08-05 19:59:59','2019-08-06 11:59:59','WAVESBNB','4h','0.050960000000000','0.048990000000000','2.790096351658107','2.682237446384040','54.75071333709001','54.750713337090012','test','test','3.9'),('2019-08-07 07:59:59','2019-08-07 11:59:59','WAVESBNB','4h','0.050050000000000','0.049000000000000','2.766127706041647','2.708097054865948','55.26728683399895','55.267286833998952','test','test','2.1'),('2019-08-18 11:59:59','2019-08-18 23:59:59','WAVESBNB','4h','0.045520000000000','0.045140000000000','2.753232005780381','2.730248083060774','60.4840071568625','60.484007156862504','test','test','1.4'),('2019-08-20 15:59:59','2019-08-20 23:59:59','WAVESBNB','4h','0.045050000000000','0.044250000000000','2.748124467398246','2.699323145002717','61.00165299441167','61.001652994411671','test','test','1.8'),('2019-08-21 15:59:59','2019-08-22 03:59:59','WAVESBNB','4h','0.045170000000000','0.045070000000000','2.737279729088128','2.731219778392781','60.599506953467525','60.599506953467525','test','test','0.2'),('2019-08-22 15:59:59','2019-08-28 03:59:59','WAVESBNB','4h','0.047710000000000','0.048450000000000','2.735933073378051','2.778368421822816','57.34506546589921','57.345065465899211','test','test','2.5'),('2019-08-28 11:59:59','2019-08-28 19:59:59','WAVESBNB','4h','0.048490000000000','0.048560000000000','2.745363150810221','2.749326347769526','56.61709941864758','56.617099418647577','test','test','0.0'),('2019-08-29 07:59:59','2019-09-02 15:59:59','WAVESBNB','4h','0.051550000000000','0.050490000000000','2.746243861245622','2.689774055369378','53.27340177004117','53.273401770041168','test','test','3.4'),('2019-09-03 07:59:59','2019-09-03 15:59:59','WAVESBNB','4h','0.049910000000000','0.050840000000000','2.733695015495346','2.784633431933147','54.77249079333492','54.772490793334917','test','test','0.0'),('2019-09-03 23:59:59','2019-09-05 19:59:59','WAVESBNB','4h','0.051320000000000','0.049267200000000','2.745014663592635','2.635214077048929','53.48820466860162','53.488204668601618','test','test','4.0'),('2019-09-11 19:59:59','2019-09-11 23:59:59','WAVESBNB','4h','0.049850000000000','0.049180000000000','2.720614533249590','2.684048600706416','54.57601872115526','54.576018721155258','test','test','1.3'),('2019-09-12 07:59:59','2019-09-12 11:59:59','WAVESBNB','4h','0.050970000000000','0.050630000000000','2.712488770462217','2.694394868520739','53.21735865140705','53.217358651407046','test','test','0.7'),('2019-09-12 15:59:59','2019-09-13 07:59:59','WAVESBNB','4h','0.049990000000000','0.049370000000000','2.708467903364111','2.674876183018327','54.18019410610344','54.180194106103443','test','test','1.7'),('2019-09-13 19:59:59','2019-09-14 15:59:59','WAVESBNB','4h','0.049180000000000','0.048440000000000','2.701003076620603','2.660361712718625','54.92076202969913','54.920762029699127','test','test','1.5'),('2019-09-15 15:59:59','2019-09-18 11:59:59','WAVESBNB','4h','0.050330000000000','0.052880000000000','2.691971662420164','2.828362040706900','53.48642285754349','53.486422857543488','test','test','0.0'),('2019-09-18 15:59:59','2019-09-19 15:59:59','WAVESBNB','4h','0.051560000000000','0.050520000000000','2.722280635372772','2.667370397576269','52.798305573560356','52.798305573560356','test','test','2.0'),('2019-09-19 19:59:59','2019-09-19 23:59:59','WAVESBNB','4h','0.050840000000000','0.049980000000000','2.710078360306882','2.664235177972815','53.30602596984426','53.306025969844256','test','test','1.7'),('2019-09-22 23:59:59','2019-09-24 15:59:59','WAVESBNB','4h','0.054190000000000','0.052022400000000','2.699890986454867','2.591895346996672','49.82267921119888','49.822679211198881','test','test','4.0'),('2019-09-24 19:59:59','2019-09-24 23:59:59','WAVESBNB','4h','0.051460000000000','0.052300000000000','2.675891955464158','2.719571497683161','51.99945502262258','51.999455022622577','test','test','0.0'),('2019-09-28 07:59:59','2019-10-01 07:59:59','WAVESBNB','4h','0.054000000000000','0.052770000000000','2.685598520401713','2.624426554103674','49.73330593336507','49.733305933365067','test','test','2.3'),('2019-10-03 03:59:59','2019-10-09 07:59:59','WAVESBNB','4h','0.055610000000000','0.053490000000000','2.672004750113260','2.570140875446112','48.04899748450387','48.048997484503872','test','test','3.8'),('2019-11-17 07:59:59','2019-11-17 11:59:59','WAVESBNB','4h','0.038420000000000','0.038500000000000','2.649368333520561','2.654884977629921','68.95805136701095','68.958051367010953','test','test','0.0'),('2019-11-18 11:59:59','2019-11-18 19:59:59','WAVESBNB','4h','0.039490000000000','0.038180000000000','2.650594254433752','2.562666210034962','67.12064457922897','67.120644579228966','test','test','3.3'),('2019-11-19 11:59:59','2019-11-20 07:59:59','WAVESBNB','4h','0.038520000000000','0.038490000000000','2.631054689011799','2.629005580998550','68.30360044163548','68.303600441635481','test','test','0.1'),('2019-11-20 11:59:59','2019-11-21 15:59:59','WAVESBNB','4h','0.038510000000000','0.038950000000000','2.630599331675521','2.660655517236082','68.30951263764013','68.309512637640125','test','test','0.0'),('2019-11-22 03:59:59','2019-11-23 19:59:59','WAVESBNB','4h','0.039540000000000','0.038980000000000','2.637278484022313','2.599927043682088','66.69900060754458','66.699000607544576','test','test','1.4'),('2019-11-28 15:59:59','2019-11-29 11:59:59','WAVESBNB','4h','0.039080000000000','0.038630000000000','2.628978163946706','2.598705897473420','67.27170327396895','67.271703273968953','test','test','1.2'),('2019-12-01 19:59:59','2019-12-02 11:59:59','WAVESBNB','4h','0.038920000000000','0.038920000000000','2.622250993619310','2.622250993619310','67.37541093574794','67.375410935747936','test','test','0.2'),('2019-12-02 15:59:59','2019-12-02 19:59:59','WAVESBNB','4h','0.038960000000000','0.038840000000000','2.622250993619310','2.614174245179004','67.30623700254901','67.306237002549011','test','test','0.3'),('2019-12-02 23:59:59','2019-12-03 07:59:59','WAVESBNB','4h','0.038880000000000','0.038750000000000','2.620456160632575','2.611694347338279','67.39856380227818','67.398563802278176','test','test','0.3'),('2019-12-03 11:59:59','2019-12-03 15:59:59','WAVESBNB','4h','0.039180000000000','0.038220000000000','2.618509091011620','2.554349603329865','66.83279966849466','66.832799668494658','test','test','2.5'),('2019-12-11 11:59:59','2019-12-15 03:59:59','WAVESBNB','4h','0.037890000000000','0.047550000000000','2.604251427082342','3.268201513796922','68.73189303463556','68.731893034635561','test','test','0.0'),('2019-12-15 07:59:59','2020-01-01 15:59:59','WAVESBNB','4h','0.049370000000000','0.075800000000000','2.751795890796693','4.224957029013355','55.73821938012342','55.738219380123418','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:42:23
