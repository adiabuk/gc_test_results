-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 15:59:59','2019-01-12 23:59:59','XVGETH','4h','0.000057520000000','0.000055219200000','1.297777777777778','1.245866666666667','22562.20058723536','22562.200587235358398','test','test','4.0'),('2019-01-15 15:59:59','2019-01-27 11:59:59','XVGETH','4h','0.000055350000000','0.000056570000000','1.286241975308642','1.314592746941461','23238.337403950172','23238.337403950172302','test','test','1.2'),('2019-01-27 19:59:59','2019-01-27 23:59:59','XVGETH','4h','0.000056220000000','0.000056990000000','1.292542146782602','1.310245054164719','22990.788807943823','22990.788807943823485','test','test','0.0'),('2019-01-28 03:59:59','2019-01-28 07:59:59','XVGETH','4h','0.000057070000000','0.000056520000000','1.296476126200850','1.283981612981812','22717.296761886282','22717.296761886282184','test','test','1.0'),('2019-01-28 11:59:59','2019-01-29 11:59:59','XVGETH','4h','0.000057450000000','0.000057470000000','1.293699567707731','1.294149941795706','22518.704398742047','22518.704398742047488','test','test','1.4'),('2019-01-29 15:59:59','2019-01-30 15:59:59','XVGETH','4h','0.000057510000000','0.000057030000000','1.293799650838392','1.283001114368171','22496.95097962774','22496.950979627741617','test','test','1.0'),('2019-03-02 07:59:59','2019-03-02 11:59:59','XVGETH','4h','0.000044750000000','0.000044600000000','1.291399976067231','1.287071261063654','28858.10002384875','28858.100023848750425','test','test','0.3'),('2019-03-02 15:59:59','2019-03-03 03:59:59','XVGETH','4h','0.000045280000000','0.000045260000000','1.290438039399770','1.289868057933604','28499.073308298804','28499.073308298804477','test','test','0.0'),('2019-03-03 11:59:59','2019-03-05 23:59:59','XVGETH','4h','0.000045220000000','0.000046020000000','1.290311376851733','1.313138645792056','28534.086175403205','28534.086175403204834','test','test','0.0'),('2019-03-08 11:59:59','2019-03-10 07:59:59','XVGETH','4h','0.000047270000000','0.000046240000000','1.295384103282916','1.267158048144744','27403.937027351716','27403.937027351716097','test','test','2.2'),('2019-03-12 11:59:59','2019-03-18 19:59:59','XVGETH','4h','0.000049210000000','0.000049580000000','1.289111646585544','1.298804215356864','26196.131814378055','26196.131814378055424','test','test','0.2'),('2019-03-19 15:59:59','2019-03-20 03:59:59','XVGETH','4h','0.000049680000000','0.000049920000000','1.291265550756949','1.297503548586693','25991.657623932144','25991.657623932143906','test','test','0.6'),('2019-03-20 11:59:59','2019-03-20 15:59:59','XVGETH','4h','0.000049790000000','0.000049500000000','1.292651772496892','1.285122770407635','25962.07616985121','25962.076169851210580','test','test','0.6'),('2019-03-21 11:59:59','2019-03-24 15:59:59','XVGETH','4h','0.000050240000000','0.000050230000000','1.290978660921501','1.290721698608420','25696.231308150902','25696.231308150901896','test','test','0.3'),('2019-03-27 11:59:59','2019-03-29 11:59:59','XVGETH','4h','0.000051650000000','0.000050490000000','1.290921558185261','1.261928934613240','24993.641010363233','24993.641010363233363','test','test','2.2'),('2019-03-31 11:59:59','2019-04-02 15:59:59','XVGETH','4h','0.000053700000000','0.000051552000000','1.284478752947034','1.233099602829153','23919.529850037878','23919.529850037877623','test','test','4.0'),('2019-04-03 07:59:59','2019-04-03 19:59:59','XVGETH','4h','0.000051610000000','0.000051810000000','1.273061164031950','1.277994553545734','24666.947568919775','24666.947568919775222','test','test','0.0'),('2019-04-03 23:59:59','2019-04-08 03:59:59','XVGETH','4h','0.000053460000000','0.000059300000000','1.274157472812790','1.413347140624737','23833.847228073148','23833.847228073147562','test','test','1.0'),('2019-04-08 07:59:59','2019-04-09 11:59:59','XVGETH','4h','0.000059600000000','0.000057216000000','1.305088510104334','1.252884969700161','21897.458223227084','21897.458223227084090','test','test','4.0'),('2019-04-23 11:59:59','2019-04-24 03:59:59','XVGETH','4h','0.000051250000000','0.000050490000000','1.293487723347851','1.274306246865034','25238.784845811733','25238.784845811733248','test','test','1.5'),('2019-05-15 23:59:59','2019-05-16 07:59:59','XVGETH','4h','0.000042100000000','0.000041860000000','1.289225173018336','1.281875670844360','30622.925724901103','30622.925724901102512','test','test','3.6'),('2019-05-16 11:59:59','2019-05-16 15:59:59','XVGETH','4h','0.000041340000000','0.000039710000000','1.287591950313008','1.236823327211648','31146.39454071138','31146.394540711378795','test','test','3.9'),('2019-05-16 19:59:59','2019-05-16 23:59:59','XVGETH','4h','0.000040480000000','0.000041050000000','1.276310034068262','1.294281790970903','31529.39807480884','31529.398074808839738','test','test','0.0'),('2019-05-19 15:59:59','2019-05-20 23:59:59','XVGETH','4h','0.000043720000000','0.000041971200000','1.280303757824404','1.229091607511428','29284.166464419126','29284.166464419125987','test','test','4.0'),('2019-05-22 15:59:59','2019-05-22 23:59:59','XVGETH','4h','0.000046620000000','0.000044755200000','1.268923279977076','1.218166348777993','27218.431573939855','27218.431573939855298','test','test','4.0'),('2019-05-24 11:59:59','2019-05-24 15:59:59','XVGETH','4h','0.000045590000000','0.000043766400000','1.257643961932835','1.207338203455522','27585.960998746115','27585.960998746115365','test','test','4.0'),('2019-05-24 19:59:59','2019-05-25 11:59:59','XVGETH','4h','0.000043880000000','0.000043170000000','1.246464904493433','1.226296488764392','28406.219336678045','28406.219336678044783','test','test','1.6'),('2019-05-25 15:59:59','2019-05-25 19:59:59','XVGETH','4h','0.000046260000000','0.000044409600000','1.241983034331424','1.192303712958167','26847.882281267262','26847.882281267262442','test','test','4.0'),('2019-05-25 23:59:59','2019-05-26 11:59:59','XVGETH','4h','0.000043820000000','0.000043070000000','1.230943185137366','1.209875011042135','28090.898793641405','28090.898793641405064','test','test','1.7'),('2019-06-10 19:59:59','2019-06-10 23:59:59','XVGETH','4h','0.000038030000000','0.000037120000000','1.226261368671760','1.196918801080614','32244.579770490654','32244.579770490654482','test','test','2.4'),('2019-06-11 03:59:59','2019-06-11 07:59:59','XVGETH','4h','0.000037550000000','0.000037210000000','1.219740798095949','1.208696540536625','32483.110468600516','32483.110468600516469','test','test','0.9'),('2019-07-07 03:59:59','2019-07-07 07:59:59','XVGETH','4h','0.000027880000000','0.000027110000000','1.217286518638322','1.183667055964308','43661.6398363817','43661.639836381698842','test','test','2.8'),('2019-07-14 11:59:59','2019-07-15 03:59:59','XVGETH','4h','0.000025770000000','0.000025900000000','1.209815526932985','1.215918593231056','46946.663831314916','46946.663831314916024','test','test','0.2'),('2019-07-15 07:59:59','2019-07-15 15:59:59','XVGETH','4h','0.000025860000000','0.000026170000000','1.211171763888112','1.225690837623816','46835.72172807859','46835.721728078591696','test','test','0.1'),('2019-07-15 19:59:59','2019-07-23 23:59:59','XVGETH','4h','0.000026200000000','0.000026850000000','1.214398224718269','1.244526424949829','46351.07727932323','46351.077279323231778','test','test','0.0'),('2019-07-24 03:59:59','2019-07-24 07:59:59','XVGETH','4h','0.000027020000000','0.000027080000000','1.221093380325282','1.223804912628003','45192.205045347226','45192.205045347225678','test','test','0.0'),('2019-07-24 19:59:59','2019-07-24 23:59:59','XVGETH','4h','0.000027200000000','0.000026890000000','1.221695943059220','1.207772202531707','44915.29202423603','44915.292024236026919','test','test','1.1'),('2019-07-25 03:59:59','2019-07-25 11:59:59','XVGETH','4h','0.000026870000000','0.000026550000000','1.218601778497550','1.204089215448826','45351.759527262766','45351.759527262765914','test','test','1.2'),('2019-07-25 23:59:59','2019-07-29 03:59:59','XVGETH','4h','0.000027040000000','0.000027220000000','1.215376764486723','1.223467290285821','44947.36555054449','44947.365550544491271','test','test','0.0'),('2019-08-04 19:59:59','2019-08-05 03:59:59','XVGETH','4h','0.000026860000000','0.000025790000000','1.217174659108745','1.168687060998307','45315.51225274552','45315.512252745516889','test','test','4.0'),('2019-08-16 11:59:59','2019-08-20 11:59:59','XVGETH','4h','0.000024360000000','0.000025580000000','1.206399637306425','1.266818666761016','49523.79463491072','49523.794634910722380','test','test','0.0'),('2019-08-22 15:59:59','2019-08-27 11:59:59','XVGETH','4h','0.000025840000000','0.000026890000000','1.219826088296334','1.269393324856363','47206.891961932444','47206.891961932444246','test','test','0.0'),('2019-08-30 19:59:59','2019-08-30 23:59:59','XVGETH','4h','0.000026760000000','0.000026770000000','1.230841029754118','1.231300985295880','45995.55417616286','45995.554176162862859','test','test','0.0'),('2019-08-31 15:59:59','2019-08-31 23:59:59','XVGETH','4h','0.000026810000000','0.000026430000000','1.230943242096732','1.213496079396368','45913.586053589424','45913.586053589424409','test','test','1.4'),('2019-09-09 23:59:59','2019-09-10 03:59:59','XVGETH','4h','0.000025720000000','0.000024910000000','1.227066094829985','1.188422100397159','47708.63510225446','47708.635102254462254','test','test','3.1'),('2019-09-10 11:59:59','2019-09-10 15:59:59','XVGETH','4h','0.000025610000000','0.000025610000000','1.218478540511579','1.218478540511579','47578.23274156888','47578.232741568877827','test','test','0.0'),('2019-10-07 15:59:59','2019-10-09 15:59:59','XVGETH','4h','0.000019360000000','0.000019260000000','1.218478540511579','1.212184746397366','62937.94114212701','62937.941142127012426','test','test','0.5'),('2019-10-11 19:59:59','2019-10-16 03:59:59','XVGETH','4h','0.000020710000000','0.000019960000000','1.217079919597309','1.173004113721018','58767.7411683877','58767.741168387699872','test','test','3.9'),('2019-10-16 07:59:59','2019-10-16 11:59:59','XVGETH','4h','0.000020270000000','0.000019540000000','1.207285296069245','1.163806348554171','59560.20207544375','59560.202075443747162','test','test','3.6'),('2019-10-17 07:59:59','2019-10-17 15:59:59','XVGETH','4h','0.000020340000000','0.000020440000000','1.197623307732562','1.203511327927904','58880.20195341994','58880.201953419942583','test','test','0.7'),('2019-10-22 11:59:59','2019-10-22 15:59:59','XVGETH','4h','0.000020030000000','0.000020000000000','1.198931756664860','1.197136052585981','59856.80262929905','59856.802629299047112','test','test','0.1'),('2019-10-27 15:59:59','2019-10-29 23:59:59','XVGETH','4h','0.000019930000000','0.000019780000000','1.198532711313998','1.189512143993521','60137.11546984435','60137.115469844349718','test','test','0.8'),('2019-10-30 07:59:59','2019-10-31 03:59:59','XVGETH','4h','0.000021010000000','0.000020169600000','1.196528140798336','1.148667015166402','56950.411270744225','56950.411270744225476','test','test','4.0'),('2019-11-03 07:59:59','2019-11-05 15:59:59','XVGETH','4h','0.000021240000000','0.000020720000000','1.185892335102351','1.156859189421879','55832.9724624459','55832.972462445897690','test','test','2.8'),('2019-11-05 23:59:59','2019-11-08 15:59:59','XVGETH','4h','0.000020960000000','0.000020340000000','1.179440524951135','1.144552494155825','56271.017411790795','56271.017411790795450','test','test','3.0'),('2019-11-13 11:59:59','2019-11-14 11:59:59','XVGETH','4h','0.000021060000000','0.000020480000000','1.171687629218844','1.139418929078914','55635.68989643133','55635.689896431329544','test','test','2.8'),('2019-11-14 15:59:59','2019-11-21 11:59:59','XVGETH','4h','0.000021250000000','0.000022990000000','1.164516806965526','1.259870183159409','54800.79091602475','54800.790916024750913','test','test','0.0'),('2019-11-21 23:59:59','2019-11-25 07:59:59','XVGETH','4h','0.000024800000000','0.000024370000000','1.185706446119722','1.165147826287807','47810.74379515009','47810.743795150090591','test','test','2.4'),('2019-11-25 11:59:59','2019-11-25 19:59:59','XVGETH','4h','0.000024690000000','0.000024910000000','1.181137863934852','1.191662381150959','47838.714618665545','47838.714618665544549','test','test','0.0'),('2019-11-25 23:59:59','2019-11-30 11:59:59','XVGETH','4h','0.000025240000000','0.000025720000000','1.183476645538432','1.205983332933775','46888.932073630414','46888.932073630414379','test','test','1.1'),('2019-12-02 07:59:59','2019-12-03 07:59:59','XVGETH','4h','0.000026530000000','0.000025770000000','1.188478131626286','1.154432018545397','44797.51721169565','44797.517211695652804','test','test','2.9'),('2019-12-03 23:59:59','2019-12-10 03:59:59','XVGETH','4h','0.000026790000000','0.000029200000000','1.180912328719421','1.287145949929343','44080.34075100491','44080.340751004907361','test','test','1.9'),('2019-12-11 11:59:59','2019-12-12 11:59:59','XVGETH','4h','0.000029950000000','0.000028760000000','1.204519800099404','1.156660749611314','40217.68948578979','40217.689485789793252','test','test','4.0'),('2019-12-12 15:59:59','2019-12-12 19:59:59','XVGETH','4h','0.000029060000000','0.000028650000000','1.193884455546495','1.177040249532246','41083.42930304525','41083.429303045253619','test','test','1.4'),('2019-12-14 15:59:59','2019-12-16 15:59:59','XVGETH','4h','0.000031340000000','0.000030086400000','1.190141298654440','1.142535646708262','37975.15311596808','37975.153115968081693','test','test','4.0'),('2019-12-16 19:59:59','2019-12-17 07:59:59','XVGETH','4h','0.000030350000000','0.000029690000000','1.179562264888623','1.153911157975065','38865.31350539119','38865.313505391190120','test','test','2.2'),('2019-12-18 15:59:59','2019-12-19 11:59:59','XVGETH','4h','0.000030760000000','0.000029970000000','1.173862018907832','1.143714067186857','38161.96420376567','38161.964203765666753','test','test','2.6'),('2019-12-19 15:59:59','2019-12-21 23:59:59','XVGETH','4h','0.000030740000000','0.000030430000000','1.167162474080949','1.155392130328018','37968.850815905935','37968.850815905934724','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:45:43
