-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 15:59:59','2019-01-12 03:59:59','ZRXETH','4h','0.002259720000000','0.002237980000000','1.297777777777778','1.285292297767472','574.309108109756','574.309108109756039','test','test','1.0'),('2019-01-13 19:59:59','2019-01-14 15:59:59','ZRXETH','4h','0.002310750000000','0.002248650000000','1.295003226664376','1.260200803046132','560.4255010989403','560.425501098940344','test','test','2.7'),('2019-01-15 23:59:59','2019-01-26 15:59:59','ZRXETH','4h','0.002330220000000','0.002482570000000','1.287269354749211','1.371431144707259','552.4239577161002','552.423957716100176','test','test','0.0'),('2019-02-08 03:59:59','2019-02-08 07:59:59','ZRXETH','4h','0.002354000000000','0.002259840000000','1.305971974739888','1.253733095750292','554.7884344689414','554.788434468941432','test','test','4.0'),('2019-02-26 11:59:59','2019-02-26 15:59:59','ZRXETH','4h','0.001777610000000','0.001827560000000','1.294363334964423','1.330734332304376','728.1480948939433','728.148094893943266','test','test','0.0'),('2019-02-26 19:59:59','2019-02-28 11:59:59','ZRXETH','4h','0.001827100000000','0.001813540000000','1.302445778817745','1.292779551046540','712.848655693583','712.848655693583055','test','test','2.0'),('2019-03-03 19:59:59','2019-03-04 07:59:59','ZRXETH','4h','0.001843420000000','0.001795570000000','1.300297728201922','1.266545655264413','705.3724751830414','705.372475183041388','test','test','2.6'),('2019-03-09 03:59:59','2019-03-09 11:59:59','ZRXETH','4h','0.001800000000000','0.001792450000000','1.292797267549142','1.287374701232477','718.220704193968','718.220704193968004','test','test','0.4'),('2019-03-09 15:59:59','2019-03-16 03:59:59','ZRXETH','4h','0.001849400000000','0.001927160000000','1.291592252812106','1.345898629787703','698.3844775668356','698.384477566835585','test','test','1.1'),('2019-03-16 07:59:59','2019-03-16 11:59:59','ZRXETH','4h','0.001939380000000','0.001912130000000','1.303660336584461','1.285342758713220','672.20469252259','672.204692522589994','test','test','1.4'),('2019-03-19 15:59:59','2019-03-21 15:59:59','ZRXETH','4h','0.001946830000000','0.001907060000000','1.299589763724185','1.273041639387026','667.5414718923505','667.541471892350501','test','test','2.0'),('2019-03-21 19:59:59','2019-03-21 23:59:59','ZRXETH','4h','0.001925130000000','0.001917860000000','1.293690180538150','1.288804729886759','672.0014651156803','672.001465115680276','test','test','0.4'),('2019-03-22 23:59:59','2019-04-03 03:59:59','ZRXETH','4h','0.002003360000000','0.002203380000000','1.292604524837840','1.421661088340188','645.2182956821741','645.218295682174130','test','test','2.5'),('2019-04-03 07:59:59','2019-04-03 19:59:59','ZRXETH','4h','0.002212640000000','0.002200460000000','1.321283761171696','1.314010442325851','597.1526146014244','597.152614601424375','test','test','0.6'),('2019-04-03 23:59:59','2019-04-04 03:59:59','ZRXETH','4h','0.002192680000000','0.002145310000000','1.319667468094841','1.291157768565657','601.8513727925832','601.851372792583220','test','test','2.2'),('2019-06-03 07:59:59','2019-06-03 11:59:59','ZRXETH','4h','0.001286320000000','0.001276680000000','1.313331979310578','1.303489544861488','1020.9994241795027','1020.999424179502739','test','test','0.7'),('2019-06-03 15:59:59','2019-06-03 19:59:59','ZRXETH','4h','0.001275480000000','0.001283880000000','1.311144771655224','1.319779651137383','1027.961843114141','1027.961843114140947','test','test','0.0'),('2019-06-06 07:59:59','2019-06-11 07:59:59','ZRXETH','4h','0.001328100000000','0.001318410000000','1.313063633762371','1.303483341155521','988.6782876006106','988.678287600610588','test','test','2.9'),('2019-06-11 11:59:59','2019-06-11 15:59:59','ZRXETH','4h','0.001322970000000','0.001330110000000','1.310934679849738','1.318009725855413','990.9028019151891','990.902801915189116','test','test','0.0'),('2019-06-11 23:59:59','2019-06-12 03:59:59','ZRXETH','4h','0.001326800000000','0.001313400000000','1.312506912295443','1.299251265155890','989.2273984741055','989.227398474105485','test','test','1.0'),('2019-06-15 15:59:59','2019-06-15 19:59:59','ZRXETH','4h','0.001333020000000','0.001326480000000','1.309561212931098','1.303136305328384','982.4017741152408','982.401774115240755','test','test','0.5'),('2019-06-15 23:59:59','2019-06-16 03:59:59','ZRXETH','4h','0.001333000000000','0.001312990000000','1.308133455686051','1.288496733669338','981.3454281215684','981.345428121568375','test','test','1.5'),('2019-06-17 07:59:59','2019-06-17 11:59:59','ZRXETH','4h','0.001310000000000','0.001290820000000','1.303769739682336','1.284680958302865','995.2440760933866','995.244076093386639','test','test','1.5'),('2019-07-15 19:59:59','2019-07-18 15:59:59','ZRXETH','4h','0.001042710000000','0.001049060000000','1.299527788264677','1.307441783004807','1246.298384272402','1246.298384272402018','test','test','0.0'),('2019-07-20 23:59:59','2019-07-23 19:59:59','ZRXETH','4h','0.001084320000000','0.001065210000000','1.301286453762483','1.278352648122634','1200.0944866482987','1200.094486648298698','test','test','1.8'),('2019-07-24 03:59:59','2019-07-24 15:59:59','ZRXETH','4h','0.001064200000000','0.001057490000000','1.296190052509183','1.288017307487254','1217.994787172696','1217.994787172696078','test','test','0.6'),('2019-07-26 15:59:59','2019-07-27 03:59:59','ZRXETH','4h','0.001084820000000','0.001068860000000','1.294373886948755','1.275330905407391','1193.1692695090012','1193.169269509001197','test','test','1.5'),('2019-07-27 11:59:59','2019-07-29 11:59:59','ZRXETH','4h','0.001075860000000','0.001079670000000','1.290142113272896','1.294710961869897','1199.172860105307','1199.172860105307109','test','test','1.1'),('2019-07-29 15:59:59','2019-07-29 19:59:59','ZRXETH','4h','0.001074380000000','0.001054070000000','1.291157412961119','1.266749468791235','1201.7697769514682','1201.769776951468202','test','test','1.9'),('2019-07-30 23:59:59','2019-07-31 03:59:59','ZRXETH','4h','0.001066440000000','0.001039800000000','1.285733425367811','1.253615407990557','1205.6312829299452','1205.631282929945201','test','test','2.5'),('2019-08-15 23:59:59','2019-08-17 23:59:59','ZRXETH','4h','0.000923980000000','0.000925320000000','1.278596088172866','1.280450369389074','1383.7919523938456','1383.791952393845577','test','test','0.0'),('2019-08-21 23:59:59','2019-08-22 15:59:59','ZRXETH','4h','0.000919420000000','0.000904640000000','1.279008150665356','1.258447644621509','1391.1032505985906','1391.103250598590648','test','test','1.6'),('2019-08-22 19:59:59','2019-08-23 03:59:59','ZRXETH','4h','0.000925950000000','0.000908900000000','1.274439149322279','1.250972236966380','1376.358495947167','1376.358495947167057','test','test','1.8'),('2019-08-23 11:59:59','2019-08-23 15:59:59','ZRXETH','4h','0.000917310000000','0.000922330000000','1.269224279909857','1.276170138872637','1383.6372435816215','1383.637243581621533','test','test','0.0'),('2019-08-23 19:59:59','2019-08-26 03:59:59','ZRXETH','4h','0.000977140000000','0.000938054400000','1.270767804123808','1.219937091958856','1300.4971694166734','1300.497169416673387','test','test','4.0'),('2019-08-30 19:59:59','2019-09-01 15:59:59','ZRXETH','4h','0.000951930000000','0.000926520000000','1.259472090309374','1.225852826482453','1323.0721694970998','1323.072169497099821','test','test','2.7'),('2019-09-01 23:59:59','2019-09-02 19:59:59','ZRXETH','4h','0.000940250000000','0.000940460000000','1.252001142792281','1.252280770806093','1331.5619705315405','1331.561970531540510','test','test','0.0'),('2019-09-02 23:59:59','2019-09-03 15:59:59','ZRXETH','4h','0.000971970000000','0.000933091200000','1.252063282350906','1.201980751056870','1288.1707072758477','1288.170707275847690','test','test','4.0'),('2019-09-03 23:59:59','2019-09-04 15:59:59','ZRXETH','4h','0.000954690000000','0.000939960000000','1.240933830952231','1.221787348502508','1299.8290868787053','1299.829086878705311','test','test','1.6'),('2019-09-05 11:59:59','2019-09-05 19:59:59','ZRXETH','4h','0.000956360000000','0.000935070000000','1.236679057074515','1.209148736771369','1293.1103946991875','1293.110394699187509','test','test','2.2'),('2019-09-18 15:59:59','2019-09-30 03:59:59','ZRXETH','4h','0.000897620000000','0.001142630000000','1.230561208118260','1.566449224874855','1370.9155412293178','1370.915541229317796','test','test','0.0'),('2019-09-30 11:59:59','2019-09-30 15:59:59','ZRXETH','4h','0.001153990000000','0.001145570000000','1.305202989619726','1.295679675576625','1131.0349219834884','1131.034921983488402','test','test','0.7'),('2019-10-01 15:59:59','2019-10-02 15:59:59','ZRXETH','4h','0.001167000000000','0.001164530000000','1.303086697610148','1.300328664925403','1116.6124229735628','1116.612422973562843','test','test','0.2'),('2019-10-03 19:59:59','2019-10-25 15:59:59','ZRXETH','4h','0.001205310000000','0.001720930000000','1.302473801457982','1.859659539158461','1080.6131214857442','1080.613121485744159','test','test','1.1'),('2019-11-01 19:59:59','2019-11-02 03:59:59','ZRXETH','4h','0.001685000000000','0.001617600000000','1.426292854280311','1.369241140109098','846.464601946772','846.464601946771950','test','test','4.0'),('2019-11-07 11:59:59','2019-11-07 15:59:59','ZRXETH','4h','0.001654730000000','0.001609020000000','1.413614695575597','1.374565226638211','854.2872224324192','854.287222432419185','test','test','2.8'),('2019-11-07 19:59:59','2019-11-08 15:59:59','ZRXETH','4h','0.001637950000000','0.001591270000000','1.404937035811733','1.364897681233332','857.7411006512613','857.741100651261263','test','test','2.8'),('2019-11-09 11:59:59','2019-11-10 23:59:59','ZRXETH','4h','0.001670530000000','0.001627760000000','1.396039401460977','1.360297089020921','835.686519524329','835.686519524329015','test','test','2.6'),('2019-11-11 15:59:59','2019-11-12 07:59:59','ZRXETH','4h','0.001671420000000','0.001635960000000','1.388096665363187','1.358647509702863','830.489443325548','830.489443325547995','test','test','2.3'),('2019-11-21 19:59:59','2019-11-22 15:59:59','ZRXETH','4h','0.001584830000000','0.001596100000000','1.381552408549782','1.391376866469153','871.7353965723654','871.735396572365403','test','test','1.3'),('2019-11-24 07:59:59','2019-11-25 23:59:59','ZRXETH','4h','0.001702830000000','0.001634716800000','1.383735621420753','1.328386196563923','812.6093746414812','812.609374641481168','test','test','4.0'),('2019-11-26 07:59:59','2019-12-01 07:59:59','ZRXETH','4h','0.001676660000000','0.001696990000000','1.371435749230347','1.388064814623363','817.956979489191','817.956979489190985','test','test','1.4'),('2019-12-01 23:59:59','2019-12-02 07:59:59','ZRXETH','4h','0.001727080000000','0.001675470000000','1.375131097095461','1.334038318578486','796.2173709935041','796.217370993504119','test','test','3.0'),('2019-12-02 11:59:59','2019-12-02 23:59:59','ZRXETH','4h','0.001718250000000','0.001667790000000','1.365999368536134','1.325883944042415','794.9945401054175','794.994540105417514','test','test','2.9'),('2019-12-20 15:59:59','2019-12-20 19:59:59','ZRXETH','4h','0.001542410000000','0.001530360000000','1.357084829759751','1.346482673265301','879.8470119875723','879.847011987572273','test','test','0.8'),('2019-12-29 11:59:59','2019-12-29 15:59:59','ZRXETH','4h','0.001482580000000','0.001493320000000','1.354728794983207','1.364542624427904','913.7643803256532','913.764380325653178','test','test','0.0'),('2019-12-29 19:59:59','2019-12-29 23:59:59','ZRXETH','4h','0.001470100000000','0.001467000000000','1.356909645970918','1.354048330480468','923.0049969192011','923.004996919201062','test','test','0.2');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:19:21
