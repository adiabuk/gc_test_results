-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-05-23 11:59:59','2019-05-23 23:59:59','RENBTC','4h','0.000004610000000','0.000004425600000','0.033333333333333','0.032000000000000','7230.657989877079','7230.657989877078762','test','test','4.0'),('2019-05-24 11:59:59','2019-05-24 15:59:59','RENBTC','4h','0.000004500000000','0.000004320000000','0.033037037037037','0.031715555555556','7341.563786008246','7341.563786008246097','test','test','4.0'),('2019-05-29 23:59:59','2019-05-30 03:59:59','RENBTC','4h','0.000004040000000','0.000004020000000','0.032743374485597','0.032581278572302','8104.795664751704','8104.795664751703953','test','test','0.5'),('2019-05-30 23:59:59','2019-06-14 03:59:59','RENBTC','4h','0.000004260000000','0.000005810000000','0.032707353171531','0.044607915945210','7677.782434631768','7677.782434631768410','test','test','0.0'),('2019-06-14 07:59:59','2019-06-14 15:59:59','RENBTC','4h','0.000005740000000','0.000005510400000','0.035351922676793','0.033937845769721','6158.871546479675','6158.871546479675089','test','test','4.0'),('2019-06-16 11:59:59','2019-06-16 15:59:59','RENBTC','4h','0.000005820000000','0.000005587200000','0.035037683364111','0.033636176029547','6020.220509297365','6020.220509297365425','test','test','4.0'),('2019-06-16 19:59:59','2019-06-17 15:59:59','RENBTC','4h','0.000005610000000','0.000005385600000','0.034726237289763','0.033337187798172','6190.060122952427','6190.060122952427264','test','test','4.0'),('2019-06-20 23:59:59','2019-06-21 07:59:59','RENBTC','4h','0.000005450000000','0.000005310000000','0.034417559624965','0.033533438827259','6315.14855503947','6315.148555039470011','test','test','2.6'),('2019-06-22 15:59:59','2019-06-23 11:59:59','RENBTC','4h','0.000005430000000','0.000005400000000','0.034221088336586','0.034032021550196','6302.226212999265','6302.226212999265044','test','test','0.6'),('2019-06-26 15:59:59','2019-06-26 19:59:59','RENBTC','4h','0.000005510000000','0.000005289600000','0.034179073495166','0.032811910555359','6203.098637961162','6203.098637961162240','test','test','4.0'),('2019-06-26 23:59:59','2019-06-27 03:59:59','RENBTC','4h','0.000005420000000','0.000005250000000','0.033875259508542','0.032812751368975','6250.047879804838','6250.047879804837976','test','test','3.1'),('2019-06-27 07:59:59','2019-06-27 15:59:59','RENBTC','4h','0.000005640000000','0.000005580000000','0.033639146588638','0.033281283327057','5964.387693021001','5964.387693021000814','test','test','3.4'),('2019-06-27 19:59:59','2019-07-04 11:59:59','RENBTC','4h','0.000005710000000','0.000008320000000','0.033559621419398','0.048899483399193','5877.341754710723','5877.341754710722853','test','test','0.0'),('2019-07-04 19:59:59','2019-07-06 03:59:59','RENBTC','4h','0.000009380000000','0.000009004800000','0.036968479637130','0.035489740451645','3941.202519949941','3941.202519949940779','test','test','4.0'),('2019-07-06 23:59:59','2019-07-07 15:59:59','RENBTC','4h','0.000008350000000','0.000008016000000','0.036639870929245','0.035174276092075','4388.008494520346','4388.008494520346176','test','test','4.0'),('2019-07-09 19:59:59','2019-07-10 03:59:59','RENBTC','4h','0.000008000000000','0.000008400000000','0.036314183187652','0.038129892347035','4539.272898456446','4539.272898456445546','test','test','0.0'),('2019-07-10 07:59:59','2019-07-10 11:59:59','RENBTC','4h','0.000008270000000','0.000007939200000','0.036717674111959','0.035248967147481','4439.863858761656','4439.863858761656047','test','test','4.0'),('2019-07-10 15:59:59','2019-07-13 03:59:59','RENBTC','4h','0.000007900000000','0.000008150000000','0.036391294786519','0.037542918039257','4606.493010951814','4606.493010951813631','test','test','0.0'),('2019-07-19 15:59:59','2019-07-19 19:59:59','RENBTC','4h','0.000007760000000','0.000007449600000','0.036647211064906','0.035181322622310','4722.57874547752','4722.578745477519988','test','test','4.0'),('2019-07-19 23:59:59','2019-07-30 11:59:59','RENBTC','4h','0.000007810000000','0.000010690000000','0.036321458077662','0.049715286408477','4650.634837088604','4650.634837088604399','test','test','0.0'),('2019-08-02 11:59:59','2019-08-03 03:59:59','RENBTC','4h','0.000011380000000','0.000011070000000','0.039297864373399','0.038227360159361','3453.2394001229068','3453.239400122906773','test','test','2.7'),('2019-08-03 07:59:59','2019-08-03 15:59:59','RENBTC','4h','0.000011000000000','0.000010650000000','0.039059974548057','0.037817157176073','3550.9067770960814','3550.906777096081441','test','test','3.2'),('2019-08-04 19:59:59','2019-08-05 19:59:59','RENBTC','4h','0.000011550000000','0.000011220000000','0.038783792909838','0.037675684540985','3357.9041480379415','3357.904148037941468','test','test','2.9'),('2019-08-05 23:59:59','2019-08-06 07:59:59','RENBTC','4h','0.000012070000000','0.000011587200000','0.038537546605649','0.036996044741423','3192.8373326966585','3192.837332696658450','test','test','4.0'),('2019-08-06 15:59:59','2019-08-06 19:59:59','RENBTC','4h','0.000011220000000','0.000010830000000','0.038194990635821','0.036867357271474','3404.1881137095074','3404.188113709507434','test','test','3.5'),('2019-08-09 19:59:59','2019-08-09 23:59:59','RENBTC','4h','0.000010980000000','0.000010690000000','0.037899960999299','0.036898960207879','3451.726866967133','3451.726866967132992','test','test','2.6'),('2019-08-15 23:59:59','2019-08-16 03:59:59','RENBTC','4h','0.000010240000000','0.000009880000000','0.037677516378984','0.036352916193785','3679.4449588851126','3679.444958885112555','test','test','3.5'),('2019-09-18 15:59:59','2019-09-18 19:59:59','RENBTC','4h','0.000004570000000','0.000004470000000','0.037383160782273','0.036565148511326','8180.122709468855','8180.122709468854737','test','test','2.2'),('2019-09-19 15:59:59','2019-09-22 23:59:59','RENBTC','4h','0.000004960000000','0.000004880000000','0.037201380277618','0.036601358015076','7500.278281777779','7500.278281777778830','test','test','1.6'),('2019-09-27 11:59:59','2019-09-27 23:59:59','RENBTC','4h','0.000004800000000','0.000004720000000','0.037068041997053','0.036450241297102','7722.50874938602','7722.508749386020099','test','test','1.7'),('2019-09-29 19:59:59','2019-09-30 03:59:59','RENBTC','4h','0.000005100000000','0.000004896000000','0.036930752952619','0.035453522834514','7241.324108356732','7241.324108356731813','test','test','4.0'),('2019-09-30 19:59:59','2019-10-01 03:59:59','RENBTC','4h','0.000004800000000','0.000004740000000','0.036602479593040','0.036144948598127','7625.5165818834275','7625.516581883427534','test','test','1.2'),('2019-10-02 07:59:59','2019-10-03 19:59:59','RENBTC','4h','0.000005140000000','0.000004934400000','0.036500806038615','0.035040773797070','7101.3241320263305','7101.324132026330517','test','test','4.0'),('2019-10-04 15:59:59','2019-10-16 15:59:59','RENBTC','4h','0.000005070000000','0.000006740000000','0.036176354429383','0.048092431726635','7135.375627097262','7135.375627097261713','test','test','0.0'),('2019-10-20 15:59:59','2019-10-20 19:59:59','RENBTC','4h','0.000006970000000','0.000006700000000','0.038824371606550','0.037320414600270','5570.211134368756','5570.211134368755665','test','test','3.9'),('2019-10-21 07:59:59','2019-10-21 11:59:59','RENBTC','4h','0.000006830000000','0.000006820000000','0.038490158938488','0.038433804386601','5635.4551886512445','5635.455188651244498','test','test','0.1'),('2019-10-22 11:59:59','2019-10-23 15:59:59','RENBTC','4h','0.000006970000000','0.000006800000000','0.038477635704735','0.037539156785107','5520.464233104065','5520.464233104064988','test','test','2.4'),('2019-10-24 07:59:59','2019-10-25 15:59:59','RENBTC','4h','0.000007030000000','0.000006748800000','0.038269084833707','0.036738321440359','5443.6820531588755','5443.682053158875533','test','test','4.0'),('2019-11-06 15:59:59','2019-11-08 15:59:59','RENBTC','4h','0.000006360000000','0.000006105600000','0.037928915190741','0.036411758583111','5963.665910493816','5963.665910493816227','test','test','4.0'),('2019-11-09 19:59:59','2019-11-10 19:59:59','RENBTC','4h','0.000006450000000','0.000006200000000','0.037591769277934','0.036134723957084','5828.18128340062','5828.181283400619577','test','test','3.9'),('2019-11-11 11:59:59','2019-11-17 07:59:59','RENBTC','4h','0.000006360000000','0.000006610000000','0.037267981428856','0.038732917805776','5859.745507681795','5859.745507681795061','test','test','0.0'),('2019-11-17 15:59:59','2019-11-17 23:59:59','RENBTC','4h','0.000006570000000','0.000006580000000','0.037593522845950','0.037650742819840','5721.997389033419','5721.997389033418585','test','test','0.5'),('2019-11-23 19:59:59','2019-11-23 23:59:59','RENBTC','4h','0.000006410000000','0.000006420000000','0.037606238395703','0.037664906474323','5866.807862044134','5866.807862044133799','test','test','0.0'),('2019-12-14 19:59:59','2019-12-15 03:59:59','RENBTC','4h','0.000005310000000','0.000005097600000','0.037619275746507','0.036114504716647','7084.609368457127','7084.609368457126948','test','test','4.0'),('2019-12-15 07:59:59','2019-12-15 11:59:59','RENBTC','4h','0.000005010000000','0.000004970000000','0.037284882184316','0.036987198494222','7442.092252358528','7442.092252358527730','test','test','0.8'),('2019-12-15 23:59:59','2019-12-16 07:59:59','RENBTC','4h','0.000005050000000','0.000004910000000','0.037218730253184','0.036186923869927','7370.0455946899465','7370.045594689946483','test','test','2.8'),('2019-12-24 15:59:59','2019-12-25 15:59:59','RENBTC','4h','0.000004810000000','0.000004617600000','0.036989439945794','0.035509862347962','7690.112254842783','7690.112254842782932','test','test','4.0'),('2019-12-31 11:59:59','2019-12-31 15:59:59','RENBTC','4h','0.000004500000000','0.000004480000000','0.036660644924053','0.036497708724391','8146.809983122963','8146.809983122962876','test','test','0.4'),('2020-01-02 03:59:59','2020-01-05 03:59:59','RENBTC','4h','0.000004540000000','0.000004670000000','0.036624436879684','0.037673154235270','8067.056581428196','8067.056581428196296','test','test','0.7'),('2020-01-06 07:59:59','2020-01-07 19:59:59','RENBTC','4h','0.000005100000000','0.000004896000000','0.036857485180925','0.035383185773688','7226.957878612811','7226.957878612811328','test','test','4.0'),('2020-01-08 19:59:59','2020-01-13 07:59:59','RENBTC','4h','0.000005090000000','0.000005400000000','0.036529863090428','0.038754668111652','7176.790391046803','7176.790391046803052','test','test','2.4'),('2020-01-26 07:59:59','2020-01-26 11:59:59','RENBTC','4h','0.000004930000000','0.000004890000000','0.037024264206256','0.036723864496672','7509.9927396056355','7509.992739605635506','test','test','0.8'),('2020-02-02 15:59:59','2020-02-02 19:59:59','RENBTC','4h','0.000004770000000','0.000004890000000','0.036957508715237','0.037887257362161','7747.905391035034','7747.905391035033972','test','test','0.0'),('2020-02-02 23:59:59','2020-02-10 11:59:59','RENBTC','4h','0.000004950000000','0.000005710000000','0.037164119525665','0.042870125755868','7507.902934477712','7507.902934477711824','test','test','1.4'),('2020-02-11 19:59:59','2020-02-16 15:59:59','RENBTC','4h','0.000006050000000','0.000005840000000','0.038432120910154','0.037098113407487','6352.416679364334','6352.416679364334414','test','test','3.5');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:41:02
