-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 07:59:59','2019-01-15 03:59:59','GXSETH','4h','0.003955000000000','0.004097000000000','1.297777777777778','1.344373086107599','328.13597415367326','328.135974153673260','test','test','0.0'),('2019-01-15 11:59:59','2019-01-15 15:59:59','GXSETH','4h','0.004129000000000','0.004171000000000','1.308132290739960','1.321438552840003','316.8157642867426','316.815764286742592','test','test','0.0'),('2019-01-15 23:59:59','2019-01-31 15:59:59','GXSETH','4h','0.004275000000000','0.004999000000000','1.311089237873303','1.533131017573951','306.6875410229948','306.687541022994822','test','test','0.0'),('2019-02-02 11:59:59','2019-02-02 15:59:59','GXSETH','4h','0.005054000000000','0.004966000000000','1.360431855584558','1.336744082871570','269.17923537486314','269.179235374863140','test','test','1.7'),('2019-02-02 23:59:59','2019-02-03 03:59:59','GXSETH','4h','0.004961000000000','0.004963000000000','1.355167906092783','1.355714234617715','273.16426246578976','273.164262465789761','test','test','0.0'),('2019-02-04 15:59:59','2019-02-05 23:59:59','GXSETH','4h','0.005093000000000','0.005036000000000','1.355289312431657','1.340121142235583','266.10824905392826','266.108249053928262','test','test','1.1'),('2019-02-06 23:59:59','2019-02-07 03:59:59','GXSETH','4h','0.005050000000000','0.005075000000000','1.351918607943640','1.358611274319599','267.70665503834465','267.706655038344650','test','test','0.0'),('2019-02-07 11:59:59','2019-02-08 19:59:59','GXSETH','4h','0.005179000000000','0.004971840000000','1.353405867138298','1.299269632452766','261.3257129056378','261.325712905637772','test','test','4.0'),('2019-02-17 03:59:59','2019-02-17 07:59:59','GXSETH','4h','0.004855000000000','0.004824000000000','1.341375592763735','1.332810681666788','276.2874547402132','276.287454740213207','test','test','0.6'),('2019-02-23 15:59:59','2019-02-23 19:59:59','GXSETH','4h','0.004564000000000','0.004381440000000','1.339472279186636','1.285893388019171','293.48647659654597','293.486476596545970','test','test','4.0'),('2019-02-26 07:59:59','2019-03-05 15:59:59','GXSETH','4h','0.004550000000000','0.004911000000000','1.327565858927199','1.432895809492631','291.77271624773607','291.772716247736071','test','test','0.0'),('2019-03-06 19:59:59','2019-03-06 23:59:59','GXSETH','4h','0.004784000000000','0.004797000000000','1.350972514608406','1.354643635572016','282.3939202776769','282.393920277676898','test','test','0.0'),('2019-03-07 11:59:59','2019-03-25 15:59:59','GXSETH','4h','0.004940000000000','0.007357000000000','1.351788319266986','2.013179486811177','273.6413601755033','273.641360175503280','test','test','0.2'),('2019-03-27 15:59:59','2019-04-02 15:59:59','GXSETH','4h','0.007801000000000','0.008025000000000','1.498764134276807','1.541800048400382','192.12461662310048','192.124616623100479','test','test','2.4'),('2019-04-02 19:59:59','2019-04-02 23:59:59','GXSETH','4h','0.007904000000000','0.008023000000000','1.508327670748712','1.531036551419144','190.8309300036326','190.830930003632602','test','test','0.0'),('2019-04-04 15:59:59','2019-04-04 19:59:59','GXSETH','4h','0.007913000000000','0.007749000000000','1.513374088675475','1.482008822588937','191.25162247889233','191.251622478892330','test','test','2.1'),('2019-04-12 19:59:59','2019-04-18 19:59:59','GXSETH','4h','0.007573000000000','0.007586000000000','1.506404029545133','1.508989960138569','198.91773795657377','198.917737956573774','test','test','1.8'),('2019-04-21 19:59:59','2019-04-22 11:59:59','GXSETH','4h','0.007866000000000','0.007707000000000','1.506978680788119','1.476517250550983','191.58132224613766','191.581322246137660','test','test','2.0'),('2019-04-22 15:59:59','2019-04-23 15:59:59','GXSETH','4h','0.007728000000000','0.007612000000000','1.500209474068755','1.477690801838945','194.1264847397458','194.126484739745791','test','test','1.5'),('2019-05-31 11:59:59','2019-05-31 15:59:59','GXSETH','4h','0.004618000000000','0.004440000000000','1.495205324684353','1.437572897704315','323.77767966313405','323.777679663134052','test','test','3.9'),('2019-06-04 11:59:59','2019-06-20 23:59:59','GXSETH','4h','0.004464000000000','0.008338000000000','1.482398118688789','2.768869962730090','332.07843160591153','332.078431605911533','test','test','0.0'),('2019-06-23 07:59:59','2019-06-23 15:59:59','GXSETH','4h','0.008574000000000','0.008404000000000','1.768280750697967','1.733220367257489','206.23754964986784','206.237549649867844','test','test','2.0'),('2019-06-23 19:59:59','2019-06-23 23:59:59','GXSETH','4h','0.008451000000000','0.008684000000000','1.760489554377861','1.809027486713684','208.31730616233116','208.317306162331164','test','test','0.0'),('2019-06-24 03:59:59','2019-06-24 07:59:59','GXSETH','4h','0.008826000000000','0.008472960000000','1.771275761563599','1.700424731101055','200.68839356034434','200.688393560344338','test','test','4.0'),('2019-06-24 11:59:59','2019-06-24 19:59:59','GXSETH','4h','0.008519000000000','0.008178240000000','1.755531088127478','1.685309844602379','206.07243668593478','206.072436685934775','test','test','4.0'),('2019-07-15 23:59:59','2019-07-16 03:59:59','GXSETH','4h','0.006579000000000','0.006508000000000','1.739926367344123','1.721149232204826','264.46669210276985','264.466692102769855','test','test','1.1'),('2019-07-17 03:59:59','2019-07-17 11:59:59','GXSETH','4h','0.006630000000000','0.006451000000000','1.735753670646502','1.688890939568716','261.8029669150078','261.802966915007801','test','test','2.7'),('2019-07-18 11:59:59','2019-07-18 15:59:59','GXSETH','4h','0.006650000000000','0.006566000000000','1.725339730406994','1.703545965391327','259.44958351984866','259.449583519848659','test','test','1.3'),('2019-07-20 19:59:59','2019-07-23 07:59:59','GXSETH','4h','0.007088000000000','0.006810000000000','1.720496671514623','1.653016694838401','242.73372905116014','242.733729051160140','test','test','3.9'),('2019-07-24 03:59:59','2019-07-24 23:59:59','GXSETH','4h','0.006780000000000','0.006805000000000','1.705501121142129','1.711789842090293','251.54883792656776','251.548837926567757','test','test','0.0'),('2019-07-25 03:59:59','2019-07-27 03:59:59','GXSETH','4h','0.006884000000000','0.006940000000000','1.706898614686166','1.720783902661533','247.95157098869345','247.951570988693447','test','test','0.0'),('2019-07-30 03:59:59','2019-07-30 15:59:59','GXSETH','4h','0.007134000000000','0.006949000000000','1.709984234236247','1.665640656533177','239.69501461119253','239.695014611192533','test','test','2.6'),('2019-07-31 07:59:59','2019-08-06 03:59:59','GXSETH','4h','0.007900000000000','0.007957000000000','1.700130105857787','1.712396867381064','215.20634251364393','215.206342513643932','test','test','1.5'),('2019-09-27 19:59:59','2019-09-30 07:59:59','GXSETH','4h','0.002496000000000','0.002425000000000','1.702856052862960','1.654417439179759','682.2339955380448','682.233995538044837','test','test','2.8'),('2019-10-03 11:59:59','2019-10-04 03:59:59','GXSETH','4h','0.002456000000000','0.002525000000000','1.692091916488915','1.739630329452162','688.9625067137279','688.962506713727862','test','test','0.0'),('2019-10-04 07:59:59','2019-10-04 11:59:59','GXSETH','4h','0.002466000000000','0.002445000000000','1.702656008258526','1.688156504538563','690.4525580934817','690.452558093481684','test','test','0.9'),('2019-10-09 03:59:59','2019-10-09 15:59:59','GXSETH','4h','0.002489000000000','0.002389440000000','1.699433896320756','1.631456540467926','682.7777807636627','682.777780763662690','test','test','4.0'),('2019-10-10 03:59:59','2019-10-10 11:59:59','GXSETH','4h','0.002552000000000','0.002518000000000','1.684327817242350','1.661887713094137','660.0030631827389','660.003063182738856','test','test','2.4'),('2019-10-10 19:59:59','2019-10-11 03:59:59','GXSETH','4h','0.002551000000000','0.002454000000000','1.679341127431636','1.615485349555953','658.3069884091085','658.306988409108499','test','test','3.8'),('2019-10-13 23:59:59','2019-10-14 07:59:59','GXSETH','4h','0.002532000000000','0.002508000000000','1.665150954570373','1.649367533200038','657.6425570973036','657.642557097303552','test','test','1.7'),('2019-10-14 11:59:59','2019-10-14 19:59:59','GXSETH','4h','0.002504000000000','0.002483000000000','1.661643527599187','1.647708018781462','663.5956579868957','663.595657986895731','test','test','0.8'),('2019-10-14 23:59:59','2019-10-15 07:59:59','GXSETH','4h','0.002511000000000','0.002495000000000','1.658546747861915','1.647978548751683','660.5124443894523','660.512444389452298','test','test','0.6'),('2019-10-15 11:59:59','2019-10-16 11:59:59','GXSETH','4h','0.003024000000000','0.002903040000000','1.656198259170752','1.589950328803922','547.6846095141375','547.684609514137492','test','test','4.0'),('2019-10-20 15:59:59','2019-10-20 19:59:59','GXSETH','4h','0.002748000000000','0.002664000000000','1.641476496867012','1.591300359408195','597.334969747821','597.334969747820992','test','test','3.1'),('2019-10-22 15:59:59','2019-10-22 19:59:59','GXSETH','4h','0.002735000000000','0.002663000000000','1.630326244098386','1.587407235112980','596.0973470195196','596.097347019519589','test','test','2.6'),('2019-10-27 15:59:59','2019-10-29 03:59:59','GXSETH','4h','0.003022000000000','0.002901120000000','1.620788686546074','1.555957139084231','536.3298102402626','536.329810240262645','test','test','4.0'),('2019-10-29 15:59:59','2019-10-29 19:59:59','GXSETH','4h','0.002740000000000','0.002630400000000','1.606381675998997','1.542126408959037','586.2706846711669','586.270684671166919','test','test','4.0'),('2019-10-31 15:59:59','2019-10-31 19:59:59','GXSETH','4h','0.002755000000000','0.002716000000000','1.592102727767895','1.569564794416553','577.8957269574938','577.895726957493821','test','test','1.4'),('2019-11-02 03:59:59','2019-11-02 07:59:59','GXSETH','4h','0.003074000000000','0.002951040000000','1.587094298134264','1.523610526208893','516.2961282154404','516.296128215440376','test','test','4.0'),('2019-11-02 11:59:59','2019-11-04 15:59:59','GXSETH','4h','0.002939000000000','0.002831000000000','1.572986793261959','1.515183944105004','535.2115662681045','535.211566268104548','test','test','3.7'),('2019-11-05 23:59:59','2019-11-11 11:59:59','GXSETH','4h','0.002941000000000','0.002976000000000','1.560141715671524','1.578708516096040','530.480012129046','530.480012129046031','test','test','1.5'),('2019-11-12 03:59:59','2019-11-18 03:59:59','GXSETH','4h','0.003008000000000','0.003151000000000','1.564267671321417','1.638632790004583','520.0357949871732','520.035794987173176','test','test','1.1'),('2019-11-18 07:59:59','2019-11-18 11:59:59','GXSETH','4h','0.003168000000000','0.003075000000000','1.580793253251009','1.534387390702921','498.9877693342833','498.987769334283314','test','test','2.9'),('2019-11-22 11:59:59','2019-11-22 15:59:59','GXSETH','4h','0.003090000000000','0.003074000000000','1.570480839351434','1.562348899730197','508.246226327325','508.246226327325019','test','test','0.5'),('2019-11-28 19:59:59','2019-11-30 11:59:59','GXSETH','4h','0.003122000000000','0.003009000000000','1.568673741657826','1.511895992520307','502.4579569691948','502.457956969194811','test','test','3.6'),('2019-12-03 07:59:59','2019-12-04 03:59:59','GXSETH','4h','0.003061000000000','0.003043000000000','1.556056464071711','1.546906181042214','508.34905719428644','508.349057194286445','test','test','0.6'),('2019-12-04 15:59:59','2019-12-04 19:59:59','GXSETH','4h','0.003024000000000','0.003020000000000','1.554023067842934','1.551967481774359','513.8965171438273','513.896517143827282','test','test','0.1'),('2019-12-04 23:59:59','2019-12-05 11:59:59','GXSETH','4h','0.003026000000000','0.003060000000000','1.553566270938806','1.571022071735871','513.4059057960363','513.405905796036336','test','test','0.0'),('2019-12-05 23:59:59','2019-12-06 07:59:59','GXSETH','4h','0.003044000000000','0.003020000000000','1.557445337782598','1.545165873884181','511.64432910072213','511.644329100722132','test','test','0.8'),('2019-12-07 07:59:59','2019-12-07 19:59:59','GXSETH','4h','0.003044000000000','0.003067000000000','1.554716568027394','1.566463769428389','510.74788699980104','510.747886999801040','test','test','0.0'),('2019-12-16 15:59:59','2019-12-17 07:59:59','GXSETH','4h','0.002992000000000','0.002957000000000','1.557327057227615','1.539109661838923','520.4970111054864','520.497011105486422','test','test','1.2'),('2019-12-17 11:59:59','2019-12-17 15:59:59','GXSETH','4h','0.002957000000000','0.002975000000000','1.553278747141239','1.562733944114030','525.2887207105983','525.288720710598341','test','test','0.0'),('2019-12-17 19:59:59','2019-12-22 19:59:59','GXSETH','4h','0.002995000000000','0.003066000000000','1.555379902024082','1.592252013223985','519.3255098577903','519.325509857790280','test','test','0.0'),('2019-12-23 03:59:59','2019-12-23 07:59:59','GXSETH','4h','0.003042000000000','0.003026000000000','1.563573704512949','1.555349779702887','513.9953006288459','513.995300628845939','test','test','0.5'),('2019-12-23 23:59:59','2019-12-24 11:59:59','GXSETH','4h','0.003080000000000','0.003035000000000','1.561746165666269','1.538928445713353','507.06044339813917','507.060443398139171','test','test','1.5'),('2019-12-24 15:59:59','2019-12-24 23:59:59','GXSETH','4h','0.003088000000000','0.003039000000000','1.556675561232287','1.531974427002889','504.1047801918029','504.104780191802888','test','test','1.6'),('2019-12-26 03:59:59','2019-12-26 07:59:59','GXSETH','4h','0.003078000000000','0.003050000000000','1.551186420292421','1.537075562667929','503.9592008747307','503.959200874730698','test','test','0.9'),('2019-12-27 07:59:59','2019-12-27 23:59:59','GXSETH','4h','0.003060000000000','0.003035000000000','1.548050674153645','1.535403201325592','505.89891312210625','505.898913122106251','test','test','0.8'),('2019-12-28 03:59:59','2019-12-28 15:59:59','GXSETH','4h','0.003103000000000','0.003062000000000','1.545240124636300','1.524822836492540','497.982637652691','497.982637652690983','test','test','1.3'),('2019-12-29 07:59:59','2019-12-29 11:59:59','GXSETH','4h','0.003084000000000','0.003026000000000','1.540702949493242','1.511727342790710','499.57942590572065','499.579425905720655','test','test','1.9');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:52:50
