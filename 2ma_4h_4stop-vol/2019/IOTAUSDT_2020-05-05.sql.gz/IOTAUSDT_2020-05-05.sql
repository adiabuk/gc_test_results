-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 07:59:59','2019-01-06 07:59:59','IOTAUSDT','4h','0.361200000000000','0.351900000000000','222.222222222222200','216.500553709856007','615.2331733727082','615.233173372708166','test','test','2.6'),('2019-01-06 19:59:59','2019-01-08 03:59:59','IOTAUSDT','4h','0.373600000000000','0.358656000000000','220.950740330585290','212.112710717361864','591.4099045251212','591.409904525121192','test','test','4.0'),('2019-01-08 11:59:59','2019-01-08 19:59:59','IOTAUSDT','4h','0.366400000000000','0.359200000000000','218.986733749868989','214.683500990592080','597.6712165662364','597.671216566236353','test','test','2.0'),('2019-01-09 15:59:59','2019-01-10 07:59:59','IOTAUSDT','4h','0.360900000000000','0.346464000000000','218.030459803362987','209.309241411228470','604.1298415166611','604.129841516661145','test','test','4.0'),('2019-01-19 11:59:59','2019-01-19 23:59:59','IOTAUSDT','4h','0.314700000000000','0.307400000000000','216.092411271777536','211.079781458355313','686.661618277018','686.661618277017965','test','test','2.3'),('2019-02-08 15:59:59','2019-02-12 03:59:59','IOTAUSDT','4h','0.265000000000000','0.265800000000000','214.978493535461467','215.627485214059078','811.2395982470243','811.239598247024333','test','test','0.0'),('2019-02-12 19:59:59','2019-02-13 15:59:59','IOTAUSDT','4h','0.274100000000000','0.267200000000000','215.122713908483206','209.707366495245196','784.832958440289','784.832958440288962','test','test','2.5'),('2019-02-15 11:59:59','2019-02-24 15:59:59','IOTAUSDT','4h','0.272600000000000','0.282100000000000','213.919303372208077','221.374304773660668','784.7369896265886','784.736989626588638','test','test','1.3'),('2019-03-01 07:59:59','2019-03-02 07:59:59','IOTAUSDT','4h','0.292700000000000','0.286500000000000','215.575970350308666','211.009619082211913','736.5082690478602','736.508269047860153','test','test','2.1'),('2019-03-09 19:59:59','2019-03-09 23:59:59','IOTAUSDT','4h','0.282700000000000','0.282000000000000','214.561225624064917','214.029945617213656','758.9714383589137','758.971438358913701','test','test','0.2'),('2019-03-12 23:59:59','2019-03-13 11:59:59','IOTAUSDT','4h','0.282700000000000','0.279500000000000','214.443163400320174','212.015791193454163','758.553814645632','758.553814645631974','test','test','1.1'),('2019-03-13 15:59:59','2019-03-13 23:59:59','IOTAUSDT','4h','0.283400000000000','0.283800000000000','213.903747354350003','214.205658077503671','754.7768078840861','754.776807884086111','test','test','0.0'),('2019-03-14 07:59:59','2019-03-14 19:59:59','IOTAUSDT','4h','0.286500000000000','0.294500000000000','213.970838626161907','219.945591537189102','746.8441138784011','746.844113878401117','test','test','0.0'),('2019-03-14 23:59:59','2019-03-18 07:59:59','IOTAUSDT','4h','0.297000000000000','0.291000000000000','215.298561495279046','210.949095606485514','724.910981465586','724.910981465586019','test','test','2.0'),('2019-03-20 15:59:59','2019-03-20 19:59:59','IOTAUSDT','4h','0.302200000000000','0.295700000000000','214.332013519991619','209.721960284121508','709.2389593646313','709.238959364631341','test','test','2.2'),('2019-03-21 19:59:59','2019-03-25 07:59:59','IOTAUSDT','4h','0.305000000000000','0.301500000000000','213.307557245353820','210.859765604833370','699.3690401487011','699.369040148701060','test','test','1.1'),('2019-03-27 11:59:59','2019-03-27 19:59:59','IOTAUSDT','4h','0.303300000000000','0.300700000000000','212.763603547460349','210.939715089750507','701.4955606576339','701.495560657633860','test','test','0.9'),('2019-03-27 23:59:59','2019-03-28 11:59:59','IOTAUSDT','4h','0.305700000000000','0.300900000000000','212.358295001302622','209.023915491959286','694.662397779858','694.662397779857997','test','test','1.6'),('2019-03-29 11:59:59','2019-03-30 07:59:59','IOTAUSDT','4h','0.306600000000000','0.306400000000000','211.617321777004122','211.479280471213514','690.2065289530467','690.206528953046700','test','test','0.1'),('2019-03-31 19:59:59','2019-04-01 03:59:59','IOTAUSDT','4h','0.305500000000000','0.310500000000000','211.586645931272869','215.049602493159483','692.5913123773253','692.591312377325266','test','test','0.0'),('2019-04-01 07:59:59','2019-04-03 23:59:59','IOTAUSDT','4h','0.311500000000000','0.335900000000000','212.356191833914323','228.990192093135846','681.7213220992434','681.721322099243366','test','test','0.0'),('2019-04-07 11:59:59','2019-04-08 11:59:59','IOTAUSDT','4h','0.357400000000000','0.343104000000000','216.052636335963570','207.410530882525023','604.5121330049344','604.512133004934412','test','test','4.0'),('2019-04-08 15:59:59','2019-04-11 03:59:59','IOTAUSDT','4h','0.350800000000000','0.336768000000000','214.132168457421670','205.566881719124808','610.4109705171655','610.410970517165538','test','test','4.0'),('2019-04-29 03:59:59','2019-04-30 03:59:59','IOTAUSDT','4h','0.308300000000000','0.295968000000000','212.228771404466784','203.739620548288116','688.3839487657048','688.383948765704758','test','test','4.0'),('2019-04-30 15:59:59','2019-05-01 11:59:59','IOTAUSDT','4h','0.297100000000000','0.291800000000000','210.342293436427099','206.589973829516765','707.9848314925181','707.984831492518083','test','test','1.8'),('2019-05-11 11:59:59','2019-05-23 03:59:59','IOTAUSDT','4h','0.292800000000000','0.383000000000000','209.508444634891475','274.049638986213949','715.5343054470337','715.534305447033717','test','test','0.0'),('2019-05-23 15:59:59','2019-05-23 19:59:59','IOTAUSDT','4h','0.381100000000000','0.378300000000000','223.850932268518704','222.206265224824534','587.381087033636','587.381087033636049','test','test','0.7'),('2019-05-23 23:59:59','2019-05-24 23:59:59','IOTAUSDT','4h','0.385900000000000','0.380600000000000','223.485450703253292','220.416072914377281','579.127884693582','579.127884693582018','test','test','1.4'),('2019-05-25 11:59:59','2019-05-25 15:59:59','IOTAUSDT','4h','0.389600000000000','0.382200000000000','222.803366750169772','218.571475287255851','571.8772247180949','571.877224718094908','test','test','1.9'),('2019-05-26 19:59:59','2019-06-03 23:59:59','IOTAUSDT','4h','0.398300000000000','0.444200000000000','221.862946425077780','247.430381124829410','557.0247211274863','557.024721127486259','test','test','0.0'),('2019-06-12 15:59:59','2019-06-12 23:59:59','IOTAUSDT','4h','0.438200000000000','0.434200000000000','227.544598580578139','225.467514157204533','519.2711058434006','519.271105843400619','test','test','0.9'),('2019-06-13 15:59:59','2019-06-14 03:59:59','IOTAUSDT','4h','0.444300000000000','0.431700000000000','227.083024264272893','220.643127559951836','511.1029130413525','511.102913041352508','test','test','2.8'),('2019-06-15 19:59:59','2019-06-16 03:59:59','IOTAUSDT','4h','0.437500000000000','0.440600000000000','225.651936107757109','227.250841255034942','515.7758539605877','515.775853960587710','test','test','0.9'),('2019-06-16 07:59:59','2019-06-17 07:59:59','IOTAUSDT','4h','0.456100000000000','0.437856000000000','226.007248362707742','216.966958428199433','495.5212636761845','495.521263676184503','test','test','4.0'),('2019-06-17 11:59:59','2019-06-17 15:59:59','IOTAUSDT','4h','0.440100000000000','0.433600000000000','223.998295043928124','220.689981211195715','508.97135888190894','508.971358881908941','test','test','1.5'),('2019-06-17 23:59:59','2019-06-18 03:59:59','IOTAUSDT','4h','0.435300000000000','0.430500000000000','223.263114192209770','220.801219066727100','512.8948178088899','512.894817808889911','test','test','1.1'),('2019-06-22 07:59:59','2019-06-22 15:59:59','IOTAUSDT','4h','0.442100000000000','0.451200000000000','222.716026386546986','227.300319171250834','503.76843787954533','503.768437879545331','test','test','0.2'),('2019-06-22 19:59:59','2019-06-25 19:59:59','IOTAUSDT','4h','0.452700000000000','0.448900000000000','223.734758116481174','221.856710665978369','494.2230132902169','494.223013290216898','test','test','1.8'),('2019-06-25 23:59:59','2019-06-26 23:59:59','IOTAUSDT','4h','0.448100000000000','0.447200000000000','223.317414238591681','222.868885622624845','498.3651288520234','498.365128852023417','test','test','0.2'),('2019-06-27 03:59:59','2019-06-27 07:59:59','IOTAUSDT','4h','0.447600000000000','0.429696000000000','223.217741212821238','214.289031564308374','498.6991537373129','498.699153737312884','test','test','4.0'),('2019-07-08 19:59:59','2019-07-08 23:59:59','IOTAUSDT','4h','0.410300000000000','0.403300000000000','221.233583513151729','217.459186524138659','539.1995698590098','539.199569859009785','test','test','1.7'),('2019-07-09 03:59:59','2019-07-09 07:59:59','IOTAUSDT','4h','0.402900000000000','0.398300000000000','220.394828626704367','217.878531253453332','547.0211680980501','547.021168098050111','test','test','1.1'),('2019-07-20 15:59:59','2019-07-20 23:59:59','IOTAUSDT','4h','0.331000000000000','0.318800000000000','219.835651432648575','211.732947663831908','664.1560466243159','664.156046624315877','test','test','3.7'),('2019-08-05 11:59:59','2019-08-05 15:59:59','IOTAUSDT','4h','0.294200000000000','0.292700000000000','218.035050595133754','216.923383103996088','741.1116607584423','741.111660758442326','test','test','0.5'),('2019-08-22 19:59:59','2019-08-24 15:59:59','IOTAUSDT','4h','0.261200000000000','0.255000000000000','217.788013374880961','212.618466349902945','833.7979072545213','833.797907254521306','test','test','2.4'),('2019-08-25 11:59:59','2019-08-27 11:59:59','IOTAUSDT','4h','0.272100000000000','0.261216000000000','216.639225147108050','207.973656141223728','796.1750281040354','796.175028104035391','test','test','4.0'),('2019-08-27 15:59:59','2019-08-28 11:59:59','IOTAUSDT','4h','0.260700000000000','0.259400000000000','214.713543145800458','213.642858043807621','823.6039246098982','823.603924609898172','test','test','0.5'),('2019-09-08 15:59:59','2019-09-08 19:59:59','IOTAUSDT','4h','0.246600000000000','0.243800000000000','214.475613123135389','212.040366907625327','869.7307912535904','869.730791253590382','test','test','1.1'),('2019-09-14 15:59:59','2019-09-16 15:59:59','IOTAUSDT','4h','0.246000000000000','0.243400000000000','213.934447297466448','211.673351513021686','869.652224786449','869.652224786448983','test','test','1.1'),('2019-09-17 11:59:59','2019-09-24 15:59:59','IOTAUSDT','4h','0.249500000000000','0.272600000000000','213.431981567589872','233.192617937174361','855.4388038781158','855.438803878115777','test','test','0.0'),('2019-09-30 19:59:59','2019-09-30 23:59:59','IOTAUSDT','4h','0.264900000000000','0.265400000000000','217.823234094164178','218.234376476372887','822.2847644173808','822.284764417380757','test','test','0.0'),('2019-10-01 03:59:59','2019-10-03 15:59:59','IOTAUSDT','4h','0.271900000000000','0.269300000000000','217.914599067988348','215.830825777893580','801.4512654210679','801.451265421067887','test','test','1.4'),('2019-10-04 19:59:59','2019-10-05 03:59:59','IOTAUSDT','4h','0.270400000000000','0.270500000000000','217.451538336856174','217.531956805176065','804.1846831984327','804.184683198432708','test','test','0.3'),('2019-10-05 15:59:59','2019-10-06 11:59:59','IOTAUSDT','4h','0.274200000000000','0.270700000000000','217.469409107593918','214.693541376461241','793.1050660379063','793.105066037906340','test','test','1.6'),('2019-10-06 15:59:59','2019-10-06 19:59:59','IOTAUSDT','4h','0.271300000000000','0.266300000000000','216.852549611786657','212.856004281676320','799.3090660220666','799.309066022066645','test','test','1.8'),('2019-10-07 11:59:59','2019-10-08 15:59:59','IOTAUSDT','4h','0.279700000000000','0.272200000000000','215.964428427317699','210.173462345069282','772.1288109664558','772.128810966455831','test','test','2.7'),('2019-10-09 11:59:59','2019-10-10 11:59:59','IOTAUSDT','4h','0.274600000000000','0.271600000000000','214.677547075706912','212.332198782818637','781.7827642960922','781.782764296092182','test','test','1.1'),('2019-10-13 11:59:59','2019-10-15 19:59:59','IOTAUSDT','4h','0.280700000000000','0.278800000000000','214.156358566176209','212.706778654256937','762.9367957469761','762.936795746976145','test','test','1.0'),('2019-10-17 11:59:59','2019-10-17 15:59:59','IOTAUSDT','4h','0.278400000000000','0.276500000000000','213.834229696860803','212.374872525797485','768.0827216122874','768.082721612287401','test','test','0.7'),('2019-10-25 19:59:59','2019-10-26 03:59:59','IOTAUSDT','4h','0.270600000000000','0.269500000000000','213.509928103291173','212.642001566285927','789.024124550226','789.024124550226020','test','test','0.4'),('2019-10-26 07:59:59','2019-10-26 15:59:59','IOTAUSDT','4h','0.277100000000000','0.267000000000000','213.317055539512239','205.541875961926252','769.8197601570272','769.819760157027190','test','test','3.6'),('2019-10-27 15:59:59','2019-10-31 07:59:59','IOTAUSDT','4h','0.271500000000000','0.273200000000000','211.589237855604239','212.914106011606179','779.334209412907','779.334209412906944','test','test','0.7'),('2019-11-04 23:59:59','2019-11-05 07:59:59','IOTAUSDT','4h','0.274000000000000','0.270700000000000','211.883653001382442','209.331769589321993','773.2980036546804','773.298003654680429','test','test','1.2'),('2019-11-05 11:59:59','2019-11-05 15:59:59','IOTAUSDT','4h','0.274100000000000','0.274500000000000','211.316567798702380','211.624946591549815','770.9469821185785','770.946982118578489','test','test','0.0'),('2019-11-05 19:59:59','2019-11-07 11:59:59','IOTAUSDT','4h','0.276900000000000','0.269400000000000','211.385096419335127','205.659606267132091','763.3986869604014','763.398686960401392','test','test','2.7'),('2019-12-29 19:59:59','2019-12-30 03:59:59','IOTAUSDT','4h','0.168300000000000','0.163700000000000','210.112765274401113','204.369932711939782','1248.4418614046413','1248.441861404641259','test','test','2.7');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:39:19
