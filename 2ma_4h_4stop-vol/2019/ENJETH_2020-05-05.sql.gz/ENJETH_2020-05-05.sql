-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 15:59:59','2019-01-11 19:59:59','ENJETH','4h','0.000271290000000','0.000273050000000','1.297777777777778','1.306197140411450','4783.728769131843','4783.728769131843364','test','test','0.0'),('2019-01-12 07:59:59','2019-01-12 19:59:59','ENJETH','4h','0.000297960000000','0.000286041600000','1.299648747251927','1.247662797361850','4361.822886467738','4361.822886467737590','test','test','4.0'),('2019-01-12 23:59:59','2019-01-13 07:59:59','ENJETH','4h','0.000287900000000','0.000277070000000','1.288096313943021','1.239641700952389','4474.11015610636','4474.110156106359682','test','test','3.8'),('2019-01-13 19:59:59','2019-01-14 11:59:59','ENJETH','4h','0.000287220000000','0.000281160000000','1.277328622167325','1.250378509186565','4447.213363161776','4447.213363161776215','test','test','2.6'),('2019-01-15 23:59:59','2019-01-16 15:59:59','ENJETH','4h','0.000285580000000','0.000277550000000','1.271339708171601','1.235591904205574','4451.781315819037','4451.781315819037445','test','test','2.8'),('2019-01-17 07:59:59','2019-01-17 15:59:59','ENJETH','4h','0.000277400000000','0.000277070000000','1.263395751734706','1.261892793558526','4554.418715698291','4554.418715698290725','test','test','0.6'),('2019-01-18 19:59:59','2019-01-19 11:59:59','ENJETH','4h','0.000278140000000','0.000281100000000','1.263061761028888','1.276503419232115','4541.100744333386','4541.100744333385592','test','test','0.5'),('2019-01-19 15:59:59','2019-01-19 23:59:59','ENJETH','4h','0.000277580000000','0.000276320000000','1.266048796185161','1.260301907060608','4561.023114724263','4561.023114724262996','test','test','0.5'),('2019-01-20 23:59:59','2019-01-21 07:59:59','ENJETH','4h','0.000278970000000','0.000280830000000','1.264771709713038','1.273204427855011','4533.719431168361','4533.719431168360643','test','test','0.0'),('2019-01-21 15:59:59','2019-01-21 23:59:59','ENJETH','4h','0.000285220000000','0.000288000000000','1.266645647077921','1.278991467493308','4440.942595462874','4440.942595462874124','test','test','0.0'),('2019-01-23 03:59:59','2019-01-27 15:59:59','ENJETH','4h','0.000301900000000','0.000289824000000','1.269389162725785','1.218613596216753','4204.66764731959','4204.667647319590287','test','test','4.0'),('2019-02-11 11:59:59','2019-02-11 23:59:59','ENJETH','4h','0.000272270000000','0.000261379200000','1.258105703501555','1.207781475361493','4620.801790507786','4620.801790507785881','test','test','4.0'),('2019-02-20 07:59:59','2019-02-20 11:59:59','ENJETH','4h','0.000263680000000','0.000253132800000','1.246922541692652','1.197045640024946','4728.923474259149','4728.923474259148861','test','test','4.0'),('2019-02-20 15:59:59','2019-02-20 19:59:59','ENJETH','4h','0.000257910000000','0.000250230000000','1.235838785766496','1.199038189144858','4791.744351775797','4791.744351775797440','test','test','3.0'),('2019-02-21 03:59:59','2019-02-21 07:59:59','ENJETH','4h','0.000258680000000','0.000253710000000','1.227660875406132','1.204073916419088','4745.866999405178','4745.866999405177921','test','test','1.9'),('2019-02-22 03:59:59','2019-02-23 19:59:59','ENJETH','4h','0.000262400000000','0.000252060000000','1.222419328964566','1.174249299004606','4658.610247578377','4658.610247578377312','test','test','3.9'),('2019-02-25 03:59:59','2019-03-16 07:59:59','ENJETH','4h','0.000303950000000','0.001167460000000','1.211714877862353','4.654149206478640','3986.559887686636','3986.559887686636102','test','test','0.0'),('2019-03-17 07:59:59','2019-03-24 11:59:59','ENJETH','4h','0.001177280000000','0.001318800000000','1.976700284221528','2.214318033799394','1679.0400620256248','1679.040062025624820','test','test','0.9'),('2019-04-13 07:59:59','2019-04-13 11:59:59','ENJETH','4h','0.000951090000000','0.000924800000000','2.029504228572165','1.973404736232679','2133.871903365785','2133.871903365784874','test','test','2.8'),('2019-04-13 15:59:59','2019-04-15 03:59:59','ENJETH','4h','0.000928160000000','0.000942080000000','2.017037674718945','2.047288024262222','2173.1572947756263','2173.157294775626269','test','test','0.0'),('2019-04-17 07:59:59','2019-04-23 03:59:59','ENJETH','4h','0.000968200000000','0.001041040000000','2.023759974617451','2.176012274298441','2090.22926525248','2090.229265252480218','test','test','0.0'),('2019-04-25 07:59:59','2019-04-25 11:59:59','ENJETH','4h','0.001046470000000','0.001017610000000','2.057593818991005','2.000848611181818','1966.2234168117618','1966.223416811761808','test','test','2.8'),('2019-05-11 03:59:59','2019-05-11 07:59:59','ENJETH','4h','0.000890250000000','0.000856500000000','2.044983772811185','1.967457008045807','2297.089326381562','2297.089326381561932','test','test','3.8'),('2019-05-22 03:59:59','2019-05-22 11:59:59','ENJETH','4h','0.000700120000000','0.000672450000000','2.027755602863324','1.947615059054794','2896.2972102829854','2896.297210282985361','test','test','4.0'),('2019-05-22 15:59:59','2019-05-22 19:59:59','ENJETH','4h','0.000674860000000','0.000700020000000','2.009946593128095','2.084881033283243','2978.3163813651645','2978.316381365164489','test','test','0.0'),('2019-05-24 03:59:59','2019-05-24 07:59:59','ENJETH','4h','0.000700830000000','0.000683300000000','2.026598690940350','1.975906975328598','2891.712242541486','2891.712242541485921','test','test','2.5'),('2019-06-02 19:59:59','2019-06-03 03:59:59','ENJETH','4h','0.000638290000000','0.000612758400000','2.015333865248849','1.934720510638895','3157.3953300989356','3157.395330098935574','test','test','4.0'),('2019-06-07 03:59:59','2019-06-07 19:59:59','ENJETH','4h','0.000634700000000','0.000609312000000','1.997419786446637','1.917522994988771','3147.0297564938355','3147.029756493835521','test','test','4.0'),('2019-06-08 07:59:59','2019-06-10 03:59:59','ENJETH','4h','0.000630700000000','0.000629850000000','1.979664943900445','1.976996931846671','3138.8377103225694','3138.837710322569365','test','test','1.7'),('2019-06-11 07:59:59','2019-06-12 15:59:59','ENJETH','4h','0.000640000000000','0.000617410000000','1.979072052332939','1.909216993485750','3092.3000817702177','3092.300081770217730','test','test','3.5'),('2019-07-01 11:59:59','2019-07-01 15:59:59','ENJETH','4h','0.000442270000000','0.000441420000000','1.963548705922453','1.959774955950639','4439.7058491926955','4439.705849192695496','test','test','0.2'),('2019-07-01 19:59:59','2019-07-01 23:59:59','ENJETH','4h','0.000446440000000','0.000432530000000','1.962710094817605','1.901556754124762','4396.358065624956','4396.358065624955998','test','test','3.1'),('2019-07-07 03:59:59','2019-07-07 19:59:59','ENJETH','4h','0.000430230000000','0.000413020800000','1.949120463552529','1.871155645010428','4530.4150420764','4530.415042076399914','test','test','4.0'),('2019-07-14 11:59:59','2019-07-16 23:59:59','ENJETH','4h','0.000412630000000','0.000413530000000','1.931794948320951','1.936008445772636','4681.663835205757','4681.663835205757096','test','test','0.0'),('2019-07-22 15:59:59','2019-07-23 15:59:59','ENJETH','4h','0.000405500000000','0.000402230000000','1.932731281087992','1.917145507255297','4766.291691955592','4766.291691955591887','test','test','0.8'),('2019-07-24 03:59:59','2019-07-24 15:59:59','ENJETH','4h','0.000410090000000','0.000404080000000','1.929267775791838','1.900993740013085','4704.498465682747','4704.498465682747337','test','test','1.5'),('2019-07-26 07:59:59','2019-07-27 11:59:59','ENJETH','4h','0.000406930000000','0.000407420000000','1.922984656729893','1.925300196212845','4725.5907815346445','4725.590781534644520','test','test','0.3'),('2019-07-27 15:59:59','2019-07-27 19:59:59','ENJETH','4h','0.000405350000000','0.000403100000000','1.923499221059438','1.912822341208978','4745.27993353753','4745.279933537530269','test','test','0.6'),('2019-07-30 11:59:59','2019-07-31 07:59:59','ENJETH','4h','0.000409790000000','0.000406870000000','1.921126581092669','1.907437399763719','4688.07579758576','4688.075797585759574','test','test','0.7'),('2019-08-12 15:59:59','2019-08-12 19:59:59','ENJETH','4h','0.000344720000000','0.000338010000000','1.918084540797347','1.880748884993361','5564.181192844472','5564.181192844472207','test','test','1.9'),('2019-08-17 07:59:59','2019-08-18 11:59:59','ENJETH','4h','0.000333530000000','0.000335300000000','1.909787728396461','1.919922721588263','5725.984854125448','5725.984854125447782','test','test','0.0'),('2019-08-21 15:59:59','2019-08-26 03:59:59','ENJETH','4h','0.000345860000000','0.000359530000000','1.912039949105750','1.987612684039757','5528.3639307978665','5528.363930797866487','test','test','1.6'),('2019-08-27 11:59:59','2019-08-29 03:59:59','ENJETH','4h','0.000371700000000','0.000363460000000','1.928833890202196','1.886074699308287','5189.2221958627815','5189.222195862781518','test','test','2.2'),('2019-08-29 07:59:59','2019-09-09 11:59:59','ENJETH','4h','0.000363320000000','0.000434270000000','1.919331847781328','2.294143569129135','5282.758581364438','5282.758581364438214','test','test','0.0'),('2019-10-03 15:59:59','2019-10-07 03:59:59','ENJETH','4h','0.000342010000000','0.000348240000000','2.002623341414174','2.039102811070062','5855.452593240471','5855.452593240471288','test','test','0.2'),('2019-10-07 15:59:59','2019-10-08 11:59:59','ENJETH','4h','0.000361000000000','0.000349620000000','2.010729890226593','1.947344554628868','5569.888892594441','5569.888892594441131','test','test','3.2'),('2019-10-22 15:59:59','2019-10-25 15:59:59','ENJETH','4h','0.000350000000000','0.000340000000000','1.996644260093765','1.939597281233943','5704.697885982187','5704.697885982186563','test','test','2.9'),('2019-10-25 19:59:59','2019-10-25 23:59:59','ENJETH','4h','0.000344920000000','0.000343950000000','1.983967153680471','1.978387749357526','5751.963219530531','5751.963219530531205','test','test','0.3'),('2019-10-27 19:59:59','2019-10-27 23:59:59','ENJETH','4h','0.000352000000000','0.000349610000000','1.982727286053150','1.969265018400687','5632.747971741905','5632.747971741904621','test','test','0.7'),('2019-10-28 03:59:59','2019-10-29 07:59:59','ENJETH','4h','0.000352050000000','0.000346930000000','1.979735671019270','1.950943605586466','5623.450279844538','5623.450279844538272','test','test','1.8'),('2019-10-31 15:59:59','2019-11-02 19:59:59','ENJETH','4h','0.000354000000000','0.000359300000000','1.973337434256424','2.002881751774952','5574.399531797809','5574.399531797808777','test','test','0.8'),('2019-11-04 03:59:59','2019-11-05 15:59:59','ENJETH','4h','0.000364750000000','0.000352000000000','1.979902838149431','1.910694445589033','5428.109220423387','5428.109220423387342','test','test','3.5'),('2019-11-05 19:59:59','2019-11-05 23:59:59','ENJETH','4h','0.000356960000000','0.000354960000000','1.964523195358231','1.953516229897909','5503.482730160888','5503.482730160888423','test','test','0.6'),('2019-11-14 19:59:59','2019-11-18 11:59:59','ENJETH','4h','0.000344520000000','0.000352190000000','1.962077203033715','2.005758650111587','5695.103921495747','5695.103921495747272','test','test','0.0'),('2019-11-18 15:59:59','2019-11-19 07:59:59','ENJETH','4h','0.000353020000000','0.000351130000000','1.971784191273242','1.961227644557740','5585.474452646429','5585.474452646429199','test','test','0.5'),('2019-11-19 15:59:59','2019-11-24 15:59:59','ENJETH','4h','0.000354000000000','0.000372720000000','1.969438292003131','2.073584859309059','5563.385005658562','5563.385005658561568','test','test','0.0'),('2019-11-26 15:59:59','2019-11-26 23:59:59','ENJETH','4h','0.000374420000000','0.000371060000000','1.992581973626670','1.974700782901320','5321.782953973267','5321.782953973266558','test','test','0.9'),('2019-11-27 11:59:59','2019-11-27 19:59:59','ENJETH','4h','0.000379550000000','0.000371150000000','1.988608375687703','1.944597546137508','5239.3844702613715','5239.384470261371462','test','test','2.2'),('2019-11-28 15:59:59','2019-12-10 03:59:59','ENJETH','4h','0.000392610000000','0.000521830000000','1.978828191343215','2.630121278338886','5040.18795074811','5040.187950748109870','test','test','1.2'),('2019-12-11 07:59:59','2019-12-14 11:59:59','ENJETH','4h','0.000557540000000','0.000543010000000','2.123559988453365','2.068218081805901','3808.8029351317655','3808.802935131765480','test','test','2.6'),('2019-12-15 19:59:59','2019-12-23 03:59:59','ENJETH','4h','0.000562610000000','0.000590700000000','2.111261786976151','2.216672895197050','3752.6204421822417','3752.620442182241732','test','test','0.0'),('2019-12-23 23:59:59','2019-12-24 03:59:59','ENJETH','4h','0.000603590000000','0.000594200000000','2.134686477691905','2.101477335682384','3536.6498412695796','3536.649841269579611','test','test','1.6'),('2019-12-24 11:59:59','2019-12-26 03:59:59','ENJETH','4h','0.000617930000000','0.000601990000000','2.127306668356457','2.072431086504788','3442.6337422628076','3442.633742262807573','test','test','2.6'),('2019-12-26 23:59:59','2019-12-27 03:59:59','ENJETH','4h','0.000602210000000','0.000596440000000','2.115112094611642','2.094846411899782','3512.250036717493','3512.250036717493003','test','test','1.0'),('2019-12-27 07:59:59','2019-12-27 15:59:59','ENJETH','4h','0.000615050000000','0.000593810000000','2.110608609564561','2.037721320942252','3431.6049257207724','3431.604925720772371','test','test','3.5'),('2019-12-28 15:59:59','2019-12-29 19:59:59','ENJETH','4h','0.000620410000000','0.000595593600000','2.094411434315159','2.010634976942553','3375.850541279411','3375.850541279411118','test','test','4.0'),('2019-12-29 23:59:59','2019-12-30 03:59:59','ENJETH','4h','0.000610380000000','0.000611650000000','2.075794443787914','2.080113489208162','3400.8231655491886','3400.823165549188616','test','test','0.0'),('2019-12-30 15:59:59','2020-01-01 03:59:59','ENJETH','4h','0.000646780000000','0.000620908800000','2.076754231659080','1.993684062392717','3210.912878659018','3210.912878659018133','test','test','4.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:47:03
