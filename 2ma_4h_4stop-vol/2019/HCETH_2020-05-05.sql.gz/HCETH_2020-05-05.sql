-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-02-08 11:59:59','2019-02-08 15:59:59','HCETH','4h','0.009920000000000','0.009523200000000','1.297777777777778','1.245866666666667','130.82437275985663','130.824372759856630','test','test','4.0'),('2019-02-08 19:59:59','2019-02-13 07:59:59','HCETH','4h','0.009187000000000','0.009364000000000','1.286241975308642','1.311023169346917','140.0067459789531','140.006745978953091','test','test','1.4'),('2019-02-15 11:59:59','2019-02-15 15:59:59','HCETH','4h','0.009391000000000','0.009142000000000','1.291748907317148','1.257498510349629','137.5517950502766','137.551795050276610','test','test','2.7'),('2019-02-16 03:59:59','2019-02-16 07:59:59','HCETH','4h','0.009208000000000','0.009301000000000','1.284137707991032','1.297107387274608','139.4589170276968','139.458917027696799','test','test','0.0'),('2019-02-26 15:59:59','2019-02-27 15:59:59','HCETH','4h','0.008514000000000','0.008266000000000','1.287019858942938','1.249530908388810','151.16512320213033','151.165123202130331','test','test','2.9'),('2019-02-28 11:59:59','2019-02-28 15:59:59','HCETH','4h','0.008341000000000','0.008305000000000','1.278688981042021','1.273170121994244','153.30164021604372','153.301640216043722','test','test','0.4'),('2019-03-01 15:59:59','2019-03-04 11:59:59','HCETH','4h','0.008448000000000','0.008472000000000','1.277462567920292','1.281091722942793','151.21479260420128','151.214792604201278','test','test','0.0'),('2019-03-08 11:59:59','2019-03-20 15:59:59','HCETH','4h','0.008718000000000','0.009494000000000','1.278269046814182','1.392049361144052','146.62411640447138','146.624116404471380','test','test','1.4'),('2019-03-21 03:59:59','2019-03-21 15:59:59','HCETH','4h','0.009750000000000','0.009500000000000','1.303553561109708','1.270129110824844','133.69780113945725','133.697801139457255','test','test','2.6'),('2019-03-23 03:59:59','2019-03-26 07:59:59','HCETH','4h','0.009724000000000','0.009745000000000','1.296125905490850','1.298925025607603','133.29143413110341','133.291434131103415','test','test','0.3'),('2019-03-26 19:59:59','2019-03-27 07:59:59','HCETH','4h','0.009958000000000','0.009846000000000','1.296747932183461','1.282163099043820','130.2217244610827','130.221724461082687','test','test','1.1'),('2019-03-28 03:59:59','2019-03-28 07:59:59','HCETH','4h','0.009948000000000','0.009920000000000','1.293506858152430','1.289866107043839','130.02682530683853','130.026825306838532','test','test','0.3'),('2019-03-31 15:59:59','2019-04-02 07:59:59','HCETH','4h','0.010000000000000','0.009921000000000','1.292697802350521','1.282485489711952','129.26978023505208','129.269780235052082','test','test','0.8'),('2019-04-04 07:59:59','2019-04-04 19:59:59','HCETH','4h','0.009988000000000','0.009962000000000','1.290428399541950','1.287069254729366','129.1978774070835','129.197877407083496','test','test','0.3'),('2019-04-07 03:59:59','2019-04-07 15:59:59','HCETH','4h','0.010152000000000','0.009745920000000','1.289681922916931','1.238094646000254','127.03722644965833','127.037226449658334','test','test','4.0'),('2019-05-30 15:59:59','2019-07-01 11:59:59','HCETH','4h','0.005353000000000','0.014674000000000','1.278218083602114','3.503936513875849','238.78536962490458','238.785369624904575','test','test','0.0'),('2019-07-01 19:59:59','2019-07-01 23:59:59','HCETH','4h','0.014769000000000','0.015223000000000','1.772822179218499','1.827318845842184','120.03671062485608','120.036710624856084','test','test','0.0'),('2019-07-02 11:59:59','2019-07-07 23:59:59','HCETH','4h','0.014893000000000','0.016214000000000','1.784932549579319','1.943254976088033','119.85043641840588','119.850436418405877','test','test','0.0'),('2019-07-08 11:59:59','2019-07-08 15:59:59','HCETH','4h','0.015966000000000','0.015777000000000','1.820115311025699','1.798569413882779','113.9994557826443','113.999455782644304','test','test','1.2'),('2019-07-21 03:59:59','2019-07-21 19:59:59','HCETH','4h','0.014486000000000','0.014124000000000','1.815327333882829','1.769962947933251','125.31598328612651','125.315983286126510','test','test','2.5'),('2019-07-24 07:59:59','2019-07-24 11:59:59','HCETH','4h','0.014361000000000','0.014060000000000','1.805246359227367','1.767409220161324','125.70478095030754','125.704780950307537','test','test','2.1'),('2019-07-24 15:59:59','2019-07-25 07:59:59','HCETH','4h','0.014612000000000','0.014106000000000','1.796838106101579','1.734615269960914','122.97003189854773','122.970031898547731','test','test','3.5'),('2019-07-27 03:59:59','2019-07-27 07:59:59','HCETH','4h','0.014144000000000','0.013982000000000','1.783010809181431','1.762588881078533','126.06128458579124','126.061284585791242','test','test','1.1'),('2019-08-17 11:59:59','2019-08-24 07:59:59','HCETH','4h','0.011182000000000','0.013333000000000','1.778472602936343','2.120584440614404','159.0478092413113','159.047809241311313','test','test','0.0'),('2019-08-25 03:59:59','2019-08-25 07:59:59','HCETH','4h','0.013227000000000','0.013011000000000','1.854497455753690','1.824213079066399','140.20544762634688','140.205447626346881','test','test','1.6'),('2019-08-25 11:59:59','2019-08-25 15:59:59','HCETH','4h','0.013438000000000','0.013110000000000','1.847767594267625','1.802666554609954','137.50316968802093','137.503169688020932','test','test','2.4'),('2019-08-28 15:59:59','2019-08-28 19:59:59','HCETH','4h','0.013314000000000','0.013402000000000','1.837745141010365','1.849891871700534','138.03103057010404','138.031030570104036','test','test','0.0'),('2019-08-28 23:59:59','2019-08-29 03:59:59','HCETH','4h','0.013284000000000','0.012753000000000','1.840444414497070','1.766876514459585','138.5459511063738','138.545951106373792','test','test','4.0'),('2019-08-30 11:59:59','2019-08-30 15:59:59','HCETH','4h','0.012866000000000','0.012767000000000','1.824095992266517','1.810060122280944','141.77646450073973','141.776464500739735','test','test','0.8'),('2019-09-08 07:59:59','2019-09-08 15:59:59','HCETH','4h','0.012761000000000','0.012250560000000','1.820976910047501','1.748137833645601','142.69860591235022','142.698605912350217','test','test','4.0'),('2019-10-27 11:59:59','2019-11-08 15:59:59','HCETH','4h','0.008467000000000','0.009677000000000','1.804790448624857','2.062709008071659','213.15583425355575','213.155834253555753','test','test','0.0'),('2019-11-10 19:59:59','2019-11-11 03:59:59','HCETH','4h','0.009965000000000','0.010089000000000','1.862105684057479','1.885276893773799','186.86459448645047','186.864594486450471','test','test','0.0'),('2019-11-11 07:59:59','2019-11-11 11:59:59','HCETH','4h','0.010059000000000','0.010064000000000','1.867254841772217','1.868182993100268','185.63026561012197','185.630265610121967','test','test','0.0'),('2019-11-11 23:59:59','2019-11-13 19:59:59','HCETH','4h','0.010182000000000','0.010013000000000','1.867461097622895','1.836465131653707','183.40808265791543','183.408082657915429','test','test','1.7'),('2019-11-15 11:59:59','2019-11-15 15:59:59','HCETH','4h','0.010042000000000','0.009640320000000','1.860573105185298','1.786150180977886','185.27913813834869','185.279138138348685','test','test','4.0'),('2019-11-29 11:59:59','2019-11-29 15:59:59','HCETH','4h','0.008554000000000','0.008598000000000','1.844034677583650','1.853520009102668','215.57571634131986','215.575716341319861','test','test','0.0'),('2019-12-05 11:59:59','2019-12-05 15:59:59','HCETH','4h','0.008421000000000','0.008326000000000','1.846142529032321','1.825315603458390','219.23079551506015','219.230795515060152','test','test','1.1'),('2019-12-07 15:59:59','2019-12-07 19:59:59','HCETH','4h','0.008386000000000','0.008407000000000','1.841514323349225','1.846125794943589','219.59388544588904','219.593885445889043','test','test','0.0'),('2019-12-08 19:59:59','2019-12-08 23:59:59','HCETH','4h','0.008348000000000','0.008187000000000','1.842539094814640','1.807003781653984','220.7162308115285','220.716230811528504','test','test','1.9'),('2019-12-13 11:59:59','2019-12-13 15:59:59','HCETH','4h','0.008245000000000','0.008598000000000','1.834642358556716','1.913190418298440','222.51574997655743','222.515749976557430','test','test','0.0'),('2019-12-13 19:59:59','2019-12-14 07:59:59','HCETH','4h','0.008371000000000','0.008339000000000','1.852097482943766','1.845017430446549','221.25164053802004','221.251640538020041','test','test','0.4'),('2019-12-16 19:59:59','2019-12-17 03:59:59','HCETH','4h','0.008456000000000','0.008202000000000','1.850524137944384','1.794938384510387','218.84154895274173','218.841548952741732','test','test','3.0'),('2019-12-17 15:59:59','2019-12-20 15:59:59','HCETH','4h','0.008321000000000','0.008647000000000','1.838171748292385','1.910187610561742','220.907552973487','220.907552973486986','test','test','0.0'),('2019-12-22 11:59:59','2019-12-22 23:59:59','HCETH','4h','0.008563000000000','0.008603000000000','1.854175273241131','1.862836608162262','216.53337302827643','216.533373028276429','test','test','0.7'),('2019-12-23 11:59:59','2019-12-23 19:59:59','HCETH','4h','0.008504000000000','0.008600000000000','1.856100014334715','1.877053165954675','218.26199604124125','218.261996041241247','test','test','0.0'),('2019-12-23 23:59:59','2019-12-26 19:59:59','HCETH','4h','0.008588000000000','0.008658000000000','1.860756270250262','1.875923123873634','216.66933747674221','216.669337476742214','test','test','0.0'),('2019-12-27 11:59:59','2019-12-28 19:59:59','HCETH','4h','0.008984000000000','0.008716000000000','1.864126682166567','1.808518272680743','207.49406524561076','207.494065245610756','test','test','3.0'),('2020-01-07 11:59:59','2020-01-08 19:59:59','HCETH','4h','0.008624000000000','0.008432000000000','1.851769257836384','1.810542484007003','214.7227803613618','214.722780361361799','test','test','2.2'),('2020-01-11 15:59:59','2020-01-11 19:59:59','HCETH','4h','0.008593000000000','0.008453000000000','1.842607752540966','1.812587377194087','214.43125247771044','214.431252477710444','test','test','1.6'),('2020-01-12 19:59:59','2020-01-13 07:59:59','HCETH','4h','0.008494000000000','0.008317000000000','1.835936558019437','1.797678873681146','216.1451092558791','216.145109255879106','test','test','2.1'),('2020-01-15 03:59:59','2020-01-16 03:59:59','HCETH','4h','0.009394000000000','0.009018240000000','1.827434850388706','1.754337456373157','194.53213225342833','194.532132253428330','test','test','4.0'),('2020-01-17 15:59:59','2020-01-18 15:59:59','HCETH','4h','0.009011000000000','0.008735000000000','1.811190985051917','1.755715598094384','200.997778831641','200.997778831641000','test','test','3.1'),('2020-01-26 19:59:59','2020-01-28 23:59:59','HCETH','4h','0.008974000000000','0.008835000000000','1.798863121283577','1.771000186821975','200.45276591080642','200.452765910806420','test','test','1.6'),('2020-01-29 19:59:59','2020-01-30 19:59:59','HCETH','4h','0.008942000000000','0.008997000000000','1.792671358069887','1.803697630122430','200.47767368260872','200.477673682608724','test','test','2.1'),('2020-01-30 23:59:59','2020-02-04 11:59:59','HCETH','4h','0.008965000000000','0.009051000000000','1.795121640748230','1.812341993353288','200.2366581983525','200.236658198352501','test','test','0.6'),('2020-02-04 15:59:59','2020-02-04 15:59:59','HCETH','4h','0.009040000000000','0.009040000000000','1.798948385771576','1.798948385771576','198.99871524021864','198.998715240218644','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:24:01
