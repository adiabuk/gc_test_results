-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-10 11:59:59','ADAUSDT','4h','0.041980000000000','0.045670000000000','222.222222222222200','241.755333227462785','5293.526017680376','5293.526017680375844','test','test','0.6'),('2019-01-16 15:59:59','2019-01-17 11:59:59','ADAUSDT','4h','0.044130000000000','0.044340000000000','226.562913556720133','227.641051146724919','5133.988523832317','5133.988523832316787','test','test','0.0'),('2019-01-17 19:59:59','2019-01-18 07:59:59','ADAUSDT','4h','0.043970000000000','0.044150000000000','226.802499687832295','227.730961137543687','5158.119165063277','5158.119165063277251','test','test','0.1'),('2019-01-19 11:59:59','2019-01-20 11:59:59','ADAUSDT','4h','0.045440000000000','0.043622400000000','227.008824454434830','217.928471476257442','4995.7927916909075','4995.792791690907507','test','test','4.0'),('2019-02-08 15:59:59','2019-02-14 11:59:59','ADAUSDT','4h','0.039880000000000','0.040140000000000','224.990968237062106','226.457810056060055','5641.699303838067','5641.699303838066953','test','test','0.0'),('2019-02-15 11:59:59','2019-02-15 15:59:59','ADAUSDT','4h','0.040630000000000','0.040240000000000','225.316933085728323','223.154156715966224','5545.580435287431','5545.580435287431101','test','test','1.0'),('2019-02-16 15:59:59','2019-02-24 15:59:59','ADAUSDT','4h','0.041200000000000','0.042700000000000','224.836316114670041','233.022104322728438','5457.192138705584','5457.192138705583602','test','test','1.0'),('2019-03-05 19:59:59','2019-03-05 23:59:59','ADAUSDT','4h','0.043160000000000','0.042920000000000','226.655380160905253','225.395016601159739','5251.51483227306','5251.514832273060165','test','test','0.6'),('2019-03-06 11:59:59','2019-03-06 15:59:59','ADAUSDT','4h','0.042840000000000','0.042540000000000','226.375299369850694','224.790038169781695','5284.204000229941','5284.204000229940902','test','test','0.7'),('2019-03-07 03:59:59','2019-03-07 07:59:59','ADAUSDT','4h','0.043000000000000','0.042640000000000','226.023019103168707','224.130733361839845','5256.34928146904','5256.349281469039852','test','test','0.8'),('2019-03-07 19:59:59','2019-03-07 23:59:59','ADAUSDT','4h','0.043120000000000','0.042750000000000','225.602511160651176','223.666682563029667','5231.969182760928','5231.969182760927652','test','test','0.9'),('2019-03-08 15:59:59','2019-03-08 23:59:59','ADAUSDT','4h','0.043070000000000','0.042430000000000','225.172327027846364','221.826371854922741','5228.054957693206','5228.054957693206234','test','test','1.5'),('2019-03-09 07:59:59','2019-04-09 07:59:59','ADAUSDT','4h','0.044010000000000','0.082850000000000','224.428781433863350','422.493172956045839','5099.495147327048','5099.495147327047562','test','test','0.0'),('2019-04-09 15:59:59','2019-04-11 07:59:59','ADAUSDT','4h','0.083750000000000','0.084950000000000','268.443090661015049','272.289439422725081','3205.2906347583885','3205.290634758388478','test','test','1.0'),('2019-04-14 23:59:59','2019-04-15 11:59:59','ADAUSDT','4h','0.084160000000000','0.082360000000000','269.297834830283932','263.538137792563987','3199.831687622195','3199.831687622195204','test','test','2.1'),('2019-04-15 15:59:59','2019-04-15 19:59:59','ADAUSDT','4h','0.082850000000000','0.080880000000000','268.017902155235049','261.644996093125030','3234.9776965025358','3234.977696502535764','test','test','2.4'),('2019-04-18 03:59:59','2019-04-18 11:59:59','ADAUSDT','4h','0.082840000000000','0.081900000000000','266.601700808099508','263.576524579712100','3218.272583390868','3218.272583390868022','test','test','1.1'),('2019-05-11 11:59:59','2019-05-12 15:59:59','ADAUSDT','4h','0.069500000000000','0.069000000000000','265.929439424013424','264.016277989308321','3826.322869410265','3826.322869410264957','test','test','0.7'),('2019-05-13 15:59:59','2019-05-17 15:59:59','ADAUSDT','4h','0.074770000000000','0.077640000000000','265.504292438523350','275.695509762297092','3550.9468027086177','3550.946802708617724','test','test','2.8'),('2019-05-19 03:59:59','2019-05-22 15:59:59','ADAUSDT','4h','0.084370000000000','0.082860000000000','267.769007399362010','262.976649912423113','3173.7466800919997','3173.746680091999679','test','test','3.4'),('2019-05-24 11:59:59','2019-05-24 23:59:59','ADAUSDT','4h','0.082200000000000','0.080620000000000','266.704039068931081','261.577611067362795','3244.5746845368744','3244.574684536874429','test','test','1.9'),('2019-05-26 19:59:59','2019-05-30 23:59:59','ADAUSDT','4h','0.082760000000000','0.083920000000000','265.564832846360389','269.287104548895172','3208.854915978255','3208.854915978255121','test','test','0.0'),('2019-06-01 23:59:59','2019-06-03 23:59:59','ADAUSDT','4h','0.090470000000000','0.087450000000000','266.392004335812544','257.499511209979119','2944.5341476269764','2944.534147626976392','test','test','3.3'),('2019-06-10 23:59:59','2019-06-11 03:59:59','ADAUSDT','4h','0.085080000000000','0.083640000000000','264.415894752294037','259.940590468757307','3107.8501969004938','3107.850196900493756','test','test','1.7'),('2019-06-11 19:59:59','2019-06-14 15:59:59','ADAUSDT','4h','0.088420000000000','0.086400000000000','263.421382689285849','257.403386839564575','2979.205866198664','2979.205866198663898','test','test','2.3'),('2019-06-16 07:59:59','2019-06-18 07:59:59','ADAUSDT','4h','0.092570000000000','0.089290000000000','262.084050278236703','252.797719016352517','2831.1985554524867','2831.198555452486744','test','test','3.5'),('2019-06-21 07:59:59','2019-06-21 11:59:59','ADAUSDT','4h','0.089430000000000','0.089960000000000','260.020421108929099','261.561412087210783','2907.530147701321','2907.530147701320857','test','test','0.0'),('2019-06-22 03:59:59','2019-06-22 15:59:59','ADAUSDT','4h','0.090650000000000','0.093460000000000','260.362863548547296','268.433681491971697','2872.1772040656074','2872.177204065607384','test','test','0.8'),('2019-06-22 19:59:59','2019-06-27 07:59:59','ADAUSDT','4h','0.095450000000000','0.093110000000000','262.156378647086001','255.729496237089364','2746.5309444430177','2746.530944443017688','test','test','2.5'),('2019-07-20 19:59:59','2019-07-20 23:59:59','ADAUSDT','4h','0.064740000000000','0.062620000000000','260.728182555975593','252.190280995600688','4027.3120567805927','4027.312056780592684','test','test','3.3'),('2019-07-26 11:59:59','2019-07-26 15:59:59','ADAUSDT','4h','0.061410000000000','0.061230000000000','258.830871098114528','258.072207089033611','4214.800050449675','4214.800050449674927','test','test','0.3'),('2019-07-26 19:59:59','2019-07-27 11:59:59','ADAUSDT','4h','0.062500000000000','0.060000000000000','258.662279096096597','248.315787932252732','4138.596465537546','4138.596465537545555','test','test','4.0'),('2019-07-29 15:59:59','2019-07-29 23:59:59','ADAUSDT','4h','0.061570000000000','0.060350000000000','256.363058837464621','251.283264590563419','4163.765776148524','4163.765776148524310','test','test','2.0'),('2019-07-30 15:59:59','2019-07-30 19:59:59','ADAUSDT','4h','0.060470000000000','0.060160000000000','255.234215671486567','253.925755164488663','4220.8403451544','4220.840345154399984','test','test','0.5'),('2019-07-31 03:59:59','2019-07-31 07:59:59','ADAUSDT','4h','0.060490000000000','0.060100000000000','254.943446669931433','253.299737888293578','4214.6379016355','4214.637901635500384','test','test','0.6'),('2019-08-11 19:59:59','2019-08-12 03:59:59','ADAUSDT','4h','0.055350000000000','0.053280000000000','254.578178051789706','245.057368140909745','4599.425077719778','4599.425077719777619','test','test','3.7'),('2019-08-24 19:59:59','2019-08-25 19:59:59','ADAUSDT','4h','0.050280000000000','0.049780000000000','252.462442516038635','249.951877256332580','5021.130519412065','5021.130519412065041','test','test','1.0'),('2019-09-07 23:59:59','2019-09-09 03:59:59','ADAUSDT','4h','0.045970000000000','0.045700000000000','251.904539124992851','250.425004089888461','5479.759389275459','5479.759389275459398','test','test','0.6'),('2019-09-09 11:59:59','2019-09-10 19:59:59','ADAUSDT','4h','0.046180000000000','0.045970000000000','251.575753561636276','250.431732161724085','5447.720951962674','5447.720951962674008','test','test','0.5'),('2019-09-14 19:59:59','2019-09-16 15:59:59','ADAUSDT','4h','0.046780000000000','0.045870000000000','251.321526583878040','246.432629850416532','5372.413992814836','5372.413992814836092','test','test','1.9'),('2019-09-16 23:59:59','2019-09-22 07:59:59','ADAUSDT','4h','0.047020000000000','0.049490000000000','250.235105087553279','263.380164840132124','5321.886539505599','5321.886539505599103','test','test','0.0'),('2019-10-07 15:59:59','2019-10-11 07:59:59','ADAUSDT','4h','0.041240000000000','0.040450000000000','253.156229477015160','248.306728475879339','6138.608862197264','6138.608862197263988','test','test','1.9'),('2019-10-11 15:59:59','2019-10-11 19:59:59','ADAUSDT','4h','0.040920000000000','0.040470000000000','252.078562587873904','249.306437632728660','6160.277678100536','6160.277678100535923','test','test','1.1'),('2019-10-13 23:59:59','2019-10-14 19:59:59','ADAUSDT','4h','0.041270000000000','0.041580000000000','251.462534820063865','253.351398057142092','6093.107216381484','6093.107216381484250','test','test','0.1'),('2019-10-14 23:59:59','2019-10-15 11:59:59','ADAUSDT','4h','0.041730000000000','0.041240000000000','251.882282206081214','248.924642180177045','6036.000052865593','6036.000052865592806','test','test','1.6'),('2019-10-22 03:59:59','2019-10-22 07:59:59','ADAUSDT','4h','0.039840000000000','0.039510000000000','251.225028866991437','249.144098658002832','6305.8491181473755','6305.849118147375520','test','test','0.8'),('2019-10-25 15:59:59','2019-10-31 11:59:59','ADAUSDT','4h','0.040070000000000','0.041020000000000','250.762599931660617','256.707807566676308','6258.113300016486','6258.113300016486392','test','test','1.0'),('2019-10-31 15:59:59','2019-10-31 23:59:59','ADAUSDT','4h','0.040890000000000','0.041260000000000','252.083757183886320','254.364779198022688','6164.924362530846','6164.924362530846338','test','test','0.0'),('2019-11-01 03:59:59','2019-11-08 11:59:59','ADAUSDT','4h','0.041760000000000','0.042570000000000','252.590650964805519','257.490038591278051','6048.626699348792','6048.626699348791590','test','test','1.0'),('2019-11-10 19:59:59','2019-11-11 11:59:59','ADAUSDT','4h','0.043470000000000','0.042970000000000','253.679403770688310','250.761536232493143','5835.735076390345','5835.735076390345057','test','test','1.2'),('2019-11-12 03:59:59','2019-11-14 07:59:59','ADAUSDT','4h','0.043740000000000','0.042480000000000','253.030988762200508','245.742030238186487','5784.8877174714335','5784.887717471433461','test','test','2.9'),('2019-11-15 11:59:59','2019-11-15 15:59:59','ADAUSDT','4h','0.043380000000000','0.042360000000000','251.411220201308453','245.499753059645599','5795.556021238092','5795.556021238092399','test','test','2.4'),('2019-11-15 23:59:59','2019-11-18 19:59:59','ADAUSDT','4h','0.043880000000000','0.043370000000000','250.097560836494523','247.190775147647372','5699.5797820532025','5699.579782053202507','test','test','1.2'),('2019-11-27 19:59:59','2019-11-28 03:59:59','ADAUSDT','4h','0.039340000000000','0.038410000000000','249.451608461195178','243.554557218975759','6340.915314214418','6340.915314214417776','test','test','2.4'),('2019-11-28 23:59:59','2019-12-01 03:59:59','ADAUSDT','4h','0.039010000000000','0.038790000000000','248.141152629590835','246.741740848547238','6360.962641107173','6360.962641107173113','test','test','0.6'),('2019-12-07 19:59:59','2019-12-08 03:59:59','ADAUSDT','4h','0.038890000000000','0.038170000000000','247.830172233803410','243.241904709803975','6372.593783332563','6372.593783332563362','test','test','1.9'),('2019-12-08 11:59:59','2019-12-09 03:59:59','ADAUSDT','4h','0.038620000000000','0.038400000000000','246.810557228470174','245.404593412046950','6390.74462010539','6390.744620105389913','test','test','0.6'),('2019-12-26 19:59:59','2019-12-26 23:59:59','ADAUSDT','4h','0.034420000000000','0.034160000000000','246.498120824820518','244.636136181751027','7161.479396421282','7161.479396421282217','test','test','0.8'),('2019-12-29 23:59:59','2019-12-30 03:59:59','ADAUSDT','4h','0.034120000000000','0.034050000000000','246.084346459694046','245.579484084190568','7212.319650049651','7212.319650049650591','test','test','0.2');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:38:31
