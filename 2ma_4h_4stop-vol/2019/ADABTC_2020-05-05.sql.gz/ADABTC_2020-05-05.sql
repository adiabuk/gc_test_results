-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-10 15:59:59','ADABTC','4h','0.000011280000000','0.000011970000000','0.033333333333333','0.035372340425532','2955.082742316785','2955.082742316784788','test','test','1.2'),('2019-01-10 19:59:59','2019-01-11 07:59:59','ADABTC','4h','0.000012000000000','0.000012110000000','0.033786446020489','0.034096155109010','2815.537168374056','2815.537168374055909','test','test','0.4'),('2019-01-14 19:59:59','2019-01-15 03:59:59','ADABTC','4h','0.000011920000000','0.000011900000000','0.033855270262382','0.033798466117646','2840.207236777032','2840.207236777031994','test','test','0.2'),('2019-01-15 23:59:59','2019-01-16 03:59:59','ADABTC','4h','0.000011830000000','0.000012010000000','0.033842647119108','0.034357581732924','2860.747854531492','2860.747854531492067','test','test','0.0'),('2019-01-16 07:59:59','2019-01-20 15:59:59','ADABTC','4h','0.000012050000000','0.000012040000000','0.033957077033289','0.033928896886373','2818.014691559244','2818.014691559244056','test','test','0.1'),('2019-01-22 19:59:59','2019-01-23 07:59:59','ADABTC','4h','0.000012180000000','0.000012090000000','0.033950814778419','0.033699946688923','2787.4232166189386','2787.423216618938568','test','test','0.7'),('2019-01-23 15:59:59','2019-01-23 19:59:59','ADABTC','4h','0.000012140000000','0.000012050000000','0.033895066314086','0.033643784932845','2792.015347124071','2792.015347124071013','test','test','0.7'),('2019-02-08 15:59:59','2019-02-08 19:59:59','ADABTC','4h','0.000011360000000','0.000011240000000','0.033839226007144','0.033481769394392','2978.805106262657','2978.805106262656864','test','test','1.1'),('2019-02-08 23:59:59','2019-02-10 07:59:59','ADABTC','4h','0.000011130000000','0.000011140000000','0.033759791204310','0.033790123451574','3033.2247263531','3033.224726353099868','test','test','0.0'),('2019-02-10 19:59:59','2019-02-14 03:59:59','ADABTC','4h','0.000011450000000','0.000011330000000','0.033766531703702','0.033412646655279','2949.042070192315','2949.042070192314895','test','test','1.3'),('2019-02-16 15:59:59','2019-02-17 03:59:59','ADABTC','4h','0.000011340000000','0.000011290000000','0.033687890581830','0.033539354909071','2970.7134551878507','2970.713455187850741','test','test','0.4'),('2019-02-17 11:59:59','2019-02-17 15:59:59','ADABTC','4h','0.000011310000000','0.000011240000000','0.033654882654550','0.033446585414425','2975.6748589346107','2975.674858934610711','test','test','0.6'),('2019-02-17 23:59:59','2019-02-18 03:59:59','ADABTC','4h','0.000011340000000','0.000011540000000','0.033608594378967','0.034201338547908','2963.720844706095','2963.720844706094795','test','test','0.0'),('2019-02-18 07:59:59','2019-02-21 11:59:59','ADABTC','4h','0.000011490000000','0.000011460000000','0.033740315305398','0.033652220487368','2936.4939343253654','2936.493934325365444','test','test','0.3'),('2019-02-23 19:59:59','2019-02-24 15:59:59','ADABTC','4h','0.000011730000000','0.000011310000000','0.033720738679170','0.032513346501399','2874.7432804066125','2874.743280406612485','test','test','3.6'),('2019-03-09 07:59:59','2019-04-02 07:59:59','ADABTC','4h','0.000011250000000','0.000016690000000','0.033452429306332','0.049628537344238','2973.549271673916','2973.549271673915882','test','test','0.0'),('2019-04-02 11:59:59','2019-04-08 03:59:59','ADABTC','4h','0.000016660000000','0.000016860000000','0.037047119981422','0.037491863318534','2223.71668555953','2223.716685559530106','test','test','0.0'),('2019-05-15 15:59:59','2019-05-15 19:59:59','ADABTC','4h','0.000011010000000','0.000010970000000','0.037145951834113','0.037010998330628','3373.8375871129274','3373.837587112927395','test','test','0.4'),('2019-05-15 23:59:59','2019-05-16 11:59:59','ADABTC','4h','0.000011490000000','0.000011030400000','0.037115962166672','0.035631323680005','3230.283913548496','3230.283913548496002','test','test','4.0'),('2019-05-17 03:59:59','2019-05-17 07:59:59','ADABTC','4h','0.000011030000000','0.000010980000000','0.036786042502968','0.036619288003861','3335.0899821367584','3335.089982136758408','test','test','0.5'),('2019-05-28 19:59:59','2019-05-29 03:59:59','ADABTC','4h','0.000010480000000','0.000010370000000','0.036748985947611','0.036363261858466','3506.582628588868','3506.582628588867919','test','test','1.0'),('2019-05-29 15:59:59','2019-05-30 19:59:59','ADABTC','4h','0.000010590000000','0.000010380000000','0.036663269483357','0.035936235810882','3462.0651070214244','3462.065107021424410','test','test','2.0'),('2019-06-01 23:59:59','2019-06-04 07:59:59','ADABTC','4h','0.000010580000000','0.000010710000000','0.036501706445029','0.036950215125355','3450.066771741882','3450.066771741881894','test','test','0.0'),('2019-06-06 23:59:59','2019-06-08 07:59:59','ADABTC','4h','0.000010670000000','0.000010650000000','0.036601375040657','0.036532768901874','3430.3069391431227','3430.306939143122690','test','test','0.7'),('2019-06-10 23:59:59','2019-06-11 03:59:59','ADABTC','4h','0.000010660000000','0.000010550000000','0.036586129232039','0.036208598817825','3432.0946746752975','3432.094674675297483','test','test','1.0'),('2019-06-11 11:59:59','2019-06-13 19:59:59','ADABTC','4h','0.000010640000000','0.000010980000000','0.036502233584436','0.037668658341833','3430.6610511687554','3430.661051168755421','test','test','0.0'),('2019-07-24 15:59:59','2019-07-24 19:59:59','ADABTC','4h','0.000005930000000','0.000005870000000','0.036761439086079','0.036389485233606','6199.230874549636','6199.230874549635701','test','test','1.0'),('2019-07-24 23:59:59','2019-07-25 03:59:59','ADABTC','4h','0.000006030000000','0.000005920000000','0.036678782674419','0.036009683819662','6082.7168614293','6082.716861429299570','test','test','1.8'),('2019-07-25 15:59:59','2019-07-31 07:59:59','ADABTC','4h','0.000005920000000','0.000006180000000','0.036530094040028','0.038134456278272','6170.62399324801','6170.623993248010265','test','test','0.3'),('2019-07-31 11:59:59','2019-07-31 15:59:59','ADABTC','4h','0.000006160000000','0.000005970000000','0.036886618981860','0.035748882357420','5988.08749705523','5988.087497055230415','test','test','3.1'),('2019-08-14 03:59:59','2019-08-14 15:59:59','ADABTC','4h','0.000004990000000','0.000004980000000','0.036633788620874','0.036560374214820','7341.440605385483','7341.440605385482741','test','test','1.8'),('2019-08-18 15:59:59','2019-08-19 07:59:59','ADABTC','4h','0.000004760000000','0.000004730000000','0.036617474308417','0.036386691907314','7692.746703448974','7692.746703448973676','test','test','0.6'),('2019-08-22 03:59:59','2019-08-23 15:59:59','ADABTC','4h','0.000004810000000','0.000004770000000','0.036566189330394','0.036262104595838','7602.118363907323','7602.118363907323328','test','test','1.5'),('2019-08-24 11:59:59','2019-08-26 03:59:59','ADABTC','4h','0.000004880000000','0.000004820000000','0.036498614944937','0.036049861482499','7479.224373962569','7479.224373962569189','test','test','1.2'),('2019-08-26 15:59:59','2019-08-26 19:59:59','ADABTC','4h','0.000004840000000','0.000004840000000','0.036398891953284','0.036398891953284','7520.432221752984','7520.432221752984333','test','test','0.0'),('2019-08-28 03:59:59','2019-08-28 11:59:59','ADABTC','4h','0.000004880000000','0.000004810000000','0.036398891953284','0.035876776699856','7458.789334689436','7458.789334689436146','test','test','1.4'),('2019-09-08 07:59:59','2019-09-08 15:59:59','ADABTC','4h','0.000004470000000','0.000004570000000','0.036282866341412','0.037094563575001','8116.972335886253','8116.972335886252949','test','test','0.2'),('2019-09-10 03:59:59','2019-09-11 11:59:59','ADABTC','4h','0.000004610000000','0.000004490000000','0.036463243504431','0.035514091829695','7909.5972894644965','7909.597289464496498','test','test','2.6'),('2019-09-14 19:59:59','2019-09-22 11:59:59','ADABTC','4h','0.000004520000000','0.000004880000000','0.036252320910046','0.039139673902882','8020.424980098574','8020.424980098574451','test','test','0.9'),('2019-09-23 15:59:59','2019-09-23 23:59:59','ADABTC','4h','0.000004970000000','0.000004771200000','0.036893954908454','0.035418196712116','7423.330967495685','7423.330967495685400','test','test','4.0'),('2019-09-30 11:59:59','2019-09-30 15:59:59','ADABTC','4h','0.000004810000000','0.000004700000000','0.036566008642601','0.035729779754724','7602.080798877478','7602.080798877477719','test','test','2.3'),('2019-10-02 19:59:59','2019-10-02 23:59:59','ADABTC','4h','0.000004740000000','0.000004700000000','0.036380180000850','0.036073174262446','7675.143460094984','7675.143460094984221','test','test','0.8'),('2019-10-04 11:59:59','2019-10-09 15:59:59','ADABTC','4h','0.000004740000000','0.000004960000000','0.036311956503427','0.037997321573206','7660.750317178715','7660.750317178714795','test','test','0.0'),('2019-10-09 19:59:59','2019-10-10 03:59:59','ADABTC','4h','0.000004920000000','0.000004870000000','0.036686482074489','0.036313651972106','7456.602047660389','7456.602047660388962','test','test','1.0'),('2019-10-13 15:59:59','2019-10-15 19:59:59','ADABTC','4h','0.000004940000000','0.000004810000000','0.036603630940626','0.035640377494820','7409.641890815024','7409.641890815024453','test','test','2.6'),('2019-10-19 15:59:59','2019-10-19 19:59:59','ADABTC','4h','0.000004890000000','0.000004890000000','0.036389574619336','0.036389574619336','7441.630801500205','7441.630801500205052','test','test','0.0'),('2019-10-23 15:59:59','2019-10-23 19:59:59','ADABTC','4h','0.000004860000000','0.000004840000000','0.036389574619336','0.036239823283454','7487.566794102057','7487.566794102057429','test','test','0.4'),('2019-10-24 03:59:59','2019-10-25 15:59:59','ADABTC','4h','0.000004880000000','0.000004860000000','0.036356296544696','0.036207295329349','7450.060767355647','7450.060767355646931','test','test','0.4'),('2019-11-04 19:59:59','2019-11-04 23:59:59','ADABTC','4h','0.000004620000000','0.000004600000000','0.036323185163507','0.036165941937691','7862.161290802454','7862.161290802453550','test','test','0.4'),('2019-11-05 03:59:59','2019-11-07 11:59:59','ADABTC','4h','0.000004730000000','0.000004690000000','0.036288242224437','0.035981364911757','7671.932817005732','7671.932817005732431','test','test','0.8'),('2019-11-08 15:59:59','2019-11-20 11:59:59','ADABTC','4h','0.000004730000000','0.000005100000000','0.036220047266064','0.039053327919012','7657.515278237586','7657.515278237586244','test','test','0.0'),('2019-11-22 15:59:59','2019-11-22 19:59:59','ADABTC','4h','0.000005100000000','0.000005180000000','0.036849665188941','0.037427699152689','7225.424546851197','7225.424546851197192','test','test','0.0'),('2019-11-22 23:59:59','2019-11-24 15:59:59','ADABTC','4h','0.000005090000000','0.000005050000000','0.036978117180885','0.036687522939778','7264.856027678803','7264.856027678803002','test','test','0.8'),('2019-11-24 19:59:59','2019-11-24 23:59:59','ADABTC','4h','0.000005090000000','0.000005070000000','0.036913540682861','0.036768497301003','7252.169092900064','7252.169092900064243','test','test','0.4'),('2019-11-25 03:59:59','2019-11-25 07:59:59','ADABTC','4h','0.000005080000000','0.000005060000000','0.036881308820226','0.036736106816997','7260.100161461855','7260.100161461855350','test','test','0.4'),('2019-11-25 11:59:59','2019-11-25 15:59:59','ADABTC','4h','0.000005100000000','0.000005080000000','0.036849041708398','0.036704535662483','7225.302295764226','7225.302295764226074','test','test','0.4'),('2019-11-26 15:59:59','2019-11-26 19:59:59','ADABTC','4h','0.000005120000000','0.000005070000000','0.036816929253750','0.036457388929006','7190.806494873003','7190.806494873003430','test','test','1.0'),('2019-11-27 11:59:59','2019-12-02 07:59:59','ADABTC','4h','0.000005200000000','0.000005230000000','0.036737031403807','0.036948975815752','7064.813731501282','7064.813731501281836','test','test','1.3'),('2019-12-13 11:59:59','2019-12-13 15:59:59','ADABTC','4h','0.000005150000000','0.000005120000000','0.036784130162017','0.036569853675636','7142.549546022655','7142.549546022654795','test','test','0.6'),('2019-12-13 19:59:59','2019-12-13 23:59:59','ADABTC','4h','0.000005120000000','0.000005140000000','0.036736513165043','0.036880015169594','7175.100227547482','7175.100227547482064','test','test','0.0'),('2019-12-14 19:59:59','2019-12-14 23:59:59','ADABTC','4h','0.000005130000000','0.000005130000000','0.036768402499388','0.036768402499388','7167.329921907949','7167.329921907949029','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:20:47
