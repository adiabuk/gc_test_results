-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-11 15:59:59','LENDETH','4h','0.000056430000000','0.000056130000000','1.297777777777778','1.290878374387146','22998.011302104867','22998.011302104867355','test','test','0.5'),('2019-01-12 19:59:59','2019-01-27 19:59:59','LENDETH','4h','0.000057470000000','0.000071400000000','1.296244577024304','1.610437842344446','22555.15185356367','22555.151853563671466','test','test','0.0'),('2019-01-28 15:59:59','2019-01-28 19:59:59','LENDETH','4h','0.000070110000000','0.000069690000000','1.366065302651002','1.357881770671064','19484.599952232235','19484.599952232234500','test','test','0.6'),('2019-01-29 11:59:59','2019-01-30 15:59:59','LENDETH','4h','0.000070100000000','0.000070520000000','1.364246739988794','1.372420543566473','19461.43708971175','19461.437089711751469','test','test','0.0'),('2019-02-01 19:59:59','2019-02-02 07:59:59','LENDETH','4h','0.000072100000000','0.000070330000000','1.366063140783833','1.332527332750721','18946.78419949838','18946.784199498379166','test','test','2.5'),('2019-02-02 19:59:59','2019-02-03 03:59:59','LENDETH','4h','0.000073720000000','0.000070771200000','1.358610738998697','1.304266309438749','18429.33720833827','18429.337208338271012','test','test','4.0'),('2019-02-26 23:59:59','2019-02-27 03:59:59','LENDETH','4h','0.000056590000000','0.000056600000000','1.346534199096487','1.346772144705092','23794.560860513993','23794.560860513993248','test','test','0.0'),('2019-02-28 07:59:59','2019-02-28 11:59:59','LENDETH','4h','0.000057260000000','0.000056060000000','1.346587075898399','1.318366599281597','23517.06384733495','23517.063847334949969','test','test','2.1'),('2019-03-01 19:59:59','2019-03-06 15:59:59','LENDETH','4h','0.000057900000000','0.000061610000000','1.340315858872443','1.426197928586031','23148.805852719222','23148.805852719222457','test','test','1.6'),('2019-03-08 07:59:59','2019-03-16 23:59:59','LENDETH','4h','0.000063930000000','0.000066770000000','1.359400763253240','1.419790223094304','21263.894310233693','21263.894310233692522','test','test','0.7'),('2019-03-26 19:59:59','2019-04-02 07:59:59','LENDETH','4h','0.000065560000000','0.000071990000000','1.372820643217921','1.507464278603693','20939.91219063333','20939.912190633331193','test','test','0.0'),('2019-04-02 11:59:59','2019-04-02 15:59:59','LENDETH','4h','0.000070410000000','0.000069380000000','1.402741451081426','1.382221302031378','19922.474805871698','19922.474805871697754','test','test','1.5'),('2019-04-04 15:59:59','2019-04-05 07:59:59','LENDETH','4h','0.000070120000000','0.000068740000000','1.398181417959193','1.370664441963989','19939.837677683878','19939.837677683877700','test','test','2.0'),('2019-04-05 15:59:59','2019-04-06 15:59:59','LENDETH','4h','0.000072970000000','0.000070051200000','1.392066534404703','1.336383873028515','19077.244544397745','19077.244544397744903','test','test','4.0'),('2019-04-07 23:59:59','2019-04-08 03:59:59','LENDETH','4h','0.000070280000000','0.000067468800000','1.379692609654440','1.324504905268262','19631.368947843475','19631.368947843475325','test','test','4.0'),('2019-04-14 15:59:59','2019-04-15 11:59:59','LENDETH','4h','0.000066910000000','0.000066740000000','1.367428675346400','1.363954413280806','20436.83567996413','20436.835679964129667','test','test','0.4'),('2019-04-18 23:59:59','2019-04-19 03:59:59','LENDETH','4h','0.000066800000000','0.000065300000000','1.366656617109601','1.335968220018817','20458.931393856306','20458.931393856306386','test','test','2.2'),('2019-04-19 07:59:59','2019-04-19 15:59:59','LENDETH','4h','0.000067210000000','0.000065620000000','1.359836973311649','1.327667046402476','20232.658433442186','20232.658433442185924','test','test','2.4'),('2019-05-20 15:59:59','2019-05-20 19:59:59','LENDETH','4h','0.000039490000000','0.000037910400000','1.352688100665166','1.298580576638559','34253.940254878864','34253.940254878863925','test','test','4.0'),('2019-05-22 19:59:59','2019-05-22 23:59:59','LENDETH','4h','0.000041190000000','0.000039542400000','1.340664206437031','1.287037638179550','32548.29343134332','32548.293431343321572','test','test','4.0'),('2019-05-24 11:59:59','2019-05-24 15:59:59','LENDETH','4h','0.000039260000000','0.000038310000000','1.328747191268702','1.296594622962404','33844.80874347179','33844.808743471789057','test','test','2.4'),('2019-05-26 11:59:59','2019-05-26 15:59:59','LENDETH','4h','0.000038600000000','0.000038980000000','1.321602176089525','1.334612767460354','34238.39834428821','34238.398344288209046','test','test','0.0'),('2019-06-07 15:59:59','2019-06-07 19:59:59','LENDETH','4h','0.000034880000000','0.000034490000000','1.324493418616376','1.309684002525195','37972.86177225848','37972.861772258482233','test','test','1.1'),('2019-06-08 07:59:59','2019-06-12 15:59:59','LENDETH','4h','0.000036130000000','0.000037870000000','1.321202437262780','1.384830786026612','36568.016530937726','36568.016530937726202','test','test','0.4'),('2019-06-16 07:59:59','2019-06-19 15:59:59','LENDETH','4h','0.000038670000000','0.000049770000000','1.335342070321410','1.718644293765104','34531.731841774235','34531.731841774235363','test','test','0.3'),('2019-06-19 19:59:59','2019-06-19 23:59:59','LENDETH','4h','0.000038610000000','0.000037360000000','1.420520342197786','1.374530950129741','36791.513654436305','36791.513654436304932','test','test','3.2'),('2019-07-22 11:59:59','2019-07-22 23:59:59','LENDETH','4h','0.000022800000000','0.000022300000000','1.410300477293776','1.379372835247860','61855.28409183227','61855.284091832269041','test','test','2.2'),('2019-07-25 19:59:59','2019-07-25 23:59:59','LENDETH','4h','0.000022300000000','0.000022800000000','1.403427667950239','1.434894656020872','62933.97614126632','62933.976141266321065','test','test','0.0'),('2019-07-26 03:59:59','2019-07-26 07:59:59','LENDETH','4h','0.000022600000000','0.000022400000000','1.410420331965935','1.397938736107829','62407.97929052809','62407.979290528091951','test','test','0.9'),('2019-07-28 19:59:59','2019-07-28 23:59:59','LENDETH','4h','0.000022500000000','0.000022300000000','1.407646643997467','1.395134229384156','62562.073066554076','62562.073066554075922','test','test','0.9'),('2019-07-29 03:59:59','2019-07-29 07:59:59','LENDETH','4h','0.000022390000000','0.000022200000000','1.404866107416731','1.392944510256875','62745.24820976915','62745.248209769153618','test','test','0.8'),('2019-08-13 15:59:59','2019-08-13 19:59:59','LENDETH','4h','0.000018590000000','0.000018400000000','1.402216863603430','1.387885437886128','75428.55640685477','75428.556406854768284','test','test','1.0'),('2019-08-14 19:59:59','2019-08-14 23:59:59','LENDETH','4h','0.000019000000000','0.000018670000000','1.399032102332918','1.374733123713451','73633.26854383781','73633.268543837810284','test','test','1.7'),('2019-08-15 23:59:59','2019-08-16 23:59:59','LENDETH','4h','0.000019200000000','0.000018432000000','1.393632329306370','1.337887036134115','72585.01715137345','72585.017151373453089','test','test','4.0'),('2019-08-21 11:59:59','2019-08-22 19:59:59','LENDETH','4h','0.000019350000000','0.000018576000000','1.381244486379202','1.325994706924034','71382.1439989252','71382.143998925195774','test','test','4.0'),('2019-08-24 23:59:59','2019-08-28 19:59:59','LENDETH','4h','0.000020400000000','0.000022200000000','1.368966757611388','1.489757942106510','67106.21360840135','67106.213608401347301','test','test','0.5'),('2019-08-31 11:59:59','2019-08-31 19:59:59','LENDETH','4h','0.000022380000000','0.000021700000000','1.395809243054748','1.353398595812691','62368.59888537748','62368.598885377483384','test','test','3.0'),('2019-09-02 03:59:59','2019-09-02 19:59:59','LENDETH','4h','0.000021800000000','0.000021470000000','1.386384654778735','1.365398098077956','63595.62636599702','63595.626365997020912','test','test','1.5'),('2019-09-07 23:59:59','2019-09-08 07:59:59','LENDETH','4h','0.000021100000000','0.000020820000000','1.381720975511896','1.363385341713634','65484.406422364715','65484.406422364714672','test','test','1.3'),('2019-09-08 11:59:59','2019-09-08 15:59:59','LENDETH','4h','0.000020900000000','0.000020600000000','1.377646390223393','1.357871561655593','65916.09522599964','65916.095225999641116','test','test','1.4'),('2019-09-09 19:59:59','2019-09-09 23:59:59','LENDETH','4h','0.000029340000000','0.000028166400000','1.373251983874993','1.318321904519993','46804.771093217205','46804.771093217204907','test','test','4.0'),('2019-09-13 15:59:59','2019-09-14 15:59:59','LENDETH','4h','0.000022600000000','0.000021900000000','1.361045299573881','1.318889029233097','60223.24334397705','60223.243343977046607','test','test','3.1'),('2019-09-15 07:59:59','2019-09-16 03:59:59','LENDETH','4h','0.000022010000000','0.000022100000000','1.351677239498152','1.357204315897735','61411.959995372636','61411.959995372635603','test','test','0.5'),('2019-09-16 07:59:59','2019-09-16 11:59:59','LENDETH','4h','0.000021900000000','0.000021560000000','1.352905478698059','1.331901466700007','61776.5058766237','61776.505876623697986','test','test','1.6'),('2019-09-16 19:59:59','2019-09-17 07:59:59','LENDETH','4h','0.000022650000000','0.000021900000000','1.348237920476270','1.303594280725400','59524.85300115981','59524.853001159812266','test','test','3.3'),('2019-09-17 11:59:59','2019-09-17 19:59:59','LENDETH','4h','0.000022800000000','0.000021888000000','1.338317111642743','1.284784427177033','58698.11893169927','58698.118931699267705','test','test','4.0'),('2019-09-17 23:59:59','2019-09-19 23:59:59','LENDETH','4h','0.000023900000000','0.000023300000000','1.326420959539252','1.293121688588476','55498.78491796033','55498.784917960329039','test','test','2.5'),('2019-09-20 07:59:59','2019-09-24 03:59:59','LENDETH','4h','0.000024910000000','0.000024000000000','1.319021121550191','1.270835283709538','52951.470154564064','52951.470154564063705','test','test','3.7'),('2019-09-24 15:59:59','2019-09-24 19:59:59','LENDETH','4h','0.000024340000000','0.000023366400000','1.308313157585601','1.255980631282177','53751.56769045197','53751.567690451971430','test','test','4.0'),('2019-09-26 11:59:59','2019-09-26 15:59:59','LENDETH','4h','0.000026600000000','0.000025536000000','1.296683707295951','1.244816359004113','48747.507793080884','48747.507793080883857','test','test','4.0'),('2019-09-28 19:59:59','2019-09-29 15:59:59','LENDETH','4h','0.000026040000000','0.000025300000000','1.285157629897765','1.248636253318489','49353.21159361617','49353.211593616171740','test','test','2.8'),('2019-09-30 15:59:59','2019-10-01 03:59:59','LENDETH','4h','0.000025500000000','0.000024590000000','1.277041768435704','1.231468905326822','50080.069350419755','50080.069350419755210','test','test','3.6'),('2019-10-02 07:59:59','2019-10-02 11:59:59','LENDETH','4h','0.000024900000000','0.000025000000000','1.266914465522619','1.272002475424316','50880.09901697264','50880.099016972642858','test','test','0.0'),('2019-10-02 15:59:59','2019-10-09 15:59:59','LENDETH','4h','0.000025200000000','0.000026220000000','1.268045134389663','1.319370770781626','50319.25136466915','50319.251364669151371','test','test','0.0'),('2019-10-10 23:59:59','2019-10-11 03:59:59','LENDETH','4h','0.000028000000000','0.000027950000000','1.279450831365655','1.277166097738216','45694.67254877338','45694.672548773378367','test','test','0.2'),('2019-10-11 11:59:59','2019-11-02 15:59:59','LENDETH','4h','0.000028800000000','0.000065490000000','1.278943112781779','2.908263349169400','44407.74697158956','44407.746971589556779','test','test','2.3'),('2019-11-02 23:59:59','2019-11-07 11:59:59','LENDETH','4h','0.000065720000000','0.000068070000000','1.641014276423473','1.699693271396010','24969.785094696785','24969.785094696784654','test','test','0.0'),('2019-11-09 11:59:59','2019-11-21 03:59:59','LENDETH','4h','0.000069280000000','0.000092850000000','1.654054053084036','2.216785779862193','23874.91416114371','23874.914161143711681','test','test','0.0'),('2019-11-22 03:59:59','2019-11-22 07:59:59','LENDETH','4h','0.000105360000000','0.000101145600000','1.779105547923627','1.707941326006682','16885.967615068592','16885.967615068591840','test','test','4.0'),('2019-11-28 19:59:59','2019-11-30 15:59:59','LENDETH','4h','0.000101200000000','0.000097152000000','1.763291276386528','1.692759625331067','17423.82684176411','17423.826841764108394','test','test','4.0'),('2019-12-04 23:59:59','2019-12-05 11:59:59','LENDETH','4h','0.000100910000000','0.000096873600000','1.747617576151981','1.677712873105902','17318.57671342762','17318.576713427621144','test','test','4.0'),('2019-12-05 15:59:59','2019-12-05 19:59:59','LENDETH','4h','0.000097100000000','0.000096840000000','1.732083197697297','1.727445281822927','17838.13797834497','17838.137978344970179','test','test','0.3'),('2019-12-05 23:59:59','2019-12-10 03:59:59','LENDETH','4h','0.000096800000000','0.000099370000000','1.731052549725214','1.777011279609448','17882.774274020812','17882.774274020812300','test','test','0.0'),('2019-12-30 23:59:59','2020-01-01 15:59:59','LENDETH','4h','0.000075670000000','0.000153280000000','1.741265600810600','3.527173137204291','23011.30700159376','23011.307001593759196','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:03:47
