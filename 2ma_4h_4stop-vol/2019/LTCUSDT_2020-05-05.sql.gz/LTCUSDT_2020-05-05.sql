-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-03 19:59:59','LTCUSDT','4h','31.480000000000000','30.850000000000001','222.222222222222200','217.774954115487759','7.059155724975292','7.059155724975292','test','test','2.0'),('2019-01-04 07:59:59','2019-01-04 15:59:59','LTCUSDT','4h','32.060000000000002','31.090000000000000','221.233940420725702','214.540337107933908','6.900621971950271','6.900621971950271','test','test','3.0'),('2019-01-04 23:59:59','2019-01-10 07:59:59','LTCUSDT','4h','31.760000000000002','35.170000000000002','219.746473017883062','243.340159195180973','6.918969553459794','6.918969553459794','test','test','0.0'),('2019-01-23 11:59:59','2019-01-23 15:59:59','LTCUSDT','4h','32.020000000000003','31.559999999999999','224.989514390615909','221.757310248839389','7.026530742992376','7.026530742992376','test','test','1.4'),('2019-01-24 15:59:59','2019-01-27 15:59:59','LTCUSDT','4h','31.980000000000000','32.340000000000003','224.271246803554476','226.795876223481940','7.012859499798451','7.012859499798451','test','test','0.0'),('2019-01-31 03:59:59','2019-01-31 11:59:59','LTCUSDT','4h','32.020000000000003','31.370000000000001','224.832275563538360','220.268222499319108','7.021620098798824','7.021620098798824','test','test','2.0'),('2019-02-01 11:59:59','2019-02-06 03:59:59','LTCUSDT','4h','32.119999999999997','32.789999999999999','223.818041549267406','228.486724234136915','6.968183111745561','6.968183111745561','test','test','0.0'),('2019-02-06 07:59:59','2019-02-06 11:59:59','LTCUSDT','4h','33.009999999999998','32.450000000000003','224.855526590349541','221.040952373730477','6.811739672534067','6.811739672534067','test','test','1.7'),('2019-02-08 07:59:59','2019-02-24 15:59:59','LTCUSDT','4h','33.820000000000000','44.390000000000001','224.007843431100838','294.018573917994274','6.623531739535802','6.623531739535802','test','test','0.0'),('2019-02-28 15:59:59','2019-02-28 19:59:59','LTCUSDT','4h','46.009999999999998','45.859999999999999','239.565783539299417','238.784760554494056','5.206819898702443','5.206819898702443','test','test','0.3'),('2019-03-01 07:59:59','2019-03-04 07:59:59','LTCUSDT','4h','46.920000000000002','46.140000000000001','239.392222876009328','235.412556766817346','5.102136037425604','5.102136037425604','test','test','1.7'),('2019-03-05 15:59:59','2019-03-14 15:59:59','LTCUSDT','4h','52.140000000000001','55.939999999999998','238.507852629522205','255.890473266119528','4.574373851736137','4.574373851736137','test','test','0.8'),('2019-03-14 19:59:59','2019-03-20 11:59:59','LTCUSDT','4h','55.680000000000000','59.810000000000002','242.370657215432715','260.348222127425117','4.352921286196708','4.352921286196708','test','test','0.0'),('2019-03-20 15:59:59','2019-03-21 15:59:59','LTCUSDT','4h','60.020000000000003','58.460000000000001','246.365671640319903','239.962298635339920','4.104726285243584','4.104726285243584','test','test','2.6'),('2019-03-22 15:59:59','2019-03-25 15:59:59','LTCUSDT','4h','59.259999999999998','58.609999999999999','244.942699861435472','242.256018205851035','4.1333563932068085','4.133356393206808','test','test','1.1'),('2019-03-25 19:59:59','2019-03-25 23:59:59','LTCUSDT','4h','58.890000000000001','59.039999999999999','244.345659493527819','244.968037637933151','4.149187629368786','4.149187629368786','test','test','0.0'),('2019-03-27 03:59:59','2019-03-30 19:59:59','LTCUSDT','4h','60.030000000000001','60.259999999999998','244.483965747840102','245.420685923119180','4.072696414256873','4.072696414256873','test','test','0.0'),('2019-04-01 03:59:59','2019-04-01 15:59:59','LTCUSDT','4h','60.659999999999997','60.369999999999997','244.692125786791024','243.522315096415667','4.03382996681159','4.033829966811590','test','test','0.5'),('2019-04-02 03:59:59','2019-04-11 11:59:59','LTCUSDT','4h','60.299999999999997','77.189999999999998','244.432167855596504','312.897496463905327','4.053601456975066','4.053601456975066','test','test','0.0'),('2019-04-14 23:59:59','2019-04-15 11:59:59','LTCUSDT','4h','83.280000000000001','80.340000000000003','259.646685324109569','250.480483896961601','3.1177555874652927','3.117755587465293','test','test','3.5'),('2019-04-15 15:59:59','2019-04-15 19:59:59','LTCUSDT','4h','81.739999999999995','78.470399999999998','257.609751673632275','247.305361606687001','3.1515751366972387','3.151575136697239','test','test','4.0'),('2019-04-17 03:59:59','2019-04-17 07:59:59','LTCUSDT','4h','80.140000000000001','79.549999999999997','255.319887214311052','253.440192511834823','3.18592322453595','3.185923224535950','test','test','0.7'),('2019-04-18 03:59:59','2019-04-18 11:59:59','LTCUSDT','4h','80.620000000000005','79.799999999999997','254.902177280427480','252.309523033715124','3.1617734716004398','3.161773471600440','test','test','1.0'),('2019-04-18 19:59:59','2019-04-19 03:59:59','LTCUSDT','4h','82.469999999999999','80.620000000000005','254.326031892269185','248.620888700797195','3.0838611845794737','3.083861184579474','test','test','2.2'),('2019-04-19 15:59:59','2019-04-20 11:59:59','LTCUSDT','4h','82.750000000000000','80.769999999999996','253.058222294164324','247.003173591536552','3.0581054053675447','3.058105405367545','test','test','2.4'),('2019-05-02 11:59:59','2019-05-02 15:59:59','LTCUSDT','4h','73.700000000000003','73.909999999999997','251.712655915802571','252.429883293581639','3.4153684656146885','3.415368465614689','test','test','0.0'),('2019-05-03 03:59:59','2019-05-04 15:59:59','LTCUSDT','4h','74.750000000000000','75.950000000000003','251.872039777531228','255.915470516434766','3.3695256157529263','3.369525615752926','test','test','0.0'),('2019-05-04 23:59:59','2019-05-06 03:59:59','LTCUSDT','4h','77.769999999999996','74.659199999999998','252.770579941732052','242.659756744062776','3.250232479641662','3.250232479641662','test','test','4.0'),('2019-05-06 19:59:59','2019-05-06 23:59:59','LTCUSDT','4h','76.010000000000005','74.939999999999998','250.523730342249991','246.997083960639543','3.2959311977667407','3.295931197766741','test','test','1.4'),('2019-05-07 03:59:59','2019-05-07 15:59:59','LTCUSDT','4h','77.650000000000006','74.709999999999994','249.740031146336577','240.284323592309107','3.2162270591930016','3.216227059193002','test','test','3.8'),('2019-05-09 03:59:59','2019-05-09 07:59:59','LTCUSDT','4h','75.299999999999997','74.280000000000001','247.638762800997057','244.284293504091153','3.288695389123467','3.288695389123467','test','test','1.4'),('2019-05-10 07:59:59','2019-05-17 07:59:59','LTCUSDT','4h','77.000000000000000','88.000000000000000','246.893325179462437','282.163800205099903','3.206406820512499','3.206406820512499','test','test','1.1'),('2019-05-19 03:59:59','2019-05-20 15:59:59','LTCUSDT','4h','91.599999999999994','90.250000000000000','254.731208518492963','250.976982192074132','2.7809083899398797','2.780908389939880','test','test','1.5'),('2019-05-21 15:59:59','2019-05-22 23:59:59','LTCUSDT','4h','90.769999999999996','87.739999999999995','253.896936001511023','245.421583835767080','2.797145929288433','2.797145929288433','test','test','3.3'),('2019-05-24 07:59:59','2019-05-30 23:59:59','LTCUSDT','4h','94.090000000000003','107.780000000000001','252.013524409123448','288.681237759754765','2.678430485802141','2.678430485802141','test','test','0.0'),('2019-05-31 03:59:59','2019-06-03 23:59:59','LTCUSDT','4h','107.230000000000004','105.989999999999995','260.161905153708233','257.153411612809236','2.4262044684669237','2.426204468466924','test','test','1.2'),('2019-06-06 23:59:59','2019-06-21 15:59:59','LTCUSDT','4h','111.189999999999998','136.240000000000009','259.493351033508418','317.954619523385134','2.333783173248569','2.333783173248569','test','test','0.6'),('2019-06-22 03:59:59','2019-06-24 03:59:59','LTCUSDT','4h','139.990000000000009','135.460000000000008','272.484744031258856','263.667286423846861','1.9464586329827762','1.946458632982776','test','test','3.2'),('2019-06-25 23:59:59','2019-06-26 03:59:59','LTCUSDT','4h','136.330000000000013','136.330000000000013','270.525309007389467','270.525309007389467','1.9843417370159866','1.984341737015987','test','test','0.0'),('2019-06-26 07:59:59','2019-06-26 11:59:59','LTCUSDT','4h','134.610000000000014','137.099999999999994','270.525309007389467','275.529454460389957','2.009696969076513','2.009696969076513','test','test','0.0'),('2019-06-26 15:59:59','2019-06-26 23:59:59','LTCUSDT','4h','137.330000000000013','132.250000000000000','271.637341330278502','261.589153068734674','1.977989815264534','1.977989815264534','test','test','3.7'),('2019-06-29 19:59:59','2019-06-30 07:59:59','LTCUSDT','4h','133.800000000000011','128.448000000000008','269.404410605491023','258.628234181271353','2.0134858789648056','2.013485878964806','test','test','4.0'),('2019-06-30 11:59:59','2019-06-30 15:59:59','LTCUSDT','4h','132.419999999999987','133.870000000000005','267.009704733442163','269.933463016658436','2.0163850229077345','2.016385022907734','test','test','0.0'),('2019-06-30 19:59:59','2019-06-30 23:59:59','LTCUSDT','4h','130.039999999999992','124.838399999999993','267.659428796379132','256.953051644523953','2.0582853644753856','2.058285364475386','test','test','4.0'),('2019-07-09 03:59:59','2019-07-09 07:59:59','LTCUSDT','4h','122.760000000000005','120.069999999999993','265.280233873744635','259.467234288208829','2.1609663886750132','2.160966388675013','test','test','2.2'),('2019-07-20 19:59:59','2019-07-21 03:59:59','LTCUSDT','4h','103.400000000000006','99.263999999999996','263.988456188070018','253.428917940547194','2.5530798470799807','2.553079847079981','test','test','4.0'),('2019-07-31 15:59:59','2019-08-02 19:59:59','LTCUSDT','4h','96.120000000000005','93.170000000000002','261.641892133064914','253.611892322489155','2.7220338340934758','2.722033834093476','test','test','3.1'),('2019-08-03 03:59:59','2019-08-03 07:59:59','LTCUSDT','4h','95.780000000000001','95.769999999999996','259.857447730714739','259.830317072150251','2.713065856449308','2.713065856449308','test','test','0.0'),('2019-08-05 03:59:59','2019-08-05 07:59:59','LTCUSDT','4h','95.099999999999994','94.739999999999995','259.851418695478230','258.867754019028439','2.732401879027111','2.732401879027111','test','test','0.4'),('2019-08-05 11:59:59','2019-08-05 19:59:59','LTCUSDT','4h','102.069999999999993','97.987199999999987','259.632826545156036','249.247513483349792','2.5436742093186644','2.543674209318664','test','test','4.0'),('2019-08-05 23:59:59','2019-08-06 03:59:59','LTCUSDT','4h','96.560000000000002','95.680000000000007','257.324979198087988','254.979846827600056','2.664923148281773','2.664923148281773','test','test','0.9'),('2019-08-06 07:59:59','2019-08-06 11:59:59','LTCUSDT','4h','97.510000000000005','95.120000000000005','256.803838671312917','250.509497840378259','2.6336154104329084','2.633615410432908','test','test','2.5'),('2019-09-03 23:59:59','2019-09-04 03:59:59','LTCUSDT','4h','69.060000000000002','68.140000000000001','255.405096264438527','252.002653626684634','3.6983072149498772','3.698307214949877','test','test','1.3'),('2019-09-07 15:59:59','2019-09-09 11:59:59','LTCUSDT','4h','68.980000000000004','70.469999999999999','254.648997900493214','260.149534387471078','3.691635226159658','3.691635226159658','test','test','0.6'),('2019-09-10 03:59:59','2019-09-11 15:59:59','LTCUSDT','4h','71.879999999999995','69.004799999999989','255.871339342043825','245.636485768362036','3.559701437702335','3.559701437702335','test','test','4.0'),('2019-09-14 15:59:59','2019-09-16 15:59:59','LTCUSDT','4h','70.269999999999996','69.969999999999999','253.596927436781243','252.514259467078176','3.60889323234355','3.608893232343550','test','test','0.4'),('2019-09-16 23:59:59','2019-09-21 19:59:59','LTCUSDT','4h','72.629999999999995','73.040000000000006','253.356334554624965','254.786543795536431','3.488315221735164','3.488315221735164','test','test','0.5'),('2019-09-23 07:59:59','2019-09-23 15:59:59','LTCUSDT','4h','73.269999999999996','72.799999999999997','253.674158830383050','252.046932753540148','3.462183142218958','3.462183142218958','test','test','0.6'),('2019-10-08 03:59:59','2019-10-08 07:59:59','LTCUSDT','4h','57.820000000000000','57.369999999999997','253.312553035529135','251.341078651821249','4.381054186017453','4.381054186017453','test','test','0.8'),('2019-10-09 11:59:59','2019-10-10 11:59:59','LTCUSDT','4h','57.850000000000001','57.869999999999997','252.874447616927370','252.961871799335938','4.371209120430897','4.371209120430897','test','test','0.0'),('2019-10-25 15:59:59','2019-11-01 19:59:59','LTCUSDT','4h','54.750000000000000','57.649999999999999','252.893875213018163','266.289167233433716','4.619066213936405','4.619066213936405','test','test','0.0'),('2019-11-02 19:59:59','2019-11-08 15:59:59','LTCUSDT','4h','58.609999999999999','60.229999999999997','255.870606773110495','262.942955911012518','4.365647615988919','4.365647615988919','test','test','1.8'),('2019-11-10 07:59:59','2019-11-11 11:59:59','LTCUSDT','4h','63.350000000000001','61.729999999999997','257.442239914866491','250.858870875212432','4.063808049169163','4.063808049169163','test','test','2.6'),('2019-11-12 15:59:59','2019-11-12 19:59:59','LTCUSDT','4h','60.969999999999999','61.420000000000002','255.979269017165592','257.868569838187852','4.198446268938258','4.198446268938258','test','test','0.0'),('2019-12-22 19:59:59','2019-12-23 19:59:59','LTCUSDT','4h','41.829999999999998','41.280000000000001','256.399113644059412','253.027860655672328','6.129550887976558','6.129550887976558','test','test','1.3'),('2019-12-27 19:59:59','2019-12-27 23:59:59','LTCUSDT','4h','41.049999999999997','40.950000000000003','255.649946313306714','255.027169342994199','6.227769703125621','6.227769703125621','test','test','0.2'),('2019-12-28 03:59:59','2019-12-31 15:59:59','LTCUSDT','4h','41.549999999999997','41.570000000000000','255.511551431015079','255.634541347468058','6.1494958226477765','6.149495822647776','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:17:02
