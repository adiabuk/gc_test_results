-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 03:59:59','2019-01-02 07:59:59','ENJBTC','4h','0.000010600000000','0.000010490000000','0.033333333333333','0.032987421383647','3144.6540880503144','3144.654088050314385','test','test','1.0'),('2019-01-12 07:59:59','2019-01-12 19:59:59','ENJBTC','4h','0.000010340000000','0.000009926400000','0.033256464011181','0.031926205450734','3216.2924575610145','3216.292457561014544','test','test','4.0'),('2019-01-22 15:59:59','2019-01-24 03:59:59','ENJBTC','4h','0.000009650000000','0.000009520000000','0.032960850997748','0.032516818808141','3415.63222774593','3415.632227745929868','test','test','1.3'),('2019-01-29 23:59:59','2019-01-30 03:59:59','ENJBTC','4h','0.000009350000000','0.000009050000000','0.032862177177836','0.031807775771061','3514.671355918241','3514.671355918240806','test','test','3.2'),('2019-02-10 23:59:59','2019-02-11 03:59:59','ENJBTC','4h','0.000008240000000','0.000008090000000','0.032627865754108','0.032033911887225','3959.6924458868657','3959.692445886865698','test','test','1.8'),('2019-02-11 07:59:59','2019-02-17 03:59:59','ENJBTC','4h','0.000008340000000','0.000008460000000','0.032495876005912','0.032963442567148','3896.388010301145','3896.388010301145187','test','test','0.0'),('2019-02-17 11:59:59','2019-03-16 07:59:59','ENJBTC','4h','0.000008580000000','0.000041040000000','0.032599779686186','0.155931813324134','3799.5081219331264','3799.508121933126404','test','test','0.0'),('2019-03-18 11:59:59','2019-03-19 07:59:59','ENJBTC','4h','0.000050800000000','0.000048768000000','0.060006898272397','0.057606622341501','1181.2381549684426','1181.238154968442586','test','test','4.0'),('2019-03-19 19:59:59','2019-03-20 03:59:59','ENJBTC','4h','0.000048000000000','0.000046080000000','0.059473503621087','0.057094563476244','1239.0313254393056','1239.031325439305647','test','test','4.0'),('2019-03-21 19:59:59','2019-03-23 19:59:59','ENJBTC','4h','0.000047960000000','0.000046041600000','0.058944850255566','0.056587056245343','1229.0419152536697','1229.041915253669686','test','test','4.0'),('2019-03-24 03:59:59','2019-03-24 11:59:59','ENJBTC','4h','0.000045060000000','0.000045130000000','0.058420896031072','0.058511651972532','1296.5134494245895','1296.513449424589453','test','test','0.0'),('2019-03-25 03:59:59','2019-03-25 07:59:59','ENJBTC','4h','0.000044750000000','0.000043700000000','0.058441064018063','0.057069821175181','1305.9455646494553','1305.945564649455264','test','test','2.3'),('2019-04-13 19:59:59','2019-04-14 23:59:59','ENJBTC','4h','0.000033070000000','0.000031747200000','0.058136343386312','0.055810889650860','1757.9783303995025','1757.978330399502511','test','test','4.0'),('2019-04-17 11:59:59','2019-04-23 03:59:59','ENJBTC','4h','0.000031460000000','0.000032990000000','0.057619575889544','0.060421799383219','1831.5186233167335','1831.518623316733510','test','test','0.0'),('2019-05-17 23:59:59','2019-05-18 03:59:59','ENJBTC','4h','0.000021930000000','0.000021490000000','0.058242292221472','0.057073728218852','2655.8272786809043','2655.827278680904328','test','test','2.0'),('2019-05-21 23:59:59','2019-05-22 03:59:59','ENJBTC','4h','0.000021480000000','0.000022590000000','0.057982611332001','0.060978919459493','2699.3766914339435','2699.376691433943506','test','test','0.0'),('2019-05-22 07:59:59','2019-05-22 11:59:59','ENJBTC','4h','0.000022940000000','0.000022022400000','0.058648457582555','0.056302519279253','2556.6023357696113','2556.602335769611273','test','test','4.0'),('2019-05-22 15:59:59','2019-05-22 23:59:59','ENJBTC','4h','0.000021560000000','0.000020697600000','0.058127137959599','0.055802052441215','2696.06391278288','2696.063912782879925','test','test','4.0'),('2019-06-02 19:59:59','2019-06-03 03:59:59','ENJBTC','4h','0.000019680000000','0.000018892800000','0.057610452288847','0.055306034197293','2927.360380530837','2927.360380530837119','test','test','4.0'),('2019-06-06 23:59:59','2019-06-07 19:59:59','ENJBTC','4h','0.000019160000000','0.000019000000000','0.057098359379613','0.056621546357654','2980.0813872449203','2980.081387244920279','test','test','0.8'),('2019-06-09 15:59:59','2019-06-09 19:59:59','ENJBTC','4h','0.000019780000000','0.000018990000000','0.056992400930288','0.054716162470484','2881.3145060813167','2881.314506081316722','test','test','4.0'),('2019-06-11 07:59:59','2019-06-11 11:59:59','ENJBTC','4h','0.000019850000000','0.000019310000000','0.056486570161443','0.054949907799368','2845.6710408787453','2845.671040878745316','test','test','2.7'),('2019-06-11 15:59:59','2019-06-12 15:59:59','ENJBTC','4h','0.000019600000000','0.000019290000000','0.056145089636538','0.055257080565756','2864.5453896192635','2864.545389619263460','test','test','1.6'),('2019-07-01 15:59:59','2019-07-01 23:59:59','ENJBTC','4h','0.000012140000000','0.000012020000000','0.055947754287475','0.055394728709675','4608.54648167009','4608.546481670089634','test','test','1.0'),('2019-07-02 07:59:59','2019-07-02 11:59:59','ENJBTC','4h','0.000012400000000','0.000011904000000','0.055824859714630','0.053591865326045','4502.004815696004','4502.004815696003789','test','test','4.0'),('2019-07-14 15:59:59','2019-07-15 03:59:59','ENJBTC','4h','0.000010300000000','0.000009930000000','0.055328638739389','0.053341105114770','5371.7124989698395','5371.712498969839544','test','test','3.6'),('2019-07-25 19:59:59','2019-07-25 23:59:59','ENJBTC','4h','0.000008940000000','0.000008820000000','0.054886964600585','0.054150226820711','6139.4814989468805','6139.481498946880492','test','test','1.3'),('2019-07-26 07:59:59','2019-07-27 11:59:59','ENJBTC','4h','0.000009010000000','0.000008850000000','0.054723245093946','0.053751467156651','6073.612108096165','6073.612108096164775','test','test','1.8'),('2019-07-27 15:59:59','2019-07-27 19:59:59','ENJBTC','4h','0.000008900000000','0.000008880000000','0.054507294441214','0.054384806139099','6124.415105754408','6124.415105754407705','test','test','0.2'),('2019-07-28 19:59:59','2019-07-28 23:59:59','ENJBTC','4h','0.000008930000000','0.000008900000000','0.054480074818522','0.054297051050935','6100.792252914','6100.792252913999619','test','test','0.3'),('2019-07-30 11:59:59','2019-07-31 07:59:59','ENJBTC','4h','0.000008970000000','0.000008870000000','0.054439402870169','0.053832497598484','6069.05271685277','6069.052716852769663','test','test','1.1'),('2019-08-17 15:59:59','2019-08-17 19:59:59','ENJBTC','4h','0.000006580000000','0.000006316800000','0.054304535032017','0.052132353630736','8252.968849850626','8252.968849850625702','test','test','4.0'),('2019-08-21 15:59:59','2019-08-26 03:59:59','ENJBTC','4h','0.000006340000000','0.000006670000000','0.053821828053955','0.056623279671905','8489.247327122188','8489.247327122187926','test','test','0.8'),('2019-08-27 11:59:59','2019-08-28 19:59:59','ENJBTC','4h','0.000006830000000','0.000006630000000','0.054444372857944','0.052850101324768','7971.357665877535','7971.357665877534600','test','test','2.9'),('2019-08-28 23:59:59','2019-08-29 03:59:59','ENJBTC','4h','0.000006830000000','0.000006556800000','0.054090090295016','0.051926486683215','7919.4861339700665','7919.486133970066476','test','test','4.0'),('2019-08-29 23:59:59','2019-08-30 11:59:59','ENJBTC','4h','0.000006670000000','0.000006650000000','0.053609289492393','0.053448541997663','8037.374736490721','8037.374736490721261','test','test','0.3'),('2019-08-31 11:59:59','2019-09-03 15:59:59','ENJBTC','4h','0.000007010000000','0.000006960000000','0.053573567826898','0.053191445374495','7642.449048059567','7642.449048059566849','test','test','1.3'),('2019-09-04 03:59:59','2019-09-09 15:59:59','ENJBTC','4h','0.000007540000000','0.000007450000000','0.053488651726364','0.052850193018755','7093.985640101268','7093.985640101267563','test','test','1.2'),('2019-09-10 19:59:59','2019-09-10 23:59:59','ENJBTC','4h','0.000007520000000','0.000007400000000','0.053346772013562','0.052495493736750','7093.98564010127','7093.985640101270292','test','test','1.6'),('2019-09-18 07:59:59','2019-09-19 03:59:59','ENJBTC','4h','0.000007140000000','0.000007090000000','0.053157599063159','0.052785346968879','7445.041885596484','7445.041885596483553','test','test','0.7'),('2019-09-28 11:59:59','2019-09-30 11:59:59','ENJBTC','4h','0.000006990000000','0.000006940000000','0.053074876375541','0.052695227760551','7592.97229979129','7592.972299791290425','test','test','1.7'),('2019-09-30 15:59:59','2019-09-30 19:59:59','ENJBTC','4h','0.000006900000000','0.000006860000000','0.052990510016654','0.052683318654239','7679.784060384703','7679.784060384702570','test','test','0.6'),('2019-10-01 07:59:59','2019-10-01 19:59:59','ENJBTC','4h','0.000007040000000','0.000006850000000','0.052922245269451','0.051493946036327','7517.364384865215','7517.364384865214561','test','test','2.7'),('2019-10-03 07:59:59','2019-10-09 15:59:59','ENJBTC','4h','0.000007180000000','0.000007490000000','0.052604845439868','0.054876085284765','7326.580144828414','7326.580144828413722','test','test','0.0'),('2019-10-12 03:59:59','2019-10-12 15:59:59','ENJBTC','4h','0.000007650000000','0.000007530000000','0.053109565405401','0.052276474183356','6942.426850379174','6942.426850379173629','test','test','1.6'),('2019-10-13 07:59:59','2019-10-13 15:59:59','ENJBTC','4h','0.000007730000000','0.000007520000000','0.052924434022724','0.051486642154060','6846.627946018629','6846.627946018628791','test','test','2.7'),('2019-10-14 15:59:59','2019-10-14 19:59:59','ENJBTC','4h','0.000007580000000','0.000007610000000','0.052604924718576','0.052813123629072','6939.963683189504','6939.963683189504081','test','test','0.0'),('2019-10-22 15:59:59','2019-10-23 03:59:59','ENJBTC','4h','0.000007430000000','0.000007250000000','0.052651191143131','0.051375657575733','7086.297596652908','7086.297596652908396','test','test','2.4'),('2019-10-23 11:59:59','2019-10-25 15:59:59','ENJBTC','4h','0.000007590000000','0.000007286400000','0.052367739239265','0.050273029669694','6899.570387254926','6899.570387254925663','test','test','4.0'),('2019-11-01 03:59:59','2019-11-02 11:59:59','ENJBTC','4h','0.000007260000000','0.000007080000000','0.051902248223805','0.050615415623215','7149.070003278881','7149.070003278880904','test','test','2.5'),('2019-11-02 19:59:59','2019-11-03 03:59:59','ENJBTC','4h','0.000007080000000','0.000007160000000','0.051616285423674','0.052199520287218','7290.435794304175','7290.435794304175033','test','test','0.0'),('2019-11-04 03:59:59','2019-11-04 23:59:59','ENJBTC','4h','0.000007190000000','0.000007140000000','0.051745893171128','0.051386046904291','7196.925336735437','7196.925336735436758','test','test','1.0'),('2019-11-05 19:59:59','2019-11-07 03:59:59','ENJBTC','4h','0.000007210000000','0.000007180000000','0.051665927334053','0.051450951214771','7165.870642725784','7165.870642725783910','test','test','0.8'),('2019-11-12 15:59:59','2019-11-12 19:59:59','ENJBTC','4h','0.000007090000000','0.000007100000000','0.051618154863101','0.051690959030750','7280.416764894407','7280.416764894406697','test','test','0.0'),('2019-11-14 07:59:59','2019-11-14 11:59:59','ENJBTC','4h','0.000007230000000','0.000007100000000','0.051634333567023','0.050705915397768','7141.678225037806','7141.678225037806442','test','test','1.8'),('2019-11-14 15:59:59','2019-11-18 15:59:59','ENJBTC','4h','0.000007270000000','0.000007600000000','0.051428018418300','0.053762440162184','7074.005284497937','7074.005284497937282','test','test','0.0'),('2019-11-19 19:59:59','2019-11-22 15:59:59','ENJBTC','4h','0.000007950000000','0.000007820000000','0.051946778805830','0.051097334624099','6534.1860133119235','6534.186013311923489','test','test','1.6'),('2019-11-23 19:59:59','2019-11-23 23:59:59','ENJBTC','4h','0.000008610000000','0.000008265600000','0.051758013432112','0.049687692894828','6011.383673880579','6011.383673880579408','test','test','4.0'),('2019-11-24 11:59:59','2019-11-24 15:59:59','ENJBTC','4h','0.000007930000000','0.000007710000000','0.051297942201604','0.049874796264107','6468.845170441895','6468.845170441894879','test','test','2.8'),('2019-11-27 11:59:59','2019-11-27 15:59:59','ENJBTC','4h','0.000007790000000','0.000007730000000','0.050981687548827','0.050589017298130','6544.504178283328','6544.504178283327747','test','test','0.8'),('2019-11-28 15:59:59','2019-11-30 15:59:59','ENJBTC','4h','0.000007910000000','0.000007800000000','0.050894427493117','0.050186666807372','6434.188052227139','6434.188052227139451','test','test','1.4'),('2019-11-30 23:59:59','2019-12-03 15:59:59','ENJBTC','4h','0.000007990000000','0.000008170000000','0.050737147340729','0.051880161924125','6350.081018864694','6350.081018864693760','test','test','1.0'),('2019-12-03 19:59:59','2019-12-04 15:59:59','ENJBTC','4h','0.000008330000000','0.000008400000000','0.050991150581484','0.051419647645194','6121.386624427799','6121.386624427798779','test','test','0.1'),('2019-12-04 19:59:59','2019-12-04 23:59:59','ENJBTC','4h','0.000011600000000','0.000011136000000','0.051086372151197','0.049042917265149','4403.997599241112','4403.997599241111857','test','test','4.0'),('2019-12-05 03:59:59','2019-12-10 03:59:59','ENJBTC','4h','0.000010410000000','0.000010400000000','0.050632271065408','0.050583632956796','4863.8108612303995','4863.810861230399496','test','test','0.1'),('2019-12-11 07:59:59','2019-12-11 15:59:59','ENJBTC','4h','0.000011250000000','0.000010800000000','0.050621462596828','0.048596604092955','4499.68556416249','4499.685564162489754','test','test','4.0'),('2019-12-11 23:59:59','2019-12-14 11:59:59','ENJBTC','4h','0.000011590000000','0.000011126400000','0.050171494040412','0.048164634278796','4328.860572943208','4328.860572943208354','test','test','4.0'),('2019-12-15 19:59:59','2019-12-17 23:59:59','ENJBTC','4h','0.000011310000000','0.000011480000000','0.049725525204497','0.050472946891921','4396.598161317164','4396.598161317164340','test','test','0.0'),('2019-12-20 15:59:59','2019-12-20 19:59:59','ENJBTC','4h','0.000011160000000','0.000011240000000','0.049891618912814','0.050249264926526','4470.575171399065','4470.575171399064857','test','test','0.0'),('2019-12-22 11:59:59','2019-12-22 19:59:59','ENJBTC','4h','0.000011460000000','0.000011220000000','0.049971095804750','0.048924580709363','4360.479564114273','4360.479564114272762','test','test','2.1'),('2019-12-28 19:59:59','2019-12-29 03:59:59','ENJBTC','4h','0.000011120000000','0.000010720000000','0.049738536894664','0.047949380891259','4472.890008512911','4472.890008512910754','test','test','3.6'),('2019-12-29 07:59:59','2019-12-29 19:59:59','ENJBTC','4h','0.000011090000000','0.000010690000000','0.049340946671685','0.047561291246196','4449.138563722694','4449.138563722694016','test','test','3.6'),('2019-12-30 15:59:59','2020-01-01 03:59:59','ENJBTC','4h','0.000011600000000','0.000011136000000','0.048945467688243','0.046987648980713','4219.436869676093','4219.436869676093011','test','test','4.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:20:05
