-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 19:59:59','2019-01-14 19:59:59','WAVESETH','4h','0.022350000000000','0.021470000000000','1.297777777777778','1.246679592344022','58.06611981108625','58.066119811086253','test','test','3.9'),('2019-01-16 11:59:59','2019-01-16 15:59:59','WAVESETH','4h','0.021248000000000','0.021219000000000','1.286422625459165','1.284666871687595','60.54323350240801','60.543233502408007','test','test','0.1'),('2019-01-17 03:59:59','2019-01-17 07:59:59','WAVESETH','4h','0.021201000000000','0.021135000000000','1.286032457954372','1.282028960844567','60.659047118266685','60.659047118266685','test','test','0.3'),('2019-01-17 11:59:59','2019-01-17 19:59:59','WAVESETH','4h','0.021167000000000','0.021083000000000','1.285142791929971','1.280042778015759','60.714451359662256','60.714451359662256','test','test','0.4'),('2019-01-18 11:59:59','2019-01-18 15:59:59','WAVESETH','4h','0.021613000000000','0.021002000000000','1.284009455504590','1.247710479087003','59.40912670636147','59.409126706361469','test','test','2.8'),('2019-01-22 19:59:59','2019-01-24 23:59:59','WAVESETH','4h','0.022779000000000','0.023377000000000','1.275943016300682','1.309439391196323','56.01400484220915','56.014004842209147','test','test','0.0'),('2019-01-25 19:59:59','2019-01-26 19:59:59','WAVESETH','4h','0.024217000000000','0.023248320000000','1.283386655166380','1.232051188959725','52.99527832375522','52.995278323755223','test','test','4.0'),('2019-01-27 11:59:59','2019-01-27 23:59:59','WAVESETH','4h','0.025120000000000','0.024115200000000','1.271978773787124','1.221099622835639','50.63609768260842','50.636097682608423','test','test','4.0'),('2019-01-28 03:59:59','2019-02-01 23:59:59','WAVESETH','4h','0.023161000000000','0.025468000000000','1.260672295797905','1.386244204886708','54.43082318543692','54.430823185436921','test','test','0.0'),('2019-02-03 11:59:59','2019-02-04 07:59:59','WAVESETH','4h','0.026232000000000','0.025434000000000','1.288577164484305','1.249377538940752','49.12233777387563','49.122337773875628','test','test','3.0'),('2019-02-04 11:59:59','2019-02-04 23:59:59','WAVESETH','4h','0.025830000000000','0.025308000000000','1.279866136585738','1.254001246020591','49.54959878380713','49.549598783807127','test','test','2.0'),('2019-02-05 11:59:59','2019-02-05 15:59:59','WAVESETH','4h','0.025361000000000','0.025141000000000','1.274118383126816','1.263065741500386','50.23928012013786','50.239280120137863','test','test','0.9'),('2019-02-28 15:59:59','2019-02-28 19:59:59','WAVESETH','4h','0.019848000000000','0.019465000000000','1.271662240543165','1.247123413551628','64.07004436432716','64.070044364327160','test','test','1.9'),('2019-03-01 07:59:59','2019-03-01 11:59:59','WAVESETH','4h','0.019820000000000','0.019707000000000','1.266209167878379','1.258990114600364','63.8854272390706','63.885427239070602','test','test','0.6'),('2019-03-02 19:59:59','2019-03-03 11:59:59','WAVESETH','4h','0.020053000000000','0.019875000000000','1.264604933816598','1.253379696783767','63.06312939792541','63.063129397925408','test','test','1.0'),('2019-03-03 23:59:59','2019-03-05 15:59:59','WAVESETH','4h','0.020321000000000','0.019571000000000','1.262110436698191','1.215528928528138','62.10867756007045','62.108677560070447','test','test','3.7'),('2019-03-08 15:59:59','2019-03-08 19:59:59','WAVESETH','4h','0.020062000000000','0.019552000000000','1.251758990438180','1.219937781928387','62.39452648979063','62.394526489790628','test','test','2.5'),('2019-03-08 23:59:59','2019-03-09 15:59:59','WAVESETH','4h','0.019865000000000','0.019750000000000','1.244687610769337','1.237482019264757','62.65731743112694','62.657317431126941','test','test','0.6'),('2019-03-09 23:59:59','2019-03-11 23:59:59','WAVESETH','4h','0.019872000000000','0.019897000000000','1.243086368212763','1.244650234919955','62.55466828767931','62.554668287679313','test','test','0.1'),('2019-03-12 01:59:59','2019-03-12 11:59:59','WAVESETH','4h','0.019789000000000','0.020149000000000','1.243433894147695','1.266054350052146','62.8345997345846','62.834599734584600','test','test','0.0'),('2019-03-12 15:59:59','2019-03-16 03:59:59','WAVESETH','4h','0.020391000000000','0.019794000000000','1.248460662126462','1.211908702178961','61.22606356365366','61.226063563653661','test','test','2.9'),('2019-03-20 15:59:59','2019-03-21 03:59:59','WAVESETH','4h','0.020224000000000','0.020035000000000','1.240338004360350','1.228746633571975','61.33000417129898','61.330004171298981','test','test','0.9'),('2019-03-21 11:59:59','2019-03-21 15:59:59','WAVESETH','4h','0.020272000000000','0.020318000000000','1.237762144185156','1.240570799405781','61.0577221875077','61.057722187507700','test','test','0.0'),('2019-03-21 19:59:59','2019-03-22 11:59:59','WAVESETH','4h','0.020252000000000','0.020126000000000','1.238386289789739','1.230681536061045','61.14883911661759','61.148839116617587','test','test','1.1'),('2019-03-24 11:59:59','2019-03-24 19:59:59','WAVESETH','4h','0.020081000000000','0.020108000000000','1.236674122294474','1.238336898117488','61.58428974127154','61.584289741271540','test','test','0.0'),('2019-03-25 15:59:59','2019-03-25 19:59:59','WAVESETH','4h','0.020258000000000','0.020136000000000','1.237043628032922','1.229593765133326','61.064449996688786','61.064449996688786','test','test','0.6'),('2019-04-01 15:59:59','2019-04-02 07:59:59','WAVESETH','4h','0.020357000000000','0.019784000000000','1.235388102944122','1.200614934845336','60.686157240463835','60.686157240463835','test','test','2.8'),('2019-05-07 19:59:59','2019-05-07 23:59:59','WAVESETH','4h','0.013536000000000','0.012994560000000','1.227660732255503','1.178554302965283','90.69597608270563','90.695976082705627','test','test','4.0'),('2019-05-23 19:59:59','2019-05-23 23:59:59','WAVESETH','4h','0.010850000000000','0.013332000000000','1.216748192413232','1.495086350345918','112.14269054499836','112.142690544998359','test','test','0.0'),('2019-05-24 03:59:59','2019-05-24 15:59:59','WAVESETH','4h','0.012079000000000','0.011595840000000','1.278601116398274','1.227457071742343','105.85322596227118','105.853225962271182','test','test','4.0'),('2019-05-25 15:59:59','2019-05-25 19:59:59','WAVESETH','4h','0.010762000000000','0.010755000000000','1.267235773141400','1.266411516459371','117.75095457548781','117.750954575487810','test','test','0.1'),('2019-06-10 03:59:59','2019-06-10 11:59:59','WAVESETH','4h','0.009770000000000','0.009701000000000','1.267052604989838','1.258104127022152','129.68808648821272','129.688086488212718','test','test','0.7'),('2019-06-11 11:59:59','2019-06-11 15:59:59','WAVESETH','4h','0.009790000000000','0.009726000000000','1.265064054330352','1.256793972667722','129.2200259785855','129.220025978585511','test','test','0.7'),('2019-07-06 19:59:59','2019-07-06 23:59:59','WAVESETH','4h','0.006730000000000','0.006739000000000','1.263226258405323','1.264915565437366','187.70078133808667','187.700781338086671','test','test','0.0'),('2019-07-07 03:59:59','2019-07-07 19:59:59','WAVESETH','4h','0.007291000000000','0.006999360000000','1.263601659968000','1.213057593569280','173.30978740474552','173.309787404745521','test','test','4.0'),('2019-07-14 11:59:59','2019-07-15 11:59:59','WAVESETH','4h','0.006317000000000','0.006640000000000','1.252369645212728','1.316405642585486','198.25386183516358','198.253861835163576','test','test','0.7'),('2019-07-15 15:59:59','2019-07-15 19:59:59','WAVESETH','4h','0.006320000000000','0.006147000000000','1.266599866851119','1.231928699609783','200.41137133720235','200.411371337202354','test','test','2.7'),('2019-07-15 23:59:59','2019-07-18 07:59:59','WAVESETH','4h','0.006533000000000','0.006681000000000','1.258895163019711','1.287414447288334','192.69786667988845','192.697866679888449','test','test','0.0'),('2019-07-18 15:59:59','2019-07-20 03:59:59','WAVESETH','4h','0.006800000000000','0.006528000000000','1.265232781746072','1.214623470476229','186.06364437442232','186.063644374422324','test','test','4.0'),('2019-07-20 07:59:59','2019-07-20 11:59:59','WAVESETH','4h','0.006514000000000','0.006518000000000','1.253986268130551','1.254756293471743','192.50633529790468','192.506335297904684','test','test','0.0'),('2019-07-20 15:59:59','2019-07-20 19:59:59','WAVESETH','4h','0.006500000000000','0.006525000000000','1.254157384873038','1.258981067122550','192.94728998046745','192.947289980467446','test','test','0.0'),('2019-07-21 03:59:59','2019-07-21 11:59:59','WAVESETH','4h','0.006551000000000','0.006505000000000','1.255229314261819','1.246415309002157','191.60880999264518','191.608809992645178','test','test','0.7'),('2019-07-21 19:59:59','2019-07-21 23:59:59','WAVESETH','4h','0.006615000000000','0.006501000000000','1.253270646426338','1.231672331431235','189.45890346581075','189.458903465810749','test','test','1.7'),('2019-07-22 07:59:59','2019-07-22 11:59:59','WAVESETH','4h','0.006519000000000','0.006511000000000','1.248471020871871','1.246938919603736','191.51265851693068','191.512658516930685','test','test','0.1'),('2019-07-22 15:59:59','2019-07-22 23:59:59','WAVESETH','4h','0.006557000000000','0.006576000000000','1.248130553923396','1.251747220161698','190.35085464746018','190.350854647460181','test','test','0.0'),('2019-07-26 15:59:59','2019-07-26 19:59:59','WAVESETH','4h','0.006506000000000','0.006482000000000','1.248934257531908','1.244327060762654','191.9665320522453','191.966532052245299','test','test','0.4'),('2019-07-27 11:59:59','2019-07-27 15:59:59','WAVESETH','4h','0.006532000000000','0.006512000000000','1.247910436027629','1.244089522261470','191.04568830796532','191.045688307965321','test','test','0.3'),('2019-07-28 19:59:59','2019-07-28 23:59:59','WAVESETH','4h','0.006502000000000','0.006410000000000','1.247061344079594','1.229416058989572','191.7965770654559','191.796577065455892','test','test','1.4'),('2019-07-29 11:59:59','2019-07-30 11:59:59','WAVESETH','4h','0.006650000000000','0.006505000000000','1.243140169615145','1.216034105766394','186.93837137069846','186.938371370698462','test','test','2.2'),('2019-08-09 11:59:59','2019-08-09 15:59:59','WAVESETH','4h','0.006208000000000','0.006212000000000','1.237116599870978','1.237913711082235','199.27780281426834','199.277802814268341','test','test','0.0'),('2019-08-12 23:59:59','2019-08-13 03:59:59','WAVESETH','4h','0.006209000000000','0.006212000000000','1.237293735695702','1.237891558405814','199.2742367040911','199.274236704091095','test','test','0.0'),('2019-08-14 19:59:59','2019-08-19 07:59:59','WAVESETH','4h','0.006449000000000','0.006272000000000','1.237426585186838','1.203464031988192','191.8788316307703','191.878831630770293','test','test','2.7'),('2019-08-20 15:59:59','2019-08-20 23:59:59','WAVESETH','4h','0.006417000000000','0.006314000000000','1.229879351142694','1.210138417191050','191.6595529285794','191.659552928579387','test','test','1.6'),('2019-08-21 07:59:59','2019-08-22 03:59:59','WAVESETH','4h','0.006459000000000','0.006446000000000','1.225492476931218','1.223025933782107','189.7340883931286','189.734088393128587','test','test','1.0'),('2019-08-22 07:59:59','2019-08-23 07:59:59','WAVESETH','4h','0.006491000000000','0.006561000000000','1.224944356231415','1.238154355451289','188.7142745696218','188.714274569621807','test','test','0.0'),('2019-08-23 15:59:59','2019-08-26 03:59:59','WAVESETH','4h','0.006860000000000','0.006766000000000','1.227879911613609','1.211054734982169','178.99124076000138','178.991240760001375','test','test','2.3'),('2019-08-28 15:59:59','2019-08-28 19:59:59','WAVESETH','4h','0.006644000000000','0.006634000000000','1.224140983473289','1.222298507580042','184.2475893246974','184.247589324697401','test','test','0.2'),('2019-09-23 03:59:59','2019-09-23 07:59:59','WAVESETH','4h','0.005622000000000','0.005397120000000','1.223731544385901','1.174782282610465','217.6683643518145','217.668364351814489','test','test','4.0'),('2019-10-04 15:59:59','2019-10-07 19:59:59','WAVESETH','4h','0.005082000000000','0.005063000000000','1.212853930658027','1.208319451184886','238.65681437584152','238.656814375841520','test','test','0.9'),('2019-10-08 07:59:59','2019-10-08 11:59:59','WAVESETH','4h','0.005044000000000','0.005011000000000','1.211846268552884','1.203917853235230','240.25500962586918','240.255009625869178','test','test','0.7'),('2019-10-08 15:59:59','2019-10-08 19:59:59','WAVESETH','4h','0.005096000000000','0.005004000000000','1.210084398482294','1.188238290817386','237.45769200986936','237.457692009869362','test','test','1.8'),('2019-10-29 03:59:59','2019-10-29 07:59:59','WAVESETH','4h','0.004591000000000','0.004447000000000','1.205229707890093','1.167426815723643','262.52008448923823','262.520084489238229','test','test','3.1'),('2019-11-04 03:59:59','2019-11-04 07:59:59','WAVESETH','4h','0.004392000000000','0.004358000000000','1.196829065186437','1.187563995009675','272.5020640224128','272.502064022412810','test','test','0.8'),('2019-11-05 03:59:59','2019-11-05 07:59:59','WAVESETH','4h','0.004421000000000','0.004347000000000','1.194770160702712','1.174771745888869','270.24884883571866','270.248848835718661','test','test','1.7'),('2019-11-05 11:59:59','2019-11-05 15:59:59','WAVESETH','4h','0.004388000000000','0.004354000000000','1.190326068521858','1.181102940370139','271.26847505056014','271.268475050560141','test','test','0.8'),('2019-11-15 15:59:59','2019-11-16 03:59:59','WAVESETH','4h','0.004301000000000','0.004258000000000','1.188276484488143','1.176396482434437','276.27911752804994','276.279117528049937','test','test','1.0'),('2019-11-22 03:59:59','2019-11-22 11:59:59','WAVESETH','4h','0.004218000000000','0.004195000000000','1.185636484031763','1.179171420225995','281.0897306855769','281.089730685576910','test','test','0.5'),('2019-12-11 15:59:59','2019-12-11 19:59:59','WAVESETH','4h','0.004428000000000','0.004250880000000','1.184199803186037','1.136831811058596','267.43446323081247','267.434463230812469','test','test','4.0'),('2019-12-11 23:59:59','2020-01-01 15:59:59','WAVESETH','4h','0.004063000000000','0.007925000000000','1.173673582713273','2.289284554024781','288.8687134416128','288.868713441612783','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:27:21
