-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-11 15:59:59','RCNETH','4h','0.000085540000000','0.000084960000000','1.297777777777778','1.288978255786767','15171.589639674745','15171.589639674744831','test','test','0.7'),('2019-01-12 03:59:59','2019-01-12 11:59:59','RCNETH','4h','0.000086100000000','0.000085150000000','1.295822328446442','1.281524637249878','15050.201259540558','15050.201259540557658','test','test','1.5'),('2019-01-12 15:59:59','2019-01-12 23:59:59','RCNETH','4h','0.000084670000000','0.000084920000000','1.292645063736094','1.296461778817398','15266.860325216658','15266.860325216657657','test','test','0.0'),('2019-01-13 11:59:59','2019-01-14 15:59:59','RCNETH','4h','0.000088320000000','0.000084787200000','1.293493222643051','1.241753493737329','14645.530147679472','14645.530147679472066','test','test','4.0'),('2019-01-14 19:59:59','2019-01-24 03:59:59','RCNETH','4h','0.000085540000000','0.000100820000000','1.281995505108446','1.510998209317670','14987.08797180788','14987.087971807879512','test','test','0.0'),('2019-01-26 11:59:59','2019-01-27 11:59:59','RCNETH','4h','0.000103830000000','0.000100320000000','1.332884994932718','1.287826473000580','12837.18573565172','12837.185735651719369','test','test','3.4'),('2019-01-27 23:59:59','2019-01-28 03:59:59','RCNETH','4h','0.000102840000000','0.000101210000000','1.322871990058909','1.301904649104066','12863.399358799197','12863.399358799197216','test','test','1.6'),('2019-01-28 11:59:59','2019-01-28 15:59:59','RCNETH','4h','0.000103250000000','0.000102500000000','1.318212580957833','1.308637186907292','12767.192067388216','12767.192067388215946','test','test','0.7'),('2019-01-28 19:59:59','2019-01-31 07:59:59','RCNETH','4h','0.000103060000000','0.000102540000000','1.316084715613269','1.309444272646852','12770.082627724321','12770.082627724321355','test','test','0.5'),('2019-02-05 15:59:59','2019-02-05 19:59:59','RCNETH','4h','0.000100230000000','0.000098020000000','1.314609061620732','1.285622869600560','13115.923991027954','13115.923991027953889','test','test','2.2'),('2019-02-06 03:59:59','2019-02-06 11:59:59','RCNETH','4h','0.000099390000000','0.000099670000000','1.308167685616249','1.311853035771924','13161.964841696841','13161.964841696841177','test','test','0.0'),('2019-02-07 03:59:59','2019-02-07 07:59:59','RCNETH','4h','0.000100000000000','0.000099080000000','1.308986652317510','1.296943975116189','13089.8665231751','13089.866523175100156','test','test','0.9'),('2019-02-07 11:59:59','2019-02-07 15:59:59','RCNETH','4h','0.000099390000000','0.000098780000000','1.306310501828328','1.298293101625941','13143.27902030715','13143.279020307150859','test','test','0.6'),('2019-02-07 19:59:59','2019-02-08 03:59:59','RCNETH','4h','0.000102610000000','0.000099030000000','1.304528857338908','1.259014645183433','12713.467082534922','12713.467082534922156','test','test','3.5'),('2019-02-21 23:59:59','2019-02-24 03:59:59','RCNETH','4h','0.000108920000000','0.000104563200000','1.294414587971025','1.242638004452184','11884.085456950284','11884.085456950284424','test','test','4.0'),('2019-02-25 19:59:59','2019-02-28 11:59:59','RCNETH','4h','0.000142190000000','0.000136502400000','1.282908680522394','1.231592333301498','9022.495819132104','9022.495819132103861','test','test','4.0'),('2019-02-28 19:59:59','2019-03-01 11:59:59','RCNETH','4h','0.000164020000000','0.000157459200000','1.271505047806639','1.220644845894373','7752.1341775798','7752.134177579800053','test','test','4.0'),('2019-03-03 15:59:59','2019-03-13 03:59:59','RCNETH','4h','0.000149250000000','0.000169370000000','1.260202780715024','1.430087403482101','8443.569720033664','8443.569720033663543','test','test','1.0'),('2019-03-14 03:59:59','2019-03-20 19:59:59','RCNETH','4h','0.000170940000000','0.000176620000000','1.297954919107708','1.341083408288308','7593.043869823961','7593.043869823961359','test','test','1.4'),('2019-03-24 15:59:59','2019-03-25 07:59:59','RCNETH','4h','0.000175890000000','0.000170290000000','1.307539027814508','1.265909494835025','7433.8451749076585','7433.845174907658475','test','test','3.2'),('2019-03-25 19:59:59','2019-03-25 23:59:59','RCNETH','4h','0.000173410000000','0.000169610000000','1.298288020485734','1.269838135947093','7486.811720695081','7486.811720695081021','test','test','2.2'),('2019-03-27 11:59:59','2019-04-02 07:59:59','RCNETH','4h','0.000177820000000','0.000208630000000','1.291965823921591','1.515818411004170','7265.582183790301','7265.582183790301315','test','test','1.1'),('2019-04-13 07:59:59','2019-04-14 23:59:59','RCNETH','4h','0.000187440000000','0.000184500000000','1.341710843273276','1.320666082927440','7158.081750284228','7158.081750284228292','test','test','1.6'),('2019-04-16 03:59:59','2019-04-17 23:59:59','RCNETH','4h','0.000187160000000','0.000187050000000','1.337034229863090','1.336248411497601','7143.803322628178','7143.803322628177739','test','test','0.3'),('2019-04-19 19:59:59','2019-04-20 03:59:59','RCNETH','4h','0.000188180000000','0.000185700000000','1.336859603559648','1.319241302906933','7104.153488998023','7104.153488998023022','test','test','1.3'),('2019-04-20 11:59:59','2019-04-20 23:59:59','RCNETH','4h','0.000193870000000','0.000186115200000','1.332944425636822','1.279626648611349','6875.454818367062','6875.454818367062217','test','test','4.0'),('2019-04-21 03:59:59','2019-04-21 11:59:59','RCNETH','4h','0.000187820000000','0.000182640000000','1.321096030742273','1.284660733972786','7033.841075190463','7033.841075190463016','test','test','2.8'),('2019-05-02 07:59:59','2019-05-02 11:59:59','RCNETH','4h','0.000162370000000','0.000191310000000','1.312999298126831','1.547021590962887','8086.46485266263','8086.464852662629710','test','test','0.0'),('2019-05-02 15:59:59','2019-05-02 23:59:59','RCNETH','4h','0.000206320000000','0.000198067200000','1.365004252090399','1.310404082006783','6615.95701866227','6615.957018662269547','test','test','4.0'),('2019-05-03 07:59:59','2019-05-04 07:59:59','RCNETH','4h','0.000180290000000','0.000173078400000','1.352870880960707','1.298756045722279','7503.8597867918725','7503.859786791872466','test','test','4.0'),('2019-05-10 15:59:59','2019-05-10 23:59:59','RCNETH','4h','0.000179030000000','0.000171868800000','1.340845362018834','1.287211547538081','7489.500988766319','7489.500988766319097','test','test','4.0'),('2019-05-11 03:59:59','2019-05-11 11:59:59','RCNETH','4h','0.000163630000000','0.000157084800000','1.328926736578667','1.275769667115520','8121.534783222311','8121.534783222310580','test','test','4.0'),('2019-05-22 19:59:59','2019-05-22 23:59:59','RCNETH','4h','0.000134020000000','0.000128840000000','1.317114054475745','1.266206348146955','9827.742534515335','9827.742534515335137','test','test','3.9'),('2019-05-24 07:59:59','2019-05-24 11:59:59','RCNETH','4h','0.000131330000000','0.000128390000000','1.305801230847125','1.276569100955322','9942.90132374267','9942.901323742669774','test','test','2.2'),('2019-05-27 23:59:59','2019-05-28 03:59:59','RCNETH','4h','0.000137390000000','0.000131894400000','1.299305201982280','1.247332993902988','9457.058024472522','9457.058024472522447','test','test','4.0'),('2019-05-28 07:59:59','2019-05-28 11:59:59','RCNETH','4h','0.000130730000000','0.000130940000000','1.287755822409104','1.289824427340688','9850.499674207174','9850.499674207174394','test','test','0.0'),('2019-06-02 03:59:59','2019-06-03 07:59:59','RCNETH','4h','0.000127600000000','0.000127150000000','1.288215512393900','1.283672432608812','10095.732855751568','10095.732855751568422','test','test','0.4'),('2019-06-07 11:59:59','2019-06-07 23:59:59','RCNETH','4h','0.000124930000000','0.000126490000000','1.287205939108325','1.303279270293861','10303.417426625512','10303.417426625512235','test','test','0.7'),('2019-06-08 07:59:59','2019-06-12 15:59:59','RCNETH','4h','0.000128340000000','0.000128200000000','1.290777790482889','1.289369742402262','10057.486290189254','10057.486290189253850','test','test','1.0'),('2019-06-14 03:59:59','2019-06-14 11:59:59','RCNETH','4h','0.000131500000000','0.000126240000000','1.290464890909416','1.238846295273039','9813.421223645752','9813.421223645751525','test','test','4.0'),('2019-06-20 07:59:59','2019-06-20 15:59:59','RCNETH','4h','0.000123180000000','0.000124260000000','1.278994091879110','1.290207873493247','10383.131124201253','10383.131124201252533','test','test','0.0'),('2019-06-20 19:59:59','2019-06-21 03:59:59','RCNETH','4h','0.000123120000000','0.000124240000000','1.281486043348918','1.293143486238382','10408.431151307004','10408.431151307004257','test','test','0.0'),('2019-06-21 11:59:59','2019-06-21 23:59:59','RCNETH','4h','0.000131100000000','0.000125856000000','1.284076586213244','1.232713522764714','9794.634524891257','9794.634524891256660','test','test','4.0'),('2019-07-10 23:59:59','2019-07-11 19:59:59','RCNETH','4h','0.000090450000000','0.000086860000000','1.272662572113570','1.222150038847813','14070.343528066009','14070.343528066008730','test','test','4.0'),('2019-07-22 15:59:59','2019-07-23 19:59:59','RCNETH','4h','0.000083100000000','0.000083890000000','1.261437564721180','1.273429570450780','15179.754088100844','15179.754088100844456','test','test','0.0'),('2019-07-24 03:59:59','2019-07-24 07:59:59','RCNETH','4h','0.000083110000000','0.000085720000000','1.264102454883313','1.303800534623963','15209.992237797056','15209.992237797056077','test','test','0.0'),('2019-07-24 11:59:59','2019-07-24 23:59:59','RCNETH','4h','0.000086570000000','0.000084160000000','1.272924250381235','1.237487639044527','14703.988106517678','14703.988106517677807','test','test','3.9'),('2019-07-26 11:59:59','2019-07-30 07:59:59','RCNETH','4h','0.000089270000000','0.000087280000000','1.265049447861967','1.236849062500196','14171.047920488038','14171.047920488037562','test','test','2.2'),('2019-08-09 07:59:59','2019-08-09 11:59:59','RCNETH','4h','0.000083070000000','0.000079747200000','1.258782695559351','1.208431387736977','15153.276701087652','15153.276701087652327','test','test','4.0'),('2019-08-10 19:59:59','2019-08-11 07:59:59','RCNETH','4h','0.000085660000000','0.000082233600000','1.247593516043268','1.197689775401537','14564.481859015503','14564.481859015502778','test','test','4.0'),('2019-08-11 11:59:59','2019-08-11 15:59:59','RCNETH','4h','0.000080550000000','0.000080040000000','1.236503795900661','1.228674907807435','15350.760967109387','15350.760967109386911','test','test','0.6'),('2019-08-18 11:59:59','2019-08-18 19:59:59','RCNETH','4h','0.000079940000000','0.000076742400000','1.234764042991056','1.185373481271414','15446.135138742253','15446.135138742252821','test','test','4.0'),('2019-08-20 19:59:59','2019-08-20 23:59:59','RCNETH','4h','0.000079750000000','0.000078150000000','1.223788362608913','1.199235868813624','15345.308622055332','15345.308622055332307','test','test','2.0'),('2019-08-21 07:59:59','2019-08-21 15:59:59','RCNETH','4h','0.000079880000000','0.000078550000000','1.218332252876626','1.198047051370293','15252.031207769482','15252.031207769481625','test','test','2.1'),('2019-08-22 03:59:59','2019-08-22 19:59:59','RCNETH','4h','0.000082200000000','0.000079170000000','1.213824430319663','1.169081267012259','14766.720563499555','14766.720563499555283','test','test','3.7'),('2019-08-23 15:59:59','2019-08-28 19:59:59','RCNETH','4h','0.000079560000000','0.000083330000000','1.203881505140241','1.260928177769435','15131.743402969338','15131.743402969337694','test','test','0.0'),('2019-08-29 03:59:59','2019-08-29 07:59:59','RCNETH','4h','0.000085240000000','0.000082110000000','1.216558543502283','1.171886696468471','14272.155601856914','14272.155601856913563','test','test','3.7'),('2019-08-29 19:59:59','2019-09-01 23:59:59','RCNETH','4h','0.000085250000000','0.000084950000000','1.206631466383659','1.202385255944772','14154.03479628925','14154.034796289250153','test','test','0.4'),('2019-09-16 11:59:59','2019-09-16 15:59:59','RCNETH','4h','0.000075610000000','0.000078610000000','1.205687864063906','1.253526292739897','15946.142891997168','15946.142891997167681','test','test','0.0'),('2019-09-17 03:59:59','2019-09-17 15:59:59','RCNETH','4h','0.000074950000000','0.000074060000000','1.216318625991904','1.201875349445769','16228.400613634476','16228.400613634476031','test','test','1.2'),('2019-09-19 03:59:59','2019-09-19 07:59:59','RCNETH','4h','0.000097280000000','0.000093388800000','1.213109008981652','1.164584648622386','12470.281753512043','12470.281753512042997','test','test','4.0'),('2019-09-19 11:59:59','2019-09-30 19:59:59','RCNETH','4h','0.000099630000000','0.000188800000000','1.202325817790704','2.278421302809243','12067.909442845566','12067.909442845566446','test','test','0.0'),('2019-10-01 11:59:59','2019-10-07 07:59:59','RCNETH','4h','0.000209760000000','0.000212630000000','1.441458147794823','1.461180615778095','6871.940063857854','6871.940063857853602','test','test','0.0'),('2019-10-07 19:59:59','2019-10-08 07:59:59','RCNETH','4h','0.000231010000000','0.000221769600000','1.445840918457773','1.388007281719462','6258.780652169918','6258.780652169917630','test','test','4.0'),('2019-10-08 11:59:59','2019-10-09 15:59:59','RCNETH','4h','0.000225390000000','0.000216374400000','1.432988999182593','1.375669439215289','6357.819775423011','6357.819775423011379','test','test','4.0'),('2019-10-09 19:59:59','2019-10-09 23:59:59','RCNETH','4h','0.000219850000000','0.000219190000000','1.420251319189859','1.415987658190699','6460.092422969564','6460.092422969563813','test','test','0.3'),('2019-10-15 15:59:59','2019-10-15 19:59:59','RCNETH','4h','0.000219030000000','0.000227200000000','1.419303838967823','1.472245045032595','6479.951782713888','6479.951782713887951','test','test','0.0'),('2019-10-15 23:59:59','2019-10-16 07:59:59','RCNETH','4h','0.000221080000000','0.000218120000000','1.431068551426661','1.411908234291584','6473.080113201833','6473.080113201833228','test','test','1.3'),('2019-10-17 11:59:59','2019-10-17 15:59:59','RCNETH','4h','0.000214210000000','0.000212640000000','1.426810703174422','1.416353241786140','6660.803432026618','6660.803432026617884','test','test','0.7'),('2019-10-21 07:59:59','2019-10-25 07:59:59','RCNETH','4h','0.000215740000000','0.000240460000000','1.424486822865915','1.587707895737174','6602.794210002386','6602.794210002385626','test','test','0.0'),('2019-10-29 23:59:59','2019-10-30 03:59:59','RCNETH','4h','0.000227020000000','0.000217939200000','1.460758172392861','1.402327845497147','6434.491112645851','6434.491112645850990','test','test','4.0'),('2019-11-01 15:59:59','2019-11-04 15:59:59','RCNETH','4h','0.000226350000000','0.000226800000000','1.447773655304925','1.450651932949667','6396.17254386978','6396.172543869780384','test','test','0.0'),('2019-11-06 19:59:59','2019-11-09 23:59:59','RCNETH','4h','0.000256040000000','0.000245798400000','1.448413272559312','1.390476741656939','5656.9804427406325','5656.980442740632498','test','test','4.0'),('2019-11-10 07:59:59','2019-11-10 19:59:59','RCNETH','4h','0.000252840000000','0.000250730000000','1.435538487914340','1.423558634214375','5677.655781974134','5677.655781974133788','test','test','0.9'),('2019-11-10 23:59:59','2019-11-15 19:59:59','RCNETH','4h','0.000256440000000','0.000255130000000','1.432876298203237','1.425556582282764','5587.56940494165','5587.569404941649736','test','test','2.1'),('2019-11-16 07:59:59','2019-11-16 11:59:59','RCNETH','4h','0.000257990000000','0.000253860000000','1.431249694665354','1.408337716530667','5547.694463604612','5547.694463604611883','test','test','1.6'),('2019-11-16 19:59:59','2019-11-17 11:59:59','RCNETH','4h','0.000269080000000','0.000258316800000','1.426158143968757','1.369111818210007','5300.12689151463','5300.126891514630188','test','test','4.0'),('2019-11-20 11:59:59','2019-11-21 11:59:59','RCNETH','4h','0.000262860000000','0.000254040000000','1.413481182689034','1.366053258960367','5377.31561549507','5377.315615495070233','test','test','3.4'),('2019-11-21 19:59:59','2019-11-30 15:59:59','RCNETH','4h','0.000257850000000','0.000302910000000','1.402941644082664','1.648109573042776','5440.921636931022','5440.921636931021567','test','test','0.0'),('2019-12-01 07:59:59','2019-12-01 23:59:59','RCNETH','4h','0.000372200000000','0.000357312000000','1.457423406073800','1.399126469830848','3915.6996401767865','3915.699640176786488','test','test','4.0'),('2019-12-02 03:59:59','2019-12-02 07:59:59','RCNETH','4h','0.000357340000000','0.000343046400000','1.444468531353144','1.386689790099018','4042.280548925796','4042.280548925796211','test','test','4.0'),('2019-12-04 23:59:59','2019-12-05 03:59:59','RCNETH','4h','0.000321430000000','0.000315340000000','1.431628811074449','1.404504337753840','4453.936505847149','4453.936505847149419','test','test','1.9'),('2019-12-06 11:59:59','2019-12-08 03:59:59','RCNETH','4h','0.000326180000000','0.000324160000000','1.425601150336536','1.416772545505830','4370.596450844736','4370.596450844735955','test','test','0.6'),('2019-12-08 15:59:59','2019-12-08 19:59:59','RCNETH','4h','0.000328820000000','0.000324410000000','1.423639238151935','1.404545968155432','4329.539681746654','4329.539681746654423','test','test','1.3'),('2019-12-09 11:59:59','2019-12-09 19:59:59','RCNETH','4h','0.000347170000000','0.000334530000000','1.419396289263823','1.367717949844246','4088.476219903283','4088.476219903282981','test','test','3.6'),('2019-12-16 03:59:59','2019-12-16 07:59:59','RCNETH','4h','0.000313830000000','0.000310230000000','1.407912213837250','1.391761801289647','4486.225707667369','4486.225707667368624','test','test','1.1'),('2019-12-16 15:59:59','2019-12-16 19:59:59','RCNETH','4h','0.000313580000000','0.000311500000000','1.404323233271116','1.395008250411227','4478.357144177296','4478.357144177295595','test','test','0.7'),('2019-12-18 03:59:59','2019-12-18 19:59:59','RCNETH','4h','0.000324620000000','0.000312030000000','1.402253237080030','1.347868515698607','4319.67604300422','4319.676043004220446','test','test','3.9'),('2019-12-19 19:59:59','2019-12-27 07:59:59','RCNETH','4h','0.000335480000000','0.000349810000000','1.390167743439713','1.449548641745100','4143.817048526629','4143.817048526629151','test','test','0.0'),('2019-12-27 15:59:59','2019-12-27 19:59:59','RCNETH','4h','0.000355150000000','0.000349810000000','1.403363498618688','1.382262664935389','3951.466981891281','3951.466981891281193','test','test','1.5'),('2019-12-30 03:59:59','2019-12-30 07:59:59','RCNETH','4h','0.000351600000000','0.000339010000000','1.398674424466845','1.348591059836477','3978.0273733414238','3978.027373341423754','test','test','3.6'),('2019-12-31 19:59:59','2019-12-31 23:59:59','RCNETH','4h','0.000349810000000','0.000346420000000','1.387544787882318','1.374098125891749','3966.5669588700093','3966.566958870009330','test','test','1.0'),('2020-01-01 07:59:59','2020-01-01 11:59:59','RCNETH','4h','0.000351600000000','0.000353400000000','1.384556640773303','1.391644814702177','3937.8744049297584','3937.874404929758384','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:28:50
