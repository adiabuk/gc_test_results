-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 11:59:59','2019-01-10 15:59:59','MDAETH','4h','0.005887700000000','0.005654800000000','1.297777777777778','1.246441526874294','220.4218587526161','220.421858752616089','test','test','4.0'),('2019-01-17 03:59:59','2019-01-20 15:59:59','MDAETH','4h','0.005848500000000','0.005899800000000','1.286369722021448','1.297653088139205','219.94865726621322','219.948657266213218','test','test','0.0'),('2019-01-21 23:59:59','2019-01-31 03:59:59','MDAETH','4h','0.005962800000000','0.006341800000000','1.288877136714283','1.370799125513960','216.1530047484878','216.153004748487803','test','test','0.7'),('2019-01-31 15:59:59','2019-02-06 23:59:59','MDAETH','4h','0.006709000000000','0.006697800000000','1.307082023114211','1.304899981281020','194.82516367777777','194.825163677777766','test','test','1.3'),('2019-02-23 07:59:59','2019-02-23 19:59:59','MDAETH','4h','0.006221500000000','0.005972640000000','1.306597124929058','1.254333239931896','210.01320018147675','210.013200181476748','test','test','4.0'),('2019-02-24 23:59:59','2019-03-02 15:59:59','MDAETH','4h','0.006162200000000','0.006436200000000','1.294982928263022','1.352563877006015','210.14944796712567','210.149447967125667','test','test','0.0'),('2019-03-07 19:59:59','2019-03-09 03:59:59','MDAETH','4h','0.006495600000000','0.006344300000000','1.307778694650353','1.277317010356277','201.33300921398384','201.333009213983843','test','test','2.4'),('2019-03-09 19:59:59','2019-03-12 19:59:59','MDAETH','4h','0.006945000000000','0.007400400000000','1.301009431473892','1.386319682747212','187.33037170250427','187.330371702504266','test','test','2.5'),('2019-03-12 23:59:59','2019-03-13 03:59:59','MDAETH','4h','0.008161400000000','0.007834944000000','1.319967265090185','1.267168574486577','161.73294595169767','161.732945951697673','test','test','4.0'),('2019-03-13 07:59:59','2019-03-14 15:59:59','MDAETH','4h','0.008747000000000','0.008397120000000','1.308234222733828','1.255904853824475','149.56376160212966','149.563761602129659','test','test','4.0'),('2019-03-18 11:59:59','2019-03-18 19:59:59','MDAETH','4h','0.008097200000000','0.007773312000000','1.296605474087305','1.244741255123813','160.13010350334747','160.130103503347470','test','test','4.0'),('2019-03-22 19:59:59','2019-03-28 03:59:59','MDAETH','4h','0.007632700000000','0.008177000000000','1.285080092095418','1.376721201287124','168.36507292248064','168.365072922480635','test','test','0.0'),('2019-03-29 15:59:59','2019-03-30 03:59:59','MDAETH','4h','0.008488100000000','0.008653900000000','1.305444783026908','1.330944334755312','153.79705505671566','153.797055056715664','test','test','2.3'),('2019-03-30 07:59:59','2019-03-30 11:59:59','MDAETH','4h','0.009192900000000','0.008825184000000','1.311111350077665','1.258666896074558','142.62217037906044','142.622170379060435','test','test','4.0'),('2019-03-30 15:59:59','2019-04-02 07:59:59','MDAETH','4h','0.008706200000000','0.008505600000000','1.299457026965863','1.269516171068990','149.25650995449945','149.256509954499450','test','test','3.4'),('2019-05-23 15:59:59','2019-05-23 19:59:59','MDAETH','4h','0.004172600000000','0.004070200000000','1.292803503433225','1.261076743439082','309.8316405678053','309.831640567805323','test','test','2.5'),('2019-06-02 11:59:59','2019-06-03 03:59:59','MDAETH','4h','0.003860000000000','0.003816600000000','1.285753112323415','1.271296717226307','333.0966612236826','333.096661223682588','test','test','1.1'),('2019-06-03 15:59:59','2019-06-03 23:59:59','MDAETH','4h','0.003849800000000','0.003842300000000','1.282540580079613','1.280041994607485','333.1447296170225','333.144729617022506','test','test','0.2'),('2019-06-04 23:59:59','2019-06-05 07:59:59','MDAETH','4h','0.003864500000000','0.003820000000000','1.281985338863585','1.267223183971767','331.7338177936563','331.733817793656328','test','test','1.2'),('2019-06-05 19:59:59','2019-06-06 15:59:59','MDAETH','4h','0.004007800000000','0.003898400000000','1.278704859998737','1.243800345880303','319.0540595834963','319.054059583496326','test','test','2.7'),('2019-06-06 19:59:59','2019-06-07 07:59:59','MDAETH','4h','0.003950200000000','0.003929700000000','1.270948301305751','1.264352574462359','321.74277284840036','321.742772848400364','test','test','0.5'),('2019-06-07 15:59:59','2019-06-12 15:59:59','MDAETH','4h','0.003972000000000','0.004050900000000','1.269482584229442','1.294699647647293','319.607901366929','319.607901366929013','test','test','1.3'),('2019-07-03 19:59:59','2019-07-03 23:59:59','MDAETH','4h','0.003031800000000','0.002910528000000','1.275086376100075','1.224082921056072','420.57074216639467','420.570742166394666','test','test','4.0'),('2019-07-07 07:59:59','2019-07-07 11:59:59','MDAETH','4h','0.002951500000000','0.002941000000000','1.263752274979186','1.259256459669248','428.172886660744','428.172886660743984','test','test','0.4'),('2019-07-07 15:59:59','2019-07-07 19:59:59','MDAETH','4h','0.003012800000000','0.002892288000000','1.262753204910311','1.212243076713899','419.1294493196729','419.129449319672915','test','test','4.0'),('2019-07-08 11:59:59','2019-07-08 15:59:59','MDAETH','4h','0.003124000000000','0.002999040000000','1.251528731977775','1.201467582698664','400.6173917982633','400.617391798263327','test','test','4.0'),('2019-07-08 19:59:59','2019-07-08 23:59:59','MDAETH','4h','0.002949200000000','0.002831232000000','1.240404032137972','1.190787870852453','420.590001403083','420.590001403083022','test','test','4.0'),('2019-07-13 19:59:59','2019-07-13 23:59:59','MDAETH','4h','0.002919100000000','0.002802336000000','1.229378218518968','1.180203089778209','421.14974427699224','421.149744276992237','test','test','4.0'),('2019-07-14 15:59:59','2019-07-14 23:59:59','MDAETH','4h','0.002881100000000','0.002850700000000','1.218450412132133','1.205593901587960','422.91153105832245','422.911531058322453','test','test','1.1'),('2019-07-15 19:59:59','2019-07-18 11:59:59','MDAETH','4h','0.002959900000000','0.002966800000000','1.215593409788983','1.218427152323374','410.68732382478566','410.687323824785665','test','test','1.9'),('2019-07-19 11:59:59','2019-07-20 03:59:59','MDAETH','4h','0.002984600000000','0.002865216000000','1.216223130352181','1.167574205138094','407.49954109501476','407.499541095014763','test','test','4.0'),('2019-07-20 19:59:59','2019-07-20 23:59:59','MDAETH','4h','0.002930000000000','0.002931600000000','1.205412258082384','1.206070503684067','411.4035010520082','411.403501052008210','test','test','0.0'),('2019-07-22 15:59:59','2019-07-24 23:59:59','MDAETH','4h','0.003016900000000','0.003019700000000','1.205558534882758','1.206677419796965','399.6017550740025','399.601755074002483','test','test','0.0'),('2019-07-26 11:59:59','2019-07-26 15:59:59','MDAETH','4h','0.003019400000000','0.003016000000000','1.205807175974804','1.204449374955292','399.3532410329218','399.353241032921801','test','test','0.1'),('2019-07-26 19:59:59','2019-07-26 23:59:59','MDAETH','4h','0.003285100000000','0.003153696000000','1.205505442414913','1.157285224718316','366.9615665930756','366.961566593075588','test','test','4.0'),('2019-07-28 07:59:59','2019-07-29 15:59:59','MDAETH','4h','0.003106300000000','0.003038600000000','1.194789838482335','1.168750089563926','384.6344005673423','384.634400567342311','test','test','2.2'),('2019-07-30 19:59:59','2019-07-31 15:59:59','MDAETH','4h','0.003187500000000','0.003116500000000','1.189003227611578','1.162518763561250','373.0206204271617','373.020620427161703','test','test','2.6'),('2019-07-31 19:59:59','2019-07-31 23:59:59','MDAETH','4h','0.003114700000000','0.003079600000000','1.183117791155950','1.169785067468412','379.8496777076282','379.849677707628189','test','test','1.1'),('2019-08-01 19:59:59','2019-08-03 07:59:59','MDAETH','4h','0.003181000000000','0.003117200000000','1.180154963669830','1.156485084172145','371.00124604521534','371.001246045215339','test','test','2.0'),('2019-08-03 15:59:59','2019-08-05 03:59:59','MDAETH','4h','0.003350000000000','0.003216000000000','1.174894990448122','1.127899190830197','350.7149225218275','350.714922521827475','test','test','4.0'),('2019-08-09 11:59:59','2019-08-09 15:59:59','MDAETH','4h','0.003191700000000','0.003165200000000','1.164451479421917','1.154783288738369','364.8373842848377','364.837384284837697','test','test','0.8'),('2019-08-14 19:59:59','2019-08-14 23:59:59','MDAETH','4h','0.003215700000000','0.003133500000000','1.162302992603350','1.132592103530366','361.4463390873994','361.446339087399394','test','test','2.6'),('2019-08-15 11:59:59','2019-08-16 07:59:59','MDAETH','4h','0.003298300000000','0.003166368000000','1.155700572809354','1.109472549896980','350.3928001726204','350.392800172620412','test','test','4.0'),('2019-08-16 15:59:59','2019-08-17 15:59:59','MDAETH','4h','0.003210700000000','0.003093400000000','1.145427678828826','1.103580521907712','356.75325593447735','356.753255934477352','test','test','3.7'),('2019-08-20 19:59:59','2019-08-20 23:59:59','MDAETH','4h','0.003568200000000','0.003425472000000','1.136128310624134','1.090683178199169','318.4037639773932','318.403763977393226','test','test','4.0'),('2019-08-21 03:59:59','2019-08-26 11:59:59','MDAETH','4h','0.003225200000000','0.003328800000000','1.126029392307476','1.162199752298501','349.13474894811964','349.134748948119636','test','test','0.0'),('2019-08-26 15:59:59','2019-08-28 11:59:59','MDAETH','4h','0.003508200000000','0.003439400000000','1.134067250083259','1.111826834255847','323.26185795657574','323.261857956575739','test','test','2.6'),('2019-08-30 23:59:59','2019-08-31 23:59:59','MDAETH','4h','0.003457000000000','0.003476400000000','1.129124935454945','1.135461361184718','326.61988297799974','326.619882977999737','test','test','0.6'),('2019-09-01 11:59:59','2019-09-01 23:59:59','MDAETH','4h','0.003471000000000','0.003450000000000','1.130533030061561','1.123693158661016','325.70816193072926','325.708161930729261','test','test','0.6'),('2019-09-02 11:59:59','2019-09-02 15:59:59','MDAETH','4h','0.003446600000000','0.003397600000000','1.129013058639218','1.112961982252831','327.5729874772871','327.572987477287086','test','test','1.4'),('2019-09-04 19:59:59','2019-09-04 23:59:59','MDAETH','4h','0.003475900000000','0.003336864000000','1.125446152775577','1.080428306664554','323.7855383571382','323.785538357138194','test','test','4.0'),('2019-09-09 19:59:59','2019-09-12 23:59:59','MDAETH','4h','0.003538600000000','0.003490100000000','1.115442186973127','1.100153952623894','315.2213267883137','315.221326788313718','test','test','1.4'),('2019-09-24 19:59:59','2019-10-07 23:59:59','MDAETH','4h','0.003246700000000','0.005117600000000','1.112044801562186','1.752856893607245','342.5154161339779','342.515416133977908','test','test','1.2'),('2019-10-08 03:59:59','2019-10-08 07:59:59','MDAETH','4h','0.005247400000000','0.005153400000000','1.254447488683310','1.231975776228336','239.06077079759697','239.060770797596973','test','test','1.8'),('2019-10-11 19:59:59','2019-10-11 23:59:59','MDAETH','4h','0.005774200000000','0.005543232000000','1.249453774804427','1.199475623812250','216.38560749617733','216.385607496177329','test','test','4.0'),('2019-10-12 23:59:59','2019-10-14 03:59:59','MDAETH','4h','0.006224000000000','0.005975040000000','1.238347519028388','1.188813618267252','198.96329033232453','198.963290332324533','test','test','4.0'),('2019-10-14 15:59:59','2019-10-15 15:59:59','MDAETH','4h','0.006517700000000','0.006256992000000','1.227339985525913','1.178246386104876','188.30875700414458','188.308757004144582','test','test','4.0'),('2019-10-25 23:59:59','2019-10-26 03:59:59','MDAETH','4h','0.004694400000000','0.004506624000000','1.216430296765683','1.167773084895056','259.1236998904403','259.123699890440321','test','test','4.0'),('2019-10-27 23:59:59','2019-10-28 03:59:59','MDAETH','4h','0.004637300000000','0.004451808000000','1.205617583016654','1.157392879695988','259.982658662725','259.982658662724987','test','test','4.0'),('2019-11-09 23:59:59','2019-11-10 19:59:59','MDAETH','4h','0.004107700000000','0.004106300000000','1.194900982278729','1.194493732144788','290.8929528151347','290.892952815134720','test','test','1.7'),('2019-11-10 23:59:59','2019-11-11 03:59:59','MDAETH','4h','0.004023900000000','0.004098900000000','1.194810482248964','1.217080117719197','296.9284729364457','296.928472936445701','test','test','0.0'),('2019-11-11 07:59:59','2019-11-11 11:59:59','MDAETH','4h','0.004107800000000','0.004000200000000','1.199759290131238','1.168332711520273','292.0685744513458','292.068574451345796','test','test','2.6'),('2019-11-22 15:59:59','2019-11-25 11:59:59','MDAETH','4h','0.003867400000000','0.003820100000000','1.192775605995468','1.178187436640453','308.4179567656483','308.417956765648285','test','test','1.2'),('2019-11-25 19:59:59','2019-11-26 23:59:59','MDAETH','4h','0.003929600000000','0.003940800000000','1.189533790583243','1.192924155621551','302.71116413457923','302.711164134579235','test','test','0.9'),('2019-11-27 15:59:59','2019-11-27 19:59:59','MDAETH','4h','0.003898000000000','0.003971400000000','1.190287205036200','1.212700514643603','305.3584415177527','305.358441517752681','test','test','0.0'),('2019-11-29 19:59:59','2019-11-30 11:59:59','MDAETH','4h','0.003957800000000','0.003900700000000','1.195267940504512','1.178023562465498','302.00311802125213','302.003118021252135','test','test','1.4'),('2019-11-30 19:59:59','2019-11-30 23:59:59','MDAETH','4h','0.003917000000000','0.003908100000000','1.191435856495842','1.188728739027674','304.17050204131783','304.170502041317832','test','test','0.2'),('2019-12-01 03:59:59','2019-12-01 07:59:59','MDAETH','4h','0.003923400000000','0.003877000000000','1.190834274836249','1.176750900632140','303.5209957782151','303.520995778215081','test','test','1.2'),('2019-12-01 11:59:59','2019-12-01 15:59:59','MDAETH','4h','0.003940700000000','0.003809700000000','1.187704636124225','1.148221978897774','301.3943299729045','301.394329972904472','test','test','3.3'),('2019-12-09 15:59:59','2019-12-09 23:59:59','MDAETH','4h','0.003756300000000','0.003637000000000','1.178930712296125','1.141487900492774','313.8542481420879','313.854248142087897','test','test','3.2'),('2019-12-12 23:59:59','2019-12-13 15:59:59','MDAETH','4h','0.003787200000000','0.003708800000000','1.170610087450936','1.146376925522294','309.0964531714553','309.096453171455323','test','test','2.1'),('2019-12-16 19:59:59','2019-12-22 11:59:59','MDAETH','4h','0.003712800000000','0.003806900000000','1.165224940355682','1.194757278991609','313.8399429960358','313.839942996035802','test','test','0.3'),('2019-12-23 07:59:59','2019-12-23 11:59:59','MDAETH','4h','0.003826200000000','0.003760900000000','1.171787682274777','1.151789319499035','306.25364128241506','306.253641282415060','test','test','1.7'),('2019-12-24 07:59:59','2019-12-24 11:59:59','MDAETH','4h','0.003826200000000','0.003797200000000','1.167343601657945','1.158495929176611','305.09215452876094','305.092154528760943','test','test','0.8'),('2019-12-24 15:59:59','2019-12-24 19:59:59','MDAETH','4h','0.003834100000000','0.003834100000000','1.165377452217649','1.165377452217649','303.9507191303432','303.950719130343202','test','test','0.0'),('2019-12-25 15:59:59','2019-12-29 15:59:59','MDAETH','4h','0.003875200000000','0.003812800000000','1.165377452217649','1.146612084489949','300.727046918262','300.727046918261976','test','test','1.6');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:17:48
