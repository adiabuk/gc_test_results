-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-02 15:59:59','BQXBTC','4h','0.000030720000000','0.000030700000000','0.033333333333333','0.033311631944444','1085.0694444444446','1085.069444444444571','test','test','0.1'),('2019-01-09 07:59:59','2019-01-09 15:59:59','BQXBTC','4h','0.000032010000000','0.000030729600000','0.033328510802469','0.031995370370370','1041.190590517623','1041.190590517622923','test','test','4.0'),('2019-01-09 19:59:59','2019-01-09 23:59:59','BQXBTC','4h','0.000030140000000','0.000029980000000','0.033032257373114','0.032856903651160','1095.960762213463','1095.960762213463113','test','test','0.5'),('2019-01-15 03:59:59','2019-01-15 07:59:59','BQXBTC','4h','0.000029610000000','0.000029100000000','0.032993289879346','0.032425016396115','1114.2617318252692','1114.261731825269180','test','test','1.7'),('2019-01-15 15:59:59','2019-01-15 19:59:59','BQXBTC','4h','0.000029430000000','0.000029280000000','0.032867006883073','0.032699489009051','1116.7858268118473','1116.785826811847301','test','test','0.5'),('2019-01-15 23:59:59','2019-01-24 07:59:59','BQXBTC','4h','0.000029500000000','0.000047060000000','0.032829780688846','0.052371846753122','1112.8739216557815','1112.873921655781487','test','test','0.0'),('2019-01-25 03:59:59','2019-01-25 07:59:59','BQXBTC','4h','0.000050120000000','0.000048115200000','0.037172462036462','0.035685563555004','741.6692345662897','741.669234566289674','test','test','4.0'),('2019-01-25 19:59:59','2019-01-27 03:59:59','BQXBTC','4h','0.000050100000000','0.000048096000000','0.036842040151694','0.035368358545626','735.3700629080638','735.370062908063801','test','test','4.0'),('2019-01-29 11:59:59','2019-01-29 15:59:59','BQXBTC','4h','0.000047280000000','0.000045550000000','0.036514555350346','0.035178468616926','772.3044701849736','772.304470184973638','test','test','3.7'),('2019-02-12 23:59:59','2019-02-13 03:59:59','BQXBTC','4h','0.000041550000000','0.000040140000000','0.036217647187363','0.034988600676312','871.6641922349779','871.664192234977918','test','test','3.4'),('2019-02-13 19:59:59','2019-02-13 23:59:59','BQXBTC','4h','0.000040520000000','0.000040170000000','0.035944525740463','0.035634047359190','887.0810893500277','887.081089350027696','test','test','0.9'),('2019-02-16 07:59:59','2019-02-16 11:59:59','BQXBTC','4h','0.000040480000000','0.000039580000000','0.035875530544625','0.035077902642200','886.2532249166173','886.253224916617341','test','test','2.2'),('2019-02-17 03:59:59','2019-02-17 15:59:59','BQXBTC','4h','0.000040660000000','0.000040320000000','0.035698279899641','0.035399769934912','877.9704844968358','877.970484496835752','test','test','0.8'),('2019-02-17 23:59:59','2019-02-18 15:59:59','BQXBTC','4h','0.000040540000000','0.000040050000000','0.035631944351924','0.035201267175495','878.9330131209613','878.933013120961277','test','test','1.2'),('2019-02-18 19:59:59','2019-02-18 23:59:59','BQXBTC','4h','0.000040340000000','0.000040580000000','0.035536238312717','0.035747658669560','880.9181535130724','880.918153513072411','test','test','0.0'),('2019-02-24 19:59:59','2019-02-24 23:59:59','BQXBTC','4h','0.000040120000000','0.000038515200000','0.035583220614238','0.034159891789668','886.9197560876869','886.919756087686892','test','test','4.0'),('2019-03-08 03:59:59','2019-03-08 07:59:59','BQXBTC','4h','0.000038300000000','0.000038190000000','0.035266925319889','0.035165636500432','920.8074496054599','920.807449605459851','test','test','0.3'),('2019-03-08 11:59:59','2019-03-08 23:59:59','BQXBTC','4h','0.000039030000000','0.000037500000000','0.035244416693343','0.033862813886763','903.0083703136847','903.008370313684736','test','test','3.9'),('2019-03-09 03:59:59','2019-03-16 07:59:59','BQXBTC','4h','0.000038660000000','0.000040310000000','0.034937393847436','0.036428513864204','903.709101071817','903.709101071817031','test','test','0.0'),('2019-03-18 11:59:59','2019-03-18 15:59:59','BQXBTC','4h','0.000040980000000','0.000040410000000','0.035268753851163','0.034778192853233','860.6333297013829','860.633329701382877','test','test','1.4'),('2019-03-25 07:59:59','2019-03-25 11:59:59','BQXBTC','4h','0.000039990000000','0.000039600000000','0.035159740296067','0.034816847104883','879.21331072936','879.213310729360046','test','test','1.0'),('2019-03-26 15:59:59','2019-03-26 19:59:59','BQXBTC','4h','0.000042280000000','0.000040588800000','0.035083541809137','0.033680200136772','829.7904874441184','829.790487444118412','test','test','4.0'),('2019-03-26 23:59:59','2019-03-27 03:59:59','BQXBTC','4h','0.000039780000000','0.000039860000000','0.034771688104167','0.034841616084266','874.0997512359811','874.099751235981103','test','test','0.0'),('2019-03-27 07:59:59','2019-03-29 15:59:59','BQXBTC','4h','0.000041720000000','0.000041180000000','0.034787227655300','0.034336961525533','833.8261662344305','833.826166234430502','test','test','2.1'),('2019-03-31 11:59:59','2019-04-02 07:59:59','BQXBTC','4h','0.000042650000000','0.000050250000000','0.034687168515352','0.040868234886200','813.2982066905561','813.298206690556071','test','test','2.0'),('2019-04-02 11:59:59','2019-04-02 19:59:59','BQXBTC','4h','0.000046720000000','0.000044851200000','0.036060738819985','0.034618309267186','771.8480055647498','771.848005564749769','test','test','4.0'),('2019-04-03 07:59:59','2019-04-03 15:59:59','BQXBTC','4h','0.000043840000000','0.000042820000000','0.035740198919363','0.034908652320418','815.2417636716037','815.241763671603735','test','test','2.3'),('2019-05-21 19:59:59','2019-05-21 23:59:59','BQXBTC','4h','0.000017220000000','0.000017000000000','0.035555410786264','0.035101160474244','2064.774145543799','2064.774145543799023','test','test','1.3'),('2019-05-22 15:59:59','2019-05-24 15:59:59','BQXBTC','4h','0.000017780000000','0.000017760000000','0.035454466272482','0.035414584983087','1994.0644697683915','1994.064469768391518','test','test','1.1'),('2019-05-24 19:59:59','2019-05-24 23:59:59','BQXBTC','4h','0.000017810000000','0.000017460000000','0.035445603763728','0.034749030977804','1990.2079597825689','1990.207959782568878','test','test','2.0'),('2019-05-26 11:59:59','2019-05-26 15:59:59','BQXBTC','4h','0.000018510000000','0.000018470000000','0.035290809811300','0.035214546581022','1906.5807569584008','1906.580756958400798','test','test','0.2'),('2019-06-07 11:59:59','2019-06-07 15:59:59','BQXBTC','4h','0.000016090000000','0.000016070000000','0.035273862426794','0.035230016730800','2192.2847996764312','2192.284799676431248','test','test','0.1'),('2019-06-07 19:59:59','2019-06-07 23:59:59','BQXBTC','4h','0.000015930000000','0.000015910000000','0.035264118938795','0.035219845092042','2213.692337651921','2213.692337651921207','test','test','0.1'),('2019-06-08 03:59:59','2019-06-13 19:59:59','BQXBTC','4h','0.000016140000000','0.000016310000000','0.035254280306183','0.035625607917834','2184.2800685367615','2184.280068536761519','test','test','0.0'),('2019-07-03 19:59:59','2019-07-03 23:59:59','BQXBTC','4h','0.000010200000000','0.000009792000000','0.035336797553217','0.033923325651088','3464.3919169820474','3464.391916982047405','test','test','4.0'),('2019-07-04 03:59:59','2019-07-04 07:59:59','BQXBTC','4h','0.000010680000000','0.000010252800000','0.035022692686077','0.033621784978634','3279.2783413929883','3279.278341392988295','test','test','4.0'),('2019-07-04 11:59:59','2019-07-06 15:59:59','BQXBTC','4h','0.000010630000000','0.000010204800000','0.034711379862201','0.033322924667713','3265.41673209792','3265.416732097919976','test','test','4.0'),('2019-07-08 07:59:59','2019-07-08 11:59:59','BQXBTC','4h','0.000011700000000','0.000011232000000','0.034402834263426','0.033026720892889','2940.4131849081864','2940.413184908186395','test','test','4.0'),('2019-07-08 15:59:59','2019-07-09 23:59:59','BQXBTC','4h','0.000012030000000','0.000011548800000','0.034097031292195','0.032733150040507','2834.333440747742','2834.333440747741861','test','test','4.0'),('2019-07-12 15:59:59','2019-07-14 07:59:59','BQXBTC','4h','0.000011990000000','0.000012180000000','0.033793946569598','0.034329463654521','2818.5109732775645','2818.510973277564517','test','test','0.8'),('2019-07-16 19:59:59','2019-07-17 15:59:59','BQXBTC','4h','0.000012100000000','0.000011930000000','0.033912950366248','0.033436487427218','2802.7231707642604','2802.723170764260431','test','test','4.0'),('2019-07-19 19:59:59','2019-07-20 19:59:59','BQXBTC','4h','0.000012050000000','0.000011660000000','0.033807069713130','0.032712898992124','2805.5659512970774','2805.565951297077390','test','test','3.2'),('2019-07-21 23:59:59','2019-07-28 19:59:59','BQXBTC','4h','0.000012410000000','0.000012700000000','0.033563920664017','0.034348250800404','2704.5866771972064','2704.586677197206427','test','test','0.3'),('2019-07-28 23:59:59','2019-07-30 15:59:59','BQXBTC','4h','0.000012850000000','0.000012660000000','0.033738216249881','0.033239363246964','2625.542120613316','2625.542120613316001','test','test','2.0'),('2019-07-30 23:59:59','2019-07-31 03:59:59','BQXBTC','4h','0.000012650000000','0.000012490000000','0.033627360027011','0.033202033734179','2658.289330198472','2658.289330198471816','test','test','1.3'),('2019-08-21 11:59:59','2019-08-23 07:59:59','BQXBTC','4h','0.000008590000000','0.000008630000000','0.033532843073048','0.033688991352783','3903.7069933699645','3903.706993369964493','test','test','0.0'),('2019-08-25 07:59:59','2019-08-25 15:59:59','BQXBTC','4h','0.000009100000000','0.000009080000000','0.033567542690767','0.033493767871666','3688.7409550293287','3688.740955029328688','test','test','2.7'),('2019-08-28 11:59:59','2019-08-28 15:59:59','BQXBTC','4h','0.000008690000000','0.000008470000000','0.033551148286522','0.032701752127370','3860.8916325111877','3860.891632511187709','test','test','2.5'),('2019-08-29 19:59:59','2019-08-29 23:59:59','BQXBTC','4h','0.000008730000000','0.000008600000000','0.033362393584488','0.032865588181741','3821.580021132697','3821.580021132696857','test','test','1.5'),('2019-09-28 11:59:59','2019-09-28 15:59:59','BQXBTC','4h','0.000007240000000','0.000006950400000','0.033251992383878','0.031921912688523','4592.816627607458','4592.816627607458031','test','test','4.0'),('2019-09-28 19:59:59','2019-09-28 23:59:59','BQXBTC','4h','0.000007050000000','0.000006768000000','0.032956419118244','0.031638162353514','4674.669378474263','4674.669378474262885','test','test','4.0'),('2019-09-29 07:59:59','2019-09-29 11:59:59','BQXBTC','4h','0.000006950000000','0.000006780000000','0.032663473170526','0.031864510517434','4699.7803123058675','4699.780312305867483','test','test','2.4'),('2019-10-01 07:59:59','2019-10-01 11:59:59','BQXBTC','4h','0.000006750000000','0.000006840000000','0.032485925914283','0.032919071593140','4812.729765078979','4812.729765078978744','test','test','0.0'),('2019-10-01 19:59:59','2019-10-08 11:59:59','BQXBTC','4h','0.000007130000000','0.000007430000000','0.032582180509585','0.033953099745612','4569.730786758017','4569.730786758016620','test','test','1.7'),('2019-10-08 15:59:59','2019-10-09 15:59:59','BQXBTC','4h','0.000007530000000','0.000007228800000','0.032886829228702','0.031571356059554','4367.440800624406','4367.440800624405711','test','test','4.0'),('2019-11-08 07:59:59','2019-11-08 11:59:59','BQXBTC','4h','0.000005020000000','0.000004880000000','0.032594501857780','0.031685491845810','6492.928656928286','6492.928656928285818','test','test','2.8'),('2019-11-14 15:59:59','2019-11-14 19:59:59','BQXBTC','4h','0.000004770000000','0.000004640000000','0.032392499632898','0.031509685177494','6790.88042618402','6790.880426184019598','test','test','2.7'),('2019-11-18 11:59:59','2019-11-18 15:59:59','BQXBTC','4h','0.000004740000000','0.000004690000000','0.032196318642808','0.031856695028432','6792.472287512235','6792.472287512235198','test','test','1.1'),('2019-11-26 23:59:59','2019-11-27 07:59:59','BQXBTC','4h','0.000004180000000','0.000004210000000','0.032120846728502','0.032351379121290','7684.413092943115','7684.413092943114862','test','test','0.2');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:39:17
