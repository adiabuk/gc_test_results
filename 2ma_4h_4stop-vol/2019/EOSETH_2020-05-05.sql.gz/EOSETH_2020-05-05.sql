-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 23:59:59','2019-01-10 19:59:59','EOSETH','4h','0.019325000000000','0.018863000000000','1.297777777777778','1.266751990800633','67.15538306741412','67.155383067414121','test','test','2.4'),('2019-01-11 11:59:59','2019-01-13 19:59:59','EOSETH','4h','0.019239000000000','0.019395000000000','1.290883158449524','1.301350322684574','67.09720663493547','67.097206634935475','test','test','1.5'),('2019-01-14 19:59:59','2019-01-15 03:59:59','EOSETH','4h','0.019073000000000','0.019039000000000','1.293209194946201','1.290903888354256','67.80313505721183','67.803135057211833','test','test','0.2'),('2019-01-15 11:59:59','2019-01-15 15:59:59','EOSETH','4h','0.019130000000000','0.018778000000000','1.292696904592435','1.268910740953306','67.57432852025276','67.574328520252763','test','test','1.8'),('2019-01-15 23:59:59','2019-01-20 11:59:59','EOSETH','4h','0.019693000000000','0.019506000000000','1.287411090450407','1.275186143823980','65.37404613062546','65.374046130625459','test','test','0.9'),('2019-01-20 15:59:59','2019-02-10 23:59:59','EOSETH','4h','0.019633000000000','0.022686000000000','1.284694435644534','1.484468902716441','65.43546251945878','65.435462519458781','test','test','0.0'),('2019-02-11 03:59:59','2019-02-14 07:59:59','EOSETH','4h','0.022765000000000','0.022735000000000','1.329088761660514','1.327337271968011','58.38298975007747','58.382989750077471','test','test','0.2'),('2019-02-15 11:59:59','2019-02-15 15:59:59','EOSETH','4h','0.022850000000000','0.022767000000000','1.328699541728846','1.323873193284054','58.14877644327555','58.148776443275551','test','test','0.4'),('2019-02-16 19:59:59','2019-02-16 23:59:59','EOSETH','4h','0.023017000000000','0.022733000000000','1.327627019852226','1.311245820146008','57.680280655699086','57.680280655699086','test','test','1.2'),('2019-02-17 03:59:59','2019-02-17 07:59:59','EOSETH','4h','0.022789000000000','0.022863000000000','1.323986753250844','1.328285977426567','58.09762399626327','58.097623996263273','test','test','0.0'),('2019-02-18 19:59:59','2019-02-25 11:59:59','EOSETH','4h','0.023667000000000','0.024841000000000','1.324942136401005','1.390665805143760','55.98268206367535','55.982682063675348','test','test','0.0'),('2019-02-25 23:59:59','2019-02-26 15:59:59','EOSETH','4h','0.025715000000000','0.025100000000000','1.339547396121617','1.307510777470449','52.09206284742823','52.092062847428231','test','test','2.4'),('2019-02-27 23:59:59','2019-03-01 23:59:59','EOSETH','4h','0.025964000000000','0.025633000000000','1.332428147532468','1.315441792701423','51.31829254092083','51.318292540920829','test','test','1.3'),('2019-03-03 19:59:59','2019-03-04 07:59:59','EOSETH','4h','0.026890000000000','0.025897000000000','1.328653402014458','1.279588588767885','49.41068806301445','49.410688063014447','test','test','3.7'),('2019-03-05 15:59:59','2019-03-11 07:59:59','EOSETH','4h','0.027063000000000','0.026933000000000','1.317750110181886','1.311420157319171','48.69194509780462','48.691945097804620','test','test','0.8'),('2019-03-11 11:59:59','2019-03-11 15:59:59','EOSETH','4h','0.026804000000000','0.026684000000000','1.316343453990172','1.310450258404482','49.109963214078945','49.109963214078945','test','test','0.4'),('2019-03-12 11:59:59','2019-03-13 11:59:59','EOSETH','4h','0.027344000000000','0.026778000000000','1.315033854971130','1.287813654491549','48.09222699572594','48.092226995725937','test','test','2.1'),('2019-03-13 15:59:59','2019-03-13 19:59:59','EOSETH','4h','0.027086000000000','0.027101000000000','1.308984921531223','1.309709826420205','48.326992598804665','48.326992598804665','test','test','0.0'),('2019-03-14 15:59:59','2019-03-15 03:59:59','EOSETH','4h','0.027081000000000','0.026976000000000','1.309146011506552','1.304070115815544','48.34186372388584','48.341863723885837','test','test','0.4'),('2019-03-15 07:59:59','2019-03-15 11:59:59','EOSETH','4h','0.026972000000000','0.027350000000000','1.308018034686328','1.326349297370276','48.49540392578705','48.495403925787052','test','test','0.0'),('2019-03-15 15:59:59','2019-03-15 19:59:59','EOSETH','4h','0.026938000000000','0.026993000000000','1.312091648616095','1.314770579519424','48.70783460598762','48.707834605987621','test','test','0.0'),('2019-03-16 03:59:59','2019-03-16 07:59:59','EOSETH','4h','0.027202000000000','0.026828000000000','1.312686966594612','1.294638847871489','48.25700193348328','48.257001933483281','test','test','1.4'),('2019-03-17 03:59:59','2019-03-17 15:59:59','EOSETH','4h','0.027119000000000','0.026911000000000','1.308676273545029','1.298638858268014','48.25680421641761','48.256804216417613','test','test','0.8'),('2019-03-25 19:59:59','2019-03-30 19:59:59','EOSETH','4h','0.027283000000000','0.029271000000000','1.306445736816804','1.401641064485748','47.88497367653131','47.884973676531310','test','test','0.9'),('2019-03-31 11:59:59','2019-04-08 03:59:59','EOSETH','4h','0.029740000000000','0.030330000000000','1.327600254076569','1.353937986084141','44.64022374164658','44.640223741646579','test','test','1.1'),('2019-04-09 19:59:59','2019-04-18 03:59:59','EOSETH','4h','0.031698000000000','0.032035000000000','1.333453083411585','1.347629803996786','42.067420134127865','42.067420134127865','test','test','0.2'),('2019-05-03 23:59:59','2019-05-04 07:59:59','EOSETH','4h','0.030281000000000','0.029837000000000','1.336603465763852','1.317005303919819','44.14000415322651','44.140004153226513','test','test','1.5'),('2019-05-04 23:59:59','2019-05-05 07:59:59','EOSETH','4h','0.030252000000000','0.030131000000000','1.332248318687400','1.326919677719491','44.03835510668386','44.038355106683859','test','test','0.5'),('2019-05-26 23:59:59','2019-06-02 19:59:59','EOSETH','4h','0.025934000000000','0.028200000000000','1.331064176250087','1.447366768344739','51.32506270726025','51.325062707260251','test','test','0.0'),('2019-06-16 15:59:59','2019-06-16 19:59:59','EOSETH','4h','0.026052000000000','0.025901000000000','1.356909196715565','1.349044415174645','52.08464596635826','52.084645966358259','test','test','0.6'),('2019-06-17 03:59:59','2019-06-17 11:59:59','EOSETH','4h','0.026185000000000','0.026072000000000','1.355161467484250','1.349313338944028','51.75334991347144','51.753349913471439','test','test','0.4'),('2019-06-17 15:59:59','2019-06-17 19:59:59','EOSETH','4h','0.026012000000000','0.026014000000000','1.353861883364200','1.353965978542069','52.04758893449948','52.047588934499480','test','test','0.0'),('2019-06-17 23:59:59','2019-06-18 07:59:59','EOSETH','4h','0.026076000000000','0.025790000000000','1.353885015625949','1.339035686186272','51.92073230656348','51.920732306563480','test','test','1.1'),('2019-07-15 07:59:59','2019-07-15 11:59:59','EOSETH','4h','0.018830000000000','0.018889000000000','1.350585164639354','1.354816950338437','71.72518134037995','71.725181340379947','test','test','0.0'),('2019-07-16 11:59:59','2019-07-16 15:59:59','EOSETH','4h','0.018866000000000','0.018935000000000','1.351525561461372','1.356468594629019','71.63816184996143','71.638161849961435','test','test','0.0'),('2019-07-20 19:59:59','2019-07-22 19:59:59','EOSETH','4h','0.018980000000000','0.019049000000000','1.352624013276405','1.357541350310971','71.26575412415202','71.265754124152025','test','test','1.2'),('2019-07-23 11:59:59','2019-07-28 23:59:59','EOSETH','4h','0.019500000000000','0.020195000000000','1.353716754839642','1.401964608409568','69.42137204305857','69.421372043058568','test','test','0.7'),('2019-07-30 15:59:59','2019-07-30 19:59:59','EOSETH','4h','0.020047000000000','0.019876000000000','1.364438500077404','1.352799901608145','68.06197935239206','68.061979352392058','test','test','0.9'),('2019-07-31 15:59:59','2019-07-31 19:59:59','EOSETH','4h','0.020002000000000','0.020040000000000','1.361852144862013','1.364439405211216','68.08579866323431','68.085798663234314','test','test','0.0'),('2019-08-01 07:59:59','2019-08-01 11:59:59','EOSETH','4h','0.020012000000000','0.020017000000000','1.362427091606280','1.362767494137663','68.08050627654808','68.080506276548078','test','test','0.0'),('2019-08-10 19:59:59','2019-08-11 07:59:59','EOSETH','4h','0.019753000000000','0.019699000000000','1.362502736613254','1.358777978461221','68.97700281543331','68.977002815433309','test','test','1.1'),('2019-08-11 19:59:59','2019-08-12 03:59:59','EOSETH','4h','0.019576000000000','0.019378000000000','1.361675012579469','1.347902451663514','69.55838846441914','69.558388464419139','test','test','1.0'),('2019-08-13 03:59:59','2019-08-13 07:59:59','EOSETH','4h','0.019292000000000','0.019329000000000','1.358614443487035','1.361220121198471','70.42372193069846','70.423721930698463','test','test','0.0'),('2019-08-13 15:59:59','2019-08-14 19:59:59','EOSETH','4h','0.019565000000000','0.019492000000000','1.359193482978465','1.354122124723549','69.47066102624404','69.470661026244045','test','test','0.6'),('2019-08-15 19:59:59','2019-08-15 23:59:59','EOSETH','4h','0.019593000000000','0.019270000000000','1.358066514477372','1.335678136782471','69.31386283251018','69.313862832510182','test','test','1.6'),('2019-08-22 19:59:59','2019-08-22 23:59:59','EOSETH','4h','0.019086000000000','0.019087000000000','1.353091319434061','1.353162213876031','70.89444196971921','70.894441969719210','test','test','0.0'),('2019-08-26 19:59:59','2019-08-26 23:59:59','EOSETH','4h','0.019105000000000','0.019006000000000','1.353107073754499','1.346095422338550','70.8247617772572','70.824761777257194','test','test','0.5'),('2019-08-31 19:59:59','2019-09-01 11:59:59','EOSETH','4h','0.019453000000000','0.019240000000000','1.351548928995399','1.336750187316685','69.47766046344518','69.477660463445176','test','test','1.2'),('2019-09-06 19:59:59','2019-09-06 23:59:59','EOSETH','4h','0.019002000000000','0.019003000000000','1.348260319733462','1.348331273334121','70.95360065958648','70.953600659586485','test','test','0.0'),('2019-09-07 15:59:59','2019-09-16 23:59:59','EOSETH','4h','0.019671000000000','0.020706000000000','1.348276087200276','1.419216341902745','68.54130889127526','68.541308891275264','test','test','0.0'),('2019-10-04 19:59:59','2019-10-04 23:59:59','EOSETH','4h','0.017227000000000','0.017116000000000','1.364040588245269','1.355251564892670','79.18039056395594','79.180390563955939','test','test','0.6'),('2019-10-07 03:59:59','2019-10-07 15:59:59','EOSETH','4h','0.017254000000000','0.017631000000000','1.362087471944691','1.391849091101011','78.94328688679096','78.943286886790958','test','test','0.3'),('2019-10-07 19:59:59','2019-10-09 15:59:59','EOSETH','4h','0.017581000000000','0.017030000000000','1.368701165090540','1.325805178402361','77.85115551393778','77.851155513937783','test','test','3.1'),('2019-10-12 19:59:59','2019-10-13 03:59:59','EOSETH','4h','0.017073000000000','0.017051000000000','1.359168723604278','1.357417320106399','79.60924990360675','79.609249903606752','test','test','0.1'),('2019-10-13 23:59:59','2019-10-14 19:59:59','EOSETH','4h','0.017127000000000','0.017010000000000','1.358779522826971','1.349497266496571','79.33552419145043','79.335524191450432','test','test','0.7'),('2019-10-21 15:59:59','2019-10-21 19:59:59','EOSETH','4h','0.016822000000000','0.016772000000000','1.356716799197994','1.352684232323669','80.6513374865054','80.651337486505398','test','test','0.3'),('2019-10-22 03:59:59','2019-10-22 23:59:59','EOSETH','4h','0.016893000000000','0.016901000000000','1.355820673225922','1.356462747776671','80.25931884365843','80.259318843658434','test','test','0.0'),('2019-10-23 03:59:59','2019-10-23 19:59:59','EOSETH','4h','0.017198000000000','0.016709000000000','1.355963356459421','1.317408519774419','78.84424679959422','78.844246799594217','test','test','2.8'),('2019-10-24 15:59:59','2019-11-03 19:59:59','EOSETH','4h','0.017009000000000','0.017893000000000','1.347395614973865','1.417423113570896','79.21662737220679','79.216627372206787','test','test','0.6'),('2019-11-04 11:59:59','2019-11-11 11:59:59','EOSETH','4h','0.018242000000000','0.018555000000000','1.362957281328761','1.386343183590349','74.71534268878199','74.715342688781988','test','test','0.0'),('2019-11-12 03:59:59','2019-11-12 11:59:59','EOSETH','4h','0.018710000000000','0.018657000000000','1.368154148498003','1.364278564859821','73.12421958834862','73.124219588348623','test','test','0.3'),('2019-11-12 15:59:59','2019-11-13 01:59:59','EOSETH','4h','0.018729000000000','0.018515000000000','1.367292907689518','1.351670040358344','73.00405294941098','73.004052949410976','test','test','1.1'),('2019-11-15 07:59:59','2019-11-15 15:59:59','EOSETH','4h','0.018734000000000','0.018473000000000','1.363821159393702','1.344820555005864','72.79925052811474','72.799250528114740','test','test','1.4'),('2019-11-15 19:59:59','2019-11-15 23:59:59','EOSETH','4h','0.018559000000000','0.018519000000000','1.359598802863071','1.356668475145278','73.25819294482844','73.258192944828437','test','test','0.2'),('2019-11-18 11:59:59','2019-11-18 15:59:59','EOSETH','4h','0.018542000000000','0.018540000000000','1.358947618925784','1.358801038446987','73.29023939843512','73.290239398435119','test','test','0.0'),('2019-11-26 15:59:59','2019-11-26 23:59:59','EOSETH','4h','0.017888000000000','0.017688000000000','1.358915045486051','1.343721451507003','75.96796989523988','75.967969895239875','test','test','1.1'),('2019-11-29 15:59:59','2019-12-04 03:59:59','EOSETH','4h','0.017979000000000','0.017966000000000','1.355538691268485','1.354558547601624','75.39566668159993','75.395666681599934','test','test','0.1'),('2019-12-04 11:59:59','2019-12-04 15:59:59','EOSETH','4h','0.018042000000000','0.018078000000000','1.355320881564738','1.358025213220670','75.12032377589723','75.120323775897234','test','test','0.0'),('2019-12-04 23:59:59','2019-12-05 23:59:59','EOSETH','4h','0.018059000000000','0.018127000000000','1.355921844154945','1.361027480425090','75.08288632565177','75.082886325651771','test','test','0.0'),('2019-12-06 11:59:59','2019-12-08 15:59:59','EOSETH','4h','0.018307000000000','0.018206000000000','1.357056429992755','1.349569528838592','74.12773419963702','74.127734199637018','test','test','0.6'),('2019-12-08 19:59:59','2019-12-09 03:59:59','EOSETH','4h','0.018282000000000','0.018200000000000','1.355392674180719','1.349313350294776','74.1380961700426','74.138096170042601','test','test','0.4'),('2019-12-13 15:59:59','2019-12-13 19:59:59','EOSETH','4h','0.018233000000000','0.018137000000000','1.354041713317176','1.346912441969704','74.2632432028287','74.263243202828704','test','test','0.5'),('2019-12-18 15:59:59','2019-12-29 23:59:59','EOSETH','4h','0.018261000000000','0.019976000000000','1.352457430795515','1.479474817237348','74.06261600106869','74.062616001068690','test','test','0.0'),('2019-12-31 15:59:59','2020-01-01 15:59:59','EOSETH','4h','0.020025000000000','0.019923000000000','1.380683516671478','1.373650821605286','68.94799084501764','68.947990845017642','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:49:19
