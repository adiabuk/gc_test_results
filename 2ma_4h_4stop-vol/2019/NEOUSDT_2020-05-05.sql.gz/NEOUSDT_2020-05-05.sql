-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-03 19:59:59','NEOUSDT','4h','7.756000000000000','7.480000000000000','222.222222222222200','214.314365938914648','28.65165320038966','28.651653200389660','test','test','3.6'),('2019-01-05 15:59:59','2019-01-10 07:59:59','NEOUSDT','4h','7.737000000000000','8.327999999999999','220.464920825931671','237.305397523375802','28.49488442883956','28.494884428839558','test','test','2.0'),('2019-01-19 11:59:59','2019-01-20 11:59:59','NEOUSDT','4h','7.900000000000000','7.584000000000000','224.207248980919275','215.238959021682490','28.380664427964465','28.380664427964465','test','test','4.0'),('2019-02-02 23:59:59','2019-02-03 03:59:59','NEOUSDT','4h','7.237000000000000','7.119000000000000','222.214295656644396','218.591069611669383','30.705305465889786','30.705305465889786','test','test','1.6'),('2019-02-08 15:59:59','2019-02-24 19:59:59','NEOUSDT','4h','7.413000000000000','9.410000000000000','221.409134313316628','281.054897327439505','29.86768303160888','29.867683031608880','test','test','0.0'),('2019-02-24 23:59:59','2019-02-27 23:59:59','NEOUSDT','4h','8.907999999999999','8.856999999999999','234.663748316455013','233.320253574185216','26.343034162152563','26.343034162152563','test','test','0.7'),('2019-02-28 19:59:59','2019-02-28 23:59:59','NEOUSDT','4h','8.864000000000001','8.813000000000001','234.365193929284004','233.016747980458035','26.440116643646657','26.440116643646657','test','test','0.6'),('2019-03-01 23:59:59','2019-03-02 07:59:59','NEOUSDT','4h','8.946999999999999','8.746000000000000','234.065539273989287','228.807109253415746','26.161343385938228','26.161343385938228','test','test','2.2'),('2019-03-05 19:59:59','2019-03-05 23:59:59','NEOUSDT','4h','8.754000000000000','8.739000000000001','232.896999269417392','232.497929702471879','26.604637796369364','26.604637796369364','test','test','0.2'),('2019-03-06 11:59:59','2019-03-06 15:59:59','NEOUSDT','4h','8.736000000000001','8.689000000000000','232.808317143429548','231.555799869420696','26.649303702315652','26.649303702315652','test','test','0.5'),('2019-03-07 07:59:59','2019-03-07 11:59:59','NEOUSDT','4h','8.779999999999999','8.669000000000000','232.529979971427565','229.590250156299078','26.484052388545283','26.484052388545283','test','test','1.3'),('2019-03-07 19:59:59','2019-03-08 23:59:59','NEOUSDT','4h','9.144000000000000','8.778240000000000','231.876706679176806','222.601638412009720','25.358344999909974','25.358344999909974','test','test','4.0'),('2019-03-09 15:59:59','2019-03-10 07:59:59','NEOUSDT','4h','9.010999999999999','8.755000000000001','229.815580397584085','223.286583773260332','25.503893063764743','25.503893063764743','test','test','2.8'),('2019-03-12 15:59:59','2019-03-12 19:59:59','NEOUSDT','4h','8.789999999999999','8.811000000000000','228.364692258845480','228.910273434890513','25.98005600214397','25.980056002143971','test','test','0.0'),('2019-03-13 03:59:59','2019-03-13 11:59:59','NEOUSDT','4h','8.907000000000000','8.784000000000001','228.485932520188840','225.330687241196699','25.652400642212736','25.652400642212736','test','test','1.4'),('2019-03-13 15:59:59','2019-03-14 07:59:59','NEOUSDT','4h','8.981999999999999','8.779000000000000','227.784766902635027','222.636658721691504','25.36013882238199','25.360138822381991','test','test','2.3'),('2019-03-14 15:59:59','2019-03-18 07:59:59','NEOUSDT','4h','9.090999999999999','9.053000000000001','226.640742862425327','225.693394030748749','24.93023241254266','24.930232412542662','test','test','0.4'),('2019-03-19 15:59:59','2019-03-20 03:59:59','NEOUSDT','4h','9.125000000000000','9.029999999999999','226.430220899830573','224.072865175393957','24.814270783543076','24.814270783543076','test','test','1.0'),('2019-03-20 11:59:59','2019-03-21 15:59:59','NEOUSDT','4h','9.084000000000000','8.920000000000000','225.906364072177979','221.827913641988971','24.86860018407948','24.868600184079479','test','test','1.8'),('2019-03-22 11:59:59','2019-03-24 07:59:59','NEOUSDT','4h','9.143000000000001','9.132000000000000','225.000041754358193','224.729342808793490','24.60899505133525','24.608995051335249','test','test','0.1'),('2019-03-24 23:59:59','2019-03-25 03:59:59','NEOUSDT','4h','9.124000000000001','9.085000000000001','224.939886433121586','223.978394152225945','24.653648228093115','24.653648228093115','test','test','0.4'),('2019-03-25 11:59:59','2019-03-25 15:59:59','NEOUSDT','4h','9.268000000000001','8.932000000000000','224.726221481811422','216.579047289117341','24.24754224016092','24.247542240160922','test','test','3.6'),('2019-03-27 11:59:59','2019-04-09 07:59:59','NEOUSDT','4h','9.236000000000001','12.166000000000000','222.915738327879438','293.632835913488634','24.13552818621475','24.135528186214749','test','test','1.0'),('2019-05-02 15:59:59','2019-05-02 19:59:59','NEOUSDT','4h','10.061999999999999','9.853000000000000','238.630648902459257','233.673999566282163','23.71602553194785','23.716025531947849','test','test','2.1'),('2019-05-03 11:59:59','2019-05-03 19:59:59','NEOUSDT','4h','10.016000000000000','9.948000000000000','237.529171272197658','235.916553096627638','23.71497317014753','23.714973170147530','test','test','0.7'),('2019-05-04 03:59:59','2019-05-04 07:59:59','NEOUSDT','4h','9.968999999999999','9.747999999999999','237.170811677626574','231.913037640034474','23.790832749285443','23.790832749285443','test','test','2.2'),('2019-05-11 11:59:59','2019-05-12 11:59:59','NEOUSDT','4h','9.516000000000000','9.371000000000000','236.002417447050561','232.406331851230647','24.80059031599943','24.800590315999429','test','test','1.5'),('2019-05-13 15:59:59','2019-05-22 23:59:59','NEOUSDT','4h','9.846000000000000','11.154000000000000','235.203287314646133','266.449062229084177','23.888207121130016','23.888207121130016','test','test','1.4'),('2019-05-24 11:59:59','2019-05-26 11:59:59','NEOUSDT','4h','11.675000000000001','11.208000000000000','242.146792851187911','232.460921137140389','20.740624655348','20.740624655348000','test','test','4.0'),('2019-05-26 19:59:59','2019-06-03 23:59:59','NEOUSDT','4h','11.573000000000000','12.417999999999999','239.994376914732896','257.517512531508942','20.737438599734975','20.737438599734975','test','test','0.0'),('2019-06-10 11:59:59','2019-06-10 15:59:59','NEOUSDT','4h','12.257999999999999','12.272000000000000','243.888407051794246','244.166954751151849','19.896264239826582','19.896264239826582','test','test','0.0'),('2019-06-12 11:59:59','2019-06-20 11:59:59','NEOUSDT','4h','12.625999999999999','13.260000000000000','243.950306540540367','256.199989286200321','19.321266160346934','19.321266160346934','test','test','0.0'),('2019-06-20 23:59:59','2019-06-27 19:59:59','NEOUSDT','4h','13.538000000000000','17.274999999999999','246.672458261798170','314.763385763965346','18.220745919766447','18.220745919766447','test','test','0.0'),('2019-07-02 15:59:59','2019-07-04 23:59:59','NEOUSDT','4h','17.689000000000000','17.010999999999999','261.803775484501955','251.769123453381326','14.800371727316522','14.800371727316522','test','test','3.8'),('2019-07-08 11:59:59','2019-07-09 11:59:59','NEOUSDT','4h','17.427000000000000','17.366000000000000','259.573852810919561','258.665262403995484','14.894924703673585','14.894924703673585','test','test','0.7'),('2019-07-09 15:59:59','2019-07-09 19:59:59','NEOUSDT','4h','17.265999999999998','17.311000000000000','259.371943831603119','260.047939283498295','15.022121153226175','15.022121153226175','test','test','0.0'),('2019-07-10 07:59:59','2019-07-10 15:59:59','NEOUSDT','4h','17.251999999999999','16.561919999999997','259.522165043135374','249.141278441409924','15.043019072753037','15.043019072753037','test','test','4.0'),('2019-08-04 03:59:59','2019-08-04 07:59:59','NEOUSDT','4h','11.971000000000000','11.830000000000000','257.215301353863026','254.185700026413798','21.486534237228554','21.486534237228554','test','test','1.2'),('2019-08-05 03:59:59','2019-08-05 15:59:59','NEOUSDT','4h','12.279000000000000','12.159000000000001','256.542056614429896','254.034926816096856','20.892748319442127','20.892748319442127','test','test','1.1'),('2019-08-05 19:59:59','2019-08-06 03:59:59','NEOUSDT','4h','12.141000000000000','11.813000000000001','255.984916659244817','249.069254632703974','21.084335446770844','21.084335446770844','test','test','2.7'),('2019-08-06 07:59:59','2019-08-06 11:59:59','NEOUSDT','4h','12.113000000000000','11.740000000000000','254.448102875569020','246.612790205496594','21.006200187861722','21.006200187861722','test','test','3.1'),('2019-08-24 23:59:59','2019-08-25 03:59:59','NEOUSDT','4h','10.102000000000000','9.999000000000001','252.706922282219580','250.130322302505789','25.015533783628943','25.015533783628943','test','test','1.0'),('2019-09-03 15:59:59','2019-09-03 19:59:59','NEOUSDT','4h','9.340000000000000','9.282999999999999','252.134344508949852','250.595623134537618','26.995111831793345','26.995111831793345','test','test','0.6'),('2019-09-04 03:59:59','2019-09-04 07:59:59','NEOUSDT','4h','9.253000000000000','9.183999999999999','251.792406425747203','249.914780137691793','27.2119751892086','27.211975189208601','test','test','0.7'),('2019-09-06 11:59:59','2019-09-06 15:59:59','NEOUSDT','4h','9.206000000000000','9.127000000000001','251.375156139512598','249.218015433992150','27.305578550892093','27.305578550892093','test','test','0.9'),('2019-09-08 11:59:59','2019-09-08 15:59:59','NEOUSDT','4h','9.164000000000000','9.255000000000001','250.895791538285863','253.387227268314717','27.378414615701207','27.378414615701207','test','test','0.0'),('2019-09-14 15:59:59','2019-09-16 15:59:59','NEOUSDT','4h','9.050000000000001','8.903000000000000','251.449443922736720','247.365126988301085','27.78446894173886','27.784468941738862','test','test','1.6'),('2019-09-16 23:59:59','2019-09-22 03:59:59','NEOUSDT','4h','9.082000000000001','9.090000000000000','250.541817937306547','250.762511016308764','27.586634875281494','27.586634875281494','test','test','0.0'),('2019-10-09 07:59:59','2019-10-10 11:59:59','NEOUSDT','4h','7.609000000000000','7.514000000000000','250.590860843751528','247.462180099875013','32.93348151448962','32.933481514489621','test','test','1.2'),('2019-10-14 23:59:59','2019-10-15 11:59:59','NEOUSDT','4h','7.529000000000000','7.499000000000000','249.895598456223411','248.899866227018094','33.191074306843326','33.191074306843326','test','test','0.4'),('2019-10-15 15:59:59','2019-10-15 19:59:59','NEOUSDT','4h','7.451000000000000','7.351000000000000','249.674324627511083','246.323441194045643','33.50883433465456','33.508834334654559','test','test','1.3'),('2019-10-20 19:59:59','2019-10-21 03:59:59','NEOUSDT','4h','7.298000000000000','7.300000000000000','248.929683864518779','248.997902467934637','34.109301707936254','34.109301707936254','test','test','0.0'),('2019-10-21 11:59:59','2019-10-21 15:59:59','NEOUSDT','4h','7.389000000000000','7.257000000000000','248.944843554166738','244.497595029447552','33.691276702418016','33.691276702418016','test','test','1.8'),('2019-10-22 03:59:59','2019-10-22 23:59:59','NEOUSDT','4h','7.457000000000000','7.264000000000000','247.956566104229154','241.539023223966836','33.25151751431261','33.251517514312610','test','test','2.6'),('2019-10-25 15:59:59','2019-11-08 15:59:59','NEOUSDT','4h','7.474000000000000','10.574999999999999','246.530445464170839','348.817160929034856','32.98507431953048','32.985074319530483','test','test','0.0'),('2019-11-10 11:59:59','2019-11-11 11:59:59','NEOUSDT','4h','10.901000000000000','10.849000000000000','269.260826678585090','267.976397453074924','24.70056202904184','24.700562029041841','test','test','1.3'),('2019-11-11 15:59:59','2019-11-18 11:59:59','NEOUSDT','4h','11.146000000000001','11.728999999999999','268.975397961805072','283.044360550332954','24.13201130107707','24.132011301077071','test','test','0.0'),('2019-11-20 03:59:59','2019-11-20 07:59:59','NEOUSDT','4h','11.815000000000000','11.785000000000000','272.101834092589058','271.410928039031944','23.030201785238177','23.030201785238177','test','test','0.3'),('2019-11-20 15:59:59','2019-11-20 19:59:59','NEOUSDT','4h','11.811000000000000','11.558999999999999','271.948299414020767','266.145998893122169','23.025002067057894','23.025002067057894','test','test','2.1'),('2019-12-13 15:59:59','2019-12-13 23:59:59','NEOUSDT','4h','9.034000000000001','8.894000000000000','270.658899298265510','266.464495279917344','29.96002870248677','29.960028702486770','test','test','1.5'),('2019-12-14 03:59:59','2019-12-14 11:59:59','NEOUSDT','4h','9.100000000000000','8.882999999999999','269.726809516410356','263.294862520249808','29.640308738067073','29.640308738067073','test','test','2.4'),('2019-12-15 19:59:59','2019-12-16 03:59:59','NEOUSDT','4h','8.952000000000000','8.789999999999999','268.297487961708043','263.442238514679786','29.970675598939682','29.970675598939682','test','test','1.8'),('2019-12-22 07:59:59','2019-12-23 19:59:59','NEOUSDT','4h','8.699000000000000','8.686000000000000','267.218543640146152','266.819205662525519','30.718305970818044','30.718305970818044','test','test','0.1'),('2019-12-24 11:59:59','2019-12-24 15:59:59','NEOUSDT','4h','8.726000000000001','8.648999999999999','267.129801867341655','264.772594126820707','30.613087539232367','30.613087539232367','test','test','0.9'),('2019-12-26 19:59:59','2019-12-26 23:59:59','NEOUSDT','4h','8.725000000000000','8.525000000000000','266.605977925003629','260.494666110103822','30.556559074498985','30.556559074498985','test','test','2.3'),('2019-12-27 19:59:59','2019-12-31 15:59:59','NEOUSDT','4h','8.736000000000001','8.776999999999999','265.247908632803671','266.492776335865074','30.362626903938146','30.362626903938146','test','test','0.6');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:24:52
