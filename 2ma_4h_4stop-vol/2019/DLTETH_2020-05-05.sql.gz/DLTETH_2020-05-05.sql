-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-05 03:59:59','DLTETH','4h','0.000295300000000','0.000308540000000','1.297777777777778','1.355964631071980','4394.777439139105','4394.777439139104899','test','test','0.0'),('2019-01-07 15:59:59','2019-01-28 07:59:59','DLTETH','4h','0.000350440000000','0.001133500000000','1.310708189620934','4.239492446453968','3740.1786029589484','3740.178602958948431','test','test','0.0'),('2019-01-28 15:59:59','2019-01-29 23:59:59','DLTETH','4h','0.001159220000000','0.001112851200000','1.961549135583830','1.883087170160477','1692.1284446298632','1692.128444629863225','test','test','4.0'),('2019-01-30 15:59:59','2019-01-30 19:59:59','DLTETH','4h','0.001099010000000','0.001107560000000','1.944113143267529','1.959237816723582','1768.9676556787738','1768.967655678773781','test','test','0.0'),('2019-02-01 19:59:59','2019-02-01 23:59:59','DLTETH','4h','0.001092900000000','0.001085690000000','1.947474181813319','1.934626447481840','1781.9326395949481','1781.932639594948114','test','test','0.7'),('2019-02-02 07:59:59','2019-02-02 15:59:59','DLTETH','4h','0.001231970000000','0.001182691200000','1.944619129739657','1.866834364550070','1578.4630548955388','1578.463054895538789','test','test','4.0'),('2019-02-03 11:59:59','2019-02-03 19:59:59','DLTETH','4h','0.001164100000000','0.001117536000000','1.927333626364194','1.850240281309626','1655.6426650323801','1655.642665032380137','test','test','4.0'),('2019-02-20 11:59:59','2019-02-20 15:59:59','DLTETH','4h','0.000822440000000','0.000789542400000','1.910201771907623','1.833793701031318','2322.603195257554','2322.603195257554034','test','test','4.0'),('2019-03-02 19:59:59','2019-03-02 23:59:59','DLTETH','4h','0.000726550000000','0.000732570000000','1.893222200601777','1.908908936060621','2605.770009774657','2605.770009774656955','test','test','0.0'),('2019-03-03 23:59:59','2019-03-04 07:59:59','DLTETH','4h','0.000726790000000','0.000738290000000','1.896708141814854','1.926719759518552','2609.7058872781045','2609.705887278104456','test','test','0.0'),('2019-03-04 19:59:59','2019-03-05 03:59:59','DLTETH','4h','0.000734000000000','0.000716640000000','1.903377390193453','1.858360181073891','2593.1572073480293','2593.157207348029260','test','test','2.4'),('2019-03-05 15:59:59','2019-03-05 19:59:59','DLTETH','4h','0.000737110000000','0.000707980000000','1.893373565944662','1.818548950926594','2568.6445251653913','2568.644525165391315','test','test','4.0'),('2019-03-06 15:59:59','2019-03-06 23:59:59','DLTETH','4h','0.000780780000000','0.000749548800000','1.876745873718424','1.801676038769687','2403.680772712447','2403.680772712446924','test','test','4.0'),('2019-03-07 15:59:59','2019-03-07 19:59:59','DLTETH','4h','0.000734160000000','0.000727170000000','1.860063688174261','1.842353863094798','2533.5944319688633','2533.594431968863319','test','test','1.0'),('2019-03-09 03:59:59','2019-03-09 07:59:59','DLTETH','4h','0.000726960000000','0.000734720000000','1.856128171489935','1.875941578844895','2553.2741436804436','2553.274143680443558','test','test','0.0'),('2019-03-09 15:59:59','2019-03-10 15:59:59','DLTETH','4h','0.000729000000000','0.000728780000000','1.860531150902149','1.859969673737268','2552.1689312786675','2552.168931278667515','test','test','0.0'),('2019-03-10 19:59:59','2019-03-11 15:59:59','DLTETH','4h','0.000738650000000','0.000731230000000','1.860406378198842','1.841717939389886','2518.6575214226523','2518.657521422652280','test','test','1.0'),('2019-03-12 11:59:59','2019-03-18 11:59:59','DLTETH','4h','0.000763090000000','0.000761580000000','1.856253391796852','1.852580243647075','2432.5484435608532','2432.548443560853229','test','test','0.3'),('2019-03-20 15:59:59','2019-03-21 03:59:59','DLTETH','4h','0.000782480000000','0.000768090000000','1.855437136652456','1.821315190536991','2371.2262762657915','2371.226276265791512','test','test','1.8'),('2019-03-21 07:59:59','2019-03-21 11:59:59','DLTETH','4h','0.000778600000000','0.000783820000000','1.847854481960131','1.860243128756730','2373.3039840227734','2373.303984022773420','test','test','0.0'),('2019-03-26 19:59:59','2019-04-02 07:59:59','DLTETH','4h','0.000830370000000','0.000861450000000','1.850607514581598','1.919874084367592','2228.6541115184773','2228.654111518477293','test','test','3.7'),('2019-04-02 15:59:59','2019-04-02 23:59:59','DLTETH','4h','0.000850820000000','0.000816787200000','1.866000085645152','1.791360082219346','2193.1784462579067','2193.178446257906671','test','test','4.0'),('2019-05-05 23:59:59','2019-05-07 15:59:59','DLTETH','4h','0.000587770000000','0.000564259200000','1.849413418217195','1.775436881488507','3146.4916858927727','3146.491685892772693','test','test','4.0'),('2019-05-10 07:59:59','2019-05-10 15:59:59','DLTETH','4h','0.000624000000000','0.000599040000000','1.832974187833042','1.759655220319720','2937.4586343478236','2937.458634347823590','test','test','4.0'),('2019-05-10 19:59:59','2019-05-11 03:59:59','DLTETH','4h','0.000549620000000','0.000528080000000','1.816681083941193','1.745484055907109','3305.3402058534857','3305.340205853485713','test','test','3.9'),('2019-05-11 07:59:59','2019-05-11 11:59:59','DLTETH','4h','0.000546280000000','0.000524428800000','1.800859522155841','1.728825141269607','3296.586955692759','3296.586955692759147','test','test','4.0'),('2019-05-12 15:59:59','2019-05-12 19:59:59','DLTETH','4h','0.000554000000000','0.000547750000000','1.784851881958900','1.764715917586620','3221.7542995648014','3221.754299564801386','test','test','1.1'),('2019-05-21 19:59:59','2019-05-21 23:59:59','DLTETH','4h','0.000495470000000','0.000490960000000','1.780377223209504','1.764171395860371','3593.309833510614','3593.309833510614226','test','test','0.9'),('2019-05-22 03:59:59','2019-05-22 11:59:59','DLTETH','4h','0.000512030000000','0.000491548800000','1.776775928243030','1.705704891113309','3470.0621608949277','3470.062160894927729','test','test','4.0'),('2019-05-22 19:59:59','2019-05-22 23:59:59','DLTETH','4h','0.000540350000000','0.000518736000000','1.760982364436426','1.690543069858969','3258.9661597787094','3258.966159778709425','test','test','4.0'),('2019-05-24 15:59:59','2019-05-24 19:59:59','DLTETH','4h','0.000529750000000','0.000527690000000','1.745329187863657','1.738542254164744','3294.6280091810427','3294.628009181042671','test','test','0.4'),('2019-06-03 11:59:59','2019-06-03 15:59:59','DLTETH','4h','0.000460610000000','0.000450870000000','1.743820980375010','1.706946365518944','3785.8947490827595','3785.894749082759517','test','test','2.1'),('2019-06-07 23:59:59','2019-06-14 11:59:59','DLTETH','4h','0.000445120000000','0.000456810000000','1.735626621518106','1.781208656038115','3899.233064158219','3899.233064158218895','test','test','0.0'),('2019-06-19 23:59:59','2019-06-20 03:59:59','DLTETH','4h','0.000461350000000','0.000461470000000','1.745755962522553','1.746210044489612','3784.016392158996','3784.016392158996041','test','test','0.0'),('2019-07-15 23:59:59','2019-07-17 15:59:59','DLTETH','4h','0.000293110000000','0.000288720000000','1.745856869626344','1.719708626108007','5956.3197080493455','5956.319708049345536','test','test','1.5'),('2019-07-22 15:59:59','2019-07-22 19:59:59','DLTETH','4h','0.000288340000000','0.000284850000000','1.740046148844491','1.718985036756445','6034.702604024732','6034.702604024731954','test','test','1.2'),('2019-07-22 23:59:59','2019-07-23 07:59:59','DLTETH','4h','0.000289800000000','0.000282000000000','1.735365901713814','1.688658330860233','5988.150109433452','5988.150109433451689','test','test','2.7'),('2019-07-23 11:59:59','2019-07-23 15:59:59','DLTETH','4h','0.000285730000000','0.000297270000000','1.724986441524130','1.794654812136906','6037.12050370675','6037.120503706750242','test','test','0.0'),('2019-07-23 19:59:59','2019-07-24 11:59:59','DLTETH','4h','0.000299110000000','0.000287145600000','1.740468301660302','1.670849569593890','5818.823515296386','5818.823515296386176','test','test','4.0'),('2019-07-27 03:59:59','2019-07-27 11:59:59','DLTETH','4h','0.000285730000000','0.000285730000000','1.724997472312211','1.724997472312211','6037.159109341724','6037.159109341723706','test','test','0.0'),('2019-07-28 19:59:59','2019-07-30 15:59:59','DLTETH','4h','0.000303050000000','0.000290928000000','1.724997472312211','1.655997573419723','5692.121670721697','5692.121670721697228','test','test','4.0'),('2019-08-02 03:59:59','2019-08-02 07:59:59','DLTETH','4h','0.000303730000000','0.000291580800000','1.709664161447213','1.641277594989324','5628.894615109516','5628.894615109516053','test','test','4.0'),('2019-08-02 15:59:59','2019-08-02 19:59:59','DLTETH','4h','0.000293950000000','0.000291130000000','1.694467146678793','1.678211329860851','5764.474048915778','5764.474048915778440','test','test','1.0'),('2019-08-21 15:59:59','2019-08-21 19:59:59','DLTETH','4h','0.000247660000000','0.000260270000000','1.690854742941473','1.776947282344251','6827.32271235352','6827.322712353519819','test','test','0.0'),('2019-08-21 23:59:59','2019-08-22 03:59:59','DLTETH','4h','0.000258860000000','0.000248880000000','1.709986418364313','1.644060186210732','6605.834885128303','6605.834885128302631','test','test','3.9'),('2019-08-22 15:59:59','2019-08-23 11:59:59','DLTETH','4h','0.000255080000000','0.000252410000000','1.695336144552406','1.677590545109271','6646.291926267861','6646.291926267860617','test','test','1.0'),('2019-08-24 11:59:59','2019-08-26 03:59:59','DLTETH','4h','0.000269160000000','0.000258393600000','1.691392678009487','1.623736970889107','6283.967446906994','6283.967446906994155','test','test','4.0'),('2019-09-10 11:59:59','2019-09-10 19:59:59','DLTETH','4h','0.000226730000000','0.000217660800000','1.676358076427180','1.609303753370093','7393.6315283693375','7393.631528369337502','test','test','4.0'),('2019-09-14 19:59:59','2019-09-14 23:59:59','DLTETH','4h','0.000331540000000','0.000318278400000','1.661457115747828','1.594998831117915','5011.3323150987135','5011.332315098713480','test','test','4.0'),('2019-09-15 03:59:59','2019-09-15 19:59:59','DLTETH','4h','0.000252000000000','0.000241920000000','1.646688608052291','1.580821063730199','6534.478603382108','6534.478603382108304','test','test','4.0'),('2019-09-19 11:59:59','2019-09-19 15:59:59','DLTETH','4h','0.000217850000000','0.000209136000000','1.632051375980715','1.566769320941486','7491.628992337458','7491.628992337457930','test','test','4.0'),('2019-09-20 07:59:59','2019-09-21 23:59:59','DLTETH','4h','0.000217550000000','0.000218220000000','1.617544252638664','1.622525887431898','7435.275810795974','7435.275810795974394','test','test','0.0'),('2019-09-22 11:59:59','2019-09-22 19:59:59','DLTETH','4h','0.000221190000000','0.000217550000000','1.618651282592716','1.592014044613433','7317.922521780895','7317.922521780895295','test','test','1.6'),('2019-09-24 11:59:59','2019-09-24 15:59:59','DLTETH','4h','0.000232200000000','0.000222912000000','1.612731896375098','1.548222620520094','6945.44313684366','6945.443136843659886','test','test','4.0'),('2019-09-25 15:59:59','2019-09-25 19:59:59','DLTETH','4h','0.000250200000000','0.000240192000000','1.598396501740653','1.534460641671027','6388.475226781185','6388.475226781184574','test','test','4.0'),('2019-09-26 03:59:59','2019-09-26 23:59:59','DLTETH','4h','0.000241250000000','0.000238890000000','1.584188532836291','1.568691393199012','6566.584592067527','6566.584592067527410','test','test','3.3'),('2019-09-27 15:59:59','2019-09-27 19:59:59','DLTETH','4h','0.000277400000000','0.000266304000000','1.580744724028007','1.517514935066887','5698.430872487407','5698.430872487407214','test','test','4.0'),('2019-10-01 11:59:59','2019-10-06 07:59:59','DLTETH','4h','0.000265230000000','0.000255930000000','1.566693659814425','1.511759259345873','5906.924781564772','5906.924781564772275','test','test','3.5'),('2019-10-06 11:59:59','2019-10-06 15:59:59','DLTETH','4h','0.000257020000000','0.000258500000000','1.554486015265858','1.563437222574992','6048.113046711765','6048.113046711764582','test','test','0.0'),('2019-10-07 23:59:59','2019-10-08 03:59:59','DLTETH','4h','0.000259580000000','0.000257370000000','1.556475172445665','1.543223727299256','5996.12902552456','5996.129025524560348','test','test','0.9'),('2019-10-08 15:59:59','2019-10-09 15:59:59','DLTETH','4h','0.000270590000000','0.000259766400000','1.553530406857574','1.491389190583271','5741.270582274195','5741.270582274194567','test','test','4.0'),('2019-10-15 07:59:59','2019-10-15 11:59:59','DLTETH','4h','0.000247680000000','0.000247750000000','1.539721247685507','1.540156407921852','6216.5748049317945','6216.574804931794461','test','test','0.0'),('2019-10-21 19:59:59','2019-10-22 03:59:59','DLTETH','4h','0.000236780000000','0.000241620000000','1.539817949960250','1.571293238742274','6503.158839261129','6503.158839261129287','test','test','0.5'),('2019-10-22 11:59:59','2019-10-22 23:59:59','DLTETH','4h','0.000247300000000','0.000237408000000','1.546812458578478','1.484939960235339','6254.8016925939255','6254.801692593925509','test','test','4.0'),('2019-10-23 03:59:59','2019-10-23 15:59:59','DLTETH','4h','0.000238460000000','0.000237110000000','1.533063014502225','1.524383843699667','6429.015409302292','6429.015409302292028','test','test','0.6'),('2019-10-24 19:59:59','2019-10-24 23:59:59','DLTETH','4h','0.000240820000000','0.000238580000000','1.531134309879434','1.516892382904391','6358.0031138586255','6358.003113858625511','test','test','0.9'),('2019-10-29 07:59:59','2019-10-29 11:59:59','DLTETH','4h','0.000231500000000','0.000226740000000','1.527969437218313','1.496552009481124','6600.299944787532','6600.299944787531786','test','test','2.1'),('2019-11-03 11:59:59','2019-11-04 15:59:59','DLTETH','4h','0.000234850000000','0.000225456000000','1.520987786610049','1.460148275145647','6476.422340259949','6476.422340259949124','test','test','4.0'),('2019-11-05 23:59:59','2019-11-06 03:59:59','DLTETH','4h','0.000232700000000','0.000230430000000','1.507467895173516','1.492762471357255','6478.160271480514','6478.160271480513984','test','test','1.0'),('2019-11-07 15:59:59','2019-11-08 11:59:59','DLTETH','4h','0.000231270000000','0.000225820000000','1.504200023214346','1.468752753241941','6504.086233468873','6504.086233468872706','test','test','2.4'),('2019-11-11 15:59:59','2019-11-20 19:59:59','DLTETH','4h','0.000227740000000','0.000240740000000','1.496322852109367','1.581736907951212','6570.3119878342295','6570.311987834229512','test','test','0.0'),('2019-11-22 07:59:59','2019-11-22 11:59:59','DLTETH','4h','0.000244110000000','0.000243130000000','1.515303753407555','1.509220439826221','6207.462838095757','6207.462838095757434','test','test','0.4'),('2019-11-23 11:59:59','2019-12-02 19:59:59','DLTETH','4h','0.000248580000000','0.000276990000000','1.513951905945037','1.686980201253986','6090.401102039733','6090.401102039732905','test','test','0.0'),('2019-12-02 23:59:59','2019-12-03 03:59:59','DLTETH','4h','0.000277940000000','0.000273240000000','1.552402638235914','1.526151316368933','5585.387631272627','5585.387631272627004','test','test','1.7'),('2019-12-06 15:59:59','2019-12-06 19:59:59','DLTETH','4h','0.000278520000000','0.000281940000000','1.546569011154363','1.565559625897103','5552.811328286525','5552.811328286525168','test','test','0.0'),('2019-12-06 23:59:59','2019-12-10 03:59:59','DLTETH','4h','0.000290060000000','0.000279470000000','1.550789147763860','1.494170320366703','5346.442624849549','5346.442624849549247','test','test','3.7'),('2019-12-16 11:59:59','2019-12-17 11:59:59','DLTETH','4h','0.000277130000000','0.000279830000000','1.538207186120048','1.553193508071927','5550.489611806906','5550.489611806906396','test','test','0.0'),('2019-12-17 15:59:59','2019-12-17 19:59:59','DLTETH','4h','0.000272770000000','0.000262850000000','1.541537479887132','1.485475406343559','5651.418703989193','5651.418703989193091','test','test','3.6'),('2019-12-19 11:59:59','2019-12-19 15:59:59','DLTETH','4h','0.000280070000000','0.000272020000000','1.529079241321894','1.485129200644059','5459.63238233975','5459.632382339749711','test','test','2.9'),('2019-12-20 11:59:59','2019-12-22 19:59:59','DLTETH','4h','0.000283350000000','0.000274050000000','1.519312565615708','1.469446298242403','5361.964233688753','5361.964233688752756','test','test','3.3'),('2019-12-23 11:59:59','2019-12-23 15:59:59','DLTETH','4h','0.000278560000000','0.000277340000000','1.508231172866085','1.501625622783888','5414.38531327572','5414.385313275720364','test','test','0.4'),('2019-12-23 19:59:59','2019-12-26 19:59:59','DLTETH','4h','0.000286790000000','0.000281680000000','1.506763272847819','1.479915892101446','5253.890557020184','5253.890557020184133','test','test','3.0'),('2019-12-27 03:59:59','2019-12-29 15:59:59','DLTETH','4h','0.000299520000000','0.000288100000000','1.500797188237513','1.443575286896460','5010.6743731220395','5010.674373122039469','test','test','3.8'),('2019-12-30 07:59:59','2019-12-30 11:59:59','DLTETH','4h','0.000291510000000','0.000291530000000','1.488081210161724','1.488183304855571','5104.734692332078','5104.734692332078339','test','test','0.0'),('2019-12-30 19:59:59','2019-12-31 19:59:59','DLTETH','4h','0.000293150000000','0.000296670000000','1.488103897871468','1.505972312405009','5076.2541288468965','5076.254128846896492','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:26:06
