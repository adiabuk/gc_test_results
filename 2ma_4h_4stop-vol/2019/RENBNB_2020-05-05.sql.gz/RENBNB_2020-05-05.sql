-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-05-23 11:59:59','2019-05-23 15:59:59','RENBNB','4h','0.001140000000000','0.001094400000000','3.111111111111111','2.986666666666667','2729.0448343079925','2729.044834307992460','test','test','4.0'),('2019-05-30 15:59:59','2019-05-30 19:59:59','RENBNB','4h','0.001030000000000','0.000990000000000','3.083456790123457','2.963710895361380','2993.6473690518997','2993.647369051899659','test','test','3.9'),('2019-05-30 23:59:59','2019-06-12 19:59:59','RENBNB','4h','0.001110000000000','0.001340000000000','3.056846591287439','3.690247236328980','2753.9158480067017','2753.915848006701708','test','test','0.0'),('2019-06-14 03:59:59','2019-06-14 15:59:59','RENBNB','4h','0.001380000000000','0.001324800000000','3.197602290185560','3.069698198578137','2317.103108830116','2317.103108830116071','test','test','4.0'),('2019-06-16 11:59:59','2019-06-16 15:59:59','RENBNB','4h','0.001610000000000','0.001545600000000','3.169179158717244','3.042411992368554','1968.4342600728219','1968.434260072821871','test','test','4.0'),('2019-06-16 19:59:59','2019-06-17 15:59:59','RENBNB','4h','0.001560000000000','0.001497600000000','3.141008677306424','3.015368330214167','2013.4671008374512','2013.467100837451198','test','test','4.0'),('2019-06-20 23:59:59','2019-06-21 07:59:59','RENBNB','4h','0.001410000000000','0.001360000000000','3.113088600174811','3.002695387402655','2207.8642554431285','2207.864255443128513','test','test','3.5'),('2019-06-22 03:59:59','2019-07-07 15:59:59','RENBNB','4h','0.001450000000000','0.002660000000000','3.088556775114332','5.665904152968361','2130.0391552512633','2130.039155251263310','test','test','0.0'),('2019-07-09 15:59:59','2019-07-13 03:59:59','RENBNB','4h','0.002890000000000','0.002979000000000','3.661300636859671','3.774053493842546','1266.8860335154573','1266.886033515457257','test','test','0.0'),('2019-07-19 15:59:59','2019-07-19 19:59:59','RENBNB','4h','0.002797000000000','0.002685120000000','3.686356827300310','3.538902554208298','1317.9681184484484','1317.968118448448422','test','test','4.0'),('2019-07-19 23:59:59','2019-07-20 15:59:59','RENBNB','4h','0.002821000000000','0.003119000000000','3.653589211057641','4.039540854054867','1295.1397416014324','1295.139741601432434','test','test','2.5'),('2019-07-20 19:59:59','2019-07-30 11:59:59','RENBNB','4h','0.003166000000000','0.003809000000000','3.739356242834802','4.498802251723866','1181.0979920514221','1181.097992051422125','test','test','3.3'),('2019-08-02 07:59:59','2019-08-03 23:59:59','RENBNB','4h','0.003874000000000','0.003943000000000','3.908122022587928','3.977729771570523','1008.8079562694704','1008.807956269470424','test','test','0.0'),('2019-08-04 15:59:59','2019-08-07 15:59:59','RENBNB','4h','0.004470000000000','0.004291200000000','3.923590411250727','3.766646794800698','877.76071840061','877.760718400610017','test','test','4.0'),('2019-08-09 19:59:59','2019-08-10 03:59:59','RENBNB','4h','0.004330000000000','0.004214000000000','3.888714052039610','3.784536031245939','898.0863861523349','898.086386152334853','test','test','2.7'),('2019-08-28 03:59:59','2019-08-28 07:59:59','RENBNB','4h','0.003257000000000','0.003126720000000','3.865563380752127','3.710940845522042','1186.8478295216846','1186.847829521684616','test','test','4.0'),('2019-08-30 23:59:59','2019-08-31 03:59:59','RENBNB','4h','0.003199000000000','0.003071040000000','3.831202817367663','3.677954704672956','1197.625138283108','1197.625138283108072','test','test','4.0'),('2019-09-19 15:59:59','2019-09-23 19:59:59','RENBNB','4h','0.002346000000000','0.002349000000000','3.797147681213284','3.802003368785168','1618.5625239613319','1618.562523961331863','test','test','0.0'),('2019-09-25 23:59:59','2019-09-26 03:59:59','RENBNB','4h','0.002406000000000','0.002371000000000','3.798226722895925','3.742974048207081','1578.6478482526704','1578.647848252670428','test','test','1.5'),('2019-09-26 15:59:59','2019-09-28 03:59:59','RENBNB','4h','0.002317000000000','0.002408000000000','3.785948350742849','3.934641186270514','1633.9872036007116','1633.987203600711609','test','test','0.0'),('2019-09-29 19:59:59','2019-09-30 03:59:59','RENBNB','4h','0.002709000000000','0.002600640000000','3.818991203082330','3.666231554959037','1409.742046172879','1409.742046172879100','test','test','4.0'),('2019-09-30 07:59:59','2019-10-16 11:59:59','RENBNB','4h','0.002455000000000','0.003018000000000','3.785044614610487','4.653060955965151','1541.7697004523366','1541.769700452336565','test','test','0.4'),('2019-10-22 15:59:59','2019-10-22 19:59:59','RENBNB','4h','0.003191000000000','0.003150000000000','3.977937134911523','3.926826065487715','1246.6114493611794','1246.611449361179439','test','test','1.3'),('2019-10-22 23:59:59','2019-10-23 07:59:59','RENBNB','4h','0.003140000000000','0.003079000000000','3.966579119484010','3.889521372258366','1263.2417577974554','1263.241757797455421','test','test','1.9'),('2019-10-24 11:59:59','2019-10-24 23:59:59','RENBNB','4h','0.003162000000000','0.003100000000000','3.949455175656089','3.872014878094205','1249.0370574497435','1249.037057449743543','test','test','2.0'),('2019-11-06 15:59:59','2019-11-08 03:59:59','RENBNB','4h','0.002875000000000','0.002760000000000','3.932246220642338','3.774956371816644','1367.7378158755957','1367.737815875595743','test','test','4.0'),('2019-11-08 19:59:59','2019-11-10 19:59:59','RENBNB','4h','0.002813000000000','0.002726000000000','3.897292920903295','3.776758088298039','1385.4578460374314','1385.457846037431409','test','test','3.1'),('2019-11-12 11:59:59','2019-11-12 19:59:59','RENBNB','4h','0.002950000000000','0.002832000000000','3.870507402546572','3.715687106444709','1312.0364076429057','1312.036407642905715','test','test','4.0'),('2019-11-14 19:59:59','2019-11-15 07:59:59','RENBNB','4h','0.002869000000000','0.002810000000000','3.836102892301712','3.757214753352322','1337.0871008371253','1337.087100837125263','test','test','2.1'),('2019-11-17 07:59:59','2019-11-17 11:59:59','RENBNB','4h','0.002798000000000','0.002764000000000','3.818572194757403','3.772170674163496','1364.7506057031462','1364.750605703146221','test','test','1.2'),('2019-11-18 03:59:59','2019-11-18 07:59:59','RENBNB','4h','0.002791000000000','0.002761000000000','3.808260745736535','3.767326377276450','1364.4789486694858','1364.478948669485817','test','test','1.1'),('2019-11-19 19:59:59','2019-11-19 23:59:59','RENBNB','4h','0.002783000000000','0.002819000000000','3.799164219412072','3.848308995516576','1365.1326695695552','1365.132669569555219','test','test','0.0'),('2019-11-22 11:59:59','2019-11-24 07:59:59','RENBNB','4h','0.002800000000000','0.002873000000000','3.810085280768628','3.909419647017238','1360.744743131653','1360.744743131652967','test','test','0.0'),('2019-11-24 15:59:59','2019-11-24 19:59:59','RENBNB','4h','0.002820000000000','0.002839000000000','3.832159584379431','3.857979099309647','1358.9218384324224','1358.921838432422419','test','test','0.0'),('2019-11-25 03:59:59','2019-11-25 07:59:59','RENBNB','4h','0.002823000000000','0.002710080000000','3.837897254363924','3.684381364189366','1359.5101857470506','1359.510185747050627','test','test','4.0'),('2019-12-07 07:59:59','2019-12-07 15:59:59','RENBNB','4h','0.002567000000000','0.002518000000000','3.803782612102910','3.731174373695024','1481.8007838344022','1481.800783834402182','test','test','1.9'),('2019-12-14 15:59:59','2019-12-15 03:59:59','RENBNB','4h','0.002457000000000','0.002448000000000','3.787647448012269','3.773773281536033','1541.5740529150464','1541.574052915046423','test','test','0.4'),('2019-12-18 19:59:59','2019-12-18 23:59:59','RENBNB','4h','0.002455000000000','0.002361000000000','3.784564299906438','3.639656338932423','1541.5740529150462','1541.574052915046195','test','test','3.8'),('2019-12-22 07:59:59','2019-12-22 19:59:59','RENBNB','4h','0.002502000000000','0.002404000000000','3.752362530801102','3.605387499618645','1499.745216147523','1499.745216147523024','test','test','3.9'),('2019-12-23 15:59:59','2019-12-23 19:59:59','RENBNB','4h','0.002421000000000','0.002431000000000','3.719701412760557','3.735065730863657','1536.4318103100193','1536.431810310019273','test','test','0.0'),('2019-12-24 07:59:59','2019-12-25 19:59:59','RENBNB','4h','0.002470000000000','0.002471000000000','3.723115705672356','3.724623039966151','1507.3342937944763','1507.334293794476253','test','test','0.0'),('2019-12-26 19:59:59','2019-12-27 15:59:59','RENBNB','4h','0.002475000000000','0.002478000000000','3.723450668848755','3.727963942386754','1504.4245126661635','1504.424512666163537','test','test','0.4'),('2020-01-02 03:59:59','2020-01-05 15:59:59','RENBNB','4h','0.002390000000000','0.002452000000000','3.724453618523865','3.821071243774275','1558.3487943614498','1558.348794361449791','test','test','0.0'),('2020-01-06 07:59:59','2020-01-07 23:59:59','RENBNB','4h','0.002678000000000','0.002572000000000','3.745924201912846','3.597653863823690','1398.7767744260066','1398.776774426006568','test','test','4.0'),('2020-01-08 07:59:59','2020-01-13 07:59:59','RENBNB','4h','0.002631000000000','0.002920000000000','3.712975237893033','4.120823905225259','1411.241063433308','1411.241063433308000','test','test','2.2'),('2020-01-14 03:59:59','2020-01-14 11:59:59','RENBNB','4h','0.002963000000000','0.002844480000000','3.803608275077972','3.651463944074853','1283.7017465669835','1283.701746566983502','test','test','4.0'),('2020-02-02 23:59:59','2020-02-07 11:59:59','RENBNB','4h','0.002507000000000','0.002628000000000','3.769798423743946','3.951747210849258','1503.7089843414224','1503.708984341422365','test','test','0.9'),('2020-02-08 11:59:59','2020-02-08 19:59:59','RENBNB','4h','0.002907000000000','0.002790720000000','3.810231487545126','3.657822228043321','1310.7091460423553','1310.709146042355314','test','test','4.0'),('2020-02-14 11:59:59','2020-02-14 19:59:59','RENBNB','4h','0.002590000000000','0.002551000000000','3.776362763211392','3.719498613495082','1458.0551209310395','1458.055120931039482','test','test','1.5'),('2020-02-15 15:59:59','2020-02-15 19:59:59','RENBNB','4h','0.002507000000000','0.002538000000000','3.763726285496656','3.810266179732952','1501.286910848287','1501.286910848287107','test','test','0.0'),('2020-02-16 03:59:59','2020-02-16 15:59:59','RENBNB','4h','0.002542000000000','0.002480000000000','3.774068484215833','3.682018033381300','1484.684690879557','1484.684690879556911','test','test','2.4');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 17:20:26
