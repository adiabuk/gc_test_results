-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-30 23:59:59','2018-05-31 19:59:59','LTCETH','4h','0.209930000000000','0.206900000000000','1.297777777777778','1.279046454638319','6.181954831504681','6.181954831504681','test','test','1.5'),('2018-06-01 19:59:59','2018-06-01 23:59:59','LTCETH','4h','0.207230000000000','0.207420000000000','1.293615261524565','1.294801320008808','6.242413074962914','6.242413074962914','test','test','0.0'),('2018-06-02 15:59:59','2018-06-03 03:59:59','LTCETH','4h','0.207430000000000','0.206420000000000','1.293878830076619','1.287578788528254','6.237664899371444','6.237664899371444','test','test','0.5'),('2018-06-11 03:59:59','2018-06-11 07:59:59','LTCETH','4h','0.202240000000000','0.201430000000000','1.292478820843649','1.287302259110642','6.3908169543297495','6.390816954329749','test','test','0.4'),('2018-06-11 19:59:59','2018-06-11 23:59:59','LTCETH','4h','0.203090000000000','0.201590000000000','1.291328473791869','1.281790866274572','6.358405011531189','6.358405011531189','test','test','0.7'),('2018-06-12 19:59:59','2018-06-12 23:59:59','LTCETH','4h','0.202240000000000','0.202100000000000','1.289209005454692','1.288316554600441','6.374648958933406','6.374648958933406','test','test','0.1'),('2018-06-14 15:59:59','2018-06-14 19:59:59','LTCETH','4h','0.203520000000000','0.195379200000000','1.289010683042636','1.237450255720931','6.333582365578991','6.333582365578991','test','test','4.0'),('2018-06-27 19:59:59','2018-06-27 23:59:59','LTCETH','4h','0.184770000000000','0.182540000000000','1.277552810304480','1.262133950278616','6.914287007114141','6.914287007114141','test','test','1.2'),('2018-07-03 03:59:59','2018-07-05 03:59:59','LTCETH','4h','0.182600000000000','0.180830000000000','1.274126396965399','1.261775883697991','6.977691111530114','6.977691111530114','test','test','1.0'),('2018-07-11 11:59:59','2018-07-11 15:59:59','LTCETH','4h','0.179540000000000','0.176820000000000','1.271381838461530','1.252120623130042','7.081329165988248','7.081329165988248','test','test','1.5'),('2018-07-13 23:59:59','2018-07-14 03:59:59','LTCETH','4h','0.177240000000000','0.176370000000000','1.267101568387866','1.260881875516632','7.149072265785748','7.149072265785748','test','test','0.5'),('2018-07-15 03:59:59','2018-07-15 07:59:59','LTCETH','4h','0.177350000000000','0.176580000000000','1.265719414416481','1.260224043967647','7.136844738745311','7.136844738745311','test','test','0.4'),('2018-07-17 19:59:59','2018-07-21 03:59:59','LTCETH','4h','0.178010000000000','0.177600000000000','1.264498220983407','1.261585776342077','7.103523515439619','7.103523515439619','test','test','0.2'),('2018-07-22 11:59:59','2018-07-22 15:59:59','LTCETH','4h','0.179150000000000','0.177460000000000','1.263851011063111','1.251928553855761','7.0547084067156645','7.054708406715664','test','test','0.9'),('2018-07-23 03:59:59','2018-07-26 07:59:59','LTCETH','4h','0.182220000000000','0.180880000000000','1.261201576128145','1.251927017287119','6.921312567929671','6.921312567929671','test','test','0.8'),('2018-07-31 07:59:59','2018-07-31 11:59:59','LTCETH','4h','0.180590000000000','0.180830000000000','1.259140563052361','1.260813932204211','6.972371466041094','6.972371466041094','test','test','0.0'),('2018-07-31 23:59:59','2018-08-01 03:59:59','LTCETH','4h','0.182380000000000','0.184150000000000','1.259512422863883','1.271736005430333','6.905978851101454','6.905978851101454','test','test','0.0'),('2018-08-01 19:59:59','2018-08-04 19:59:59','LTCETH','4h','0.185150000000000','0.179560000000000','1.262228774545316','1.224119896069981','6.81733067537303','6.817330675373030','test','test','3.0'),('2018-08-06 03:59:59','2018-08-06 11:59:59','LTCETH','4h','0.184350000000000','0.181220000000000','1.253760134884131','1.232473076450785','6.800977135254303','6.800977135254303','test','test','1.7'),('2018-08-07 19:59:59','2018-08-07 23:59:59','LTCETH','4h','0.183210000000000','0.178030000000000','1.249029677454499','1.213715154616148','6.817475451419129','6.817475451419129','test','test','2.8'),('2018-08-11 15:59:59','2018-08-18 15:59:59','LTCETH','4h','0.180270000000000','0.195540000000000','1.241182005712643','1.346317908676153','6.885127895449286','6.885127895449286','test','test','0.0'),('2018-08-18 23:59:59','2018-08-19 15:59:59','LTCETH','4h','0.193400000000000','0.193950000000000','1.264545539704534','1.268141713679909','6.53849813704516','6.538498137045160','test','test','1.6'),('2018-08-20 11:59:59','2018-09-13 23:59:59','LTCETH','4h','0.193620000000000','0.258530000000000','1.265344689476839','1.689544275232141','6.535196206367315','6.535196206367315','test','test','0.0'),('2018-09-14 19:59:59','2018-09-15 15:59:59','LTCETH','4h','0.264460000000000','0.259040000000000','1.359611264089129','1.331746584926446','5.14108471636213','5.141084716362130','test','test','2.0'),('2018-09-17 19:59:59','2018-09-18 03:59:59','LTCETH','4h','0.264870000000000','0.258880000000000','1.353419113164088','1.322811719016571','5.109748605595531','5.109748605595531','test','test','2.3'),('2018-09-25 07:59:59','2018-09-29 11:59:59','LTCETH','4h','0.264830000000000','0.266050000000000','1.346617470020195','1.352820971562409','5.08483732968393','5.084837329683930','test','test','1.1'),('2018-09-29 23:59:59','2018-09-30 03:59:59','LTCETH','4h','0.266250000000000','0.264200000000000','1.347996025918465','1.337617089380877','5.062895871994235','5.062895871994235','test','test','0.8'),('2018-10-11 11:59:59','2018-10-11 15:59:59','LTCETH','4h','0.261990000000000','0.262340000000000','1.345689595576779','1.347487341133678','5.136415876853235','5.136415876853235','test','test','0.0'),('2018-10-11 19:59:59','2018-10-15 07:59:59','LTCETH','4h','0.260360000000000','0.261250000000000','1.346089094589423','1.350690489942721','5.170107138536731','5.170107138536731','test','test','0.0'),('2018-10-15 19:59:59','2018-10-15 23:59:59','LTCETH','4h','0.268080000000000','0.261860000000000','1.347111626890156','1.315855903526769','5.025035910512369','5.025035910512369','test','test','2.3'),('2018-10-23 15:59:59','2018-10-23 19:59:59','LTCETH','4h','0.261240000000000','0.258220000000000','1.340165910587181','1.324673256131610','5.130018031645924','5.130018031645924','test','test','1.2'),('2018-11-02 15:59:59','2018-11-02 23:59:59','LTCETH','4h','0.257180000000000','0.255880000000000','1.336723098485943','1.329966196596092','5.197616838346462','5.197616838346462','test','test','0.6'),('2018-11-03 03:59:59','2018-11-03 07:59:59','LTCETH','4h','0.255860000000000','0.255760000000000','1.335221564732643','1.334699708418748','5.218563138953502','5.218563138953502','test','test','0.0'),('2018-11-03 11:59:59','2018-11-03 15:59:59','LTCETH','4h','0.255890000000000','0.255230000000000','1.335105596662888','1.331662047896631','5.21749813069244','5.217498130692440','test','test','0.3'),('2018-11-04 07:59:59','2018-11-04 19:59:59','LTCETH','4h','0.257430000000000','0.255040000000000','1.334340363603720','1.321952244623753','5.1833133807393095','5.183313380739309','test','test','0.9'),('2018-11-05 03:59:59','2018-11-05 07:59:59','LTCETH','4h','0.256190000000000','0.257530000000000','1.331587448274839','1.338552307093249','5.197655834633823','5.197655834633823','test','test','0.0'),('2018-11-20 03:59:59','2018-11-20 11:59:59','LTCETH','4h','0.251000000000000','0.243950000000000','1.333135194678930','1.295690560724801','5.311295596330398','5.311295596330398','test','test','2.8'),('2018-11-20 15:59:59','2018-11-20 19:59:59','LTCETH','4h','0.246030000000000','0.247730000000000','1.324814164911346','1.333968268396081','5.384766755726316','5.384766755726316','test','test','0.0'),('2018-11-20 23:59:59','2018-12-07 19:59:59','LTCETH','4h','0.252840000000000','0.263770000000000','1.326848410130176','1.384206633206916','5.247778872528776','5.247778872528776','test','test','1.8'),('2018-12-14 23:59:59','2018-12-19 19:59:59','LTCETH','4h','0.278400000000000','0.289990000000000','1.339594681925007','1.395363009380147','4.811762506914537','4.811762506914537','test','test','0.0'),('2018-12-19 23:59:59','2018-12-20 03:59:59','LTCETH','4h','0.292510000000000','0.290620000000000','1.351987643581704','1.343252022076903','4.622021960212316','4.622021960212316','test','test','0.6'),('2018-12-20 11:59:59','2018-12-20 15:59:59','LTCETH','4h','0.289960000000000','0.287880000000000','1.350046394358415','1.340361967195132','4.655974597732154','4.655974597732154','test','test','0.7'),('2019-01-06 07:59:59','2019-01-14 15:59:59','LTCETH','4h','0.232610000000000','0.251430000000000','1.347894299433241','1.456949674160611','5.794653279881524','5.794653279881524','test','test','0.0'),('2019-01-15 23:59:59','2019-01-16 15:59:59','LTCETH','4h','0.258350000000000','0.256340000000000','1.372128827150435','1.361453468363625','5.311123774532357','5.311123774532357','test','test','0.8'),('2019-01-16 19:59:59','2019-01-17 11:59:59','LTCETH','4h','0.257580000000000','0.254460000000000','1.369756525197810','1.353165018253882','5.317790687156652','5.317790687156652','test','test','1.5'),('2019-01-17 15:59:59','2019-02-13 15:59:59','LTCETH','4h','0.255040000000000','0.338760000000000','1.366069523654715','1.814498556435349','5.356295183715164','5.356295183715164','test','test','0.0'),('2019-02-15 11:59:59','2019-02-17 11:59:59','LTCETH','4h','0.346280000000000','0.342220000000000','1.465720419828189','1.448535410862894','4.232760828890463','4.232760828890463','test','test','1.2'),('2019-02-20 11:59:59','2019-02-21 11:59:59','LTCETH','4h','0.346600000000000','0.337550000000000','1.461901528947013','1.423730124339481','4.217834763263164','4.217834763263164','test','test','2.6'),('2019-02-27 23:59:59','2019-02-28 03:59:59','LTCETH','4h','0.335070000000000','0.334360000000000','1.453418994589783','1.450339257561226','4.33765778670064','4.337657786700640','test','test','0.2'),('2019-02-28 15:59:59','2019-03-20 11:59:59','LTCETH','4h','0.336440000000000','0.432480000000000','1.452734608583437','1.867431528712890','4.3179604345007645','4.317960434500764','test','test','0.0'),('2019-03-20 19:59:59','2019-03-29 07:59:59','LTCETH','4h','0.435300000000000','0.433750000000000','1.544889479723316','1.539388494900042','3.549022466628338','3.549022466628338','test','test','1.4'),('2019-03-29 11:59:59','2019-03-29 15:59:59','LTCETH','4h','0.435560000000000','0.432430000000000','1.543667038651477','1.532574013968358','3.5440973428493825','3.544097342849382','test','test','0.7'),('2019-04-02 07:59:59','2019-04-08 07:59:59','LTCETH','4h','0.448070000000000','0.493540000000000','1.541201922055228','1.697602599172310','3.439645417133993','3.439645417133993','test','test','0.4'),('2019-04-10 23:59:59','2019-04-11 07:59:59','LTCETH','4h','0.498150000000000','0.493730000000000','1.575957628081247','1.561974424796857','3.1636206525770283','3.163620652577028','test','test','0.9'),('2019-04-14 23:59:59','2019-04-15 11:59:59','LTCETH','4h','0.499060000000000','0.485620000000000','1.572850249573604','1.530492402111837','3.1516255551909675','3.151625555190968','test','test','2.7'),('2019-04-15 23:59:59','2019-04-16 03:59:59','LTCETH','4h','0.488330000000000','0.485630000000000','1.563437394582101','1.554793074213965','3.201600136346529','3.201600136346529','test','test','0.6'),('2019-04-26 03:59:59','2019-04-27 07:59:59','LTCETH','4h','0.471700000000000','0.464160000000000','1.561516434500293','1.536556006439805','3.310401599534222','3.310401599534222','test','test','1.6'),('2019-04-30 23:59:59','2019-05-01 03:59:59','LTCETH','4h','0.459000000000000','0.454640000000000','1.555969672709073','1.541189655774407','3.389912140978373','3.389912140978373','test','test','0.9'),('2019-05-02 15:59:59','2019-05-02 19:59:59','LTCETH','4h','0.456460000000000','0.454490000000000','1.552685224501370','1.545984111824974','3.4015800387796733','3.401580038779673','test','test','0.4'),('2019-05-03 07:59:59','2019-05-03 11:59:59','LTCETH','4h','0.456860000000000','0.470640000000000','1.551196088351059','1.597983905401091','3.395342311323073','3.395342311323073','test','test','0.0'),('2019-05-03 15:59:59','2019-05-06 03:59:59','LTCETH','4h','0.468990000000000','0.450230400000000','1.561593381028844','1.499129645787690','3.32969440932396','3.329694409323960','test','test','4.0'),('2019-05-11 11:59:59','2019-05-12 03:59:59','LTCETH','4h','0.457700000000000','0.457310000000000','1.547712550975255','1.546393765974424','3.3815000021307724','3.381500002130772','test','test','0.7'),('2019-05-12 11:59:59','2019-05-13 07:59:59','LTCETH','4h','0.460670000000000','0.452100000000000','1.547419487641736','1.518632318932921','3.359062859838358','3.359062859838358','test','test','2.3'),('2019-05-24 11:59:59','2019-05-30 19:59:59','LTCETH','4h','0.395420000000000','0.421150000000000','1.541022339039777','1.641296742922973','3.8971785419042475','3.897178541904248','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:42:22
