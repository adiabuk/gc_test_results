-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-25 15:59:59','2018-05-27 03:59:59','XLMETH','4h','0.000490070000000','0.000482880000000','1.297777777777778','1.278737595309514','2648.147770273181','2648.147770273180868','test','test','1.6'),('2018-05-27 15:59:59','2018-05-29 03:59:59','XLMETH','4h','0.000478980000000','0.000474530000000','1.293546626118163','1.281528833128423','2700.627638143896','2700.627638143896093','test','test','0.9'),('2018-05-29 11:59:59','2018-06-03 11:59:59','XLMETH','4h','0.000499910000000','0.000491920000000','1.290876005453777','1.270244093142409','2582.2168099333417','2582.216809933341665','test','test','2.4'),('2018-06-06 23:59:59','2018-06-07 03:59:59','XLMETH','4h','0.000492990000000','0.000489040000000','1.286291136051251','1.275984943253421','2609.1627336279653','2609.162733627965281','test','test','0.8'),('2018-06-07 11:59:59','2018-06-07 15:59:59','XLMETH','4h','0.000492340000000','0.000488080000000','1.284000870985066','1.272890980034917','2607.9556221007156','2607.955622100715573','test','test','0.9'),('2018-06-28 11:59:59','2018-06-28 15:59:59','XLMETH','4h','0.000438360000000','0.000438610000000','1.281532006329478','1.282262873656749','2923.4693090826663','2923.469309082666314','test','test','0.0'),('2018-06-30 03:59:59','2018-06-30 07:59:59','XLMETH','4h','0.000439830000000','0.000435840000000','1.281694421291093','1.270067290943114','2914.067756385634','2914.067756385633857','test','test','0.9'),('2018-07-02 11:59:59','2018-07-05 15:59:59','XLMETH','4h','0.000448450000000','0.000437130000000','1.279110614547098','1.246822662363637','2852.292595712115','2852.292595712115144','test','test','2.5'),('2018-07-10 11:59:59','2018-07-10 15:59:59','XLMETH','4h','0.000439750000000','0.000437690000000','1.271935514061884','1.265977157816364','2892.405944427253','2892.405944427252962','test','test','0.5'),('2018-07-13 23:59:59','2018-07-30 19:59:59','XLMETH','4h','0.000475090000000','0.000635750000000','1.270611434896213','1.700290933792055','2674.464701206536','2674.464701206536120','test','test','3.0'),('2018-07-30 23:59:59','2018-07-31 03:59:59','XLMETH','4h','0.000646140000000','0.000625050000000','1.366095767984178','1.321506422413889','2114.2411365712974','2114.241136571297375','test','test','3.3'),('2018-07-31 15:59:59','2018-07-31 23:59:59','XLMETH','4h','0.000641060000000','0.000641670000000','1.356187024524114','1.357477502927009','2115.538365401232','2115.538365401232113','test','test','0.0'),('2018-08-01 03:59:59','2018-08-02 15:59:59','XLMETH','4h','0.000641000000000','0.000642600000000','1.356473797502535','1.359859691536863','2116.1837714548133','2116.183771454813268','test','test','0.1'),('2018-08-02 19:59:59','2018-08-02 23:59:59','XLMETH','4h','0.000644790000000','0.000631250000000','1.357226218399052','1.328725709710761','2104.912015383384','2104.912015383384187','test','test','2.1'),('2018-08-09 23:59:59','2018-08-10 03:59:59','XLMETH','4h','0.000609120000000','0.000610330000000','1.350892772023877','1.353576283079414','2217.777731849023','2217.777731849022985','test','test','0.0'),('2018-08-10 19:59:59','2018-08-29 15:59:59','XLMETH','4h','0.000646550000000','0.000778680000000','1.351489107813996','1.627681599988559','2090.3087275755875','2090.308727575587454','test','test','0.0'),('2018-08-30 19:59:59','2018-08-30 23:59:59','XLMETH','4h','0.000778840000000','0.000783180000000','1.412865217186121','1.420738252780836','1814.0635010863864','1814.063501086386395','test','test','0.0'),('2018-08-31 15:59:59','2018-09-01 15:59:59','XLMETH','4h','0.000779680000000','0.000777700000000','1.414614780651613','1.411022361626256','1814.3530431094975','1814.353043109497548','test','test','0.3'),('2018-09-01 19:59:59','2018-09-01 23:59:59','XLMETH','4h','0.000779500000000','0.000778990000000','1.413816465312645','1.412891453898521','1813.7478708308468','1813.747870830846750','test','test','0.1'),('2018-09-04 15:59:59','2018-09-14 03:59:59','XLMETH','4h','0.000777020000000','0.000947330000000','1.413610907220618','1.723451160507204','1819.2722287979946','1819.272228797994558','test','test','0.0'),('2018-09-17 15:59:59','2018-09-22 03:59:59','XLMETH','4h','0.000966740000000','0.000984750000000','1.482464296839859','1.510082045134215','1533.4674233401524','1533.467423340152436','test','test','0.0'),('2018-09-22 07:59:59','2018-09-22 15:59:59','XLMETH','4h','0.001006860000000','0.000985480000000','1.488601574238605','1.456992113482173','1478.4593431446322','1478.459343144632157','test','test','2.1'),('2018-09-23 03:59:59','2018-09-29 11:59:59','XLMETH','4h','0.001069350000000','0.001101170000000','1.481577249626064','1.525663646112810','1385.4932899668627','1385.493289966862676','test','test','0.0'),('2018-09-30 23:59:59','2018-10-02 23:59:59','XLMETH','4h','0.001113670000000','0.001096170000000','1.491374226623119','1.467939053756916','1339.1527352116148','1339.152735211614754','test','test','1.6'),('2018-10-05 07:59:59','2018-10-05 11:59:59','XLMETH','4h','0.001115190000000','0.001094440000000','1.486166410430630','1.458513765575102','1332.657583398909','1332.657583398909082','test','test','1.9'),('2018-10-11 19:59:59','2018-10-11 23:59:59','XLMETH','4h','0.001095870000000','0.001078980000000','1.480021378240512','1.457210678907122','1350.5446615387882','1350.544661538788205','test','test','1.5'),('2018-10-12 07:59:59','2018-10-12 23:59:59','XLMETH','4h','0.001095030000000','0.001097110000000','1.474952333944203','1.477753993126695','1346.9515300441112','1346.951530044111223','test','test','0.0'),('2018-10-16 23:59:59','2018-10-25 11:59:59','XLMETH','4h','0.001100650000000','0.001165150000000','1.475574924873646','1.562046176092790','1340.6395537851688','1340.639553785168800','test','test','0.0'),('2018-11-02 23:59:59','2018-11-04 19:59:59','XLMETH','4h','0.001180130000000','0.001161000000000','1.494790758477900','1.470560082866160','1266.6322849837732','1266.632284983773161','test','test','1.6'),('2018-11-05 15:59:59','2018-11-07 15:59:59','XLMETH','4h','0.001170000000000','0.001173260000000','1.489406163897513','1.493556133208885','1272.9967212799259','1272.996721279925850','test','test','0.0'),('2018-11-08 15:59:59','2018-11-14 01:59:59','XLMETH','4h','0.001220630000000','0.001233810000000','1.490328379300040','1.506420502252265','1220.9501481202662','1220.950148120266249','test','test','1.0'),('2018-11-14 19:59:59','2018-11-24 23:59:59','XLMETH','4h','0.001265520000000','0.001340830000000','1.493904406622757','1.582805365013584','1180.4668489022356','1180.466848902235597','test','test','0.0'),('2018-11-29 11:59:59','2018-11-29 23:59:59','XLMETH','4h','0.001403520000000','0.001399620000000','1.513660175154052','1.509454125590739','1078.474247003286','1078.474247003286109','test','test','1.0'),('2018-11-30 07:59:59','2018-11-30 11:59:59','XLMETH','4h','0.001443690000000','0.001385942400000','1.512725497473316','1.452216477574383','1047.8187820607718','1047.818782060771809','test','test','4.0'),('2018-12-01 07:59:59','2018-12-02 07:59:59','XLMETH','4h','0.001410930000000','0.001390290000000','1.499279048606886','1.477346621368649','1062.6175987518066','1062.617598751806554','test','test','1.5'),('2018-12-03 15:59:59','2018-12-03 19:59:59','XLMETH','4h','0.001392430000000','0.001385320000000','1.494405175887278','1.486774472153116','1073.2354056485985','1073.235405648598544','test','test','0.5'),('2019-01-08 15:59:59','2019-01-08 19:59:59','XLMETH','4h','0.000826140000000','0.000821090000000','1.492709463946353','1.483584881196542','1806.8480692695587','1806.848069269558664','test','test','0.6'),('2019-01-10 03:59:59','2019-01-10 19:59:59','XLMETH','4h','0.000845590000000','0.000838510000000','1.490681778890840','1.478200520840784','1762.8895550927039','1762.889555092703858','test','test','0.8'),('2019-01-11 15:59:59','2019-01-12 03:59:59','XLMETH','4h','0.000838510000000','0.000829270000000','1.487908165990827','1.471512092653890','1774.4668113568441','1774.466811356844119','test','test','1.1'),('2019-01-12 07:59:59','2019-01-14 15:59:59','XLMETH','4h','0.000830940000000','0.000841350000000','1.484264594138174','1.502859431821976','1786.247616119304','1786.247616119303984','test','test','0.0'),('2019-01-15 23:59:59','2019-01-19 19:59:59','XLMETH','4h','0.000871000000000','0.000857130000000','1.488396780290131','1.464695215028794','1708.8367167510112','1708.836716751011181','test','test','1.6'),('2019-01-20 03:59:59','2019-01-22 19:59:59','XLMETH','4h','0.000876270000000','0.000868190000000','1.483129765787611','1.469453971217942','1692.548832879833','1692.548832879833071','test','test','0.9'),('2019-01-23 03:59:59','2019-01-23 07:59:59','XLMETH','4h','0.000868160000000','0.000862540000000','1.480090700327685','1.470509390735166','1704.8593580995262','1704.859358099526162','test','test','0.6'),('2019-01-23 19:59:59','2019-01-23 23:59:59','XLMETH','4h','0.000868370000000','0.000864010000000','1.477961520418236','1.470540821604339','1701.9951408020038','1701.995140802003789','test','test','0.5'),('2019-01-26 07:59:59','2019-01-26 15:59:59','XLMETH','4h','0.000877000000000','0.000868340000000','1.476312476237370','1.461734521796987','1683.3665635545838','1683.366563554583763','test','test','1.0'),('2019-02-25 19:59:59','2019-02-25 23:59:59','XLMETH','4h','0.000624170000000','0.000625000000000','1.473072930806174','1.475031773000719','2360.05083680115','2360.050836801150126','test','test','0.0'),('2019-02-27 23:59:59','2019-02-28 03:59:59','XLMETH','4h','0.000623190000000','0.000616450000000','1.473508229071628','1.457571764327420','2364.4606445411964','2364.460644541196416','test','test','1.1'),('2019-03-01 23:59:59','2019-03-03 11:59:59','XLMETH','4h','0.000626160000000','0.000623630000000','1.469966792461804','1.464027390416116','2347.589741378888','2347.589741378887993','test','test','0.4'),('2019-03-03 15:59:59','2019-03-05 15:59:59','XLMETH','4h','0.000660150000000','0.000633744000000','1.468646925340540','1.409901048326919','2224.716996653094','2224.716996653094156','test','test','4.0'),('2019-03-08 07:59:59','2019-03-21 15:59:59','XLMETH','4h','0.000639150000000','0.000772780000000','1.455592286004180','1.759919591298303','2277.3876022908235','2277.387602290823452','test','test','0.3'),('2019-03-22 15:59:59','2019-03-24 03:59:59','XLMETH','4h','0.000796010000000','0.000774900000000','1.523220576069541','1.482825120785276','1913.5696487098664','1913.569648709866442','test','test','2.7'),('2019-04-01 03:59:59','2019-04-02 07:59:59','XLMETH','4h','0.000771150000000','0.000775680000000','1.514243808228593','1.523138996520463','1963.6177244746068','1963.617724474606803','test','test','0.3'),('2019-04-05 07:59:59','2019-04-05 15:59:59','XLMETH','4h','0.000772350000000','0.000766430000000','1.516220516737897','1.504598809663270','1963.1261950383857','1963.126195038385731','test','test','0.8'),('2019-05-15 23:59:59','2019-05-16 07:59:59','XLMETH','4h','0.000569580000000','0.000566480000000','1.513637915165758','1.505399779105830','2657.4632451380985','2657.463245138098500','test','test','0.8'),('2019-05-16 11:59:59','2019-05-16 15:59:59','XLMETH','4h','0.000559750000000','0.000546420000000','1.511807218263552','1.475804734620045','2700.861488635198','2700.861488635197929','test','test','2.4');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:11:14
