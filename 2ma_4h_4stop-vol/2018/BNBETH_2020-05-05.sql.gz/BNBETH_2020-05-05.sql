-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-09 15:59:59','2018-02-11 03:59:59','BNBETH','4h','0.011279000000000','0.010827840000000','1.297777777777778','1.245866666666667','115.06142191486636','115.061421914866358','test','test','4.0'),('2018-02-14 15:59:59','2018-02-20 07:59:59','BNBETH','4h','0.010883000000000','0.011438000000000','1.286241975308642','1.351836415839405','118.18818113651034','118.188181136510337','test','test','0.0'),('2018-02-23 23:59:59','2018-02-24 03:59:59','BNBETH','4h','0.011455000000000','0.011230000000000','1.300818517648812','1.275267739257631','113.55901507191722','113.559015071917216','test','test','2.0'),('2018-02-26 15:59:59','2018-02-26 19:59:59','BNBETH','4h','0.011426000000000','0.011364000000000','1.295140566895216','1.288112848083077','113.35030342160124','113.350303421601240','test','test','0.5'),('2018-02-27 03:59:59','2018-03-06 07:59:59','BNBETH','4h','0.011464000000000','0.011729000000000','1.293578851603629','1.323481014520147','112.83835062836961','112.838350628369611','test','test','0.0'),('2018-03-07 07:59:59','2018-03-07 19:59:59','BNBETH','4h','0.011924000000000','0.011885000000000','1.300223776696189','1.295971115903573','109.04258442604737','109.042584426047370','test','test','0.3'),('2018-03-07 23:59:59','2018-03-08 03:59:59','BNBETH','4h','0.012088000000000','0.011604480000000','1.299278740964496','1.247307591325916','107.48500504338983','107.485005043389833','test','test','4.0'),('2018-03-08 23:59:59','2018-03-09 03:59:59','BNBETH','4h','0.011859000000000','0.011402000000000','1.287729596600367','1.238105477733147','108.58669336372101','108.586693363721011','test','test','3.9'),('2018-03-13 07:59:59','2018-03-13 11:59:59','BNBETH','4h','0.011558000000000','0.011523000000000','1.276702014629874','1.272835898475518','110.46046155302597','110.460461553025965','test','test','0.3'),('2018-03-13 15:59:59','2018-04-07 19:59:59','BNBETH','4h','0.014000000000000','0.031920000000000','1.275842877706684','2.908921761171239','91.13163412190599','91.131634121905989','test','test','0.0'),('2018-04-08 11:59:59','2018-04-09 03:59:59','BNBETH','4h','0.031003000000000','0.029762880000000','1.638749296254363','1.573199324404188','52.8577652567288','52.857765256728797','test','test','4.0'),('2018-04-10 03:59:59','2018-04-10 15:59:59','BNBETH','4h','0.030897000000000','0.029675000000000','1.624182635843213','1.559944969370727','52.56764850448952','52.567648504489519','test','test','4.0'),('2018-05-09 23:59:59','2018-05-10 03:59:59','BNBETH','4h','0.019473000000000','0.019184000000000','1.609907598849327','1.586014860387485','82.67383550810491','82.673835508104915','test','test','1.5'),('2018-05-17 23:59:59','2018-05-18 03:59:59','BNBETH','4h','0.018527000000000','0.018341000000000','1.604598101413362','1.588488896098800','86.60863072345022','86.608630723450219','test','test','1.0'),('2018-05-18 11:59:59','2018-05-19 15:59:59','BNBETH','4h','0.021839000000000','0.020965440000000','1.601018278010126','1.536977546889721','73.31005439855882','73.310054398558819','test','test','4.0'),('2018-05-22 11:59:59','2018-06-19 15:59:59','BNBETH','4h','0.021001000000000','0.030597000000000','1.586787004427814','2.311838577899997','75.557687939994','75.557687939993997','test','test','0.9'),('2018-06-20 07:59:59','2018-06-20 15:59:59','BNBETH','4h','0.030515000000000','0.029780000000000','1.747909576310521','1.705808526381364','57.28034003966971','57.280340039669710','test','test','2.4'),('2018-06-21 15:59:59','2018-06-24 07:59:59','BNBETH','4h','0.031393000000000','0.032042000000000','1.738553787437375','1.774495602748013','55.3803009408905','55.380300940890500','test','test','0.0'),('2018-06-24 15:59:59','2018-06-25 03:59:59','BNBETH','4h','0.031994000000000','0.031130000000000','1.746540857506406','1.699375410832482','54.58963735407907','54.589637354079073','test','test','2.7'),('2018-06-25 07:59:59','2018-06-25 15:59:59','BNBETH','4h','0.032496000000000','0.031964000000000','1.736059647134423','1.707638188115605','53.423795148154326','53.423795148154326','test','test','1.6'),('2018-06-26 15:59:59','2018-06-30 03:59:59','BNBETH','4h','0.032100000000000','0.032837000000000','1.729743767352463','1.769457822073297','53.886098671416306','53.886098671416306','test','test','0.8'),('2018-06-30 07:59:59','2018-06-30 11:59:59','BNBETH','4h','0.032282000000000','0.032621000000000','1.738569112845982','1.756826188902446','53.85568158249123','53.855681582491229','test','test','0.0'),('2018-07-25 11:59:59','2018-07-25 23:59:59','BNBETH','4h','0.027613000000000','0.027520000000000','1.742626240858529','1.736757112534919','63.10890670548399','63.108906705483989','test','test','1.5'),('2018-07-26 07:59:59','2018-07-26 11:59:59','BNBETH','4h','0.027371000000000','0.027251000000000','1.741321990119949','1.733687682319197','63.619231672936664','63.619231672936664','test','test','0.4'),('2018-07-26 15:59:59','2018-08-14 03:59:59','BNBETH','4h','0.028440000000000','0.034927000000000','1.739625477275338','2.136424017046263','61.16826572698094','61.168265726980941','test','test','1.1'),('2018-08-14 19:59:59','2018-08-14 23:59:59','BNBETH','4h','0.035204000000000','0.033811000000000','1.827802930557766','1.755477925380316','51.92031958180224','51.920319581802239','test','test','4.0'),('2018-08-15 03:59:59','2018-08-15 07:59:59','BNBETH','4h','0.035546000000000','0.035527000000000','1.811730707184999','1.810762303329811','50.968623957266615','50.968623957266615','test','test','0.1'),('2018-08-15 11:59:59','2018-08-15 15:59:59','BNBETH','4h','0.035109000000000','0.034219000000000','1.811515506328290','1.765594266742082','51.59689841146972','51.596898411469716','test','test','2.5'),('2018-08-20 23:59:59','2018-08-21 15:59:59','BNBETH','4h','0.035610000000000','0.034482000000000','1.801310786420244','1.744251573640630','50.58440849256513','50.584408492565132','test','test','3.2'),('2018-08-21 19:59:59','2018-08-21 23:59:59','BNBETH','4h','0.034539000000000','0.034620000000000','1.788630961358108','1.792825614007866','51.785835182202966','51.785835182202966','test','test','0.0'),('2018-08-22 03:59:59','2018-09-13 19:59:59','BNBETH','4h','0.034990000000000','0.046713000000000','1.789563106391388','2.389135792765387','51.14498732184589','51.144987321845889','test','test','0.5'),('2018-09-14 23:59:59','2018-09-15 15:59:59','BNBETH','4h','0.047351000000000','0.045456960000000','1.922801481141165','1.845889421895518','40.60741021607073','40.607410216070733','test','test','4.0'),('2018-09-17 19:59:59','2018-09-18 15:59:59','BNBETH','4h','0.047336000000000','0.045442560000000','1.905709912419910','1.829481515923113','40.25920889851086','40.259208898510863','test','test','4.0'),('2018-09-25 07:59:59','2018-09-25 23:59:59','BNBETH','4h','0.045787000000000','0.044830000000000','1.888770268753955','1.849292837448180','41.25123438430025','41.251234384300247','test','test','2.1'),('2018-09-26 03:59:59','2018-09-26 15:59:59','BNBETH','4h','0.045700000000000','0.044797000000000','1.879997506241561','1.842850071927860','41.13780101185035','41.137801011850350','test','test','2.0'),('2018-09-27 15:59:59','2018-09-27 19:59:59','BNBETH','4h','0.045120000000000','0.043985000000000','1.871742520838517','1.824658572231431','41.483655160428114','41.483655160428114','test','test','2.5'),('2018-09-28 19:59:59','2018-09-29 11:59:59','BNBETH','4h','0.045185000000000','0.043377600000000','1.861279421148053','1.786828244302131','41.19241830581061','41.192418305810612','test','test','4.0'),('2018-10-02 23:59:59','2018-10-09 03:59:59','BNBETH','4h','0.045773000000000','0.046164000000000','1.844734715182293','1.860492722602306','40.30180925834646','40.301809258346459','test','test','0.0'),('2018-10-09 11:59:59','2018-10-09 15:59:59','BNBETH','4h','0.046130000000000','0.045202000000000','1.848236494608962','1.811055409263262','40.06582472596926','40.065824725969257','test','test','2.0'),('2018-10-10 15:59:59','2018-10-10 19:59:59','BNBETH','4h','0.045916000000000','0.045873000000000','1.839974031198807','1.838250908902842','40.07261153407977','40.072611534079769','test','test','0.1'),('2018-10-11 03:59:59','2018-10-15 07:59:59','BNBETH','4h','0.047947000000000','0.047632000000000','1.839591115133036','1.827505453855649','38.36717865837355','38.367178658373547','test','test','1.9'),('2018-10-15 11:59:59','2018-10-17 07:59:59','BNBETH','4h','0.047250000000000','0.047571000000000','1.836905412626951','1.849384706541306','38.87630502914182','38.876305029141818','test','test','0.0'),('2018-10-18 19:59:59','2018-10-20 11:59:59','BNBETH','4h','0.048433000000000','0.047631000000000','1.839678589052363','1.809215429049473','37.983990028541754','37.983990028541754','test','test','1.7'),('2018-10-20 15:59:59','2018-10-20 19:59:59','BNBETH','4h','0.047724000000000','0.047598000000000','1.832908997940610','1.828069786354395','38.4064411604352','38.406441160435200','test','test','0.3'),('2018-10-21 19:59:59','2018-10-21 23:59:59','BNBETH','4h','0.047684000000000','0.047843000000000','1.831833617588117','1.837941778505752','38.41610640022056','38.416106400220563','test','test','0.0'),('2018-10-22 15:59:59','2018-10-24 11:59:59','BNBETH','4h','0.047876000000000','0.047965000000000','1.833190986680925','1.836598831902218','38.29039574486015','38.290395744860149','test','test','0.1'),('2018-10-24 19:59:59','2018-10-24 23:59:59','BNBETH','4h','0.048033000000000','0.048150000000000','1.833948285618990','1.838415463380475','38.181006508421085','38.181006508421085','test','test','0.0'),('2018-10-25 07:59:59','2018-10-25 15:59:59','BNBETH','4h','0.048252000000000','0.047888000000000','1.834940991788209','1.821098694660402','38.02828881265457','38.028288812654573','test','test','0.8'),('2018-10-29 19:59:59','2018-10-30 11:59:59','BNBETH','4h','0.047938000000000','0.047815000000000','1.831864925759807','1.827164700763594','38.21321135132477','38.213211351324773','test','test','0.3'),('2018-11-01 15:59:59','2018-11-02 11:59:59','BNBETH','4h','0.047897000000000','0.047836000000000','1.830820431316205','1.828488760307367','38.22411489897498','38.224114898974982','test','test','0.1'),('2018-11-14 15:59:59','2018-11-14 19:59:59','BNBETH','4h','0.046758000000000','0.046472000000000','1.830302282203130','1.819107054590527','39.14415249161918','39.144152491619181','test','test','0.6'),('2018-11-14 23:59:59','2018-11-15 11:59:59','BNBETH','4h','0.046302000000000','0.045924000000000','1.827814453844773','1.812892552770233','39.47592876862281','39.475928768622808','test','test','0.8'),('2018-11-19 07:59:59','2018-11-19 15:59:59','BNBETH','4h','0.045891000000000','0.044316000000000','1.824498475828209','1.761880858007080','39.75721766420886','39.757217664208859','test','test','3.4'),('2018-11-23 03:59:59','2018-11-23 07:59:59','BNBETH','4h','0.045275000000000','0.044735000000000','1.810583449645736','1.788988417888503','39.99079955043039','39.990799550430388','test','test','1.2'),('2018-11-26 23:59:59','2018-11-27 19:59:59','BNBETH','4h','0.045665000000000','0.044906000000000','1.805784553699684','1.775770528160254','39.54417067118546','39.544170671185462','test','test','1.7'),('2018-11-28 15:59:59','2018-11-28 19:59:59','BNBETH','4h','0.044986000000000','0.043663000000000','1.799114770246477','1.746204334976925','39.99277042294219','39.992770422942193','test','test','2.9'),('2018-11-29 11:59:59','2018-11-29 19:59:59','BNBETH','4h','0.045600000000000','0.044709000000000','1.787356895742132','1.752432882713486','39.19642315223974','39.196423152239738','test','test','2.0'),('2018-11-29 23:59:59','2018-11-30 11:59:59','BNBETH','4h','0.045568000000000','0.044400000000000','1.779596003957989','1.733981359193617','39.053634216072446','39.053634216072446','test','test','2.6'),('2018-12-03 03:59:59','2018-12-07 19:59:59','BNBETH','4h','0.045149000000000','0.048342000000000','1.769459416232573','1.894598044242731','39.19155277486927','39.191552774869272','test','test','0.0'),('2018-12-10 23:59:59','2018-12-17 19:59:59','BNBETH','4h','0.051521000000000','0.053070000000000','1.797268000234831','1.851303599939102','34.88418315317697','34.884183153176970','test','test','0.0'),('2018-12-17 23:59:59','2018-12-19 07:59:59','BNBETH','4h','0.053834000000000','0.052927000000000','1.809275911280224','1.778793070482008','33.608424253821454','33.608424253821454','test','test','1.7'),('2018-12-19 11:59:59','2018-12-20 03:59:59','BNBETH','4h','0.053425000000000','0.054186000000000','1.802501946658398','1.828177266853195','33.738922726408944','33.738922726408944','test','test','0.0'),('2018-12-20 11:59:59','2018-12-20 15:59:59','BNBETH','4h','0.053259000000000','0.052761000000000','1.808207573368353','1.791299870040513','33.9512115016871','33.951211501687098','test','test','0.9'),('2018-12-31 23:59:59','2019-01-01 03:59:59','BNBETH','4h','0.046469000000000','0.044641000000000','1.804450305962167','1.733466743602339','38.831270437542585','38.831270437542585','test','test','3.9'),('2019-01-08 11:59:59','2019-01-24 19:59:59','BNBETH','4h','0.043388000000000','0.055440000000000','1.788676180993316','2.285521514572450','41.225135544236096','41.225135544236096','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:14:26
