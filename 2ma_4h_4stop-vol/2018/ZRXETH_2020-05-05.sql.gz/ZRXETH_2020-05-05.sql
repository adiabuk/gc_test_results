-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-20 03:59:59','2018-04-09 11:59:59','ZRXETH','4h','0.000893000000000','0.001362800000000','1.297777777777778','1.980528057732985','1453.278586537265','1453.278586537265028','test','test','0.0'),('2018-04-11 07:59:59','2018-04-11 11:59:59','ZRXETH','4h','0.001400000000000','0.001436990000000','1.449500062212268','1.487797924570291','1035.3571872944772','1035.357187294477171','test','test','0.0'),('2018-04-11 15:59:59','2018-04-12 11:59:59','ZRXETH','4h','0.001424860000000','0.001379200000000','1.458010698291829','1.411288375759086','1023.2659337000329','1023.265933700032861','test','test','3.2'),('2018-04-12 15:59:59','2018-04-12 19:59:59','ZRXETH','4h','0.001375900000000','0.001382620000000','1.447627959951219','1.454698284750167','1052.1316665100803','1052.131666510080322','test','test','0.0'),('2018-04-12 23:59:59','2018-04-13 03:59:59','ZRXETH','4h','0.001401240000000','0.001373650000000','1.449199143239874','1.420664841933897','1034.2262162369575','1034.226216236957498','test','test','2.0'),('2018-04-13 15:59:59','2018-04-13 23:59:59','ZRXETH','4h','0.001388970000000','0.001388000000000','1.442858187394102','1.441850554081811','1038.79722916557','1038.797229165569888','test','test','0.1'),('2018-04-14 11:59:59','2018-04-21 03:59:59','ZRXETH','4h','0.001437570000000','0.001523810000000','1.442634268880259','1.529178074989341','1003.5227981108811','1003.522798110881126','test','test','1.0'),('2018-04-22 15:59:59','2018-04-23 19:59:59','ZRXETH','4h','0.001594820000000','0.001549820000000','1.461866225793389','1.420617696077996','916.633993675392','916.633993675392048','test','test','2.8'),('2018-04-24 11:59:59','2018-04-25 07:59:59','ZRXETH','4h','0.001602350000000','0.001605000000000','1.452699885856635','1.455102391362623','906.605851316276','906.605851316276016','test','test','0.0'),('2018-04-26 07:59:59','2018-04-27 19:59:59','ZRXETH','4h','0.001756590000000','0.001686326400000','1.453233775969076','1.395104424930313','827.3039103997384','827.303910399738356','test','test','4.0'),('2018-04-29 15:59:59','2018-05-01 07:59:59','ZRXETH','4h','0.001810420000000','0.001738003200000','1.440316142404907','1.382703496708711','795.5701673671892','795.570167367189242','test','test','4.0'),('2018-05-02 03:59:59','2018-05-06 11:59:59','ZRXETH','4h','0.001786950000000','0.001878430000000','1.427513332250197','1.500592556422249','798.8546586363339','798.854658636333852','test','test','1.1'),('2018-05-07 03:59:59','2018-05-14 19:59:59','ZRXETH','4h','0.002006940000000','0.002186510000000','1.443753159843986','1.572932285733741','719.3803301762814','719.380330176281404','test','test','0.0'),('2018-05-19 23:59:59','2018-05-20 03:59:59','ZRXETH','4h','0.002104750000000','0.002083500000000','1.472459632263932','1.457593369199146','699.5888501075813','699.588850107581266','test','test','1.0'),('2018-05-23 19:59:59','2018-05-24 03:59:59','ZRXETH','4h','0.002354770000000','0.002260579200000','1.469156018249535','1.410389777519554','623.9063765248984','623.906376524898405','test','test','4.0'),('2018-05-24 19:59:59','2018-05-25 15:59:59','ZRXETH','4h','0.002320000000000','0.002227200000000','1.456096853642872','1.397852979497157','627.6279541564105','627.627954156410510','test','test','4.0'),('2018-05-28 07:59:59','2018-05-28 11:59:59','ZRXETH','4h','0.002125350000000','0.002091700000000','1.443153770499380','1.420304769451410','679.0193476365682','679.019347636568227','test','test','1.6'),('2018-05-29 11:59:59','2018-06-01 15:59:59','ZRXETH','4h','0.002177980000000','0.002167680000000','1.438076214710942','1.431275332695716','660.27980730353','660.279807303529992','test','test','0.9'),('2018-06-03 15:59:59','2018-06-03 19:59:59','ZRXETH','4h','0.002183070000000','0.002161000000000','1.436564907596448','1.422041787627481','658.0480275925405','658.048027592540507','test','test','1.0'),('2018-06-06 11:59:59','2018-06-06 15:59:59','ZRXETH','4h','0.002158050000000','0.002150460000000','1.433337547603344','1.428296407691706','664.1818065398595','664.181806539859508','test','test','0.4'),('2018-06-06 23:59:59','2018-06-07 23:59:59','ZRXETH','4h','0.002211310000000','0.002144250000000','1.432217294289647','1.388783993777704','647.6782062621913','647.678206262191338','test','test','3.0'),('2018-06-30 03:59:59','2018-07-10 03:59:59','ZRXETH','4h','0.001605700000000','0.001910000000000','1.422565449731437','1.692159188507844','885.9472191140542','885.947219114054178','test','test','0.0'),('2018-07-10 19:59:59','2018-07-10 23:59:59','ZRXETH','4h','0.001930100000000','0.001880000000000','1.482475169459527','1.443994258631113','768.0820524633581','768.082052463358082','test','test','2.6'),('2018-07-11 15:59:59','2018-07-11 19:59:59','ZRXETH','4h','0.001948990000000','0.001890620000000','1.473923855942102','1.429781538397455','756.250086425329','756.250086425328959','test','test','3.0'),('2018-07-13 03:59:59','2018-07-13 07:59:59','ZRXETH','4h','0.001956070000000','0.001877827200000','1.464114452043292','1.405549873961560','748.4979842456006','748.497984245600605','test','test','4.0'),('2018-07-13 19:59:59','2018-07-21 03:59:59','ZRXETH','4h','0.002087150000000','0.002319540000000','1.451100101358462','1.612670258057642','695.2543426962425','695.254342696242475','test','test','0.0'),('2018-07-22 23:59:59','2018-07-24 07:59:59','ZRXETH','4h','0.002451000000000','0.002486400000000','1.487004580624947','1.508481513368368','606.6930153508555','606.693015350855489','test','test','0.0'),('2018-07-27 19:59:59','2018-07-30 11:59:59','ZRXETH','4h','0.002471310000000','0.002435400000000','1.491777232345707','1.470100582951849','603.6382454429865','603.638245442986545','test','test','1.6'),('2018-07-30 19:59:59','2018-07-31 11:59:59','ZRXETH','4h','0.002508630000000','0.002478750000000','1.486960199147072','1.469249189253021','592.7379482614302','592.737948261430233','test','test','1.2'),('2018-07-31 15:59:59','2018-07-31 19:59:59','ZRXETH','4h','0.002478660000000','0.002445100000000','1.483024419170616','1.462944900597126','598.3170015938514','598.317001593851387','test','test','1.4'),('2018-07-31 23:59:59','2018-08-01 03:59:59','ZRXETH','4h','0.002588100000000','0.002484576000000','1.478562303932063','1.419419811774780','571.2925713581635','571.292571358163514','test','test','4.0'),('2018-08-01 23:59:59','2018-08-02 11:59:59','ZRXETH','4h','0.002517650000000','0.002443240000000','1.465419527897111','1.422108556526657','582.058478302032','582.058478302031972','test','test','3.0'),('2018-08-07 11:59:59','2018-08-07 23:59:59','ZRXETH','4h','0.002460000000000','0.002386920000000','1.455794867592566','1.412547107867499','591.7865315416933','591.786531541693307','test','test','3.0'),('2018-08-09 15:59:59','2018-08-10 11:59:59','ZRXETH','4h','0.002466000000000','0.002435210000000','1.446184254320329','1.428127476870807','586.4494137552023','586.449413755202272','test','test','1.2'),('2018-08-10 23:59:59','2018-08-14 03:59:59','ZRXETH','4h','0.002604410000000','0.002518190000000','1.442171637109324','1.394427987472145','553.7421669818974','553.742166981897412','test','test','3.3'),('2018-08-14 15:59:59','2018-08-14 23:59:59','ZRXETH','4h','0.002626280000000','0.002521228800000','1.431561937189951','1.374299459702353','545.0911316348412','545.091131634841190','test','test','4.0'),('2018-08-15 07:59:59','2018-08-15 11:59:59','ZRXETH','4h','0.002561390000000','0.002458934400000','1.418836942192707','1.362083464504999','553.9324125543968','553.932412554396819','test','test','4.0'),('2018-08-17 07:59:59','2018-08-18 07:59:59','ZRXETH','4h','0.002547070000000','0.002475750000000','1.406225058262105','1.366849630356608','552.0951753434749','552.095175343474921','test','test','2.8'),('2018-08-18 15:59:59','2018-08-18 19:59:59','ZRXETH','4h','0.002540000000000','0.002511110000000','1.397474963171994','1.381580060933396','550.1869933748009','550.186993374800863','test','test','1.1'),('2018-08-19 11:59:59','2018-08-19 15:59:59','ZRXETH','4h','0.002598570000000','0.002572170000000','1.393942762674528','1.379781093396961','536.4268665745113','536.426866574511337','test','test','1.0'),('2018-08-23 23:59:59','2018-08-25 15:59:59','ZRXETH','4h','0.002588850000000','0.002573660000000','1.390795725057291','1.382635272708325','537.225302762729','537.225302762729029','test','test','1.4'),('2018-08-26 15:59:59','2018-08-30 19:59:59','ZRXETH','4h','0.002617520000000','0.002632000000000','1.388982291201965','1.396666077219495','530.6482056305072','530.648205630507164','test','test','0.8'),('2018-08-31 19:59:59','2018-09-02 15:59:59','ZRXETH','4h','0.002694250000000','0.002698080000000','1.390689799205861','1.392666728566892','516.1695459611619','516.169545961161930','test','test','0.0'),('2018-09-03 15:59:59','2018-09-03 19:59:59','ZRXETH','4h','0.002754040000000','0.002736120000000','1.391129116841645','1.382077311575998','505.1230616990477','505.123061699047696','test','test','0.7'),('2018-09-03 23:59:59','2018-09-05 19:59:59','ZRXETH','4h','0.002730000000000','0.002734730000000','1.389117604560391','1.391524390739721','508.8342873847585','508.834287384758511','test','test','0.3'),('2018-09-06 03:59:59','2018-09-06 07:59:59','ZRXETH','4h','0.002793960000000','0.002710930000000','1.389652445933575','1.348355203816342','497.37735899353413','497.377358993534131','test','test','3.0'),('2018-09-06 15:59:59','2018-09-10 23:59:59','ZRXETH','4h','0.002858290000000','0.002809000000000','1.380475281018634','1.356669569701235','482.9724349239','482.972434923899982','test','test','1.7'),('2018-09-21 07:59:59','2018-09-21 19:59:59','ZRXETH','4h','0.002662500000000','0.002608010000000','1.375185122948101','1.347040958685400','516.5014546283948','516.501454628394754','test','test','2.0'),('2018-09-24 07:59:59','2018-09-29 11:59:59','ZRXETH','4h','0.002694850000000','0.002809670000000','1.368930864223056','1.427257168778074','507.9803566888905','507.980356688890481','test','test','2.3'),('2018-10-04 15:59:59','2018-10-05 19:59:59','ZRXETH','4h','0.002827900000000','0.002812290000000','1.381892265235283','1.374264223840494','488.66376648229516','488.663766482295159','test','test','0.6'),('2018-10-05 23:59:59','2018-10-15 07:59:59','ZRXETH','4h','0.002811600000000','0.003421700000000','1.380197144925330','1.679691481999930','490.8938486716921','490.893848671692126','test','test','0.0'),('2018-10-15 19:59:59','2018-10-25 07:59:59','ZRXETH','4h','0.003615410000000','0.004171840000000','1.446751442053018','1.669413852374824','400.1624828312746','400.162482831274588','test','test','3.8'),('2018-11-01 19:59:59','2018-11-02 23:59:59','ZRXETH','4h','0.004095010000000','0.004045140000000','1.496231977680086','1.478010510888331','365.3793220724947','365.379322072494688','test','test','1.3'),('2018-11-03 23:59:59','2018-11-04 03:59:59','ZRXETH','4h','0.004062670000000','0.004052540000000','1.492182762837474','1.488462103421980','367.2911565146749','367.291156514674924','test','test','0.2'),('2018-11-23 03:59:59','2018-11-23 07:59:59','ZRXETH','4h','0.003236760000000','0.003238340000000','1.491355949634031','1.492083943801168','460.7558019853283','460.755801985328276','test','test','0.0'),('2018-11-23 23:59:59','2018-11-24 03:59:59','ZRXETH','4h','0.003262220000000','0.003246680000000','1.491517726115617','1.484412691671638','457.2094236794628','457.209423679462816','test','test','0.5'),('2018-11-26 19:59:59','2018-11-26 23:59:59','ZRXETH','4h','0.003224860000000','0.003233850000000','1.489938829572511','1.494092358742105','462.01659283581637','462.016592835816368','test','test','0.0'),('2018-11-27 11:59:59','2018-11-27 23:59:59','ZRXETH','4h','0.003287520000000','0.003262630000000','1.490861836054643','1.479574436708206','453.491335734731','453.491335734731024','test','test','0.8'),('2018-11-28 15:59:59','2018-12-03 11:59:59','ZRXETH','4h','0.003405150000000','0.003442700000000','1.488353525088768','1.504766216120612','437.08897554843924','437.088975548439237','test','test','0.0'),('2018-12-03 15:59:59','2018-12-04 07:59:59','ZRXETH','4h','0.003429560000000','0.003448370000000','1.492000789762511','1.500183919626235','435.04146005974843','435.041460059748431','test','test','0.0'),('2018-12-04 11:59:59','2018-12-04 19:59:59','ZRXETH','4h','0.003437980000000','0.003436290000000','1.493819263065561','1.493084949731981','434.50493111232777','434.504931112327768','test','test','0.0'),('2018-12-05 19:59:59','2018-12-05 23:59:59','ZRXETH','4h','0.003437140000000','0.003420110000000','1.493656082324765','1.486255463472466','434.5636437051633','434.563643705163315','test','test','0.5'),('2018-12-06 15:59:59','2018-12-06 19:59:59','ZRXETH','4h','0.003439330000000','0.003432420000000','1.492011500357588','1.489013881790172','433.80876518321526','433.808765183215257','test','test','0.2'),('2018-12-06 23:59:59','2018-12-07 03:59:59','ZRXETH','4h','0.003501490000000','0.003549080000000','1.491345362898162','1.511614769870715','425.9173560107731','425.917356010773119','test','test','0.0'),('2018-12-07 07:59:59','2018-12-07 19:59:59','ZRXETH','4h','0.003504110000000','0.003363945600000','1.495849675558729','1.436015688536380','426.8843374091364','426.884337409136378','test','test','4.0'),('2018-12-08 03:59:59','2018-12-10 15:59:59','ZRXETH','4h','0.003582000000000','0.003505430000000','1.482553233998207','1.450861692644985','413.88979173595953','413.889791735959534','test','test','3.0'),('2018-12-11 07:59:59','2018-12-11 11:59:59','ZRXETH','4h','0.003461270000000','0.003497130000000','1.475510669253047','1.490797489581833','426.2916990737639','426.291699073763880','test','test','0.0'),('2018-12-11 19:59:59','2018-12-11 23:59:59','ZRXETH','4h','0.003505340000000','0.003399280000000','1.478907740437221','1.434160881373401','421.9013677524067','421.901367752406713','test','test','3.0'),('2019-01-11 15:59:59','2019-01-12 03:59:59','ZRXETH','4h','0.002259720000000','0.002237980000000','1.468963993978594','1.454831589420023','650.0646071099935','650.064607109993517','test','test','1.0'),('2019-01-13 19:59:59','2019-01-14 15:59:59','ZRXETH','4h','0.002310750000000','0.002248650000000','1.465823459632245','1.426430346208827','634.3496525510096','634.349652551009626','test','test','2.7'),('2019-01-15 23:59:59','2019-01-26 15:59:59','ZRXETH','4h','0.002330220000000','0.002482570000000','1.457069434427042','1.552332769363211','625.292648087752','625.292648087752013','test','test','0.0'),('2019-02-08 03:59:59','2019-02-08 07:59:59','ZRXETH','4h','0.002354000000000','0.002259840000000','1.478239064412857','1.419109501836342','627.9690163181209','627.969016318120907','test','test','4.0'),('2019-02-26 11:59:59','2019-02-26 15:59:59','ZRXETH','4h','0.001777610000000','0.001827560000000','1.465099161618076','1.506267754910656','824.1960619135107','824.196061913510675','test','test','0.0'),('2019-02-26 19:59:59','2019-02-28 11:59:59','ZRXETH','4h','0.001827100000000','0.001813540000000','1.474247737905316','1.463306465218547','806.8785167233955','806.878516723395478','test','test','2.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:45:58
