-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-24 15:59:59','2018-06-01 07:59:59','CMTETH','4h','0.000506980000000','0.000583450000000','1.297777777777778','1.493527248499831','2559.820461907329','2559.820461907328990','test','test','0.5'),('2018-06-04 23:59:59','2018-06-05 03:59:59','CMTETH','4h','0.000588880000000','0.000565324800000','1.341277660160456','1.287626553754038','2277.675689716846','2277.675689716846136','test','test','4.0'),('2018-07-01 03:59:59','2018-07-06 07:59:59','CMTETH','4h','0.000353660000000','0.000379090000000','1.329355192070141','1.424942769218656','3758.8508512982557','3758.850851298255748','test','test','0.9'),('2018-07-08 15:59:59','2018-07-09 03:59:59','CMTETH','4h','0.000383770000000','0.000377270000000','1.350596875880922','1.327721508621298','3519.287270711421','3519.287270711421115','test','test','1.7'),('2018-07-17 19:59:59','2018-07-19 03:59:59','CMTETH','4h','0.000353250000000','0.000339120000000','1.345513460934339','1.291692922496966','3808.9553034234655','3808.955303423465466','test','test','4.0'),('2018-08-11 03:59:59','2018-08-11 07:59:59','CMTETH','4h','0.000275970000000','0.000265960000000','1.333553341281590','1.285182616397622','4832.240248148674','4832.240248148674254','test','test','3.6'),('2018-08-13 11:59:59','2018-08-14 03:59:59','CMTETH','4h','0.000273780000000','0.000275000000000','1.322804291307374','1.328698882714325','4831.632300779364','4831.632300779364414','test','test','0.0'),('2018-08-14 15:59:59','2018-08-14 19:59:59','CMTETH','4h','0.000271590000000','0.000266370000000','1.324114200508919','1.298664529583419','4875.41588611112','4875.415886111120017','test','test','1.9'),('2018-08-17 03:59:59','2018-08-18 07:59:59','CMTETH','4h','0.000274230000000','0.000270250000000','1.318458718081030','1.299323445871708','4807.857339025745','4807.857339025745205','test','test','1.5'),('2018-08-18 15:59:59','2018-08-18 19:59:59','CMTETH','4h','0.000275000000000','0.000272530000000','1.314206435367848','1.302402472111998','4778.932492246718','4778.932492246717629','test','test','0.9'),('2018-08-21 15:59:59','2018-08-29 03:59:59','CMTETH','4h','0.000276570000000','0.000344960000000','1.311583332422103','1.635910570026860','4742.319602350591','4742.319602350590685','test','test','0.0'),('2018-09-01 07:59:59','2018-09-02 03:59:59','CMTETH','4h','0.000357780000000','0.000343468800000','1.383656051889827','1.328309809814234','3867.33761498638','3867.337614986379776','test','test','4.0'),('2018-09-02 07:59:59','2018-09-13 15:59:59','CMTETH','4h','0.000347960000000','0.000394380000000','1.371356886984139','1.554304313969435','3941.133713599664','3941.133713599664134','test','test','0.7'),('2018-09-17 19:59:59','2018-09-18 15:59:59','CMTETH','4h','0.000415800000000','0.000399168000000','1.412011870758650','1.355531395928304','3395.8919450664976','3395.891945066497556','test','test','4.0'),('2018-09-19 03:59:59','2018-09-21 15:59:59','CMTETH','4h','0.000403800000000','0.000407400000000','1.399460654129684','1.411937272145699','3465.727226670837','3465.727226670836899','test','test','0.0'),('2018-09-25 03:59:59','2018-09-27 19:59:59','CMTETH','4h','0.000400290000000','0.000400620000000','1.402233235911021','1.403389240227518','3503.043383324641','3503.043383324641127','test','test','0.0'),('2018-09-28 23:59:59','2018-10-12 03:59:59','CMTETH','4h','0.000419690000000','0.000534970000000','1.402490125759131','1.787724612398108','3341.728718242348','3341.728718242347895','test','test','0.0'),('2018-10-12 15:59:59','2018-10-15 07:59:59','CMTETH','4h','0.000580000000000','0.000556800000000','1.488097789456681','1.428573877878414','2565.68584389083','2565.685843890829801','test','test','4.0'),('2018-10-16 07:59:59','2018-10-18 07:59:59','CMTETH','4h','0.000552370000000','0.000554360000000','1.474870253550400','1.480183706135742','2670.0766760511974','2670.076676051197410','test','test','0.0'),('2018-10-21 11:59:59','2018-10-21 15:59:59','CMTETH','4h','0.000564570000000','0.000554470000000','1.476051020791587','1.449644879285671','2614.469456031293','2614.469456031292793','test','test','1.8'),('2018-10-22 03:59:59','2018-10-22 07:59:59','CMTETH','4h','0.000552840000000','0.000546640000000','1.470182989345828','1.453695154648729','2659.328176951429','2659.328176951429214','test','test','1.1'),('2018-11-23 03:59:59','2018-11-23 07:59:59','CMTETH','4h','0.000380690000000','0.000373670000000','1.466519026079806','1.439476120925796','3852.26569145448','3852.265691454480020','test','test','1.8'),('2018-11-25 11:59:59','2018-11-25 23:59:59','CMTETH','4h','0.000391420000000','0.000389430000000','1.460509491601137','1.453084184033087','3731.310335703686','3731.310335703686178','test','test','1.9'),('2018-11-26 03:59:59','2018-11-26 11:59:59','CMTETH','4h','0.000387850000000','0.000375300000000','1.458859423252681','1.411653839233547','3761.4011170624763','3761.401117062476260','test','test','3.2'),('2018-11-29 07:59:59','2018-11-30 07:59:59','CMTETH','4h','0.000391000000000','0.000376410000000','1.448369293470652','1.394324004489228','3704.269292763815','3704.269292763814974','test','test','3.7'),('2018-11-30 15:59:59','2018-11-30 19:59:59','CMTETH','4h','0.000432010000000','0.000414729600000','1.436359229252558','1.378904860082456','3324.8286596434286','3324.828659643428637','test','test','4.0'),('2018-11-30 23:59:59','2018-12-02 19:59:59','CMTETH','4h','0.000400680000000','0.000385940000000','1.423591591659201','1.371221271051592','3552.9389828771127','3552.938982877112721','test','test','3.7'),('2019-01-11 11:59:59','2019-01-11 15:59:59','CMTETH','4h','0.000183550000000','0.000181860000000','1.411953742635289','1.398953460286863','7692.474762382395','7692.474762382395056','test','test','0.9'),('2019-01-13 07:59:59','2019-01-14 15:59:59','CMTETH','4h','0.000189330000000','0.000181756800000','1.409064791002305','1.352702199362213','7442.374642171365','7442.374642171364940','test','test','4.0'),('2019-01-15 23:59:59','2019-01-27 19:59:59','CMTETH','4h','0.000187730000000','0.000227580000000','1.396539770637840','1.692987380822243','7439.086830223408','7439.086830223407560','test','test','0.7'),('2019-02-05 23:59:59','2019-02-06 03:59:59','CMTETH','4h','0.000215820000000','0.000213580000000','1.462417017345485','1.447238562527331','6776.095900961381','6776.095900961380721','test','test','1.0'),('2019-02-07 19:59:59','2019-02-07 23:59:59','CMTETH','4h','0.000216230000000','0.000215410000000','1.459044027385896','1.453510955645358','6747.648464070182','6747.648464070181944','test','test','0.4'),('2019-02-08 07:59:59','2019-02-08 11:59:59','CMTETH','4h','0.000214390000000','0.000216070000000','1.457814455887998','1.469238161685339','6799.824879369365','6799.824879369364680','test','test','0.0'),('2019-02-10 07:59:59','2019-02-10 15:59:59','CMTETH','4h','0.000220300000000','0.000214460000000','1.460353057176296','1.421640111856688','6628.928993083506','6628.928993083505702','test','test','2.7'),('2019-02-11 03:59:59','2019-02-11 11:59:59','CMTETH','4h','0.000216880000000','0.000210440000000','1.451750180438605','1.408642142989211','6693.7946349991025','6693.794634999102527','test','test','3.0'),('2019-02-16 03:59:59','2019-02-16 11:59:59','CMTETH','4h','0.000213290000000','0.000208490000000','1.442170616560962','1.409715185178841','6761.548204608571','6761.548204608570813','test','test','2.3'),('2019-02-16 19:59:59','2019-02-17 11:59:59','CMTETH','4h','0.000210590000000','0.000203070000000','1.434958298476047','1.383717088520494','6813.990685578833','6813.990685578833109','test','test','3.6'),('2019-02-25 15:59:59','2019-02-25 19:59:59','CMTETH','4h','0.000193790000000','0.000191180000000','1.423571362930368','1.404398437303410','7345.9485160760005','7345.948516076000487','test','test','1.3'),('2019-02-26 03:59:59','2019-03-05 15:59:59','CMTETH','4h','0.000201420000000','0.000205520000000','1.419310712791044','1.448201458111485','7046.523248888115','7046.523248888114722','test','test','0.9'),('2019-03-08 03:59:59','2019-03-16 03:59:59','CMTETH','4h','0.000212910000000','0.000237970000000','1.425730878417809','1.593542704133606','6696.401664636742','6696.401664636741771','test','test','0.4'),('2019-03-17 15:59:59','2019-03-18 15:59:59','CMTETH','4h','0.000239420000000','0.000239550000000','1.463022395243541','1.463816785484046','6110.694157729268','6110.694157729268227','test','test','0.9'),('2019-03-19 11:59:59','2019-03-21 15:59:59','CMTETH','4h','0.000242390000000','0.000241470000000','1.463198926408098','1.457645302032936','6036.548233871439','6036.548233871439152','test','test','0.4'),('2019-03-21 19:59:59','2019-03-21 23:59:59','CMTETH','4h','0.000244590000000','0.000242790000000','1.461964787658062','1.451205817063252','5977.205886005406','5977.205886005405773','test','test','0.7'),('2019-03-22 03:59:59','2019-03-22 07:59:59','CMTETH','4h','0.000243920000000','0.000242340000000','1.459573905303660','1.450119466264714','5983.822176548295','5983.822176548294919','test','test','0.6'),('2019-03-22 15:59:59','2019-03-22 19:59:59','CMTETH','4h','0.000242180000000','0.000243180000000','1.457472918850561','1.463491057915928','6018.139065366921','6018.139065366921386','test','test','0.0'),('2019-03-23 07:59:59','2019-03-24 11:59:59','CMTETH','4h','0.000247080000000','0.000243860000000','1.458810283087309','1.439798751957549','5904.202214211223','5904.202214211222781','test','test','1.3'),('2019-03-24 23:59:59','2019-03-25 07:59:59','CMTETH','4h','0.000242850000000','0.000240460000000','1.454585498391807','1.440270244773704','5989.645865315243','5989.645865315243100','test','test','1.0'),('2019-03-27 15:59:59','2019-03-27 23:59:59','CMTETH','4h','0.000243660000000','0.000238650000000','1.451404330921117','1.421561370657164','5956.678695399808','5956.678695399808021','test','test','2.1'),('2019-03-28 07:59:59','2019-03-29 15:59:59','CMTETH','4h','0.000242980000000','0.000241030000000','1.444772561973572','1.433177753775990','5946.055485939469','5946.055485939468781','test','test','0.8'),('2019-03-30 15:59:59','2019-04-03 03:59:59','CMTETH','4h','0.000252750000000','0.000244460000000','1.442195937929665','1.394893052369084','5706.017558574341','5706.017558574340910','test','test','3.3'),('2019-04-03 07:59:59','2019-04-07 23:59:59','CMTETH','4h','0.000261660000000','0.000275150000000','1.431684185582869','1.505495313242859','5471.54393328315','5471.543933283150182','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:43:55
