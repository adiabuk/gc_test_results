-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-29 19:59:59','2018-05-01 07:59:59','ENJETH','4h','0.000233300000000','0.000230920000000','1.297777777777778','1.284538553126637','5562.699433252369','5562.699433252369090','test','test','1.0'),('2018-05-03 11:59:59','2018-05-03 15:59:59','ENJETH','4h','0.000237740000000','0.000229950000000','1.294835727855302','1.252407990326940','5446.4361397127195','5446.436139712719523','test','test','3.3'),('2018-05-21 11:59:59','2018-05-22 11:59:59','ENJETH','4h','0.000203610000000','0.000203190000000','1.285407341737888','1.282755845821529','6313.085515141143','6313.085515141143333','test','test','0.8'),('2018-05-22 15:59:59','2018-05-23 03:59:59','ENJETH','4h','0.000203990000000','0.000203550000000','1.284818120423142','1.282046808236338','6298.436788191293','6298.436788191293090','test','test','0.4'),('2018-05-23 07:59:59','2018-05-23 11:59:59','ENJETH','4h','0.000203760000000','0.000201950000000','1.284202273270519','1.272794704981259','6302.523916718289','6302.523916718289001','test','test','0.9'),('2018-05-23 15:59:59','2018-05-23 19:59:59','ENJETH','4h','0.000202810000000','0.000195690000000','1.281667258095127','1.236672085876610','6319.546659903986','6319.546659903986438','test','test','3.5'),('2018-05-24 03:59:59','2018-05-24 07:59:59','ENJETH','4h','0.000204440000000','0.000200040000000','1.271668330935457','1.244299221875997','6220.252058968192','6220.252058968191704','test','test','2.2'),('2018-06-07 15:59:59','2018-06-07 19:59:59','ENJETH','4h','0.000182530000000','0.000178770000000','1.265586306700021','1.239516046944408','6933.579722237558','6933.579722237557689','test','test','2.1'),('2018-06-07 23:59:59','2018-06-08 11:59:59','ENJETH','4h','0.000187750000000','0.000180240000000','1.259792915643219','1.209401199017490','6709.948951495172','6709.948951495171968','test','test','4.0'),('2018-07-02 15:59:59','2018-07-03 03:59:59','ENJETH','4h','0.000133350000000','0.000131810000000','1.248594756393057','1.234175289390093','9363.290261665217','9363.290261665217258','test','test','1.2'),('2018-07-03 07:59:59','2018-07-03 11:59:59','ENJETH','4h','0.000128930000000','0.000130580000000','1.245390430392398','1.261328491434416','9659.43093455672','9659.430934556719876','test','test','0.0'),('2018-07-03 19:59:59','2018-07-03 23:59:59','ENJETH','4h','0.000132850000000','0.000130440000000','1.248932221735069','1.226275641724670','9401.070543734051','9401.070543734051171','test','test','1.8'),('2018-07-04 15:59:59','2018-07-05 23:59:59','ENJETH','4h','0.000138870000000','0.000133440000000','1.243897426177202','1.195259397631496','8957.279658509413','8957.279658509412911','test','test','3.9'),('2018-07-06 03:59:59','2018-07-06 07:59:59','ENJETH','4h','0.000131840000000','0.000131280000000','1.233088975389268','1.227851340178270','9352.920019639469','9352.920019639468592','test','test','0.4'),('2018-07-06 19:59:59','2018-07-06 23:59:59','ENJETH','4h','0.000132460000000','0.000129710000000','1.231925056453490','1.206349079515191','9300.355250290582','9300.355250290582262','test','test','2.1'),('2018-07-07 11:59:59','2018-07-07 15:59:59','ENJETH','4h','0.000137000000000','0.000131520000000','1.226241506022757','1.177191845781847','8950.66792717341','8950.667927173410135','test','test','4.0'),('2018-07-07 23:59:59','2018-07-08 03:59:59','ENJETH','4h','0.000135080000000','0.000137240000000','1.215341581524777','1.234775530415016','8997.198560295954','8997.198560295953939','test','test','0.0'),('2018-07-08 07:59:59','2018-07-08 11:59:59','ENJETH','4h','0.000132530000000','0.000132050000000','1.219660236833719','1.215242845196503','9202.899244199194','9202.899244199194072','test','test','0.4'),('2018-07-08 15:59:59','2018-07-08 19:59:59','ENJETH','4h','0.000132780000000','0.000132850000000','1.218678594247671','1.219321066770621','9178.178899289584','9178.178899289583569','test','test','0.0'),('2018-07-09 11:59:59','2018-07-12 07:59:59','ENJETH','4h','0.000133810000000','0.000133540000000','1.218821365919438','1.216362044726715','9108.597010084732','9108.597010084731664','test','test','0.2'),('2018-07-12 15:59:59','2018-07-12 19:59:59','ENJETH','4h','0.000137320000000','0.000136870000000','1.218274850098833','1.214282542477624','8871.794713798667','8871.794713798666635','test','test','0.3'),('2018-07-12 23:59:59','2018-07-13 03:59:59','ENJETH','4h','0.000136160000000','0.000136110000000','1.217387670627453','1.216940627563915','8940.861270765665','8940.861270765664813','test','test','0.0'),('2018-07-13 07:59:59','2018-07-13 15:59:59','ENJETH','4h','0.000136170000000','0.000136110000000','1.217288327724444','1.216751959216965','8939.475124656272','8939.475124656271873','test','test','0.0'),('2018-07-18 15:59:59','2018-07-18 23:59:59','ENJETH','4h','0.000133740000000','0.000132340000000','1.217169134722783','1.204427720122724','9101.010428613597','9101.010428613597469','test','test','1.0'),('2018-07-24 11:59:59','2018-07-24 15:59:59','ENJETH','4h','0.000131870000000','0.000126595200000','1.214337709256103','1.165764200885859','9208.597173398823','9208.597173398822633','test','test','4.0'),('2018-07-24 23:59:59','2018-07-25 03:59:59','ENJETH','4h','0.000141690000000','0.000136022400000','1.203543596284937','1.155401852433539','8494.202810960105','8494.202810960105126','test','test','4.0'),('2018-07-28 11:59:59','2018-07-29 07:59:59','ENJETH','4h','0.000134610000000','0.000130630000000','1.192845430984627','1.157576693035598','8861.49194699225','8861.491946992249723','test','test','3.0'),('2018-07-29 15:59:59','2018-07-30 19:59:59','ENJETH','4h','0.000134810000000','0.000131640000000','1.185007933662620','1.157142974462928','8790.20794942972','8790.207949429719520','test','test','2.4'),('2018-07-30 23:59:59','2018-07-31 19:59:59','ENJETH','4h','0.000132990000000','0.000129590000000','1.178815720507133','1.148678315817124','8863.942555884902','8863.942555884901594','test','test','2.6'),('2018-08-07 11:59:59','2018-08-07 19:59:59','ENJETH','4h','0.000126860000000','0.000125350000000','1.172118519464909','1.158166927439117','9239.464917743253','9239.464917743252954','test','test','1.2'),('2018-08-07 23:59:59','2018-08-08 03:59:59','ENJETH','4h','0.000127180000000','0.000125830000000','1.169018165681400','1.156609182164574','9191.839642093095','9191.839642093094881','test','test','1.1'),('2018-08-13 03:59:59','2018-08-14 03:59:59','ENJETH','4h','0.000127730000000','0.000122620800000','1.166260613788772','1.119610189237221','9130.671054480323','9130.671054480322709','test','test','4.0'),('2018-08-14 11:59:59','2018-08-14 19:59:59','ENJETH','4h','0.000129760000000','0.000128480000000','1.155893852777316','1.144491693933643','8907.936596619265','8907.936596619265401','test','test','2.5'),('2018-08-15 03:59:59','2018-08-15 23:59:59','ENJETH','4h','0.000131850000000','0.000129030000000','1.153360039700944','1.128692043402448','8747.516417906287','8747.516417906286733','test','test','2.1'),('2018-08-16 11:59:59','2018-08-19 11:59:59','ENJETH','4h','0.000128970000000','0.000131090000000','1.147878262745723','1.166747006771627','8900.350955615435','8900.350955615434941','test','test','0.0'),('2018-08-19 15:59:59','2018-08-20 23:59:59','ENJETH','4h','0.000132190000000','0.000129410000000','1.152071316973701','1.127842871091358','8715.268303000994','8715.268303000993910','test','test','2.1'),('2018-08-21 11:59:59','2018-08-21 15:59:59','ENJETH','4h','0.000133280000000','0.000130650000000','1.146687217888736','1.124059761533339','8603.59557239448','8603.595572394480769','test','test','2.0'),('2018-08-22 03:59:59','2018-08-22 11:59:59','ENJETH','4h','0.000133780000000','0.000134220000000','1.141658894254204','1.145413789705481','8533.853298357033','8533.853298357033054','test','test','0.0'),('2018-08-22 19:59:59','2018-08-22 23:59:59','ENJETH','4h','0.000133700000000','0.000128352000000','1.142493315465599','1.096793582846975','8545.20056443978','8545.200564439779555','test','test','4.0'),('2018-08-24 07:59:59','2018-08-24 11:59:59','ENJETH','4h','0.000130930000000','0.000131830000000','1.132337819328127','1.140121398625426','8648.421441442959','8648.421441442958894','test','test','0.0'),('2018-08-24 19:59:59','2018-08-24 23:59:59','ENJETH','4h','0.000136120000000','0.000133520000000','1.134067503616415','1.112405914508255','8331.380426215217','8331.380426215217085','test','test','1.9'),('2018-08-25 03:59:59','2018-09-13 15:59:59','ENJETH','4h','0.000133620000000','0.000196310000000','1.129253817147935','1.659061643798167','8451.233476634749','8451.233476634748513','test','test','0.6'),('2018-09-13 19:59:59','2018-09-14 03:59:59','ENJETH','4h','0.000199330000000','0.000191356800000','1.246988889736876','1.197109334147401','6255.901719444518','6255.901719444517767','test','test','4.0'),('2018-09-15 03:59:59','2018-09-15 15:59:59','ENJETH','4h','0.000197070000000','0.000192590000000','1.235904544050326','1.207808677823374','6271.3987113732455','6271.398711373245533','test','test','2.3'),('2018-09-17 03:59:59','2018-09-17 11:59:59','ENJETH','4h','0.000198390000000','0.000195450000000','1.229661018222114','1.211438308440507','6198.200605988781','6198.200605988780808','test','test','1.5'),('2018-09-17 19:59:59','2018-09-18 15:59:59','ENJETH','4h','0.000199030000000','0.000193510000000','1.225611527159535','1.191619789080247','6157.923565088353','6157.923565088352916','test','test','2.8'),('2018-09-20 11:59:59','2018-09-20 23:59:59','ENJETH','4h','0.000197010000000','0.000189129600000','1.218057807586360','1.169335495282906','6182.720712584944','6182.720712584943612','test','test','4.0'),('2018-09-25 11:59:59','2018-09-25 23:59:59','ENJETH','4h','0.000193470000000','0.000186590000000','1.207230627074481','1.164300215567413','6239.885393469173','6239.885393469173323','test','test','3.6'),('2018-09-26 03:59:59','2018-09-26 07:59:59','ENJETH','4h','0.000190010000000','0.000188620000000','1.197690535628466','1.188928944951535','6303.302645273753','6303.302645273753114','test','test','0.7'),('2018-09-27 07:59:59','2018-09-27 23:59:59','ENJETH','4h','0.000194500000000','0.000190760000000','1.195743515478037','1.172750812404063','6147.781570581165','6147.781570581165397','test','test','1.9'),('2018-09-28 03:59:59','2018-10-03 23:59:59','ENJETH','4h','0.000253010000000','0.000248890000000','1.190634025906043','1.171245811263409','4705.8773404452095','4705.877340445209484','test','test','3.6'),('2018-10-04 03:59:59','2018-10-07 11:59:59','ENJETH','4h','0.000244200000000','0.000240920000000','1.186325533763235','1.170391267789675','4858.007918768366','4858.007918768365926','test','test','1.8'),('2018-10-10 15:59:59','2018-10-11 07:59:59','ENJETH','4h','0.000244420000000','0.000239640000000','1.182784585769111','1.159653457710947','4839.14812932293','4839.148129322929890','test','test','2.0'),('2018-10-11 11:59:59','2018-10-11 15:59:59','ENJETH','4h','0.000243220000000','0.000242580000000','1.177644335089518','1.174545525886092','4841.889380353255','4841.889380353254637','test','test','0.3'),('2018-10-12 11:59:59','2018-10-12 15:59:59','ENJETH','4h','0.000243770000000','0.000242920000000','1.176955710822091','1.172851791741815','4828.140094441854','4828.140094441853762','test','test','0.3'),('2018-10-14 03:59:59','2018-10-15 03:59:59','ENJETH','4h','0.000245220000000','0.000242750000000','1.176043728804251','1.164197924994829','4795.871987620306','4795.871987620305845','test','test','1.0'),('2018-10-19 03:59:59','2018-10-19 05:59:59','ENJETH','4h','0.000241550000000','0.000242390000000','1.173411327957713','1.177491913821859','4857.840314459588','4857.840314459587717','test','test','0.0'),('2018-10-20 03:59:59','2018-10-20 07:59:59','ENJETH','4h','0.000239400000000','0.000238450000000','1.174318124816412','1.169658132257617','4905.25532504767','4905.255325047670340','test','test','0.4'),('2018-10-20 15:59:59','2018-10-21 23:59:59','ENJETH','4h','0.000254300000000','0.000244128000000','1.173282570914458','1.126351268077880','4613.773381496099','4613.773381496099319','test','test','4.0'),('2018-10-22 03:59:59','2018-10-22 07:59:59','ENJETH','4h','0.000245590000000','0.000246200000000','1.162853392506330','1.165741704609546','4734.937874124881','4734.937874124881091','test','test','0.0'),('2018-10-24 11:59:59','2018-10-26 03:59:59','ENJETH','4h','0.000249870000000','0.000248350000000','1.163495239640377','1.156417508162995','4656.402287751141','4656.402287751140648','test','test','0.6'),('2018-10-31 19:59:59','2018-11-02 23:59:59','ENJETH','4h','0.000248850000000','0.000248100000000','1.161922410423182','1.158420534562955','4669.167813635449','4669.167813635449420','test','test','0.3'),('2018-11-03 03:59:59','2018-11-03 11:59:59','ENJETH','4h','0.000251200000000','0.000248220000000','1.161144215787575','1.147369495393280','4622.38939405882','4622.389394058819562','test','test','1.2'),('2018-11-09 07:59:59','2018-11-09 11:59:59','ENJETH','4h','0.000240340000000','0.000236510000000','1.158083166811065','1.139628234095386','4818.520291300098','4818.520291300097597','test','test','1.6'),('2018-11-09 15:59:59','2018-11-09 19:59:59','ENJETH','4h','0.000241910000000','0.000242750000000','1.153982070652026','1.157989118477034','4770.29502977151','4770.295029771509689','test','test','0.0'),('2018-11-10 03:59:59','2018-11-10 15:59:59','ENJETH','4h','0.000243920000000','0.000240520000000','1.154872525724250','1.138774761754660','4734.636461644186','4734.636461644186056','test','test','1.4'),('2018-11-12 07:59:59','2018-11-12 15:59:59','ENJETH','4h','0.000245910000000','0.000241380000000','1.151295244842119','1.130086804928595','4681.77481534756','4681.774815347560434','test','test','1.8'),('2018-11-12 23:59:59','2018-11-13 03:59:59','ENJETH','4h','0.000239970000000','0.000239740000000','1.146582258194669','1.145483312829062','4778.023328727211','4778.023328727211265','test','test','0.1'),('2018-11-13 15:59:59','2018-11-13 19:59:59','ENJETH','4h','0.000239800000000','0.000240530000000','1.146338048113423','1.149827734415019','4780.392193967568','4780.392193967568346','test','test','0.0'),('2018-11-28 11:59:59','2018-11-28 15:59:59','ENJETH','4h','0.000246780000000','0.000236908800000','1.147113533958222','1.101228992599893','4648.324556115657','4648.324556115657288','test','test','4.0'),('2018-11-28 19:59:59','2018-11-29 03:59:59','ENJETH','4h','0.000221380000000','0.000221540000000','1.136916969211927','1.137738663651686','5135.590248495469','5135.590248495468586','test','test','0.0'),('2018-11-29 11:59:59','2018-11-29 15:59:59','ENJETH','4h','0.000234460000000','0.000225081600000','1.137099567976317','1.091615585257264','4849.865938651869','4849.865938651869328','test','test','4.0'),('2018-11-29 19:59:59','2018-12-23 03:59:59','ENJETH','4h','0.000229600000000','0.000338000000000','1.126992016260972','1.659073612788364','4908.501812983329','4908.501812983328819','test','test','3.8'),('2018-12-27 07:59:59','2018-12-28 11:59:59','ENJETH','4h','0.000341280000000','0.000329910000000','1.245232371044837','1.203746517614282','3648.7118232678076','3648.711823267807631','test','test','3.3'),('2019-01-11 15:59:59','2019-01-11 19:59:59','ENJETH','4h','0.000271290000000','0.000273050000000','1.236013292504714','1.244031956645701','4556.059171015202','4556.059171015202082','test','test','0.0'),('2019-01-12 07:59:59','2019-01-12 19:59:59','ENJETH','4h','0.000297960000000','0.000286041600000','1.237795217869378','1.188283409154603','4154.2328428962865','4154.232842896286456','test','test','4.0'),('2019-01-12 23:59:59','2019-01-13 07:59:59','ENJETH','4h','0.000287900000000','0.000277070000000','1.226792593710539','1.180644056753661','4261.176080967484','4261.176080967484268','test','test','3.8'),('2019-01-13 19:59:59','2019-01-14 11:59:59','ENJETH','4h','0.000287220000000','0.000281160000000','1.216537363275677','1.190869873471866','4235.559373566176','4235.559373566175964','test','test','2.6'),('2019-01-15 23:59:59','2019-01-16 15:59:59','ENJETH','4h','0.000285580000000','0.000277550000000','1.210833476652608','1.176786999947235','4239.909925949323','4239.909925949323224','test','test','2.8'),('2019-01-17 07:59:59','2019-01-17 15:59:59','ENJETH','4h','0.000277400000000','0.000277070000000','1.203267592940303','1.201836164296935','4337.662555660788','4337.662555660787802','test','test','0.6'),('2019-01-18 19:59:59','2019-01-19 11:59:59','ENJETH','4h','0.000278140000000','0.000281100000000','1.202949497686221','1.215751433808861','4324.978419810962','4324.978419810961896','test','test','0.5'),('2019-01-19 15:59:59','2019-01-19 23:59:59','ENJETH','4h','0.000277580000000','0.000276320000000','1.205794372380141','1.200320992060237','4343.952634844518','4343.952634844517888','test','test','0.5'),('2019-01-20 23:59:59','2019-01-21 07:59:59','ENJETH','4h','0.000278970000000','0.000280830000000','1.204578065642384','1.212609449669680','4317.948401772177','4317.948401772177021','test','test','0.0'),('2019-01-21 15:59:59','2019-01-21 23:59:59','ENJETH','4h','0.000285220000000','0.000288000000000','1.206362817648450','1.218121069640115','4229.587047361511','4229.587047361511395','test','test','0.0'),('2019-01-23 03:59:59','2019-01-27 15:59:59','ENJETH','4h','0.000301900000000','0.000289824000000','1.208975762535487','1.160616732034068','4004.557014029437','4004.557014029437141','test','test','4.0'),('2019-02-11 11:59:59','2019-02-11 23:59:59','ENJETH','4h','0.000272270000000','0.000261379200000','1.198229311312949','1.150300138860431','4400.886294167368','4400.886294167367851','test','test','4.0'),('2019-02-20 07:59:59','2019-02-20 11:59:59','ENJETH','4h','0.000263680000000','0.000253132800000','1.187578384101279','1.140075248737228','4503.862196986039','4503.862196986038725','test','test','4.0'),('2019-02-20 15:59:59','2019-02-20 19:59:59','ENJETH','4h','0.000257910000000','0.000250230000000','1.177022131798156','1.141972967468701','4563.6932720645045','4563.693272064504526','test','test','3.0'),('2019-02-21 03:59:59','2019-02-21 07:59:59','ENJETH','4h','0.000258680000000','0.000253710000000','1.169233428613833','1.146769031906663','4519.999337458764','4519.999337458763875','test','test','1.9'),('2019-02-22 03:59:59','2019-02-23 19:59:59','ENJETH','4h','0.000262400000000','0.000252060000000','1.164241340456684','1.118363842513383','4436.895352350169','4436.895352350168650','test','test','3.9'),('2019-02-25 03:59:59','2019-03-16 07:59:59','ENJETH','4h','0.000303950000000','0.001167460000000','1.154046340913728','4.432646623336539','3796.829547339129','3796.829547339129022','test','test','0.0'),('2019-03-17 07:59:59','2019-03-24 11:59:59','ENJETH','4h','0.001177280000000','0.001318800000000','1.882624181452131','2.108933108945255','1599.1303525517555','1599.130352551755550','test','test','0.9'),('2019-04-13 07:59:59','2019-04-13 11:59:59','ENJETH','4h','0.000951090000000','0.000924800000000','1.932915054228380','1.879485476821758','2032.3156107501711','2032.315610750171118','test','test','2.8'),('2019-04-13 15:59:59','2019-04-15 03:59:59','ENJETH','4h','0.000928160000000','0.000942080000000','1.921041814804687','1.949852474671608','2069.7313122787955','2069.731312278795485','test','test','0.0'),('2019-04-17 07:59:59','2019-04-20 11:59:59','ENJETH','4h','0.000968200000000','0.001156600000000','1.927444183664002','2.302501490214609','1990.7500347696782','1990.750034769678223','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:54:55
