-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-27 19:59:59','2018-02-27 23:59:59','MCOBTC','4h','0.000812000000000','0.000786000000000','0.033333333333333','0.032266009852216','41.050903119868636','41.050903119868636','test','test','3.2'),('2018-02-28 03:59:59','2018-02-28 07:59:59','MCOBTC','4h','0.000766000000000','0.000744000000000','0.033096150337530','0.032145608160734','43.20646258163127','43.206462581631271','test','test','2.9'),('2018-03-03 03:59:59','2018-03-06 03:59:59','MCOBTC','4h','0.000789000000000','0.000775000000000','0.032884918742686','0.032301409411384','41.679237950172364','41.679237950172364','test','test','1.8'),('2018-03-07 11:59:59','2018-03-07 15:59:59','MCOBTC','4h','0.000803000000000','0.000770880000000','0.032755250002397','0.031445040002301','40.7910958933956','40.791095893395600','test','test','4.0'),('2018-03-11 07:59:59','2018-03-15 03:59:59','MCOBTC','4h','0.000788000000000','0.000824000000000','0.032464092224598','0.033947223341458','41.19808657943852','41.198086579438517','test','test','0.0'),('2018-04-03 07:59:59','2018-04-06 03:59:59','MCOBTC','4h','0.000719000000000','0.000707000000000','0.032793676917233','0.032246355466598','45.610120886276924','45.610120886276924','test','test','1.7'),('2018-04-07 11:59:59','2018-04-09 15:59:59','MCOBTC','4h','0.000728000000000','0.000715000000000','0.032672049928203','0.032088620465199','44.87918946181746','44.879189461817461','test','test','1.8'),('2018-04-09 23:59:59','2018-04-10 03:59:59','MCOBTC','4h','0.000724000000000','0.000730000000000','0.032542398936424','0.032812087325400','44.94806482931553','44.948064829315527','test','test','0.0'),('2018-04-10 07:59:59','2018-04-25 03:59:59','MCOBTC','4h','0.000764000000000','0.001274000000000','0.032602329689530','0.054365664953483','42.67320639990866','42.673206399908658','test','test','1.2'),('2018-04-25 07:59:59','2018-04-25 11:59:59','MCOBTC','4h','0.001296000000000','0.001258000000000','0.037438626414853','0.036340888911948','28.887829023806407','28.887829023806407','test','test','2.9'),('2018-04-27 07:59:59','2018-04-27 11:59:59','MCOBTC','4h','0.001367000000000','0.001312320000000','0.037194684747541','0.035706897357639','27.20898664779875','27.208986647798749','test','test','4.0'),('2018-04-28 19:59:59','2018-04-29 11:59:59','MCOBTC','4h','0.001355000000000','0.001300800000000','0.036864065327563','0.035389502714460','27.205952271263957','27.205952271263957','test','test','4.0'),('2018-05-07 23:59:59','2018-05-08 03:59:59','MCOBTC','4h','0.001288000000000','0.001244000000000','0.036536384746873','0.035288247379744','28.366758343845582','28.366758343845582','test','test','3.4'),('2018-05-13 15:59:59','2018-05-14 03:59:59','MCOBTC','4h','0.001253000000000','0.001202880000000','0.036259020887511','0.034808660052011','28.937766071437437','28.937766071437437','test','test','4.0'),('2018-05-14 11:59:59','2018-05-14 15:59:59','MCOBTC','4h','0.001244000000000','0.001258000000000','0.035936718479622','0.036341151002705','28.88803736304037','28.888037363040372','test','test','0.0'),('2018-05-14 19:59:59','2018-05-16 03:59:59','MCOBTC','4h','0.001292000000000','0.001240320000000','0.036026592373641','0.034585528678695','27.884359422322497','27.884359422322497','test','test','4.0'),('2018-05-16 07:59:59','2018-05-16 11:59:59','MCOBTC','4h','0.001282000000000','0.001230720000000','0.035706355996986','0.034278101757107','27.8520717605195','27.852071760519500','test','test','4.0'),('2018-05-16 15:59:59','2018-05-16 19:59:59','MCOBTC','4h','0.001212000000000','0.001207000000000','0.035388966165902','0.035242972081059','29.198816968565826','29.198816968565826','test','test','0.4'),('2018-05-16 23:59:59','2018-05-17 03:59:59','MCOBTC','4h','0.001199000000000','0.001206000000000','0.035356523035937','0.035562941435646','29.48834281562691','29.488342815626911','test','test','0.0'),('2018-06-03 19:59:59','2018-06-04 07:59:59','MCOBTC','4h','0.000945000000000','0.000917000000000','0.035402393791428','0.034353433975386','37.46285057293921','37.462850572939210','test','test','3.0'),('2018-06-22 23:59:59','2018-06-23 03:59:59','MCOBTC','4h','0.000807000000000','0.000790000000000','0.035169291610085','0.034428426731062','43.580287001344345','43.580287001344345','test','test','2.1'),('2018-06-25 15:59:59','2018-07-10 15:59:59','MCOBTC','4h','0.000795000000000','0.001326000000000','0.035004654970302','0.058385122629711','44.03101254126037','44.031012541260367','test','test','0.0'),('2018-07-16 07:59:59','2018-07-17 07:59:59','MCOBTC','4h','0.001144000000000','0.001146000000000','0.040200314450171','0.040270594720189','35.14013500889043','35.140135008890432','test','test','0.8'),('2018-07-17 11:59:59','2018-07-17 15:59:59','MCOBTC','4h','0.001149000000000','0.001146000000000','0.040215932287952','0.040110929853780','35.0008113907332','35.000811390733197','test','test','0.3'),('2018-07-22 23:59:59','2018-07-23 03:59:59','MCOBTC','4h','0.001083000000000','0.001039680000000','0.040192598413692','0.038584894477144','37.11227923701939','37.112279237019393','test','test','4.0'),('2018-09-04 07:59:59','2018-09-05 11:59:59','MCOBTC','4h','0.000681000000000','0.000653760000000','0.039835330872237','0.038241917637348','58.495346361581326','58.495346361581326','test','test','4.0'),('2018-09-06 15:59:59','2018-09-06 19:59:59','MCOBTC','4h','0.000759000000000','0.000728640000000','0.039481239042262','0.037901989480572','52.0174427434276','52.017442743427601','test','test','4.0'),('2018-09-10 07:59:59','2018-09-11 15:59:59','MCOBTC','4h','0.000693000000000','0.000671000000000','0.039130294695219','0.037888063117593','56.4650717102732','56.465071710273200','test','test','3.2'),('2018-09-13 11:59:59','2018-09-13 19:59:59','MCOBTC','4h','0.000689000000000','0.000682000000000','0.038854243233525','0.038459497656406','56.39222530264827','56.392225302648271','test','test','1.0'),('2018-09-14 19:59:59','2018-09-14 23:59:59','MCOBTC','4h','0.000692000000000','0.000677000000000','0.038766521994165','0.037926207211054','56.02098554070069','56.020985540700693','test','test','2.2'),('2018-09-18 15:59:59','2018-09-18 23:59:59','MCOBTC','4h','0.000682000000000','0.000674000000000','0.038579785375696','0.038127236573635','56.568600257618435','56.568600257618435','test','test','1.2'),('2018-09-20 03:59:59','2018-09-20 11:59:59','MCOBTC','4h','0.000684000000000','0.000676000000000','0.038479218975238','0.038029169630498','56.25616809245288','56.256168092452882','test','test','1.2'),('2018-09-20 23:59:59','2018-09-21 03:59:59','MCOBTC','4h','0.000680000000000','0.000673000000000','0.038379208009740','0.037984127927287','56.440011779029405','56.440011779029405','test','test','1.0'),('2018-09-21 07:59:59','2018-09-21 11:59:59','MCOBTC','4h','0.000680000000000','0.000676000000000','0.038291412435862','0.038066168833298','56.31090064097287','56.310900640972868','test','test','0.6'),('2018-09-25 23:59:59','2018-09-26 11:59:59','MCOBTC','4h','0.000678000000000','0.000673000000000','0.038241358301958','0.037959342385277','56.403183336221886','56.403183336221886','test','test','1.2'),('2018-09-26 15:59:59','2018-09-27 03:59:59','MCOBTC','4h','0.000682000000000','0.000681000000000','0.038178688098252','0.038122707617170','55.98048108248029','55.980481082480289','test','test','0.4'),('2018-09-27 15:59:59','2018-09-27 23:59:59','MCOBTC','4h','0.000677000000000','0.000671000000000','0.038166247991344','0.037827994685660','56.375550947333004','56.375550947333004','test','test','0.9'),('2018-09-29 03:59:59','2018-09-30 11:59:59','MCOBTC','4h','0.000678000000000','0.000676000000000','0.038091080590081','0.037978717520494','56.181534793630284','56.181534793630284','test','test','0.3'),('2018-09-30 19:59:59','2018-09-30 23:59:59','MCOBTC','4h','0.000678000000000','0.000673000000000','0.038066111019062','0.037785387486473','56.14470651779055','56.144706517790553','test','test','0.7'),('2018-10-01 07:59:59','2018-10-01 15:59:59','MCOBTC','4h','0.000682000000000','0.000675000000000','0.038003728011820','0.037613660422256','55.723941366304985','55.723941366304985','test','test','1.0'),('2018-10-01 23:59:59','2018-10-05 11:59:59','MCOBTC','4h','0.000678000000000','0.000683000000000','0.037917046325250','0.038196670560687','55.9248470873897','55.924847087389701','test','test','0.1'),('2018-10-08 23:59:59','2018-10-09 11:59:59','MCOBTC','4h','0.000693000000000','0.000681000000000','0.037979185044236','0.037321536818362','54.80401882285168','54.804018822851681','test','test','1.7'),('2018-10-09 19:59:59','2018-10-11 03:59:59','MCOBTC','4h','0.000692000000000','0.000686000000000','0.037833040994042','0.037505008846695','54.67202455786415','54.672024557864148','test','test','0.9'),('2018-10-18 07:59:59','2018-10-27 19:59:59','MCOBTC','4h','0.000675000000000','0.000727000000000','0.037760144961298','0.040669074647205','55.94095549821958','55.940955498219580','test','test','0.0'),('2018-10-28 15:59:59','2018-10-28 19:59:59','MCOBTC','4h','0.000732000000000','0.000724000000000','0.038406573780389','0.037986829804647','52.46799696774407','52.467996967744071','test','test','1.1'),('2018-11-03 23:59:59','2018-11-04 07:59:59','MCOBTC','4h','0.000708000000000','0.000700000000000','0.038313297341335','0.037880378727309','54.114826753297855','54.114826753297855','test','test','1.1'),('2018-11-16 07:59:59','2018-11-16 11:59:59','MCOBTC','4h','0.000690000000000','0.000683000000000','0.038217093204885','0.037829383563676','55.387091601282116','55.387091601282116','test','test','1.0'),('2018-11-16 15:59:59','2018-11-16 19:59:59','MCOBTC','4h','0.000697000000000','0.000674000000000','0.038130935506838','0.036872669342337','54.70722454352685','54.707224543526848','test','test','3.3'),('2018-12-01 03:59:59','2018-12-01 07:59:59','MCOBTC','4h','0.000585000000000','0.000564000000000','0.037851320803616','0.036492555441435','64.70311248481329','64.703112484813289','test','test','3.6'),('2018-12-01 19:59:59','2018-12-06 11:59:59','MCOBTC','4h','0.000583000000000','0.000590000000000','0.037549372945353','0.038000223049328','64.40715771072612','64.407157710726125','test','test','1.4'),('2018-12-19 11:59:59','2018-12-19 15:59:59','MCOBTC','4h','0.000557000000000','0.000548000000000','0.037649561857348','0.037041220642418','67.59346832557948','67.593468325579479','test','test','1.6'),('2018-12-20 07:59:59','2018-12-20 11:59:59','MCOBTC','4h','0.000565000000000','0.000547000000000','0.037514374920697','0.036319226693135','66.39712375344543','66.397123753445427','test','test','3.2'),('2018-12-20 15:59:59','2018-12-20 19:59:59','MCOBTC','4h','0.000548000000000','0.000546000000000','0.037248786425683','0.037112841949677','67.97223800307094','67.972238003070942','test','test','0.4'),('2018-12-23 03:59:59','2018-12-27 07:59:59','MCOBTC','4h','0.000551000000000','0.000578000000000','0.037218576542126','0.039042354340016','67.54732584777858','67.547325847778581','test','test','0.0'),('2018-12-30 03:59:59','2019-01-01 03:59:59','MCOBTC','4h','0.000579000000000','0.000580000000000','0.037623860497213','0.037688841258003','64.98076078965916','64.980760789659158','test','test','0.0'),('2019-01-02 11:59:59','2019-01-10 07:59:59','MCOBTC','4h','0.000604000000000','0.000638000000000','0.037638300666277','0.039757012955438','62.315067328273344','62.315067328273344','test','test','1.7'),('2019-01-12 03:59:59','2019-01-12 11:59:59','MCOBTC','4h','0.000641000000000','0.000623000000000','0.038109125619424','0.037038978566148','59.452614070864264','59.452614070864264','test','test','2.8'),('2019-01-17 23:59:59','2019-01-18 07:59:59','MCOBTC','4h','0.000627000000000','0.000622000000000','0.037871315163140','0.037569311054981','60.40082163180294','60.400821631802941','test','test','0.8'),('2019-01-18 23:59:59','2019-01-19 11:59:59','MCOBTC','4h','0.000631000000000','0.000635000000000','0.037804203139105','0.038043849434757','59.91157391300333','59.911573913003330','test','test','1.1'),('2019-01-19 15:59:59','2019-01-20 11:59:59','MCOBTC','4h','0.000638000000000','0.000626000000000','0.037857457871472','0.037145405372322','59.33770826249563','59.337708262495632','test','test','1.9'),('2019-01-20 15:59:59','2019-01-20 19:59:59','MCOBTC','4h','0.000632000000000','0.000633000000000','0.037699223982772','0.037758874653631','59.650670858816795','59.650670858816795','test','test','0.0'),('2019-01-23 23:59:59','2019-01-24 03:59:59','MCOBTC','4h','0.000626000000000','0.000621000000000','0.037712479687408','0.037411261798531','60.24357777541142','60.243577775411417','test','test','0.8'),('2019-01-26 11:59:59','2019-01-26 19:59:59','MCOBTC','4h','0.000629000000000','0.000624000000000','0.037645542378768','0.037346293234263','59.849828901062345','59.849828901062345','test','test','0.8'),('2019-02-08 15:59:59','2019-02-08 15:59:59','MCOBTC','4h','0.000584000000000','0.000584000000000','0.037579042568878','0.037579042568878','64.34767563164078','64.347675631640783','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:26:18
