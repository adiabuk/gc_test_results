-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-21 07:59:59','2018-05-21 11:59:59','NEOUSDT','4h','65.659999999999997','63.567999999999998','222.222222222222200','215.141977188885505','3.38443835245541','3.384438352455410','test','test','3.2'),('2018-06-02 07:59:59','2018-06-04 07:59:59','NEOUSDT','4h','56.817000000000000','54.704999999999998','220.648834437036271','212.446881881797140','3.8835002628973068','3.883500262897307','test','test','3.7'),('2018-07-02 11:59:59','2018-07-09 19:59:59','NEOUSDT','4h','32.973999999999997','37.619999999999997','218.826178313649820','249.658543948550545','6.636324932178378','6.636324932178378','test','test','0.0'),('2018-07-16 11:59:59','2018-07-19 19:59:59','NEOUSDT','4h','35.218000000000004','35.810000000000002','225.677815121405530','229.471365764595703','6.408024735118562','6.408024735118562','test','test','0.0'),('2018-07-25 07:59:59','2018-07-25 11:59:59','NEOUSDT','4h','34.871000000000002','33.997000000000000','226.520826375447797','220.843352191967483','6.4959658849888955','6.495965884988895','test','test','2.5'),('2018-07-26 07:59:59','2018-07-26 15:59:59','NEOUSDT','4h','35.174999999999997','34.423000000000002','225.259165445785499','220.443390252744138','6.403956373725245','6.403956373725245','test','test','2.1'),('2018-08-17 23:59:59','2018-08-18 03:59:59','NEOUSDT','4h','20.670000000000002','19.859000000000002','224.188993180665193','215.392801914602330','10.846105136945582','10.846105136945582','test','test','3.9'),('2018-08-27 19:59:59','2018-08-30 11:59:59','NEOUSDT','4h','19.946999999999999','19.149120000000000','222.234284010429036','213.344912650011878','11.141238482500077','11.141238482500077','test','test','4.0'),('2018-08-31 19:59:59','2018-09-05 11:59:59','NEOUSDT','4h','20.180000000000000','21.524999999999999','220.258868152558534','234.939154459059608','10.914711008550968','10.914711008550968','test','test','0.7'),('2018-09-05 15:59:59','2018-09-05 19:59:59','NEOUSDT','4h','21.532000000000000','20.670719999999999','223.521153998447659','214.580307838509754','10.380882128852297','10.380882128852297','test','test','4.0'),('2018-09-20 23:59:59','2018-09-21 03:59:59','NEOUSDT','4h','18.186000000000000','18.265000000000001','221.534299296239197','222.496644487287426','12.18158469681289','12.181584696812889','test','test','0.0'),('2018-09-21 07:59:59','2018-09-24 07:59:59','NEOUSDT','4h','19.149999999999999','18.841999999999999','221.748153783138832','218.181656061718115','11.579538056560775','11.579538056560775','test','test','2.8'),('2018-09-26 15:59:59','2018-09-26 19:59:59','NEOUSDT','4h','18.559999999999999','18.135000000000002','220.955598733934238','215.896001241373796','11.904935276612838','11.904935276612838','test','test','2.3'),('2018-09-27 15:59:59','2018-09-29 03:59:59','NEOUSDT','4h','18.472999999999999','18.638999999999999','219.831243735587464','221.806666593818790','11.900137700188788','11.900137700188788','test','test','0.0'),('2018-10-08 11:59:59','2018-10-09 11:59:59','NEOUSDT','4h','18.408000000000001','18.297000000000001','220.270226592972193','218.941999998457845','11.966005355985017','11.966005355985017','test','test','0.6'),('2018-10-18 11:59:59','2018-10-18 19:59:59','NEOUSDT','4h','17.748999999999999','17.039040000000000','219.975065127524573','211.176062522423621','12.393659649981666','12.393659649981666','test','test','4.0'),('2018-10-22 15:59:59','2018-10-23 03:59:59','NEOUSDT','4h','17.143999999999998','16.884000000000000','218.019731215279904','214.713319052659017','12.716969856234247','12.716969856234247','test','test','1.5'),('2018-11-02 15:59:59','2018-11-02 19:59:59','NEOUSDT','4h','16.138000000000002','16.180000000000000','217.284972956919745','217.850468610915925','13.464182238004692','13.464182238004692','test','test','0.0'),('2018-11-04 07:59:59','2018-11-04 11:59:59','NEOUSDT','4h','16.152000000000001','16.559999999999999','217.410638657807766','222.902437851244201','13.460292140775616','13.460292140775616','test','test','0.0'),('2018-11-04 15:59:59','2018-11-08 19:59:59','NEOUSDT','4h','16.651000000000000','16.460000000000001','218.631038478571412','216.123169380654957','13.13020470113335','13.130204701133350','test','test','1.8'),('2018-12-17 19:59:59','2018-12-27 19:59:59','NEOUSDT','4h','6.592000000000000','6.814000000000000','218.073734234589978','225.417843609601988','33.08157376131523','33.081573761315227','test','test','3.7'),('2018-12-28 15:59:59','2018-12-31 19:59:59','NEOUSDT','4h','7.372000000000000','7.418000000000000','219.705758540148196','221.076684325938629','29.802734473704312','29.802734473704312','test','test','0.0'),('2019-01-01 23:59:59','2019-01-03 19:59:59','NEOUSDT','4h','7.756000000000000','7.480000000000000','220.010408714768317','212.181260596501659','28.36647868937188','28.366478689371881','test','test','3.6'),('2019-01-05 15:59:59','2019-01-10 07:59:59','NEOUSDT','4h','7.737000000000000','8.327999999999999','218.270598021820177','234.943458747023158','28.211270262610853','28.211270262610853','test','test','2.0'),('2019-01-19 11:59:59','2019-01-20 11:59:59','NEOUSDT','4h','7.900000000000000','7.584000000000000','221.975678182976367','213.096651055657304','28.09818711176916','28.098187111769160','test','test','4.0'),('2019-02-02 23:59:59','2019-02-03 03:59:59','NEOUSDT','4h','7.237000000000000','7.119000000000000','220.002561043572115','216.415397549977854','30.399690623679994','30.399690623679994','test','test','1.6'),('2019-02-08 15:59:59','2019-02-24 19:59:59','NEOUSDT','4h','7.413000000000000','9.410000000000000','219.205413600551196','278.257512745337465','29.570405180163387','29.570405180163387','test','test','0.0'),('2019-02-24 23:59:59','2019-02-27 23:59:59','NEOUSDT','4h','8.907999999999999','8.856999999999999','232.328102299392555','230.997979576304431','26.080837707610304','26.080837707610304','test','test','0.7'),('2019-02-28 19:59:59','2019-02-28 23:59:59','NEOUSDT','4h','8.864000000000001','8.813000000000001','232.032519472039695','230.697494822550311','26.176953911556822','26.176953911556822','test','test','0.6'),('2019-03-01 23:59:59','2019-03-02 07:59:59','NEOUSDT','4h','8.946999999999999','8.746000000000000','231.735847327708711','226.529755306598929','25.90095532890452','25.900955328904519','test','test','2.2'),('2019-03-05 19:59:59','2019-03-05 23:59:59','NEOUSDT','4h','8.754000000000000','8.739000000000001','230.578937989684306','230.183840426302424','26.339837558794187','26.339837558794187','test','test','0.2'),('2019-03-06 11:59:59','2019-03-06 15:59:59','NEOUSDT','4h','8.736000000000001','8.689000000000000','230.491138531154974','229.251087762958491','26.384058897797043','26.384058897797043','test','test','0.5'),('2019-03-07 07:59:59','2019-03-07 11:59:59','NEOUSDT','4h','8.779999999999999','8.669000000000000','230.215571693778003','227.305101482159671','26.220452356922326','26.220452356922326','test','test','1.3'),('2019-03-07 19:59:59','2019-03-08 23:59:59','NEOUSDT','4h','9.144000000000000','8.778240000000000','229.568800535640577','220.386048514214934','25.10594931492132','25.105949314921322','test','test','4.0'),('2019-03-09 15:59:59','2019-03-10 07:59:59','NEOUSDT','4h','9.010999999999999','8.755000000000001','227.528188975323786','221.064176504157132','25.250048715494817','25.250048715494817','test','test','2.8'),('2019-03-12 15:59:59','2019-03-12 19:59:59','NEOUSDT','4h','8.789999999999999','8.811000000000000','226.091741759508949','226.631892678388340','25.72147232758919','25.721472327589190','test','test','0.0'),('2019-03-13 03:59:59','2019-03-13 11:59:59','NEOUSDT','4h','8.907000000000000','8.784000000000001','226.211775297037747','223.087934681618918','25.397078174136944','25.397078174136944','test','test','1.4'),('2019-03-13 15:59:59','2019-03-14 07:59:59','NEOUSDT','4h','8.981999999999999','8.779000000000000','225.517588493611328','220.420720261123790','25.10772528318986','25.107725283189861','test','test','2.3'),('2019-03-14 15:59:59','2019-03-18 07:59:59','NEOUSDT','4h','9.090999999999999','9.053000000000001','224.384951108614104','223.447031392177308','24.682097800969544','24.682097800969544','test','test','0.4'),('2019-03-19 15:59:59','2019-03-20 03:59:59','NEOUSDT','4h','9.125000000000000','9.029999999999999','224.176524504961463','221.842631921074172','24.567290356708106','24.567290356708106','test','test','1.0'),('2019-03-20 11:59:59','2019-03-21 15:59:59','NEOUSDT','4h','9.084000000000000','8.920000000000000','223.657881708542050','219.620024751232421','24.621079007985696','24.621079007985696','test','test','1.8'),('2019-03-22 11:59:59','2019-03-24 07:59:59','NEOUSDT','4h','9.143000000000001','9.132000000000000','222.760580162473275','222.492575527037701','24.364057766867905','24.364057766867905','test','test','0.1'),('2019-03-24 23:59:59','2019-03-25 03:59:59','NEOUSDT','4h','9.124000000000001','9.085000000000001','222.701023576820916','221.749101183189168','24.408266503378','24.408266503378002','test','test','0.4'),('2019-03-25 11:59:59','2019-03-25 15:59:59','NEOUSDT','4h','9.268000000000001','8.932000000000000','222.489485267124991','214.423401209102337','24.00620255363886','24.006202553638861','test','test','3.6'),('2019-03-27 11:59:59','2019-04-09 07:59:59','NEOUSDT','4h','9.236000000000001','12.166000000000000','220.697022143119938','290.710261086314063','23.895303393581628','23.895303393581628','test','test','1.0'),('2019-05-02 15:59:59','2019-05-02 19:59:59','NEOUSDT','4h','10.061999999999999','9.853000000000000','236.255519686051940','231.348204677665450','23.47997611668177','23.479976116681769','test','test','2.1'),('2019-05-03 11:59:59','2019-05-03 19:59:59','NEOUSDT','4h','10.016000000000000','9.948000000000000','235.165005239743863','233.568437712157760','23.478934229207653','23.478934229207653','test','test','0.7'),('2019-05-04 03:59:59','2019-05-04 07:59:59','NEOUSDT','4h','9.968999999999999','9.747999999999999','234.810212455835853','229.604769888603442','23.554038765757436','23.554038765757436','test','test','2.2');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:15:59
