-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-30 11:59:59','2018-05-30 15:59:59','ADABTC','4h','0.000028360000000','0.000027340000000','0.033333333333333','0.032134461683121','1175.3643629525152','1175.364362952515194','test','test','3.6'),('2018-05-31 15:59:59','2018-06-04 07:59:59','ADABTC','4h','0.000029820000000','0.000028627200000','0.033066917411064','0.031744240714621','1108.8838836708248','1108.883883670824844','test','test','4.0'),('2018-06-05 19:59:59','2018-06-06 07:59:59','ADABTC','4h','0.000028700000000','0.000028250000000','0.032772989256299','0.032259127055416','1141.9160019616338','1141.916001961633810','test','test','1.6'),('2018-07-01 11:59:59','2018-07-01 15:59:59','ADABTC','4h','0.000022370000000','0.000022060000000','0.032658797656103','0.032206217089568','1459.9373114037849','1459.937311403784861','test','test','1.4'),('2018-07-01 19:59:59','2018-07-02 07:59:59','ADABTC','4h','0.000022050000000','0.000022310000000','0.032558224196873','0.032942130695340','1476.5634556404837','1476.563455640483653','test','test','0.0'),('2018-07-02 15:59:59','2018-07-05 15:59:59','ADABTC','4h','0.000022960000000','0.000022620000000','0.032643536752088','0.032160139430846','1421.7568271815137','1421.756827181513700','test','test','1.5'),('2018-07-13 23:59:59','2018-07-20 19:59:59','ADABTC','4h','0.000022130000000','0.000022270000000','0.032536115125145','0.032741946852100','1470.226621109123','1470.226621109123016','test','test','2.0'),('2018-07-22 15:59:59','2018-07-22 23:59:59','ADABTC','4h','0.000023370000000','0.000022890000000','0.032581855508913','0.031912651801413','1394.1743906252746','1394.174390625274555','test','test','2.1'),('2018-08-09 19:59:59','2018-08-09 23:59:59','ADABTC','4h','0.000019080000000','0.000018710000000','0.032433143573913','0.031804198965823','1699.850292133788','1699.850292133787889','test','test','1.9'),('2018-08-28 19:59:59','2018-08-28 23:59:59','ADABTC','4h','0.000015000000000','0.000014900000000','0.032293378105448','0.032078088918078','2152.8918736965484','2152.891873696548373','test','test','0.7'),('2018-09-01 07:59:59','2018-09-02 03:59:59','ADABTC','4h','0.000014950000000','0.000014710000000','0.032245536063810','0.031727881973154','2156.8920444020364','2156.892044402036390','test','test','1.6'),('2018-09-19 07:59:59','2018-09-19 11:59:59','ADABTC','4h','0.000011560000000','0.000011097600000','0.032130501821442','0.030845281748584','2779.455174865263','2779.455174865262961','test','test','4.0'),('2018-09-19 23:59:59','2018-09-20 03:59:59','ADABTC','4h','0.000011290000000','0.000011320000000','0.031844897360807','0.031929516220047','2820.6286413469734','2820.628641346973382','test','test','0.0'),('2018-09-20 15:59:59','2018-09-25 03:59:59','ADABTC','4h','0.000011690000000','0.000012300000000','0.031863701551750','0.033526392565143','2725.722972775839','2725.722972775839025','test','test','0.3'),('2018-09-25 23:59:59','2018-09-26 03:59:59','ADABTC','4h','0.000012580000000','0.000012076800000','0.032233188443615','0.030943860905870','2562.256633037732','2562.256633037732172','test','test','4.0'),('2018-09-26 15:59:59','2018-09-26 23:59:59','ADABTC','4h','0.000012490000000','0.000012240000000','0.031946671213005','0.031307226232761','2557.7799209771547','2557.779920977154688','test','test','2.0'),('2018-09-27 15:59:59','2018-09-28 11:59:59','ADABTC','4h','0.000012950000000','0.000012432000000','0.031804572328506','0.030532389435366','2455.9515311587643','2455.951531158764283','test','test','4.0'),('2018-09-28 15:59:59','2018-10-03 03:59:59','ADABTC','4h','0.000012700000000','0.000012260000000','0.031521865018919','0.030429768908027','2482.0366156629393','2482.036615662939312','test','test','3.5'),('2018-10-05 23:59:59','2018-10-06 03:59:59','ADABTC','4h','0.000012570000000','0.000012500000000','0.031279176994277','0.031104989055566','2488.3991244452395','2488.399124445239522','test','test','0.6'),('2018-10-07 15:59:59','2018-10-11 03:59:59','ADABTC','4h','0.000012700000000','0.000012310000000','0.031240468563452','0.030281115591818','2459.879414445039','2459.879414445038947','test','test','3.1'),('2018-10-17 19:59:59','2018-10-17 23:59:59','ADABTC','4h','0.000012020000000','0.000011880000000','0.031027279014200','0.030665896396730','2581.3044104991677','2581.304410499167716','test','test','1.2'),('2018-11-02 23:59:59','2018-11-03 07:59:59','ADABTC','4h','0.000011360000000','0.000011280000000','0.030946971765873','0.030729035344987','2724.205261080399','2724.205261080398941','test','test','0.7'),('2018-11-04 03:59:59','2018-11-04 07:59:59','ADABTC','4h','0.000011310000000','0.000011640000000','0.030898541450121','0.031800090404899','2731.966529630494','2731.966529630493824','test','test','0.0'),('2018-11-04 11:59:59','2018-11-09 15:59:59','ADABTC','4h','0.000011630000000','0.000011680000000','0.031098885662294','0.031232586804436','2674.0228428455525','2674.022842845552532','test','test','0.0'),('2018-11-11 07:59:59','2018-11-11 15:59:59','ADABTC','4h','0.000011930000000','0.000011780000000','0.031128597027214','0.030737206452689','2609.270496832709','2609.270496832708886','test','test','1.3'),('2018-11-12 03:59:59','2018-11-12 11:59:59','ADABTC','4h','0.000011940000000','0.000011850000000','0.031041621343986','0.030807639273554','2599.8007825784293','2599.800782578429335','test','test','1.4'),('2018-11-12 15:59:59','2018-11-13 11:59:59','ADABTC','4h','0.000011990000000','0.000011840000000','0.030989625328335','0.030601931933902','2584.622629552534','2584.622629552533908','test','test','1.3'),('2018-11-13 15:59:59','2018-11-13 19:59:59','ADABTC','4h','0.000011830000000','0.000011640000000','0.030903471240683','0.030407134847130','2612.2968081727054','2612.296808172705369','test','test','1.6'),('2018-12-02 03:59:59','2018-12-02 07:59:59','ADABTC','4h','0.000010000000000','0.000009960000000','0.030793174264338','0.030670001567281','3079.3174264337995','3079.317426433799483','test','test','0.4'),('2018-12-03 03:59:59','2018-12-03 15:59:59','ADABTC','4h','0.000010090000000','0.000009900000000','0.030765802553881','0.030186466331360','3049.138013268671','3049.138013268670875','test','test','1.9'),('2018-12-16 15:59:59','2018-12-16 19:59:59','ADABTC','4h','0.000008970000000','0.000009000000000','0.030637061171098','0.030739526258627','3415.5029176252438','3415.502917625243754','test','test','0.0'),('2018-12-17 11:59:59','2018-12-17 15:59:59','ADABTC','4h','0.000008970000000','0.000009180000000','0.030659831190549','0.031377619880629','3418.0413813321434','3418.041381332143374','test','test','0.0'),('2018-12-17 19:59:59','2018-12-27 19:59:59','ADABTC','4h','0.000009330000000','0.000010120000000','0.030819339788345','0.033428908752203','3303.251852984447','3303.251852984446941','test','test','1.5'),('2018-12-28 15:59:59','2019-01-10 15:59:59','ADABTC','4h','0.000010360000000','0.000011970000000','0.031399244002536','0.036278856246173','3030.8150581598024','3030.815058159802447','test','test','0.0'),('2019-01-10 19:59:59','2019-01-11 07:59:59','ADABTC','4h','0.000012000000000','0.000012110000000','0.032483602278899','0.032781368633122','2706.966856574944','2706.966856574943904','test','test','0.4'),('2019-01-14 19:59:59','2019-01-15 03:59:59','ADABTC','4h','0.000011920000000','0.000011900000000','0.032549772579838','0.032495158867456','2730.6856191139077','2730.685619113907705','test','test','0.2'),('2019-01-15 23:59:59','2019-01-16 03:59:59','ADABTC','4h','0.000011830000000','0.000012010000000','0.032537636199308','0.033032714349424','2750.4341673126323','2750.434167312632326','test','test','0.0'),('2019-01-16 07:59:59','2019-01-20 15:59:59','ADABTC','4h','0.000012050000000','0.000012040000000','0.032647653566001','0.032620560077564','2709.3488436515263','2709.348843651526295','test','test','0.1'),('2019-01-22 19:59:59','2019-01-23 07:59:59','ADABTC','4h','0.000012180000000','0.000012090000000','0.032641632790793','0.032400438459827','2679.937010738314','2679.937010738313802','test','test','0.7'),('2019-01-23 15:59:59','2019-01-23 19:59:59','ADABTC','4h','0.000012140000000','0.000012050000000','0.032588034050578','0.032346442364865','2684.3520634742995','2684.352063474299484','test','test','0.7'),('2019-02-08 15:59:59','2019-02-08 19:59:59','ADABTC','4h','0.000011360000000','0.000011240000000','0.032534347009308','0.032190674329632','2863.9389972982785','2863.938997298278537','test','test','1.1'),('2019-02-08 23:59:59','2019-02-10 07:59:59','ADABTC','4h','0.000011130000000','0.000011140000000','0.032457975302714','0.032487137904064','2916.2601350147147','2916.260135014714706','test','test','0.0'),('2019-02-10 19:59:59','2019-02-14 03:59:59','ADABTC','4h','0.000011450000000','0.000011330000000','0.032464455880792','0.032124217041867','2835.3236577110524','2835.323657711052419','test','test','1.3'),('2019-02-16 15:59:59','2019-02-17 03:59:59','ADABTC','4h','0.000011340000000','0.000011290000000','0.032388847249919','0.032246039281445','2856.1593694814223','2856.159369481422345','test','test','0.4'),('2019-02-17 11:59:59','2019-02-17 15:59:59','ADABTC','4h','0.000011310000000','0.000011240000000','0.032357112145814','0.032156847083904','2860.929455863307','2860.929455863306885','test','test','0.6'),('2019-02-17 23:59:59','2019-02-18 03:59:59','ADABTC','4h','0.000011340000000','0.000011540000000','0.032312608798723','0.032882496079124','2849.436402003782','2849.436402003781950','test','test','0.0'),('2019-02-18 07:59:59','2019-02-21 11:59:59','ADABTC','4h','0.000011490000000','0.000011460000000','0.032439250416590','0.032354552634823','2823.259392218431','2823.259392218431003','test','test','0.3'),('2019-02-23 19:59:59','2019-02-24 15:59:59','ADABTC','4h','0.000011730000000','0.000011310000000','0.032420428687308','0.031259594923568','2763.889913666515','2763.889913666514985','test','test','3.6'),('2019-03-09 07:59:59','2019-04-02 07:59:59','ADABTC','4h','0.000011250000000','0.000016690000000','0.032162465628699','0.047714804563821','2858.8858336621624','2858.885833662162440','test','test','0.0'),('2019-04-02 11:59:59','2019-04-08 03:59:59','ADABTC','4h','0.000016660000000','0.000016860000000','0.035618540947615','0.036046134476398','2137.9676439144855','2137.967643914485507','test','test','0.0'),('2019-05-15 15:59:59','2019-05-15 19:59:59','ADABTC','4h','0.000011010000000','0.000010970000000','0.035713561731789','0.035583812188713','3243.7385769109296','3243.738576910929623','test','test','0.4'),('2019-05-15 23:59:59','2019-05-16 11:59:59','ADABTC','4h','0.000011490000000','0.000011030400000','0.035684728499995','0.034257339359995','3105.720496083087','3105.720496083086800','test','test','4.0'),('2019-05-17 03:59:59','2019-05-17 07:59:59','ADABTC','4h','0.000011030000000','0.000010980000000','0.035367530913328','0.035207206657148','3206.485123601813','3206.485123601813029','test','test','0.5');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:29:55
