-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-29 15:59:59','2018-05-03 19:59:59','EOSBTC','4h','0.000828000000000','0.001886300000000','0.033333333333333','0.075938003220611','40.25764895330113','40.257648953301128','test','test','3.4'),('2018-05-05 03:59:59','2018-05-05 15:59:59','EOSBTC','4h','0.001860000000000','0.001798000000000','0.042801037752728','0.041374336494304','23.011310619746478','23.011310619746478','test','test','3.3'),('2018-05-06 15:59:59','2018-05-06 23:59:59','EOSBTC','4h','0.001845000000000','0.001798100000000','0.042483993028634','0.041404047623191','23.02655448706462','23.026554487064619','test','test','2.5'),('2018-05-07 03:59:59','2018-05-11 07:59:59','EOSBTC','4h','0.001812500000000','0.001751100000000','0.042244005160758','0.040812953068691','23.307037330073378','23.307037330073378','test','test','3.4'),('2018-05-24 23:59:59','2018-05-25 07:59:59','EOSBTC','4h','0.001680700000000','0.001613472000000','0.041925993584743','0.040248953841353','24.94555458127156','24.945554581271558','test','test','4.0'),('2018-05-25 11:59:59','2018-05-28 15:59:59','EOSBTC','4h','0.001635900000000','0.001658700000000','0.041553318086212','0.042132458407971','25.40089130522159','25.400891305221592','test','test','1.1'),('2018-05-29 03:59:59','2018-05-29 07:59:59','EOSBTC','4h','0.001630500000000','0.001565280000000','0.041682015935492','0.040014735298072','25.563947215879654','25.563947215879654','test','test','4.0'),('2018-05-31 19:59:59','2018-06-01 03:59:59','EOSBTC','4h','0.001654900000000','0.001643500000000','0.041311509127176','0.041026929270961','24.963145281996628','24.963145281996628','test','test','1.3'),('2018-06-02 11:59:59','2018-06-10 11:59:59','EOSBTC','4h','0.001820900000000','0.001841600000000','0.041248269159128','0.041717179682273','22.65268227751576','22.652682277515758','test','test','3.4'),('2018-06-10 19:59:59','2018-06-10 23:59:59','EOSBTC','4h','0.001812700000000','0.001740192000000','0.041352471497605','0.039698372637701','22.812639431568993','22.812639431568993','test','test','4.0'),('2018-07-03 19:59:59','2018-07-03 23:59:59','EOSBTC','4h','0.001362400000000','0.001357200000000','0.040984893973182','0.040828463080155','30.08286404373312','30.082864043733121','test','test','0.4'),('2018-07-04 15:59:59','2018-07-04 23:59:59','EOSBTC','4h','0.001367200000000','0.001351600000000','0.040950131552509','0.040482883123443','29.95182237603082','29.951822376030819','test','test','1.1'),('2018-07-16 15:59:59','2018-07-16 23:59:59','EOSBTC','4h','0.001199600000000','0.001203400000000','0.040846298568272','0.040975688310319','34.04993211759957','34.049932117599568','test','test','0.0'),('2018-07-17 19:59:59','2018-07-18 11:59:59','EOSBTC','4h','0.001200600000000','0.001198100000000','0.040875051844283','0.040789938043175','34.04552044334741','34.045520443347407','test','test','0.2'),('2018-08-05 03:59:59','2018-08-05 11:59:59','EOSBTC','4h','0.001008500000000','0.000995100000000','0.040856137666259','0.040313279714124','40.51178747274059','40.511787472740593','test','test','1.3'),('2018-08-05 15:59:59','2018-08-05 23:59:59','EOSBTC','4h','0.001001000000000','0.001001000000000','0.040735502565784','0.040735502565784','40.69480775802642','40.694807758026421','test','test','0.2'),('2018-08-06 03:59:59','2018-08-06 07:59:59','EOSBTC','4h','0.000998700000000','0.001001100000000','0.040735502565784','0.040833395032148','40.7885276517317','40.788527651731698','test','test','0.0'),('2018-08-07 15:59:59','2018-08-07 19:59:59','EOSBTC','4h','0.000999100000000','0.000993300000000','0.040757256447199','0.040520651415277','40.79397102111767','40.793971021117670','test','test','0.6'),('2018-08-17 23:59:59','2018-08-18 07:59:59','EOSBTC','4h','0.000848800000000','0.000814848000000','0.040704677551216','0.039076490449167','47.95555790671065','47.955557906710652','test','test','4.0'),('2018-08-27 15:59:59','2018-08-27 19:59:59','EOSBTC','4h','0.000771200000000','0.000774900000000','0.040342858195205','0.040536411845778','52.311797452288786','52.311797452288786','test','test','0.0'),('2018-08-27 23:59:59','2018-08-28 15:59:59','EOSBTC','4h','0.000780300000000','0.000769900000000','0.040385870117555','0.039847598876721','51.75685008016745','51.756850080167453','test','test','1.3'),('2018-08-28 19:59:59','2018-09-05 11:59:59','EOSBTC','4h','0.000823500000000','0.000830600000000','0.040266254286258','0.040613419320177','48.89648365058679','48.896483650586788','test','test','0.0'),('2018-09-13 15:59:59','2018-09-14 11:59:59','EOSBTC','4h','0.000817400000000','0.000810900000000','0.040343402071574','0.040022589600978','49.355764707087786','49.355764707087786','test','test','0.8'),('2018-09-15 11:59:59','2018-09-17 15:59:59','EOSBTC','4h','0.000831800000000','0.000798528000000','0.040272110411441','0.038661225994983','48.41561722943148','48.415617229431483','test','test','4.0'),('2018-09-19 19:59:59','2018-09-25 03:59:59','EOSBTC','4h','0.000820000000000','0.000834600000000','0.039914136096673','0.040624802422297','48.6757757276496','48.675775727649601','test','test','0.4'),('2018-09-26 15:59:59','2018-09-27 11:59:59','EOSBTC','4h','0.000860900000000','0.000857100000000','0.040072061946811','0.039895184451866','46.54670919597089','46.546709195970891','test','test','1.2'),('2018-09-27 15:59:59','2018-09-29 07:59:59','EOSBTC','4h','0.000853200000000','0.000860800000000','0.040032755836824','0.040389353286847','46.92071710832579','46.920717108325789','test','test','0.0'),('2018-09-30 11:59:59','2018-09-30 23:59:59','EOSBTC','4h','0.000878800000000','0.000863200000000','0.040111999714606','0.039399952382394','45.64405975717621','45.644059757176208','test','test','1.8'),('2018-10-01 23:59:59','2018-10-02 07:59:59','EOSBTC','4h','0.000868800000000','0.000863200000000','0.039953766974115','0.039696238089383','45.98730084497571','45.987300844975707','test','test','0.6'),('2018-10-02 23:59:59','2018-10-03 03:59:59','EOSBTC','4h','0.000859800000000','0.000848200000000','0.039896538333063','0.039358273801005','46.402114832592865','46.402114832592865','test','test','1.3'),('2018-10-03 15:59:59','2018-10-03 19:59:59','EOSBTC','4h','0.000857900000000','0.000852200000000','0.039776923992606','0.039512640898122','46.365455172637844','46.365455172637844','test','test','0.7'),('2018-10-04 07:59:59','2018-10-04 11:59:59','EOSBTC','4h','0.000857900000000','0.000863400000000','0.039718194416054','0.039972827903976','46.2969978040028','46.296997804002800','test','test','0.0'),('2018-10-04 15:59:59','2018-10-06 19:59:59','EOSBTC','4h','0.000870800000000','0.000865500000000','0.039774779635592','0.039532696112316','45.676136467147714','45.676136467147714','test','test','0.6'),('2018-10-08 07:59:59','2018-10-11 03:59:59','EOSBTC','4h','0.000870500000000','0.000858400000000','0.039720983297086','0.039168859347753','45.63007845730781','45.630078457307810','test','test','1.4'),('2018-10-21 03:59:59','2018-10-21 11:59:59','EOSBTC','4h','0.000839800000000','0.000837200000000','0.039598289086124','0.039475693763876','47.15204701848483','47.152047018484829','test','test','0.3'),('2018-10-21 15:59:59','2018-10-21 19:59:59','EOSBTC','4h','0.000838100000000','0.000836000000000','0.039571045681180','0.039471893794853','47.215183965134905','47.215183965134905','test','test','0.3'),('2018-10-21 23:59:59','2018-10-22 03:59:59','EOSBTC','4h','0.000836300000000','0.000835400000000','0.039549011928662','0.039506450514414','47.29046027581304','47.290460275813039','test','test','0.1'),('2018-10-28 15:59:59','2018-10-29 07:59:59','EOSBTC','4h','0.000836800000000','0.000835100000000','0.039539553836607','0.039459227305151','47.25090085636632','47.250900856366322','test','test','0.2'),('2018-10-29 11:59:59','2018-10-29 15:59:59','EOSBTC','4h','0.000837500000000','0.000811400000000','0.039521703496284','0.038290042050012','47.190093726906014','47.190093726906014','test','test','3.1'),('2018-11-02 11:59:59','2018-11-02 15:59:59','EOSBTC','4h','0.000828200000000','0.000839700000000','0.039248000952668','0.039792980439453','47.389520590035964','47.389520590035964','test','test','0.0'),('2018-11-03 23:59:59','2018-11-08 23:59:59','EOSBTC','4h','0.000834600000000','0.000852500000000','0.039369107505287','0.040213472499709','47.17122873866124','47.171228738661242','test','test','0.2'),('2018-11-12 19:59:59','2018-11-12 23:59:59','EOSBTC','4h','0.000846000000000','0.000845400000000','0.039556744170714','0.039528689742224','46.75738081644656','46.757380816446563','test','test','0.1'),('2018-11-19 23:59:59','2018-11-20 07:59:59','EOSBTC','4h','0.000839500000000','0.000818400000000','0.039550509853272','0.038556447008836','47.111983148626045','47.111983148626045','test','test','2.5'),('2018-11-20 23:59:59','2018-11-21 03:59:59','EOSBTC','4h','0.000835100000000','0.000824800000000','0.039329606998952','0.038844521437835','47.09568554538672','47.095685545386722','test','test','1.2'),('2018-11-23 03:59:59','2018-11-23 07:59:59','EOSBTC','4h','0.000833900000000','0.000838400000000','0.039221810207593','0.039433464058096','47.03418900059133','47.034189000591333','test','test','0.0'),('2018-11-24 23:59:59','2018-11-25 03:59:59','EOSBTC','4h','0.000840300000000','0.000835900000000','0.039268844396594','0.039063223885651','46.731934305121726','46.731934305121726','test','test','0.5'),('2018-11-25 07:59:59','2018-11-25 23:59:59','EOSBTC','4h','0.000835500000000','0.000833300000000','0.039223150949718','0.039119870360742','46.945722261780446','46.945722261780446','test','test','0.3'),('2018-11-26 11:59:59','2018-11-26 15:59:59','EOSBTC','4h','0.000832300000000','0.000846500000000','0.039200199707723','0.039869000423630','47.098641965304445','47.098641965304445','test','test','0.0'),('2018-11-26 19:59:59','2018-11-26 23:59:59','EOSBTC','4h','0.000842000000000','0.000842200000000','0.039348822089036','0.039358168602596','46.732567801704946','46.732567801704946','test','test','0.0'),('2018-12-15 23:59:59','2018-12-25 11:59:59','EOSBTC','4h','0.000586600000000','0.000658700000000','0.039350899092049','0.044187584779974','67.08301924999813','67.083019249998131','test','test','0.0'),('2018-12-26 03:59:59','2018-12-27 07:59:59','EOSBTC','4h','0.000675000000000','0.000656400000000','0.040425718133810','0.039311765011901','59.88995279082963','59.889952790829632','test','test','2.8'),('2018-12-28 19:59:59','2018-12-31 11:59:59','EOSBTC','4h','0.000684100000000','0.000671800000000','0.040178172995608','0.039455776375456','58.731432532682376','58.731432532682376','test','test','1.8'),('2019-01-01 11:59:59','2019-01-07 03:59:59','EOSBTC','4h','0.000693100000000','0.000694000000000','0.040017640413352','0.040069603876593','57.737181378375425','57.737181378375425','test','test','0.6'),('2019-01-09 15:59:59','2019-01-10 11:59:59','EOSBTC','4h','0.000703400000000','0.000677800000000','0.040029187849628','0.038572339386520','56.90814309017314','56.908143090173141','test','test','3.6'),('2019-01-17 11:59:59','2019-01-17 15:59:59','EOSBTC','4h','0.000672400000000','0.000673000000000','0.039705443746715','0.039740873946370','59.050332758350535','59.050332758350535','test','test','0.0'),('2019-01-17 19:59:59','2019-01-18 11:59:59','EOSBTC','4h','0.000682700000000','0.000676900000000','0.039713317124416','0.039375925533202','58.17096400236709','58.170964002367093','test','test','0.8'),('2019-01-22 19:59:59','2019-01-26 23:59:59','EOSBTC','4h','0.000687900000000','0.000674500000000','0.039638341215257','0.038866203154079','57.62224337150362','57.622243371503622','test','test','1.9'),('2019-01-27 03:59:59','2019-01-27 11:59:59','EOSBTC','4h','0.000677300000000','0.000669500000000','0.039466754979440','0.039012243405780','58.27071457174073','58.270714571740733','test','test','1.2'),('2019-02-02 23:59:59','2019-02-06 03:59:59','EOSBTC','4h','0.000695900000000','0.000679200000000','0.039365752407516','0.038421064858722','56.5681166942313','56.568116694231300','test','test','2.4'),('2019-02-07 03:59:59','2019-02-25 11:59:59','EOSBTC','4h','0.000693000000000','0.000896200000000','0.039155821841117','0.050637009428584','56.5019074186391','56.501907418639099','test','test','0.5'),('2019-02-25 15:59:59','2019-02-25 23:59:59','EOSBTC','4h','0.000935800000000','0.000925700000000','0.041707196860554','0.041257055069261','44.56849418738407','44.568494187384069','test','test','1.1'),('2019-02-27 23:59:59','2019-03-01 23:59:59','EOSBTC','4h','0.000917600000000','0.000907400000000','0.041607165351378','0.041144661987620','45.343467035067334','45.343467035067334','test','test','1.1'),('2019-03-02 03:59:59','2019-03-02 07:59:59','EOSBTC','4h','0.000913400000000','0.000910200000000','0.041504386826098','0.041358980609935','45.439442551016235','45.439442551016235','test','test','0.4'),('2019-03-03 11:59:59','2019-03-04 03:59:59','EOSBTC','4h','0.000926000000000','0.000909000000000','0.041472074333618','0.040710707958163','44.786257379716595','44.786257379716595','test','test','1.8'),('2019-03-05 15:59:59','2019-03-08 23:59:59','EOSBTC','4h','0.000946300000000','0.000928400000000','0.041302881805739','0.040521605694228','43.646710140271246','43.646710140271246','test','test','1.9'),('2019-03-09 07:59:59','2019-03-11 07:59:59','EOSBTC','4h','0.000958500000000','0.000926900000000','0.041129264892070','0.039773307906583','42.910031186301055','42.910031186301055','test','test','3.3'),('2019-03-12 11:59:59','2019-03-12 15:59:59','EOSBTC','4h','0.000942400000000','0.000935900000000','0.040827941117517','0.040546339231626','43.323367060183465','43.323367060183465','test','test','0.7'),('2019-03-15 11:59:59','2019-03-18 03:59:59','EOSBTC','4h','0.000941600000000','0.000935700000000','0.040765362920652','0.040509929996659','43.29371593102403','43.293715931024032','test','test','0.6'),('2019-03-25 23:59:59','2019-03-26 03:59:59','EOSBTC','4h','0.000927300000000','0.000921400000000','0.040708600048654','0.040449589221212','43.900140244423355','43.900140244423355','test','test','0.6'),('2019-03-26 11:59:59','2019-03-28 15:59:59','EOSBTC','4h','0.000924700000000','0.001065800000000','0.040651042087000','0.046853985786011','43.96133025521791','43.961330255217909','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:44:36
