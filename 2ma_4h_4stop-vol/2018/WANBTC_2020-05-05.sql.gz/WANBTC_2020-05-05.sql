-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-16 19:59:59','2018-09-17 11:59:59','WANBTC','4h','0.000152800000000','0.000151000000000','0.033333333333333','0.032940663176265','218.1500872600349','218.150087260034894','test','test','2.6'),('2018-09-20 15:59:59','2018-09-20 19:59:59','WANBTC','4h','0.000145900000000','0.000143500000000','0.033246073298429','0.032699187925460','227.8689054039022','227.868905403902204','test','test','1.6'),('2018-09-20 23:59:59','2018-09-21 11:59:59','WANBTC','4h','0.000150100000000','0.000149600000000','0.033124543215547','0.033014201632551','220.6831659929869','220.683165992986886','test','test','0.3'),('2018-09-21 15:59:59','2018-09-22 11:59:59','WANBTC','4h','0.000146700000000','0.000147600000000','0.033100022863770','0.033303090488701','225.63069436789667','225.630694367896666','test','test','0.0'),('2018-09-22 19:59:59','2018-09-24 11:59:59','WANBTC','4h','0.000149200000000','0.000143700000000','0.033145149002644','0.031923310400000','222.15247320806967','222.152473208069665','test','test','3.7'),('2018-09-30 23:59:59','2018-10-01 15:59:59','WANBTC','4h','0.000147000000000','0.000146700000000','0.032873629313168','0.032806540273753','223.63013138209217','223.630131382092173','test','test','0.2'),('2018-10-01 19:59:59','2018-10-03 03:59:59','WANBTC','4h','0.000151800000000','0.000148800000000','0.032858720637742','0.032209338806957','216.460610261805','216.460610261804987','test','test','2.0'),('2018-10-04 15:59:59','2018-10-11 03:59:59','WANBTC','4h','0.000158200000000','0.000154300000000','0.032714413564234','0.031907926757025','206.79148902802922','206.791489028029218','test','test','2.5'),('2018-10-17 07:59:59','2018-10-17 11:59:59','WANBTC','4h','0.000155500000000','0.000154500000000','0.032535194273743','0.032325964728574','209.22954516876737','209.229545168767373','test','test','0.6'),('2018-10-17 15:59:59','2018-10-18 03:59:59','WANBTC','4h','0.000161700000000','0.000158200000000','0.032488698819261','0.031785480230100','200.91959690328588','200.919596903285878','test','test','2.2'),('2018-10-18 15:59:59','2018-10-18 19:59:59','WANBTC','4h','0.000154700000000','0.000151700000000','0.032332428021670','0.031705425539026','209.00082754796384','209.000827547963837','test','test','1.9'),('2018-10-24 15:59:59','2018-10-25 03:59:59','WANBTC','4h','0.000157000000000','0.000154200000000','0.032193094136638','0.031618949782609','205.05155501043308','205.051555010433077','test','test','1.8'),('2018-10-25 07:59:59','2018-10-27 15:59:59','WANBTC','4h','0.000157500000000','0.000158400000000','0.032065506502409','0.032248737968137','203.59051747561483','203.590517475614831','test','test','0.0'),('2018-10-28 23:59:59','2018-10-29 15:59:59','WANBTC','4h','0.000165400000000','0.000165800000000','0.032106224605904','0.032183869647273','194.1126034214295','194.112603421429498','test','test','1.8'),('2018-10-29 19:59:59','2018-11-03 03:59:59','WANBTC','4h','0.000161700000000','0.000165300000000','0.032123479059542','0.032838658556229','198.66097130205318','198.660971302053184','test','test','0.1'),('2018-12-02 03:59:59','2018-12-02 07:59:59','WANBTC','4h','0.000105900000000','0.000105000000000','0.032282407836584','0.032008053095763','304.838600912026','304.838600912025981','test','test','0.8'),('2018-12-04 15:59:59','2018-12-04 19:59:59','WANBTC','4h','0.000105000000000','0.000103900000000','0.032221440116401','0.031883882172324','306.87085825143913','306.870858251439131','test','test','1.0'),('2018-12-19 19:59:59','2018-12-19 23:59:59','WANBTC','4h','0.000095300000000','0.000092500000000','0.032146427239940','0.031201936198263','337.31822917040455','337.318229170404550','test','test','2.9'),('2018-12-20 19:59:59','2018-12-21 03:59:59','WANBTC','4h','0.000095200000000','0.000093200000000','0.031936540341789','0.031265604620323','335.4678607330789','335.467860733078908','test','test','2.1'),('2018-12-21 11:59:59','2018-12-21 15:59:59','WANBTC','4h','0.000095100000000','0.000101000000000','0.031787443514797','0.033759535173444','334.25282349943916','334.252823499439160','test','test','0.0'),('2018-12-21 19:59:59','2018-12-25 03:59:59','WANBTC','4h','0.000097500000000','0.000094700000000','0.032225686105607','0.031300230504625','330.5198574934063','330.519857493406278','test','test','2.9'),('2019-01-05 03:59:59','2019-01-07 11:59:59','WANBTC','4h','0.000093100000000','0.000092200000000','0.032020029305389','0.031710490891051','343.93157148645423','343.931571486454231','test','test','1.0'),('2019-01-16 15:59:59','2019-01-16 19:59:59','WANBTC','4h','0.000087800000000','0.000087700000000','0.031951242991092','0.031914852053745','363.9093734748468','363.909373474846802','test','test','0.1'),('2019-01-17 03:59:59','2019-01-20 11:59:59','WANBTC','4h','0.000091700000000','0.000088032000000','0.031943156116126','0.030665429871481','348.3441234037684','348.344123403768378','test','test','4.0'),('2019-01-21 23:59:59','2019-01-22 11:59:59','WANBTC','4h','0.000090700000000','0.000090800000000','0.031659216950649','0.031694122371763','349.0542111427662','349.054211142766178','test','test','0.0'),('2019-01-22 15:59:59','2019-01-23 19:59:59','WANBTC','4h','0.000091300000000','0.000089000000000','0.031666973710896','0.030869229575791','346.8452761324912','346.845276132491222','test','test','2.5'),('2019-01-26 11:59:59','2019-01-27 15:59:59','WANBTC','4h','0.000091100000000','0.000087800000000','0.031489697236429','0.030349016655966','345.6607819586023','345.660781958602286','test','test','3.6'),('2019-02-06 19:59:59','2019-02-06 23:59:59','WANBTC','4h','0.000082600000000','0.000082900000000','0.031236212662992','0.031349661377264','378.1623809078988','378.162380907898807','test','test','0.0'),('2019-02-07 07:59:59','2019-02-07 15:59:59','WANBTC','4h','0.000083000000000','0.000080100000000','0.031261423488386','0.030169156884575','376.64365648658094','376.643656486580937','test','test','3.5'),('2019-02-11 23:59:59','2019-02-12 03:59:59','WANBTC','4h','0.000080700000000','0.000079800000000','0.031018697576428','0.030672764146208','384.3704780226546','384.370478022654595','test','test','1.1'),('2019-02-12 07:59:59','2019-02-12 11:59:59','WANBTC','4h','0.000081100000000','0.000081000000000','0.030941823480824','0.030903670800823','381.5268000101575','381.526800010157501','test','test','0.1'),('2019-02-12 15:59:59','2019-02-12 23:59:59','WANBTC','4h','0.000081600000000','0.000081100000000','0.030933345107490','0.030743802551684','379.0851116113998','379.085111611399782','test','test','0.6'),('2019-02-17 23:59:59','2019-02-18 03:59:59','WANBTC','4h','0.000079900000000','0.000079600000000','0.030891224539533','0.030775237463665','386.62358622695035','386.623586226950351','test','test','0.4'),('2019-02-24 03:59:59','2019-02-24 15:59:59','WANBTC','4h','0.000079400000000','0.000076900000000','0.030865449633785','0.029893615577306','388.73362259174917','388.733622591749167','test','test','3.1'),('2019-02-26 07:59:59','2019-02-26 11:59:59','WANBTC','4h','0.000078200000000','0.000078200000000','0.030649486510123','0.030649486510123','391.9371676486303','391.937167648630293','test','test','0.0'),('2019-02-26 15:59:59','2019-03-04 07:59:59','WANBTC','4h','0.000078200000000','0.000078500000000','0.030649486510123','0.030767067660418','391.9371676486303','391.937167648630293','test','test','0.0'),('2019-03-07 19:59:59','2019-03-17 03:59:59','WANBTC','4h','0.000081400000000','0.000101100000000','0.030675615654633','0.038099566863432','376.85031516748023','376.850315167480233','test','test','1.4'),('2019-03-19 07:59:59','2019-03-19 11:59:59','WANBTC','4h','0.000103900000000','0.000100900000000','0.032325382589922','0.031392022168654','311.12014042272904','311.120140422729037','test','test','2.9'),('2019-03-19 19:59:59','2019-03-19 23:59:59','WANBTC','4h','0.000102500000000','0.000100600000000','0.032117969162973','0.031522611685806','313.3460406143718','313.346040614371816','test','test','1.9'),('2019-03-23 07:59:59','2019-03-23 11:59:59','WANBTC','4h','0.000101900000000','0.000101100000000','0.031985667501380','0.031734553330614','313.89271345810056','313.892713458100559','test','test','0.8'),('2019-03-23 19:59:59','2019-03-24 11:59:59','WANBTC','4h','0.000104500000000','0.000102200000000','0.031929864352321','0.031227101787629','305.5489411705391','305.548941170539081','test','test','2.2'),('2019-03-24 19:59:59','2019-03-24 23:59:59','WANBTC','4h','0.000101600000000','0.000101600000000','0.031773694893501','0.031773694893501','312.73321745571735','312.733217455717352','test','test','0.0'),('2019-03-27 03:59:59','2019-03-27 07:59:59','WANBTC','4h','0.000101600000000','0.000103400000000','0.031773694893501','0.032336614684921','312.73321745571735','312.733217455717352','test','test','0.0'),('2019-03-27 11:59:59','2019-03-27 15:59:59','WANBTC','4h','0.000102700000000','0.000100000000000','0.031898788180483','0.031060163758990','310.60163758990365','310.601637589903646','test','test','2.6'),('2019-03-28 07:59:59','2019-03-29 11:59:59','WANBTC','4h','0.000102200000000','0.000101200000000','0.031712427197929','0.031402129475836','310.2977220932398','310.297722093239827','test','test','1.0'),('2019-03-29 15:59:59','2019-03-30 03:59:59','WANBTC','4h','0.000103500000000','0.000101600000000','0.031643472148575','0.031062577490775','305.7340304210156','305.734030421015575','test','test','1.8'),('2019-03-31 11:59:59','2019-04-02 03:59:59','WANBTC','4h','0.000103500000000','0.000103500000000','0.031514384446842','0.031514384446842','304.486806249679','304.486806249678978','test','test','0.0'),('2019-04-19 07:59:59','2019-04-19 19:59:59','WANBTC','4h','0.000085300000000','0.000084600000000','0.031514384446842','0.031255766989482','369.45351051397154','369.453510513971537','test','test','1.6'),('2019-05-16 03:59:59','2019-05-16 07:59:59','WANBTC','4h','0.000053200000000','0.000053000000000','0.031456913900762','0.031338654825947','591.2953740744695','591.295374074469464','test','test','0.4'),('2019-05-18 03:59:59','2019-05-18 11:59:59','WANBTC','4h','0.000054600000000','0.000053000000000','0.031430634106358','0.030509589883461','575.6526393105942','575.652639310594168','test','test','2.9'),('2019-05-18 23:59:59','2019-05-19 03:59:59','WANBTC','4h','0.000054500000000','0.000052320000000','0.031225957612381','0.029976919307886','572.953350685896','572.953350685895998','test','test','4.0'),('2019-05-22 07:59:59','2019-05-22 11:59:59','WANBTC','4h','0.000053000000000','0.000050880000000','0.030948393544716','0.029710457802927','583.9319536738826','583.931953673882617','test','test','4.0'),('2019-05-22 19:59:59','2019-05-22 23:59:59','WANBTC','4h','0.000053600000000','0.000052200000000','0.030673296713207','0.029872128515474','572.2629983807296','572.262998380729641','test','test','2.6'),('2019-05-23 03:59:59','2019-05-23 07:59:59','WANBTC','4h','0.000053300000000','0.000051168000000','0.030495259335933','0.029275448962496','572.1437023627225','572.143702362722479','test','test','4.0'),('2019-05-23 11:59:59','2019-05-24 15:59:59','WANBTC','4h','0.000053300000000','0.000053200000000','0.030224190364058','0.030167484566002','567.0579805639439','567.057980563943943','test','test','0.2'),('2019-05-30 07:59:59','2019-05-30 15:59:59','WANBTC','4h','0.000051300000000','0.000049248000000','0.030211589075601','0.029003125512577','588.9198650214684','588.919865021468354','test','test','4.0'),('2019-06-02 11:59:59','2019-06-11 19:59:59','WANBTC','4h','0.000054600000000','0.000056600000000','0.029943041617152','0.031039856328403','548.4073556254864','548.407355625486389','test','test','3.7'),('2019-06-12 11:59:59','2019-06-12 23:59:59','WANBTC','4h','0.000057300000000','0.000057500000000','0.030186778219652','0.030292142192495','526.8198642173086','526.819864217308577','test','test','0.3'),('2019-06-13 11:59:59','2019-06-13 19:59:59','WANBTC','4h','0.000058800000000','0.000056600000000','0.030210192435839','0.029079879113410','513.7787829224338','513.778782922433834','test','test','3.7'),('2019-06-14 03:59:59','2019-06-14 11:59:59','WANBTC','4h','0.000060300000000','0.000057888000000','0.029959011697522','0.028760651229621','496.83269813468576','496.832698134685756','test','test','4.0'),('2019-07-07 07:59:59','2019-07-07 15:59:59','WANBTC','4h','0.000034300000000','0.000032928000000','0.029692709371321','0.028505000996468','865.6766580560155','865.676658056015526','test','test','4.0'),('2019-07-07 23:59:59','2019-07-08 07:59:59','WANBTC','4h','0.000034100000000','0.000032736000000','0.029428774176910','0.028251623209834','863.0139054812184','863.013905481218444','test','test','4.0'),('2019-07-23 23:59:59','2019-07-24 03:59:59','WANBTC','4h','0.000025900000000','0.000025600000000','0.029167185073115','0.028829341230569','1126.1461418191077','1126.146141819107697','test','test','1.2'),('2019-07-24 07:59:59','2019-07-30 23:59:59','WANBTC','4h','0.000026200000000','0.000028600000000','0.029092108663660','0.031757034648117','1110.3858268572606','1110.385826857260554','test','test','0.0'),('2019-07-31 07:59:59','2019-07-31 11:59:59','WANBTC','4h','0.000028600000000','0.000029200000000','0.029684314437984','0.030307062293326','1037.9130922372028','1037.913092237202818','test','test','0.0'),('2019-08-22 15:59:59','2019-08-29 03:59:59','WANBTC','4h','0.000021800000000','0.000034700000000','0.029822702850282','0.047470082059853','1368.013892214781','1368.013892214780981','test','test','0.0'),('2019-08-30 15:59:59','2019-08-31 07:59:59','WANBTC','4h','0.000039580000000','0.000037996800000','0.033744342674631','0.032394568967646','852.5604516076638','852.560451607663822','test','test','4.0'),('2019-08-31 11:59:59','2019-08-31 15:59:59','WANBTC','4h','0.000040660000000','0.000039033600000','0.033444392961968','0.032106617243489','822.5379479087064','822.537947908706428','test','test','4.0'),('2019-08-31 19:59:59','2019-08-31 23:59:59','WANBTC','4h','0.000036100000000','0.000035300000000','0.033147109468973','0.032412547486281','918.2024783648938','918.202478364893750','test','test','2.2'),('2019-09-01 19:59:59','2019-09-02 11:59:59','WANBTC','4h','0.000041540000000','0.000039878400000','0.032983873472819','0.031664518533906','794.0268048343497','794.026804834349718','test','test','4.0'),('2019-09-02 15:59:59','2019-09-02 19:59:59','WANBTC','4h','0.000039830000000','0.000038236800000','0.032690683486394','0.031383056146938','820.7552971728289','820.755297172828932','test','test','4.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:14:30
