-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-12 23:59:59','2018-02-13 03:59:59','BTCUSDT','4h','8903.000000000000000','8760.590000000000146','222.222222222222200','218.667615160932002','0.024960375404046074','0.024960375404046','test','test','1.6'),('2018-02-14 15:59:59','2018-02-22 11:59:59','BTCUSDT','4h','9330.079999999999927','10259.870000000000800','221.432309541935524','243.499167177560963','0.023733163010599644','0.023733163010600','test','test','1.0'),('2018-02-23 15:59:59','2018-02-23 19:59:59','BTCUSDT','4h','10292.000000000000000','10033.000000000000000','226.336055683185606','220.640268817470002','0.021991455079983055','0.021991455079983','test','test','2.5'),('2018-02-26 15:59:59','2018-03-06 15:59:59','BTCUSDT','4h','10260.920000000000073','10966.000000000000000','225.070325268582138','240.536052020215720','0.02193471202081121','0.021934712020811','test','test','0.2'),('2018-03-20 19:59:59','2018-03-22 11:59:59','BTCUSDT','4h','8950.000000000000000','8642.010000000000218','228.507153435611855','220.643698889619230','0.02553152552353205','0.025531525523532','test','test','3.4'),('2018-04-12 11:59:59','2018-05-01 03:59:59','BTCUSDT','4h','7690.000000000000000','8938.010000000000218','226.759719092057935','263.560550954747100','0.029487609764897','0.029487609764897','test','test','1.0'),('2018-05-03 15:59:59','2018-05-07 03:59:59','BTCUSDT','4h','9442.280000000000655','9350.020000000000437','234.937681728211061','232.642118525653558','0.02488145678037625','0.024881456780376','test','test','1.0'),('2018-05-07 11:59:59','2018-05-07 15:59:59','BTCUSDT','4h','9339.000000000000000','9365.280000000000655','234.427556572087155','235.087237071788905','0.02510199770554526','0.025101997705545','test','test','0.0'),('2018-05-21 07:59:59','2018-05-21 11:59:59','BTCUSDT','4h','8540.000000000000000','8469.979999999999563','234.574152238687589','232.650863931924931','0.027467699325373254','0.027467699325373','test','test','0.8'),('2018-06-02 11:59:59','2018-06-02 15:59:59','BTCUSDT','4h','7652.279999999999745','7623.100000000000364','234.146754837184744','233.253896459531433','0.030598299439798957','0.030598299439799','test','test','0.4'),('2018-06-03 11:59:59','2018-06-04 07:59:59','BTCUSDT','4h','7714.850000000000364','7597.699999999999818','233.948341864372907','230.395836209770238','0.030324418733270627','0.030324418733271','test','test','1.5'),('2018-06-07 11:59:59','2018-06-08 07:59:59','BTCUSDT','4h','7696.229999999999563','7627.880000000000109','233.158896163350050','231.088218629964899','0.030295208974179574','0.030295208974180','test','test','0.9'),('2018-06-30 03:59:59','2018-07-01 15:59:59','BTCUSDT','4h','6366.000000000000000','6316.579999999999927','232.698745600375588','230.892278115680256','0.03655336877165812','0.036553368771658','test','test','0.8'),('2018-07-02 15:59:59','2018-07-06 07:59:59','BTCUSDT','4h','6630.079999999999927','6478.850000000000364','232.297308381554416','226.998681223730927','0.03503687864724927','0.035036878647249','test','test','2.3'),('2018-07-07 23:59:59','2018-07-10 07:59:59','BTCUSDT','4h','6756.979999999999563','6601.170000000000073','231.119835679815878','225.790416087442964','0.03420460556044504','0.034204605560445','test','test','2.3'),('2018-07-16 11:59:59','2018-07-31 15:59:59','BTCUSDT','4h','6635.569999999999709','7758.439999999999600','229.935520214844132','268.845168908723053','0.03465196210948632','0.034651962109486','test','test','0.0'),('2018-08-22 03:59:59','2018-08-22 15:59:59','BTCUSDT','4h','6726.010000000000218','6459.359999999999673','238.582108813483842','229.123615692730880','0.0354715661757095','0.035471566175709','test','test','4.0'),('2018-08-24 15:59:59','2018-09-05 11:59:59','BTCUSDT','4h','6504.079999999999927','6991.899999999999636','236.480221453316517','254.216747084821179','0.03635875042332144','0.036358750423321','test','test','0.0'),('2018-09-14 03:59:59','2018-09-14 11:59:59','BTCUSDT','4h','6542.369999999999891','6459.279999999999745','240.421671593650899','237.368246505690934','0.03674840640221371','0.036748406402214','test','test','1.3'),('2018-09-20 23:59:59','2018-09-24 23:59:59','BTCUSDT','4h','6492.000000000000000','6581.390000000000327','239.743132685215329','243.044216885882548','0.03692900996383477','0.036929009963835','test','test','0.0'),('2018-09-27 19:59:59','2018-09-28 19:59:59','BTCUSDT','4h','6669.359999999999673','6684.000000000000000','240.476706952030327','241.004580539567627','0.03605693903943262','0.036056939039433','test','test','0.2'),('2018-09-30 11:59:59','2018-09-30 23:59:59','BTCUSDT','4h','6627.930000000000291','6626.569999999999709','240.594012193705254','240.544644162271084','0.03630002311335594','0.036300023113356','test','test','0.4'),('2018-10-04 03:59:59','2018-10-04 23:59:59','BTCUSDT','4h','6598.510000000000218','6593.789999999999964','240.583041520053229','240.410949342277519','0.03646020715586598','0.036460207155866','test','test','0.4'),('2018-10-05 19:59:59','2018-10-06 11:59:59','BTCUSDT','4h','6595.500000000000000','6587.159999999999854','240.544798813880817','240.240630271373362','0.03647104826228198','0.036471048262282','test','test','0.1'),('2018-10-07 03:59:59','2018-10-07 07:59:59','BTCUSDT','4h','6604.069999999999709','6570.930000000000291','240.477205804434760','239.270462901897560','0.03641348529080321','0.036413485290803','test','test','0.5'),('2018-10-07 15:59:59','2018-10-07 19:59:59','BTCUSDT','4h','6582.069999999999709','6584.000000000000000','240.209040714982024','240.279475008233248','0.03649445246176082','0.036494452461761','test','test','0.0'),('2018-10-08 03:59:59','2018-10-10 03:59:59','BTCUSDT','4h','6605.260000000000218','6616.060000000000400','240.224692780148985','240.617474696686060','0.0363686959756541','0.036368695975654','test','test','0.1'),('2018-10-15 07:59:59','2018-10-18 23:59:59','BTCUSDT','4h','6860.250000000000000','6618.960000000000036','240.311977650490491','231.859679689441435','0.035029623942347654','0.035029623942348','test','test','3.5'),('2018-10-22 03:59:59','2018-10-22 07:59:59','BTCUSDT','4h','6597.909999999999854','6615.060000000000400','238.433689214701843','239.053451801647157','0.036137760171736484','0.036137760171736','test','test','0.0'),('2018-10-24 07:59:59','2018-10-24 15:59:59','BTCUSDT','4h','6610.939999999999600','6581.000000000000000','238.571414234023024','237.490958483075872','0.03608736643110103','0.036087366431101','test','test','0.5'),('2018-11-04 15:59:59','2018-11-05 11:59:59','BTCUSDT','4h','6479.989999999999782','6452.840000000000146','238.331312956034822','237.332747349181062','0.03677958036293803','0.036779580362938','test','test','0.4'),('2018-11-05 15:59:59','2018-11-05 19:59:59','BTCUSDT','4h','6473.149999999999636','6448.119999999999891','238.109409487845056','237.188701869532366','0.0367841637360242','0.036784163736024','test','test','0.4'),('2018-11-06 03:59:59','2018-11-06 07:59:59','BTCUSDT','4h','6448.380000000000109','6464.340000000000146','237.904807794886693','238.493631768102688','0.03689373265764218','0.036893732657642','test','test','0.0'),('2018-11-06 11:59:59','2018-11-08 19:59:59','BTCUSDT','4h','6471.720000000000255','6495.720000000000255','238.035657566712445','238.918399060720390','0.03678089558366438','0.036780895583664','test','test','0.0'),('2018-11-13 19:59:59','2018-11-13 23:59:59','BTCUSDT','4h','6461.300000000000182','6457.659999999999854','238.231822343158655','238.097613463625265','0.036870571300382064','0.036870571300382','test','test','0.1'),('2018-12-17 19:59:59','2018-12-18 11:59:59','BTCUSDT','4h','3535.610000000000127','3490.849999999999909','238.201998147706803','235.186416271569044','0.06737224924347052','0.067372249243471','test','test','1.3'),('2018-12-18 15:59:59','2018-12-25 03:59:59','BTCUSDT','4h','3512.179999999999836','3709.099999999999909','237.531868841898387','250.849744239043929','0.06763089273382868','0.067630892733829','test','test','0.0'),('2018-12-28 19:59:59','2018-12-29 23:59:59','BTCUSDT','4h','3819.539999999999964','3695.320000000000164','240.491396707930761','232.670077570270422','0.06296344499807065','0.062963444998071','test','test','3.3'),('2018-12-30 15:59:59','2018-12-30 19:59:59','BTCUSDT','4h','3768.000000000000000','3780.119999999999891','238.753325788450667','239.521290307706522','0.06336340917952513','0.063363409179525','test','test','0.0'),('2019-01-01 23:59:59','2019-01-03 19:59:59','BTCUSDT','4h','3797.139999999999873','3756.000000000000000','238.923984570507542','236.335369790638822','0.06292208993360991','0.062922089933610','test','test','1.1'),('2019-01-04 23:59:59','2019-01-05 23:59:59','BTCUSDT','4h','3792.010000000000218','3770.960000000000036','238.348736841647820','237.025628276397015','0.06285551378863659','0.062855513788637','test','test','0.6'),('2019-01-06 11:59:59','2019-01-10 07:59:59','BTCUSDT','4h','3814.239999999999782','3777.019999999999982','238.054712716036533','235.731734506146523','0.06241209591321903','0.062412095913219','test','test','1.0'),('2019-01-19 11:59:59','2019-01-20 11:59:59','BTCUSDT','4h','3695.380000000000109','3580.000000000000000','237.538495336060947','230.121885517348176','0.06427985628976207','0.064279856289762','test','test','3.1'),('2019-01-26 07:59:59','2019-01-26 11:59:59','BTCUSDT','4h','3620.579999999999927','3589.929999999999836','235.890359820791474','233.893431282129910','0.06515264400200838','0.065152644002008','test','test','0.8');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:10:33
