-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 15:59:59','2018-07-01 19:59:59','WINGSETH','4h','0.000477900000000','0.000484900000000','1.297777777777778','1.316786868475506','2715.5843853897836','2715.584385389783620','test','test','0.0'),('2018-07-02 03:59:59','2018-07-02 11:59:59','WINGSETH','4h','0.000495600000000','0.000477800000000','1.302002020155051','1.255239235734632','2627.122720248286','2627.122720248285987','test','test','3.6'),('2018-07-02 15:59:59','2018-07-03 19:59:59','WINGSETH','4h','0.000483000000000','0.000478600000000','1.291610290283846','1.279844068177741','2674.141387751235','2674.141387751235015','test','test','0.9'),('2018-07-04 15:59:59','2018-07-05 19:59:59','WINGSETH','4h','0.000529400000000','0.000508224000000','1.288995574260267','1.237435751289856','2434.8235252366217','2434.823525236621663','test','test','4.0'),('2018-07-09 19:59:59','2018-07-10 03:59:59','WINGSETH','4h','0.000503800000000','0.000491100000000','1.277537835822398','1.245333130552560','2535.803564554185','2535.803564554184959','test','test','3.6'),('2018-07-16 19:59:59','2018-07-16 23:59:59','WINGSETH','4h','0.000461400000000','0.000447200000000','1.270381234651323','1.231284109527680','2753.3186706790707','2753.318670679070692','test','test','3.1'),('2018-07-17 19:59:59','2018-07-21 11:59:59','WINGSETH','4h','0.000460600000000','0.000493500000000','1.261692984623847','1.351813912096979','2739.237917116472','2739.237917116472090','test','test','0.0'),('2018-07-22 03:59:59','2018-07-22 23:59:59','WINGSETH','4h','0.000507600000000','0.000487296000000','1.281719857395654','1.230451063099828','2525.058820716419','2525.058820716419177','test','test','4.0'),('2018-07-23 19:59:59','2018-07-24 03:59:59','WINGSETH','4h','0.000487500000000','0.000473300000000','1.270326791996582','1.233324452619451','2605.798547685296','2605.798547685295944','test','test','2.9'),('2018-07-27 23:59:59','2018-07-30 23:59:59','WINGSETH','4h','0.000482600000000','0.000511000000000','1.262104049912775','1.336376231880290','2615.217674912504','2615.217674912504208','test','test','0.0'),('2018-08-07 19:59:59','2018-08-07 23:59:59','WINGSETH','4h','0.000459300000000','0.000445900000000','1.278608979238889','1.241305778015721','2783.820986803591','2783.820986803591040','test','test','2.9'),('2018-08-08 15:59:59','2018-08-08 19:59:59','WINGSETH','4h','0.000463000000000','0.000444480000000','1.270319378967074','1.219506603808391','2743.670364939685','2743.670364939684987','test','test','4.0'),('2018-08-11 23:59:59','2018-08-15 03:59:59','WINGSETH','4h','0.000448800000000','0.000451800000000','1.259027651154033','1.267443611389020','2805.3200783289517','2805.320078328951695','test','test','2.1'),('2018-08-15 19:59:59','2018-08-16 07:59:59','WINGSETH','4h','0.000448900000000','0.000449100000000','1.260897864539586','1.261459636811602','2808.8613600792737','2808.861360079273709','test','test','0.0'),('2018-08-17 07:59:59','2018-08-23 11:59:59','WINGSETH','4h','0.000461500000000','0.000518000000000','1.261022702822256','1.415405763947841','2732.443559744868','2732.443559744867798','test','test','0.0'),('2018-08-23 15:59:59','2018-08-29 19:59:59','WINGSETH','4h','0.000527600000000','0.000519000000000','1.295330049739053','1.274215875311919','2455.1365612946415','2455.136561294641524','test','test','3.9'),('2018-08-30 11:59:59','2018-08-30 15:59:59','WINGSETH','4h','0.000509000000000','0.000501400000000','1.290638010977468','1.271367188023777','2535.6345991698777','2535.634599169877674','test','test','1.5'),('2018-08-31 07:59:59','2018-08-31 19:59:59','WINGSETH','4h','0.000513100000000','0.000512800000000','1.286355605876647','1.285603497746140','2507.0271016890424','2507.027101689042411','test','test','0.3'),('2018-09-01 11:59:59','2018-09-01 15:59:59','WINGSETH','4h','0.000511800000000','0.000508700000000','1.286188470736535','1.278397958311206','2513.068524299599','2513.068524299599176','test','test','0.6'),('2018-09-03 19:59:59','2018-09-13 23:59:59','WINGSETH','4h','0.000537000000000','0.000573600000000','1.284457245753128','1.372001259150827','2391.9129343633676','2391.912934363367640','test','test','0.0'),('2018-09-16 23:59:59','2018-09-21 15:59:59','WINGSETH','4h','0.000598000000000','0.000603300000000','1.303911470952617','1.315467876966076','2180.4539648037075','2180.453964803707549','test','test','0.0'),('2018-09-23 07:59:59','2018-09-23 11:59:59','WINGSETH','4h','0.000625600000000','0.000600576000000','1.306479561177830','1.254220378730717','2088.362469913411','2088.362469913411132','test','test','4.0'),('2018-09-26 15:59:59','2018-09-27 19:59:59','WINGSETH','4h','0.000648800000000','0.000622848000000','1.294866409522916','1.243071753141999','1995.7866977850124','1995.786697785012393','test','test','4.0'),('2018-09-27 23:59:59','2018-09-29 11:59:59','WINGSETH','4h','0.000622900000000','0.000619000000000','1.283356485882712','1.275321343331833','2060.2929617638665','2060.292961763866515','test','test','0.9'),('2018-09-29 15:59:59','2018-09-29 19:59:59','WINGSETH','4h','0.000620000000000','0.000612600000000','1.281570898649184','1.266274729858855','2067.0498365309413','2067.049836530941320','test','test','1.2'),('2018-10-01 15:59:59','2018-10-03 19:59:59','WINGSETH','4h','0.000620700000000','0.000631900000000','1.278171750029111','1.301235264771057','2059.2423876737726','2059.242387673772555','test','test','0.0'),('2018-10-04 07:59:59','2018-10-11 15:59:59','WINGSETH','4h','0.000653500000000','0.000671200000000','1.283296975527321','1.318054980832346','1963.729113278226','1963.729113278225896','test','test','0.0'),('2018-10-12 07:59:59','2018-10-17 07:59:59','WINGSETH','4h','0.000673600000000','0.000754800000000','1.291020976706215','1.446648802283033','1916.5988371529324','1916.598837152932447','test','test','0.0'),('2018-10-17 19:59:59','2018-10-27 15:59:59','WINGSETH','4h','0.000777000000000','0.000820300000000','1.325604937945508','1.399477130755084','1706.05526119113','1706.055261191130057','test','test','0.4'),('2018-10-28 03:59:59','2018-11-03 11:59:59','WINGSETH','4h','0.000849800000000','0.000873200000000','1.342020980792080','1.378974723967574','1579.219793824524','1579.219793824524004','test','test','0.0'),('2018-11-07 19:59:59','2018-11-08 03:59:59','WINGSETH','4h','0.001057500000000','0.001015200000000','1.350232923719968','1.296223606771169','1276.8160035177002','1276.816003517700210','test','test','4.0'),('2018-11-08 07:59:59','2018-11-08 19:59:59','WINGSETH','4h','0.001036000000000','0.000994560000000','1.338230853286902','1.284701619155426','1291.7286228638045','1291.728622863804503','test','test','4.0'),('2018-11-08 23:59:59','2018-11-12 11:59:59','WINGSETH','4h','0.000939000000000','0.000901440000000','1.326335467924351','1.273282049207377','1412.4978359151771','1412.497835915177120','test','test','4.0'),('2018-11-26 15:59:59','2018-11-26 19:59:59','WINGSETH','4h','0.000778700000000','0.000747552000000','1.314545819320579','1.261963986547756','1688.1287008097847','1688.128700809784732','test','test','4.0'),('2018-11-30 07:59:59','2018-12-05 23:59:59','WINGSETH','4h','0.000765200000000','0.000765200000000','1.302860967593286','1.302860967593286','1702.641097220708','1702.641097220707934','test','test','3.1'),('2018-12-07 15:59:59','2018-12-07 19:59:59','WINGSETH','4h','0.000804500000000','0.000772320000000','1.302860967593286','1.250746528889555','1619.4667092520642','1619.466709252064220','test','test','4.0'),('2018-12-08 11:59:59','2018-12-08 15:59:59','WINGSETH','4h','0.000788800000000','0.000767000000000','1.291279981214678','1.255592983762244','1637.0182317630306','1637.018231763030599','test','test','2.8'),('2018-12-12 15:59:59','2018-12-12 19:59:59','WINGSETH','4h','0.000762200000000','0.000758300000000','1.283349537336360','1.276782936449963','1683.7438170248754','1683.743817024875398','test','test','0.5'),('2018-12-12 23:59:59','2018-12-13 03:59:59','WINGSETH','4h','0.000866300000000','0.000831648000000','1.281890292694938','1.230614680987141','1479.730223588755','1479.730223588755052','test','test','4.0'),('2018-12-13 07:59:59','2018-12-13 11:59:59','WINGSETH','4h','0.000770900000000','0.000778700000000','1.270495712315428','1.283350643637338','1648.0681181935759','1648.068118193575856','test','test','0.0'),('2018-12-15 07:59:59','2018-12-15 19:59:59','WINGSETH','4h','0.000768300000000','0.000761500000000','1.273352363720297','1.262082292038274','1657.3634826503928','1657.363482650392825','test','test','0.9'),('2018-12-16 23:59:59','2018-12-17 19:59:59','WINGSETH','4h','0.000773800000000','0.000754900000000','1.270847903346514','1.239807550059813','1642.3467347460762','1642.346734746076208','test','test','2.4'),('2019-01-08 15:59:59','2019-01-10 19:59:59','WINGSETH','4h','0.000580000000000','0.000570700000000','1.263950047060580','1.243683261823229','2179.224219069966','2179.224219069965784','test','test','1.6'),('2019-01-11 15:59:59','2019-01-14 15:59:59','WINGSETH','4h','0.000587300000000','0.000570200000000','1.259446317007836','1.222775906619901','2144.468443738865','2144.468443738865062','test','test','2.9'),('2019-01-14 19:59:59','2019-01-26 15:59:59','WINGSETH','4h','0.000600700000000','0.000818200000000','1.251297336921628','1.704364043731107','2083.065318664271','2083.065318664271217','test','test','0.4'),('2019-01-27 19:59:59','2019-01-27 23:59:59','WINGSETH','4h','0.000845300000000','0.000811488000000','1.351978827323734','1.297899674230785','1599.4071067357554','1599.407106735755406','test','test','4.0'),('2019-01-28 15:59:59','2019-01-29 07:59:59','WINGSETH','4h','0.000851200000000','0.000817152000000','1.339961237747523','1.286362788237622','1574.2025819402295','1574.202581940229493','test','test','4.0'),('2019-02-02 07:59:59','2019-02-02 11:59:59','WINGSETH','4h','0.000813300000000','0.000794300000000','1.328050471189768','1.297025069797163','1632.9158627686802','1632.915862768680199','test','test','2.3'),('2019-02-02 15:59:59','2019-02-02 19:59:59','WINGSETH','4h','0.000826000000000','0.000797600000000','1.321155937546967','1.275731205553827','1599.4623941246568','1599.462394124656839','test','test','3.4'),('2019-02-03 07:59:59','2019-02-03 11:59:59','WINGSETH','4h','0.000812100000000','0.000838200000000','1.311061552659602','1.353197627680432','1614.4090046294818','1614.409004629481842','test','test','0.0'),('2019-02-03 15:59:59','2019-02-03 23:59:59','WINGSETH','4h','0.000831300000000','0.000810400000000','1.320425124886453','1.287227861431470','1588.3858112431772','1588.385811243177159','test','test','2.8'),('2019-02-07 19:59:59','2019-02-08 03:59:59','WINGSETH','4h','0.000824100000000','0.000791136000000','1.313047955229790','1.260526037020598','1593.3114369976824','1593.311436997682449','test','test','4.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:00:47
