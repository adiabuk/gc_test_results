-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-02 15:59:59','2018-06-03 23:59:59','LENDBTC','4h','0.000006270000000','0.000006260000000','0.033333333333333','0.033280170122275','5316.32110579479','5316.321105794790128','test','test','0.2'),('2018-06-09 07:59:59','2018-06-09 11:59:59','LENDBTC','4h','0.000006120000000','0.000006140000000','0.033321519286432','0.033430413140309','5444.692693861365','5444.692693861365115','test','test','0.0'),('2018-06-09 15:59:59','2018-06-09 19:59:59','LENDBTC','4h','0.000006040000000','0.000006120000000','0.033345717920626','0.033787383058648','5520.814225269279','5520.814225269278722','test','test','0.0'),('2018-06-30 19:59:59','2018-07-01 03:59:59','LENDBTC','4h','0.000004310000000','0.000004350000000','0.033443865729076','0.033754249633754','7759.597616954936','7759.597616954935802','test','test','0.0'),('2018-07-01 07:59:59','2018-07-01 19:59:59','LENDBTC','4h','0.000004670000000','0.000004483200000','0.033512839930115','0.032172326332910','7176.1969871767305','7176.196987176730545','test','test','4.0'),('2018-07-01 23:59:59','2018-07-02 11:59:59','LENDBTC','4h','0.000005180000000','0.000004972800000','0.033214948019625','0.031886350098840','6412.152127340798','6412.152127340797961','test','test','4.0'),('2018-07-02 15:59:59','2018-07-06 03:59:59','LENDBTC','4h','0.000004980000000','0.000004780800000','0.032919704037229','0.031602915875740','6610.382336792905','6610.382336792905335','test','test','4.0'),('2018-07-16 19:59:59','2018-07-16 23:59:59','LENDBTC','4h','0.000004280000000','0.000004260000000','0.032627084445787','0.032474621434358','7623.150571445483','7623.150571445483365','test','test','0.5'),('2018-07-17 03:59:59','2018-07-17 07:59:59','LENDBTC','4h','0.000004280000000','0.000004150000000','0.032593203776580','0.031603223288039','7615.234527238371','7615.234527238370902','test','test','3.0'),('2018-07-17 23:59:59','2018-07-18 23:59:59','LENDBTC','4h','0.000004260000000','0.000004270000000','0.032373208112460','0.032449201558733','7599.3446273380305','7599.344627338030477','test','test','0.0'),('2018-08-27 19:59:59','2018-08-27 23:59:59','LENDBTC','4h','0.000002060000000','0.000002080000000','0.032390095544965','0.032704562492003','15723.347351924813','15723.347351924812756','test','test','0.0'),('2018-08-28 03:59:59','2018-08-28 19:59:59','LENDBTC','4h','0.000002180000000','0.000002092800000','0.032459977088751','0.031161578005201','14889.89774713364','14889.897747133640223','test','test','4.0'),('2018-08-28 23:59:59','2018-08-29 15:59:59','LENDBTC','4h','0.000002170000000','0.000002083200000','0.032171443959074','0.030884586200711','14825.550211554635','14825.550211554635098','test','test','4.0'),('2018-09-01 15:59:59','2018-09-02 11:59:59','LENDBTC','4h','0.000002120000000','0.000002050000000','0.031885475568326','0.030832653261825','15040.318664304821','15040.318664304821141','test','test','3.3'),('2018-09-04 11:59:59','2018-09-05 11:59:59','LENDBTC','4h','0.000002120000000','0.000002035200000','0.031651515055770','0.030385454453539','14929.959931967189','14929.959931967188822','test','test','4.0'),('2018-09-16 15:59:59','2018-09-19 19:59:59','LENDBTC','4h','0.000001860000000','0.000002020000000','0.031370168255275','0.034068677352503','16865.681857674554','16865.681857674553612','test','test','0.0'),('2018-09-20 15:59:59','2018-09-20 23:59:59','LENDBTC','4h','0.000002330000000','0.000002236800000','0.031969836943548','0.030691043465806','13720.960061608392','13720.960061608391698','test','test','4.0'),('2018-09-23 11:59:59','2018-09-24 11:59:59','LENDBTC','4h','0.000002140000000','0.000002054400000','0.031685660615160','0.030418234190554','14806.383465028248','14806.383465028247883','test','test','4.0'),('2018-09-24 19:59:59','2018-09-24 23:59:59','LENDBTC','4h','0.000002140000000','0.000002070000000','0.031404010298581','0.030376776316852','14674.77116756137','14674.771167561370021','test','test','3.3'),('2018-09-25 03:59:59','2018-09-25 07:59:59','LENDBTC','4h','0.000002040000000','0.000001958400000','0.031175736080419','0.029928706637202','15282.223568833007','15282.223568833007448','test','test','4.0'),('2018-09-25 11:59:59','2018-09-25 15:59:59','LENDBTC','4h','0.000002100000000','0.000002040000000','0.030898618426371','0.030015800757046','14713.627822081484','14713.627822081483828','test','test','2.9'),('2018-09-27 15:59:59','2018-10-01 19:59:59','LENDBTC','4h','0.000002110000000','0.000002120000000','0.030702436722077','0.030847945900855','14550.917877761456','14550.917877761456111','test','test','0.0'),('2018-10-02 03:59:59','2018-10-11 03:59:59','LENDBTC','4h','0.000002190000000','0.000002460000000','0.030734772095138','0.034523990572621','14034.142509195635','14034.142509195635284','test','test','1.4'),('2018-10-13 03:59:59','2018-10-13 07:59:59','LENDBTC','4h','0.000002500000000','0.000002450000000','0.031576820645690','0.030945284232776','12630.728258276087','12630.728258276087217','test','test','2.0'),('2018-10-18 03:59:59','2018-10-26 07:59:59','LENDBTC','4h','0.000002450000000','0.000002800000000','0.031436479220598','0.035927404823541','12831.216008407438','12831.216008407438494','test','test','0.0'),('2018-10-27 07:59:59','2018-11-04 07:59:59','LENDBTC','4h','0.000003120000000','0.000003240000000','0.032434462687919','0.033681942022070','10395.661117922722','10395.661117922722042','test','test','0.0'),('2018-11-07 23:59:59','2018-11-08 03:59:59','LENDBTC','4h','0.000003280000000','0.000003148800000','0.032711680317730','0.031403213105021','9973.073267600676','9973.073267600675536','test','test','4.0'),('2018-11-08 07:59:59','2018-11-08 11:59:59','LENDBTC','4h','0.000003200000000','0.000003140000000','0.032420909826017','0.031813017766779','10131.534320630346','10131.534320630345974','test','test','1.9'),('2018-11-28 19:59:59','2018-11-28 23:59:59','LENDBTC','4h','0.000002160000000','0.000002180000000','0.032285822701742','0.032584765504536','14947.140139695368','14947.140139695367907','test','test','0.0'),('2018-11-29 03:59:59','2018-11-29 07:59:59','LENDBTC','4h','0.000002170000000','0.000002200000000','0.032352254435696','0.032799520626051','14908.873011841575','14908.873011841575135','test','test','0.0'),('2018-11-29 11:59:59','2018-11-29 15:59:59','LENDBTC','4h','0.000002210000000','0.000002190000000','0.032451646922442','0.032157966859795','14684.003132326596','14684.003132326595733','test','test','0.9'),('2018-11-29 19:59:59','2018-11-29 23:59:59','LENDBTC','4h','0.000002200000000','0.000002170000000','0.032386384686298','0.031944752167848','14721.083948317273','14721.083948317273098','test','test','1.4'),('2018-12-01 11:59:59','2018-12-05 19:59:59','LENDBTC','4h','0.000002270000000','0.000002210000000','0.032288244126642','0.031434810361180','14223.896091031917','14223.896091031916512','test','test','2.6'),('2018-12-14 23:59:59','2018-12-15 03:59:59','LENDBTC','4h','0.000002060000000','0.000002050000000','0.032098592178762','0.031942773770127','15581.840863476698','15581.840863476698360','test','test','0.5'),('2018-12-15 07:59:59','2018-12-15 11:59:59','LENDBTC','4h','0.000002080000000','0.000002130000000','0.032063965865732','0.032834734275966','15415.368204678845','15415.368204678845359','test','test','0.0'),('2018-12-15 15:59:59','2018-12-20 11:59:59','LENDBTC','4h','0.000002140000000','0.000002190000000','0.032235247734673','0.032988407728474','15063.19987601537','15063.199876015369227','test','test','1.4'),('2018-12-21 15:59:59','2018-12-25 03:59:59','LENDBTC','4h','0.000002220000000','0.000002131200000','0.032402616622184','0.031106511957297','14595.773253236137','14595.773253236136952','test','test','4.0'),('2019-01-03 23:59:59','2019-01-04 03:59:59','LENDBTC','4h','0.000002090000000','0.000002090000000','0.032114593363320','0.032114593363320','15365.834145129398','15365.834145129398166','test','test','0.0'),('2019-01-04 07:59:59','2019-01-04 11:59:59','LENDBTC','4h','0.000002090000000','0.000002090000000','0.032114593363320','0.032114593363320','15365.834145129398','15365.834145129398166','test','test','0.0'),('2019-01-09 11:59:59','2019-01-09 15:59:59','LENDBTC','4h','0.000002110000000','0.000002080000000','0.032114593363320','0.031657987770477','15220.186428113951','15220.186428113951479','test','test','1.4'),('2019-01-13 11:59:59','2019-01-13 19:59:59','LENDBTC','4h','0.000002080000000','0.000002060000000','0.032013125453800','0.031705306939821','15390.925698942197','15390.925698942197414','test','test','1.0'),('2019-01-13 23:59:59','2019-01-20 11:59:59','LENDBTC','4h','0.000002100000000','0.000002220000000','0.031944721339582','0.033770133987558','15211.772066467727','15211.772066467727200','test','test','0.0'),('2019-01-20 15:59:59','2019-01-20 19:59:59','LENDBTC','4h','0.000002240000000','0.000002230000000','0.032350368594688','0.032205947306319','14442.128836914288','14442.128836914287604','test','test','0.4'),('2019-01-22 07:59:59','2019-01-23 23:59:59','LENDBTC','4h','0.000002260000000','0.000002290000000','0.032318274975050','0.032747278625161','14300.121670376304','14300.121670376303882','test','test','0.0'),('2019-01-25 07:59:59','2019-01-27 15:59:59','LENDBTC','4h','0.000002330000000','0.000002280000000','0.032413609119520','0.031718038108372','13911.420222969764','13911.420222969763927','test','test','2.1'),('2019-02-02 19:59:59','2019-02-03 03:59:59','LENDBTC','4h','0.000002290000000','0.000002198400000','0.032259037783709','0.030968676272361','14086.916062754972','14086.916062754971790','test','test','4.0'),('2019-02-09 19:59:59','2019-02-10 03:59:59','LENDBTC','4h','0.000002170000000','0.000002130000000','0.031972290781187','0.031382939799045','14733.774553542446','14733.774553542445574','test','test','1.8'),('2019-02-15 07:59:59','2019-02-15 11:59:59','LENDBTC','4h','0.000002110000000','0.000002120000000','0.031841323896267','0.031992230644591','15090.67483235387','15090.674832353870443','test','test','0.0'),('2019-02-21 23:59:59','2019-02-22 23:59:59','LENDBTC','4h','0.000002190000000','0.000002102400000','0.031874858729228','0.030599864380059','14554.730013345912','14554.730013345912084','test','test','4.0'),('2019-03-01 19:59:59','2019-03-01 23:59:59','LENDBTC','4h','0.000002070000000','0.000002020000000','0.031591526651634','0.030828446297730','15261.607078084271','15261.607078084271052','test','test','2.4'),('2019-03-02 11:59:59','2019-03-07 07:59:59','LENDBTC','4h','0.000002050000000','0.000002170000000','0.031421953239656','0.033261287087831','15327.78206812477','15327.782068124770376','test','test','0.0'),('2019-03-08 03:59:59','2019-03-11 19:59:59','LENDBTC','4h','0.000002260000000','0.000002250000000','0.031830694094806','0.031689850315625','14084.377918055656','14084.377918055655755','test','test','1.8'),('2019-03-12 11:59:59','2019-03-16 23:59:59','LENDBTC','4h','0.000002340000000','0.000002340000000','0.031799395477210','0.031799395477210','13589.48524667094','13589.485246670939887','test','test','0.9'),('2019-03-26 23:59:59','2019-03-27 03:59:59','LENDBTC','4h','0.000002240000000','0.000002260000000','0.031799395477210','0.032083318651114','14196.158695183036','14196.158695183035888','test','test','0.0'),('2019-03-27 07:59:59','2019-04-02 07:59:59','LENDBTC','4h','0.000002270000000','0.000002310000000','0.031862489515855','0.032423943075606','14036.33899376887','14036.338993768869841','test','test','0.0'),('2019-04-05 15:59:59','2019-04-06 11:59:59','LENDBTC','4h','0.000002390000000','0.000002310000000','0.031987256973578','0.030916553811283','13383.78952869363','13383.789528693629109','test','test','3.3'),('2019-04-07 23:59:59','2019-04-08 03:59:59','LENDBTC','4h','0.000002370000000','0.000002280000000','0.031749322937512','0.030543652446214','13396.338792199249','13396.338792199248928','test','test','3.8'),('2019-04-14 19:59:59','2019-04-14 23:59:59','LENDBTC','4h','0.000002210000000','0.000002170000000','0.031481396161668','0.030911597136117','14244.9756387639','14244.975638763900861','test','test','1.8'),('2019-05-20 15:59:59','2019-05-20 19:59:59','LENDBTC','4h','0.000001250000000','0.000001200000000','0.031354774155990','0.030100583189750','25083.81932479217','25083.819324792169937','test','test','4.0'),('2019-05-21 07:59:59','2019-05-21 11:59:59','LENDBTC','4h','0.000001180000000','0.000001160000000','0.031076065052381','0.030549352085391','26335.648349475705','26335.648349475704890','test','test','1.7'),('2019-05-21 19:59:59','2019-05-22 11:59:59','LENDBTC','4h','0.000001180000000','0.000001150000000','0.030959017726384','0.030171924055374','26236.45570032505','26236.455700325048383','test','test','2.5'),('2019-05-22 15:59:59','2019-05-24 15:59:59','LENDBTC','4h','0.000001240000000','0.000001200000000','0.030784108021715','0.029791072279079','24825.893565898925','24825.893565898924862','test','test','3.2'),('2019-05-26 11:59:59','2019-05-26 15:59:59','LENDBTC','4h','0.000001200000000','0.000001220000000','0.030563433412240','0.031072823969111','25469.52784353333','25469.527843533331179','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:50:19
