-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-28 19:59:59','2018-04-29 03:59:59','RCNETH','4h','0.000226270000000','0.000220400000000','1.297777777777778','1.264110232121900','5735.527368974136','5735.527368974136152','test','test','2.6'),('2018-04-29 23:59:59','2018-04-30 11:59:59','RCNETH','4h','0.000225190000000','0.000221040000000','1.290296100965360','1.266517386017955','5729.810830700121','5729.810830700121187','test','test','1.8'),('2018-04-30 19:59:59','2018-05-01 03:59:59','RCNETH','4h','0.000230180000000','0.000220972800000','1.285011942088159','1.233611464404633','5582.639421705446','5582.639421705445784','test','test','4.0'),('2018-05-02 11:59:59','2018-05-02 15:59:59','RCNETH','4h','0.000223560000000','0.000221310000000','1.273589613714042','1.260771682819174','5696.8581754967','5696.858175496699914','test','test','1.0'),('2018-06-01 19:59:59','2018-06-02 11:59:59','RCNETH','4h','0.000161440000000','0.000155120000000','1.270741184626294','1.220994626853510','7871.290786832843','7871.290786832842969','test','test','3.9'),('2018-07-01 15:59:59','2018-07-01 23:59:59','RCNETH','4h','0.000103950000000','0.000100310000000','1.259686394010120','1.215576163378115','12118.19522857258','12118.195228572580163','test','test','3.5'),('2018-07-02 07:59:59','2018-07-02 11:59:59','RCNETH','4h','0.000102520000000','0.000106650000000','1.249884120536341','1.300235480444799','12191.612568633836','12191.612568633836418','test','test','0.0'),('2018-07-02 15:59:59','2018-07-03 23:59:59','RCNETH','4h','0.000111240000000','0.000106790400000','1.261073311627109','1.210630379162025','11336.509453677718','11336.509453677717829','test','test','4.0'),('2018-07-06 03:59:59','2018-07-06 11:59:59','RCNETH','4h','0.000110240000000','0.000105830400000','1.249863771079313','1.199869220236141','11337.661203549646','11337.661203549645506','test','test','4.0'),('2018-07-08 19:59:59','2018-07-09 03:59:59','RCNETH','4h','0.000108490000000','0.000109000000000','1.238753870891941','1.244577121644590','11418.138730684315','11418.138730684315306','test','test','2.0'),('2018-07-09 15:59:59','2018-07-09 23:59:59','RCNETH','4h','0.000110200000000','0.000105792000000','1.240047926614752','1.190446009550162','11252.70350830084','11252.703508300839530','test','test','4.0'),('2018-07-18 03:59:59','2018-07-19 19:59:59','RCNETH','4h','0.000105060000000','0.000100857600000','1.229025278378177','1.179864267243050','11698.317898136082','11698.317898136081567','test','test','4.0'),('2018-07-23 15:59:59','2018-07-23 19:59:59','RCNETH','4h','0.000104300000000','0.000100128000000','1.218100609237037','1.169376584867555','11678.816962962966','11678.816962962966500','test','test','4.0'),('2018-07-28 07:59:59','2018-07-28 23:59:59','RCNETH','4h','0.000100020000000','0.000096360000000','1.207273048266041','1.163095690171123','12070.316419376539','12070.316419376538761','test','test','3.7'),('2018-07-29 03:59:59','2018-07-29 07:59:59','RCNETH','4h','0.000106840000000','0.000102566400000','1.197455857578282','1.149557623275151','11207.935769171489','11207.935769171488573','test','test','4.0'),('2018-07-29 11:59:59','2018-07-31 11:59:59','RCNETH','4h','0.000097310000000','0.000100490000000','1.186811805510920','1.225595707900445','12196.195719976566','12196.195719976565670','test','test','0.0'),('2018-08-20 07:59:59','2018-08-20 11:59:59','RCNETH','4h','0.000072970000000','0.000071670000000','1.195430450486369','1.174133210721640','16382.492126714667','16382.492126714667393','test','test','1.8'),('2018-08-20 15:59:59','2018-08-20 23:59:59','RCNETH','4h','0.000074110000000','0.000071145600000','1.190697730538652','1.143069821317106','16066.627048153448','16066.627048153448413','test','test','4.0'),('2018-08-25 15:59:59','2018-08-29 19:59:59','RCNETH','4h','0.000072010000000','0.000072950000000','1.180113750711641','1.195518651776339','16388.192622019742','16388.192622019741975','test','test','2.0'),('2018-08-31 07:59:59','2018-09-02 15:59:59','RCNETH','4h','0.000074850000000','0.000074620000000','1.183537062059352','1.179900274827907','15812.118397586535','15812.118397586535139','test','test','0.3'),('2018-09-04 15:59:59','2018-09-14 03:59:59','RCNETH','4h','0.000079160000000','0.000093960000000','1.182728887119031','1.403855561315111','14940.991499735108','14940.991499735107936','test','test','2.1'),('2018-09-15 11:59:59','2018-09-21 23:59:59','RCNETH','4h','0.000101000000000','0.000114300000000','1.231868148051493','1.394084448735501','12196.7143371435','12196.714337143499506','test','test','1.5'),('2018-09-22 19:59:59','2018-09-24 11:59:59','RCNETH','4h','0.000120680000000','0.000116170000000','1.267916214870162','1.220532206508673','10506.432009199218','10506.432009199217646','test','test','3.7'),('2018-09-25 03:59:59','2018-09-27 19:59:59','RCNETH','4h','0.000124200000000','0.000120140000000','1.257386435234275','1.216283464807132','10123.884341660832','10123.884341660832433','test','test','3.3'),('2018-09-28 19:59:59','2018-09-29 11:59:59','RCNETH','4h','0.000129160000000','0.000123993600000','1.248252441806021','1.198322344133780','9664.388679204254','9664.388679204254004','test','test','4.0'),('2018-10-03 19:59:59','2018-10-04 03:59:59','RCNETH','4h','0.000125950000000','0.000120912000000','1.237156864545523','1.187670589963702','9822.603132556755','9822.603132556754645','test','test','4.0'),('2018-10-04 11:59:59','2018-10-08 03:59:59','RCNETH','4h','0.000124780000000','0.000127600000000','1.226159914638452','1.253870853565207','9826.574087501616','9826.574087501616305','test','test','0.0'),('2018-10-08 15:59:59','2018-10-08 19:59:59','RCNETH','4h','0.000129160000000','0.000126200000000','1.232317901066620','1.204076487415666','9541.018125322236','9541.018125322236301','test','test','2.3'),('2018-10-09 03:59:59','2018-10-11 07:59:59','RCNETH','4h','0.000130150000000','0.000131220000000','1.226042031366408','1.236121670041491','9420.223060825261','9420.223060825261200','test','test','0.3'),('2018-10-11 11:59:59','2018-10-11 23:59:59','RCNETH','4h','0.000136410000000','0.000130953600000','1.228281951071982','1.179150673029103','9004.339499098172','9004.339499098172382','test','test','4.0'),('2018-10-12 07:59:59','2018-10-15 07:59:59','RCNETH','4h','0.000135700000000','0.000130272000000','1.217363889284675','1.168669333713288','8970.99402567926','8970.994025679259721','test','test','4.0'),('2018-10-17 11:59:59','2018-10-18 19:59:59','RCNETH','4h','0.000135900000000','0.000134880000000','1.206542876935478','1.197487146733313','8878.16686486739','8878.166864867389450','test','test','0.8'),('2018-10-18 23:59:59','2018-10-26 11:59:59','RCNETH','4h','0.000138370000000','0.000143670000000','1.204530492446108','1.250667744812693','8705.141955959443','8705.141955959443294','test','test','1.9'),('2018-10-27 23:59:59','2018-10-29 07:59:59','RCNETH','4h','0.000168550000000','0.000161808000000','1.214783215194238','1.166191886586468','7207.257283857835','7207.257283857835318','test','test','4.0'),('2018-10-31 19:59:59','2018-11-04 07:59:59','RCNETH','4h','0.000166090000000','0.000159660000000','1.203985142170289','1.157374121252985','7248.992366610208','7248.992366610207682','test','test','3.9'),('2018-11-06 03:59:59','2018-11-06 07:59:59','RCNETH','4h','0.000163210000000','0.000157120000000','1.193627137522000','1.149088265715683','7313.443646357451','7313.443646357451144','test','test','3.7'),('2018-11-06 11:59:59','2018-11-06 15:59:59','RCNETH','4h','0.000171790000000','0.000164918400000','1.183729610453929','1.136380426035772','6890.561793200589','6890.561793200588909','test','test','4.0'),('2018-11-07 03:59:59','2018-11-07 07:59:59','RCNETH','4h','0.000162030000000','0.000159910000000','1.173207569472116','1.157857325398297','7240.681166895739','7240.681166895738897','test','test','1.3'),('2018-11-27 11:59:59','2018-11-27 19:59:59','RCNETH','4h','0.000128720000000','0.000128040000000','1.169796404122379','1.163616621999918','9087.914885972492','9087.914885972491902','test','test','0.5'),('2018-11-28 03:59:59','2018-11-30 15:59:59','RCNETH','4h','0.000134010000000','0.000133820000000','1.168423119206276','1.166766523484694','8718.924850431134','8718.924850431134473','test','test','2.3'),('2018-12-03 03:59:59','2018-12-06 15:59:59','RCNETH','4h','0.000146110000000','0.000141200000000','1.168054986823703','1.128802711241577','7994.353479047996','7994.353479047996188','test','test','3.4'),('2019-01-11 11:59:59','2019-01-11 15:59:59','RCNETH','4h','0.000085540000000','0.000084960000000','1.159332258916564','1.151471460340791','13553.100992711757','13553.100992711757499','test','test','0.7'),('2019-01-12 03:59:59','2019-01-12 11:59:59','RCNETH','4h','0.000086100000000','0.000085150000000','1.157585414788614','1.144812985705580','13444.662192666829','13444.662192666828560','test','test','1.5'),('2019-01-12 15:59:59','2019-01-12 23:59:59','RCNETH','4h','0.000084670000000','0.000084920000000','1.154747097214607','1.158156649290946','13638.208305357346','13638.208305357346035','test','test','0.0'),('2019-01-13 11:59:59','2019-01-14 15:59:59','RCNETH','4h','0.000088320000000','0.000084787200000','1.155504775453793','1.109284584435641','13083.16095396052','13083.160953960519691','test','test','4.0'),('2019-01-14 19:59:59','2019-01-24 03:59:59','RCNETH','4h','0.000085540000000','0.000100820000000','1.145233621894204','1.349806567212692','13388.281761681128','13388.281761681128046','test','test','0.0'),('2019-01-26 11:59:59','2019-01-27 11:59:59','RCNETH','4h','0.000103830000000','0.000100320000000','1.190694276409423','1.150442548486885','11467.728752859706','11467.728752859706219','test','test','3.4'),('2019-01-27 23:59:59','2019-01-28 03:59:59','RCNETH','4h','0.000102840000000','0.000101210000000','1.181749447982192','1.163018880107717','11491.145935260525','11491.145935260525221','test','test','1.6'),('2019-01-28 11:59:59','2019-01-28 15:59:59','RCNETH','4h','0.000103250000000','0.000102500000000','1.177587099565643','1.169033198116014','11405.201932839153','11405.201932839152505','test','test','0.7'),('2019-01-28 19:59:59','2019-01-31 07:59:59','RCNETH','4h','0.000103060000000','0.000102540000000','1.175686232576836','1.169754184828534','11407.784131349077','11407.784131349077143','test','test','0.5'),('2019-02-05 15:59:59','2019-02-05 19:59:59','RCNETH','4h','0.000100230000000','0.000098020000000','1.174367999743880','1.148474023095831','11716.731514954407','11716.731514954406521','test','test','2.2'),('2019-02-06 03:59:59','2019-02-06 11:59:59','RCNETH','4h','0.000099390000000','0.000099670000000','1.168613782710980','1.171905983728779','11757.860777854718','11757.860777854717526','test','test','0.0'),('2019-02-07 03:59:59','2019-02-07 07:59:59','RCNETH','4h','0.000100000000000','0.000099080000000','1.169345382937158','1.158587405414136','11693.45382937158','11693.453829371579559','test','test','0.9'),('2019-02-07 11:59:59','2019-02-07 15:59:59','RCNETH','4h','0.000099390000000','0.000098780000000','1.166954721265375','1.159792608578265','11741.168339524855','11741.168339524854673','test','test','0.6'),('2019-02-07 19:59:59','2019-02-08 03:59:59','RCNETH','4h','0.000102610000000','0.000099030000000','1.165363140668240','1.124704335058726','11357.208270814148','11357.208270814147909','test','test','3.5'),('2019-02-21 23:59:59','2019-02-24 03:59:59','RCNETH','4h','0.000108920000000','0.000104563200000','1.156327850532792','1.110074736511480','10616.304173088432','10616.304173088432435','test','test','4.0'),('2019-02-25 19:59:59','2019-02-28 11:59:59','RCNETH','4h','0.000142190000000','0.000136502400000','1.146049380750278','1.100207405520267','8059.985798932966','8059.985798932965736','test','test','4.0'),('2019-02-28 19:59:59','2019-03-01 11:59:59','RCNETH','4h','0.000164020000000','0.000157459200000','1.135862275143609','1.090427784137865','6925.144952710702','6925.144952710701546','test','test','4.0'),('2019-03-03 15:59:59','2019-03-13 03:59:59','RCNETH','4h','0.000149250000000','0.000169370000000','1.125765721586777','1.277527237957470','7542.8189051040345','7542.818905104034457','test','test','1.0'),('2019-03-14 03:59:59','2019-03-20 19:59:59','RCNETH','4h','0.000170940000000','0.000176620000000','1.159490503002487','1.198018091963843','6783.026225590774','6783.026225590773720','test','test','1.4'),('2019-03-24 15:59:59','2019-03-25 07:59:59','RCNETH','4h','0.000175890000000','0.000170290000000','1.168052189438344','1.130863649664311','6640.810673934526','6640.810673934525767','test','test','3.2'),('2019-03-25 19:59:59','2019-03-25 23:59:59','RCNETH','4h','0.000173410000000','0.000169610000000','1.159788069488559','1.134373187624442','6688.126806346569','6688.126806346568628','test','test','2.2'),('2019-03-27 11:59:59','2019-04-02 07:59:59','RCNETH','4h','0.000177820000000','0.000208630000000','1.154140317963199','1.354112555036904','6490.497795316608','6490.497795316608062','test','test','1.1'),('2019-04-13 07:59:59','2019-04-14 23:59:59','RCNETH','4h','0.000187440000000','0.000184500000000','1.198578592868467','1.179778864619250','6394.465390890243','6394.465390890242816','test','test','1.6'),('2019-04-16 03:59:59','2019-04-17 23:59:59','RCNETH','4h','0.000187160000000','0.000187050000000','1.194400875479752','1.193698887361015','6381.710170334218','6381.710170334217764','test','test','0.3'),('2019-04-19 19:59:59','2019-04-20 03:59:59','RCNETH','4h','0.000188180000000','0.000185700000000','1.194244878120033','1.178506078578436','6346.290137740635','6346.290137740635146','test','test','1.3'),('2019-04-20 11:59:59','2019-04-20 23:59:59','RCNETH','4h','0.000193870000000','0.000186115200000','1.190747367110789','1.143117472426358','6141.988792029654','6141.988792029654178','test','test','4.0'),('2019-04-21 03:59:59','2019-04-21 11:59:59','RCNETH','4h','0.000187820000000','0.000182640000000','1.180162946069804','1.147614527048179','6283.47857560326','6283.478575603259742','test','test','2.8');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:06:14
