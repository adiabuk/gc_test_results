-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-15 07:59:59','2018-08-15 15:59:59','NANOETH','4h','0.003763000000000','0.004200000000000','1.297777777777778','1.448489680219683','344.8784952904007','344.878495290400679','test','test','0.3'),('2018-08-15 19:59:59','2018-09-06 07:59:59','NANOETH','4h','0.003893000000000','0.009849000000000','1.331269311653757','3.368012188666286','341.9648886857839','341.964888685783876','test','test','0.2'),('2018-09-06 15:59:59','2018-09-09 07:59:59','NANOETH','4h','0.010369000000000','0.010500000000000','1.783878839878763','1.806416030352687','172.03962193835116','172.039621938351161','test','test','0.0'),('2018-09-09 15:59:59','2018-09-09 19:59:59','NANOETH','4h','0.010327000000000','0.010310000000000','1.788887104428524','1.785942291726357','173.2242765980947','173.224276598094690','test','test','0.2'),('2018-09-12 19:59:59','2018-09-12 23:59:59','NANOETH','4h','0.010616000000000','0.011097000000000','1.788232701605820','1.869255679137131','168.44693873453468','168.446938734534683','test','test','0.0'),('2018-09-13 03:59:59','2018-09-17 15:59:59','NANOETH','4h','0.010837000000000','0.010800000000000','1.806237807723889','1.800070898165360','166.67323131160737','166.673231311607367','test','test','0.7'),('2018-09-17 23:59:59','2018-09-19 07:59:59','NANOETH','4h','0.010991000000000','0.010994000000000','1.804867383377549','1.805360023005438','164.2132092964743','164.213209296474304','test','test','0.0'),('2018-09-20 23:59:59','2018-09-21 15:59:59','NANOETH','4h','0.011462000000000','0.011016000000000','1.804976858850413','1.734743070763928','157.4748611804583','157.474861180458305','test','test','3.9'),('2018-10-17 03:59:59','2018-10-18 19:59:59','NANOETH','4h','0.009552000000000','0.009542000000000','1.789369350386750','1.787496057515742','187.32928710079048','187.329287100790481','test','test','0.1'),('2018-10-18 23:59:59','2018-10-22 03:59:59','NANOETH','4h','0.009794000000000','0.009780000000000','1.788953063082082','1.786395850208573','182.65806239351457','182.658062393514570','test','test','0.2'),('2018-10-23 03:59:59','2018-10-23 23:59:59','NANOETH','4h','0.010094000000000','0.009835000000000','1.788384793554635','1.742496972915577','177.17305266045526','177.173052660455255','test','test','2.6'),('2018-10-24 07:59:59','2018-10-24 11:59:59','NANOETH','4h','0.009835000000000','0.009943000000000','1.778187500079289','1.797714114213358','180.80198272285605','180.801982722856053','test','test','0.0'),('2018-10-26 11:59:59','2018-10-27 19:59:59','NANOETH','4h','0.010066000000000','0.009859000000000','1.782526747664638','1.745870376040698','177.083920888599','177.083920888599010','test','test','2.1'),('2018-10-31 11:59:59','2018-11-01 11:59:59','NANOETH','4h','0.010285000000000','0.009998000000000','1.774380887303762','1.724867293268159','172.52123357353057','172.521233573530566','test','test','2.8'),('2018-11-20 15:59:59','2018-11-20 19:59:59','NANOETH','4h','0.008681000000000','0.008556000000000','1.763377866406961','1.737986525167372','203.13072991671024','203.130729916710237','test','test','1.4'),('2018-11-20 23:59:59','2018-11-22 23:59:59','NANOETH','4h','0.008663000000000','0.008482000000000','1.757735346131497','1.721010181910119','202.9014597866209','202.901459786620904','test','test','2.1'),('2018-11-25 07:59:59','2018-11-25 11:59:59','NANOETH','4h','0.008691000000000','0.008863000000000','1.749574198526746','1.784199300603215','201.30873300273228','201.308733002732282','test','test','0.0'),('2018-11-25 15:59:59','2018-11-25 19:59:59','NANOETH','4h','0.008676000000000','0.008623000000000','1.757268665654851','1.746533852459864','202.54364518843371','202.543645188433715','test','test','0.6'),('2018-11-25 23:59:59','2018-11-26 03:59:59','NANOETH','4h','0.008569000000000','0.008711000000000','1.754883151611520','1.783963955384286','204.79439276596105','204.794392765961049','test','test','0.0'),('2018-11-26 19:59:59','2018-11-30 11:59:59','NANOETH','4h','0.008791000000000','0.008665000000000','1.761345552449913','1.736100467748663','200.35781508928596','200.357815089285964','test','test','1.4'),('2018-11-30 15:59:59','2018-11-30 23:59:59','NANOETH','4h','0.008876000000000','0.008874000000000','1.755735533627413','1.755339919491850','197.80706778136692','197.807067781366925','test','test','0.0'),('2018-12-03 19:59:59','2018-12-04 07:59:59','NANOETH','4h','0.009039000000000','0.009110000000000','1.755647619375065','1.769437970185512','194.2302931048861','194.230293104886101','test','test','1.3'),('2018-12-04 11:59:59','2018-12-04 15:59:59','NANOETH','4h','0.008926000000000','0.008924000000000','1.758712141777387','1.758318076766906','197.03250524057663','197.032505240576626','test','test','0.0'),('2018-12-05 03:59:59','2018-12-05 07:59:59','NANOETH','4h','0.008934000000000','0.008840000000000','1.758624571775058','1.740121022441405','196.84626950694627','196.846269506946271','test','test','1.1'),('2018-12-05 11:59:59','2018-12-05 15:59:59','NANOETH','4h','0.008977000000000','0.009023000000000','1.754512671923135','1.763503156818809','195.44532381899685','195.445323818996854','test','test','0.0'),('2018-12-05 19:59:59','2018-12-06 15:59:59','NANOETH','4h','0.008943000000000','0.009003000000000','1.756510557455507','1.768295264315323','196.41178099692578','196.411780996925785','test','test','0.0'),('2018-12-06 23:59:59','2018-12-07 19:59:59','NANOETH','4h','0.009135000000000','0.009029000000000','1.759129381202133','1.738716932991139','192.57026614144854','192.570266141448542','test','test','1.2'),('2018-12-08 23:59:59','2018-12-13 15:59:59','NANOETH','4h','0.009419000000000','0.009100000000000','1.754593281599689','1.695169217810508','186.28233162752832','186.282331627528322','test','test','3.4'),('2018-12-13 23:59:59','2018-12-14 03:59:59','NANOETH','4h','0.009193000000000','0.009201000000000','1.741387934090983','1.742903337492781','189.42542522473434','189.425425224734340','test','test','0.0'),('2018-12-14 19:59:59','2018-12-15 03:59:59','NANOETH','4h','0.009267000000000','0.009067000000000','1.741724690402493','1.704134862186188','187.94914108152514','187.949141081525141','test','test','2.2'),('2018-12-18 11:59:59','2018-12-18 15:59:59','NANOETH','4h','0.009194000000000','0.009079000000000','1.733371395243315','1.711690112835986','188.53289049851145','188.532890498511449','test','test','1.3'),('2018-12-18 23:59:59','2018-12-19 03:59:59','NANOETH','4h','0.009180000000000','0.009402000000000','1.728553332486130','1.770354949023376','188.29556998759585','188.295569987595854','test','test','0.0'),('2018-12-19 07:59:59','2018-12-20 19:59:59','NANOETH','4h','0.009579000000000','0.009195840000000','1.737842580605518','1.668328877381297','181.42212972184132','181.422129721841316','test','test','4.0'),('2019-01-09 11:59:59','2019-01-09 15:59:59','NANOETH','4h','0.006674000000000','0.006763000000000','1.722395091000136','1.745363799885214','258.075380731216','258.075380731216001','test','test','0.0'),('2019-01-09 19:59:59','2019-01-14 15:59:59','NANOETH','4h','0.006715000000000','0.006798000000000','1.727499248530153','1.748851808117347','257.25975406256936','257.259754062569357','test','test','0.0'),('2019-01-15 23:59:59','2019-01-27 19:59:59','NANOETH','4h','0.007035000000000','0.008213000000000','1.732244261771752','2.022305916408159','246.23230444516727','246.232304445167273','test','test','0.0'),('2019-02-27 23:59:59','2019-02-28 03:59:59','NANOETH','4h','0.006418000000000','0.006387000000000','1.796702407246509','1.788024037875265','279.94739907237596','279.947399072375958','test','test','0.5'),('2019-03-01 11:59:59','2019-03-05 15:59:59','NANOETH','4h','0.006545000000000','0.006532000000000','1.794773880719566','1.791209012812865','274.2206082077259','274.220608207725888','test','test','0.4'),('2019-03-09 03:59:59','2019-03-09 07:59:59','NANOETH','4h','0.006510000000000','0.006486000000000','1.793981687851410','1.787367930476843','275.57322394030876','275.573223940308765','test','test','0.4'),('2019-03-09 15:59:59','2019-03-09 19:59:59','NANOETH','4h','0.006552000000000','0.006610000000000','1.792511963990395','1.808379743891409','273.58241208644614','273.582412086446141','test','test','0.0'),('2019-03-09 23:59:59','2019-03-16 07:59:59','NANOETH','4h','0.006633000000000','0.007230000000000','1.796038137301732','1.957689692852634','270.77312487588296','270.773124875882957','test','test','0.0'),('2019-03-17 19:59:59','2019-03-21 15:59:59','NANOETH','4h','0.007329000000000','0.007176000000000','1.831960705201932','1.793716744512084','249.9605273846271','249.960527384627113','test','test','2.2'),('2019-03-21 23:59:59','2019-03-22 03:59:59','NANOETH','4h','0.007230000000000','0.007180000000000','1.823462047270855','1.810851659668705','252.2077520429951','252.207752042995111','test','test','0.7'),('2019-03-24 03:59:59','2019-03-24 07:59:59','NANOETH','4h','0.007249000000000','0.007158000000000','1.820659738914822','1.797804167630335','251.16012400535544','251.160124005355442','test','test','1.3'),('2019-03-24 11:59:59','2019-03-24 15:59:59','NANOETH','4h','0.007188000000000','0.007216000000000','1.815580723073824','1.822653102072999','252.584964256236','252.584964256235992','test','test','0.0'),('2019-03-24 23:59:59','2019-03-25 03:59:59','NANOETH','4h','0.007244000000000','0.007158000000000','1.817152362851419','1.795579322651913','250.84930464541952','250.849304645419522','test','test','1.2'),('2019-03-27 07:59:59','2019-03-29 11:59:59','NANOETH','4h','0.007222000000000','0.007276000000000','1.812358353918196','1.825909634880752','250.94964745474877','250.949647454748771','test','test','0.4'),('2019-03-29 19:59:59','2019-03-30 03:59:59','NANOETH','4h','0.007227000000000','0.007183000000000','1.815369749687652','1.804317270237499','251.1927147762076','251.192714776207595','test','test','0.6'),('2019-03-31 11:59:59','2019-04-07 23:59:59','NANOETH','4h','0.007498000000000','0.008035000000000','1.812913643143174','1.942752883789731','241.7862954312048','241.786295431204792','test','test','0.0'),('2019-04-08 03:59:59','2019-04-12 03:59:59','NANOETH','4h','0.008190000000000','0.008932000000000','1.841766807731298','2.008627732192425','224.87995210394357','224.879952103943566','test','test','0.0'),('2019-04-12 11:59:59','2019-04-13 11:59:59','NANOETH','4h','0.009923000000000','0.009526080000000','1.878847013167103','1.803693132640419','189.34263964195338','189.342639641953383','test','test','4.0'),('2019-04-13 19:59:59','2019-04-16 15:59:59','NANOETH','4h','0.009546000000000','0.009164160000000','1.862146150827840','1.787660304794727','195.07083080115652','195.070830801156518','test','test','4.0'),('2019-04-16 23:59:59','2019-04-21 11:59:59','NANOETH','4h','0.009181000000000','0.009556000000000','1.845593740598260','1.920977430035614','201.02317183294412','201.023171832944115','test','test','0.0'),('2019-04-21 15:59:59','2019-04-26 03:59:59','NANOETH','4h','0.009910000000000','0.010386000000000','1.862345671584339','1.951798400108470','187.92590026078088','187.925900260780878','test','test','1.0'),('2019-06-08 11:59:59','2019-06-08 15:59:59','NANOETH','4h','0.006482000000000','0.006424000000000','1.882224055700812','1.865382186643322','290.37705271533656','290.377052715336561','test','test','0.9'),('2019-06-08 19:59:59','2019-06-09 19:59:59','NANOETH','4h','0.006592000000000','0.006454000000000','1.878481418132480','1.839156412716478','284.96380736233016','284.963807362330158','test','test','2.1'),('2019-06-13 11:59:59','2019-06-13 15:59:59','NANOETH','4h','0.006472000000000','0.006360000000000','1.869742528040035','1.837386044242062','288.8971767676198','288.897176767619783','test','test','1.7'),('2019-06-13 23:59:59','2019-06-14 11:59:59','NANOETH','4h','0.006924000000000','0.006647040000000','1.862552198307153','1.788050110374867','268.9994509397968','268.999450939796816','test','test','4.0'),('2019-07-07 15:59:59','2019-07-07 19:59:59','NANOETH','4h','0.004472000000000','0.004293120000000','1.845996178766645','1.772156331615979','412.789843194688','412.789843194687990','test','test','4.0'),('2019-07-08 03:59:59','2019-07-08 07:59:59','NANOETH','4h','0.004561000000000','0.004426000000000','1.829587323844275','1.775433785427486','401.13732160584846','401.137321605848456','test','test','3.0'),('2019-07-09 03:59:59','2019-07-09 07:59:59','NANOETH','4h','0.004488000000000','0.004401000000000','1.817553204196099','1.782319886735078','404.98066047150166','404.980660471501665','test','test','1.9'),('2019-07-13 03:59:59','2019-07-13 11:59:59','NANOETH','4h','0.004450000000000','0.004371000000000','1.809723578093650','1.777595901089291','406.6794557513821','406.679455751382079','test','test','1.8'),('2019-07-14 15:59:59','2019-07-15 23:59:59','NANOETH','4h','0.004497000000000','0.004444000000000','1.802584094314904','1.781339496361004','400.84147082830856','400.841470828308559','test','test','1.9'),('2019-07-16 11:59:59','2019-07-21 11:59:59','NANOETH','4h','0.004481000000000','0.005357000000000','1.797863072547371','2.149331059950071','401.2191637017118','401.219163701711807','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:14:07
