-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-09 19:59:59','2018-05-10 19:59:59','GXSETH','4h','0.005591000000000','0.005514000000000','1.297777777777778','1.279904608597150','232.11908026789087','232.119080267890865','test','test','1.4'),('2018-05-12 11:59:59','2018-05-12 15:59:59','GXSETH','4h','0.005687000000000','0.005506000000000','1.293805962404305','1.252628033936716','227.50236722424913','227.502367224249127','test','test','3.2'),('2018-05-28 07:59:59','2018-06-02 07:59:59','GXSETH','4h','0.005186000000000','0.005830000000000','1.284655311633730','1.444184432476793','247.7160261538237','247.716026153823691','test','test','0.4'),('2018-06-02 19:59:59','2018-06-14 19:59:59','GXSETH','4h','0.005760000000000','0.006392000000000','1.320106227376632','1.464951216213790','229.1851089195542','229.185108919554210','test','test','0.4'),('2018-06-16 03:59:59','2018-06-16 07:59:59','GXSETH','4h','0.006555000000000','0.006530000000000','1.352294002673778','1.347136512198287','206.29961901964583','206.299619019645831','test','test','0.4'),('2018-07-02 19:59:59','2018-07-02 23:59:59','GXSETH','4h','0.005767000000000','0.005730000000000','1.351147893679225','1.342479179951787','234.28956020101003','234.289560201010033','test','test','0.6'),('2018-07-03 03:59:59','2018-07-03 07:59:59','GXSETH','4h','0.005772000000000','0.005668000000000','1.349221512850906','1.324911215322061','233.75286085428021','233.752860854280215','test','test','1.8'),('2018-07-11 15:59:59','2018-07-13 03:59:59','GXSETH','4h','0.005619000000000','0.005722000000000','1.343819224511162','1.368452322949434','239.15629551720278','239.156295517202778','test','test','1.6'),('2018-07-14 23:59:59','2018-07-24 11:59:59','GXSETH','4h','0.005947000000000','0.006489000000000','1.349293246386334','1.472265659290554','226.88637067199156','226.886370671991557','test','test','3.1'),('2018-07-24 15:59:59','2018-07-24 19:59:59','GXSETH','4h','0.006585000000000','0.006409000000000','1.376620449253938','1.339826949015716','209.05397862626245','209.053978626262449','test','test','2.7'),('2018-08-17 19:59:59','2018-08-17 23:59:59','GXSETH','4h','0.005360000000000','0.005307000000000','1.368444115867667','1.354912858751811','255.30673803501244','255.306738035012444','test','test','1.0'),('2018-08-19 07:59:59','2018-08-19 11:59:59','GXSETH','4h','0.005217000000000','0.005215000000000','1.365437169841921','1.364913713000885','261.728420517907','261.728420517907011','test','test','0.0'),('2018-08-20 23:59:59','2018-08-21 03:59:59','GXSETH','4h','0.005258000000000','0.005061000000000','1.365320846099468','1.314166755821493','259.6654328831245','259.665432883124481','test','test','3.7'),('2018-08-25 15:59:59','2018-08-25 19:59:59','GXSETH','4h','0.005110000000000','0.005067000000000','1.353953270482141','1.342559925936010','264.96150107282597','264.961501072825968','test','test','0.8'),('2018-08-26 15:59:59','2018-08-26 19:59:59','GXSETH','4h','0.005086000000000','0.005081000000000','1.351421416138556','1.350092846126623','265.7140023866606','265.714002386660582','test','test','0.1'),('2018-08-27 15:59:59','2018-08-27 19:59:59','GXSETH','4h','0.005066000000000','0.005113000000000','1.351126178358126','1.363661300818219','266.70473319347144','266.704733193471441','test','test','0.0'),('2018-08-28 15:59:59','2018-08-29 19:59:59','GXSETH','4h','0.005188000000000','0.005082000000000','1.353911761127036','1.326248953363068','260.9698845657355','260.969884565735526','test','test','2.0'),('2018-09-01 11:59:59','2018-09-01 15:59:59','GXSETH','4h','0.005156000000000','0.005081000000000','1.347764470512821','1.328159673133367','261.3972983927116','261.397298392711605','test','test','1.5'),('2018-09-01 19:59:59','2018-09-01 23:59:59','GXSETH','4h','0.005101000000000','0.005140000000000','1.343407848872942','1.353678953775127','263.3616641585851','263.361664158585086','test','test','0.0'),('2018-09-02 03:59:59','2018-09-02 07:59:59','GXSETH','4h','0.005076000000000','0.005102000000000','1.345690316628984','1.352583135429684','265.1084154115413','265.108415411541273','test','test','0.0'),('2018-09-03 15:59:59','2018-09-03 19:59:59','GXSETH','4h','0.005190000000000','0.005119000000000','1.347222054140250','1.328791848775326','259.5803572524566','259.580357252456622','test','test','1.4'),('2018-09-04 15:59:59','2018-09-05 11:59:59','GXSETH','4h','0.005235000000000','0.005129000000000','1.343126452948045','1.315930387234102','256.56665767870965','256.566657678709646','test','test','2.0'),('2018-09-05 15:59:59','2018-09-06 03:59:59','GXSETH','4h','0.005151000000000','0.005070000000000','1.337082882789391','1.316057118179424','259.5773408637916','259.577340863791619','test','test','1.6'),('2018-09-06 19:59:59','2018-09-06 23:59:59','GXSETH','4h','0.005149000000000','0.005215000000000','1.332410490653843','1.349489358857990','258.7707303658657','258.770730365865688','test','test','0.0'),('2018-09-07 03:59:59','2018-09-13 03:59:59','GXSETH','4h','0.005273000000000','0.005515000000000','1.336205794699208','1.397529861135242','253.40523320675297','253.405233206752968','test','test','1.4'),('2018-09-20 15:59:59','2018-09-20 23:59:59','GXSETH','4h','0.005202000000000','0.004993920000000','1.349833365018327','1.295840030417594','259.48353806580684','259.483538065806840','test','test','4.0'),('2018-09-22 11:59:59','2018-09-22 15:59:59','GXSETH','4h','0.005267000000000','0.005056320000000','1.337834846218164','1.284321452369437','254.00319844658517','254.003198446585174','test','test','4.0'),('2018-09-23 03:59:59','2018-09-23 11:59:59','GXSETH','4h','0.005206000000000','0.005187000000000','1.325942980918447','1.321103772958891','254.69515576612508','254.695155766125083','test','test','0.4'),('2018-09-24 07:59:59','2018-09-30 23:59:59','GXSETH','4h','0.005320000000000','0.005894000000000','1.324867601371879','1.467813842572529','249.03526341576674','249.035263415766735','test','test','1.9'),('2018-10-01 11:59:59','2018-10-01 15:59:59','GXSETH','4h','0.005825000000000','0.005833000000000','1.356633432749802','1.358496620296926','232.89844339052385','232.898443390523852','test','test','0.0'),('2018-10-02 07:59:59','2018-10-02 11:59:59','GXSETH','4h','0.005802000000000','0.005767000000000','1.357047474426940','1.348861217687033','233.89304971164083','233.893049711640828','test','test','0.6'),('2018-10-02 23:59:59','2018-10-03 07:59:59','GXSETH','4h','0.005830000000000','0.005889000000000','1.355228306262516','1.368943309704967','232.45768546526867','232.457685465268668','test','test','0.5'),('2018-10-04 07:59:59','2018-10-06 15:59:59','GXSETH','4h','0.006218000000000','0.005972000000000','1.358276084805283','1.304539205284199','218.44259967920283','218.442599679202829','test','test','4.0'),('2018-10-07 23:59:59','2018-10-18 03:59:59','GXSETH','4h','0.006081000000000','0.006814000000000','1.346334556022820','1.508620895369100','221.40019010406516','221.400190104065160','test','test','0.6'),('2018-10-23 11:59:59','2018-10-23 15:59:59','GXSETH','4h','0.007089000000000','0.007028000000000','1.382398186988660','1.370502815369770','195.00609211294403','195.006092112944032','test','test','0.9'),('2018-11-03 11:59:59','2018-11-04 11:59:59','GXSETH','4h','0.006745000000000','0.006720000000000','1.379754771073351','1.374640780076045','204.5596398922685','204.559639892268507','test','test','0.4'),('2018-11-16 11:59:59','2018-11-17 03:59:59','GXSETH','4h','0.006514000000000','0.006253440000000','1.378618328629506','1.323473595484326','211.6392890128194','211.639289012819404','test','test','4.0'),('2018-11-17 15:59:59','2018-11-17 19:59:59','GXSETH','4h','0.006315000000000','0.006221000000000','1.366363943486132','1.346025351136536','216.36800371910243','216.368003719102433','test','test','1.5'),('2018-11-19 07:59:59','2018-11-19 15:59:59','GXSETH','4h','0.006362000000000','0.006206000000000','1.361844256297333','1.328451030270551','214.05914119731736','214.059141197317359','test','test','2.5'),('2018-11-20 07:59:59','2018-11-20 11:59:59','GXSETH','4h','0.006252000000000','0.006303000000000','1.354423539402492','1.365472099944643','216.63844200295785','216.638442002957845','test','test','0.0'),('2018-11-21 19:59:59','2018-11-24 23:59:59','GXSETH','4h','0.006349000000000','0.006313000000000','1.356878775078526','1.349185022376868','213.71535282383465','213.715352823834650','test','test','0.9'),('2018-11-30 23:59:59','2018-12-04 07:59:59','GXSETH','4h','0.006356000000000','0.006197000000000','1.355169052255935','1.321268504850540','213.21098997104082','213.210989971040817','test','test','2.8'),('2019-01-10 07:59:59','2019-01-15 03:59:59','GXSETH','4h','0.003955000000000','0.004097000000000','1.347635597276959','1.396020996724071','340.7422496275496','340.742249627549597','test','test','0.0'),('2019-01-15 11:59:59','2019-01-15 15:59:59','GXSETH','4h','0.004129000000000','0.004171000000000','1.358387908265206','1.372205368218497','328.9871417450245','328.987141745024473','test','test','0.0'),('2019-01-15 23:59:59','2019-01-31 15:59:59','GXSETH','4h','0.004275000000000','0.004999000000000','1.361458454921493','1.592030600269601','318.4698140167235','318.469814016723490','test','test','0.0'),('2019-02-02 11:59:59','2019-02-02 15:59:59','GXSETH','4h','0.005054000000000','0.004966000000000','1.412696709443295','1.388098903659557','279.52052026974565','279.520520269745646','test','test','1.7'),('2019-02-02 23:59:59','2019-02-03 03:59:59','GXSETH','4h','0.004961000000000','0.004963000000000','1.407230530380241','1.407797847667232','283.6586434953117','283.658643495311708','test','test','0.0'),('2019-02-04 15:59:59','2019-02-05 23:59:59','GXSETH','4h','0.005093000000000','0.005036000000000','1.407356600888462','1.391605702351128','276.33155328656227','276.331553286562269','test','test','1.1'),('2019-02-06 23:59:59','2019-02-07 03:59:59','GXSETH','4h','0.005050000000000','0.005075000000000','1.403856401213499','1.410806185377922','277.9913665769305','277.991366576930488','test','test','0.0'),('2019-02-07 11:59:59','2019-02-08 19:59:59','GXSETH','4h','0.005179000000000','0.004971840000000','1.405400797694482','1.349184765786702','271.3652824279748','271.365282427974819','test','test','4.0'),('2019-02-17 03:59:59','2019-02-17 07:59:59','GXSETH','4h','0.004855000000000','0.004824000000000','1.392908346159419','1.384014389675188','286.901822071971','286.901822071971026','test','test','0.6'),('2019-02-23 15:59:59','2019-02-23 19:59:59','GXSETH','4h','0.004564000000000','0.004381440000000','1.390931911385146','1.335294634929740','304.7615932044579','304.761593204457881','test','test','4.0'),('2019-02-26 07:59:59','2019-03-05 15:59:59','GXSETH','4h','0.004550000000000','0.004911000000000','1.378568072172834','1.487944571965008','302.98199388413923','302.981993884139229','test','test','0.0'),('2019-03-06 19:59:59','2019-03-06 23:59:59','GXSETH','4h','0.004784000000000','0.004797000000000','1.402873961015539','1.406686118518299','293.24288482766275','293.242884827662749','test','test','0.0'),('2019-03-07 11:59:59','2019-03-25 15:59:59','GXSETH','4h','0.004940000000000','0.007357000000000','1.403721107127263','2.090521494966655','284.1540702686768','284.154070268676776','test','test','0.2'),('2019-03-27 15:59:59','2019-04-02 15:59:59','GXSETH','4h','0.007801000000000','0.008025000000000','1.556343415536017','1.601032676538461','199.5056294751977','199.505629475197708','test','test','2.4'),('2019-04-02 19:59:59','2019-04-02 23:59:59','GXSETH','4h','0.007904000000000','0.008023000000000','1.566274362425449','1.589855669248403','198.1622422096975','198.162242209697496','test','test','0.0'),('2019-04-04 15:59:59','2019-04-04 19:59:59','GXSETH','4h','0.007913000000000','0.007749000000000','1.571514652830550','1.538944400958414','198.59909678131555','198.599096781315552','test','test','2.1'),('2019-04-12 19:59:59','2019-04-18 19:59:59','GXSETH','4h','0.007573000000000','0.007586000000000','1.564276819081186','1.566962095543362','206.55972785965753','206.559727859657528','test','test','1.8'),('2019-04-21 19:59:59','2019-04-22 11:59:59','GXSETH','4h','0.007866000000000','0.007707000000000','1.564873547183892','1.533241854582540','198.94146290158812','198.941462901588125','test','test','2.0'),('2019-04-22 15:59:59','2019-04-23 15:59:59','GXSETH','4h','0.007728000000000','0.007612000000000','1.557844282161369','1.534460491176545','201.5844050415851','201.584405041585086','test','test','1.5');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:02:59
