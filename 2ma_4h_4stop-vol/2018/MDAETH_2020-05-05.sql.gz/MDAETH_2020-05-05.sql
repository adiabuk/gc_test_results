-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-22 15:59:59','2018-04-03 19:59:59','MDAETH','4h','0.001600200000000','0.001797100000000','1.297777777777778','1.457465594578456','811.0097348942493','811.009734894249277','test','test','0.0'),('2018-04-04 19:59:59','2018-04-04 23:59:59','MDAETH','4h','0.001820000000000','0.001778400000000','1.333263959289040','1.302789354505291','732.5626149939778','732.562614993977832','test','test','2.3'),('2018-04-06 11:59:59','2018-04-07 07:59:59','MDAETH','4h','0.001828300000000','0.001853000000000','1.326491824892651','1.344412487844491','725.5329130299464','725.532913029946371','test','test','0.3'),('2018-04-07 23:59:59','2018-04-08 03:59:59','MDAETH','4h','0.001835600000000','0.001813400000000','1.330474194437504','1.314383255716371','724.8170595105166','724.817059510516629','test','test','1.2'),('2018-04-11 15:59:59','2018-04-11 23:59:59','MDAETH','4h','0.001912800000000','0.001836288000000','1.326898430277253','1.273822493066163','693.6942860086014','693.694286008601352','test','test','4.0'),('2018-04-12 19:59:59','2018-04-12 23:59:59','MDAETH','4h','0.001799700000000','0.001757800000000','1.315103777563677','1.284485981108758','730.7349989240856','730.734998924085630','test','test','2.3'),('2018-04-14 07:59:59','2018-04-14 19:59:59','MDAETH','4h','0.001825200000000','0.001779800000000','1.308299822795917','1.275757190780283','716.7980620183636','716.798062018363566','test','test','2.5'),('2018-04-15 11:59:59','2018-04-15 15:59:59','MDAETH','4h','0.001852400000000','0.001856800000000','1.301068126792443','1.304158549896463','702.3688872772851','702.368887277285125','test','test','0.0'),('2018-04-17 19:59:59','2018-04-18 07:59:59','MDAETH','4h','0.001894000000000','0.001875000000000','1.301754887482225','1.288696100332192','687.3045868438358','687.304586843835750','test','test','1.6'),('2018-04-18 11:59:59','2018-04-21 03:59:59','MDAETH','4h','0.001892800000000','0.001894400000000','1.298852934782218','1.299950866257097','686.2071717995656','686.207171799565572','test','test','0.0'),('2018-04-23 11:59:59','2018-04-24 03:59:59','MDAETH','4h','0.001935200000000','0.001858600000000','1.299096919554413','1.247675451986271','671.2985322211725','671.298532221172536','test','test','4.0'),('2018-04-30 15:59:59','2018-05-01 03:59:59','MDAETH','4h','0.001899800000000','0.001825900000000','1.287669926761492','1.237581071309511','677.7923606492749','677.792360649274883','test','test','3.9'),('2018-05-01 15:59:59','2018-05-01 19:59:59','MDAETH','4h','0.001899900000000','0.001823904000000','1.276539069994386','1.225477507194610','671.8980314723858','671.898031472385810','test','test','4.0'),('2018-05-02 19:59:59','2018-05-03 03:59:59','MDAETH','4h','0.001818500000000','0.001773700000000','1.265192056038880','1.234023178331681','695.7338773928402','695.733877392840213','test','test','2.5'),('2018-06-01 15:59:59','2018-06-01 19:59:59','MDAETH','4h','0.001395800000000','0.001339968000000','1.258265638770613','1.207935013219789','901.4655672521948','901.465567252194774','test','test','4.0'),('2018-06-02 07:59:59','2018-06-02 19:59:59','MDAETH','4h','0.001381000000000','0.001325760000000','1.247081055314875','1.197197813102280','903.0275563467594','903.027556346759411','test','test','4.0'),('2018-06-06 11:59:59','2018-06-06 15:59:59','MDAETH','4h','0.001288900000000','0.001266400000000','1.235995890378743','1.214419423986066','958.9540618967668','958.954061896766802','test','test','1.7'),('2018-06-07 03:59:59','2018-06-07 11:59:59','MDAETH','4h','0.001285500000000','0.001280100000000','1.231201120069259','1.226029213380520','957.7604979146315','957.760497914631515','test','test','0.4'),('2018-06-29 23:59:59','2018-06-30 03:59:59','MDAETH','4h','0.000976100000000','0.001002200000000','1.230051807471761','1.262942241008297','1260.1698673002368','1260.169867300236774','test','test','0.0'),('2018-06-30 07:59:59','2018-06-30 11:59:59','MDAETH','4h','0.001123000000000','0.001078080000000','1.237360792702103','1.187866360994019','1101.8350780962624','1101.835078096262350','test','test','4.0'),('2018-06-30 15:59:59','2018-07-10 03:59:59','MDAETH','4h','0.001109800000000','0.001123600000000','1.226362030100306','1.241611440818799','1105.029762209683','1105.029762209682985','test','test','2.3'),('2018-07-17 07:59:59','2018-07-30 19:59:59','MDAETH','4h','0.001150800000000','0.001346900000000','1.229750788037749','1.439304254786274','1068.6051338527539','1068.605133852753852','test','test','0.0'),('2018-07-31 03:59:59','2018-07-31 15:59:59','MDAETH','4h','0.001349600000000','0.001341200000000','1.276318225092977','1.268374335725178','945.7011152141203','945.701115214120250','test','test','0.6'),('2018-07-31 19:59:59','2018-08-01 03:59:59','MDAETH','4h','0.001363600000000','0.001367700000000','1.274552916344577','1.278385174306599','934.6970639077275','934.697063907727511','test','test','1.2'),('2018-08-01 07:59:59','2018-08-01 11:59:59','MDAETH','4h','0.001347200000000','0.001348300000000','1.275404529225026','1.276445907626264','946.7076374888854','946.707637488885439','test','test','0.0'),('2018-08-10 03:59:59','2018-08-10 07:59:59','MDAETH','4h','0.001295000000000','0.001252800000000','1.275635946647524','1.234066960586887','985.047063048281','985.047063048280961','test','test','3.3'),('2018-08-11 03:59:59','2018-08-11 07:59:59','MDAETH','4h','0.001298100000000','0.001270600000000','1.266398394189604','1.239569986639944','975.578456351286','975.578456351286036','test','test','2.1'),('2018-08-13 23:59:59','2018-08-14 23:59:59','MDAETH','4h','0.001253000000000','0.001239500000000','1.260436525845235','1.246856403659353','1005.9349767320315','1005.934976732031487','test','test','1.1'),('2018-08-15 03:59:59','2018-08-15 19:59:59','MDAETH','4h','0.001269400000000','0.001232900000000','1.257418720915040','1.221263227521784','990.5614628289268','990.561462828926778','test','test','2.9'),('2018-08-17 11:59:59','2018-09-07 07:59:59','MDAETH','4h','0.001309200000000','0.002634200000000','1.249384166827649','2.513846449936903','954.311157063588','954.311157063587984','test','test','1.4'),('2018-09-07 19:59:59','2018-09-07 23:59:59','MDAETH','4h','0.002686100000000','0.002637700000000','1.530375785296372','1.502800420265903','569.7389469105292','569.738946910529194','test','test','1.8'),('2018-09-17 03:59:59','2018-09-17 07:59:59','MDAETH','4h','0.002506200000000','0.002463200000000','1.524247926400713','1.498095719539636','608.1908572343439','608.190857234343866','test','test','1.7'),('2018-10-04 11:59:59','2018-10-04 15:59:59','MDAETH','4h','0.002020800000000','0.001996500000000','1.518436324876029','1.500177218237823','751.4035653582882','751.403565358288233','test','test','1.2'),('2018-10-07 15:59:59','2018-10-20 15:59:59','MDAETH','4h','0.002136500000000','0.009737700000000','1.514378745623094','6.902207306929092','708.8128928729672','708.812892872967154','test','test','0.0'),('2018-10-21 15:59:59','2018-10-21 23:59:59','MDAETH','4h','0.009081200000000','0.008717952000000','2.711673981468872','2.603207022210117','298.6030460147196','298.603046014719610','test','test','4.0'),('2018-10-22 19:59:59','2018-10-22 23:59:59','MDAETH','4h','0.008790100000000','0.008438496000000','2.687570212744703','2.580067404234915','305.7496743773908','305.749674377390818','test','test','4.0'),('2018-11-12 07:59:59','2018-11-12 15:59:59','MDAETH','4h','0.006735100000000','0.006465696000000','2.663680699742529','2.557133471752828','395.4923757245666','395.492375724566614','test','test','4.0'),('2018-11-12 23:59:59','2018-11-13 07:59:59','MDAETH','4h','0.006653000000000','0.006386880000000','2.640003537967039','2.534403396448357','396.8139993938132','396.813999393813219','test','test','4.0'),('2018-11-22 11:59:59','2018-11-22 15:59:59','MDAETH','4h','0.005463500000000','0.005530700000000','2.616536839851777','2.648719740124137','478.9122064339301','478.912206433930123','test','test','0.0'),('2018-11-22 23:59:59','2018-11-23 03:59:59','MDAETH','4h','0.005704500000000','0.005476320000000','2.623688595467857','2.518741051649142','459.93313970862596','459.933139708625959','test','test','4.0'),('2018-11-25 19:59:59','2018-11-30 15:59:59','MDAETH','4h','0.005917300000000','0.008283200000000','2.600366919063698','3.640065446062971','439.4515943189795','439.451594318979517','test','test','0.0'),('2018-12-07 15:59:59','2018-12-07 19:59:59','MDAETH','4h','0.007575600000000','0.007272576000000','2.831411036174648','2.718154594727662','373.75403085889536','373.754030858895362','test','test','4.0'),('2018-12-11 03:59:59','2018-12-20 19:59:59','MDAETH','4h','0.007458000000000','0.009143600000000','2.806242938075318','3.440488459182820','376.2728530538103','376.272853053810309','test','test','2.0'),('2018-12-20 23:59:59','2018-12-21 03:59:59','MDAETH','4h','0.009058300000000','0.008809700000000','2.947186387210318','2.866302497754185','325.35756016143404','325.357560161434037','test','test','2.7'),('2019-01-10 11:59:59','2019-01-10 15:59:59','MDAETH','4h','0.005887700000000','0.005654800000000','2.929212189553400','2.813341218045513','497.513832150653','497.513832150653002','test','test','4.0'),('2019-01-17 03:59:59','2019-01-20 15:59:59','MDAETH','4h','0.005848500000000','0.005899800000000','2.903463084773869','2.928930752765474','496.44576981685367','496.445769816853669','test','test','0.0'),('2019-01-21 23:59:59','2019-01-31 03:59:59','MDAETH','4h','0.005962800000000','0.006341800000000','2.909122566549781','3.094028559157677','487.8786084641077','487.878608464107685','test','test','0.7'),('2019-01-31 15:59:59','2019-02-06 23:59:59','MDAETH','4h','0.006709000000000','0.006697800000000','2.950212787129314','2.945287703925282','439.7395717885399','439.739571788539877','test','test','1.3'),('2019-02-23 07:59:59','2019-02-23 19:59:59','MDAETH','4h','0.006221500000000','0.005972640000000','2.949118324195085','2.831153591227281','474.0204651924914','474.020465192491372','test','test','4.0'),('2019-02-24 23:59:59','2019-03-02 15:59:59','MDAETH','4h','0.006162200000000','0.006436200000000','2.922903939091128','3.052869808311693','474.3279898560787','474.327989856078716','test','test','0.0'),('2019-03-07 19:59:59','2019-03-09 03:59:59','MDAETH','4h','0.006495600000000','0.006344300000000','2.951785243362365','2.883030223453392','454.4284197552752','454.428419755275172','test','test','2.4'),('2019-03-09 19:59:59','2019-03-12 19:59:59','MDAETH','4h','0.006945000000000','0.007400400000000','2.936506350049260','3.129059984579488','422.8230885600086','422.823088560008614','test','test','2.5'),('2019-03-12 23:59:59','2019-03-13 03:59:59','MDAETH','4h','0.008161400000000','0.007834944000000','2.979296046611533','2.860124204747071','365.0471789903121','365.047178990312091','test','test','4.0'),('2019-03-13 07:59:59','2019-03-14 15:59:59','MDAETH','4h','0.008747000000000','0.008397120000000','2.952813415086097','2.834700878482653','337.58013205511566','337.580132055115655','test','test','4.0'),('2019-03-18 11:59:59','2019-03-18 19:59:59','MDAETH','4h','0.008097200000000','0.007773312000000','2.926566184729776','2.809503537340585','361.4294058106229','361.429405810622882','test','test','4.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:33:19
