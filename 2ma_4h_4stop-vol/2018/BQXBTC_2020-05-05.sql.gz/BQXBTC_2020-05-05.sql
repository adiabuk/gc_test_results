-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-21 07:59:59','2018-03-21 11:59:59','BQXBTC','4h','0.000336980000000','0.000332860000000','0.033333333333333','0.032925791837300','98.91783884305696','98.917838843056956','test','test','1.2'),('2018-03-21 15:59:59','2018-03-21 19:59:59','BQXBTC','4h','0.000336710000000','0.000323241600000','0.033242768556437','0.031913057814180','98.72818911359066','98.728189113590659','test','test','4.0'),('2018-03-24 19:59:59','2018-03-24 23:59:59','BQXBTC','4h','0.000331340000000','0.000318220000000','0.032947277280380','0.031642670900472','99.43646188320155','99.436461883201545','test','test','4.0'),('2018-03-25 15:59:59','2018-03-28 03:59:59','BQXBTC','4h','0.000347060000000','0.000335850000000','0.032657364751512','0.031602535445731','94.09717268343098','94.097172683430983','test','test','3.2'),('2018-04-11 15:59:59','2018-04-12 11:59:59','BQXBTC','4h','0.000295720000000','0.000296240000000','0.032422958239116','0.032479971421465','109.64073528714924','109.640735287149241','test','test','0.0'),('2018-04-12 15:59:59','2018-04-12 19:59:59','BQXBTC','4h','0.000294480000000','0.000289980000000','0.032435627835193','0.031939973375609','110.1454354631667','110.145435463166706','test','test','1.5'),('2018-04-13 15:59:59','2018-04-21 11:59:59','BQXBTC','4h','0.000304190000000','0.000325790000000','0.032325482399730','0.034620858381301','106.26740655422671','106.267406554226710','test','test','0.7'),('2018-04-22 23:59:59','2018-04-25 15:59:59','BQXBTC','4h','0.000337490000000','0.000356310000000','0.032835565951190','0.034666628652904','97.29344855015096','97.293448550150956','test','test','0.0'),('2018-04-27 15:59:59','2018-05-03 19:59:59','BQXBTC','4h','0.000369570000000','0.000375610000000','0.033242468773794','0.033785761009077','89.94904557673392','89.949045576733923','test','test','0.4'),('2018-05-08 07:59:59','2018-05-11 15:59:59','BQXBTC','4h','0.000381490000000','0.000398170000000','0.033363200381634','0.034821949450720','87.45498016103758','87.454980161037582','test','test','0.0'),('2018-05-14 15:59:59','2018-05-14 19:59:59','BQXBTC','4h','0.000404020000000','0.000403540000000','0.033687366841431','0.033647344228481','83.38044364494607','83.380443644946070','test','test','0.1'),('2018-05-14 23:59:59','2018-05-15 03:59:59','BQXBTC','4h','0.000400470000000','0.000395040000000','0.033678472927442','0.033221824219684','84.09736791130979','84.097367911309789','test','test','1.4'),('2018-05-31 15:59:59','2018-05-31 19:59:59','BQXBTC','4h','0.000342300000000','0.000328608000000','0.033576995436829','0.032233915619356','98.09230335036322','98.092303350363224','test','test','4.0'),('2018-05-31 23:59:59','2018-06-01 07:59:59','BQXBTC','4h','0.000329000000000','0.000317950000000','0.033278533255169','0.032160819600246','101.15055700659171','101.150557006591711','test','test','3.6'),('2018-06-02 11:59:59','2018-06-02 19:59:59','BQXBTC','4h','0.000318870000000','0.000320380000000','0.033030152442964','0.033186565809505','103.5850109541931','103.585010954193095','test','test','0.8'),('2018-06-02 23:59:59','2018-06-03 19:59:59','BQXBTC','4h','0.000317200000000','0.000316480000000','0.033064910968862','0.032989858207520','104.23994630788637','104.239946307886370','test','test','0.2'),('2018-06-03 23:59:59','2018-06-04 03:59:59','BQXBTC','4h','0.000321970000000','0.000313710000000','0.033048232577452','0.032200394576738','102.6438257522509','102.643825752250905','test','test','2.6'),('2018-06-09 03:59:59','2018-06-10 03:59:59','BQXBTC','4h','0.000319120000000','0.000309290000000','0.032859824132849','0.031847627870547','102.97011824031433','102.970118240314335','test','test','3.1'),('2018-06-28 15:59:59','2018-06-28 19:59:59','BQXBTC','4h','0.000242090000000','0.000232406400000','0.032634891630115','0.031329495964910','134.80479007854655','134.804790078546546','test','test','4.0'),('2018-06-29 07:59:59','2018-06-30 15:59:59','BQXBTC','4h','0.000227610000000','0.000222460000000','0.032344803704514','0.031612956513801','142.10625062393666','142.106250623936660','test','test','2.3'),('2018-07-02 19:59:59','2018-07-02 23:59:59','BQXBTC','4h','0.000260250000000','0.000249840000000','0.032182170995467','0.030894884155648','123.65867817662587','123.658678176625870','test','test','4.0'),('2018-07-03 15:59:59','2018-07-03 23:59:59','BQXBTC','4h','0.000246950000000','0.000237072000000','0.031896107253285','0.030620262963154','129.1601832487746','129.160183248774587','test','test','4.0'),('2018-07-04 11:59:59','2018-07-07 23:59:59','BQXBTC','4h','0.000238620000000','0.000254330000000','0.031612586299922','0.033693860840077','132.48087461202934','132.480874612029339','test','test','0.0'),('2018-08-17 11:59:59','2018-08-17 15:59:59','BQXBTC','4h','0.000080770000000','0.000077539200000','0.032075091753290','0.030792088083158','397.1164015511975','397.116401551197498','test','test','4.0'),('2018-08-17 19:59:59','2018-08-18 03:59:59','BQXBTC','4h','0.000081640000000','0.000078374400000','0.031789979826594','0.030518380633530','389.39220757709734','389.392207577097338','test','test','4.0'),('2018-08-19 19:59:59','2018-08-19 23:59:59','BQXBTC','4h','0.000076880000000','0.000075490000000','0.031507402228136','0.030937744461524','409.82573137533234','409.825731375332339','test','test','1.8'),('2018-08-26 15:59:59','2018-08-29 19:59:59','BQXBTC','4h','0.000073090000000','0.000073580000000','0.031380811613333','0.031591190566549','429.3448024809534','429.344802480953376','test','test','1.3'),('2018-09-26 19:59:59','2018-09-28 11:59:59','BQXBTC','4h','0.000052020000000','0.000050540000000','0.031427562491825','0.030533429610474','604.1438387509677','604.143838750967689','test','test','2.8'),('2018-09-30 07:59:59','2018-10-01 23:59:59','BQXBTC','4h','0.000052310000000','0.000051390000000','0.031228866295970','0.030679629878606','596.996105830043','596.996105830043007','test','test','2.3'),('2018-10-02 03:59:59','2018-10-02 19:59:59','BQXBTC','4h','0.000051730000000','0.000050590000000','0.031106813758778','0.030421297275403','601.3302485748609','601.330248574860889','test','test','2.2'),('2018-10-05 03:59:59','2018-10-05 23:59:59','BQXBTC','4h','0.000051080000000','0.000050710000000','0.030954476762472','0.030730256785923','605.9999366184809','605.999936618480888','test','test','0.7'),('2018-10-06 03:59:59','2018-10-09 11:59:59','BQXBTC','4h','0.000051330000000','0.000050770000000','0.030904650101017','0.030567486569816','602.0777342882656','602.077734288265560','test','test','1.1'),('2018-10-13 15:59:59','2018-10-15 07:59:59','BQXBTC','4h','0.000053100000000','0.000054200000000','0.030829724871861','0.031468382072596','580.5974552139527','580.597455213952685','test','test','0.0'),('2018-10-19 15:59:59','2018-10-26 15:59:59','BQXBTC','4h','0.000058270000000','0.000060550000000','0.030971648694246','0.032183513444939','531.5196274969356','531.519627496935641','test','test','0.0'),('2018-11-01 07:59:59','2018-11-01 11:59:59','BQXBTC','4h','0.000060980000000','0.000060240000000','0.031240951972178','0.030861839075172','512.3147256834736','512.314725683473625','test','test','1.2'),('2018-11-01 19:59:59','2018-11-02 15:59:59','BQXBTC','4h','0.000061560000000','0.000061530000000','0.031156704661732','0.031141521082462','506.11930899500396','506.119308995003962','test','test','0.4'),('2018-11-12 03:59:59','2018-11-12 07:59:59','BQXBTC','4h','0.000055370000000','0.000055060000000','0.031153330533006','0.030978912392041','562.6391644032108','562.639164403210771','test','test','0.6'),('2018-12-15 15:59:59','2018-12-15 19:59:59','BQXBTC','4h','0.000028200000000','0.000027230000000','0.031114570946125','0.030044317973865','1103.3535796498109','1103.353579649810854','test','test','3.4'),('2018-12-15 23:59:59','2018-12-16 15:59:59','BQXBTC','4h','0.000028040000000','0.000027310000000','0.030876736952289','0.030072884670721','1101.167508997472','1101.167508997471941','test','test','2.6'),('2018-12-21 03:59:59','2018-12-25 11:59:59','BQXBTC','4h','0.000027980000000','0.000028720000000','0.030698103111941','0.031509990041992','1097.144500069359','1097.144500069359083','test','test','0.0'),('2018-12-28 03:59:59','2019-01-01 23:59:59','BQXBTC','4h','0.000028880000000','0.000030720000000','0.030878522429730','0.032845852113619','1069.2009151568484','1069.200915156848396','test','test','0.0'),('2019-01-09 07:59:59','2019-01-09 15:59:59','BQXBTC','4h','0.000032010000000','0.000030729600000','0.031315706803927','0.030063078531770','978.3101157115693','978.310115711569324','test','test','4.0'),('2019-01-09 19:59:59','2019-01-09 23:59:59','BQXBTC','4h','0.000030140000000','0.000029980000000','0.031037344965670','0.030872581356031','1029.7725602412154','1029.772560241215388','test','test','0.5'),('2019-01-15 03:59:59','2019-01-15 07:59:59','BQXBTC','4h','0.000029610000000','0.000029100000000','0.031000730830195','0.030466777006372','1046.9682820059065','1046.968282005906531','test','test','1.7'),('2019-01-15 15:59:59','2019-01-15 19:59:59','BQXBTC','4h','0.000029430000000','0.000029280000000','0.030882074424901','0.030724673433948','1049.3399396840261','1049.339939684026149','test','test','0.5'),('2019-01-15 23:59:59','2019-01-24 07:59:59','BQXBTC','4h','0.000029500000000','0.000047060000000','0.030847096426911','0.049208961283065','1045.6642856580115','1045.664285658011522','test','test','0.0'),('2019-01-25 03:59:59','2019-01-25 07:59:59','BQXBTC','4h','0.000050120000000','0.000048115200000','0.034927510839390','0.033530410405814','696.8777102831206','696.877710283120564','test','test','4.0'),('2019-01-25 19:59:59','2019-01-27 03:59:59','BQXBTC','4h','0.000050100000000','0.000048096000000','0.034617044076373','0.033232362313318','690.9589636002618','690.958963600261768','test','test','4.0'),('2019-01-29 11:59:59','2019-01-29 15:59:59','BQXBTC','4h','0.000047280000000','0.000045550000000','0.034309337017916','0.033053940379993','725.6627964872345','725.662796487234459','test','test','3.7'),('2019-02-12 23:59:59','2019-02-13 03:59:59','BQXBTC','4h','0.000041550000000','0.000040140000000','0.034030359987267','0.032875539106833','819.0219010172536','819.021901017253640','test','test','3.4'),('2019-02-13 19:59:59','2019-02-13 23:59:59','BQXBTC','4h','0.000040520000000','0.000040170000000','0.033773733124948','0.033482005420266','833.5077276640727','833.507727664072718','test','test','0.9'),('2019-02-16 07:59:59','2019-02-16 11:59:59','BQXBTC','4h','0.000040480000000','0.000039580000000','0.033708904746130','0.032959447871834','832.7298603292987','832.729860329298731','test','test','2.2'),('2019-02-17 03:59:59','2019-02-17 15:59:59','BQXBTC','4h','0.000040660000000','0.000040320000000','0.033542358774064','0.033261876679052','824.9473382701483','824.947338270148293','test','test','0.8'),('2019-02-17 23:59:59','2019-02-18 15:59:59','BQXBTC','4h','0.000040540000000','0.000040050000000','0.033480029419617','0.033075362068467','825.8517370403824','825.851737040382432','test','test','1.2'),('2019-02-18 19:59:59','2019-02-18 23:59:59','BQXBTC','4h','0.000040340000000','0.000040580000000','0.033390103341584','0.033588755418976','827.7169891319728','827.716989131972809','test','test','0.0'),('2019-02-24 19:59:59','2019-02-24 23:59:59','BQXBTC','4h','0.000040120000000','0.000038515200000','0.033434248247671','0.032096878317764','833.356137778437','833.356137778436960','test','test','4.0'),('2019-03-08 03:59:59','2019-03-08 07:59:59','BQXBTC','4h','0.000038300000000','0.000038190000000','0.033137054929914','0.033041883231682','865.1972566557122','865.197256655712181','test','test','0.3'),('2019-03-08 11:59:59','2019-03-08 23:59:59','BQXBTC','4h','0.000039030000000','0.000037500000000','0.033115905663640','0.031817741798271','848.4731146205484','848.473114620548358','test','test','3.9'),('2019-03-09 03:59:59','2019-03-09 15:59:59','BQXBTC','4h','0.000038660000000','0.000039170000000','0.032827424804669','0.033260481883054','849.1315262459677','849.131526245967734','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:43:06
