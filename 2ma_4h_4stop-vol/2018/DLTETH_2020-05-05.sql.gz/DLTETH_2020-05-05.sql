-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-28 15:59:59','2018-04-28 19:59:59','DLTETH','4h','0.000423680000000','0.000421320000000','1.297777777777778','1.290548841893253','3063.1084256461895','3063.108425646189517','test','test','0.6'),('2018-04-29 07:59:59','2018-04-29 11:59:59','DLTETH','4h','0.000422050000000','0.000408100000000','1.296171347581217','1.253329053306231','3071.132206092209','3071.132206092208889','test','test','3.3'),('2018-04-29 15:59:59','2018-04-29 19:59:59','DLTETH','4h','0.000419160000000','0.000430070000000','1.286650837742331','1.320140103511414','3069.5935627023828','3069.593562702382769','test','test','0.0'),('2018-04-29 23:59:59','2018-04-30 11:59:59','DLTETH','4h','0.000433500000000','0.000436000000000','1.294092896802127','1.301555946956695','2985.2200618272823','2985.220061827282279','test','test','2.7'),('2018-04-30 19:59:59','2018-05-01 03:59:59','DLTETH','4h','0.000460010000000','0.000441609600000','1.295751352392031','1.243921298296350','2816.7895315145997','2816.789531514599730','test','test','4.0'),('2018-05-01 11:59:59','2018-05-03 15:59:59','DLTETH','4h','0.000455190000000','0.000439420000000','1.284233562592991','1.239741453183532','2821.3132155649087','2821.313215564908660','test','test','3.5'),('2018-05-13 23:59:59','2018-05-15 11:59:59','DLTETH','4h','0.000402820000000','0.000413710000000','1.274346427168667','1.308797627684696','3163.562949130298','3163.562949130297966','test','test','2.1'),('2018-05-31 23:59:59','2018-06-01 07:59:59','DLTETH','4h','0.000359990000000','0.000345590400000','1.282002249505562','1.230722159525339','3561.2162824121842','3561.216282412184228','test','test','4.0'),('2018-06-02 07:59:59','2018-06-02 11:59:59','DLTETH','4h','0.000330320000000','0.000327450000000','1.270606673954401','1.259566951399760','3846.5932246137118','3846.593224613711755','test','test','0.9'),('2018-07-01 23:59:59','2018-07-06 07:59:59','DLTETH','4h','0.000200310000000','0.000207660000000','1.268153402275592','1.314685914415403','6330.954032627387','6330.954032627387278','test','test','0.0'),('2018-07-08 07:59:59','2018-07-09 11:59:59','DLTETH','4h','0.000220800000000','0.000211968000000','1.278493960528883','1.227354202107728','5790.280618337334','5790.280618337334090','test','test','4.0'),('2018-07-17 19:59:59','2018-07-19 03:59:59','DLTETH','4h','0.000203180000000','0.000197690000000','1.267129569768627','1.232891252325819','6236.487694500575','6236.487694500575344','test','test','2.7'),('2018-07-19 07:59:59','2018-07-20 07:59:59','DLTETH','4h','0.000200710000000','0.000193080000000','1.259521054781336','1.211640303209508','6275.327860003667','6275.327860003667411','test','test','3.8'),('2018-07-23 15:59:59','2018-07-23 19:59:59','DLTETH','4h','0.000200100000000','0.000192590000000','1.248880887765374','1.202008846450442','6241.283796928407','6241.283796928407355','test','test','3.8'),('2018-07-30 03:59:59','2018-07-30 07:59:59','DLTETH','4h','0.000189190000000','0.000190390000000','1.238464878584278','1.246320250719704','6546.143446187845','6546.143446187845257','test','test','0.0'),('2018-07-30 11:59:59','2018-07-30 15:59:59','DLTETH','4h','0.000192350000000','0.000184656000000','1.240210516836595','1.190602096163131','6447.676198786562','6447.676198786562054','test','test','4.0'),('2018-08-13 19:59:59','2018-08-14 03:59:59','DLTETH','4h','0.000148830000000','0.000144320000000','1.229186423353603','1.191938349918645','8258.996327041612','8258.996327041611949','test','test','3.0'),('2018-08-17 15:59:59','2018-08-17 19:59:59','DLTETH','4h','0.000144550000000','0.000144260000000','1.220909073701390','1.218459653906347','8446.275155319201','8446.275155319201076','test','test','0.2'),('2018-08-20 11:59:59','2018-08-21 07:59:59','DLTETH','4h','0.000150560000000','0.000144537600000','1.220364758191381','1.171550167863726','8105.504504459223','8105.504504459223426','test','test','4.0'),('2018-08-21 11:59:59','2018-08-21 19:59:59','DLTETH','4h','0.000145380000000','0.000143790000000','1.209517071451902','1.196288758454182','8319.693709257821','8319.693709257820956','test','test','1.1'),('2018-08-22 11:59:59','2018-08-22 19:59:59','DLTETH','4h','0.000153230000000','0.000147100800000','1.206577446341297','1.158314348487645','7874.289932397686','7874.289932397686243','test','test','4.0'),('2018-08-23 11:59:59','2018-08-30 15:59:59','DLTETH','4h','0.000146870000000','0.000162000000000','1.195852313484930','1.319044561752289','8142.25038118697','8142.250381186970117','test','test','0.0'),('2018-08-31 07:59:59','2018-09-01 07:59:59','DLTETH','4h','0.000167160000000','0.000161550000000','1.223228368655455','1.182176016728217','7317.709790951511','7317.709790951511422','test','test','3.4'),('2018-09-01 11:59:59','2018-09-02 03:59:59','DLTETH','4h','0.000172500000000','0.000165600000000','1.214105623782735','1.165541398831426','7038.293471204262','7038.293471204261550','test','test','4.0'),('2018-09-02 15:59:59','2018-09-06 03:59:59','DLTETH','4h','0.000172280000000','0.000165388800000','1.203313573793555','1.155181030841813','6984.638807717409','6984.638807717408781','test','test','4.0'),('2018-09-07 19:59:59','2018-09-07 23:59:59','DLTETH','4h','0.000170310000000','0.000169470000000','1.192617453137612','1.186735246217081','7002.627286346148','7002.627286346148139','test','test','0.5'),('2018-09-08 19:59:59','2018-09-12 11:59:59','DLTETH','4h','0.000173190000000','0.000175460000000','1.191310296044161','1.206924790945831','6878.632115273176','6878.632115273176169','test','test','0.0'),('2018-09-12 19:59:59','2018-09-12 23:59:59','DLTETH','4h','0.000174680000000','0.000176770000000','1.194780183800088','1.209075412699459','6839.822439890587','6839.822439890586793','test','test','0.0'),('2018-09-16 03:59:59','2018-09-19 07:59:59','DLTETH','4h','0.000182150000000','0.000189040000000','1.197956901333281','1.243270780280227','6576.76036965842','6576.760369658420132','test','test','0.0'),('2018-09-20 15:59:59','2018-09-20 23:59:59','DLTETH','4h','0.000213590000000','0.000205046400000','1.208026652210381','1.159705586121966','5655.8202734696415','5655.820273469641506','test','test','4.0'),('2018-09-22 07:59:59','2018-10-06 23:59:59','DLTETH','4h','0.000201350000000','0.000295720000000','1.197288637524066','1.758441499322656','5946.305624653917','5946.305624653917221','test','test','0.8'),('2018-10-07 03:59:59','2018-10-07 07:59:59','DLTETH','4h','0.000329690000000','0.000316502400000','1.321989273479308','1.269109702540136','4009.794878459487','4009.794878459486881','test','test','4.0'),('2018-10-07 19:59:59','2018-10-10 03:59:59','DLTETH','4h','0.000308750000000','0.000296400000000','1.310238257715048','1.257828727406446','4243.686664664123','4243.686664664122873','test','test','4.0'),('2018-10-10 11:59:59','2018-10-15 07:59:59','DLTETH','4h','0.000410000000000','0.000393600000000','1.298591695424247','1.246648027607277','3167.2968181079204','3167.296818107920444','test','test','4.0'),('2018-10-16 07:59:59','2018-10-22 03:59:59','DLTETH','4h','0.000418170000000','0.000435980000000','1.287048658131588','1.341864490451754','3077.8120336982274','3077.812033698227424','test','test','0.0'),('2018-10-22 19:59:59','2018-10-26 23:59:59','DLTETH','4h','0.000451610000000','0.000454420000000','1.299229954202736','1.307314000550934','2876.8848214227664','2876.884821422766436','test','test','1.1'),('2018-10-27 07:59:59','2018-10-27 15:59:59','DLTETH','4h','0.000475370000000','0.000456355200000','1.301026408946780','1.248985352588909','2736.871087672296','2736.871087672296198','test','test','4.0'),('2018-10-28 15:59:59','2018-10-29 11:59:59','DLTETH','4h','0.000483570000000','0.000464227200000','1.289461729756141','1.237883260565895','2666.54616654495','2666.546166544950211','test','test','4.0'),('2018-10-30 15:59:59','2018-10-30 19:59:59','DLTETH','4h','0.000465500000000','0.000461920000000','1.277999847713865','1.268171191527365','2745.4346889664116','2745.434688966411613','test','test','0.8'),('2018-10-30 23:59:59','2018-10-31 23:59:59','DLTETH','4h','0.000521990000000','0.000501110400000','1.275815701894642','1.224783073818856','2444.1382055109148','2444.138205510914759','test','test','4.0'),('2018-11-28 07:59:59','2018-12-05 23:59:59','DLTETH','4h','0.000356500000000','0.000376320000000','1.264475117877801','1.334774968751119','3546.9147766558235','3546.914776655823516','test','test','0.0'),('2018-12-19 15:59:59','2018-12-19 19:59:59','DLTETH','4h','0.000355990000000','0.000356480000000','1.280097306960761','1.281859288141162','3595.8799600010134','3595.879960001013387','test','test','0.0'),('2018-12-20 11:59:59','2018-12-20 19:59:59','DLTETH','4h','0.000376780000000','0.000361708800000','1.280488858334183','1.229269304000816','3398.5053833382426','3398.505383338242609','test','test','4.0'),('2019-01-01 03:59:59','2019-01-01 07:59:59','DLTETH','4h','0.000301060000000','0.000296400000000','1.269106735148990','1.249462686169403','4215.461154417691','4215.461154417691432','test','test','1.5'),('2019-01-01 11:59:59','2019-01-01 15:59:59','DLTETH','4h','0.000296000000000','0.000287030000000','1.264741390931304','1.226414599456123','4272.774969362515','4272.774969362514639','test','test','3.0'),('2019-01-01 23:59:59','2019-01-05 03:59:59','DLTETH','4h','0.000295300000000','0.000308540000000','1.256224326159042','1.312548098859163','4254.061382184361','4254.061382184360809','test','test','0.0'),('2019-01-07 15:59:59','2019-01-28 07:59:59','DLTETH','4h','0.000350440000000','0.001133500000000','1.268740720092402','4.103748448307092','3620.4220981977005','3620.422098197700507','test','test','0.0'),('2019-01-28 15:59:59','2019-01-29 23:59:59','DLTETH','4h','0.001159220000000','0.001112851200000','1.898742437473445','1.822792739974507','1637.948307891034','1637.948307891033892','test','test','4.0'),('2019-01-30 15:59:59','2019-01-30 19:59:59','DLTETH','4h','0.001099010000000','0.001107560000000','1.881864726918125','1.896505124562505','1712.3272098689956','1712.327209868995624','test','test','0.0'),('2019-02-01 19:59:59','2019-02-01 23:59:59','DLTETH','4h','0.001092900000000','0.001085690000000','1.885118148616876','1.872681784950001','1724.8770689147002','1724.877068914700203','test','test','0.7'),('2019-02-02 07:59:59','2019-02-02 15:59:59','DLTETH','4h','0.001231970000000','0.001182691200000','1.882354512246460','1.807060331756602','1527.9223619458749','1527.922361945874854','test','test','4.0'),('2019-02-03 11:59:59','2019-02-03 19:59:59','DLTETH','4h','0.001164100000000','0.001117536000000','1.865622472137602','1.790997573252098','1602.630763798301','1602.630763798300904','test','test','4.0'),('2019-02-20 11:59:59','2019-02-20 15:59:59','DLTETH','4h','0.000822440000000','0.000789542400000','1.849039161274157','1.775077594823191','2248.2359336537097','2248.235933653709708','test','test','4.0'),('2019-03-02 19:59:59','2019-03-02 23:59:59','DLTETH','4h','0.000726550000000','0.000732570000000','1.832603257618387','1.847787720643455','2522.3360506756408','2522.336050675640763','test','test','0.0'),('2019-03-03 23:59:59','2019-03-04 07:59:59','DLTETH','4h','0.000726790000000','0.000738290000000','1.835977582735068','1.865028260649532','2526.1459056055637','2526.145905605563712','test','test','0.0'),('2019-03-04 19:59:59','2019-03-05 03:59:59','DLTETH','4h','0.000734000000000','0.000716640000000','1.842433288938283','1.798857482540506','2510.1270966461616','2510.127096646161590','test','test','2.4'),('2019-03-05 15:59:59','2019-03-05 19:59:59','DLTETH','4h','0.000737110000000','0.000707980000000','1.832749776405443','1.760320965255560','2486.3992842390458','2486.399284239045755','test','test','4.0'),('2019-03-06 15:59:59','2019-03-06 23:59:59','DLTETH','4h','0.000780780000000','0.000749548800000','1.816654485038802','1.743988305637250','2326.717494094114','2326.717494094114045','test','test','4.0'),('2019-03-07 15:59:59','2019-03-07 19:59:59','DLTETH','4h','0.000734160000000','0.000727170000000','1.800506445171790','1.783363669684497','2452.4714574095437','2452.471457409543746','test','test','1.0'),('2019-03-09 03:59:59','2019-03-09 07:59:59','DLTETH','4h','0.000726960000000','0.000734720000000','1.796696939507948','1.815875942823924','2471.521045873154','2471.521045873153980','test','test','0.0'),('2019-03-09 15:59:59','2019-03-10 15:59:59','DLTETH','4h','0.000729000000000','0.000728780000000','1.800958940244832','1.800415440976171','2470.4512211863257','2470.451221186325711','test','test','0.0'),('2019-03-10 19:59:59','2019-03-11 15:59:59','DLTETH','4h','0.000738650000000','0.000731230000000','1.800838162629574','1.782748107574120','2438.012810708148','2438.012810708148209','test','test','1.0'),('2019-03-12 11:59:59','2019-03-18 11:59:59','DLTETH','4h','0.000763090000000','0.000761580000000','1.796818150395028','1.793262612506841','2354.6608531038646','2354.660853103864611','test','test','0.3'),('2019-03-20 15:59:59','2019-03-21 03:59:59','DLTETH','4h','0.000782480000000','0.000768090000000','1.796028030864320','1.762998632842470','2295.30215579225','2295.302155792249778','test','test','1.8'),('2019-03-21 07:59:59','2019-03-21 11:59:59','DLTETH','4h','0.000778600000000','0.000783820000000','1.788688164637242','1.800680140259393','2297.31333757673','2297.313337576730191','test','test','0.0'),('2019-03-26 19:59:59','2019-04-02 07:59:59','DLTETH','4h','0.000830370000000','0.000861450000000','1.791353048108832','1.858401776669862','2157.2949987461393','2157.294998746139299','test','test','3.7'),('2019-04-02 15:59:59','2019-04-02 23:59:59','DLTETH','4h','0.000850820000000','0.000816787200000','1.806252765566838','1.734002654944165','2122.955226213345','2122.955226213345213','test','test','4.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:14:10
