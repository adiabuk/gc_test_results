-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-18 07:59:59','2018-03-18 15:59:59','IOTABTC','4h','0.000148070000000','0.000151180000000','0.033333333333333','0.034033452646271','225.1187501406992','225.118750140699206','test','test','0.0'),('2018-03-18 19:59:59','2018-03-19 03:59:59','IOTABTC','4h','0.000155520000000','0.000149299200000','0.033488915402875','0.032149358786760','215.33510418515374','215.335104185153739','test','test','4.0'),('2018-03-20 15:59:59','2018-03-21 07:59:59','IOTABTC','4h','0.000169160000000','0.000162393600000','0.033191236154850','0.031863586708656','196.2120841502102','196.212084150210188','test','test','4.0'),('2018-03-21 15:59:59','2018-03-22 11:59:59','IOTABTC','4h','0.000156670000000','0.000150403200000','0.032896202944584','0.031580354826801','209.97129600168648','209.971296001686483','test','test','4.0'),('2018-03-25 23:59:59','2018-03-26 11:59:59','IOTABTC','4h','0.000156180000000','0.000150820000000','0.032603792251744','0.031484850476425','208.75779390282722','208.757793902827217','test','test','3.4'),('2018-03-28 11:59:59','2018-03-28 15:59:59','IOTABTC','4h','0.000153230000000','0.000150850000000','0.032355138523895','0.031852591831427','211.1540724655413','211.154072465541304','test','test','1.6'),('2018-03-29 23:59:59','2018-03-31 19:59:59','IOTABTC','4h','0.000153490000000','0.000154090000000','0.032243461481124','0.032369502766476','210.06880891995718','210.068808919957178','test','test','0.0'),('2018-04-09 03:59:59','2018-04-09 11:59:59','IOTABTC','4h','0.000148010000000','0.000146590000000','0.032271470655647','0.031961859897381','218.03574525806965','218.035745258069653','test','test','1.0'),('2018-04-10 15:59:59','2018-04-10 23:59:59','IOTABTC','4h','0.000148000000000','0.000147490000000','0.032202668264921','0.032091699610765','217.5855963846021','217.585596384602098','test','test','0.3'),('2018-04-11 03:59:59','2018-04-25 03:59:59','IOTABTC','4h','0.000150850000000','0.000198590000000','0.032178008563998','0.042361489696549','213.31129309908889','213.311293099088886','test','test','0.7'),('2018-04-25 07:59:59','2018-04-25 11:59:59','IOTABTC','4h','0.000211880000000','0.000205360000000','0.034441004371231','0.033381181129300','162.54957698334488','162.549576983344878','test','test','3.1'),('2018-04-29 03:59:59','2018-04-29 11:59:59','IOTABTC','4h','0.000219530000000','0.000212100000000','0.034205488095246','0.033047802236604','155.81236320888465','155.812363208884648','test','test','3.4'),('2018-04-29 15:59:59','2018-04-30 03:59:59','IOTABTC','4h','0.000216630000000','0.000211990000000','0.033948224571104','0.033221087230893','156.71063366617636','156.710633666176363','test','test','2.1'),('2018-05-01 23:59:59','2018-05-07 03:59:59','IOTABTC','4h','0.000216090000000','0.000232870000000','0.033786638495501','0.036410266585438','156.3544749664553','156.354474966455314','test','test','0.0'),('2018-05-07 23:59:59','2018-05-10 23:59:59','IOTABTC','4h','0.000240660000000','0.000236200000000','0.034369666959932','0.033732715598504','142.81420659823726','142.814206598237263','test','test','1.9'),('2018-05-15 11:59:59','2018-05-15 15:59:59','IOTABTC','4h','0.000234900000000','0.000231260000000','0.034228122212948','0.033697724746557','145.7135896677215','145.713589667721493','test','test','1.5'),('2018-05-15 23:59:59','2018-05-16 03:59:59','IOTABTC','4h','0.000234560000000','0.000228130000000','0.034110256109305','0.033175190681343','145.42230605945312','145.422306059453120','test','test','2.7'),('2018-05-29 19:59:59','2018-05-30 15:59:59','IOTABTC','4h','0.000217120000000','0.000208435200000','0.033902463791980','0.032546365240301','156.1462039055842','156.146203905584201','test','test','4.0'),('2018-05-31 07:59:59','2018-06-04 07:59:59','IOTABTC','4h','0.000225250000000','0.000229150000000','0.033601108558274','0.034182881359061','149.1725130223041','149.172513022304088','test','test','0.0'),('2018-06-04 11:59:59','2018-06-05 03:59:59','IOTABTC','4h','0.000229650000000','0.000225610000000','0.033730391402893','0.033137006768590','146.87738472847087','146.877384728470872','test','test','1.8'),('2018-06-05 19:59:59','2018-06-05 23:59:59','IOTABTC','4h','0.000231490000000','0.000228690000000','0.033598528150826','0.033192135309570','145.14030044851182','145.140300448511823','test','test','1.2'),('2018-07-01 23:59:59','2018-07-02 07:59:59','IOTABTC','4h','0.000167900000000','0.000165910000000','0.033508218630547','0.033111069404372','199.57247546484155','199.572475464841546','test','test','1.2'),('2018-07-02 15:59:59','2018-07-05 19:59:59','IOTABTC','4h','0.000172630000000','0.000174070000000','0.033419963246952','0.033698737197457','193.59302118375973','193.593021183759731','test','test','0.0'),('2018-07-16 11:59:59','2018-07-17 07:59:59','IOTABTC','4h','0.000162310000000','0.000160530000000','0.033481913013731','0.033114727965586','206.28373491301417','206.283734913014172','test','test','1.1'),('2018-07-17 15:59:59','2018-07-17 19:59:59','IOTABTC','4h','0.000159990000000','0.000155250000000','0.033400316336366','0.032410770118263','208.76502491634338','208.765024916343378','test','test','3.0'),('2018-08-05 07:59:59','2018-08-06 19:59:59','IOTABTC','4h','0.000130990000000','0.000125750400000','0.033180417176787','0.031853200489716','253.3049635604805','253.304963560480502','test','test','4.0'),('2018-08-26 23:59:59','2018-09-03 11:59:59','IOTABTC','4h','0.000085530000000','0.000095620000000','0.032885480135216','0.036764990185074','384.4905896786625','384.490589678662502','test','test','0.0'),('2018-09-03 15:59:59','2018-09-03 19:59:59','IOTABTC','4h','0.000096610000000','0.000096200000000','0.033747593479629','0.033604373178142','349.31780850459467','349.317808504594666','test','test','0.4'),('2018-09-04 11:59:59','2018-09-04 23:59:59','IOTABTC','4h','0.000099100000000','0.000095660000000','0.033715766745965','0.032545411169718','340.21964425797296','340.219644257972959','test','test','3.5'),('2018-09-10 03:59:59','2018-09-10 07:59:59','IOTABTC','4h','0.000093110000000','0.000092130000000','0.033455687729021','0.033103560417514','359.3135831706727','359.313583170672700','test','test','1.1'),('2018-09-14 03:59:59','2018-09-14 11:59:59','IOTABTC','4h','0.000091590000000','0.000089040000000','0.033377437215353','0.032448160384922','364.42228644342305','364.422286443423047','test','test','2.8'),('2018-09-21 19:59:59','2018-09-22 11:59:59','IOTABTC','4h','0.000089740000000','0.000088000000000','0.033170931253035','0.032527768556575','369.63373359744946','369.633733597449464','test','test','1.9'),('2018-09-25 23:59:59','2018-09-26 03:59:59','IOTABTC','4h','0.000088490000000','0.000085300000000','0.033028006209377','0.031837370659508','373.23998428497384','373.239984284973843','test','test','3.6'),('2018-09-27 23:59:59','2018-09-28 03:59:59','IOTABTC','4h','0.000087550000000','0.000086480000000','0.032763420531629','0.032362999515423','374.2252487907329','374.225248790732905','test','test','1.2'),('2018-10-07 19:59:59','2018-10-10 07:59:59','IOTABTC','4h','0.000086130000000','0.000087690000000','0.032674438083583','0.033266242604776','379.36187255988494','379.361872559884944','test','test','0.0'),('2018-10-10 15:59:59','2018-10-11 03:59:59','IOTABTC','4h','0.000088070000000','0.000084547200000','0.032805950199404','0.031493712191428','372.49858293861195','372.498582938611946','test','test','4.0'),('2018-11-02 11:59:59','2018-11-03 07:59:59','IOTABTC','4h','0.000075350000000','0.000074500000000','0.032514341753187','0.032147557539647','431.51083945834995','431.510839458349949','test','test','1.1'),('2018-11-04 19:59:59','2018-11-08 07:59:59','IOTABTC','4h','0.000077410000000','0.000076000000000','0.032432834150178','0.031842079775398','418.97473388680754','418.974733886807542','test','test','1.8'),('2018-11-10 15:59:59','2018-11-10 19:59:59','IOTABTC','4h','0.000076490000000','0.000076390000000','0.032301555400227','0.032259325624570','422.2977565724496','422.297756572449600','test','test','0.1'),('2018-11-12 07:59:59','2018-11-14 11:59:59','IOTABTC','4h','0.000076300000000','0.000076150000000','0.032292171005636','0.032228687052152','423.2263565614183','423.226356561418299','test','test','0.2'),('2018-12-15 15:59:59','2019-01-06 07:59:59','IOTABTC','4h','0.000067190000000','0.000093400000000','0.032278063460418','0.044869342568880','480.39981337129865','480.399813371298649','test','test','0.0'),('2019-01-06 19:59:59','2019-01-06 23:59:59','IOTABTC','4h','0.000093610000000','0.000092840000000','0.035076125484520','0.034787602713202','374.7048978156203','374.704897815620313','test','test','0.8'),('2019-01-19 11:59:59','2019-01-19 19:59:59','IOTABTC','4h','0.000085130000000','0.000084920000000','0.035012009313116','0.034925641147302','411.27698006714695','411.276980067146951','test','test','0.2'),('2019-01-21 23:59:59','2019-01-22 03:59:59','IOTABTC','4h','0.000085160000000','0.000084530000000','0.034992816387380','0.034733945152950','410.9067213172824','410.906721317282404','test','test','0.7'),('2019-02-08 11:59:59','2019-02-09 19:59:59','IOTABTC','4h','0.000075090000000','0.000075110000000','0.034935289446395','0.034944594357687','465.2455646077418','465.245564607741812','test','test','0.1'),('2019-02-10 03:59:59','2019-02-10 15:59:59','IOTABTC','4h','0.000076270000000','0.000075220000000','0.034937357204460','0.034456378771725','458.07469784266704','458.074697842667035','test','test','1.4'),('2019-02-12 19:59:59','2019-02-12 23:59:59','IOTABTC','4h','0.000075220000000','0.000075310000000','0.034830473108297','0.034872147431346','463.04803387791657','463.048033877916566','test','test','0.0'),('2019-02-15 11:59:59','2019-02-16 03:59:59','IOTABTC','4h','0.000075640000000','0.000074650000000','0.034839734068974','0.034383740722487','460.59933988596566','460.599339885965662','test','test','1.3'),('2019-02-16 11:59:59','2019-02-16 15:59:59','IOTABTC','4h','0.000075710000000','0.000074990000000','0.034738402214200','0.034408040972697','458.8350576436343','458.835057643634286','test','test','1.0'),('2019-02-16 23:59:59','2019-02-18 03:59:59','IOTABTC','4h','0.000075730000000','0.000074720000000','0.034664988604977','0.034202666691719','457.74446857225234','457.744468572252345','test','test','1.3'),('2019-02-18 07:59:59','2019-02-21 19:59:59','IOTABTC','4h','0.000075440000000','0.000076050000000','0.034562250402030','0.034841717166946','458.14223756668144','458.142237566681445','test','test','0.0'),('2019-02-23 19:59:59','2019-02-24 07:59:59','IOTABTC','4h','0.000077130000000','0.000076770000000','0.034624354127567','0.034462746873763','448.9090383452267','448.909038345226691','test','test','0.5'),('2019-02-24 11:59:59','2019-02-24 15:59:59','IOTABTC','4h','0.000077510000000','0.000074730000000','0.034588441404500','0.033347880610996','446.2448897497068','446.244889749706772','test','test','3.6'),('2019-03-01 07:59:59','2019-03-02 07:59:59','IOTABTC','4h','0.000076390000000','0.000075390000000','0.034312761228166','0.033863582523778','449.17870438755796','449.178704387557957','test','test','1.3'),('2019-03-02 11:59:59','2019-03-02 15:59:59','IOTABTC','4h','0.000075720000000','0.000075360000000','0.034212943738302','0.034050283150006','451.8349674894552','451.834967489455209','test','test','0.5'),('2019-03-13 03:59:59','2019-03-13 11:59:59','IOTABTC','4h','0.000073980000000','0.000072570000000','0.034176796940902','0.033525414355248','461.9734650027364','461.973465002736418','test','test','1.9'),('2019-03-13 15:59:59','2019-03-17 11:59:59','IOTABTC','4h','0.000073190000000','0.000074870000000','0.034032045255202','0.034813215306148','464.98217318215','464.982173182150007','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:44:18
