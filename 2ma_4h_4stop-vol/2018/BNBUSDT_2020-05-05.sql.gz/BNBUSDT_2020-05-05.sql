-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-23 11:59:59','2018-04-25 15:59:59','BNBUSDT','4h','13.726500000000000','13.590000000000000','222.222222222222200','220.012384803118039','16.18928512164224','16.189285121642239','test','test','2.0'),('2018-04-26 07:59:59','2018-05-01 03:59:59','BNBUSDT','4h','14.260300000000001','13.802800000000000','221.731147240199078','214.617552164191466','15.54884169619146','15.548841696191460','test','test','3.2'),('2018-05-02 07:59:59','2018-05-02 15:59:59','BNBUSDT','4h','14.219900000000001','14.138999999999999','220.150348334419618','218.897866729045802','15.481849262963847','15.481849262963847','test','test','0.6'),('2018-05-02 23:59:59','2018-05-06 11:59:59','BNBUSDT','4h','14.439000000000000','14.150399999999999','219.872019088781002','215.477319683765245','15.227648666028188','15.227648666028188','test','test','2.0'),('2018-05-09 19:59:59','2018-05-10 19:59:59','BNBUSDT','4h','14.570800000000000','13.987968000000000','218.895419220999685','210.139602452159693','15.022882698341867','15.022882698341867','test','test','4.0'),('2018-05-18 11:59:59','2018-05-19 19:59:59','BNBUSDT','4h','14.879799999999999','14.284607999999999','216.949682161257471','208.271694874807167','14.580147727876549','14.580147727876549','test','test','4.0'),('2018-05-20 07:59:59','2018-05-22 23:59:59','BNBUSDT','4h','13.914700000000000','13.888000000000000','215.021240542046286','214.608650466624425','15.452811813553026','15.452811813553026','test','test','0.6'),('2018-05-31 07:59:59','2018-06-04 15:59:59','BNBUSDT','4h','13.856199999999999','13.891999999999999','214.929553858619215','215.484863252835424','15.511435592631402','15.511435592631402','test','test','0.5'),('2018-06-05 07:59:59','2018-06-10 07:59:59','BNBUSDT','4h','14.715600000000000','14.597200000000001','215.052955946222824','213.322664963589943','14.613944110075215','14.613944110075215','test','test','2.3'),('2018-06-11 23:59:59','2018-06-12 15:59:59','BNBUSDT','4h','15.470000000000001','15.770000000000000','214.668446838971050','218.831377288336995','13.876434831219848','13.876434831219848','test','test','0.0'),('2018-06-12 19:59:59','2018-06-12 23:59:59','BNBUSDT','4h','15.180000000000000','15.226300000000000','215.593542494385730','216.251117001466753','14.202473155097874','14.202473155097874','test','test','0.0'),('2018-06-13 03:59:59','2018-06-13 11:59:59','BNBUSDT','4h','15.630100000000001','15.153499999999999','215.739670162625970','209.161239647177723','13.802833645506169','13.802833645506169','test','test','3.0'),('2018-06-15 15:59:59','2018-06-15 23:59:59','BNBUSDT','4h','15.325400000000000','14.989500000000000','214.277796714748575','209.581285568776252','13.981873015696072','13.981873015696072','test','test','2.2'),('2018-06-16 11:59:59','2018-06-20 07:59:59','BNBUSDT','4h','15.670400000000001','15.991899999999999','213.234127571199195','217.608921578636142','13.607446368388757','13.607446368388757','test','test','1.5'),('2018-06-21 15:59:59','2018-06-22 11:59:59','BNBUSDT','4h','16.594999999999999','16.139199999999999','214.206304017296247','208.322891340521096','12.9078821342149','12.907882134214899','test','test','2.7'),('2018-06-22 15:59:59','2018-06-22 19:59:59','BNBUSDT','4h','16.020000000000000','16.024500000000000','212.898878978012903','212.958682033905603','13.289567976155611','13.289567976155611','test','test','0.0'),('2018-07-16 11:59:59','2018-07-17 07:59:59','BNBUSDT','4h','13.183100000000000','13.050000000000001','212.912168545989061','210.762552019263865','16.15038712791294','16.150387127912939','test','test','1.0'),('2018-07-17 15:59:59','2018-07-18 19:59:59','BNBUSDT','4h','13.183600000000000','13.170000000000000','212.434475984494583','212.215331830136961','16.113540761589746','16.113540761589746','test','test','0.1'),('2018-07-19 11:59:59','2018-07-19 15:59:59','BNBUSDT','4h','13.263400000000001','13.060400000000000','212.385777283526181','209.135154306871925','16.012921067262255','16.012921067262255','test','test','1.5'),('2018-07-25 07:59:59','2018-07-30 15:59:59','BNBUSDT','4h','13.042199999999999','13.390000000000001','211.663416622047492','217.307904231587941','16.229119061358322','16.229119061358322','test','test','0.8'),('2018-07-31 11:59:59','2018-08-01 07:59:59','BNBUSDT','4h','13.449999999999999','13.495799999999999','212.917747201945332','213.642775664536316','15.830315777096308','15.830315777096308','test','test','0.0'),('2018-08-02 11:59:59','2018-08-02 15:59:59','BNBUSDT','4h','13.612800000000000','13.516299999999999','213.078864638076681','211.568366398362997','15.65283149962364','15.652831499623639','test','test','0.7'),('2018-08-02 23:59:59','2018-08-04 19:59:59','BNBUSDT','4h','14.150000000000000','13.643200000000000','212.743198362584764','205.123533844552412','15.03485500795652','15.034855007956519','test','test','3.6'),('2018-08-06 15:59:59','2018-08-06 19:59:59','BNBUSDT','4h','13.679600000000001','13.612399999999999','211.049939580799787','210.013172720670099','15.42807827573904','15.428078275739040','test','test','0.5'),('2018-08-06 23:59:59','2018-08-07 03:59:59','BNBUSDT','4h','13.699800000000000','13.560300000000000','210.819546945215393','208.672849416867706','15.388512748012044','15.388512748012044','test','test','1.0'),('2018-08-26 23:59:59','2018-08-27 03:59:59','BNBUSDT','4h','10.215800000000000','10.313599999999999','210.342503050027034','212.356197209886517','20.589919834964178','20.589919834964178','test','test','0.0'),('2018-08-27 07:59:59','2018-08-30 11:59:59','BNBUSDT','4h','10.420000000000000','10.449999999999999','210.789990641106925','211.396871612242535','20.22936570452082','20.229365704520820','test','test','0.0'),('2018-08-30 23:59:59','2018-09-05 11:59:59','BNBUSDT','4h','10.789899999999999','10.534700000000001','210.924853079137051','205.936111523997937','19.54836032578032','19.548360325780319','test','test','2.4'),('2018-09-14 19:59:59','2018-09-14 23:59:59','BNBUSDT','4h','10.026000000000000','9.926800000000000','209.816243844661699','207.740264252661859','20.92721362903069','20.927213629030689','test','test','1.0'),('2018-09-15 03:59:59','2018-09-16 03:59:59','BNBUSDT','4h','10.140000000000001','9.897100000000000','209.354915046439487','204.339894448334945','20.646441326078843','20.646441326078843','test','test','2.4'),('2018-09-20 23:59:59','2018-09-24 11:59:59','BNBUSDT','4h','10.038800000000000','9.925599999999999','208.240466024638522','205.892294853384072','20.743561583519796','20.743561583519796','test','test','1.1'),('2018-09-27 19:59:59','2018-09-28 11:59:59','BNBUSDT','4h','10.039500000000000','9.949999999999999','207.718650208804178','205.866882770815408','20.69013897194125','20.690138971941249','test','test','0.9'),('2018-09-29 11:59:59','2018-09-29 15:59:59','BNBUSDT','4h','9.960900000000001','9.988099999999999','207.307146333695556','207.873235179108718','20.812089904897704','20.812089904897704','test','test','0.0'),('2018-09-29 19:59:59','2018-09-30 03:59:59','BNBUSDT','4h','10.000000000000000','9.895500000000000','207.432943854898468','205.265269591614782','20.743294385489847','20.743294385489847','test','test','1.0'),('2018-09-30 15:59:59','2018-09-30 19:59:59','BNBUSDT','4h','9.965999999999999','9.980800000000000','206.951238463057649','207.258571227381708','20.765727319191015','20.765727319191015','test','test','0.0'),('2018-09-30 23:59:59','2018-10-01 07:59:59','BNBUSDT','4h','10.017200000000001','9.955000000000000','207.019534632907465','205.734084102403244','20.66640724283307','20.666407242833071','test','test','0.6'),('2018-10-01 19:59:59','2018-10-01 23:59:59','BNBUSDT','4h','9.951900000000000','9.981100000000000','206.733878959462089','207.340459538609423','20.773307505045477','20.773307505045477','test','test','0.0'),('2018-10-02 07:59:59','2018-10-02 11:59:59','BNBUSDT','4h','9.964800000000000','9.937799999999999','206.868674643717014','206.308156197247371','20.75994246183737','20.759942461837369','test','test','0.3'),('2018-10-02 19:59:59','2018-10-09 15:59:59','BNBUSDT','4h','10.024100000000001','10.345700000000001','206.744114988945995','213.377020424889906','20.624705957536936','20.624705957536936','test','test','0.0'),('2018-10-10 15:59:59','2018-10-11 03:59:59','BNBUSDT','4h','10.340199999999999','9.926591999999999','208.218093974711337','199.889370215722863','20.136756926820695','20.136756926820695','test','test','4.0'),('2018-10-15 07:59:59','2018-10-18 15:59:59','BNBUSDT','4h','10.355100000000000','10.132400000000001','206.367266472713908','201.929067880380330','19.92904621613639','19.929046216136388','test','test','2.2'),('2018-11-04 15:59:59','2018-11-04 19:59:59','BNBUSDT','4h','9.700900000000001','9.826499999999999','205.381000118861976','208.040119748476656','21.171334630690136','21.171334630690136','test','test','0.0'),('2018-11-04 23:59:59','2018-11-05 11:59:59','BNBUSDT','4h','9.819000000000001','9.695000000000000','205.971915592109667','203.370783345096555','20.976872959783037','20.976872959783037','test','test','1.3'),('2018-11-05 15:59:59','2018-11-05 19:59:59','BNBUSDT','4h','9.726699999999999','9.729699999999999','205.393886203884563','205.457235711796983','21.11650263747053','21.116502637470528','test','test','0.0'),('2018-11-05 23:59:59','2018-11-06 03:59:59','BNBUSDT','4h','9.733300000000000','9.694200000000000','205.407963872309551','204.582811931302160','21.10363020479278','21.103630204792779','test','test','0.4'),('2018-11-06 07:59:59','2018-11-08 19:59:59','BNBUSDT','4h','9.742000000000001','9.742500000000000','205.224596774307884','205.235129755049684','21.065961483710517','21.065961483710517','test','test','0.1'),('2018-12-04 15:59:59','2018-12-06 07:59:59','BNBUSDT','4h','5.756200000000000','5.894800000000000','205.226937436694953','210.168470658043390','35.65319784522688','35.653197845226877','test','test','0.0'),('2018-12-17 19:59:59','2018-12-25 03:59:59','BNBUSDT','4h','5.061900000000000','5.365500000000000','206.325055930327949','218.699912600836569','40.760397465443404','40.760397465443404','test','test','1.6'),('2018-12-26 23:59:59','2018-12-27 03:59:59','BNBUSDT','4h','5.602900000000000','5.452200000000000','209.075024079329864','203.451577983780254','37.31550162939368','37.315501629393680','test','test','2.7'),('2018-12-28 15:59:59','2019-01-04 03:59:59','BNBUSDT','4h','5.637000000000000','5.893500000000000','207.825369391429945','217.282032022067142','36.868080431334036','36.868080431334036','test','test','0.0'),('2019-01-04 07:59:59','2019-01-10 07:59:59','BNBUSDT','4h','5.865900000000000','6.059900000000000','209.926849976016001','216.869656518123264','35.78766258818187','35.787662588181867','test','test','0.0'),('2019-01-14 23:59:59','2019-01-15 03:59:59','BNBUSDT','4h','6.058300000000000','5.892900000000000','211.469695874262044','205.696279619272531','34.90578146910223','34.905781469102230','test','test','2.7'),('2019-01-16 23:59:59','2019-01-28 07:59:59','BNBUSDT','4h','6.091100000000000','6.739800000000000','210.186714484264371','232.571525386390789','34.50718498863331','34.507184988633313','test','test','1.6'),('2019-02-01 11:59:59','2019-02-24 15:59:59','BNBUSDT','4h','6.574400000000000','9.786300000000001','215.161116906959137','320.277323921053551','32.72711074880736','32.727110748807362','test','test','0.8'),('2019-02-24 19:59:59','2019-02-24 23:59:59','BNBUSDT','4h','9.932499999999999','9.947600000000000','238.520274021202368','238.882887274433699','24.01412273055146','24.014122730551460','test','test','0.0'),('2019-02-28 11:59:59','2019-03-21 15:59:59','BNBUSDT','4h','10.347600000000000','14.458200000000000','238.600854744142651','333.385410922509891','23.058569595282254','23.058569595282254','test','test','1.3'),('2019-03-22 23:59:59','2019-03-24 03:59:59','BNBUSDT','4h','15.150200000000000','14.700400000000000','259.664089450446511','251.954824395542232','17.139317596496845','17.139317596496845','test','test','3.0'),('2019-03-24 11:59:59','2019-03-26 07:59:59','BNBUSDT','4h','17.040199999999999','16.358591999999998','257.950919438245535','247.632882660715694','15.13778708220828','15.137787082208281','test','test','4.0'),('2019-03-26 15:59:59','2019-03-30 07:59:59','BNBUSDT','4h','15.904299999999999','16.367000000000001','255.658022376572234','263.095820139041564','16.074773638360206','16.074773638360206','test','test','0.0'),('2019-03-30 15:59:59','2019-04-08 11:59:59','BNBUSDT','4h','16.510999999999999','17.836900000000000','257.310866323787593','277.973968356293767','15.584208486692969','15.584208486692969','test','test','0.0'),('2019-04-09 23:59:59','2019-04-10 03:59:59','BNBUSDT','4h','18.298400000000001','18.105000000000000','261.902666775455657','259.134557227387347','14.312872533962294','14.312872533962294','test','test','1.1'),('2019-04-10 07:59:59','2019-04-10 23:59:59','BNBUSDT','4h','18.302099999999999','18.239999999999998','261.287531320329379','260.400968811382711','14.276368904132825','14.276368904132825','test','test','0.3'),('2019-04-12 19:59:59','2019-04-12 23:59:59','BNBUSDT','4h','18.270399999999999','18.333300000000001','261.090517429452291','261.989380812099284','14.290355844943313','14.290355844943313','test','test','0.0'),('2019-04-13 03:59:59','2019-04-13 11:59:59','BNBUSDT','4h','18.185700000000001','18.054700000000000','261.290264847818321','259.408070338117625','14.367897020616105','14.367897020616105','test','test','0.7'),('2019-04-13 19:59:59','2019-04-23 11:59:59','BNBUSDT','4h','18.371700000000001','23.763100000000001','260.871999401218204','337.428077367423157','14.199665757726187','14.199665757726187','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:33:32
