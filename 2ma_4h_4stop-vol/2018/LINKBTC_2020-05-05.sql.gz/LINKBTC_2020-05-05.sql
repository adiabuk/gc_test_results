-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-21 23:59:59','2018-03-22 03:59:59','LINKBTC','4h','0.000049890000000','0.000048990000000','0.033333333333333','0.032732010422930','668.1365671143182','668.136567114318154','test','test','1.8'),('2018-03-26 07:59:59','2018-03-26 11:59:59','LINKBTC','4h','0.000048650000000','0.000046704000000','0.033199706019910','0.031871717779114','682.4194454246751','682.419445424675132','test','test','4.0'),('2018-04-06 03:59:59','2018-04-06 07:59:59','LINKBTC','4h','0.000042610000000','0.000041630000000','0.032904597521956','0.032147814945765','772.2271185626796','772.227118562679607','test','test','2.3'),('2018-04-07 07:59:59','2018-04-07 11:59:59','LINKBTC','4h','0.000042230000000','0.000042610000000','0.032736423616136','0.033030997165133','775.19354999137','775.193549991369991','test','test','0.0'),('2018-04-08 15:59:59','2018-04-21 11:59:59','LINKBTC','4h','0.000044970000000','0.000051280000000','0.032801884404802','0.037404505943479','729.417042579532','729.417042579531994','test','test','0.0'),('2018-04-21 19:59:59','2018-04-25 03:59:59','LINKBTC','4h','0.000055220000000','0.000053011200000','0.033824689191174','0.032471701623527','612.5441722414745','612.544172241474485','test','test','4.0'),('2018-04-29 03:59:59','2018-05-04 11:59:59','LINKBTC','4h','0.000053030000000','0.000056750000000','0.033524025287253','0.035875701207837','632.1709463936011','632.170946393601071','test','test','0.0'),('2018-05-04 19:59:59','2018-05-05 19:59:59','LINKBTC','4h','0.000060920000000','0.000058483200000','0.034046619936271','0.032684755138820','558.8742602802254','558.874260280225371','test','test','4.0'),('2018-05-07 03:59:59','2018-05-07 07:59:59','LINKBTC','4h','0.000058030000000','0.000058530000000','0.033743983314616','0.034034729336627','581.4920440223256','581.492044022325558','test','test','0.0'),('2018-05-07 11:59:59','2018-05-07 15:59:59','LINKBTC','4h','0.000057640000000','0.000056670000000','0.033808593541729','0.033239642540073','586.5474243880832','586.547424388083186','test','test','1.7'),('2018-05-07 23:59:59','2018-05-09 03:59:59','LINKBTC','4h','0.000061310000000','0.000058857600000','0.033682159985806','0.032334873586374','549.3746531692311','549.374653169231124','test','test','4.0'),('2018-05-09 07:59:59','2018-05-09 23:59:59','LINKBTC','4h','0.000058550000000','0.000057970000000','0.033382763008154','0.033052071248210','570.1582068002391','570.158206800239100','test','test','1.0'),('2018-05-10 11:59:59','2018-05-10 23:59:59','LINKBTC','4h','0.000060820000000','0.000058700000000','0.033309275950389','0.032148216019201','547.66977886203','547.669778862029943','test','test','3.5'),('2018-05-13 19:59:59','2018-05-13 23:59:59','LINKBTC','4h','0.000058130000000','0.000057860000000','0.033051262632347','0.032897747392183','568.574963570392','568.574963570392015','test','test','0.5'),('2018-05-14 23:59:59','2018-05-16 15:59:59','LINKBTC','4h','0.000059590000000','0.000058540000000','0.033017148134533','0.032435372575861','554.0719606399173','554.071960639917279','test','test','1.8'),('2018-06-02 15:59:59','2018-06-02 23:59:59','LINKBTC','4h','0.000048210000000','0.000048110000000','0.032887864677050','0.032819646745756','682.1793129444097','682.179312944409730','test','test','0.2'),('2018-06-30 03:59:59','2018-07-05 15:59:59','LINKBTC','4h','0.000032010000000','0.000034750000000','0.032872705136762','0.035686551187206','1026.9511133009198','1026.951113300919815','test','test','0.5'),('2018-07-06 19:59:59','2018-07-09 23:59:59','LINKBTC','4h','0.000034850000000','0.000035090000000','0.033498004259083','0.033728693528012','961.2052872046867','961.205287204686670','test','test','0.0'),('2018-07-16 19:59:59','2018-07-16 23:59:59','LINKBTC','4h','0.000033330000000','0.000032930000000','0.033549268541068','0.033146637055427','1006.5787141034368','1006.578714103436823','test','test','1.2'),('2018-07-17 19:59:59','2018-07-18 15:59:59','LINKBTC','4h','0.000034020000000','0.000032820000000','0.033459794877592','0.032279555199370','983.5330651849434','983.533065184943439','test','test','3.5'),('2018-07-25 19:59:59','2018-07-25 23:59:59','LINKBTC','4h','0.000030390000000','0.000030030000000','0.033197519393542','0.032804261513263','1092.3830007746774','1092.383000774677384','test','test','1.2'),('2018-07-26 03:59:59','2018-08-04 15:59:59','LINKBTC','4h','0.000030960000000','0.000036110000000','0.033110128753480','0.038617789059695','1069.448603148593','1069.448603148593065','test','test','0.0'),('2018-08-08 15:59:59','2018-08-08 19:59:59','LINKBTC','4h','0.000035950000000','0.000035650000000','0.034334053265973','0.034047538217856','955.0501603886694','955.050160388669383','test','test','0.8'),('2018-08-09 03:59:59','2018-08-11 15:59:59','LINKBTC','4h','0.000038880000000','0.000042130000000','0.034270383255280','0.037135062925539','881.4398985411523','881.439898541152274','test','test','0.0'),('2018-08-13 19:59:59','2018-08-14 03:59:59','LINKBTC','4h','0.000042380000000','0.000040684800000','0.034906978737560','0.033510699588058','823.6663222642703','823.666322264270320','test','test','4.0'),('2018-08-14 07:59:59','2018-08-14 11:59:59','LINKBTC','4h','0.000040900000000','0.000040190000000','0.034596694482115','0.033996116167144','845.8849506629557','845.884950662955703','test','test','1.7'),('2018-08-14 15:59:59','2018-08-14 19:59:59','LINKBTC','4h','0.000041160000000','0.000041850000000','0.034463232634344','0.035040969041480','837.2991407760825','837.299140776082481','test','test','0.0'),('2018-08-15 11:59:59','2018-08-15 15:59:59','LINKBTC','4h','0.000042370000000','0.000040675200000','0.034591618502596','0.033207953762492','816.4177130657539','816.417713065753901','test','test','4.0'),('2018-08-16 19:59:59','2018-08-18 19:59:59','LINKBTC','4h','0.000042830000000','0.000041450000000','0.034284137449240','0.033179488612444','800.4701715909307','800.470171590930704','test','test','3.2'),('2018-08-19 15:59:59','2018-08-25 23:59:59','LINKBTC','4h','0.000045760000000','0.000047000000000','0.034038659929952','0.034961036204278','743.8518341335566','743.851834133556622','test','test','0.2'),('2018-08-28 07:59:59','2018-08-28 15:59:59','LINKBTC','4h','0.000047250000000','0.000047040000000','0.034243632435357','0.034091438513422','724.732961594864','724.732961594864037','test','test','0.4'),('2018-08-28 23:59:59','2018-08-29 07:59:59','LINKBTC','4h','0.000047340000000','0.000046860000000','0.034209811563816','0.033862944019443','722.6407174443646','722.640717444364554','test','test','1.0'),('2018-09-02 03:59:59','2018-09-02 07:59:59','LINKBTC','4h','0.000046500000000','0.000045650000000','0.034132729887289','0.033508798265693','734.0372018771805','734.037201877180451','test','test','1.8'),('2018-09-12 03:59:59','2018-09-12 07:59:59','LINKBTC','4h','0.000041910000000','0.000040233600000','0.033994078415823','0.032634315279190','811.1209357151782','811.120935715178234','test','test','4.0'),('2018-09-13 15:59:59','2018-09-13 19:59:59','LINKBTC','4h','0.000041580000000','0.000041240000000','0.033691908829905','0.033416409815904','810.2912176504251','810.291217650425097','test','test','0.8'),('2018-09-15 03:59:59','2018-09-15 07:59:59','LINKBTC','4h','0.000041690000000','0.000041360000000','0.033630686826793','0.033364480862465','806.6847403884225','806.684740388422483','test','test','0.8'),('2018-09-16 11:59:59','2018-09-28 19:59:59','LINKBTC','4h','0.000042300000000','0.000050370000000','0.033571529945832','0.039976311190817','793.6531902087838','793.653190208783826','test','test','0.1'),('2018-09-30 11:59:59','2018-09-30 15:59:59','LINKBTC','4h','0.000050000000000','0.000048860000000','0.034994814666939','0.034196932892533','699.8962933387867','699.896293338786677','test','test','2.3'),('2018-10-05 15:59:59','2018-10-09 07:59:59','LINKBTC','4h','0.000052120000000','0.000050320000000','0.034817507605960','0.033615061065463','668.0258558319305','668.025855831930471','test','test','3.5'),('2018-10-09 15:59:59','2018-10-11 03:59:59','LINKBTC','4h','0.000051030000000','0.000051180000000','0.034550297263628','0.034651856044532','677.0585393617','677.058539361700014','test','test','0.0'),('2018-10-14 15:59:59','2018-10-15 07:59:59','LINKBTC','4h','0.000051920000000','0.000049990000000','0.034572865881606','0.033287703494250','665.8872473344804','665.887247334480435','test','test','3.7'),('2018-10-15 15:59:59','2018-10-15 19:59:59','LINKBTC','4h','0.000051370000000','0.000050740000000','0.034287274239972','0.033866776230021','667.4571586523566','667.457158652356611','test','test','1.2'),('2018-10-16 11:59:59','2018-10-29 15:59:59','LINKBTC','4h','0.000053810000000','0.000064690000000','0.034193830237760','0.041107579968049','635.4549384456461','635.454938445646121','test','test','0.0'),('2018-10-29 19:59:59','2018-11-06 03:59:59','LINKBTC','4h','0.000065990000000','0.000074100000000','0.035730219066713','0.040121370402234','541.4489932825176','541.448993282517563','test','test','0.0'),('2018-11-08 07:59:59','2018-11-09 03:59:59','LINKBTC','4h','0.000079020000000','0.000075859200000','0.036706030474607','0.035237789255623','464.51569823597686','464.515698235976856','test','test','4.0'),('2018-11-10 03:59:59','2018-11-17 07:59:59','LINKBTC','4h','0.000079760000000','0.000087820000000','0.036379754648166','0.040056043796413','456.1152789388916','456.115278938891606','test','test','0.7'),('2018-11-18 19:59:59','2018-11-19 07:59:59','LINKBTC','4h','0.000092780000000','0.000089068800000','0.037196707792221','0.035708839480532','400.9129962515724','400.912996251572395','test','test','4.0'),('2018-11-27 11:59:59','2018-11-27 15:59:59','LINKBTC','4h','0.000080690000000','0.000077810000000','0.036866070389623','0.035550240885073','456.885244635312','456.885244635312006','test','test','3.6'),('2018-11-28 07:59:59','2018-11-28 11:59:59','LINKBTC','4h','0.000078660000000','0.000080750000000','0.036573663833057','0.037545427847945','464.9588587980761','464.958858798076108','test','test','0.0'),('2018-11-29 15:59:59','2018-11-29 23:59:59','LINKBTC','4h','0.000086030000000','0.000082588800000','0.036789611391921','0.035318026936244','427.6370032770041','427.637003277004112','test','test','4.0'),('2018-11-30 03:59:59','2018-11-30 11:59:59','LINKBTC','4h','0.000087630000000','0.000084124800000','0.036462592623992','0.035004088919032','416.09714280488924','416.097142804889245','test','test','4.0'),('2018-12-01 15:59:59','2018-12-01 19:59:59','LINKBTC','4h','0.000081080000000','0.000079250000000','0.036138480689557','0.035322824304975','445.713871356153','445.713871356152993','test','test','2.3'),('2018-12-18 03:59:59','2018-12-18 11:59:59','LINKBTC','4h','0.000066590000000','0.000068670000000','0.035957223715205','0.037080380725681','539.9793319598338','539.979331959833758','test','test','0.6'),('2018-12-18 15:59:59','2018-12-24 23:59:59','LINKBTC','4h','0.000069490000000','0.000075670000000','0.036206814161978','0.039426818644940','521.0363241038679','521.036324103867855','test','test','0.0'),('2018-12-25 03:59:59','2018-12-27 19:59:59','LINKBTC','4h','0.000076070000000','0.000075780000000','0.036922370713747','0.036781612366081','485.3736126429224','485.373612642922410','test','test','0.4'),('2018-12-29 15:59:59','2018-12-31 19:59:59','LINKBTC','4h','0.000078610000000','0.000076850000000','0.036891091080932','0.036065136109523','469.2925973913298','469.292597391329821','test','test','2.2'),('2019-01-01 23:59:59','2019-01-08 07:59:59','LINKBTC','4h','0.000077840000000','0.000092190000000','0.036707545531730','0.043474673979576','471.57689532027797','471.576895320277970','test','test','0.0'),('2019-01-08 15:59:59','2019-01-10 11:59:59','LINKBTC','4h','0.000095890000000','0.000093490000000','0.038211351853474','0.037254972205457','398.49152000702884','398.491520007028839','test','test','2.5'),('2019-01-10 19:59:59','2019-01-25 15:59:59','LINKBTC','4h','0.000099400000000','0.000137160000000','0.037998823042804','0.052433788416006','382.28192195979426','382.281921959794261','test','test','2.7'),('2019-01-29 19:59:59','2019-01-29 23:59:59','LINKBTC','4h','0.000132130000000','0.000132130000000','0.041206593125737','0.041206593125737','311.8640212346729','311.864021234672919','test','test','0.0'),('2019-02-05 23:59:59','2019-02-06 03:59:59','LINKBTC','4h','0.000121660000000','0.000120220000000','0.041206593125737','0.040718860969720','338.7028861231081','338.702886123108101','test','test','1.2'),('2019-02-08 03:59:59','2019-02-08 19:59:59','LINKBTC','4h','0.000121800000000','0.000121000000000','0.041098208202178','0.040828269232049','337.42371266155993','337.423712661559932','test','test','0.7'),('2019-02-09 15:59:59','2019-02-09 19:59:59','LINKBTC','4h','0.000131900000000','0.000126624000000','0.041038221764372','0.039396692893797','311.13132497628163','311.131324976281633','test','test','4.0'),('2019-02-09 23:59:59','2019-02-10 23:59:59','LINKBTC','4h','0.000126320000000','0.000122400000000','0.040673437570910','0.039411247297969','321.98731452589016','321.987314525890156','test','test','3.1'),('2019-02-13 23:59:59','2019-02-14 03:59:59','LINKBTC','4h','0.000122500000000','0.000119920000000','0.040392950843590','0.039542225838068','329.73837423338955','329.738374233389550','test','test','2.1'),('2019-02-14 11:59:59','2019-02-14 15:59:59','LINKBTC','4h','0.000121410000000','0.000120100000000','0.040203900842363','0.039770105355142','331.1415932984359','331.141593298435907','test','test','1.1'),('2019-02-15 23:59:59','2019-02-16 07:59:59','LINKBTC','4h','0.000120720000000','0.000120500000000','0.040107501845203','0.040034409976366','332.235767438725','332.235767438725020','test','test','0.4'),('2019-02-17 11:59:59','2019-02-18 23:59:59','LINKBTC','4h','0.000123660000000','0.000121060000000','0.040091259207684','0.039248324758873','324.2055572350279','324.205557235027925','test','test','2.1'),('2019-02-19 03:59:59','2019-02-19 07:59:59','LINKBTC','4h','0.000121830000000','0.000120250000000','0.039903940441281','0.039386430584126','327.5378842754749','327.537884275474880','test','test','1.3'),('2019-02-25 15:59:59','2019-02-25 19:59:59','LINKBTC','4h','0.000120100000000','0.000116640000000','0.039788938250802','0.038642645774967','331.2984034205014','331.298403420501415','test','test','2.9'),('2019-02-25 23:59:59','2019-02-26 03:59:59','LINKBTC','4h','0.000123280000000','0.000118348800000','0.039534206589506','0.037952838325926','320.6862961510833','320.686296151083297','test','test','4.0'),('2019-03-07 15:59:59','2019-03-07 19:59:59','LINKBTC','4h','0.000112460000000','0.000120200000000','0.039182791419821','0.041879526308576','348.41536030429575','348.415360304295746','test','test','0.0'),('2019-03-07 23:59:59','2019-03-15 19:59:59','LINKBTC','4h','0.000116660000000','0.000124770000000','0.039782065839544','0.042547645763757','341.0086219744938','341.008621974493792','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:46:26
