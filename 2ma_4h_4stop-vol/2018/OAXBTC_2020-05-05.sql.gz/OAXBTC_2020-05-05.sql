-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-10 07:59:59','2018-04-12 11:59:59','OAXBTC','4h','0.000071170000000','0.000070990000000','0.033333333333333','0.033249028148564','468.36213760479603','468.362137604796033','test','test','0.3'),('2018-04-12 15:59:59','2018-04-14 15:59:59','OAXBTC','4h','0.000072730000000','0.000072540000000','0.033314598847829','0.033227567722006','458.0585569617641','458.058556961764111','test','test','1.6'),('2018-04-15 15:59:59','2018-04-16 03:59:59','OAXBTC','4h','0.000077400000000','0.000074304000000','0.033295258597646','0.031963448253740','430.1712997111916','430.171299711191580','test','test','4.0'),('2018-04-17 07:59:59','2018-04-21 11:59:59','OAXBTC','4h','0.000075770000000','0.000074090000000','0.032999300743445','0.032267628244448','435.51934464095143','435.519344640951431','test','test','2.2'),('2018-04-21 23:59:59','2018-04-22 03:59:59','OAXBTC','4h','0.000085560000000','0.000082137600000','0.032836706854779','0.031523238580588','383.7857276154615','383.785727615461496','test','test','4.0'),('2018-04-22 19:59:59','2018-04-25 03:59:59','OAXBTC','4h','0.000080040000000','0.000077590000000','0.032544825016070','0.031548637843539','406.6070091962741','406.607009196274078','test','test','3.1'),('2018-04-26 15:59:59','2018-05-03 19:59:59','OAXBTC','4h','0.000082050000000','0.000094540000000','0.032323450088841','0.037243863149287','393.94820339842374','393.948203398423743','test','test','0.3'),('2018-05-04 15:59:59','2018-05-04 19:59:59','OAXBTC','4h','0.000092090000000','0.000091840000000','0.033416875213384','0.033326157233111','362.8719210922383','362.871921092238324','test','test','0.3'),('2018-05-06 19:59:59','2018-05-06 23:59:59','OAXBTC','4h','0.000093470000000','0.000090910000000','0.033396715662212','0.032482030821137','357.29876604485344','357.298766044853437','test','test','2.7'),('2018-05-13 19:59:59','2018-05-13 23:59:59','OAXBTC','4h','0.000086900000000','0.000083424000000','0.033193452364196','0.031865714269628','381.9729846282598','381.972984628259780','test','test','4.0'),('2018-05-15 11:59:59','2018-05-15 23:59:59','OAXBTC','4h','0.000086960000000','0.000083481600000','0.032898399454292','0.031582463476120','378.3164610659128','378.316461065912790','test','test','4.0'),('2018-05-17 15:59:59','2018-05-17 19:59:59','OAXBTC','4h','0.000082440000000','0.000079142400000','0.032605969236920','0.031301730467443','395.51151427608227','395.511514276082266','test','test','4.0'),('2018-05-21 03:59:59','2018-05-21 15:59:59','OAXBTC','4h','0.000080890000000','0.000081130000000','0.032316138399259','0.032412020130200','399.5072122544031','399.507212254403100','test','test','0.3'),('2018-05-30 11:59:59','2018-05-30 15:59:59','OAXBTC','4h','0.000074200000000','0.000071560000000','0.032337445450579','0.031186894830774','435.81462871400123','435.814628714001230','test','test','3.6'),('2018-05-31 07:59:59','2018-06-04 11:59:59','OAXBTC','4h','0.000074400000000','0.000074100000000','0.032081767535067','0.031952405569200','431.2065528906809','431.206552890680882','test','test','0.4'),('2018-06-07 03:59:59','2018-06-07 07:59:59','OAXBTC','4h','0.000075010000000','0.000074110000000','0.032053020431541','0.031668435464358','427.3166302031818','427.316630203181774','test','test','1.2'),('2018-06-07 11:59:59','2018-06-07 15:59:59','OAXBTC','4h','0.000076450000000','0.000075040000000','0.031967557105500','0.031377965797210','418.1498640353172','418.149864035317194','test','test','1.8'),('2018-06-07 19:59:59','2018-06-07 23:59:59','OAXBTC','4h','0.000074890000000','0.000074000000000','0.031836536814769','0.031458188333461','425.11065315487906','425.110653154879060','test','test','1.2'),('2018-07-01 23:59:59','2018-07-02 07:59:59','OAXBTC','4h','0.000053950000000','0.000051940000000','0.031752459374478','0.030569466912148','588.5534638457502','588.553463845750230','test','test','3.7'),('2018-07-02 11:59:59','2018-07-03 23:59:59','OAXBTC','4h','0.000052150000000','0.000053470000000','0.031489572160627','0.032286623651558','603.8268870685927','603.826887068592669','test','test','0.0'),('2018-07-04 15:59:59','2018-07-06 07:59:59','OAXBTC','4h','0.000056930000000','0.000054652800000','0.031666694714167','0.030400026925600','556.2391483254407','556.239148325440738','test','test','4.0'),('2018-07-06 15:59:59','2018-07-07 07:59:59','OAXBTC','4h','0.000058370000000','0.000056035200000','0.031385212983375','0.030129804464040','537.6942433334705','537.694243333470467','test','test','4.0'),('2018-07-08 15:59:59','2018-07-09 11:59:59','OAXBTC','4h','0.000055740000000','0.000055430000000','0.031106233312411','0.030933234885306','558.0594422750509','558.059442275050856','test','test','1.0'),('2018-07-09 15:59:59','2018-07-09 19:59:59','OAXBTC','4h','0.000057790000000','0.000055478400000','0.031067789217499','0.029825077648799','537.59801379995','537.598013799949968','test','test','4.0'),('2018-07-16 11:59:59','2018-07-16 15:59:59','OAXBTC','4h','0.000052110000000','0.000053930000000','0.030791631091121','0.031867063226716','590.8967777992964','590.896777799296387','test','test','0.0'),('2018-07-16 19:59:59','2018-07-17 19:59:59','OAXBTC','4h','0.000053730000000','0.000051950000000','0.031030616010142','0.030002614958624','577.5286806280002','577.528680628000188','test','test','3.3'),('2018-07-18 11:59:59','2018-07-18 15:59:59','OAXBTC','4h','0.000052550000000','0.000052670000000','0.030802171332027','0.030872509306524','586.1497874791121','586.149787479112092','test','test','0.0'),('2018-08-24 07:59:59','2018-08-24 11:59:59','OAXBTC','4h','0.000025720000000','0.000025210000000','0.030817801993027','0.030206718049930','1198.2038099932608','1198.203809993260847','test','test','2.0'),('2018-08-24 15:59:59','2018-08-24 19:59:59','OAXBTC','4h','0.000026400000000','0.000025344000000','0.030682005561227','0.029454725338778','1162.1971803495203','1162.197180349520295','test','test','4.0'),('2018-08-25 19:59:59','2018-08-26 03:59:59','OAXBTC','4h','0.000025400000000','0.000025320000000','0.030409276622905','0.030313499373699','1197.2156150750131','1197.215615075013147','test','test','0.4'),('2018-08-28 03:59:59','2018-08-28 23:59:59','OAXBTC','4h','0.000026200000000','0.000025580000000','0.030387992789748','0.029668887616861','1159.8470530438337','1159.847053043833739','test','test','2.4'),('2018-08-31 23:59:59','2018-09-01 11:59:59','OAXBTC','4h','0.000025450000000','0.000025520000000','0.030228191640218','0.030311334014081','1187.7481980439295','1187.748198043929506','test','test','0.0'),('2018-09-01 15:59:59','2018-09-02 11:59:59','OAXBTC','4h','0.000025540000000','0.000025000000000','0.030246667723299','0.029607153213879','1184.2861285551553','1184.286128555155301','test','test','2.1'),('2018-09-03 15:59:59','2018-09-05 11:59:59','OAXBTC','4h','0.000026500000000','0.000025440000000','0.030104553387872','0.028900371252357','1136.0208825612076','1136.020882561207600','test','test','4.0'),('2018-09-15 15:59:59','2018-09-15 23:59:59','OAXBTC','4h','0.000023710000000','0.000022761600000','0.029836957357758','0.028643479063448','1258.4123727438869','1258.412372743886863','test','test','4.0'),('2018-09-16 19:59:59','2018-09-18 03:59:59','OAXBTC','4h','0.000022750000000','0.000022860000000','0.029571739959022','0.029714724196186','1299.8567014954724','1299.856701495472407','test','test','0.0'),('2018-09-19 11:59:59','2018-09-20 07:59:59','OAXBTC','4h','0.000030320000000','0.000029107200000','0.029603514233947','0.028419373664589','976.3692029666007','976.369202966600710','test','test','4.0'),('2018-09-20 15:59:59','2018-09-21 15:59:59','OAXBTC','4h','0.000028010000000','0.000026889600000','0.029340371885201','0.028166757009793','1047.4963186433813','1047.496318643381301','test','test','4.0'),('2018-09-24 19:59:59','2018-09-24 23:59:59','OAXBTC','4h','0.000025950000000','0.000025240000000','0.029079568579555','0.028283942618419','1120.599945262231','1120.599945262230904','test','test','2.7'),('2018-09-25 15:59:59','2018-09-25 19:59:59','OAXBTC','4h','0.000026960000000','0.000025881600000','0.028902762810414','0.027746652297997','1072.0609351043604','1072.060935104360397','test','test','4.0'),('2018-09-25 23:59:59','2018-09-29 07:59:59','OAXBTC','4h','0.000026450000000','0.000028000000000','0.028645849363210','0.030324528626460','1083.018879516438','1083.018879516437892','test','test','0.0'),('2018-10-01 03:59:59','2018-10-02 15:59:59','OAXBTC','4h','0.000029060000000','0.000028380000000','0.029018889199488','0.028339851186561','998.5853131275827','998.585313127582708','test','test','2.7'),('2018-10-04 03:59:59','2018-10-04 07:59:59','OAXBTC','4h','0.000028720000000','0.000028490000000','0.028867991863282','0.028636806691675','1005.1529200306949','1005.152920030694872','test','test','0.8'),('2018-10-04 15:59:59','2018-10-04 23:59:59','OAXBTC','4h','0.000029310000000','0.000029470000000','0.028816617380702','0.028973924060365','983.1667478915805','983.166747891580485','test','test','2.7'),('2018-10-05 03:59:59','2018-10-14 23:59:59','OAXBTC','4h','0.000028800000000','0.000035900000000','0.028851574420627','0.035964288947934','1001.7907784940047','1001.790778494004712','test','test','0.0'),('2018-10-16 15:59:59','2018-10-16 19:59:59','OAXBTC','4h','0.000037290000000','0.000035910000000','0.030432177648918','0.029305966730294','816.0948685684574','816.094868568457400','test','test','3.7'),('2018-10-17 07:59:59','2018-10-27 15:59:59','OAXBTC','4h','0.000036470000000','0.000039450000000','0.030181908555890','0.032648102345211','827.5818084971269','827.581808497126872','test','test','0.0'),('2018-10-28 19:59:59','2018-10-30 03:59:59','OAXBTC','4h','0.000042660000000','0.000041070000000','0.030729951620184','0.029584601805930','720.345795128546','720.345795128546001','test','test','3.7'),('2018-10-30 11:59:59','2018-10-31 15:59:59','OAXBTC','4h','0.000043410000000','0.000041673600000','0.030475429439238','0.029256412261668','702.0370753107219','702.037075310721889','test','test','4.0'),('2018-11-06 15:59:59','2018-11-13 11:59:59','OAXBTC','4h','0.000040860000000','0.000044180000000','0.030204536733112','0.032658747745200','739.2201843639692','739.220184363969224','test','test','0.0'),('2018-12-17 11:59:59','2018-12-17 19:59:59','OAXBTC','4h','0.000026080000000','0.000025036800000','0.030749916958020','0.029519920279699','1179.0612330529225','1179.061233052922489','test','test','4.0'),('2018-12-17 23:59:59','2018-12-18 19:59:59','OAXBTC','4h','0.000025990000000','0.000024950400000','0.030476584362838','0.029257520988324','1172.6273321599758','1172.627332159975822','test','test','4.0'),('2018-12-19 15:59:59','2018-12-19 23:59:59','OAXBTC','4h','0.000025290000000','0.000024890000000','0.030205681390724','0.029727932377031','1194.3725342318526','1194.372534231852569','test','test','1.6'),('2018-12-23 11:59:59','2018-12-23 15:59:59','OAXBTC','4h','0.000024220000000','0.000024220000000','0.030099514943236','0.030099514943236','1242.7545393573998','1242.754539357399835','test','test','0.0'),('2018-12-24 07:59:59','2018-12-25 03:59:59','OAXBTC','4h','0.000024780000000','0.000024280000000','0.030099514943236','0.029492180097731','1214.6696910103399','1214.669691010339875','test','test','2.0'),('2018-12-26 15:59:59','2018-12-26 19:59:59','OAXBTC','4h','0.000024480000000','0.000024340000000','0.029964551644235','0.029793185744309','1224.0421423298658','1224.042142329865783','test','test','0.6'),('2019-01-02 07:59:59','2019-01-07 11:59:59','OAXBTC','4h','0.000023730000000','0.000024190000000','0.029926470333140','0.030506587330748','1261.1239078440979','1261.123907844097857','test','test','0.0'),('2019-01-14 19:59:59','2019-01-27 11:59:59','OAXBTC','4h','0.000023820000000','0.000039560000000','0.030055385221498','0.049915660762488','1261.771000062879','1261.771000062879011','test','test','0.0'),('2019-01-27 23:59:59','2019-01-28 03:59:59','OAXBTC','4h','0.000042060000000','0.000040377600000','0.034468779786162','0.033090028594716','819.5144980067098','819.514498006709800','test','test','4.0'),('2019-02-02 11:59:59','2019-02-02 15:59:59','OAXBTC','4h','0.000040000000000','0.000038910000000','0.034162390632508','0.033231465487772','854.0597658126887','854.059765812688738','test','test','2.7'),('2019-02-10 23:59:59','2019-02-11 03:59:59','OAXBTC','4h','0.000036180000000','0.000035420000000','0.033955518378122','0.033242246018604','938.5162625240954','938.516262524095396','test','test','2.1'),('2019-02-11 15:59:59','2019-02-12 03:59:59','OAXBTC','4h','0.000037480000000','0.000035980800000','0.033797013409340','0.032445132872966','901.7346160442903','901.734616044290306','test','test','4.0'),('2019-02-12 19:59:59','2019-02-12 23:59:59','OAXBTC','4h','0.000037340000000','0.000035846400000','0.033496595512368','0.032156731691873','897.070045858811','897.070045858811000','test','test','4.0'),('2019-02-13 15:59:59','2019-02-14 15:59:59','OAXBTC','4h','0.000036040000000','0.000035880000000','0.033198847996702','0.033051461324131','921.1667035710999','921.166703571099902','test','test','0.4'),('2019-02-15 15:59:59','2019-02-15 19:59:59','OAXBTC','4h','0.000036110000000','0.000036000000000','0.033166095402798','0.033065063265044','918.4739795845412','918.473979584541212','test','test','0.3'),('2019-02-25 15:59:59','2019-02-25 19:59:59','OAXBTC','4h','0.000033860000000','0.000033120000000','0.033143643816630','0.032419299563106','978.8435858425936','978.843585842593598','test','test','2.2'),('2019-02-26 15:59:59','2019-02-26 19:59:59','OAXBTC','4h','0.000033580000000','0.000033910000000','0.032982678426958','0.033306808381720','982.2119841262124','982.211984126212428','test','test','0.0'),('2019-03-01 19:59:59','2019-03-01 23:59:59','OAXBTC','4h','0.000033160000000','0.000033270000000','0.033054707305794','0.033164358023636','996.8247076536254','996.824707653625410','test','test','0.0'),('2019-03-02 23:59:59','2019-03-04 03:59:59','OAXBTC','4h','0.000033720000000','0.000033010000000','0.033079074131981','0.032382569308917','980.9927085403717','980.992708540371723','test','test','2.1'),('2019-03-06 19:59:59','2019-03-11 11:59:59','OAXBTC','4h','0.000033860000000','0.000033840000000','0.032924295282412','0.032904847972735','972.3654838278663','972.365483827866342','test','test','1.2'),('2019-03-12 11:59:59','2019-03-18 07:59:59','OAXBTC','4h','0.000035100000000','0.000037600000000','0.032919973658039','0.035264701126560','937.8909874085152','937.890987408515230','test','test','0.0'),('2019-03-18 11:59:59','2019-03-18 19:59:59','OAXBTC','4h','0.000040500000000','0.000038880000000','0.033441024206599','0.032103383238335','825.7043013975087','825.704301397508743','test','test','4.0'),('2019-03-19 07:59:59','2019-03-19 11:59:59','OAXBTC','4h','0.000040490000000','0.000038870400000','0.033143770658096','0.031818019831772','818.5668228722153','818.566822872215312','test','test','4.0'),('2019-03-19 19:59:59','2019-03-21 15:59:59','OAXBTC','4h','0.000039730000000','0.000038140800000','0.032849159363357','0.031535192988823','826.8099512549037','826.809951254903694','test','test','4.0'),('2019-03-26 11:59:59','2019-03-26 15:59:59','OAXBTC','4h','0.000038230000000','0.000088340000000','0.032557166835683','0.075231496684913','851.6130482783967','851.613048278396718','test','test','0.0'),('2019-03-26 19:59:59','2019-03-27 03:59:59','OAXBTC','4h','0.000091990000000','0.000088310400000','0.042040351246623','0.040358737196758','457.01001463879885','457.010014638798850','test','test','4.0'),('2019-03-27 07:59:59','2019-03-27 11:59:59','OAXBTC','4h','0.000109800000000','0.000105408000000','0.041666659235542','0.039999992866120','379.47777081550083','379.477770815500833','test','test','4.0'),('2019-03-27 15:59:59','2019-03-28 03:59:59','OAXBTC','4h','0.000068150000000','0.000065424000000','0.041296288931226','0.039644437373977','605.9616864449889','605.961686444988914','test','test','4.0'),('2019-03-31 15:59:59','2019-04-02 03:59:59','OAXBTC','4h','0.000054120000000','0.000053860000000','0.040929210807393','0.040732581191541','756.2677532777695','756.267753277769543','test','test','0.5');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:12:13
