-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-19 15:59:59','2018-04-14 19:59:59','XVGETH','4h','0.000056730000000','0.000172950000000','1.297777777777778','3.956472178153828','22876.39305090389','22876.393050903890980','test','test','1.3'),('2018-04-14 23:59:59','2018-04-15 03:59:59','XVGETH','4h','0.000173450000000','0.000180320000000','1.888598755639122','1.963402292400383','10888.433298582428','10888.433298582427597','test','test','0.0'),('2018-04-16 23:59:59','2018-04-17 11:59:59','XVGETH','4h','0.000183780000000','0.000208460000000','1.905221763808291','2.161075899899207','10366.861267865335','10366.861267865335321','test','test','0.0'),('2018-04-30 23:59:59','2018-05-01 03:59:59','XVGETH','4h','0.000115250000000','0.000112210000000','1.962078238495162','1.910323636802969','17024.54003032678','17024.540030326781562','test','test','2.6'),('2018-05-01 11:59:59','2018-05-02 15:59:59','XVGETH','4h','0.000121250000000','0.000116400000000','1.950577215896896','1.872554127261020','16087.234770283678','16087.234770283677790','test','test','4.0'),('2018-07-01 23:59:59','2018-07-05 11:59:59','XVGETH','4h','0.000055360000000','0.000054280000000','1.933238751755591','1.895523833910648','34921.22022679896','34921.220226798963267','test','test','2.0'),('2018-07-16 15:59:59','2018-07-16 19:59:59','XVGETH','4h','0.000051710000000','0.000051860000000','1.924857658901159','1.930441272299635','37224.089323170745','37224.089323170745047','test','test','0.0'),('2018-07-16 23:59:59','2018-07-17 03:59:59','XVGETH','4h','0.000052200000000','0.000051210000000','1.926098461878598','1.889569008291245','36898.43796702295','36898.437967022946395','test','test','1.9'),('2018-07-17 11:59:59','2018-07-17 15:59:59','XVGETH','4h','0.000051800000000','0.000052000000000','1.917980805525853','1.925386136821319','37026.65647733307','37026.656477333068324','test','test','0.0'),('2018-07-17 19:59:59','2018-07-20 07:59:59','XVGETH','4h','0.000052160000000','0.000051120000000','1.919626434702623','1.881351674501497','36802.654039544155','36802.654039544155239','test','test','2.0'),('2018-07-25 07:59:59','2018-07-25 19:59:59','XVGETH','4h','0.000051960000000','0.000051270000000','1.911120932435706','1.885742305734770','36780.6184071537','36780.618407153699081','test','test','1.3'),('2018-07-26 03:59:59','2018-07-26 11:59:59','XVGETH','4h','0.000053570000000','0.000051820000000','1.905481237613276','1.843233857254433','35569.93163362472','35569.931633624721144','test','test','3.3'),('2018-07-30 07:59:59','2018-07-30 15:59:59','XVGETH','4h','0.000052400000000','0.000052000000000','1.891648486422422','1.877208421640571','36100.161954626376','36100.161954626375518','test','test','0.8'),('2018-07-30 23:59:59','2018-08-02 11:59:59','XVGETH','4h','0.000053110000000','0.000050985600000','1.888439583137566','1.812901999812063','35557.13769793949','35557.137697939491773','test','test','4.0'),('2018-08-17 03:59:59','2018-08-22 19:59:59','XVGETH','4h','0.000044330000000','0.000045950000000','1.871653453509676','1.940051346464462','42220.921577028574','42220.921577028573665','test','test','0.0'),('2018-08-23 03:59:59','2018-08-23 07:59:59','XVGETH','4h','0.000045800000000','0.000046260000000','1.886852985277407','1.905803910457049','41197.66343400452','41197.663434004520241','test','test','0.0'),('2018-08-24 19:59:59','2018-08-30 15:59:59','XVGETH','4h','0.000046810000000','0.000050000000000','1.891064301983994','2.019936233693649','40398.72467387298','40398.724673872980929','test','test','0.0'),('2018-09-01 03:59:59','2018-09-13 23:59:59','XVGETH','4h','0.000051930000000','0.000063800000000','1.919702509030584','2.358502215985967','36967.1193728208','36967.119372820801800','test','test','0.0'),('2018-09-17 19:59:59','2018-09-18 15:59:59','XVGETH','4h','0.000064960000000','0.000062840000000','2.017213555020669','1.951380846636374','31053.16433221473','31053.164332214728347','test','test','3.3'),('2018-09-18 23:59:59','2018-09-19 03:59:59','XVGETH','4h','0.000063760000000','0.000064400000000','2.002584064268603','2.022685284487108','31408.156591414736','31408.156591414735885','test','test','0.0'),('2018-09-19 19:59:59','2018-09-21 19:59:59','XVGETH','4h','0.000065010000000','0.000064050000000','2.007051002094939','1.977412962377801','30872.95803868541','30872.958038685410429','test','test','1.5'),('2018-09-21 23:59:59','2018-09-22 03:59:59','XVGETH','4h','0.000064400000000','0.000063430000000','2.000464771046686','1.970333547010735','31063.11756283674','31063.117562836738216','test','test','1.5'),('2018-09-25 07:59:59','2018-09-25 11:59:59','XVGETH','4h','0.000064350000000','0.000064930000000','1.993768943483141','2.011739199694799','30983.20036492837','30983.200364928368799','test','test','0.0'),('2018-09-25 15:59:59','2018-09-25 23:59:59','XVGETH','4h','0.000064770000000','0.000063740000000','1.997762333752398','1.965993070146331','30843.94524860889','30843.945248608888505','test','test','1.6'),('2018-09-26 03:59:59','2018-09-26 19:59:59','XVGETH','4h','0.000064950000000','0.000064360000000','1.990702497395494','1.972619133677814','30649.769013017612','30649.769013017612451','test','test','0.9'),('2018-09-27 15:59:59','2018-09-28 03:59:59','XVGETH','4h','0.000065550000000','0.000064080000000','1.986683972124898','1.942131333848413','30307.91719488785','30307.917194887850201','test','test','2.2'),('2018-09-28 07:59:59','2018-09-28 11:59:59','XVGETH','4h','0.000064950000000','0.000064440000000','1.976783385841235','1.961261299208763','30435.46398523841','30435.463985238409805','test','test','0.8'),('2018-09-28 19:59:59','2018-09-29 03:59:59','XVGETH','4h','0.000064590000000','0.000064400000000','1.973334033256241','1.967529211049728','30551.695823753536','30551.695823753536388','test','test','0.6'),('2018-09-30 15:59:59','2018-10-10 07:59:59','XVGETH','4h','0.000065880000000','0.000069190000000','1.972044072765905','2.071125218498376','29933.880885942697','29933.880885942697205','test','test','0.7'),('2018-10-10 11:59:59','2018-10-15 03:59:59','XVGETH','4h','0.000070300000000','0.000070410000000','1.994062105150899','1.997182259227237','28365.037057623027','28365.037057623027067','test','test','0.0'),('2018-10-19 19:59:59','2018-10-20 03:59:59','XVGETH','4h','0.000070520000000','0.000069680000000','1.994755472723418','1.970994914057966','28286.379363633274','28286.379363633273897','test','test','1.2'),('2018-10-21 11:59:59','2018-10-22 07:59:59','XVGETH','4h','0.000070710000000','0.000070430000000','1.989475348575540','1.981597352569301','28135.70002228171','28135.700022281711426','test','test','0.7'),('2018-10-23 15:59:59','2018-10-27 23:59:59','XVGETH','4h','0.000070180000000','0.000071810000000','1.987724682796376','2.033891557019205','28323.23571952659','28323.235719526590401','test','test','0.0'),('2018-10-28 11:59:59','2018-10-29 11:59:59','XVGETH','4h','0.000071930000000','0.000070660000000','1.997983988179227','1.962707473998946','27776.782819118962','27776.782819118961925','test','test','1.8'),('2018-11-27 23:59:59','2018-12-04 07:59:59','XVGETH','4h','0.000055290000000','0.000064780000000','1.990144762805831','2.331734088163533','35994.66020629103','35994.660206291031500','test','test','0.0'),('2018-12-05 03:59:59','2018-12-06 15:59:59','XVGETH','4h','0.000065830000000','0.000063196800000','2.066053501774209','1.983411361703241','31384.6802639254','31384.680263925398322','test','test','4.0'),('2018-12-07 07:59:59','2018-12-08 03:59:59','XVGETH','4h','0.000065220000000','0.000064820000000','2.047688581758438','2.035129927469824','31396.635721533858','31396.635721533857577','test','test','1.5'),('2018-12-10 15:59:59','2018-12-10 19:59:59','XVGETH','4h','0.000064720000000','0.000063550000000','2.044897769694302','2.007930365637714','31596.07184323705','31596.071843237048597','test','test','1.8'),('2018-12-11 23:59:59','2018-12-12 03:59:59','XVGETH','4h','0.000064350000000','0.000063720000000','2.036682791015060','2.016743239214913','31650.082222456258','31650.082222456258023','test','test','1.0'),('2018-12-12 11:59:59','2018-12-12 15:59:59','XVGETH','4h','0.000064700000000','0.000064700000000','2.032251779503917','2.032251779503917','31410.382990786962','31410.382990786962182','test','test','0.0'),('2018-12-13 03:59:59','2018-12-13 11:59:59','XVGETH','4h','0.000065250000000','0.000064050000000','2.032251779503917','1.994877034133730','31145.621141822478','31145.621141822477512','test','test','1.8'),('2018-12-13 19:59:59','2018-12-13 23:59:59','XVGETH','4h','0.000064960000000','0.000064020000000','2.023946280532764','1.994658880537370','31156.808505738365','31156.808505738365056','test','test','1.4'),('2018-12-14 19:59:59','2018-12-15 11:59:59','XVGETH','4h','0.000069210000000','0.000066441600000','2.017437969422676','1.936740450645769','29149.515524095885','29149.515524095884757','test','test','4.0'),('2018-12-15 15:59:59','2018-12-16 23:59:59','XVGETH','4h','0.000066820000000','0.000065710000000','1.999505187472252','1.966289821442707','29923.753179770312','29923.753179770312272','test','test','2.3'),('2018-12-17 15:59:59','2018-12-18 03:59:59','XVGETH','4h','0.000066180000000','0.000065350000000','1.992123995021243','1.967139665679030','30101.601617123637','30101.601617123636970','test','test','1.3'),('2018-12-18 11:59:59','2018-12-18 15:59:59','XVGETH','4h','0.000065580000000','0.000065880000000','1.986571921834084','1.995659625044670','30292.34403528643','30292.344035286430881','test','test','0.0'),('2018-12-18 19:59:59','2018-12-18 23:59:59','XVGETH','4h','0.000065930000000','0.000065000000000','1.988591411436437','1.960540599778074','30162.163073508822','30162.163073508821981','test','test','1.4'),('2018-12-19 03:59:59','2018-12-22 23:59:59','XVGETH','4h','0.000067260000000','0.000068960000000','1.982357897734578','2.032462096755523','29473.058247614896','29473.058247614895663','test','test','1.0'),('2019-01-10 15:59:59','2019-01-12 23:59:59','XVGETH','4h','0.000057520000000','0.000055219200000','1.993492164183677','1.913752477616330','34657.37420347144','34657.374203471437795','test','test','4.0'),('2019-01-15 15:59:59','2019-01-27 11:59:59','XVGETH','4h','0.000055350000000','0.000056570000000','1.975772233835378','2.019321323722987','35695.975317712335','35695.975317712334800','test','test','1.2'),('2019-01-27 19:59:59','2019-01-27 23:59:59','XVGETH','4h','0.000056220000000','0.000056990000000','1.985449809365957','2.012642914190073','35315.72055079967','35315.720550799669581','test','test','0.0'),('2019-01-28 03:59:59','2019-01-28 07:59:59','XVGETH','4h','0.000057070000000','0.000056520000000','1.991492721549094','1.972300133554491','34895.6145356421','34895.614535642096598','test','test','1.0'),('2019-01-28 11:59:59','2019-01-29 11:59:59','XVGETH','4h','0.000057450000000','0.000057470000000','1.987227701994738','1.987919513205180','34590.560522101616','34590.560522101615788','test','test','1.4'),('2019-01-29 15:59:59','2019-01-30 15:59:59','XVGETH','4h','0.000057510000000','0.000057030000000','1.987381437819280','1.970794007978326','34557.145501987136','34557.145501987135503','test','test','1.0'),('2019-03-02 07:59:59','2019-03-02 11:59:59','XVGETH','4h','0.000044750000000','0.000044600000000','1.983695342299068','1.977046084168457','44328.387537409355','44328.387537409354991','test','test','0.3'),('2019-03-02 15:59:59','2019-03-03 03:59:59','XVGETH','4h','0.000045280000000','0.000045260000000','1.982217729381155','1.981342191514820','43776.89331672162','43776.893316721616429','test','test','0.0'),('2019-03-03 11:59:59','2019-03-05 23:59:59','XVGETH','4h','0.000045220000000','0.000046020000000','1.982023165410858','2.017087706152315','43830.675926821285','43830.675926821284520','test','test','0.0'),('2019-03-08 11:59:59','2019-03-10 07:59:59','XVGETH','4h','0.000047270000000','0.000046240000000','1.989815285575627','1.946457770362111','42094.67496457853','42094.674964578531217','test','test','2.2'),('2019-03-12 11:59:59','2019-03-18 19:59:59','XVGETH','4h','0.000049210000000','0.000049580000000','1.980180282194845','1.995068855745182','40239.38797388428','40239.387973884280655','test','test','0.2'),('2019-03-19 15:59:59','2019-03-19 15:59:59','XVGETH','4h','0.000049680000000','0.000049680000000','1.983488854094920','1.983488854094920','39925.29899546941','39925.298995469413057','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:44:42
