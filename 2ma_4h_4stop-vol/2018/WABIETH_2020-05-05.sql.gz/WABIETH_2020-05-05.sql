-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-31 07:59:59','2018-06-01 11:59:59','WABIETH','4h','0.001360300000000','0.001305888000000','1.297777777777778','1.245866666666667','954.0379164726734','954.037916472673373','test','test','4.0'),('2018-06-02 11:59:59','2018-06-03 19:59:59','WABIETH','4h','0.001382080000000','0.001326796800000','1.286241975308642','1.234792296296296','930.6566734983808','930.656673498380769','test','test','4.0'),('2018-06-29 15:59:59','2018-06-29 23:59:59','WABIETH','4h','0.000814920000000','0.000801440000000','1.274808713305899','1.253721463691994','1564.3360247704052','1564.336024770405174','test','test','1.7'),('2018-06-30 03:59:59','2018-07-01 03:59:59','WABIETH','4h','0.000872190000000','0.000837302400000','1.270122657836142','1.219317751522696','1456.2453798325384','1456.245379832538447','test','test','4.0'),('2018-07-01 23:59:59','2018-07-03 23:59:59','WABIETH','4h','0.000917490000000','0.000880790400000','1.258832678655376','1.208479371509161','1372.0396719913854','1372.039671991385376','test','test','4.0'),('2018-07-04 15:59:59','2018-07-05 15:59:59','WABIETH','4h','0.000896890000000','0.000861014400000','1.247643054845106','1.197737332651302','1391.0770048111874','1391.077004811187408','test','test','4.0'),('2018-07-06 19:59:59','2018-07-07 15:59:59','WABIETH','4h','0.000905890000000','0.000869654400000','1.236552894357594','1.187090778583290','1365.0143994939715','1365.014399493971496','test','test','4.0'),('2018-07-16 11:59:59','2018-07-20 07:59:59','WABIETH','4h','0.000842230000000','0.000808540800000','1.225561313074415','1.176538860551438','1455.1385168830548','1455.138516883054763','test','test','4.0'),('2018-08-17 15:59:59','2018-08-18 07:59:59','WABIETH','4h','0.000545810000000','0.000523977600000','1.214667434735976','1.166080737346537','2225.440051915458','2225.440051915457843','test','test','4.0'),('2018-08-20 11:59:59','2018-08-20 15:59:59','WABIETH','4h','0.000510000000000','0.000564280000000','1.203870390871656','1.331999968943251','2360.5301781797184','2360.530178179718405','test','test','0.0'),('2018-08-20 19:59:59','2018-08-20 23:59:59','WABIETH','4h','0.000565520000000','0.000542899200000','1.232343630443122','1.183049885225397','2179.1335946440827','2179.133594644082677','test','test','4.0'),('2018-08-21 15:59:59','2018-08-22 19:59:59','WABIETH','4h','0.000560140000000','0.000543430000000','1.221389464839183','1.184953184699463','2180.507488912027','2180.507488912026929','test','test','3.0'),('2018-08-26 03:59:59','2018-09-13 19:59:59','WABIETH','4h','0.000596950000000','0.000851450000000','1.213292513697023','1.730560198990418','2032.4859932942843','2032.485993294284299','test','test','0.0'),('2018-09-15 15:59:59','2018-09-15 23:59:59','WABIETH','4h','0.000954220000000','0.000916051200000','1.328240888206666','1.275111252678399','1391.9650481091007','1391.965048109100735','test','test','4.0'),('2018-09-16 07:59:59','2018-09-17 15:59:59','WABIETH','4h','0.000989940000000','0.000950342400000','1.316434302533718','1.263776930432369','1329.8122134005273','1329.812213400527298','test','test','4.0'),('2018-09-20 03:59:59','2018-09-20 07:59:59','WABIETH','4h','0.000902480000000','0.000913750000000','1.304732664288974','1.321025919681378','1445.7192007456936','1445.719200745693570','test','test','0.0'),('2018-09-20 15:59:59','2018-09-20 23:59:59','WABIETH','4h','0.000932570000000','0.000907330000000','1.308353387709508','1.272942813161980','1402.954617572416','1402.954617572416055','test','test','2.7'),('2018-09-21 11:59:59','2018-09-21 15:59:59','WABIETH','4h','0.000940750000000','0.000903120000000','1.300484371143391','1.248464996297656','1382.3910402799795','1382.391040279979507','test','test','4.0'),('2018-09-23 11:59:59','2018-09-23 15:59:59','WABIETH','4h','0.000897730000000','0.000901560000000','1.288924510066561','1.294423469523809','1435.7596494119173','1435.759649411917280','test','test','0.0'),('2018-09-25 03:59:59','2018-09-28 11:59:59','WABIETH','4h','0.000951300000000','0.000976880000000','1.290146501057060','1.324837920690235','1356.1931052844109','1356.193105284410876','test','test','0.3'),('2018-10-04 07:59:59','2018-10-04 11:59:59','WABIETH','4h','0.000945330000000','0.000941270000000','1.297855705419988','1.292281679244996','1372.912850983242','1372.912850983241924','test','test','0.4'),('2018-10-04 19:59:59','2018-10-06 11:59:59','WABIETH','4h','0.000945280000000','0.000936360000000','1.296617032936656','1.284381691097418','1371.6750940849868','1371.675094084986767','test','test','0.9'),('2018-10-10 11:59:59','2018-10-11 07:59:59','WABIETH','4h','0.000970000000000','0.000931200000000','1.293898068083492','1.242142145360152','1333.915534106693','1333.915534106693030','test','test','4.0'),('2018-10-11 23:59:59','2018-10-12 11:59:59','WABIETH','4h','0.000987380000000','0.000947884800000','1.282396751922750','1.231100881845840','1298.7874495358933','1298.787449535893302','test','test','4.0'),('2018-10-13 15:59:59','2018-10-22 07:59:59','WABIETH','4h','0.001232190000000','0.001210970000000','1.270997669683437','1.249109348441841','1031.4948747217854','1031.494874721785436','test','test','1.7'),('2018-10-22 11:59:59','2018-10-22 15:59:59','WABIETH','4h','0.001225530000000','0.001215040000000','1.266133598296415','1.255296049279965','1033.1314601000508','1033.131460100050845','test','test','0.9'),('2018-10-22 23:59:59','2018-10-26 11:59:59','WABIETH','4h','0.001256530000000','0.001266850000000','1.263725254070538','1.274104349374277','1005.7262891220565','1005.726289122056528','test','test','0.1'),('2018-10-28 15:59:59','2018-10-28 19:59:59','WABIETH','4h','0.001315870000000','0.001274580000000','1.266031719693591','1.226305569157331','962.1252249033648','962.125224903364824','test','test','3.1'),('2018-10-28 23:59:59','2018-11-04 07:59:59','WABIETH','4h','0.001289570000000','0.001451890000000','1.257203686241089','1.415449692546022','974.9014681181236','974.901468118123603','test','test','0.9'),('2018-11-04 11:59:59','2018-11-04 23:59:59','WABIETH','4h','0.001452680000000','0.001394572800000','1.292369465419962','1.240674686803164','889.6449771594312','889.644977159431164','test','test','4.0'),('2018-11-05 15:59:59','2018-11-05 19:59:59','WABIETH','4h','0.001401630000000','0.001393420000000','1.280881736838452','1.273379015678485','913.8515420178306','913.851542017830639','test','test','0.6'),('2018-11-07 15:59:59','2018-11-08 07:59:59','WABIETH','4h','0.001428640000000','0.001385070000000','1.279214465469570','1.240201576105903','895.4071462856775','895.407146285677527','test','test','3.0'),('2018-11-11 19:59:59','2018-11-13 03:59:59','WABIETH','4h','0.001510830000000','0.001450396800000','1.270544934499866','1.219723137119871','840.9582378559246','840.958237855924608','test','test','4.0'),('2018-11-25 11:59:59','2018-11-25 19:59:59','WABIETH','4h','0.001201740000000','0.001289150000000','1.259251201748756','1.350844347974112','1047.8566093737052','1047.856609373705169','test','test','0.0'),('2018-11-25 23:59:59','2018-11-30 11:59:59','WABIETH','4h','0.001277660000000','0.001328700000000','1.279605234243280','1.330722942519173','1001.52249756843','1001.522497568430026','test','test','0.8'),('2018-12-01 23:59:59','2018-12-03 03:59:59','WABIETH','4h','0.001401830000000','0.001345756800000','1.290964724971256','1.239326135972406','920.9138946742875','920.913894674287462','test','test','4.0'),('2018-12-03 07:59:59','2018-12-03 15:59:59','WABIETH','4h','0.001328200000000','0.001353570000000','1.279489482971512','1.303929061486033','963.3259170091188','963.325917009118825','test','test','0.0'),('2018-12-03 19:59:59','2018-12-06 15:59:59','WABIETH','4h','0.001379170000000','0.001380050000000','1.284920500419183','1.285740363119480','931.6621594286297','931.662159428629707','test','test','1.1'),('2018-12-06 23:59:59','2018-12-07 03:59:59','WABIETH','4h','0.001408350000000','0.001402200000000','1.285102692130360','1.279490889981319','912.4881543155893','912.488154315589327','test','test','0.4'),('2018-12-07 15:59:59','2018-12-07 19:59:59','WABIETH','4h','0.001385530000000','0.001330108800000','1.283855624986129','1.232501399986684','926.6169804956434','926.616980495643361','test','test','4.0'),('2018-12-16 19:59:59','2018-12-16 23:59:59','WABIETH','4h','0.001411000000000','0.001354560000000','1.272443574986252','1.221545831986802','901.8026753977691','901.802675397769121','test','test','4.0'),('2018-12-17 03:59:59','2018-12-17 23:59:59','WABIETH','4h','0.001383710000000','0.001328361600000','1.261132965430819','1.210687646813586','911.4142164404528','911.414216440452833','test','test','4.0'),('2018-12-18 03:59:59','2018-12-18 07:59:59','WABIETH','4h','0.001294980000000','0.001287390000000','1.249922894626989','1.242596978574062','965.2063310838695','965.206331083869486','test','test','0.6'),('2019-01-10 07:59:59','2019-01-10 11:59:59','WABIETH','4h','0.000883470000000','0.000889250000000','1.248294913281895','1.256461737960457','1412.9454461180285','1412.945446118028485','test','test','0.0'),('2019-01-10 15:59:59','2019-01-10 19:59:59','WABIETH','4h','0.000901060000000','0.000893170000000','1.250109763210464','1.239163360050041','1387.37682641607','1387.376826416069889','test','test','0.9'),('2019-01-11 11:59:59','2019-01-12 03:59:59','WABIETH','4h','0.000895560000000','0.000894070000000','1.247677229174814','1.245601389396942','1393.1810589740658','1393.181058974065763','test','test','0.2'),('2019-01-12 15:59:59','2019-01-14 15:59:59','WABIETH','4h','0.000903010000000','0.000882180000000','1.247215931446398','1.218446030944711','1381.1762122749453','1381.176212274945328','test','test','2.3'),('2019-01-14 23:59:59','2019-01-15 15:59:59','WABIETH','4h','0.000910970000000','0.000898390000000','1.240822620223801','1.223687535026247','1362.0894433667424','1362.089443366742444','test','test','1.4'),('2019-01-15 23:59:59','2019-01-26 15:59:59','WABIETH','4h','0.000930000000000','0.001090140000000','1.237014823513234','1.450020795381416','1330.123466143262','1330.123466143262021','test','test','0.7'),('2019-01-27 23:59:59','2019-01-28 03:59:59','WABIETH','4h','0.001104680000000','0.001060492800000','1.284349483928385','1.232975504571250','1162.6439185360334','1162.643918536033425','test','test','4.0'),('2019-01-30 11:59:59','2019-01-30 15:59:59','WABIETH','4h','0.001124740000000','0.001090000000000','1.272933044071244','1.233615785014898','1131.757600931099','1131.757600931098978','test','test','3.1'),('2019-02-02 07:59:59','2019-02-02 15:59:59','WABIETH','4h','0.001106880000000','0.001080970000000','1.264195875392056','1.234603403641362','1142.125501763566','1142.125501763566035','test','test','2.3'),('2019-02-06 03:59:59','2019-02-06 19:59:59','WABIETH','4h','0.001097280000000','0.001066450000000','1.257619770558569','1.222284744378997','1146.1247544460562','1146.124754446056158','test','test','2.8'),('2019-02-07 07:59:59','2019-02-08 15:59:59','WABIETH','4h','0.001097950000000','0.001156610000000','1.249767542518664','1.316538674213318','1138.2736395269944','1138.273639526994430','test','test','1.7'),('2019-02-08 19:59:59','2019-02-08 23:59:59','WABIETH','4h','0.001124600000000','0.001128740000000','1.264605571784142','1.269260975542978','1124.4936615544573','1124.493661554457276','test','test','0.0'),('2019-02-09 03:59:59','2019-02-09 19:59:59','WABIETH','4h','0.001159900000000','0.001113504000000','1.265640105952772','1.215014501714661','1091.163122642273','1091.163122642273038','test','test','4.0'),('2019-02-09 23:59:59','2019-02-12 11:59:59','WABIETH','4h','0.001108850000000','0.001112500000000','1.254389971677637','1.258519045399622','1131.253074516514','1131.253074516514062','test','test','0.0'),('2019-02-24 23:59:59','2019-02-25 03:59:59','WABIETH','4h','0.001020000000000','0.000980460000000','1.255307543615856','1.206645915895689','1230.6936702116234','1230.693670211623385','test','test','3.9'),('2019-02-26 11:59:59','2019-03-11 23:59:59','WABIETH','4h','0.001052200000000','0.001437200000000','1.244493848566930','1.699854171412651','1182.7540853135617','1182.754085313561745','test','test','0.0'),('2019-03-12 11:59:59','2019-03-21 15:59:59','WABIETH','4h','0.001504020000000','0.001668870000000','1.345685031421534','1.493180528442744','894.7254899679089','894.725489967908857','test','test','0.0'),('2019-03-24 11:59:59','2019-03-24 15:59:59','WABIETH','4h','0.001643980000000','0.001636520000000','1.378461808537359','1.372206668516380','838.4906194341528','838.490619434152791','test','test','0.5'),('2019-03-25 11:59:59','2019-03-25 15:59:59','WABIETH','4h','0.001647430000000','0.001593230000000','1.377071777421585','1.331766489587656','835.8909194451876','835.890919445187592','test','test','3.3'),('2019-03-27 15:59:59','2019-04-02 19:59:59','WABIETH','4h','0.001723340000000','0.002100820000000','1.367003935680713','1.666432165537129','793.2293892561611','793.229389256161085','test','test','0.8'),('2019-04-03 15:59:59','2019-04-03 19:59:59','WABIETH','4h','0.002088000000000','0.002004480000000','1.433543542315472','1.376201800622853','686.5629991932335','686.562999193233509','test','test','4.0'),('2019-04-12 15:59:59','2019-04-17 23:59:59','WABIETH','4h','0.001964150000000','0.002297230000000','1.420800933050445','1.661739952361822','723.3668167148359','723.366816714835863','test','test','0.0'),('2019-04-24 15:59:59','2019-04-24 19:59:59','WABIETH','4h','0.002275950000000','0.002274400000000','1.474342937341862','1.473338859241341','647.7923229165237','647.792322916523744','test','test','0.1'),('2019-04-24 23:59:59','2019-04-25 23:59:59','WABIETH','4h','0.002228580000000','0.002188160000000','1.474119808875080','1.447383536147724','661.4614727203331','661.461472720333063','test','test','1.8'),('2019-04-28 11:59:59','2019-04-29 15:59:59','WABIETH','4h','0.002182100000000','0.002188890000000','1.468178414935667','1.472746918412782','672.8281998696975','672.828199869697528','test','test','0.0'),('2019-04-29 19:59:59','2019-04-29 23:59:59','WABIETH','4h','0.002208760000000','0.002191000000000','1.469193637930582','1.457380277035941','665.1667170405937','665.166717040593653','test','test','0.8'),('2019-04-30 15:59:59','2019-04-30 23:59:59','WABIETH','4h','0.002225550000000','0.002191720000000','1.466568446620662','1.444275525522876','658.9689949094209','658.968994909420871','test','test','1.5'),('2019-05-05 11:59:59','2019-05-05 19:59:59','WABIETH','4h','0.002254760000000','0.002164569600000','1.461614464154487','1.403149885588308','648.2350512491291','648.235051249129128','test','test','4.0'),('2019-05-22 23:59:59','2019-05-23 03:59:59','WABIETH','4h','0.001449850000000','0.001417310000000','1.448622335584225','1.416109888917390','999.1532472905644','999.153247290564423','test','test','2.2'),('2019-05-23 11:59:59','2019-05-23 15:59:59','WABIETH','4h','0.001420410000000','0.001434560000000','1.441397347436039','1.455756421552822','1014.7755559564065','1014.775555956406492','test','test','0.0'),('2019-05-24 03:59:59','2019-05-24 07:59:59','WABIETH','4h','0.001472840000000','0.001413926400000','1.444588252795324','1.386804722683511','980.8181830988597','980.818183098859663','test','test','4.0'),('2019-05-24 11:59:59','2019-05-24 15:59:59','WABIETH','4h','0.001432390000000','0.001375094400000','1.431747468326033','1.374477569592992','999.5514268642149','999.551426864214932','test','test','4.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:32:10
