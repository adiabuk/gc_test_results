-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-01-02 03:59:59','2018-01-02 19:59:59','BNBBTC','4h','0.000627680000000','0.000602640000000','0.033333333333333','0.032003568697425','53.10561644999575','53.105616449995750','test','test','4.0'),('2018-01-02 23:59:59','2018-01-03 07:59:59','BNBBTC','4h','0.000592980000000','0.000569260800000','0.033037830080909','0.031716316877673','55.71491463609115','55.714914636091152','test','test','4.0'),('2018-01-03 19:59:59','2018-01-16 03:59:59','BNBBTC','4h','0.000597920000000','0.001372900000000','0.032744160480190','0.075184736960217','54.76344741803288','54.763447418032882','test','test','0.0'),('2018-01-16 11:59:59','2018-01-16 15:59:59','BNBBTC','4h','0.001319300000000','0.001266528000000','0.042175399697974','0.040488383710055','31.968013111478818','31.968013111478818','test','test','4.0'),('2018-01-19 03:59:59','2018-01-20 07:59:59','BNBBTC','4h','0.001314500000000','0.001278900000000','0.041800507256214','0.040668443309222','31.79954907281417','31.799549072814170','test','test','2.7'),('2018-01-20 19:59:59','2018-01-20 23:59:59','BNBBTC','4h','0.001278900000000','0.001266600000000','0.041548937490216','0.041149334760425','32.48802681227305','32.488026812273048','test','test','1.0'),('2018-02-07 11:59:59','2018-02-07 15:59:59','BNBBTC','4h','0.001086800000000','0.001072900000000','0.041460136883596','0.040929868294452','38.14881936289637','38.148819362896369','test','test','1.3'),('2018-02-09 15:59:59','2018-02-10 19:59:59','BNBBTC','4h','0.001144200000000','0.001098432000000','0.041342299419342','0.039688607442568','36.13205682515431','36.132056825154308','test','test','4.0'),('2018-02-11 15:59:59','2018-02-11 19:59:59','BNBBTC','4h','0.001097400000000','0.001072500000000','0.040974812313392','0.040045094046030','37.338083026600856','37.338083026600856','test','test','2.3'),('2018-02-14 23:59:59','2018-02-15 19:59:59','BNBBTC','4h','0.001101000000000','0.001083500000000','0.040768208253978','0.040120212209977','37.02834537146049','37.028345371460489','test','test','1.6'),('2018-02-15 23:59:59','2018-02-16 03:59:59','BNBBTC','4h','0.001085700000000','0.001069800000000','0.040624209133089','0.040029270452776','37.41752706372745','37.417527063727448','test','test','1.5'),('2018-02-16 15:59:59','2018-02-16 19:59:59','BNBBTC','4h','0.001084000000000','0.001080800000000','0.040492000537464','0.040372466956542','37.35424403825073','37.354244038250727','test','test','0.3'),('2018-02-16 23:59:59','2018-02-17 11:59:59','BNBBTC','4h','0.001103900000000','0.001080600000000','0.040465437519481','0.039611334163920','36.656796376013325','36.656796376013325','test','test','2.1'),('2018-02-26 07:59:59','2018-02-26 11:59:59','BNBBTC','4h','0.000978300000000','0.000962900000000','0.040275636773801','0.039641634109673','41.16900416416323','41.169004164163233','test','test','1.6'),('2018-02-27 07:59:59','2018-02-27 15:59:59','BNBBTC','4h','0.001012800000000','0.000988200000000','0.040134747292884','0.039159910421434','39.62751509960857','39.627515099608573','test','test','2.4'),('2018-02-28 03:59:59','2018-03-01 07:59:59','BNBBTC','4h','0.001008600000000','0.000991000000000','0.039918116877006','0.039221548507945','39.577748242123526','39.577748242123526','test','test','1.7'),('2018-03-01 11:59:59','2018-03-01 15:59:59','BNBBTC','4h','0.000987800000000','0.000973800000000','0.039763323906103','0.039199761915128','40.25442792681043','40.254427926810429','test','test','1.4'),('2018-03-13 15:59:59','2018-03-19 15:59:59','BNBBTC','4h','0.001063000000000','0.001043300000000','0.039638087908109','0.038903496815174','37.288887966236025','37.288887966236025','test','test','1.9'),('2018-03-20 03:59:59','2018-03-20 19:59:59','BNBBTC','4h','0.001051500000000','0.001024700000000','0.039474845443012','0.038468734308563','37.54146024062028','37.541460240620282','test','test','2.5'),('2018-03-21 11:59:59','2018-04-12 11:59:59','BNBBTC','4h','0.001099000000000','0.001626100000000','0.039251265190912','0.058076871999037','35.715436934406235','35.715436934406235','test','test','1.0'),('2018-04-14 03:59:59','2018-04-14 07:59:59','BNBBTC','4h','0.001711700000000','0.001690500000000','0.043434733370496','0.042896779086770','25.37520206256691','25.375202062566910','test','test','1.2'),('2018-04-24 15:59:59','2018-04-25 03:59:59','BNBBTC','4h','0.001592200000000','0.001537000000000','0.043315187974112','0.041813493227114','27.20461498185669','27.204614981856690','test','test','3.5'),('2018-04-26 07:59:59','2018-04-29 11:59:59','BNBBTC','4h','0.001613700000000','0.001587900000000','0.042981478030335','0.042294285780733','26.63535851170285','26.635358511702851','test','test','3.5'),('2018-04-30 03:59:59','2018-04-30 07:59:59','BNBBTC','4h','0.001576000000000','0.001567900000000','0.042828768641534','0.042608646163110','27.175614620262976','27.175614620262976','test','test','0.5'),('2018-05-09 15:59:59','2018-05-11 07:59:59','BNBBTC','4h','0.001513800000000','0.001506700000000','0.042779852535218','0.042579207170573','28.259910513421847','28.259910513421847','test','test','0.5'),('2018-05-13 11:59:59','2018-05-13 19:59:59','BNBBTC','4h','0.001537800000000','0.001499500000000','0.042735264676408','0.041670912590892','27.789871684489537','27.789871684489537','test','test','2.5'),('2018-05-17 15:59:59','2018-05-17 19:59:59','BNBBTC','4h','0.001509500000000','0.001546200000000','0.042498741990738','0.043532000573752','28.154184823277763','28.154184823277763','test','test','0.0'),('2018-05-17 23:59:59','2018-05-23 11:59:59','BNBBTC','4h','0.001536700000000','0.001651800000000','0.042728355009185','0.045928741331536','27.805267787587255','27.805267787587255','test','test','0.0'),('2018-05-25 07:59:59','2018-05-28 07:59:59','BNBBTC','4h','0.001720900000000','0.001694200000000','0.043439551969708','0.042765581351083','25.24234526684164','25.242345266841639','test','test','1.6'),('2018-05-29 23:59:59','2018-05-30 03:59:59','BNBBTC','4h','0.001688800000000','0.001671100000000','0.043289780721124','0.042836068547531','25.63345613519922','25.633456135199221','test','test','1.0'),('2018-05-30 11:59:59','2018-05-30 15:59:59','BNBBTC','4h','0.001686000000000','0.001678700000000','0.043188955793659','0.043001957349238','25.61622526314314','25.616225263143139','test','test','0.4'),('2018-05-30 23:59:59','2018-06-20 15:59:59','BNBBTC','4h','0.001705000000000','0.002362600000000','0.043147400583788','0.059788884820679','25.306393304274486','25.306393304274486','test','test','0.0'),('2018-06-21 11:59:59','2018-06-24 03:59:59','BNBBTC','4h','0.002387800000000','0.002412200000000','0.046845508191986','0.047324204230132','19.6186900879412','19.618690087941200','test','test','0.0'),('2018-06-28 23:59:59','2018-06-29 03:59:59','BNBBTC','4h','0.002419900000000','0.002416800000000','0.046951885089352','0.046891737627152','19.40240716118508','19.402407161185081','test','test','0.1'),('2018-06-29 19:59:59','2018-06-29 23:59:59','BNBBTC','4h','0.002394300000000','0.002338500000000','0.046938518986641','0.045844600363472','19.604276400885716','19.604276400885716','test','test','2.3'),('2018-07-28 07:59:59','2018-07-29 11:59:59','BNBBTC','4h','0.001755300000000','0.001713600000000','0.046695425959270','0.045586100338293','26.602532877154776','26.602532877154776','test','test','2.4'),('2018-07-31 15:59:59','2018-08-11 15:59:59','BNBBTC','4h','0.001775000000000','0.001899000000000','0.046448909154608','0.049693790695550','26.168399523722943','26.168399523722943','test','test','1.6'),('2018-08-27 11:59:59','2018-08-28 19:59:59','BNBBTC','4h','0.001588900000000','0.001613800000000','0.047169993941484','0.047909205250656','29.687201171555305','29.687201171555305','test','test','0.8'),('2018-08-28 23:59:59','2018-08-29 03:59:59','BNBBTC','4h','0.001626300000000','0.001561248000000','0.047334263121300','0.045440892596448','29.105492911086657','29.105492911086657','test','test','4.0'),('2018-09-01 03:59:59','2018-09-02 03:59:59','BNBBTC','4h','0.001600800000000','0.001583100000000','0.046913514115778','0.046394792726567','29.30629317577309','29.306293175773089','test','test','1.1'),('2018-09-06 23:59:59','2018-09-07 07:59:59','BNBBTC','4h','0.001578800000000','0.001548900000000','0.046798242695953','0.045911957253459','29.641653595105705','29.641653595105705','test','test','1.9'),('2018-09-15 03:59:59','2018-09-16 07:59:59','BNBBTC','4h','0.001559000000000','0.001527000000000','0.046601290375399','0.045644753305474','29.891783435149883','29.891783435149883','test','test','2.1'),('2018-09-16 15:59:59','2018-09-16 19:59:59','BNBBTC','4h','0.001526400000000','0.001515200000000','0.046388726582082','0.046048348085148','30.390937226206763','30.390937226206763','test','test','0.7'),('2018-09-16 23:59:59','2018-09-17 15:59:59','BNBBTC','4h','0.001528700000000','0.001510900000000','0.046313086916097','0.045773822870106','30.2957329208456','30.295732920845602','test','test','1.2'),('2018-09-20 19:59:59','2018-09-20 23:59:59','BNBBTC','4h','0.001517400000000','0.001546200000000','0.046193250461432','0.047069990683713','30.442368829202586','30.442368829202586','test','test','0.0'),('2018-09-21 03:59:59','2018-09-21 11:59:59','BNBBTC','4h','0.001533000000000','0.001528100000000','0.046388081621939','0.046239809214928','30.259674900155833','30.259674900155833','test','test','0.3'),('2018-09-22 03:59:59','2018-09-22 11:59:59','BNBBTC','4h','0.001531500000000','0.001507700000000','0.046355132198159','0.045634758612579','30.267797713456524','30.267797713456524','test','test','1.6'),('2018-09-23 11:59:59','2018-09-23 15:59:59','BNBBTC','4h','0.001534500000000','0.001523500000000','0.046195049179141','0.045863901873197','30.104300540332936','30.104300540332936','test','test','0.7'),('2018-09-24 03:59:59','2018-09-24 07:59:59','BNBBTC','4h','0.001535100000000','0.001518500000000','0.046121460888931','0.045622720578361','30.04459702229894','30.044597022298941','test','test','1.1'),('2018-09-25 03:59:59','2018-09-25 07:59:59','BNBBTC','4h','0.001522100000000','0.001497000000000','0.046010629708804','0.045251897164496','30.228388219436603','30.228388219436603','test','test','1.6'),('2018-09-29 19:59:59','2018-09-30 03:59:59','BNBBTC','4h','0.001518400000000','0.001505900000000','0.045842022476736','0.045464634910245','30.191005319241306','30.191005319241306','test','test','0.8'),('2018-10-02 19:59:59','2018-10-09 15:59:59','BNBBTC','4h','0.001527500000000','0.001557100000000','0.045758158573071','0.046644863315305','29.956241291699726','29.956241291699726','test','test','0.0'),('2018-10-10 15:59:59','2018-10-10 19:59:59','BNBBTC','4h','0.001568800000000','0.001566300000000','0.045955204071346','0.045881971020493','29.29322034124526','29.293220341245259','test','test','0.2'),('2018-10-15 23:59:59','2018-10-16 07:59:59','BNBBTC','4h','0.001563900000000','0.001528100000000','0.045938930060045','0.044887319537537','29.374595600770444','29.374595600770444','test','test','2.3'),('2018-11-01 23:59:59','2018-11-02 03:59:59','BNBBTC','4h','0.001499400000000','0.001507100000000','0.045705238832821','0.045939952944474','30.4823521627457','30.482352162745698','test','test','0.0'),('2018-11-02 07:59:59','2018-11-02 11:59:59','BNBBTC','4h','0.001502100000000','0.001493700000000','0.045757397524299','0.045501514334628','30.4622844845878','30.462284484587801','test','test','0.6'),('2018-11-02 23:59:59','2018-11-03 03:59:59','BNBBTC','4h','0.001501600000000','0.001494800000000','0.045700534593261','0.045493579588443','30.434559532006748','30.434559532006748','test','test','0.5'),('2018-11-03 23:59:59','2018-11-04 03:59:59','BNBBTC','4h','0.001501900000000','0.001497600000000','0.045654544592191','0.045523833798033','30.397859106592097','30.397859106592097','test','test','0.3'),('2018-11-04 11:59:59','2018-11-04 15:59:59','BNBBTC','4h','0.001503300000000','0.001497100000000','0.045625497749044','0.045437326335458','30.350227997767874','30.350227997767874','test','test','0.4'),('2018-11-04 19:59:59','2018-11-05 19:59:59','BNBBTC','4h','0.001515800000000','0.001504800000000','0.045583681879359','0.045252885929581','30.072359070694468','30.072359070694468','test','test','1.0'),('2018-11-05 23:59:59','2018-11-06 03:59:59','BNBBTC','4h','0.001507900000000','0.001503300000000','0.045510171668297','0.045371338330759','30.18116033443656','30.181160334436559','test','test','0.3'),('2018-11-06 07:59:59','2018-11-06 19:59:59','BNBBTC','4h','0.001506600000000','0.001501600000000','0.045479319815511','0.045328386190742','30.18672495387672','30.186724953876720','test','test','0.3'),('2018-11-07 03:59:59','2018-11-07 07:59:59','BNBBTC','4h','0.001510900000000','0.001502100000000','0.045445779010006','0.045181087200298','30.078614739563477','30.078614739563477','test','test','0.6'),('2018-11-08 15:59:59','2018-11-08 19:59:59','BNBBTC','4h','0.001507000000000','0.001500800000000','0.045386958607849','0.045200230576417','30.117424424584677','30.117424424584677','test','test','0.4'),('2018-12-03 15:59:59','2018-12-06 19:59:59','BNBBTC','4h','0.001294800000000','0.001389200000000','0.045345463489753','0.048651465770748','35.0212106037636','35.021210603763599','test','test','0.0'),('2018-12-11 15:59:59','2018-12-11 19:59:59','BNBBTC','4h','0.001362400000000','0.001393000000000','0.046080130663308','0.047115107174096','33.82276179044888','33.822761790448880','test','test','0.0'),('2018-12-11 23:59:59','2018-12-14 03:59:59','BNBBTC','4h','0.001449500000000','0.001399800000000','0.046310125443483','0.044722258431037','31.949034455662414','31.949034455662414','test','test','3.4'),('2018-12-14 15:59:59','2018-12-20 19:59:59','BNBBTC','4h','0.001421800000000','0.001396800000000','0.045957266107384','0.045149183639608','32.323298711058904','32.323298711058904','test','test','2.1'),('2018-12-21 23:59:59','2018-12-22 03:59:59','BNBBTC','4h','0.001427600000000','0.001428100000000','0.045777692225656','0.045793725320439','32.06618956686436','32.066189566864360','test','test','0.0'),('2018-12-22 11:59:59','2018-12-25 03:59:59','BNBBTC','4h','0.001438900000000','0.001445500000000','0.045781255135607','0.045991246298228','31.81684282132694','31.816842821326940','test','test','0.0'),('2018-12-26 19:59:59','2018-12-27 07:59:59','BNBBTC','4h','0.001473200000000','0.001461700000000','0.045827919838412','0.045470180849720','31.10773814717078','31.107738147170782','test','test','0.8'),('2018-12-28 11:59:59','2019-01-02 19:59:59','BNBBTC','4h','0.001489000000000','0.001559500000000','0.045748422285369','0.047914482574905','30.724259426037158','30.724259426037158','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:16:45
