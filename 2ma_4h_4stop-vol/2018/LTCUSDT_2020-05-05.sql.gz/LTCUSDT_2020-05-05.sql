-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-03 11:59:59','2018-06-04 07:59:59','LTCUSDT','4h','126.930000000000007','122.510000000000005','222.222222222222200','214.483923772508007','1.7507462555914455','1.750746255591445','test','test','3.5'),('2018-06-07 03:59:59','2018-06-07 07:59:59','LTCUSDT','4h','122.230000000000004','122.159999999999997','220.502600344507954','220.376320527571693','1.8039973848033048','1.803997384803305','test','test','0.1'),('2018-07-02 15:59:59','2018-07-03 23:59:59','LTCUSDT','4h','85.569999999999993','85.090000000000003','220.474538162966581','219.237798904836154','2.576540121105137','2.576540121105137','test','test','0.6'),('2018-07-04 15:59:59','2018-07-05 03:59:59','LTCUSDT','4h','86.840000000000003','85.150000000000006','220.199707216715382','215.914383573276297','2.535694463573415','2.535694463573415','test','test','1.9'),('2018-07-05 15:59:59','2018-07-05 19:59:59','LTCUSDT','4h','84.230000000000004','82.719999999999999','219.247413073728893','215.316941819528097','2.602961095497197','2.602961095497197','test','test','1.8'),('2018-07-08 03:59:59','2018-07-08 07:59:59','LTCUSDT','4h','84.090000000000003','83.709999999999994','218.373975017239815','217.387150061756955','2.5969077775863934','2.596907777586393','test','test','0.5'),('2018-07-08 15:59:59','2018-07-08 23:59:59','LTCUSDT','4h','84.519999999999996','82.219999999999999','218.154680582688087','212.218147627882331','2.5811012846981556','2.581101284698156','test','test','2.7'),('2018-07-16 11:59:59','2018-07-20 07:59:59','LTCUSDT','4h','82.640000000000001','83.939999999999998','216.835451037175716','220.246463698699500','2.623855893479861','2.623855893479861','test','test','1.1'),('2018-07-22 15:59:59','2018-07-22 19:59:59','LTCUSDT','4h','83.250000000000000','83.370000000000005','217.593453850847681','217.907102072614663','2.6137351813915637','2.613735181391564','test','test','0.0'),('2018-07-23 11:59:59','2018-07-23 19:59:59','LTCUSDT','4h','84.000000000000000','82.620000000000005','217.663153455684750','214.087258791769955','2.5912280173295805','2.591228017329581','test','test','1.6'),('2018-07-24 07:59:59','2018-07-26 23:59:59','LTCUSDT','4h','87.310000000000002','83.817599999999999','216.868510197037011','208.193769789155510','2.483890850956786','2.483890850956786','test','test','4.0'),('2018-08-27 19:59:59','2018-08-27 23:59:59','LTCUSDT','4h','58.130000000000003','60.609999999999999','214.940790106396690','224.110808332164197','3.697587994261082','3.697587994261082','test','test','0.0'),('2018-08-28 03:59:59','2018-08-30 11:59:59','LTCUSDT','4h','60.090000000000003','59.100000000000001','216.978571934345041','213.403787673819124','3.6108931924504084','3.610893192450408','test','test','1.6'),('2018-08-31 15:59:59','2018-09-05 11:59:59','LTCUSDT','4h','60.450000000000003','62.299999999999997','216.184175432005958','222.800233737203826','3.576247732539387','3.576247732539387','test','test','0.0'),('2018-09-14 19:59:59','2018-09-15 23:59:59','LTCUSDT','4h','58.020000000000003','56.219999999999999','217.654410610938811','210.901946993226119','3.7513686765070458','3.751368676507046','test','test','3.1'),('2018-09-20 23:59:59','2018-09-24 11:59:59','LTCUSDT','4h','56.530000000000001','57.369999999999997','216.153863140335972','219.365772658076679','3.823701806834176','3.823701806834176','test','test','0.0'),('2018-09-26 11:59:59','2018-09-26 15:59:59','LTCUSDT','4h','57.590000000000003','58.299999999999997','216.867620810945027','219.541279619345261','3.7657166315496617','3.765716631549662','test','test','0.0'),('2018-09-26 19:59:59','2018-09-26 23:59:59','LTCUSDT','4h','58.450000000000003','57.180000000000000','217.461767212811736','212.736763887571840','3.7204750592439986','3.720475059243999','test','test','2.2'),('2018-09-27 11:59:59','2018-10-02 15:59:59','LTCUSDT','4h','58.270000000000003','60.090000000000003','216.411766473869534','223.171152349662265','3.7139482834026003','3.713948283402600','test','test','0.0'),('2018-10-02 19:59:59','2018-10-02 23:59:59','LTCUSDT','4h','59.689999999999998','59.460000000000001','217.913852224045712','217.074177470962610','3.6507597960134985','3.650759796013499','test','test','0.4'),('2018-10-08 15:59:59','2018-10-09 15:59:59','LTCUSDT','4h','59.399999999999999','58.780000000000001','217.727257834471658','215.454683762798737','3.6654420510853813','3.665442051085381','test','test','1.0'),('2018-10-15 11:59:59','2018-10-15 23:59:59','LTCUSDT','4h','57.359999999999999','56.159999999999997','217.222241374099923','212.677843018993229','3.7869986292555775','3.786998629255578','test','test','2.1'),('2018-11-02 15:59:59','2018-11-02 23:59:59','LTCUSDT','4h','51.950000000000003','51.780000000000001','216.212375072965074','215.504846607856223','4.161932147699039','4.161932147699039','test','test','0.3'),('2018-11-04 07:59:59','2018-11-08 23:59:59','LTCUSDT','4h','51.859999999999999','52.719999999999999','216.055146525163110','219.638012433602000','4.166123149347534','4.166123149347534','test','test','0.0'),('2018-11-28 19:59:59','2018-11-28 23:59:59','LTCUSDT','4h','35.649999999999999','34.740000000000002','216.851338949260679','211.316003228536232','6.082786506290622','6.082786506290622','test','test','2.6'),('2018-12-16 11:59:59','2018-12-16 15:59:59','LTCUSDT','4h','26.230000000000000','26.079999999999998','215.621264344655202','214.388203359077664','8.220406570516783','8.220406570516783','test','test','0.6'),('2018-12-16 19:59:59','2018-12-16 23:59:59','LTCUSDT','4h','26.010000000000002','25.520000000000000','215.347250792304635','211.290343722399598','8.27940218347961','8.279402183479609','test','test','1.9'),('2018-12-17 07:59:59','2018-12-25 03:59:59','LTCUSDT','4h','27.350000000000001','29.870000000000001','214.445715887881306','234.204516766764726','7.840793999556903','7.840793999556903','test','test','0.0'),('2018-12-28 15:59:59','2018-12-29 23:59:59','LTCUSDT','4h','30.920000000000002','30.280000000000001','218.836560527633196','214.306955135081921','7.077508425861358','7.077508425861358','test','test','2.1'),('2018-12-30 03:59:59','2018-12-31 11:59:59','LTCUSDT','4h','30.510000000000002','30.219999999999999','217.829981551510656','215.759490084780452','7.139625747345482','7.139625747345482','test','test','1.0'),('2019-01-01 23:59:59','2019-01-03 19:59:59','LTCUSDT','4h','31.480000000000000','30.850000000000001','217.369872336681766','213.019712883946397','6.90501500434186','6.905015004341860','test','test','2.0'),('2019-01-04 07:59:59','2019-01-04 15:59:59','LTCUSDT','4h','32.060000000000002','31.090000000000000','216.403170236073919','209.855725596991192','6.749942926889392','6.749942926889392','test','test','3.0'),('2019-01-04 23:59:59','2019-01-10 07:59:59','LTCUSDT','4h','31.760000000000002','35.170000000000002','214.948182538499964','238.026687023899399','6.767889878416246','6.767889878416246','test','test','0.0'),('2019-01-23 11:59:59','2019-01-23 15:59:59','LTCUSDT','4h','32.020000000000003','31.559999999999999','220.076739090810946','216.915111983322703','6.873102407583102','6.873102407583102','test','test','1.4'),('2019-01-24 15:59:59','2019-01-27 15:59:59','LTCUSDT','4h','31.980000000000000','32.340000000000003','219.374155289146870','221.843657975328654','6.859729683838238','6.859729683838238','test','test','0.0'),('2019-01-31 03:59:59','2019-01-31 11:59:59','LTCUSDT','4h','32.020000000000003','31.370000000000001','219.922933663853968','215.458539320271655','6.868298990126607','6.868298990126607','test','test','2.0'),('2019-02-01 11:59:59','2019-02-06 03:59:59','LTCUSDT','4h','32.119999999999997','32.789999999999999','218.930846031946771','223.497585348304312','6.816028830384395','6.816028830384395','test','test','0.0'),('2019-02-06 07:59:59','2019-02-06 11:59:59','LTCUSDT','4h','33.009999999999998','32.450000000000003','219.945676991137333','216.214396193953576','6.663001423542482','6.663001423542482','test','test','1.7'),('2019-02-08 07:59:59','2019-02-24 15:59:59','LTCUSDT','4h','33.820000000000000','44.390000000000001','219.116503480652028','287.598509447254401','6.478903118883856','6.478903118883856','test','test','0.0'),('2019-02-28 15:59:59','2019-02-28 19:59:59','LTCUSDT','4h','46.009999999999998','45.859999999999999','234.334727028785892','233.570758129539712','5.093125994974699','5.093125994974699','test','test','0.3'),('2019-03-01 07:59:59','2019-03-04 07:59:59','LTCUSDT','4h','46.920000000000002','46.140000000000001','234.164956162286785','230.272188348847237','4.990727965948141','4.990727965948141','test','test','1.7'),('2019-03-05 15:59:59','2019-03-14 15:59:59','LTCUSDT','4h','52.140000000000001','55.939999999999998','233.299896648189105','250.302957777132690','4.474489770774628','4.474489770774628','test','test','0.8'),('2019-03-14 19:59:59','2019-03-20 11:59:59','LTCUSDT','4h','55.680000000000000','59.810000000000002','237.078354676843190','254.663369131142105','4.257872749224914','4.257872749224914','test','test','0.0'),('2019-03-20 15:59:59','2019-03-21 15:59:59','LTCUSDT','4h','60.020000000000003','58.460000000000001','240.986135666687431','234.722583989912465','4.015097228701889','4.015097228701889','test','test','2.6'),('2019-03-22 15:59:59','2019-03-25 15:59:59','LTCUSDT','4h','59.259999999999998','58.609999999999999','239.594235294070728','236.966218875894100','4.043102181810171','4.043102181810171','test','test','1.1'),('2019-03-25 19:59:59','2019-03-25 23:59:59','LTCUSDT','4h','58.890000000000001','59.039999999999999','239.010231645587083','239.619019805662447','4.058587733835746','4.058587733835746','test','test','0.0'),('2019-03-27 03:59:59','2019-03-30 19:59:59','LTCUSDT','4h','60.030000000000001','60.259999999999998','239.145517903381602','240.061784255501834','3.9837667483488524','3.983766748348852','test','test','0.0'),('2019-04-01 03:59:59','2019-04-01 15:59:59','LTCUSDT','4h','60.659999999999997','60.369999999999997','239.349132648297200','238.204865446384787','3.9457489721117245','3.945748972111724','test','test','0.5'),('2019-04-02 03:59:59','2019-04-11 11:59:59','LTCUSDT','4h','60.299999999999997','77.189999999999998','239.094851047872197','306.065199873718939','3.9650887404290582','3.965088740429058','test','test','0.0'),('2019-04-14 23:59:59','2019-04-15 11:59:59','LTCUSDT','4h','83.280000000000001','80.340000000000003','253.977150786949238','245.011098633807649','3.0496776031093806','3.049677603109381','test','test','3.5'),('2019-04-15 15:59:59','2019-04-15 19:59:59','LTCUSDT','4h','81.739999999999995','78.470399999999998','251.984694752917790','241.905306962801092','3.0827586830550255','3.082758683055026','test','test','4.0'),('2019-04-17 03:59:59','2019-04-17 07:59:59','LTCUSDT','4h','80.140000000000001','79.549999999999997','249.744830799558571','247.906180310767212','3.1163567606633213','3.116356760663321','test','test','0.7'),('2019-04-18 03:59:59','2019-04-18 11:59:59','LTCUSDT','4h','80.620000000000005','79.799999999999997','249.336241802049358','246.800199650254740','3.0927343314568265','3.092734331456827','test','test','1.0'),('2019-04-18 19:59:59','2019-04-19 03:59:59','LTCUSDT','4h','82.469999999999999','80.620000000000005','248.772676879428332','243.192108767060915','3.0165233039823978','3.016523303982398','test','test','2.2'),('2019-04-19 15:59:59','2019-04-20 11:59:59','LTCUSDT','4h','82.750000000000000','80.769999999999996','247.532550632235569','241.609717396563923','2.991329917005868','2.991329917005868','test','test','2.4'),('2019-05-02 11:59:59','2019-05-02 15:59:59','LTCUSDT','4h','73.700000000000003','73.909999999999997','246.216365468752997','246.917931774701941','3.340791933090271','3.340791933090271','test','test','0.0'),('2019-05-03 03:59:59','2019-05-04 15:59:59','LTCUSDT','4h','74.750000000000000','75.950000000000003','246.372269092297188','250.327409198126730','3.2959500881912667','3.295950088191267','test','test','0.0'),('2019-05-04 23:59:59','2019-05-06 03:59:59','LTCUSDT','4h','77.769999999999996','74.659199999999998','247.251189115814867','237.361141551182300','3.179261786239101','3.179261786239101','test','test','4.0'),('2019-05-06 19:59:59','2019-05-06 23:59:59','LTCUSDT','4h','76.010000000000005','74.939999999999998','245.053400768118735','241.603760736255964','3.2239626466006936','3.223962646600694','test','test','1.4'),('2019-05-07 03:59:59','2019-05-07 15:59:59','LTCUSDT','4h','77.650000000000006','74.709999999999994','244.286814094371465','235.037577346947700','3.145998893681538','3.145998893681538','test','test','3.8'),('2019-05-09 03:59:59','2019-05-09 07:59:59','LTCUSDT','4h','75.299999999999997','74.280000000000001','242.231428150499482','238.950205617783581','3.216884835996009','3.216884835996009','test','test','1.4'),('2019-05-10 07:59:59','2019-05-17 07:59:59','LTCUSDT','4h','77.000000000000000','88.000000000000000','241.502267587673742','276.002591528769983','3.1363930855542046','3.136393085554205','test','test','1.1'),('2019-05-19 03:59:59','2019-05-20 15:59:59','LTCUSDT','4h','91.599999999999994','90.250000000000000','249.169006241250685','245.496755603415664','2.720185657655575','2.720185657655575','test','test','1.5'),('2019-05-21 15:59:59','2019-05-22 23:59:59','LTCUSDT','4h','90.769999999999996','87.739999999999995','248.352950543954051','240.062662561711250','2.736068641004231','2.736068641004231','test','test','3.3'),('2019-05-24 07:59:59','2019-05-30 19:59:59','LTCUSDT','4h','94.090000000000003','113.379999999999995','246.510664325677823','297.049411427838777','2.619945417426696','2.619945417426696','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:54:33
