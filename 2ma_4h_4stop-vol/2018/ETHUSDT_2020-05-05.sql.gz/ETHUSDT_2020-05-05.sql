-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-01 03:59:59','2018-02-01 11:59:59','ETHUSDT','4h','1140.000000000000000','1116.000000000000000','222.222222222222200','217.543859649122794','0.1949317738791423','0.194931773879142','test','test','2.1'),('2018-02-14 15:59:59','2018-02-18 11:59:59','ETHUSDT','4h','903.059999999999945','929.179999999999950','221.182586094866792','227.580044900259480','0.24492568167659604','0.244925681676596','test','test','0.1'),('2018-02-20 11:59:59','2018-02-20 23:59:59','ETHUSDT','4h','936.519999999999982','899.059199999999919','222.604243607176272','213.700073862889212','0.2376929949250163','0.237692994925016','test','test','4.0'),('2018-02-27 11:59:59','2018-02-27 15:59:59','ETHUSDT','4h','885.169999999999959','873.070000000000050','220.625539219556941','217.609656367046540','0.24924651673639747','0.249246516736397','test','test','1.4'),('2018-02-28 07:59:59','2018-02-28 11:59:59','ETHUSDT','4h','874.029999999999973','864.529999999999973','219.955343030110157','217.564606146037477','0.25165651411291395','0.251656514112914','test','test','1.1'),('2018-03-05 07:59:59','2018-03-05 11:59:59','ETHUSDT','4h','867.799999999999955','869.139999999999986','219.424068166982920','219.762888461225572','0.2528509658527114','0.252850965852711','test','test','0.0'),('2018-04-09 07:59:59','2018-04-09 11:59:59','ETHUSDT','4h','418.810000000000002','402.057599999999979','219.499361565703538','210.719387103075377','0.5241024845770242','0.524102484577024','test','test','4.0'),('2018-04-10 23:59:59','2018-05-01 03:59:59','ETHUSDT','4h','416.069999999999993','641.860000000000014','217.548256129563924','335.605844399552780','0.5228645567562283','0.522864556756228','test','test','0.7'),('2018-05-01 15:59:59','2018-05-07 11:59:59','ETHUSDT','4h','649.279999999999973','733.000000000000000','243.783275745116981','275.217380977653363','0.37546709546746704','0.375467095467467','test','test','0.0'),('2018-05-07 15:59:59','2018-05-08 15:59:59','ETHUSDT','4h','729.840000000000032','737.470000000000027','250.768632463458431','253.390254552815236','0.34359398287769705','0.343593982877697','test','test','0.3'),('2018-05-10 19:59:59','2018-05-10 23:59:59','ETHUSDT','4h','737.600000000000023','722.519999999999982','251.351215149982153','246.212418614649010','0.3407690010167871','0.340769001016787','test','test','2.0'),('2018-05-13 15:59:59','2018-05-14 03:59:59','ETHUSDT','4h','727.009999999999991','697.929599999999937','250.209260364352559','240.200889949778457','0.34416206154571816','0.344162061545718','test','test','4.0'),('2018-05-14 15:59:59','2018-05-15 15:59:59','ETHUSDT','4h','733.250000000000000','717.980000000000018','247.985178050002759','242.820863465858849','0.33820003825435085','0.338200038254351','test','test','2.1'),('2018-05-19 15:59:59','2018-05-19 19:59:59','ETHUSDT','4h','706.919999999999959','703.659999999999968','246.837552586859630','245.699247797869134','0.3491732481565943','0.349173248156594','test','test','0.5'),('2018-05-20 11:59:59','2018-05-21 03:59:59','ETHUSDT','4h','712.500000000000000','712.720000000000027','246.584595967084027','246.660734368645819','0.3460836434625741','0.346083643462574','test','test','0.0'),('2018-05-21 11:59:59','2018-05-21 15:59:59','ETHUSDT','4h','709.519999999999982','701.000000000000000','246.601515611875556','243.640295472889790','0.347561049176733','0.347561049176733','test','test','1.2'),('2018-06-03 11:59:59','2018-06-04 11:59:59','ETHUSDT','4h','619.929999999999950','595.132799999999975','245.943466692100884','236.105728024416862','0.39672780264239654','0.396727802642397','test','test','4.0'),('2018-06-05 19:59:59','2018-06-06 19:59:59','ETHUSDT','4h','607.240000000000009','598.259999999999991','243.757302543726695','240.152565410397756','0.40141838901213145','0.401418389012131','test','test','1.5'),('2018-06-19 11:59:59','2018-06-20 03:59:59','ETHUSDT','4h','534.000000000000000','519.929999999999950','242.956249847431337','236.554762140777086','0.45497425065062047','0.454974250650620','test','test','2.6'),('2018-06-20 15:59:59','2018-06-21 15:59:59','ETHUSDT','4h','535.289999999999964','528.610000000000014','241.533697023730383','238.519545636410413','0.4512202675628732','0.451220267562873','test','test','1.2'),('2018-07-02 15:59:59','2018-07-03 23:59:59','ETHUSDT','4h','474.430000000000007','461.819999999999993','240.863885604325986','234.461900912231130','0.5076910937426512','0.507691093742651','test','test','2.7'),('2018-07-04 15:59:59','2018-07-04 23:59:59','ETHUSDT','4h','473.449999999999989','467.379999999999995','239.441222339416043','236.371398240566634','0.5057370838302166','0.505737083830217','test','test','1.3'),('2018-07-05 03:59:59','2018-07-05 19:59:59','ETHUSDT','4h','470.569999999999993','462.750000000000000','238.759039206338343','234.791307122708787','0.5073826193899703','0.507382619389970','test','test','1.7'),('2018-07-07 23:59:59','2018-07-09 23:59:59','ETHUSDT','4h','485.569999999999993','471.709999999999980','237.877320965531794','231.087404643307849','0.48989295254140863','0.489892952541409','test','test','2.9'),('2018-07-15 15:59:59','2018-07-15 19:59:59','ETHUSDT','4h','452.959999999999980','450.189999999999998','236.368450671704210','234.922979529968472','0.5218307370887147','0.521830737088715','test','test','0.6'),('2018-07-16 07:59:59','2018-07-19 19:59:59','ETHUSDT','4h','452.819999999999993','467.850000000000023','236.047234862429633','243.882113931336335','0.521282705848747','0.521282705848747','test','test','0.0'),('2018-07-23 15:59:59','2018-07-23 19:59:59','ETHUSDT','4h','463.490000000000009','451.269999999999982','237.788319099964468','231.518985868607643','0.5130387259702787','0.513038725970279','test','test','2.6'),('2018-07-24 07:59:59','2018-07-25 15:59:59','ETHUSDT','4h','472.329999999999984','467.800000000000011','236.395133937440733','234.127926779867437','0.5004872312523887','0.500487231252389','test','test','1.0'),('2018-07-25 19:59:59','2018-07-26 23:59:59','ETHUSDT','4h','474.230000000000018','462.639999999999986','235.891310124646651','230.126216637636844','0.4974196278696975','0.497419627869698','test','test','2.4'),('2018-07-27 19:59:59','2018-07-27 23:59:59','ETHUSDT','4h','467.360000000000014','470.089999999999975','234.610178238644494','235.980611708756385','0.5019902820922725','0.501990282092272','test','test','0.0'),('2018-08-28 15:59:59','2018-08-28 19:59:59','ETHUSDT','4h','288.589999999999975','293.139999999999986','234.914719009780441','238.618457779296023','0.8140085207726548','0.814008520772655','test','test','0.0'),('2018-08-28 23:59:59','2018-08-29 15:59:59','ETHUSDT','4h','295.439999999999998','286.509999999999991','235.737772069672815','228.612337786629951','0.7979209723452234','0.797920972345223','test','test','3.0'),('2018-09-01 15:59:59','2018-09-03 07:59:59','ETHUSDT','4h','295.540000000000020','289.870000000000005','234.154342228996626','229.662039595043808','0.7922932335013758','0.792293233501376','test','test','1.9'),('2018-09-03 15:59:59','2018-09-03 19:59:59','ETHUSDT','4h','289.689999999999998','292.540000000000020','233.156052754784895','235.449865970122488','0.8048467422237043','0.804846742223704','test','test','0.0'),('2018-09-03 23:59:59','2018-09-04 03:59:59','ETHUSDT','4h','289.089999999999975','288.310000000000002','233.665789024859919','233.035330290765387','0.8082804283263342','0.808280428326334','test','test','0.3'),('2018-09-04 11:59:59','2018-09-04 15:59:59','ETHUSDT','4h','288.769999999999982','289.329999999999984','233.525687083949975','233.978554018766630','0.8086909550297815','0.808690955029781','test','test','0.0'),('2018-09-15 15:59:59','2018-09-16 03:59:59','ETHUSDT','4h','224.039999999999992','215.078399999999988','233.626324180575921','224.281271213352881','1.0427884492973394','1.042788449297339','test','test','4.0'),('2018-09-17 07:59:59','2018-09-17 11:59:59','ETHUSDT','4h','218.270000000000010','219.139999999999986','231.549645743415255','232.472576937792695','1.0608404533074414','1.060840453307441','test','test','0.0'),('2018-09-20 23:59:59','2018-09-24 23:59:59','ETHUSDT','4h','224.000000000000000','228.060000000000002','231.754741564388013','235.955296255242530','1.0346193819838752','1.034619381983875','test','test','0.6'),('2018-09-27 19:59:59','2018-09-28 11:59:59','ETHUSDT','4h','228.599999999999994','223.930000000000007','232.688198162355690','227.934681603220980','1.017883631506368','1.017883631506368','test','test','2.0'),('2018-09-29 11:59:59','2018-10-01 15:59:59','ETHUSDT','4h','232.389999999999986','227.699999999999989','231.631861149214615','226.957161597642624','0.9967376442584217','0.996737644258422','test','test','2.0'),('2018-10-01 19:59:59','2018-10-02 15:59:59','ETHUSDT','4h','229.860000000000014','227.750000000000000','230.593039026643055','228.476310094483381','1.003189067374241','1.003189067374241','test','test','0.9'),('2018-10-02 19:59:59','2018-10-02 23:59:59','ETHUSDT','4h','226.509999999999991','225.689999999999998','230.122654819496489','229.289576469966732','1.0159492067436162','1.015949206743616','test','test','0.4'),('2018-10-05 23:59:59','2018-10-06 11:59:59','ETHUSDT','4h','228.370000000000005','225.270000000000010','229.937526297378753','226.816247970444948','1.0068639764302612','1.006863976430261','test','test','1.4'),('2018-10-07 23:59:59','2018-10-08 07:59:59','ETHUSDT','4h','226.139999999999986','224.979999999999990','229.243908891393431','228.067987186635236','1.013725607550161','1.013725607550161','test','test','0.5'),('2018-10-08 11:59:59','2018-10-10 03:59:59','ETHUSDT','4h','226.330000000000013','226.500000000000000','228.982592957002765','229.154585361026506','1.0117200236689912','1.011720023668991','test','test','0.0'),('2018-10-10 07:59:59','2018-10-10 11:59:59','ETHUSDT','4h','226.000000000000000','226.340000000000003','229.020813491230257','229.365358077898463','1.0133664313771251','1.013366431377125','test','test','0.0'),('2018-10-15 11:59:59','2018-10-15 19:59:59','ETHUSDT','4h','221.750000000000000','212.879999999999995','229.097378954934328','219.933483796736937','1.0331336142274379','1.033133614227438','test','test','4.0'),('2018-11-04 15:59:59','2018-11-09 23:59:59','ETHUSDT','4h','205.840000000000003','210.770000000000010','227.060957808668235','232.499213356650813','1.1030944316394686','1.103094431639469','test','test','0.0'),('2018-11-10 15:59:59','2018-11-10 23:59:59','ETHUSDT','4h','213.969999999999999','213.250000000000000','228.269459041553233','227.501341966683299','1.0668292706526767','1.066829270652677','test','test','0.3'),('2018-11-11 15:59:59','2018-11-11 19:59:59','ETHUSDT','4h','210.400000000000006','211.379999999999995','228.098766358248810','229.161203577978284','1.0841196119688632','1.084119611968863','test','test','0.0'),('2018-11-12 11:59:59','2018-11-13 03:59:59','ETHUSDT','4h','212.509999999999991','211.699999999999989','228.334863518188712','227.464545700440198','1.0744664416648098','1.074466441664810','test','test','0.4'),('2018-11-13 11:59:59','2018-11-13 15:59:59','ETHUSDT','4h','211.490000000000009','212.189999999999998','228.141459558689036','228.896573378212793','1.0787340278911013','1.078734027891101','test','test','0.0'),('2018-12-17 19:59:59','2018-12-18 11:59:59','ETHUSDT','4h','95.409999999999997','93.390000000000001','228.309262629694302','223.475548024181450','2.392928022531122','2.392928022531122','test','test','2.1'),('2018-12-18 15:59:59','2018-12-27 19:59:59','ETHUSDT','4h','93.819999999999993','114.099999999999994','227.235103828469192','276.353926101346588','2.4220326564535197','2.422032656453520','test','test','0.1'),('2018-12-28 15:59:59','2019-01-10 07:59:59','ETHUSDT','4h','126.620000000000005','135.449999999999989','238.150397666886420','254.758105859893874','1.8808276549272342','1.880827654927234','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:14:33
