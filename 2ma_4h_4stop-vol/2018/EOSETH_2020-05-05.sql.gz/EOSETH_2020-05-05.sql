-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-01-11 19:59:59','2018-01-14 23:59:59','EOSETH','4h','0.010079000000000','0.009795000000000','1.297777777777778','1.261209776102127','128.76056928046214','128.760569280462136','test','test','3.8'),('2018-01-16 15:59:59','2018-01-16 19:59:59','EOSETH','4h','0.010560000000000','0.010137600000000','1.289651555183189','1.238065492975861','122.12609424083226','122.126094240832259','test','test','4.0'),('2018-01-18 03:59:59','2018-01-18 19:59:59','EOSETH','4h','0.010295000000000','0.010225000000000','1.278187985803782','1.269497052437462','124.15619094742907','124.156190947429067','test','test','0.7'),('2018-01-19 15:59:59','2018-01-28 07:59:59','EOSETH','4h','0.010424000000000','0.012165000000000','1.276256667277934','1.489415038127021','122.43444620855082','122.434446208550824','test','test','0.0'),('2018-02-28 03:59:59','2018-02-28 07:59:59','EOSETH','4h','0.009848000000000','0.009958000000000','1.323625194133286','1.338409797235912','134.40548275114605','134.405482751146053','test','test','0.0'),('2018-02-28 15:59:59','2018-02-28 19:59:59','EOSETH','4h','0.009791000000000','0.009638000000000','1.326910661489425','1.306175564848849','135.52350745474675','135.523507454746749','test','test','1.6'),('2018-03-01 23:59:59','2018-03-02 03:59:59','EOSETH','4h','0.009811000000000','0.009694000000000','1.322302862235964','1.306533885079547','134.77758253347915','134.777582533479148','test','test','1.2'),('2018-03-19 03:59:59','2018-03-19 07:59:59','EOSETH','4h','0.008596000000000','0.008617000000000','1.318798645090094','1.322020465884288','153.42003781876383','153.420037818763831','test','test','0.0'),('2018-03-19 11:59:59','2018-04-09 03:59:59','EOSETH','4h','0.008896000000000','0.014617000000000','1.319514605266581','2.168091837363041','148.32673170712465','148.326731707124651','test','test','0.0'),('2018-04-10 11:59:59','2018-04-10 23:59:59','EOSETH','4h','0.015077000000000','0.014473920000000','1.508087323510239','1.447763830569829','100.02568969358883','100.025689693588831','test','test','4.0'),('2018-04-11 07:59:59','2018-04-15 03:59:59','EOSETH','4h','0.015150000000000','0.015906000000000','1.494682102856814','1.569268219672639','98.65888467701745','98.658884677017454','test','test','0.0'),('2018-04-17 03:59:59','2018-04-19 19:59:59','EOSETH','4h','0.017344000000000','0.016650240000000','1.511256795482553','1.450806523663251','87.13427095725055','87.134270957250550','test','test','4.0'),('2018-04-20 03:59:59','2018-05-03 07:59:59','EOSETH','4h','0.016963000000000','0.024492000000000','1.497823401744931','2.162629885959845','88.29944006042156','88.299440060421560','test','test','0.0'),('2018-05-07 11:59:59','2018-05-07 19:59:59','EOSETH','4h','0.024099000000000','0.023620000000000','1.645558176014911','1.612850496596215','68.28325557138933','68.283255571389333','test','test','2.0'),('2018-05-08 03:59:59','2018-05-09 19:59:59','EOSETH','4h','0.023940000000000','0.023489000000000','1.638289802810757','1.607426448547280','68.43315801214523','68.433158012145228','test','test','1.9'),('2018-05-10 15:59:59','2018-05-11 07:59:59','EOSETH','4h','0.024220000000000','0.023251200000000','1.631431279641095','1.566174028455451','67.35884721887264','67.358847218872640','test','test','4.0'),('2018-05-24 15:59:59','2018-05-29 07:59:59','EOSETH','4h','0.020631000000000','0.021338000000000','1.616929668266508','1.672339938028731','78.3737903284624','78.373790328462405','test','test','2.4'),('2018-05-29 15:59:59','2018-06-01 07:59:59','EOSETH','4h','0.021309000000000','0.020988000000000','1.629243061547002','1.604700050483292','76.45797839161865','76.457978391618653','test','test','1.5'),('2018-06-01 19:59:59','2018-06-01 23:59:59','EOSETH','4h','0.020940000000000','0.021072000000000','1.623789059088399','1.634024978658584','77.54484522867237','77.544845228672372','test','test','0.0'),('2018-06-02 11:59:59','2018-06-05 03:59:59','EOSETH','4h','0.023539000000000','0.022597440000000','1.626063707881774','1.561021159566503','69.07955766522682','69.079557665226815','test','test','4.0'),('2018-06-05 11:59:59','2018-06-10 19:59:59','EOSETH','4h','0.023268000000000','0.023009000000000','1.611609808256158','1.593670709909143','69.26292798075289','69.262927980752892','test','test','2.6'),('2018-07-02 15:59:59','2018-07-06 07:59:59','EOSETH','4h','0.018815000000000','0.018354000000000','1.607623341956822','1.568233793158411','85.44370672106413','85.443706721064132','test','test','2.5'),('2018-07-16 23:59:59','2018-07-17 03:59:59','EOSETH','4h','0.016891000000000','0.016862000000000','1.598870108890508','1.596125023747069','94.6581083944413','94.658108394441300','test','test','0.2'),('2018-07-17 15:59:59','2018-07-21 03:59:59','EOSETH','4h','0.017077000000000','0.017092000000000','1.598260089969744','1.599663960752056','93.5913854874828','93.591385487482796','test','test','0.0'),('2018-07-22 11:59:59','2018-07-22 23:59:59','EOSETH','4h','0.017527000000000','0.017133000000000','1.598572061254702','1.562636796113243','91.20625670421074','91.206256704210745','test','test','2.2'),('2018-07-23 03:59:59','2018-07-23 19:59:59','EOSETH','4h','0.017408000000000','0.017470000000000','1.590586446778822','1.596251449059399','91.37100452543785','91.371004525437854','test','test','0.2'),('2018-07-24 15:59:59','2018-07-27 03:59:59','EOSETH','4h','0.017750000000000','0.017617000000000','1.591845336174506','1.579917706331621','89.68142739011302','89.681427390113015','test','test','0.7'),('2018-07-30 03:59:59','2018-07-30 07:59:59','EOSETH','4h','0.017664000000000','0.017631000000000','1.589194751764976','1.586225807765415','89.96799998669474','89.967999986694736','test','test','0.2'),('2018-07-30 11:59:59','2018-07-30 15:59:59','EOSETH','4h','0.017677000000000','0.017330000000000','1.588534986431740','1.557352000614474','89.86451244168921','89.864512441689214','test','test','2.0'),('2018-08-07 15:59:59','2018-08-07 23:59:59','EOSETH','4h','0.017403000000000','0.017355000000000','1.581605434027903','1.577243136674956','90.88119485306576','90.881194853065765','test','test','0.3'),('2018-08-15 03:59:59','2018-08-15 07:59:59','EOSETH','4h','0.016567000000000','0.016491000000000','1.580636034616137','1.573384972949521','95.40870613968356','95.408706139683559','test','test','0.5'),('2018-08-17 15:59:59','2018-08-22 23:59:59','EOSETH','4h','0.016541000000000','0.017455000000000','1.579024687579111','1.666276278441048','95.46125914872809','95.461259148728089','test','test','0.0'),('2018-08-23 07:59:59','2018-09-14 07:59:59','EOSETH','4h','0.017404000000000','0.025149000000000','1.598413929992875','2.309728334026133','91.84175649235092','91.841756492350925','test','test','0.0'),('2018-09-17 19:59:59','2018-09-17 23:59:59','EOSETH','4h','0.024909000000000','0.024741000000000','1.756483797555822','1.744637104473427','70.51603025235143','70.516030252351428','test','test','0.7'),('2018-09-18 11:59:59','2018-09-18 15:59:59','EOSETH','4h','0.024630000000000','0.024122000000000','1.753851199093067','1.717677573062240','71.2079252575342','71.207925257534200','test','test','2.1'),('2018-09-19 19:59:59','2018-09-21 19:59:59','EOSETH','4h','0.025091000000000','0.024698000000000','1.745812615530661','1.718467975703490','69.57923620145316','69.579236201453156','test','test','1.6'),('2018-09-21 23:59:59','2018-09-22 03:59:59','EOSETH','4h','0.024940000000000','0.024677000000000','1.739736028902401','1.721389975349822','69.75685761437052','69.756857614370517','test','test','1.1'),('2018-09-25 11:59:59','2018-09-25 15:59:59','EOSETH','4h','0.024872000000000','0.024567000000000','1.735659128112939','1.714375112590486','69.78365745066498','69.783657450664975','test','test','1.2'),('2018-09-25 19:59:59','2018-09-25 23:59:59','EOSETH','4h','0.025690000000000','0.024683000000000','1.730929346885727','1.663080150610370','67.37755340154641','67.377553401546407','test','test','3.9'),('2018-09-26 03:59:59','2018-09-29 11:59:59','EOSETH','4h','0.025288000000000','0.024723000000000','1.715851747713426','1.677515135982246','67.85241014368182','67.852410143681823','test','test','2.2'),('2018-10-03 23:59:59','2018-10-07 19:59:59','EOSETH','4h','0.025460000000000','0.025340000000000','1.707332500662052','1.699285371829395','67.05940693880802','67.059406938808024','test','test','0.9'),('2018-10-07 23:59:59','2018-10-14 23:59:59','EOSETH','4h','0.025507000000000','0.026467000000000','1.705544249810351','1.769735353421828','66.8657329286216','66.865732928621597','test','test','0.0'),('2018-10-15 19:59:59','2018-10-16 07:59:59','EOSETH','4h','0.026383000000000','0.026017000000000','1.719808939501790','1.695950770534741','65.18625400833074','65.186254008330735','test','test','1.4'),('2018-10-17 11:59:59','2018-10-26 11:59:59','EOSETH','4h','0.025990000000000','0.026482000000000','1.714507124175779','1.746963357538398','65.96795398906423','65.967953989064227','test','test','0.0'),('2018-10-26 23:59:59','2018-10-28 15:59:59','EOSETH','4h','0.026561000000000','0.026455000000000','1.721719620478583','1.714848558403709','64.82134032900053','64.821340329000535','test','test','0.4'),('2018-10-31 15:59:59','2018-10-31 19:59:59','EOSETH','4h','0.026463000000000','0.026508000000000','1.720192717795278','1.723117883963165','65.00369261970593','65.003692619705930','test','test','0.0'),('2018-11-01 23:59:59','2018-11-03 23:59:59','EOSETH','4h','0.026416000000000','0.026584000000000','1.720842754721475','1.731786939412314','65.14395649309037','65.143956493090371','test','test','0.0'),('2018-11-04 07:59:59','2018-11-04 19:59:59','EOSETH','4h','0.026824000000000','0.025901000000000','1.723274795763884','1.663977799175379','64.24376661809886','64.243766618098860','test','test','3.4'),('2018-11-06 07:59:59','2018-11-06 11:59:59','EOSETH','4h','0.026514000000000','0.026543000000000','1.710097685410883','1.711968124909899','64.49791375917941','64.497913759179411','test','test','0.0'),('2018-11-19 03:59:59','2018-11-27 11:59:59','EOSETH','4h','0.026028000000000','0.028041000000000','1.710513338632886','1.842804077478283','65.71820111544822','65.718201115448224','test','test','0.0'),('2018-12-15 23:59:59','2018-12-20 19:59:59','EOSETH','4h','0.022515000000000','0.023718000000000','1.739911280598530','1.832876560214787','77.27787166771175','77.277871667711750','test','test','1.9'),('2019-01-09 23:59:59','2019-01-10 19:59:59','EOSETH','4h','0.019325000000000','0.018863000000000','1.760570231624365','1.718480531908430','91.10324613838887','91.103246138388869','test','test','2.4');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:12:37
