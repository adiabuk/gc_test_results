-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-30 07:59:59','2018-05-30 15:59:59','LENDETH','4h','0.000081700000000','0.000078810000000','1.297777777777778','1.251871073031416','15884.672922616619','15884.672922616618962','test','test','3.5'),('2018-06-01 19:59:59','2018-06-02 03:59:59','LENDETH','4h','0.000080600000000','0.000080630000000','1.287576287834142','1.288055534591401','15974.89190861218','15974.891908612180487','test','test','0.2'),('2018-06-02 15:59:59','2018-06-03 11:59:59','LENDETH','4h','0.000080830000000','0.000079600000000','1.287682787113533','1.268087960586876','15930.753273704473','15930.753273704473031','test','test','1.5'),('2018-06-09 07:59:59','2018-06-09 11:59:59','LENDETH','4h','0.000077580000000','0.000077610000000','1.283328381218720','1.283824641226925','16542.00027350761','16542.000273507608654','test','test','0.0'),('2018-06-09 15:59:59','2018-06-09 19:59:59','LENDETH','4h','0.000076500000000','0.000077810000000','1.283438661220543','1.305416499732947','16776.97596366723','16776.975963667231554','test','test','0.0'),('2018-06-28 11:59:59','2018-06-28 19:59:59','LENDETH','4h','0.000059100000000','0.000057400000000','1.288322625334411','1.251264275705503','21799.02919347565','21799.029193475649663','test','test','2.9'),('2018-06-30 19:59:59','2018-07-07 11:59:59','LENDETH','4h','0.000061610000000','0.000064910000000','1.280087436527987','1.348652418520234','20777.26727037797','20777.267270377971727','test','test','2.1'),('2018-07-07 19:59:59','2018-07-07 23:59:59','LENDETH','4h','0.000065610000000','0.000065960000000','1.295324099192931','1.302234073811396','19742.784624187327','19742.784624187326699','test','test','0.0'),('2018-07-17 19:59:59','2018-07-20 03:59:59','LENDETH','4h','0.000061040000000','0.000061200000000','1.296859649108145','1.300259019092701','21246.062403475513','21246.062403475512838','test','test','0.0'),('2018-07-30 15:59:59','2018-07-31 11:59:59','LENDETH','4h','0.000059700000000','0.000058380000000','1.297615064660269','1.268924078305972','21735.595722952574','21735.595722952573851','test','test','2.2'),('2018-08-17 11:59:59','2018-08-17 15:59:59','LENDETH','4h','0.000048690000000','0.000047990000000','1.291239289914869','1.272675570404900','26519.599299956237','26519.599299956236791','test','test','1.4'),('2018-08-17 19:59:59','2018-08-17 23:59:59','LENDETH','4h','0.000047570000000','0.000047920000000','1.287114018912654','1.296584061095110','27057.263378445532','27057.263378445531998','test','test','0.0'),('2018-08-18 03:59:59','2018-08-18 07:59:59','LENDETH','4h','0.000047600000000','0.000046020000000','1.289218472730977','1.246425086451251','27084.421696028938','27084.421696028937731','test','test','3.3'),('2018-08-26 11:59:59','2018-08-30 11:59:59','LENDETH','4h','0.000047950000000','0.000048010000000','1.279708831335483','1.281310135399719','26688.401070604436','26688.401070604435517','test','test','0.7'),('2018-08-31 07:59:59','2018-09-12 11:59:59','LENDETH','4h','0.000051430000000','0.000057810000000','1.280064676683091','1.438859400331509','24889.45511730684','24889.455117306839384','test','test','2.8'),('2018-09-16 15:59:59','2018-09-21 19:59:59','LENDETH','4h','0.000056340000000','0.000058450000000','1.315352393049406','1.364613904397192','23346.687842552466','23346.687842552466464','test','test','0.0'),('2018-09-24 23:59:59','2018-09-25 03:59:59','LENDETH','4h','0.000059520000000','0.000059960000000','1.326299395571136','1.336104028199686','22283.255973977422','22283.255973977422400','test','test','0.0'),('2018-09-25 07:59:59','2018-09-25 11:59:59','LENDETH','4h','0.000059360000000','0.000064640000000','1.328478202821925','1.446644727601234','22380.02363244483','22380.023632444830582','test','test','0.0'),('2018-09-25 15:59:59','2018-09-26 19:59:59','LENDETH','4h','0.000062130000000','0.000060790000000','1.354737430550660','1.325518886257438','21804.883800911964','21804.883800911964499','test','test','2.2'),('2018-09-27 15:59:59','2018-10-01 03:59:59','LENDETH','4h','0.000062950000000','0.000063730000000','1.348244420707722','1.364950229256602','21417.70326779543','21417.703267795430293','test','test','1.8'),('2018-10-02 03:59:59','2018-10-02 07:59:59','LENDETH','4h','0.000062840000000','0.000062060000000','1.351956822607473','1.335175690818265','21514.271524625612','21514.271524625612074','test','test','1.2'),('2018-10-02 15:59:59','2018-10-11 23:59:59','LENDETH','4h','0.000064770000000','0.000073780000000','1.348227682209872','1.535776414905733','20815.619611083395','20815.619611083395284','test','test','1.3'),('2018-10-12 07:59:59','2018-10-13 11:59:59','LENDETH','4h','0.000074550000000','0.000073610000000','1.389905178364508','1.372379881682246','18643.932640704326','18643.932640704326332','test','test','1.3'),('2018-10-13 15:59:59','2018-10-15 07:59:59','LENDETH','4h','0.000075280000000','0.000073000000000','1.386010667990671','1.344032661574375','18411.406322936655','18411.406322936654760','test','test','3.0'),('2018-10-15 15:59:59','2018-10-15 19:59:59','LENDETH','4h','0.000075400000000','0.000072384000000','1.376682222120383','1.321614933235568','18258.3849087584','18258.384908758398524','test','test','4.0'),('2018-10-17 19:59:59','2018-10-26 11:59:59','LENDETH','4h','0.000075080000000','0.000090340000000','1.364445046812647','1.641768320845159','18173.215860583998','18173.215860583997710','test','test','0.0'),('2018-10-27 07:59:59','2018-11-04 07:59:59','LENDETH','4h','0.000099100000000','0.000102640000000','1.426072441042094','1.477013878391126','14390.236539274407','14390.236539274406823','test','test','0.0'),('2018-11-28 19:59:59','2018-11-30 11:59:59','LENDETH','4h','0.000076150000000','0.000073104000000','1.437392760452990','1.379897050034870','18875.807753814704','18875.807753814704483','test','test','4.0'),('2018-12-01 15:59:59','2018-12-06 03:59:59','LENDETH','4h','0.000081950000000','0.000078910000000','1.424615935915630','1.371768682161103','17383.965050831357','17383.965050831357075','test','test','3.7'),('2018-12-06 07:59:59','2018-12-06 11:59:59','LENDETH','4h','0.000079820000000','0.000078260000000','1.412872101747957','1.385258966208909','17700.727909646168','17700.727909646167973','test','test','2.0'),('2018-12-12 19:59:59','2018-12-13 11:59:59','LENDETH','4h','0.000078200000000','0.000076640000000','1.406735849405947','1.378673088215752','17988.949480894455','17988.949480894454609','test','test','2.0'),('2018-12-13 19:59:59','2018-12-13 23:59:59','LENDETH','4h','0.000078380000000','0.000077050000000','1.400499680252570','1.376735141151576','17868.07451202564','17868.074512025639706','test','test','1.7'),('2018-12-14 11:59:59','2018-12-14 15:59:59','LENDETH','4h','0.000076590000000','0.000077700000000','1.395218671563460','1.415439232020901','18216.721132830135','18216.721132830134593','test','test','0.0'),('2018-12-14 23:59:59','2018-12-19 15:59:59','LENDETH','4h','0.000078520000000','0.000080500000000','1.399712129442891','1.435007977841986','17826.186060148895','17826.186060148895194','test','test','0.0'),('2018-12-20 11:59:59','2018-12-20 19:59:59','LENDETH','4h','0.000081650000000','0.000080210000000','1.407555651309357','1.382731644721660','17238.89346367859','17238.893463678588887','test','test','1.8'),('2019-01-11 11:59:59','2019-01-11 15:59:59','LENDETH','4h','0.000056430000000','0.000056130000000','1.402039205400980','1.394585514782155','24845.635396083286','24845.635396083285741','test','test','0.5'),('2019-01-12 19:59:59','2019-01-27 19:59:59','LENDETH','4h','0.000057470000000','0.000071400000000','1.400382829707908','1.739817888309459','24367.197315258527','24367.197315258526942','test','test','0.0'),('2019-01-28 15:59:59','2019-01-28 19:59:59','LENDETH','4h','0.000070110000000','0.000069690000000','1.475812842730474','1.466971858649076','21049.96209856617','21049.962098566171335','test','test','0.6'),('2019-01-29 11:59:59','2019-01-30 15:59:59','LENDETH','4h','0.000070100000000','0.000070520000000','1.473848179601275','1.482678653715862','21024.938368063835','21024.938368063834787','test','test','0.0'),('2019-02-01 19:59:59','2019-02-02 07:59:59','LENDETH','4h','0.000072100000000','0.000070330000000','1.475810507182294','1.439580485022618','20468.939073263446','20468.939073263445607','test','test','2.5'),('2019-02-02 19:59:59','2019-02-03 03:59:59','LENDETH','4h','0.000073720000000','0.000070771200000','1.467759391146811','1.409049015500939','19909.921203836282','19909.921203836282075','test','test','4.0'),('2019-02-26 23:59:59','2019-02-27 03:59:59','LENDETH','4h','0.000056590000000','0.000056600000000','1.454712641003283','1.454969702788228','25706.178494491665','25706.178494491665333','test','test','0.0'),('2019-02-28 07:59:59','2019-02-28 11:59:59','LENDETH','4h','0.000057260000000','0.000056060000000','1.454769765844383','1.424282100475657','25406.38780727179','25406.387807271788915','test','test','2.1'),('2019-03-01 19:59:59','2019-03-06 15:59:59','LENDETH','4h','0.000057900000000','0.000061610000000','1.447994729095777','1.540776429353900','25008.544543968514','25008.544543968513608','test','test','1.6'),('2019-03-08 07:59:59','2019-03-16 23:59:59','LENDETH','4h','0.000063930000000','0.000066770000000','1.468612884708693','1.533853938870630','22972.202169696433','22972.202169696432975','test','test','0.7'),('2019-03-26 19:59:59','2019-04-02 07:59:59','LENDETH','4h','0.000065560000000','0.000071990000000','1.483110896744679','1.628571590247856','22622.19183564184','22622.191835641839134','test','test','0.0'),('2019-04-02 11:59:59','2019-04-02 15:59:59','LENDETH','4h','0.000070410000000','0.000069380000000','1.515435495300941','1.493266789717076','21523.01512996649','21523.015129966490349','test','test','1.5'),('2019-04-04 15:59:59','2019-04-05 07:59:59','LENDETH','4h','0.000070120000000','0.000068740000000','1.510509116282304','1.480781469669789','21541.77290761985','21541.772907619848411','test','test','2.0'),('2019-04-05 15:59:59','2019-04-06 15:59:59','LENDETH','4h','0.000072970000000','0.000070051200000','1.503902972590634','1.443746853687009','20609.88039729524','20609.880397295240982','test','test','4.0'),('2019-04-07 23:59:59','2019-04-08 03:59:59','LENDETH','4h','0.000070280000000','0.000067468800000','1.490534946167606','1.430913548320902','21208.522284684204','21208.522284684204351','test','test','4.0'),('2019-04-14 15:59:59','2019-04-15 11:59:59','LENDETH','4h','0.000066910000000','0.000066740000000','1.477285746646116','1.473532367824866','22078.698948529607','22078.698948529607151','test','test','0.4'),('2019-04-18 23:59:59','2019-04-19 03:59:59','LENDETH','4h','0.000066800000000','0.000065300000000','1.476451662463616','1.443297807767577','22102.569797359523','22102.569797359523363','test','test','2.2'),('2019-04-19 07:59:59','2019-04-19 15:59:59','LENDETH','4h','0.000067210000000','0.000065620000000','1.469084139197830','1.434329730905544','21858.11842282145','21858.118422821451531','test','test','2.4'),('2019-05-20 15:59:59','2019-05-20 19:59:59','LENDETH','4h','0.000039490000000','0.000037910400000','1.461360937355100','1.402906499860896','37005.847995824246','37005.847995824246027','test','test','4.0'),('2019-05-22 19:59:59','2019-05-22 23:59:59','LENDETH','4h','0.000041190000000','0.000039542400000','1.448371062356387','1.390436219862131','35163.17218636532','35163.172186365321977','test','test','4.0'),('2019-05-24 11:59:59','2019-05-24 15:59:59','LENDETH','4h','0.000039260000000','0.000038310000000','1.435496652913219','1.400760997786689','36563.847501610275','36563.847501610274776','test','test','2.4'),('2019-05-26 11:59:59','2019-05-26 15:59:59','LENDETH','4h','0.000038600000000','0.000038980000000','1.427777618440657','1.441833460280228','36989.05747255589','36989.057472555890854','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:47:01
