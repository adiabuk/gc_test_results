-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-30 19:59:59','2018-05-01 03:59:59','BATBTC','4h','0.000054290000000','0.000052118400000','0.033333333333333','0.032000000000000','613.986615091791','613.986615091791009','test','test','4.0'),('2018-05-01 15:59:59','2018-05-03 19:59:59','BATBTC','4h','0.000054840000000','0.000052646400000','0.033037037037037','0.031715555555556','602.4259124186198','602.425912418619760','test','test','4.0'),('2018-05-14 03:59:59','2018-05-15 15:59:59','BATBTC','4h','0.000044140000000','0.000044400000000','0.032743374485597','0.032936244385150','741.8073059718371','741.807305971837081','test','test','0.0'),('2018-05-16 07:59:59','2018-05-17 19:59:59','BATBTC','4h','0.000045470000000','0.000044860000000','0.032786234463275','0.032346392742963','721.0520005118833','721.052000511883307','test','test','1.3'),('2018-06-03 11:59:59','2018-06-03 23:59:59','BATBTC','4h','0.000040250000000','0.000039330000000','0.032688491858762','0.031941326330562','812.1364436959392','812.136443695939192','test','test','2.3'),('2018-06-15 11:59:59','2018-06-20 03:59:59','BATBTC','4h','0.000035160000000','0.000037380000000','0.032522455074717','0.034575920668172','924.9845015562316','924.984501556231635','test','test','0.0'),('2018-06-20 15:59:59','2018-06-25 15:59:59','BATBTC','4h','0.000037900000000','0.000041520000000','0.032978780762152','0.036128732908827','870.1525267058458','870.152526705845844','test','test','0.0'),('2018-06-25 23:59:59','2018-06-26 15:59:59','BATBTC','4h','0.000040250000000','0.000038670000000','0.033678770128079','0.032356721511871','836.7396305112876','836.739630511287601','test','test','3.9'),('2018-07-01 15:59:59','2018-07-03 23:59:59','BATBTC','4h','0.000039670000000','0.000038870000000','0.033384981546700','0.032711727570462','841.5674702974484','841.567470297448381','test','test','2.0'),('2018-07-04 15:59:59','2018-07-04 19:59:59','BATBTC','4h','0.000039790000000','0.000038920000000','0.033235369551980','0.032508685171225','835.2694031661277','835.269403166127745','test','test','2.2'),('2018-07-06 23:59:59','2018-07-07 03:59:59','BATBTC','4h','0.000040460000000','0.000039450000000','0.033073884134035','0.032248263200388','817.4464689578514','817.446468957851380','test','test','2.5'),('2018-07-07 15:59:59','2018-07-08 07:59:59','BATBTC','4h','0.000040080000000','0.000039560000000','0.032890412815446','0.032463690892691','820.6190822217177','820.619082221717690','test','test','1.3'),('2018-07-08 15:59:59','2018-07-09 23:59:59','BATBTC','4h','0.000041430000000','0.000039772800000','0.032795585721501','0.031483762292641','791.5902901641537','791.590290164153657','test','test','4.0'),('2018-07-11 03:59:59','2018-07-19 03:59:59','BATBTC','4h','0.000040170000000','0.000047730000000','0.032504069403976','0.038621340120781','809.1627932281913','809.162793228191276','test','test','0.0'),('2018-07-23 11:59:59','2018-07-23 15:59:59','BATBTC','4h','0.000050000000000','0.000048000000000','0.033863462896600','0.032508924380736','677.2692579319956','677.269257931995639','test','test','4.0'),('2018-07-24 03:59:59','2018-07-24 07:59:59','BATBTC','4h','0.000047170000000','0.000045283200000','0.033562454337519','0.032219956164018','711.521185870657','711.521185870656950','test','test','4.0'),('2018-08-06 19:59:59','2018-08-06 23:59:59','BATBTC','4h','0.000037990000000','0.000038840000000','0.033264121410074','0.034008383142071','875.6020376434384','875.602037643438393','test','test','0.0'),('2018-08-07 03:59:59','2018-08-08 11:59:59','BATBTC','4h','0.000039720000000','0.000038131200000','0.033429512906074','0.032092332389831','841.6292272425367','841.629227242536672','test','test','4.0'),('2018-08-17 19:59:59','2018-08-18 03:59:59','BATBTC','4h','0.000033910000000','0.000033350000000','0.033132361680242','0.032585203834741','977.0675812516005','977.067581251600473','test','test','1.7'),('2018-08-19 11:59:59','2018-08-19 19:59:59','BATBTC','4h','0.000034970000000','0.000034020000000','0.033010771047908','0.032113995740630','943.9740076610873','943.974007661087285','test','test','2.7'),('2018-08-20 03:59:59','2018-08-20 07:59:59','BATBTC','4h','0.000033630000000','0.000033630000000','0.032811487646291','0.032811487646291','975.6612443143291','975.661244314329110','test','test','0.0'),('2018-08-27 19:59:59','2018-08-28 19:59:59','BATBTC','4h','0.000032700000000','0.000032270000000','0.032811487646291','0.032380021600789','1003.4094081434522','1003.409408143452197','test','test','1.3'),('2018-08-28 23:59:59','2018-08-29 03:59:59','BATBTC','4h','0.000032800000000','0.000031740000000','0.032715606302846','0.031658333660132','997.4270214282318','997.427021428231797','test','test','3.2'),('2018-09-01 19:59:59','2018-09-01 23:59:59','BATBTC','4h','0.000032440000000','0.000031820000000','0.032480656826687','0.031859879784993','1001.2532930544801','1001.253293054480082','test','test','1.9'),('2018-09-03 03:59:59','2018-09-03 07:59:59','BATBTC','4h','0.000031940000000','0.000031620000000','0.032342706372978','0.032018671744319','1012.6082145578446','1012.608214557844576','test','test','1.0'),('2018-09-05 07:59:59','2018-09-05 11:59:59','BATBTC','4h','0.000032520000000','0.000031219200000','0.032270698677720','0.030979870730611','992.3339076789667','992.333907678966739','test','test','4.0'),('2018-09-20 23:59:59','2018-09-21 03:59:59','BATBTC','4h','0.000025060000000','0.000024990000000','0.031983848022807','0.031894507665201','1276.290822937226','1276.290822937226039','test','test','0.3'),('2018-09-21 11:59:59','2018-09-21 15:59:59','BATBTC','4h','0.000026440000000','0.000025382400000','0.031963994610006','0.030685434825606','1208.9256660365188','1208.925666036518805','test','test','4.0'),('2018-09-21 19:59:59','2018-09-22 03:59:59','BATBTC','4h','0.000026120000000','0.000025200000000','0.031679870213472','0.030564040175325','1212.858737116088','1212.858737116087923','test','test','3.5'),('2018-09-22 07:59:59','2018-09-24 07:59:59','BATBTC','4h','0.000026000000000','0.000025270000000','0.031431907982773','0.030549396720180','1208.9195377989572','1208.919537798957208','test','test','2.8'),('2018-09-24 19:59:59','2018-09-24 23:59:59','BATBTC','4h','0.000025410000000','0.000025030000000','0.031235794368863','0.030768671115806','1229.2717185699855','1229.271718569985524','test','test','1.5'),('2018-09-25 23:59:59','2018-09-26 03:59:59','BATBTC','4h','0.000025750000000','0.000024730000000','0.031131989201517','0.029898799726350','1209.009289379314','1209.009289379313941','test','test','4.0'),('2018-09-26 15:59:59','2018-09-26 23:59:59','BATBTC','4h','0.000025640000000','0.000025350000000','0.030857947095925','0.030508929753576','1203.5080770641446','1203.508077064144572','test','test','1.1'),('2018-09-27 15:59:59','2018-09-28 11:59:59','BATBTC','4h','0.000025510000000','0.000025260000000','0.030780387686514','0.030478737473984','1206.6008501181411','1206.600850118141125','test','test','1.0'),('2018-09-28 15:59:59','2018-09-28 19:59:59','BATBTC','4h','0.000025500000000','0.000025240000000','0.030713354305952','0.030400198536558','1204.445266900061','1204.445266900060915','test','test','1.0'),('2018-09-28 23:59:59','2018-09-29 03:59:59','BATBTC','4h','0.000025490000000','0.000024930000000','0.030643764134975','0.029970539030401','1202.1876867389215','1202.187686738921457','test','test','2.2'),('2018-09-29 11:59:59','2018-10-03 03:59:59','BATBTC','4h','0.000025400000000','0.000025560000000','0.030494158556181','0.030686247743936','1200.5574234716885','1200.557423471688480','test','test','0.0'),('2018-10-04 11:59:59','2018-10-06 19:59:59','BATBTC','4h','0.000026180000000','0.000026090000000','0.030536845042349','0.030431867347398','1166.4188327864272','1166.418832786427174','test','test','0.4'),('2018-10-07 19:59:59','2018-10-10 07:59:59','BATBTC','4h','0.000026660000000','0.000026630000000','0.030513516665693','0.030479180375372','1144.5430107161626','1144.543010716162598','test','test','0.2'),('2018-10-10 11:59:59','2018-10-11 03:59:59','BATBTC','4h','0.000026920000000','0.000025910000000','0.030505886378955','0.029361349037100','1133.2052889656347','1133.205288965634736','test','test','3.8'),('2018-10-12 03:59:59','2018-10-15 03:59:59','BATBTC','4h','0.000027190000000','0.000027570000000','0.030251544747432','0.030674332059092','1112.5981885778433','1112.598188577843302','test','test','0.0'),('2018-10-15 15:59:59','2018-10-15 19:59:59','BATBTC','4h','0.000027350000000','0.000027150000000','0.030345497483356','0.030123592565745','1109.524588056892','1109.524588056892071','test','test','0.7'),('2018-10-16 19:59:59','2018-10-27 23:59:59','BATBTC','4h','0.000027510000000','0.000037700000000','0.030296185279442','0.041518218285531','1101.2789996162285','1101.278999616228475','test','test','0.0'),('2018-10-28 23:59:59','2018-10-29 03:59:59','BATBTC','4h','0.000038760000000','0.000037760000000','0.032789970391907','0.031943995923592','845.9744683154453','845.974468315445279','test','test','2.6'),('2018-10-30 07:59:59','2018-11-01 07:59:59','BATBTC','4h','0.000039140000000','0.000038560000000','0.032601976065614','0.032118860426420','832.9579986104865','832.957998610486470','test','test','1.5'),('2018-11-01 15:59:59','2018-11-09 07:59:59','BATBTC','4h','0.000039530000000','0.000045540000000','0.032494617034682','0.037434982538817','822.024210338539','822.024210338538978','test','test','0.0'),('2018-11-22 03:59:59','2018-11-22 11:59:59','BATBTC','4h','0.000039440000000','0.000040090000000','0.033592476035601','0.034146104570670','851.7362077992224','851.736207799222370','test','test','0.0'),('2018-11-22 15:59:59','2018-11-23 03:59:59','BATBTC','4h','0.000039100000000','0.000037536000000','0.033715504598950','0.032366884414992','862.2891201777492','862.289120177749169','test','test','4.0'),('2018-11-28 03:59:59','2018-11-28 07:59:59','BATBTC','4h','0.000038660000000','0.000037350000000','0.033415811224737','0.032283511361716','864.3510404743175','864.351040474317529','test','test','3.4'),('2018-11-28 15:59:59','2018-11-28 23:59:59','BATBTC','4h','0.000038270000000','0.000039990000000','0.033164189032955','0.034654714382751','866.5845056951833','866.584505695183339','test','test','0.0'),('2018-11-29 03:59:59','2018-12-05 03:59:59','BATBTC','4h','0.000039440000000','0.000040260000000','0.033495416888465','0.034191822614848','849.2752760766961','849.275276076696059','test','test','0.0'),('2018-12-09 19:59:59','2018-12-09 23:59:59','BATBTC','4h','0.000039930000000','0.000040010000000','0.033650173716550','0.033717592046060','842.7291188717755','842.729118871775540','test','test','0.0'),('2018-12-11 03:59:59','2018-12-11 11:59:59','BATBTC','4h','0.000040180000000','0.000039920000000','0.033665155567552','0.033447312350838','837.8585258226037','837.858525822603724','test','test','0.6'),('2018-12-12 03:59:59','2018-12-13 03:59:59','BATBTC','4h','0.000040980000000','0.000039820000000','0.033616745963838','0.032665173847731','820.320789747145','820.320789747145000','test','test','2.8'),('2018-12-14 19:59:59','2018-12-15 07:59:59','BATBTC','4h','0.000040430000000','0.000039950000000','0.033405285493592','0.033008685517413','826.2499503732871','826.249950373287106','test','test','1.2'),('2019-01-04 11:59:59','2019-01-05 03:59:59','BATBTC','4h','0.000035840000000','0.000035820000000','0.033317152165552','0.033298560004745','929.6080403334882','929.608040333488248','test','test','0.1'),('2019-01-05 19:59:59','2019-01-05 23:59:59','BATBTC','4h','0.000036380000000','0.000035520000000','0.033313020574262','0.032525522012034','915.6960025910329','915.696002591032880','test','test','2.4'),('2019-01-09 11:59:59','2019-01-09 15:59:59','BATBTC','4h','0.000035690000000','0.000035120000000','0.033138020893767','0.032608778195268','928.495962279817','928.495962279817036','test','test','1.6'),('2019-01-11 23:59:59','2019-01-12 03:59:59','BATBTC','4h','0.000035280000000','0.000034730000000','0.033020411405211','0.032505637417885','935.9527042293461','935.952704229346068','test','test','1.6'),('2019-01-12 11:59:59','2019-01-13 03:59:59','BATBTC','4h','0.000035370000000','0.000035080000000','0.032906017185806','0.032636219476338','930.3369292000439','930.336929200043869','test','test','0.8'),('2019-01-18 03:59:59','2019-01-18 19:59:59','BATBTC','4h','0.000035280000000','0.000034590000000','0.032846062139257','0.032203664665445','931.010831611596','931.010831611596018','test','test','2.0'),('2019-01-25 03:59:59','2019-01-25 07:59:59','BATBTC','4h','0.000034710000000','0.000034590000000','0.032703307145077','0.032590244717609','942.1868955654471','942.186895565447116','test','test','0.3'),('2019-01-25 11:59:59','2019-01-27 15:59:59','BATBTC','4h','0.000034790000000','0.000034690000000','0.032678182161195','0.032584252347567','939.2981362803934','939.298136280393351','test','test','0.3'),('2019-02-06 23:59:59','2019-02-08 23:59:59','BATBTC','4h','0.000034240000000','0.000032870400000','0.032657308869278','0.031351016514507','953.7765440793679','953.776544079367909','test','test','4.0'),('2019-02-10 11:59:59','2019-02-11 23:59:59','BATBTC','4h','0.000034590000000','0.000033206400000','0.032367021679328','0.031072340812155','935.7334975232277','935.733497523227697','test','test','4.0'),('2019-02-14 03:59:59','2019-02-21 07:59:59','BATBTC','4h','0.000034840000000','0.000035460000000','0.032079314819957','0.032650186668073','920.7610453489284','920.761045348928405','test','test','2.0'),('2019-02-25 23:59:59','2019-03-17 07:59:59','BATBTC','4h','0.000039000000000','0.000048350000000','0.032206175230649','0.039927399292356','825.7993648884386','825.799364888438618','test','test','2.9'),('2019-03-18 11:59:59','2019-03-18 15:59:59','BATBTC','4h','0.000048730000000','0.000048560000000','0.033922002799917','0.033803662137574','696.1215431955125','696.121543195512459','test','test','0.3'),('2019-03-19 03:59:59','2019-03-19 07:59:59','BATBTC','4h','0.000048560000000','0.000048280000000','0.033895704874952','0.033700260118671','698.0169867164789','698.016986716478868','test','test','0.6'),('2019-03-21 07:59:59','2019-03-21 15:59:59','BATBTC','4h','0.000048510000000','0.000047990000000','0.033852272706890','0.033489395324751','697.8411194988615','697.841119498861531','test','test','1.1'),('2019-03-21 19:59:59','2019-03-22 03:59:59','BATBTC','4h','0.000048720000000','0.000048520000000','0.033771633288637','0.033632997684004','693.1780231657771','693.178023165777063','test','test','0.4'),('2019-03-22 07:59:59','2019-04-02 07:59:59','BATBTC','4h','0.000048740000000','0.000066050000000','0.033740825376496','0.045723871894082','692.2614972608945','692.261497260894544','test','test','0.0'),('2019-04-02 23:59:59','2019-04-03 03:59:59','BATBTC','4h','0.000065660000000','0.000063033600000','0.036403724602626','0.034947575618521','554.4277277280873','554.427727728087348','test','test','4.0'),('2019-04-05 19:59:59','2019-04-06 11:59:59','BATBTC','4h','0.000062730000000','0.000060510000000','0.036080135939492','0.034803268383527','575.1655657499088','575.165565749908751','test','test','3.5'),('2019-04-13 07:59:59','2019-04-15 19:59:59','BATBTC','4h','0.000058460000000','0.000058220000000','0.035796387593722','0.035649430135246','612.322743649021','612.322743649021049','test','test','0.4'),('2019-04-16 11:59:59','2019-04-26 03:59:59','BATBTC','4h','0.000061730000000','0.000072750000000','0.035763730380727','0.042148248585743','579.3573688761884','579.357368876188389','test','test','0.5'),('2019-04-28 03:59:59','2019-04-29 07:59:59','BATBTC','4h','0.000077790000000','0.000074678400000','0.037182512204064','0.035695211715901','477.9857591472425','477.985759147242504','test','test','4.0'),('2019-04-30 15:59:59','2019-04-30 19:59:59','BATBTC','4h','0.000073140000000','0.000073640000000','0.036852000984472','0.037103928800882','503.85563282023816','503.855632820238156','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:14:53
