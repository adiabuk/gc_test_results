-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-29 07:59:59','2018-06-03 23:59:59','ADAETH','4h','0.000359480000000','0.000365890000000','1.297777777777778','1.320918858103681','3610.1529369583222','3610.152936958322243','test','test','1.4'),('2018-06-14 03:59:59','2018-06-14 11:59:59','ADAETH','4h','0.000355920000000','0.000342980000000','1.302920240072423','1.255550640424926','3660.7109464835435','3660.710946483543466','test','test','3.6'),('2018-06-30 15:59:59','2018-06-30 19:59:59','ADAETH','4h','0.000298120000000','0.000302480000000','1.292393662372979','1.311294898009455','4335.14578818254','4335.145788182539945','test','test','0.0'),('2018-07-01 11:59:59','2018-07-05 23:59:59','ADAETH','4h','0.000313010000000','0.000315610000000','1.296593936958863','1.307364021736005','4142.340298900555','4142.340298900555354','test','test','1.1'),('2018-07-13 23:59:59','2018-07-26 23:59:59','ADAETH','4h','0.000317920000000','0.000354780000000','1.298987289131561','1.449593326742876','4085.8935868506574','4085.893586850657357','test','test','1.7'),('2018-08-09 15:59:59','2018-08-10 11:59:59','ADAETH','4h','0.000331730000000','0.000325700000000','1.332455297489631','1.308234679987860','4016.686152864169','4016.686152864168889','test','test','1.8'),('2018-08-10 23:59:59','2018-08-14 03:59:59','ADAETH','4h','0.000346000000000','0.000347180000000','1.327072938044793','1.331598793729454','3835.4709192046034','3835.470919204603433','test','test','0.0'),('2018-08-14 07:59:59','2018-08-14 11:59:59','ADAETH','4h','0.000341890000000','0.000345260000000','1.328078683752495','1.341169517541859','3884.520412274402','3884.520412274402133','test','test','0.0'),('2018-08-14 15:59:59','2018-08-14 23:59:59','ADAETH','4h','0.000344730000000','0.000335990000000','1.330987757927909','1.297242992446837','3860.957148864066','3860.957148864065857','test','test','2.5'),('2018-08-15 03:59:59','2018-08-15 07:59:59','ADAETH','4h','0.000344240000000','0.000346510000000','1.323488921154338','1.332216320210288','3844.669187643324','3844.669187643324221','test','test','0.0'),('2018-08-17 15:59:59','2018-08-18 03:59:59','ADAETH','4h','0.000340820000000','0.000342790000000','1.325428343166771','1.333089553882218','3888.939449465323','3888.939449465322923','test','test','0.0'),('2018-08-20 23:59:59','2018-08-21 03:59:59','ADAETH','4h','0.000338920000000','0.000334250000000','1.327130834436871','1.308844215185071','3915.7642937474056','3915.764293747405645','test','test','1.4'),('2018-08-25 19:59:59','2018-08-26 03:59:59','ADAETH','4h','0.000337550000000','0.000336560000000','1.323067141269804','1.319186719199423','3919.6182529100997','3919.618252910099727','test','test','0.3'),('2018-08-26 11:59:59','2018-09-10 19:59:59','ADAETH','4h','0.000337070000000','0.000373110000000','1.322204825254164','1.463576830778714','3922.6416627233616','3922.641662723361605','test','test','0.0'),('2018-09-11 23:59:59','2018-09-12 03:59:59','ADAETH','4h','0.000378060000000','0.000370150000000','1.353620826481841','1.325299552775362','3580.439153789984','3580.439153789984175','test','test','2.1'),('2018-09-19 07:59:59','2018-09-19 11:59:59','ADAETH','4h','0.000347440000000','0.000336220000000','1.347327210102624','1.303817506852130','3877.870164928114','3877.870164928113809','test','test','3.2'),('2018-09-20 15:59:59','2018-09-22 03:59:59','ADAETH','4h','0.000356530000000','0.000342910000000','1.337658387158070','1.286557758226163','3751.88171306221','3751.881713062210110','test','test','3.8'),('2018-09-23 07:59:59','2018-09-25 03:59:59','ADAETH','4h','0.000371300000000','0.000358860000000','1.326302691839868','1.281866372188675','3572.0514189061887','3572.051418906188701','test','test','3.7'),('2018-09-25 15:59:59','2018-09-29 11:59:59','ADAETH','4h','0.000359990000000','0.000367380000000','1.316427954139603','1.343452045311835','3656.845896107123','3656.845896107122826','test','test','0.0'),('2018-10-01 11:59:59','2018-10-01 15:59:59','ADAETH','4h','0.000369330000000','0.000365000000000','1.322433307733432','1.306929188862813','3580.627914692639','3580.627914692639024','test','test','1.2'),('2018-10-02 19:59:59','2018-10-02 23:59:59','ADAETH','4h','0.000367840000000','0.000364470000000','1.318987947984406','1.306903918556645','3585.76540883103','3585.765408831030072','test','test','0.9'),('2018-10-04 03:59:59','2018-10-04 11:59:59','ADAETH','4h','0.000366800000000','0.000364850000000','1.316302608111570','1.309304816165503','3588.6112543935933','3588.611254393593299','test','test','0.5'),('2018-10-04 15:59:59','2018-10-04 19:59:59','ADAETH','4h','0.000367450000000','0.000367470000000','1.314747543234666','1.314819103857512','3578.0311422905597','3578.031142290559728','test','test','0.0'),('2018-10-04 23:59:59','2018-10-05 15:59:59','ADAETH','4h','0.000366810000000','0.000364850000000','1.314763445595299','1.307738183597625','3584.3173457520206','3584.317345752020628','test','test','0.5'),('2018-10-05 23:59:59','2018-10-06 03:59:59','ADAETH','4h','0.000365680000000','0.000364480000000','1.313202276262482','1.308892927292030','3591.1241420435417','3591.124142043541724','test','test','0.3'),('2018-10-07 15:59:59','2018-10-11 07:59:59','ADAETH','4h','0.000373670000000','0.000376290000000','1.312244643157938','1.321445491406590','3511.774140706874','3511.774140706873823','test','test','0.8'),('2018-10-11 11:59:59','2018-10-11 15:59:59','ADAETH','4h','0.000375310000000','0.000374800000000','1.314289276102082','1.312503319077723','3501.8765183503833','3501.876518350383321','test','test','0.1'),('2018-10-12 03:59:59','2018-10-12 23:59:59','ADAETH','4h','0.000372040000000','0.000372630000000','1.313892396763336','1.315976034313305','3531.5890677436187','3531.589067743618671','test','test','0.0'),('2018-10-17 15:59:59','2018-10-18 19:59:59','ADAETH','4h','0.000372330000000','0.000370990000000','1.314355427329996','1.309625117463420','3530.0819899819935','3530.081989981993502','test','test','0.4'),('2018-10-18 23:59:59','2018-10-19 11:59:59','ADAETH','4h','0.000371990000000','0.000369790000000','1.313304247359645','1.305537185491876','3530.482667167519','3530.482667167519139','test','test','0.6'),('2018-10-19 19:59:59','2018-10-21 23:59:59','ADAETH','4h','0.000375730000000','0.000372580000000','1.311578233611252','1.300582381707291','3490.746636178246','3490.746636178245808','test','test','0.8'),('2018-10-22 07:59:59','2018-10-22 11:59:59','ADAETH','4h','0.000372190000000','0.000371840000000','1.309134710965928','1.307903626979690','3517.3828178240356','3517.382817824035556','test','test','0.1'),('2018-10-22 15:59:59','2018-10-23 11:59:59','ADAETH','4h','0.000372800000000','0.000367010000000','1.308861136746764','1.288533062761346','3510.8936071533362','3510.893607153336234','test','test','1.6'),('2018-11-02 23:59:59','2018-11-03 03:59:59','ADAETH','4h','0.000362130000000','0.000360790000000','1.304343786972227','1.299517286338358','3601.8661446779515','3601.866144677951524','test','test','0.4'),('2018-11-04 07:59:59','2018-11-04 19:59:59','ADAETH','4h','0.000368580000000','0.000360080000000','1.303271231275811','1.273215868896288','3535.9249858261733','3535.924985826173270','test','test','2.3'),('2018-11-05 03:59:59','2018-11-05 07:59:59','ADAETH','4h','0.000361190000000','0.000361960000000','1.296592261858139','1.299356391655838','3589.778958050166','3589.778958050165784','test','test','0.0'),('2018-11-05 19:59:59','2018-11-07 03:59:59','ADAETH','4h','0.000368120000000','0.000366460000000','1.297206512924295','1.291356891030743','3523.86861057344','3523.868610573440037','test','test','0.8'),('2018-11-08 15:59:59','2018-11-08 19:59:59','ADAETH','4h','0.000365610000000','0.000360300000000','1.295906596947950','1.277085273598497','3544.50533888009','3544.505338880090221','test','test','1.5'),('2018-11-11 19:59:59','2018-11-12 03:59:59','ADAETH','4h','0.000362950000000','0.000361450000000','1.291724080648071','1.286385642513418','3558.9587564349667','3558.958756434966745','test','test','0.4'),('2018-11-12 15:59:59','2018-11-12 19:59:59','ADAETH','4h','0.000362910000000','0.000362500000000','1.290537761062593','1.289079767394643','3556.0821169507394','3556.082116950739419','test','test','0.1'),('2018-11-23 15:59:59','2018-11-23 23:59:59','ADAETH','4h','0.000352820000000','0.000350960000000','1.290213762469715','1.283412000669948','3656.8611826702427','3656.861182670242670','test','test','0.6'),('2018-11-28 19:59:59','2018-11-28 23:59:59','ADAETH','4h','0.000343520000000','0.000343330000000','1.288702259847545','1.287989482048957','3751.4620978328617','3751.462097832861673','test','test','0.1'),('2018-11-29 03:59:59','2018-11-30 11:59:59','ADAETH','4h','0.000342640000000','0.000338890000000','1.288543864781192','1.274441484752796','3760.6346742388273','3760.634674238827301','test','test','1.1'),('2018-12-02 11:59:59','2018-12-04 07:59:59','ADAETH','4h','0.000353120000000','0.000352940000000','1.285410002552659','1.284754775433098','3640.1506642293252','3640.150664229325230','test','test','0.9'),('2018-12-12 11:59:59','2018-12-12 15:59:59','ADAETH','4h','0.000338800000000','0.000337900000000','1.285264396526090','1.281850175874161','3793.5785021431234','3793.578502143123387','test','test','0.3'),('2018-12-12 23:59:59','2018-12-13 03:59:59','ADAETH','4h','0.000339260000000','0.000338230000000','1.284505680825661','1.280605896438317','3786.198434314866','3786.198434314866063','test','test','0.3'),('2018-12-13 23:59:59','2018-12-14 03:59:59','ADAETH','4h','0.000337530000000','0.000337470000000','1.283639062072918','1.283410879855857','3803.0369510055943','3803.036951005594346','test','test','0.0'),('2018-12-15 19:59:59','2018-12-15 23:59:59','ADAETH','4h','0.000339990000000','0.000334870000000','1.283588354913572','1.264258455866078','3775.370907713673','3775.370907713673205','test','test','1.5'),('2018-12-17 03:59:59','2018-12-17 15:59:59','ADAETH','4h','0.000342880000000','0.000350000000000','1.279292821791906','1.305857698399344','3731.021995426698','3731.021995426698140','test','test','0.7'),('2018-12-17 19:59:59','2018-12-20 03:59:59','ADAETH','4h','0.000345390000000','0.000343920000000','1.285196127704670','1.279726257969803','3720.9998196377146','3720.999819637714609','test','test','1.3'),('2018-12-20 19:59:59','2018-12-20 23:59:59','ADAETH','4h','0.000343500000000','0.000339870000000','1.283980601096922','1.270411897801487','3737.934792130777','3737.934792130777168','test','test','1.1'),('2018-12-21 03:59:59','2018-12-23 03:59:59','ADAETH','4h','0.000357610000000','0.000343305600000','1.280965333697936','1.229726720350019','3582.01765526114','3582.017655261140135','test','test','4.0'),('2019-01-06 15:59:59','2019-01-14 19:59:59','ADAETH','4h','0.000308000000000','0.000339920000000','1.269578975176177','1.401153523512617','4122.009659662912','4122.009659662911872','test','test','0.0'),('2019-01-14 23:59:59','2019-01-27 07:59:59','ADAETH','4h','0.000341380000000','0.000360010000000','1.298817763695386','1.369697648098822','3804.610005552129','3804.610005552129223','test','test','0.8'),('2019-01-27 15:59:59','2019-01-27 19:59:59','ADAETH','4h','0.000363000000000','0.000362290000000','1.314568849118372','1.311997653848747','3621.401788204881','3621.401788204881086','test','test','0.2'),('2019-01-28 11:59:59','2019-01-28 15:59:59','ADAETH','4h','0.000364960000000','0.000365140000000','1.313997472391788','1.314645542166641','3600.3876380748256','3600.387638074825645','test','test','0.0'),('2019-01-28 19:59:59','2019-01-28 23:59:59','ADAETH','4h','0.000366700000000','0.000365480000000','1.314141487897311','1.309769378229368','3583.6964491336553','3583.696449133655278','test','test','0.3'),('2019-01-29 19:59:59','2019-01-30 03:59:59','ADAETH','4h','0.000365170000000','0.000364590000000','1.313169907971102','1.311084198447803','3596.0509022403317','3596.050902240331652','test','test','0.4'),('2019-03-03 15:59:59','2019-03-04 07:59:59','ADAETH','4h','0.000319330000000','0.000318480000000','1.312706416965924','1.309212224580551','4110.8145710266','4110.814571026599879','test','test','0.3'),('2019-03-04 11:59:59','2019-03-04 15:59:59','ADAETH','4h','0.000320580000000','0.000318970000000','1.311929929769175','1.305341224338617','4092.363621464766','4092.363621464765856','test','test','0.5'),('2019-03-05 03:59:59','2019-03-05 07:59:59','ADAETH','4h','0.000318400000000','0.000314890000000','1.310465773006829','1.296019369541835','4115.784462961145','4115.784462961145437','test','test','1.1'),('2019-03-05 11:59:59','2019-03-05 15:59:59','ADAETH','4h','0.000319660000000','0.000317350000000','1.307255461125719','1.297808673553923','4089.5184293490547','4089.518429349054713','test','test','0.7'),('2019-03-08 23:59:59','2019-04-07 23:59:59','ADAETH','4h','0.000317500000000','0.000515610000000','1.305156174998653','2.119532520916710','4110.728110231978','4110.728110231977553','test','test','0.0'),('2019-04-10 23:59:59','2019-04-11 03:59:59','ADAETH','4h','0.000504110000000','0.000493860000000','1.486128696313777','1.455911443854560','2948.0246301675766','2948.024630167576561','test','test','2.0'),('2019-04-11 19:59:59','2019-04-11 23:59:59','ADAETH','4h','0.000507480000000','0.000505450000000','1.479413751322840','1.473495863100279','2915.215873182863','2915.215873182863106','test','test','0.4'),('2019-04-13 11:59:59','2019-04-14 07:59:59','ADAETH','4h','0.000510560000000','0.000504530000000','1.478098665051159','1.460641490673498','2895.0537939735964','2895.053793973596385','test','test','1.2'),('2019-04-15 19:59:59','2019-04-16 07:59:59','ADAETH','4h','0.000511810000000','0.000503420000000','1.474219292967234','1.450052707968904','2880.40345629674','2880.403456296739932','test','test','1.6'),('2019-05-14 23:59:59','2019-05-15 02:59:59','ADAETH','4h','0.000390490000000','0.000384110000000','1.468848940745384','1.444850230811825','3761.5532811221374','3761.553281122137378','test','test','1.6');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:14:55
