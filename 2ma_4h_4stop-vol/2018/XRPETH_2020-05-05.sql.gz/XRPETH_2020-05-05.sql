-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-19 15:59:59','2018-04-23 03:59:59','XRPETH','4h','0.001335000000000','0.001344130000000','1.297777777777778','1.306653216812318','972.1181856013316','972.118185601331561','test','test','0.1'),('2018-04-24 03:59:59','2018-04-24 07:59:59','XRPETH','4h','0.001358430000000','0.001337070000000','1.299750097563231','1.279312782365576','956.8031459576356','956.803145957635593','test','test','1.6'),('2018-05-23 19:59:59','2018-05-25 19:59:59','XRPETH','4h','0.001027800000000','0.001034590000000','1.295208471963752','1.303765064223563','1260.175590546558','1260.175590546557942','test','test','1.1'),('2018-05-27 07:59:59','2018-06-10 11:59:59','XRPETH','4h','0.001031240000000','0.001095710000000','1.297109936910377','1.378201319743289','1257.8157721872471','1257.815772187247148','test','test','0.0'),('2018-06-10 19:59:59','2018-06-10 23:59:59','XRPETH','4h','0.001101010000000','0.001109660000000','1.315130244206580','1.325462463362071','1194.476202946912','1194.476202946912053','test','test','0.0'),('2018-06-11 03:59:59','2018-06-11 07:59:59','XRPETH','4h','0.001096150000000','0.001085340000000','1.317426292907800','1.304434112798934','1201.8668000800983','1201.866800080098301','test','test','1.0'),('2018-06-11 19:59:59','2018-06-12 15:59:59','XRPETH','4h','0.001111530000000','0.001098510000000','1.314539141772496','1.299141177141872','1182.6393725517948','1182.639372551794850','test','test','1.2'),('2018-06-12 19:59:59','2018-06-13 19:59:59','XRPETH','4h','0.001129000000000','0.001102520000000','1.311117371854580','1.280365921007185','1161.3085667445346','1161.308566744534573','test','test','2.3'),('2018-06-14 07:59:59','2018-06-14 19:59:59','XRPETH','4h','0.001131750000000','0.001086480000000','1.304283716110714','1.252112367466285','1152.448611540282','1152.448611540281945','test','test','4.0'),('2018-06-24 19:59:59','2018-06-24 23:59:59','XRPETH','4h','0.001052870000000','0.001041280000000','1.292690083078619','1.278460142000536','1227.777487323809','1227.777487323809055','test','test','1.1'),('2018-06-26 15:59:59','2018-06-27 03:59:59','XRPETH','4h','0.001060580000000','0.001059700000000','1.289527873950156','1.288457907960720','1215.8704425410208','1215.870442541020793','test','test','0.5'),('2018-06-28 03:59:59','2018-06-28 15:59:59','XRPETH','4h','0.001073370000000','0.001057100000000','1.289290103730281','1.269747215455323','1201.1609265493553','1201.160926549355281','test','test','1.7'),('2018-06-28 23:59:59','2018-06-29 11:59:59','XRPETH','4h','0.001060350000000','0.001042860000000','1.284947239669179','1.263752608441929','1211.8142496997966','1211.814249699796619','test','test','1.6'),('2018-07-03 03:59:59','2018-07-03 23:59:59','XRPETH','4h','0.001052550000000','0.001051360000000','1.280237321618680','1.278789901151504','1216.31972031607','1216.319720316070061','test','test','0.1'),('2018-07-04 15:59:59','2018-07-04 19:59:59','XRPETH','4h','0.001048610000000','0.001065490000000','1.279915672625974','1.300519115806877','1220.583126830732','1220.583126830731999','test','test','0.0'),('2018-07-10 19:59:59','2018-07-10 23:59:59','XRPETH','4h','0.001023610000000','0.001023710000000','1.284494215555063','1.284619702236079','1254.8668101670198','1254.866810167019821','test','test','0.0'),('2018-07-17 15:59:59','2018-07-17 19:59:59','XRPETH','4h','0.001014080000000','0.001013990000000','1.284522101484178','1.284408099640996','1266.6871464619928','1266.687146461992825','test','test','0.0'),('2018-07-17 23:59:59','2018-07-18 19:59:59','XRPETH','4h','0.001016060000000','0.001015460000000','1.284496767741249','1.283738251452206','1264.193815071205','1264.193815071205108','test','test','0.1'),('2018-07-18 23:59:59','2018-07-19 03:59:59','XRPETH','4h','0.001018320000000','0.001006390000000','1.284328208565906','1.269281822824497','1261.2226103443963','1261.222610344396344','test','test','1.2'),('2018-07-19 15:59:59','2018-07-19 23:59:59','XRPETH','4h','0.001028700000000','0.001018880000000','1.280984567290037','1.268756251502355','1245.24600689223','1245.246006892230071','test','test','1.0'),('2018-07-31 11:59:59','2018-08-06 23:59:59','XRPETH','4h','0.000999000000000','0.001017910000000','1.278267163781663','1.302463392077069','1279.5467104921554','1279.546710492155398','test','test','0.0'),('2018-08-14 03:59:59','2018-08-14 07:59:59','XRPETH','4h','0.000987780000000','0.000976100000000','1.283644103402865','1.268465659692985','1299.5242902294688','1299.524290229468761','test','test','1.2'),('2018-08-14 11:59:59','2018-08-14 23:59:59','XRPETH','4h','0.000995260000000','0.000979220000000','1.280271115911780','1.259637765129849','1286.3685026141713','1286.368502614171348','test','test','1.6'),('2018-08-15 03:59:59','2018-08-15 19:59:59','XRPETH','4h','0.000999340000000','0.000991860000000','1.275685926849129','1.266137494150717','1276.528435616636','1276.528435616635988','test','test','0.7'),('2018-08-17 11:59:59','2018-08-31 15:59:59','XRPETH','4h','0.001052000000000','0.001186000000000','1.273564052916148','1.435786090074669','1210.6122176009017','1210.612217600901658','test','test','0.0'),('2018-08-31 19:59:59','2018-09-01 15:59:59','XRPETH','4h','0.001190000000000','0.001167880000000','1.309613394506931','1.285269992585508','1100.5154575688496','1100.515457568849570','test','test','1.9'),('2018-09-01 19:59:59','2018-09-01 23:59:59','XRPETH','4h','0.001169310000000','0.001175590000000','1.304203749635504','1.311208221971934','1115.3618370111465','1115.361837011146463','test','test','0.0'),('2018-09-04 07:59:59','2018-09-04 11:59:59','XRPETH','4h','0.001169050000000','0.001168980000000','1.305760299043599','1.305682113148271','1116.9413618267818','1116.941361826781758','test','test','0.0'),('2018-09-05 11:59:59','2018-09-05 19:59:59','XRPETH','4h','0.001172280000000','0.001186520000000','1.305742924400193','1.321604134387107','1113.8490159349244','1113.849015934924410','test','test','0.2'),('2018-09-05 23:59:59','2018-09-13 23:59:59','XRPETH','4h','0.001222490000000','0.001321790000000','1.309267637730618','1.415616382036625','1070.984333393826','1070.984333393826091','test','test','0.0'),('2018-09-17 19:59:59','2018-10-02 23:59:59','XRPETH','4h','0.001370000000000','0.002294530000000','1.332900692020842','2.232394616688016','972.9202131538995','972.920213153899454','test','test','0.0'),('2018-10-03 03:59:59','2018-10-05 11:59:59','XRPETH','4h','0.002368040000000','0.002324530000000','1.532788230835770','1.504625017408774','647.2813934037305','647.281393403730476','test','test','1.8'),('2018-10-16 07:59:59','2018-10-22 15:59:59','XRPETH','4h','0.002197600000000','0.002233800000000','1.526529738963104','1.551675523705762','694.6349376424753','694.634937642475279','test','test','0.5'),('2018-10-22 19:59:59','2018-10-23 11:59:59','XRPETH','4h','0.002233680000000','0.002205610000000','1.532117691128139','1.512864018448988','685.916376172119','685.916376172119044','test','test','1.3'),('2018-10-23 23:59:59','2018-10-27 23:59:59','XRPETH','4h','0.002282400000000','0.002249540000000','1.527839097199439','1.505842605465311','669.4002353660353','669.400235366035304','test','test','1.4'),('2018-10-29 15:59:59','2018-10-29 19:59:59','XRPETH','4h','0.002256860000000','0.002252630000000','1.522950987925188','1.520096542953447','674.8096859907963','674.809685990796311','test','test','0.2'),('2018-10-29 23:59:59','2018-10-31 15:59:59','XRPETH','4h','0.002263810000000','0.002286340000000','1.522316666820357','1.537467140801593','672.4577887810182','672.457788781018166','test','test','0.1'),('2018-10-31 19:59:59','2018-11-04 07:59:59','XRPETH','4h','0.002287640000000','0.002256960000000','1.525683438816187','1.505222191459575','666.9246204893195','666.924620489319523','test','test','1.3'),('2018-11-05 15:59:59','2018-11-08 19:59:59','XRPETH','4h','0.002333720000000','0.002361690000000','1.521136494959162','1.539367554282477','651.8076268614753','651.807626861475342','test','test','0.0'),('2018-11-12 15:59:59','2018-11-14 19:59:59','XRPETH','4h','0.002478500000000','0.002506570000000','1.525187841475454','1.542461201455368','615.36729533002','615.367295330020056','test','test','1.1'),('2018-11-14 23:59:59','2018-11-29 15:59:59','XRPETH','4h','0.002586730000000','0.003208670000000','1.529026365915435','1.896657567477811','591.1039675248035','591.103967524803465','test','test','1.0'),('2018-11-29 23:59:59','2018-11-30 11:59:59','XRPETH','4h','0.003235330000000','0.003167190000000','1.610722188484852','1.576798412572238','497.8540638775185','497.854063877518513','test','test','2.1'),('2018-12-03 07:59:59','2018-12-04 11:59:59','XRPETH','4h','0.003196100000000','0.003203380000000','1.603183571615382','1.606835264741805','501.6061986844537','501.606198684453716','test','test','0.5'),('2018-12-04 15:59:59','2018-12-07 19:59:59','XRPETH','4h','0.003187180000000','0.003203020000000','1.603995058976809','1.611966771190801','503.26465997427493','503.264659974274934','test','test','0.0'),('2018-12-08 03:59:59','2018-12-09 15:59:59','XRPETH','4h','0.003298690000000','0.003272750000000','1.605766550579919','1.593139239640715','486.7891649654617','486.789164965461680','test','test','0.8'),('2018-12-10 15:59:59','2018-12-16 03:59:59','XRPETH','4h','0.003332930000000','0.003361590000000','1.602960481482318','1.616744403556674','480.9463389517086','480.946338951708583','test','test','0.0'),('2018-12-17 15:59:59','2018-12-17 19:59:59','XRPETH','4h','0.003380610000000','0.003446030000000','1.606023575276619','1.637102600155146','475.06916659319455','475.069166593194552','test','test','0.0'),('2018-12-17 23:59:59','2018-12-20 15:59:59','XRPETH','4h','0.003479410000000','0.003413370000000','1.612930025249625','1.582316243353417','463.5642322260456','463.564232226045590','test','test','1.9'),('2019-01-10 07:59:59','2019-01-14 19:59:59','XRPETH','4h','0.002576340000000','0.002596400000000','1.606126962606024','1.618632651633822','623.414208763604','623.414208763604051','test','test','0.0'),('2019-01-15 15:59:59','2019-01-15 19:59:59','XRPETH','4h','0.002590000000000','0.002603960000000','1.608906004612201','1.617577945857138','621.1992295800005','621.199229580000519','test','test','0.0'),('2019-01-15 23:59:59','2019-01-19 11:59:59','XRPETH','4h','0.002702650000000','0.002648540000000','1.610833102666631','1.578582467480687','596.019870374126','596.019870374125958','test','test','2.0'),('2019-01-20 11:59:59','2019-01-27 11:59:59','XRPETH','4h','0.002680000000000','0.002688090000000','1.603666294847533','1.608507212879368','598.3829458386316','598.382945838631599','test','test','0.0'),('2019-01-27 15:59:59','2019-01-27 23:59:59','XRPETH','4h','0.002713340000000','0.002735430000000','1.604742054410163','1.617806672917951','591.4268224439852','591.426822443985202','test','test','0.3'),('2019-01-28 03:59:59','2019-02-03 07:59:59','XRPETH','4h','0.002754280000000','0.002812130000000','1.607645302967449','1.641411761271131','583.6898583177633','583.689858317763310','test','test','0.9'),('2019-02-03 19:59:59','2019-02-03 23:59:59','XRPETH','4h','0.002805030000000','0.002816620000000','1.615148960368267','1.621822534786604','575.8045227210644','575.804522721064359','test','test','0.0'),('2019-02-05 19:59:59','2019-02-05 23:59:59','XRPETH','4h','0.002815070000000','0.002793970000000','1.616631976905675','1.604514717046165','574.2777184601716','574.277718460171627','test','test','0.7'),('2019-02-06 03:59:59','2019-02-06 19:59:59','XRPETH','4h','0.002829350000000','0.002793490000000','1.613939252492451','1.593483719739565','570.4275725846753','570.427572584675318','test','test','1.3'),('2019-02-25 19:59:59','2019-02-27 03:59:59','XRPETH','4h','0.002380130000000','0.002309270000000','1.609393578547365','1.561479544870269','676.178855166468','676.178855166467997','test','test','3.0'),('2019-02-27 23:59:59','2019-02-28 03:59:59','XRPETH','4h','0.002300420000000','0.002287290000000','1.598746015508011','1.589620927400787','694.9800538632123','694.980053863212333','test','test','0.6'),('2019-03-01 11:59:59','2019-03-05 15:59:59','XRPETH','4h','0.002343980000000','0.002341950000000','1.596718218150850','1.595335382980394','681.1995913577973','681.199591357797317','test','test','0.4'),('2019-03-10 15:59:59','2019-03-10 23:59:59','XRPETH','4h','0.002319560000000','0.002310030000000','1.596410921446304','1.589852006789480','688.2386838220629','688.238683822062853','test','test','0.4'),('2019-03-11 07:59:59','2019-03-12 11:59:59','XRPETH','4h','0.002316800000000','0.002319890000000','1.594953384855899','1.597080631903207','688.4294651484369','688.429465148436861','test','test','0.0'),('2019-03-12 15:59:59','2019-03-15 07:59:59','XRPETH','4h','0.002324780000000','0.002332830000000','1.595426106421967','1.600950577622122','686.2697143049954','686.269714304995432','test','test','0.0'),('2019-04-02 03:59:59','2019-04-02 07:59:59','XRPETH','4h','0.002251270000000','0.002201400000000','1.596653766688668','1.561284786804086','709.2235789970408','709.223578997040818','test','test','2.2');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:42:08
