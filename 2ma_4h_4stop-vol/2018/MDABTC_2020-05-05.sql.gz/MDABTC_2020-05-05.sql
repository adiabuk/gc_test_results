-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-24 11:59:59','2018-03-24 23:59:59','MDABTC','4h','0.000104070000000','0.000102100000000','0.033333333333333','0.032702347778738','320.29723583485475','320.297235834854746','test','test','1.9'),('2018-03-25 15:59:59','2018-03-26 15:59:59','MDABTC','4h','0.000106800000000','0.000103440000000','0.033193114321201','0.032148836567276','310.7969505730441','310.796950573044114','test','test','3.1'),('2018-03-29 03:59:59','2018-03-29 07:59:59','MDABTC','4h','0.000105310000000','0.000104960000000','0.032961052598107','0.032851505846523','312.9907188121419','312.990718812141893','test','test','0.3'),('2018-03-31 19:59:59','2018-03-31 23:59:59','MDABTC','4h','0.000106210000000','0.000106230000000','0.032936708875532','0.032942911061555','310.1093011536808','310.109301153680804','test','test','0.0'),('2018-04-02 15:59:59','2018-04-02 19:59:59','MDABTC','4h','0.000108890000000','0.000106600000000','0.032938087139093','0.032245386068760','302.4895503636065','302.489550363606497','test','test','2.1'),('2018-04-10 07:59:59','2018-04-10 11:59:59','MDABTC','4h','0.000102300000000','0.000102710000000','0.032784153567908','0.032915546558747','320.47070936371455','320.470709363714548','test','test','0.0'),('2018-04-10 19:59:59','2018-04-10 23:59:59','MDABTC','4h','0.000103970000000','0.000103080000000','0.032813352010317','0.032532464414961','315.6040397260428','315.604039726042799','test','test','0.9'),('2018-04-11 03:59:59','2018-04-15 07:59:59','MDABTC','4h','0.000103640000000','0.000108320000000','0.032750932544682','0.034229843817445','316.0066822142223','316.006682214222280','test','test','0.0'),('2018-04-15 11:59:59','2018-04-21 15:59:59','MDABTC','4h','0.000116920000000','0.000122120000000','0.033079579494185','0.034550788982466','282.92490159241265','282.924901592412652','test','test','2.5'),('2018-04-22 23:59:59','2018-04-24 15:59:59','MDABTC','4h','0.000133020000000','0.000129270000000','0.033406514936025','0.032464743540670','251.13903876127733','251.139038761277334','test','test','2.8'),('2018-04-24 19:59:59','2018-04-24 23:59:59','MDABTC','4h','0.000138060000000','0.000132537600000','0.033197232403724','0.031869343107575','240.45510939971027','240.455109399710267','test','test','4.0'),('2018-04-26 19:59:59','2018-04-26 23:59:59','MDABTC','4h','0.000128130000000','0.000126510000000','0.032902145893469','0.032486150604720','256.78721527720796','256.787215277207963','test','test','1.3'),('2018-04-28 15:59:59','2018-04-29 11:59:59','MDABTC','4h','0.000130550000000','0.000125328000000','0.032809702495969','0.031497314396130','251.31905397142003','251.319053971420033','test','test','4.0'),('2018-04-29 19:59:59','2018-05-01 15:59:59','MDABTC','4h','0.000127010000000','0.000134470000000','0.032518060696005','0.034428026311249','256.02756236520486','256.027562365204858','test','test','0.0'),('2018-05-02 19:59:59','2018-05-03 07:59:59','MDABTC','4h','0.000136300000000','0.000134490000000','0.032942497499392','0.032505036600831','241.69110417749246','241.691104177492463','test','test','1.3'),('2018-05-03 11:59:59','2018-05-03 15:59:59','MDABTC','4h','0.000133750000000','0.000134170000000','0.032845283966379','0.032948424297339','245.57221657105546','245.572216571055463','test','test','0.0'),('2018-05-05 19:59:59','2018-05-06 07:59:59','MDABTC','4h','0.000135380000000','0.000129990000000','0.032868204039925','0.031559594054881','242.7847838670803','242.784783867080307','test','test','4.0'),('2018-05-18 15:59:59','2018-05-18 19:59:59','MDABTC','4h','0.000118000000000','0.000119570000000','0.032577401821027','0.033010846913053','276.0796764493785','276.079676449378496','test','test','0.0'),('2018-05-19 03:59:59','2018-05-19 07:59:59','MDABTC','4h','0.000117580000000','0.000115900000000','0.032673722952588','0.032206876086111','277.8850395695526','277.885039569552589','test','test','1.4'),('2018-06-01 15:59:59','2018-06-01 19:59:59','MDABTC','4h','0.000108150000000','0.000103824000000','0.032569979204482','0.031267180036303','301.1556098426445','301.155609842644481','test','test','4.0'),('2018-06-01 23:59:59','2018-06-04 11:59:59','MDABTC','4h','0.000101180000000','0.000099810000000','0.032280468278220','0.031843383463621','319.0400106564538','319.040010656453774','test','test','1.4'),('2018-06-05 23:59:59','2018-06-06 03:59:59','MDABTC','4h','0.000101780000000','0.000100370000000','0.032183338319420','0.031737489360583','316.2049353450601','316.204935345060107','test','test','1.4'),('2018-06-06 07:59:59','2018-06-06 11:59:59','MDABTC','4h','0.000100260000000','0.000101740000000','0.032084260773012','0.032557876431740','320.01058022154393','320.010580221543933','test','test','0.0'),('2018-06-07 03:59:59','2018-06-07 23:59:59','MDABTC','4h','0.000101990000000','0.000100390000000','0.032189508697174','0.031684525719279','315.6143611841727','315.614361184172708','test','test','1.6'),('2018-06-08 03:59:59','2018-06-08 07:59:59','MDABTC','4h','0.000102310000000','0.000099990000000','0.032077290257642','0.031349899842260','313.5303514577417','313.530351457741688','test','test','2.3'),('2018-07-05 07:59:59','2018-07-09 23:59:59','MDABTC','4h','0.000084840000000','0.000081580000000','0.031915647943112','0.030689280518612','376.1863265336189','376.186326533618910','test','test','3.8'),('2018-07-16 15:59:59','2018-07-17 19:59:59','MDABTC','4h','0.000079150000000','0.000079310000000','0.031643121848779','0.031707087729964','399.7867574071875','399.786757407187508','test','test','0.0'),('2018-07-19 23:59:59','2018-07-20 03:59:59','MDABTC','4h','0.000079590000000','0.000080480000000','0.031657336489042','0.032011338618396','397.7552015208219','397.755201520821913','test','test','0.0'),('2018-07-23 11:59:59','2018-07-26 23:59:59','MDABTC','4h','0.000079480000000','0.000080410000000','0.031736003628899','0.032107348412176','399.29546588951507','399.295465889515071','test','test','0.0'),('2018-08-17 15:59:59','2018-08-18 19:59:59','MDABTC','4h','0.000065230000000','0.000062620800000','0.031818524691849','0.030545783704175','487.78973925876306','487.789739258763063','test','test','4.0'),('2018-08-19 07:59:59','2018-09-05 11:59:59','MDABTC','4h','0.000067100000000','0.000105600000000','0.031535693361255','0.049629943650500','469.98052699336637','469.980526993366368','test','test','0.7'),('2018-09-05 15:59:59','2018-09-05 19:59:59','MDABTC','4h','0.000107000000000','0.000102720000000','0.035556637869976','0.034134372355177','332.30502682220555','332.305026822205548','test','test','4.0'),('2018-10-07 15:59:59','2018-10-17 11:59:59','MDABTC','4h','0.000072500000000','0.000240870000000','0.035240578866687','0.117081354918881','486.0769498853425','486.076949885342515','test','test','0.0'),('2018-10-17 15:59:59','2018-10-22 07:59:59','MDABTC','4h','0.000266990000000','0.000256310400000','0.053427417989397','0.051290321269821','200.1101838623061','200.110183862306087','test','test','4.0'),('2018-10-22 19:59:59','2018-10-22 23:59:59','MDABTC','4h','0.000276500000000','0.000265440000000','0.052952507607269','0.050834407302978','191.5099732631794','191.509973263179404','test','test','4.0'),('2018-11-12 07:59:59','2018-11-12 15:59:59','MDABTC','4h','0.000221990000000','0.000213110400000','0.052481818650760','0.050382545904730','236.4152378519753','236.415237851975292','test','test','4.0'),('2018-11-12 19:59:59','2018-11-12 23:59:59','MDABTC','4h','0.000199610000000','0.000218600000000','0.052015313596087','0.056963817204071','260.5847081613479','260.584708161347919','test','test','0.0'),('2018-11-13 03:59:59','2018-11-13 11:59:59','MDABTC','4h','0.000211280000000','0.000202828800000','0.053114981064528','0.050990381821947','251.39616179727162','251.396161797271617','test','test','4.0'),('2018-11-25 19:59:59','2018-11-30 15:59:59','MDABTC','4h','0.000168090000000','0.000232000000000','0.052642847899510','0.072658342035138','313.1825087721432','313.182508772143194','test','test','0.0'),('2018-12-11 15:59:59','2018-12-12 03:59:59','MDABTC','4h','0.000193620000000','0.000193030000000','0.057090735485205','0.056916768261074','294.8597019171814','294.859701917181383','test','test','0.3'),('2018-12-12 11:59:59','2018-12-20 23:59:59','MDABTC','4h','0.000211000000000','0.000252550000000','0.057052076102064','0.068286738481404','270.3889862657083','270.388986265708297','test','test','0.3'),('2018-12-22 19:59:59','2018-12-22 23:59:59','MDABTC','4h','0.000243560000000','0.000233817600000','0.059548667741918','0.057166721032241','244.49280564098282','244.492805640982823','test','test','4.0'),('2018-12-25 19:59:59','2018-12-26 03:59:59','MDABTC','4h','0.000247800000000','0.000240200000000','0.059019346250878','0.057209229093870','238.1733101326814','238.173310132681394','test','test','3.5'),('2018-12-26 23:59:59','2018-12-27 07:59:59','MDABTC','4h','0.000238700000000','0.000238430000000','0.058617097993766','0.058550794615223','245.5680686793698','245.568068679369787','test','test','0.1'),('2019-01-02 19:59:59','2019-01-02 23:59:59','MDABTC','4h','0.000224100000000','0.000223340000000','0.058602363909645','0.058403623184204','261.50095452764344','261.500954527643444','test','test','0.3'),('2019-01-03 03:59:59','2019-01-03 07:59:59','MDABTC','4h','0.000219770000000','0.000218340000000','0.058558199303991','0.058177172662481','266.4521968603146','266.452196860314587','test','test','0.7'),('2019-01-03 15:59:59','2019-01-03 19:59:59','MDABTC','4h','0.000225740000000','0.000216990000000','0.058473526716989','0.056207010553378','259.03041869845447','259.030418698454469','test','test','3.9'),('2019-01-05 15:59:59','2019-01-05 19:59:59','MDABTC','4h','0.000225110000000','0.000216105600000','0.057969856458409','0.055651062200073','257.5179088374968','257.517908837496805','test','test','4.0'),('2019-01-17 07:59:59','2019-01-18 03:59:59','MDABTC','4h','0.000211360000000','0.000202905600000','0.057454568845445','0.055156386091627','271.8327443482463','271.832744348246308','test','test','4.0'),('2019-01-19 19:59:59','2019-01-19 23:59:59','MDABTC','4h','0.000201460000000','0.000199400000000','0.056943861566819','0.056361590372400','282.65591962086324','282.655919620863244','test','test','1.0'),('2019-01-23 11:59:59','2019-01-23 15:59:59','MDABTC','4h','0.000203190000000','0.000199900000000','0.056814467968059','0.055894542776785','279.61252014399986','279.612520143999859','test','test','1.6'),('2019-01-23 19:59:59','2019-01-23 23:59:59','MDABTC','4h','0.000200400000000','0.000201290000000','0.056610040147776','0.056861452002724','282.4852302783245','282.485230278324480','test','test','0.0'),('2019-01-24 03:59:59','2019-01-24 07:59:59','MDABTC','4h','0.000199150000000','0.000197500000000','0.056665909448876','0.056196420367326','284.5388373029163','284.538837302916306','test','test','0.8'),('2019-01-24 15:59:59','2019-01-24 19:59:59','MDABTC','4h','0.000200030000000','0.000199290000000','0.056561578541865','0.056352332088228','282.7654778876402','282.765477887640202','test','test','0.4'),('2019-01-25 19:59:59','2019-01-25 23:59:59','MDABTC','4h','0.000201260000000','0.000197130000000','0.056515079329945','0.055355349241340','280.80631685354933','280.806316853549333','test','test','2.1'),('2019-01-26 07:59:59','2019-01-27 03:59:59','MDABTC','4h','0.000205880000000','0.000198260000000','0.056257361532478','0.054175172418055','273.2531646224867','273.253164622486679','test','test','3.7'),('2019-01-27 07:59:59','2019-01-28 11:59:59','MDABTC','4h','0.000207390000000','0.000203510000000','0.055794652840384','0.054750806690518','269.03251285203504','269.032512852035040','test','test','1.9'),('2019-01-31 15:59:59','2019-02-05 15:59:59','MDABTC','4h','0.000207030000000','0.000209070000000','0.055562687029302','0.056110181989162','268.3798822842208','268.379882284220798','test','test','0.5'),('2019-02-14 19:59:59','2019-02-15 15:59:59','MDABTC','4h','0.000209920000000','0.000201523200000','0.055684352575938','0.053456978472900','265.26463688994744','265.264636889947440','test','test','4.0'),('2019-02-18 03:59:59','2019-02-18 11:59:59','MDABTC','4h','0.000203080000000','0.000200400000000','0.055189380553040','0.054461059005462','271.7617714843434','271.761771484343399','test','test','1.3'),('2019-02-20 15:59:59','2019-02-20 23:59:59','MDABTC','4h','0.000202610000000','0.000203410000000','0.055027531320245','0.055244806010814','271.5933632113189','271.593363211318888','test','test','0.0'),('2019-02-21 15:59:59','2019-02-21 19:59:59','MDABTC','4h','0.000200540000000','0.000198720000000','0.055075814584816','0.054575974241022','274.6375515349368','274.637551534936790','test','test','0.9'),('2019-02-23 03:59:59','2019-02-24 19:59:59','MDABTC','4h','0.000207080000000','0.000207280000000','0.054964738952862','0.055017824464696','265.42755916970253','265.427559169702533','test','test','0.0'),('2019-02-24 23:59:59','2019-03-02 11:59:59','MDABTC','4h','0.000217700000000','0.000227270000000','0.054976535733270','0.057393281011026','252.5334668501128','252.533466850112802','test','test','0.0'),('2019-03-07 19:59:59','2019-03-08 23:59:59','MDABTC','4h','0.000230410000000','0.000221193600000','0.055513590239438','0.053293046629860','240.93394487842346','240.933944878423461','test','test','4.0'),('2019-03-09 19:59:59','2019-03-12 19:59:59','MDABTC','4h','0.000240210000000','0.000253770000000','0.055020136103976','0.058126056113842','229.05014822020638','229.050148220206381','test','test','1.4'),('2019-03-12 23:59:59','2019-03-13 03:59:59','MDABTC','4h','0.000281530000000','0.000270268800000','0.055710340550613','0.053481926928588','197.88420612585753','197.884206125857531','test','test','4.0'),('2019-03-13 07:59:59','2019-03-14 15:59:59','MDABTC','4h','0.000297500000000','0.000285600000000','0.055215137523496','0.053006532022556','185.59710091931427','185.597100919314272','test','test','4.0'),('2019-03-18 11:59:59','2019-03-18 19:59:59','MDABTC','4h','0.000279460000000','0.000268281600000','0.054724336301065','0.052535362849022','195.821714381539','195.821714381539010','test','test','4.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:47:58
