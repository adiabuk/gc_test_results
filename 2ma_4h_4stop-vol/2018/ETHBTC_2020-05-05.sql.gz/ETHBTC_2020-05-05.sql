-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-01-02 03:59:59','2018-01-02 19:59:59','ETHBTC','4h','0.061941000000000','0.059463360000000','0.033333333333333','0.032000000000000','0.5381465157703836','0.538146515770384','test','test','4.0'),('2018-01-02 23:59:59','2018-01-05 19:59:59','ETHBTC','4h','0.058261000000000','0.058499000000000','0.033037037037037','0.033171995496638','0.5670523512647759','0.567052351264776','test','test','1.0'),('2018-01-06 03:59:59','2018-01-16 11:59:59','ETHBTC','4h','0.058299000000000','0.093500000000000','0.033067027805837','0.053032935382181','0.5671971698629023','0.567197169862902','test','test','0.0'),('2018-01-16 23:59:59','2018-01-17 11:59:59','ETHBTC','4h','0.091855000000000','0.088180800000000','0.037503896156136','0.036003740309891','0.4082945528946273','0.408294552894627','test','test','4.0'),('2018-01-17 19:59:59','2018-02-02 15:59:59','ETHBTC','4h','0.088038000000000','0.107076000000000','0.037170528190304','0.045208563080772','0.4222100478237099','0.422210047823710','test','test','0.0'),('2018-02-02 19:59:59','2018-02-04 11:59:59','ETHBTC','4h','0.103598000000000','0.101937000000000','0.038956758165963','0.038332159473771','0.3760377436433458','0.376037743643346','test','test','1.6'),('2018-02-25 19:59:59','2018-02-26 15:59:59','ETHBTC','4h','0.087994000000000','0.085364000000000','0.038817958456587','0.037657751729528','0.44114324222773516','0.441143242227735','test','test','3.0'),('2018-04-09 03:59:59','2018-04-25 11:59:59','ETHBTC','4h','0.057799000000000','0.068881000000000','0.038560134739463','0.045953401287028','0.6671419010616637','0.667141901061664','test','test','0.0'),('2018-04-25 15:59:59','2018-05-01 03:59:59','ETHBTC','4h','0.069348000000000','0.071767000000000','0.040203082861144','0.041605448573798','0.5797295215600192','0.579729521560019','test','test','0.0'),('2018-05-01 07:59:59','2018-05-07 11:59:59','ETHBTC','4h','0.073734000000000','0.078480000000000','0.040514719686178','0.043122510659550','0.5494713386792857','0.549471338679286','test','test','1.2'),('2018-05-07 15:59:59','2018-05-11 07:59:59','ETHBTC','4h','0.077945000000000','0.079512000000000','0.041094228791372','0.041920383856047','0.5272208453572675','0.527220845357268','test','test','0.0'),('2018-05-11 11:59:59','2018-05-11 15:59:59','ETHBTC','4h','0.078803000000000','0.079438000000000','0.041277818805744','0.041610438311875','0.523810245875721','0.523810245875721','test','test','0.0'),('2018-05-12 11:59:59','2018-05-12 15:59:59','ETHBTC','4h','0.079422000000000','0.079269000000000','0.041351734251551','0.041272073510944','0.5206584353397211','0.520658435339721','test','test','0.2'),('2018-05-13 15:59:59','2018-05-21 19:59:59','ETHBTC','4h','0.084224000000000','0.083041000000000','0.041334031864750','0.040753459110001','0.4907631062968962','0.490763106296896','test','test','1.6'),('2018-05-22 07:59:59','2018-05-22 11:59:59','ETHBTC','4h','0.083412000000000','0.083332000000000','0.041205015697028','0.041165496188375','0.4939938581622281','0.493993858162228','test','test','0.1'),('2018-06-02 19:59:59','2018-06-02 23:59:59','ETHBTC','4h','0.078069000000000','0.077350000000000','0.041196233583994','0.040816824446604','0.5276900380944264','0.527690038094426','test','test','0.9'),('2018-06-03 11:59:59','2018-06-04 15:59:59','ETHBTC','4h','0.080321000000000','0.078215000000000','0.041111920442352','0.040033974395221','0.5118452265578312','0.511845226557831','test','test','2.6'),('2018-06-05 07:59:59','2018-06-05 11:59:59','ETHBTC','4h','0.079096000000000','0.079060000000000','0.040872376876322','0.040853774095302','0.5167439172186007','0.516743917218601','test','test','0.0'),('2018-06-05 19:59:59','2018-06-07 07:59:59','ETHBTC','4h','0.079773000000000','0.079030000000000','0.040868242924985','0.040487599041801','0.5123067068429753','0.512306706842975','test','test','0.9'),('2018-06-07 11:59:59','2018-06-07 15:59:59','ETHBTC','4h','0.078998000000000','0.078760000000000','0.040783655395388','0.040660785069758','0.5162618723940887','0.516261872394089','test','test','0.3'),('2018-06-08 07:59:59','2018-06-08 11:59:59','ETHBTC','4h','0.078720000000000','0.078962000000000','0.040756350878582','0.040881643522289','0.5177381971364526','0.517738197136453','test','test','0.0'),('2018-06-19 07:59:59','2018-06-21 19:59:59','ETHBTC','4h','0.077526000000000','0.078102000000000','0.040784193688294','0.041087210683424','0.526071172100898','0.526071172100898','test','test','0.0'),('2018-07-08 15:59:59','2018-07-09 03:59:59','ETHBTC','4h','0.072687000000000','0.071920000000000','0.040851530798323','0.040420461637093','0.5620197669228763','0.562019766922876','test','test','1.1'),('2018-07-15 15:59:59','2018-07-15 19:59:59','ETHBTC','4h','0.070867000000000','0.070747000000000','0.040755737651383','0.040686725438108','0.5751017772924366','0.575101777292437','test','test','0.2'),('2018-07-16 07:59:59','2018-07-17 07:59:59','ETHBTC','4h','0.071090000000000','0.070809000000000','0.040740401603989','0.040579365553198','0.573082031284128','0.573082031284128','test','test','0.4'),('2018-08-04 19:59:59','2018-08-07 15:59:59','ETHBTC','4h','0.058032000000000','0.057458000000000','0.040704615814924','0.040302002610524','0.701416732404949','0.701416732404949','test','test','1.0'),('2018-09-20 23:59:59','2018-09-24 23:59:59','ETHBTC','4h','0.034522000000000','0.034631000000000','0.040615146213946','0.040743384755668','1.1765003827688496','1.176500382768850','test','test','2.1'),('2018-09-27 19:59:59','2018-09-28 07:59:59','ETHBTC','4h','0.034297000000000','0.033977000000000','0.040643643667662','0.040264427818647','1.1850495281704585','1.185049528170458','test','test','0.9'),('2018-09-29 11:59:59','2018-10-02 19:59:59','ETHBTC','4h','0.035291000000000','0.034535000000000','0.040559373478992','0.039690514949902','1.149283768637676','1.149283768637676','test','test','2.1'),('2018-10-05 23:59:59','2018-10-06 11:59:59','ETHBTC','4h','0.034409000000000','0.034179000000000','0.040366293805861','0.040096473480500','1.1731318493958298','1.173131849395830','test','test','0.7'),('2018-10-08 15:59:59','2018-10-09 15:59:59','ETHBTC','4h','0.034402000000000','0.034397000000000','0.040306333733559','0.040300475595408','1.17162763018309','1.171627630183090','test','test','0.3'),('2018-10-09 19:59:59','2018-10-10 03:59:59','ETHBTC','4h','0.034368000000000','0.034230000000000','0.040305031925081','0.040143192585996','1.1727488339467138','1.172748833946714','test','test','0.4'),('2018-10-10 07:59:59','2018-10-10 15:59:59','ETHBTC','4h','0.034358000000000','0.034179000000000','0.040269067627506','0.040059271856352','1.1720434142705112','1.172043414270511','test','test','0.5'),('2018-10-28 19:59:59','2018-10-28 23:59:59','ETHBTC','4h','0.031562000000000','0.031616000000000','0.040222446345028','0.040291263660237','1.2743947260955437','1.274394726095544','test','test','0.0'),('2018-10-29 07:59:59','2018-10-29 15:59:59','ETHBTC','4h','0.031591000000000','0.031109000000000','0.040237739081741','0.039623811373299','1.2737089386768594','1.273708938676859','test','test','1.5'),('2018-11-02 15:59:59','2018-11-03 03:59:59','ETHBTC','4h','0.031463000000000','0.031384000000000','0.040101310702087','0.040000620890389','1.274554578459997','1.274554578459997','test','test','0.3'),('2018-11-04 07:59:59','2018-11-13 11:59:59','ETHBTC','4h','0.031534000000000','0.032804000000000','0.040078935188376','0.041693073822524','1.2709753024791088','1.270975302479109','test','test','0.0'),('2018-11-13 15:59:59','2018-11-13 19:59:59','ETHBTC','4h','0.032843000000000','0.032504000000000','0.040437632662631','0.040020242123623','1.231240528046504','1.231240528046504','test','test','1.0'),('2018-12-17 19:59:59','2018-12-18 07:59:59','ETHBTC','4h','0.026991000000000','0.026666000000000','0.040344879209518','0.039859084472639','1.494753036549903','1.494753036549903','test','test','1.2'),('2018-12-18 11:59:59','2018-12-18 19:59:59','ETHBTC','4h','0.026757000000000','0.026509000000000','0.040236924823545','0.039863984757161','1.5037905902584494','1.503790590258449','test','test','0.9'),('2018-12-18 23:59:59','2019-01-02 07:59:59','ETHBTC','4h','0.027493000000000','0.038058000000000','0.040154049253238','0.055584432636661','1.4605190140485858','1.460519014048586','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:45:42
