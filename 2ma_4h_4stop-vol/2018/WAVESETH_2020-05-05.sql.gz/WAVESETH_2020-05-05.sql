-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-07 23:59:59','2018-06-09 03:59:59','WAVESETH','4h','0.007544000000000','0.007426000000000','1.297777777777778','1.277478496524096','172.02780723459406','172.027807234594064','test','test','1.6'),('2018-06-09 11:59:59','2018-06-09 19:59:59','WAVESETH','4h','0.007555000000000','0.007411000000000','1.293266826388071','1.268616869670681','171.18025498187566','171.180254981875663','test','test','1.9'),('2018-06-13 03:59:59','2018-06-13 07:59:59','WAVESETH','4h','0.007534000000000','0.007283000000000','1.287789058228651','1.244885546997514','170.9303236300306','170.930323630030614','test','test','3.3'),('2018-06-13 11:59:59','2018-06-13 15:59:59','WAVESETH','4h','0.007408000000000','0.007159000000000','1.278254944621731','1.235289841866492','172.55061347485574','172.550613474855737','test','test','3.4'),('2018-06-18 19:59:59','2018-06-18 23:59:59','WAVESETH','4h','0.007108000000000','0.007038000000000','1.268707144009456','1.256212841803398','178.4900315151176','178.490031515117607','test','test','1.0'),('2018-06-30 11:59:59','2018-06-30 15:59:59','WAVESETH','4h','0.006394000000000','0.006296000000000','1.265930632408110','1.246527879518527','197.98727438350164','197.987274383501642','test','test','1.5'),('2018-07-02 15:59:59','2018-07-05 07:59:59','WAVESETH','4h','0.006500000000000','0.006379000000000','1.261618909543758','1.238133388304559','194.09521685288584','194.095216852885841','test','test','1.9'),('2018-07-15 07:59:59','2018-07-15 11:59:59','WAVESETH','4h','0.006251000000000','0.006161000000000','1.256399904823936','1.238310640476767','200.99182607965705','200.991826079657045','test','test','1.4'),('2018-07-17 19:59:59','2018-07-17 23:59:59','WAVESETH','4h','0.006405000000000','0.006188000000000','1.252380068302343','1.209949705332537','195.5316265889684','195.531626588968408','test','test','3.4'),('2018-07-18 03:59:59','2018-07-18 07:59:59','WAVESETH','4h','0.006263000000000','0.006246000000000','1.242951098753497','1.239577289288575','198.45938028955723','198.459380289557231','test','test','0.3'),('2018-07-18 15:59:59','2018-07-19 03:59:59','WAVESETH','4h','0.006382000000000','0.006279000000000','1.242201363316848','1.222153299947742','194.6413919330692','194.641391933069201','test','test','1.6'),('2018-07-19 19:59:59','2018-07-19 23:59:59','WAVESETH','4h','0.006290000000000','0.006166000000000','1.237746238123713','1.213345517372149','196.78000606100366','196.780006061003661','test','test','2.0'),('2018-07-20 11:59:59','2018-07-21 03:59:59','WAVESETH','4h','0.006569000000000','0.006306240000000','1.232323855734477','1.183030901505098','187.59687254292535','187.596872542925354','test','test','4.0'),('2018-07-21 07:59:59','2018-07-21 11:59:59','WAVESETH','4h','0.006256000000000','0.006275000000000','1.221369865905726','1.225079269270849','195.23175605909938','195.231756059099382','test','test','0.0'),('2018-08-10 11:59:59','2018-08-11 03:59:59','WAVESETH','4h','0.005050000000000','0.005474000000000','1.222194177764642','1.324810084967059','242.01864906230534','242.018649062305343','test','test','0.3'),('2018-08-11 07:59:59','2018-08-28 19:59:59','WAVESETH','4h','0.005511000000000','0.007710000000000','1.244997712698513','1.741776876230364','225.91139769524813','225.911397695248127','test','test','0.0'),('2018-08-29 11:59:59','2018-08-29 15:59:59','WAVESETH','4h','0.007810000000000','0.007593000000000','1.355393082372257','1.317733633092516','173.54584921539782','173.545849215397823','test','test','2.8'),('2018-08-31 15:59:59','2018-08-31 19:59:59','WAVESETH','4h','0.007679000000000','0.007477000000000','1.347024315865648','1.311590156234855','175.41663183560982','175.416631835609820','test','test','2.6'),('2018-09-03 19:59:59','2018-09-15 15:59:59','WAVESETH','4h','0.007723000000000','0.010380000000000','1.339150058169916','1.799867616703837','173.397650934859','173.397650934859001','test','test','0.1'),('2018-09-18 07:59:59','2018-09-18 15:59:59','WAVESETH','4h','0.010499000000000','0.010373000000000','1.441531737844121','1.424231709368232','137.30181330070684','137.301813300706840','test','test','1.2'),('2018-09-19 03:59:59','2018-09-20 15:59:59','WAVESETH','4h','0.010698000000000','0.010460000000000','1.437687287071701','1.405702843781080','134.38841718748375','134.388417187483753','test','test','2.2'),('2018-09-26 11:59:59','2018-09-26 15:59:59','WAVESETH','4h','0.010003000000000','0.009965000000000','1.430579633007119','1.425145060773362','143.01505878307694','143.015058783076938','test','test','0.4'),('2018-09-26 19:59:59','2018-09-27 19:59:59','WAVESETH','4h','0.010327000000000','0.009928000000000','1.429371950288506','1.374145901274745','138.41115041042957','138.411150410429570','test','test','3.9'),('2018-10-05 19:59:59','2018-10-05 23:59:59','WAVESETH','4h','0.009863000000000','0.009644000000000','1.417099494952115','1.385633937880786','143.67834279145438','143.678342791454384','test','test','2.2'),('2018-10-06 03:59:59','2018-10-06 07:59:59','WAVESETH','4h','0.009701000000000','0.009675000000000','1.410107148936264','1.406327869906026','145.35688577840054','145.356885778400539','test','test','0.3'),('2018-10-11 23:59:59','2018-10-12 11:59:59','WAVESETH','4h','0.009728000000000','0.009638000000000','1.409267309151766','1.396229268668248','144.8671164835286','144.867116483528605','test','test','1.5'),('2018-10-14 23:59:59','2018-10-15 07:59:59','WAVESETH','4h','0.009629000000000','0.009420000000000','1.406369966822096','1.375844333520006','146.05566173248474','146.055661732484737','test','test','2.2'),('2018-10-16 15:59:59','2018-10-16 19:59:59','WAVESETH','4h','0.009594000000000','0.009570000000000','1.399586492754965','1.396085338301544','145.8814355592','145.881435559200014','test','test','0.3'),('2018-10-17 07:59:59','2018-10-19 15:59:59','WAVESETH','4h','0.009749000000000','0.009649000000000','1.398808458431982','1.384460233399343','143.48225032639058','143.482250326390584','test','test','1.0'),('2018-10-20 19:59:59','2018-10-20 23:59:59','WAVESETH','4h','0.009663000000000','0.009590000000000','1.395619963980285','1.385076627814440','144.4292625458227','144.429262545822695','test','test','0.8'),('2018-10-21 19:59:59','2018-10-22 03:59:59','WAVESETH','4h','0.009710000000000','0.009657000000000','1.393277000387875','1.385672089881124','143.48887748587794','143.488877485877936','test','test','0.5'),('2018-10-23 11:59:59','2018-10-23 23:59:59','WAVESETH','4h','0.009829000000000','0.009700000000000','1.391587020275263','1.373323237020048','141.57971515670602','141.579715156706015','test','test','1.6'),('2018-10-24 03:59:59','2018-10-24 11:59:59','WAVESETH','4h','0.009701000000000','0.009660000000000','1.387528401774104','1.381664195561060','143.02941983033753','143.029419830337531','test','test','0.4'),('2018-10-24 19:59:59','2018-10-24 23:59:59','WAVESETH','4h','0.009695000000000','0.009692000000000','1.386225244837872','1.385796294272166','142.9835219017919','142.983521901791903','test','test','0.0'),('2018-11-18 15:59:59','2018-11-18 19:59:59','WAVESETH','4h','0.008547000000000','0.008618000000000','1.386129922489937','1.397644515270654','162.17736310868577','162.177363108685768','test','test','0.0'),('2018-11-19 03:59:59','2018-11-20 07:59:59','WAVESETH','4h','0.008747000000000','0.008498000000000','1.388688720885653','1.349157053856897','158.76171497492314','158.761714974923137','test','test','2.8'),('2018-11-23 07:59:59','2018-12-22 07:59:59','WAVESETH','4h','0.008808000000000','0.029594000000000','1.379903905990373','4.636339259068926','156.66483946303057','156.664839463030575','test','test','0.1'),('2018-12-22 15:59:59','2018-12-23 03:59:59','WAVESETH','4h','0.033614000000000','0.032269440000000','2.103556206674496','2.019413958407516','62.57976458245066','62.579764582450657','test','test','4.0'),('2018-12-23 11:59:59','2018-12-23 15:59:59','WAVESETH','4h','0.029401000000000','0.029250000000000','2.084857929281834','2.074150349698774','70.91112306662474','70.911123066624739','test','test','0.5'),('2019-01-13 19:59:59','2019-01-14 19:59:59','WAVESETH','4h','0.022350000000000','0.021470000000000','2.082478467152265','2.000483789250968','93.17577034238323','93.175770342383231','test','test','3.9'),('2019-01-16 11:59:59','2019-01-16 15:59:59','WAVESETH','4h','0.021248000000000','0.021219000000000','2.064257427618644','2.061440058200302','97.15066959801598','97.150669598015980','test','test','0.1'),('2019-01-17 03:59:59','2019-01-17 07:59:59','WAVESETH','4h','0.021201000000000','0.021135000000000','2.063631345525679','2.057207135874970','97.33650985923677','97.336509859236770','test','test','0.3'),('2019-01-17 11:59:59','2019-01-17 19:59:59','WAVESETH','4h','0.021167000000000','0.021083000000000','2.062203743381077','2.054020008584271','97.42541424770053','97.425414247700530','test','test','0.4'),('2019-01-18 11:59:59','2019-01-18 15:59:59','WAVESETH','4h','0.021613000000000','0.021002000000000','2.060385135648453','2.002138001151566','95.33082569048506','95.330825690485057','test','test','2.8'),('2019-01-22 19:59:59','2019-01-24 23:59:59','WAVESETH','4h','0.022779000000000','0.023377000000000','2.047441327982478','2.101191269337829','89.88284507583643','89.882845075836428','test','test','0.0'),('2019-01-25 19:59:59','2019-01-26 19:59:59','WAVESETH','4h','0.024217000000000','0.023248320000000','2.059385759394778','1.977010329018987','85.03884706589497','85.038847065894970','test','test','4.0'),('2019-01-27 11:59:59','2019-01-27 23:59:59','WAVESETH','4h','0.025120000000000','0.024115200000000','2.041080108200158','1.959436903872152','81.25318902070693','81.253189020706927','test','test','4.0'),('2019-01-28 03:59:59','2019-02-01 23:59:59','WAVESETH','4h','0.023161000000000','0.025468000000000','2.022937173905046','2.224436075515466','87.34239341587347','87.342393415873474','test','test','0.0'),('2019-02-03 11:59:59','2019-02-04 07:59:59','WAVESETH','4h','0.026232000000000','0.025434000000000','2.067714707596250','2.004813047918688','78.82413493428828','78.824134934288281','test','test','3.0'),('2019-02-04 11:59:59','2019-02-04 23:59:59','WAVESETH','4h','0.025830000000000','0.025308000000000','2.053736561001236','2.012232477190061','79.50973910186745','79.509739101867453','test','test','2.0'),('2019-02-05 11:59:59','2019-02-05 15:59:59','WAVESETH','4h','0.025361000000000','0.025141000000000','2.044513431265420','2.026777815363902','80.61643591598988','80.616435915989882','test','test','0.9'),('2019-02-28 15:59:59','2019-02-28 19:59:59','WAVESETH','4h','0.019848000000000','0.019465000000000','2.040572183287305','2.001195966731529','102.80996489758691','102.809964897586909','test','test','1.9'),('2019-03-01 07:59:59','2019-03-01 11:59:59','WAVESETH','4h','0.019820000000000','0.019707000000000','2.031821912941576','2.020237862681112','102.51371911915118','102.513719119151176','test','test','0.6'),('2019-03-02 19:59:59','2019-03-03 11:59:59','WAVESETH','4h','0.020053000000000','0.019875000000000','2.029247679550362','2.011235108515606','101.1942192963827','101.194219296382698','test','test','1.0'),('2019-03-03 23:59:59','2019-03-05 15:59:59','WAVESETH','4h','0.020321000000000','0.019571000000000','2.025244885987083','1.950497892015807','99.66265862836885','99.662658628368845','test','test','3.7'),('2019-03-08 15:59:59','2019-03-08 19:59:59','WAVESETH','4h','0.020062000000000','0.019552000000000','2.008634442882355','1.957572556436836','100.12134597160578','100.121345971605777','test','test','2.5'),('2019-03-08 23:59:59','2019-03-09 15:59:59','WAVESETH','4h','0.019865000000000','0.019750000000000','1.997287357005573','1.985724908173172','100.54303332522393','100.543033325223931','test','test','0.6'),('2019-03-09 23:59:59','2019-03-11 23:59:59','WAVESETH','4h','0.019872000000000','0.019897000000000','1.994717923931706','1.997227381867409','100.3783174281253','100.378317428125300','test','test','0.1'),('2019-03-12 01:59:59','2019-03-12 11:59:59','WAVESETH','4h','0.019789000000000','0.020149000000000','1.995275581250752','2.031573484593532','100.8275092854996','100.827509285499602','test','test','0.0'),('2019-03-12 15:59:59','2019-03-16 03:59:59','WAVESETH','4h','0.020391000000000','0.019794000000000','2.003341781993591','1.944688697600958','98.24637251697276','98.246372516972755','test','test','2.9'),('2019-03-20 15:59:59','2019-03-21 03:59:59','WAVESETH','4h','0.020224000000000','0.020035000000000','1.990307763239673','1.971707675855758','98.41316076145534','98.413160761455345','test','test','0.9'),('2019-03-21 11:59:59','2019-03-21 15:59:59','WAVESETH','4h','0.020272000000000','0.020318000000000','1.986174410487692','1.990681317693810','97.97624361127131','97.976243611271315','test','test','0.0'),('2019-03-21 19:59:59','2019-03-22 11:59:59','WAVESETH','4h','0.020252000000000','0.020126000000000','1.987175945422385','1.974812516174745','98.12245434635517','98.122454346355170','test','test','1.1'),('2019-03-24 11:59:59','2019-03-24 19:59:59','WAVESETH','4h','0.020081000000000','0.020108000000000','1.984428516700687','1.987096689100015','98.82119997513506','98.821199975135059','test','test','0.0'),('2019-03-25 15:59:59','2019-03-25 19:59:59','WAVESETH','4h','0.020258000000000','0.020136000000000','1.985021443900538','1.973067025095332','97.98703938693541','97.987039386935407','test','test','0.6'),('2019-04-01 15:59:59','2019-04-02 07:59:59','WAVESETH','4h','0.020357000000000','0.019784000000000','1.982364906388270','1.926566159453040','97.38001210336836','97.380012103368358','test','test','2.8'),('2019-05-07 19:59:59','2019-05-07 23:59:59','WAVESETH','4h','0.013536000000000','0.012994560000000','1.969965184847107','1.891166577453222','145.53525301766456','145.535253017664559','test','test','4.0'),('2019-05-23 19:59:59','2019-05-23 23:59:59','WAVESETH','4h','0.010850000000000','0.013332000000000','1.952454383204022','2.399089570218988','179.94971273769787','179.949712737697865','test','test','0.0'),('2019-05-24 03:59:59','2019-05-24 15:59:59','WAVESETH','4h','0.012079000000000','0.011595840000000','2.051706646985125','1.969638381105720','169.85732651586434','169.857326515864344','test','test','4.0'),('2019-05-25 15:59:59','2019-05-25 19:59:59','WAVESETH','4h','0.010762000000000','0.010755000000000','2.033469254567480','2.032146611491660','188.9490108313956','188.949010831395611','test','test','0.1');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:53:40
