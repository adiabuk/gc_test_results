-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-20 23:59:59','2018-03-21 03:59:59','LINKETH','4h','0.000703000000000','0.000707100000000','1.297777777777778','1.305346609767663','1846.0565828986882','1846.056582898688248','test','test','0.0'),('2018-03-21 07:59:59','2018-03-21 11:59:59','LINKETH','4h','0.000713320000000','0.000722970000000','1.299459740442197','1.317039208977030','1821.7065839205356','1821.706583920535650','test','test','0.0'),('2018-03-21 15:59:59','2018-03-23 07:59:59','LINKETH','4h','0.000775000000000','0.000744000000000','1.303366289005493','1.251231637445273','1681.7629535554745','1681.762953555474496','test','test','4.0'),('2018-03-24 15:59:59','2018-03-26 19:59:59','LINKETH','4h','0.000789830000000','0.000758236800000','1.291780810881000','1.240109578445760','1635.5175302039675','1635.517530203967453','test','test','4.0'),('2018-03-26 23:59:59','2018-03-27 07:59:59','LINKETH','4h','0.000758480000000','0.000749400000000','1.280298314784279','1.264971465429990','1687.9790037763416','1687.979003776341642','test','test','1.2'),('2018-03-27 15:59:59','2018-03-29 11:59:59','LINKETH','4h','0.000770000000000','0.000739200000000','1.276892348261104','1.225816654330660','1658.3017509884473','1658.301750988447338','test','test','4.0'),('2018-04-04 11:59:59','2018-04-04 15:59:59','LINKETH','4h','0.000732030000000','0.000725510000000','1.265542194054339','1.254270340298025','1728.8119258149784','1728.811925814978395','test','test','0.9'),('2018-04-04 19:59:59','2018-04-04 23:59:59','LINKETH','4h','0.000743590000000','0.000767000000000','1.263037337664047','1.302800788052991','1698.5668683872118','1698.566868387211798','test','test','0.0'),('2018-04-05 07:59:59','2018-04-12 23:59:59','LINKETH','4h','0.000737760000000','0.000782410000000','1.271873659972701','1.348848772363968','1723.9666828951163','1723.966682895116264','test','test','0.0'),('2018-04-13 15:59:59','2018-04-13 23:59:59','LINKETH','4h','0.000795000000000','0.000773920000000','1.288979240504094','1.254801023661545','1621.357535225275','1621.357535225274887','test','test','2.7'),('2018-04-16 11:59:59','2018-04-16 15:59:59','LINKETH','4h','0.000794280000000','0.000795000000000','1.281384081205750','1.282545631966777','1613.2649458701587','1613.264945870158726','test','test','0.0'),('2018-04-16 23:59:59','2018-04-20 11:59:59','LINKETH','4h','0.000801680000000','0.000806820000000','1.281642203597089','1.289859498436038','1598.695493959047','1598.695493959047099','test','test','0.0'),('2018-04-29 15:59:59','2018-04-29 23:59:59','LINKETH','4h','0.000763650000000','0.000749980000000','1.283468269116855','1.260493069432671','1680.7022446367514','1680.702244636751402','test','test','1.8'),('2018-04-30 07:59:59','2018-04-30 11:59:59','LINKETH','4h','0.000756820000000','0.000756230000000','1.278362669187037','1.277366086149035','1689.1237932230079','1689.123793223007851','test','test','0.1'),('2018-04-30 15:59:59','2018-05-03 07:59:59','LINKETH','4h','0.000808720000000','0.000783410000000','1.278141206289703','1.238140026732882','1580.4496071442563','1580.449607144256333','test','test','3.1'),('2018-05-07 23:59:59','2018-05-08 23:59:59','LINKETH','4h','0.000765710000000','0.000736540000000','1.269252055277076','1.220899438160371','1657.614573764318','1657.614573764318038','test','test','3.8'),('2018-05-15 15:59:59','2018-05-15 19:59:59','LINKETH','4h','0.000724110000000','0.000727950000000','1.258507029251142','1.265180969663958','1738.005315837568','1738.005315837568105','test','test','0.0'),('2018-06-02 15:59:59','2018-06-02 23:59:59','LINKETH','4h','0.000622050000000','0.000622350000000','1.259990127120656','1.260597790553075','2025.5447747297744','2025.544774729774417','test','test','0.7'),('2018-06-30 03:59:59','2018-07-05 15:59:59','LINKETH','4h','0.000455540000000','0.000484080000000','1.260125163438972','1.339073163975804','2766.222863939438','2766.222863939437957','test','test','1.4'),('2018-07-06 23:59:59','2018-07-10 03:59:59','LINKETH','4h','0.000489000000000','0.000484350000000','1.277669163558268','1.265519548812775','2612.8203753747803','2612.820375374780269','test','test','1.0'),('2018-07-17 15:59:59','2018-07-20 11:59:59','LINKETH','4h','0.000475000000000','0.000472210000000','1.274969249170380','1.267480482422621','2684.145787727116','2684.145787727115930','test','test','0.6'),('2018-07-20 19:59:59','2018-07-20 23:59:59','LINKETH','4h','0.000486540000000','0.000471350000000','1.273305078781989','1.233551915328422','2617.061451847719','2617.061451847719127','test','test','3.1'),('2018-07-25 03:59:59','2018-08-04 15:59:59','LINKETH','4h','0.000501930000000','0.000627750000000','1.264471042458974','1.581439039116253','2519.2179038092445','2519.217903809244490','test','test','2.9'),('2018-08-08 15:59:59','2018-08-08 19:59:59','LINKETH','4h','0.000630040000000','0.000615770000000','1.334908375049481','1.304673560574279','2118.7676576875765','2118.767657687576502','test','test','2.3'),('2018-08-09 03:59:59','2018-08-29 19:59:59','LINKETH','4h','0.000685000000000','0.001090000000000','1.328189527388325','2.113469466939087','1938.9628137055838','1938.962813705583812','test','test','0.0'),('2018-08-31 07:59:59','2018-08-31 11:59:59','LINKETH','4h','0.001132470000000','0.001105440000000','1.502696180621827','1.466829554784315','1326.919194876533','1326.919194876533084','test','test','2.4'),('2018-08-31 23:59:59','2018-09-01 15:59:59','LINKETH','4h','0.001158760000000','0.001112409600000','1.494725819324603','1.434936786551619','1289.9356375130335','1289.935637513033498','test','test','4.0'),('2018-09-02 07:59:59','2018-09-02 11:59:59','LINKETH','4h','0.001109900000000','0.001074320000000','1.481439367597273','1.433948951614652','1334.750308674','1334.750308674000053','test','test','3.2'),('2018-09-05 19:59:59','2018-09-14 03:59:59','LINKETH','4h','0.001129500000000','0.001231530000000','1.470885941823357','1.603754018533615','1302.245189750648','1302.245189750648024','test','test','0.0'),('2018-09-16 15:59:59','2018-09-16 19:59:59','LINKETH','4h','0.001263740000000','0.001229380000000','1.500412181092303','1.459617268735068','1187.2791722128788','1187.279172212878848','test','test','2.7'),('2018-09-17 19:59:59','2018-09-22 03:59:59','LINKETH','4h','0.001348770000000','0.001420980000000','1.491346645012918','1.571189866048664','1105.7086419574262','1105.708641957426153','test','test','0.0'),('2018-09-24 23:59:59','2018-09-28 19:59:59','LINKETH','4h','0.001470130000000','0.001509950000000','1.509089583020861','1.549964843845339','1026.5007740953938','1026.500774095393808','test','test','0.0'),('2018-10-04 23:59:59','2018-10-05 03:59:59','LINKETH','4h','0.001446960000000','0.001456510000000','1.518172974315190','1.528192983095467','1049.21557908663','1049.215579086629987','test','test','0.0'),('2018-10-05 15:59:59','2018-10-08 23:59:59','LINKETH','4h','0.001535680000000','0.001502140000000','1.520399642933029','1.487193373382098','990.049777904921','990.049777904921029','test','test','2.7'),('2018-10-09 19:59:59','2018-10-15 07:59:59','LINKETH','4h','0.001489320000000','0.001574720000000','1.513020471921711','1.599779495034349','1015.9136195859257','1015.913619585925744','test','test','0.2'),('2018-10-15 11:59:59','2018-11-04 19:59:59','LINKETH','4h','0.001565730000000','0.002363900000000','1.532300254835630','2.313428606723985','978.6490996759533','978.649099675953266','test','test','0.0'),('2018-11-08 07:59:59','2018-11-08 11:59:59','LINKETH','4h','0.002407460000000','0.002343030000000','1.705884333033043','1.660230354326307','708.5826277624728','708.582627762472839','test','test','2.7'),('2018-11-08 15:59:59','2018-11-08 23:59:59','LINKETH','4h','0.002398420000000','0.002341640000000','1.695739004431546','1.655594217166753','707.0233755687268','707.023375568726806','test','test','2.4'),('2018-11-10 03:59:59','2018-11-19 19:59:59','LINKETH','4h','0.002416070000000','0.002755250000000','1.686817940594925','1.923621886296410','698.1660053702603','698.166005370260336','test','test','0.1'),('2018-11-19 23:59:59','2018-11-20 03:59:59','LINKETH','4h','0.002768360000000','0.002750510000000','1.739441039639700','1.728225365898724','628.3290611191102','628.329061119110179','test','test','0.6'),('2018-11-20 07:59:59','2018-11-20 11:59:59','LINKETH','4h','0.002758140000000','0.002647814400000','1.736948667697261','1.667470720989370','629.7536266096937','629.753626609693697','test','test','4.0'),('2018-11-22 15:59:59','2018-11-22 23:59:59','LINKETH','4h','0.002800010000000','0.002703700000000','1.721509123984396','1.662295569843183','614.8224913426724','614.822491342672379','test','test','3.4'),('2018-11-27 11:59:59','2018-11-27 15:59:59','LINKETH','4h','0.002893880000000','0.002778124800000','1.708350556397460','1.640016534141562','590.332203269472','590.332203269471961','test','test','4.0'),('2018-11-29 15:59:59','2018-11-29 23:59:59','LINKETH','4h','0.003130000000000','0.003004800000000','1.693165218118371','1.625438609393636','540.9473540314285','540.947354031428517','test','test','4.0'),('2018-11-30 03:59:59','2018-11-30 11:59:59','LINKETH','4h','0.003175000000000','0.003048000000000','1.678114860623986','1.610990266199027','528.5401135823577','528.540113582357662','test','test','4.0'),('2018-11-30 15:59:59','2018-12-01 15:59:59','LINKETH','4h','0.002890480000000','0.002868130000000','1.663198284085106','1.650337969656602','575.4055672708706','575.405567270870620','test','test','2.4'),('2018-12-08 19:59:59','2018-12-08 23:59:59','LINKETH','4h','0.002741280000000','0.002631628800000','1.660340436434327','1.593926818976954','605.6807171957361','605.680717195736065','test','test','4.0'),('2018-12-12 07:59:59','2018-12-12 15:59:59','LINKETH','4h','0.002601070000000','0.002555680000000','1.645581854777133','1.616865610928127','632.655735823001','632.655735823001010','test','test','1.7'),('2018-12-18 11:59:59','2018-12-22 03:59:59','LINKETH','4h','0.002571230000000','0.002650300000000','1.639200467255132','1.689608863604686','637.5160787853019','637.516078785301943','test','test','0.0'),('2019-01-03 11:59:59','2019-01-26 19:59:59','LINKETH','4h','0.002312050000000','0.004074820000000','1.650402333110588','2.908714100043548','713.8264021585123','713.826402158512337','test','test','0.0'),('2019-01-26 23:59:59','2019-01-27 03:59:59','LINKETH','4h','0.004049580000000','0.003904210000000','1.930027170206801','1.860743923615065','476.5993436867037','476.599343686703719','test','test','3.6'),('2019-01-29 07:59:59','2019-01-29 15:59:59','LINKETH','4h','0.004022410000000','0.004109550000000','1.914630893186416','1.956108747515603','475.99098380980956','475.990983809809563','test','test','0.0'),('2019-01-29 19:59:59','2019-01-30 15:59:59','LINKETH','4h','0.004291500000000','0.004119840000000','1.923848194148458','1.846894266382519','448.292716800293','448.292716800293022','test','test','4.0'),('2019-02-05 19:59:59','2019-02-06 07:59:59','LINKETH','4h','0.003894150000000','0.003935530000000','1.906747321311582','1.927008791505558','489.64403562050313','489.644035620503132','test','test','0.0'),('2019-02-06 11:59:59','2019-02-06 15:59:59','LINKETH','4h','0.003969940000000','0.003840810000000','1.911249870243577','1.849082760477547','481.43041714574446','481.430417145744457','test','test','3.3'),('2019-02-08 03:59:59','2019-02-08 11:59:59','LINKETH','4h','0.003946080000000','0.003885270000000','1.897434956962237','1.868195048056976','480.8404687594364','480.840468759436419','test','test','1.5'),('2019-02-09 15:59:59','2019-02-09 19:59:59','LINKETH','4h','0.004048190000000','0.003886262400000','1.890937199427735','1.815299711450626','467.1068303186695','467.106830318669495','test','test','4.0'),('2019-02-10 07:59:59','2019-02-10 19:59:59','LINKETH','4h','0.003979650000000','0.003836520000000','1.874128868766155','1.806724935006528','470.9280637156922','470.928063715692190','test','test','3.6'),('2019-02-25 15:59:59','2019-02-25 19:59:59','LINKETH','4h','0.003348290000000','0.003214830000000','1.859150216819571','1.785046065764334','555.2536419544218','555.253641954421823','test','test','4.0'),('2019-02-25 23:59:59','2019-02-26 07:59:59','LINKETH','4h','0.003429610000000','0.003292425600000','1.842682627696185','1.768975322588338','537.2863467555159','537.286346755515865','test','test','4.0'),('2019-03-03 15:59:59','2019-03-03 19:59:59','LINKETH','4h','0.003199200000000','0.003236060000000','1.826303226561108','1.847345217349756','570.8624739188258','570.862473918825799','test','test','0.0'),('2019-03-03 23:59:59','2019-03-04 07:59:59','LINKETH','4h','0.003220140000000','0.003198670000000','1.830979224514141','1.818771331705034','568.6023665164063','568.602366516406278','test','test','0.7'),('2019-03-04 11:59:59','2019-03-04 15:59:59','LINKETH','4h','0.003220300000000','0.003249100000000','1.828266359445450','1.844617032100802','567.7316894219327','567.731689421932742','test','test','0.0'),('2019-03-04 19:59:59','2019-03-04 23:59:59','LINKETH','4h','0.003264070000000','0.003208290000000','1.831899842257750','1.800594333123100','561.2317880001809','561.231788000180927','test','test','1.7'),('2019-03-05 07:59:59','2019-03-05 15:59:59','LINKETH','4h','0.003274870000000','0.003143875200000','1.824943062450051','1.751945339952049','557.2566429965314','557.256642996531355','test','test','4.0'),('2019-03-07 19:59:59','2019-03-15 19:59:59','LINKETH','4h','0.003401970000000','0.003569070000000','1.808721346339383','1.897563204725351','531.668811406151','531.668811406151008','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:44:36
