-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-22 03:59:59','2018-04-25 03:59:59','ENJBTC','4h','0.000015270000000','0.000015200000000','0.033333333333333','0.033180528268937','2182.9294913774283','2182.929491377428349','test','test','0.5'),('2018-04-25 07:59:59','2018-04-25 11:59:59','ENJBTC','4h','0.000015490000000','0.000015020000000','0.033299376652356','0.032289001763614','2149.7338058332116','2149.733805833211591','test','test','3.0'),('2018-04-26 15:59:59','2018-05-05 15:59:59','ENJBTC','4h','0.000015850000000','0.000016850000000','0.033074848899303','0.035161590154780','2086.7412554765087','2086.741255476508741','test','test','0.5'),('2018-05-07 23:59:59','2018-05-08 07:59:59','ENJBTC','4h','0.000016750000000','0.000016930000000','0.033538569178298','0.033898983653050','2002.3026375103018','2002.302637510301793','test','test','0.0'),('2018-05-10 19:59:59','2018-05-10 23:59:59','ENJBTC','4h','0.000017130000000','0.000016970000000','0.033618661283798','0.033304651604556','1962.5604952596614','1962.560495259661366','test','test','0.9'),('2018-05-14 15:59:59','2018-05-14 19:59:59','ENJBTC','4h','0.000016910000000','0.000016550000000','0.033548881355078','0.032834653248169','1983.9669636355738','1983.966963635573848','test','test','2.1'),('2018-05-15 11:59:59','2018-05-15 15:59:59','ENJBTC','4h','0.000016700000000','0.000016630000000','0.033390163997987','0.033250205226738','1999.411017843513','1999.411017843513036','test','test','0.4'),('2018-05-19 03:59:59','2018-05-19 11:59:59','ENJBTC','4h','0.000016620000000','0.000016300000000','0.033359062048820','0.032716769638734','2007.1637815174622','2007.163781517462212','test','test','1.9'),('2018-05-19 15:59:59','2018-05-21 03:59:59','ENJBTC','4h','0.000017080000000','0.000016580000000','0.033216330402134','0.032243955390362','1944.7500235441714','1944.750023544171427','test','test','2.9'),('2018-05-21 11:59:59','2018-05-22 23:59:59','ENJBTC','4h','0.000017060000000','0.000016377600000','0.033000247066185','0.031680237183538','1934.3638374082714','1934.363837408271365','test','test','4.0'),('2018-06-07 15:59:59','2018-06-07 19:59:59','ENJBTC','4h','0.000014400000000','0.000014080000000','0.032706911536708','0.031980091280337','2271.3133011602777','2271.313301160277661','test','test','2.2'),('2018-06-07 23:59:59','2018-06-08 11:59:59','ENJBTC','4h','0.000014780000000','0.000014188800000','0.032545395924181','0.031243580087214','2201.988898794392','2201.988898794391844','test','test','4.0'),('2018-07-02 15:59:59','2018-07-03 03:59:59','ENJBTC','4h','0.000009520000000','0.000009530000000','0.032256103515966','0.032289985977642','3388.24616764351','3388.246167643510034','test','test','0.0'),('2018-07-04 11:59:59','2018-07-05 19:59:59','ENJBTC','4h','0.000009490000000','0.000009560000000','0.032263632951894','0.032501615492108','3399.750574488327','3399.750574488326947','test','test','0.0'),('2018-07-07 11:59:59','2018-07-07 15:59:59','ENJBTC','4h','0.000009800000000','0.000009408000000','0.032316517960831','0.031023857242398','3297.6038735541492','3297.603873554149231','test','test','4.0'),('2018-07-07 23:59:59','2018-07-08 03:59:59','ENJBTC','4h','0.000009700000000','0.000009880000000','0.032029260023401','0.032623617425897','3301.985569422794','3301.985569422794015','test','test','0.0'),('2018-07-09 11:59:59','2018-07-09 15:59:59','ENJBTC','4h','0.000009630000000','0.000009870000000','0.032161339446178','0.032962868155117','3339.702953912565','3339.702953912565135','test','test','0.0'),('2018-07-09 19:59:59','2018-07-10 07:59:59','ENJBTC','4h','0.000010260000000','0.000009849600000','0.032339456937053','0.031045878659571','3151.99385351397','3151.993853513969952','test','test','4.0'),('2018-07-10 11:59:59','2018-07-11 23:59:59','ENJBTC','4h','0.000009650000000','0.000009630000000','0.032051995097613','0.031985566092229','3321.450269182682','3321.450269182681950','test','test','0.2'),('2018-08-07 11:59:59','2018-08-07 19:59:59','ENJBTC','4h','0.000007310000000','0.000007070000000','0.032037233096416','0.030985395074099','4382.6584263223585','4382.658426322358537','test','test','3.3'),('2018-08-07 23:59:59','2018-08-08 03:59:59','ENJBTC','4h','0.000007190000000','0.000007210000000','0.031803491313679','0.031891957214412','4423.295036673065','4423.295036673064715','test','test','0.0'),('2018-08-17 23:59:59','2018-08-18 03:59:59','ENJBTC','4h','0.000006520000000','0.000006450000000','0.031823150402731','0.031481490812518','4880.85128876244','4880.851288762440163','test','test','1.1'),('2018-08-28 03:59:59','2018-08-28 07:59:59','ENJBTC','4h','0.000005810000000','0.000005820000000','0.031747226049350','0.031801868434977','5464.23856271092','5464.238562710919723','test','test','0.0'),('2018-08-28 11:59:59','2018-08-29 15:59:59','ENJBTC','4h','0.000005830000000','0.000005910000000','0.031759368801712','0.032195174891615','5447.576123792795','5447.576123792795443','test','test','0.0'),('2018-08-30 07:59:59','2018-09-05 11:59:59','ENJBTC','4h','0.000006130000000','0.000006390000000','0.031856214599468','0.033207375414454','5196.772365329238','5196.772365329237800','test','test','2.1'),('2018-09-05 15:59:59','2018-09-05 23:59:59','ENJBTC','4h','0.000006740000000','0.000006470400000','0.032156472558354','0.030870213656020','4770.989993821068','4770.989993821068310','test','test','4.0'),('2018-09-06 11:59:59','2018-09-08 19:59:59','ENJBTC','4h','0.000006710000000','0.000006650000000','0.031870637246724','0.031585653903236','4749.722391464115','4749.722391464115390','test','test','0.9'),('2018-09-15 03:59:59','2018-09-15 23:59:59','ENJBTC','4h','0.000006500000000','0.000006500000000','0.031807307614838','0.031807307614838','4893.431940744308','4893.431940744308122','test','test','0.0'),('2018-09-17 03:59:59','2018-09-17 15:59:59','ENJBTC','4h','0.000006790000000','0.000006518400000','0.031807307614838','0.030535015310244','4684.434111169072','4684.434111169071912','test','test','4.0'),('2018-09-18 15:59:59','2018-09-18 19:59:59','ENJBTC','4h','0.000006420000000','0.000006350000000','0.031524575991595','0.031180850085145','4910.370092148735','4910.370092148735239','test','test','1.1'),('2018-09-19 03:59:59','2018-09-19 07:59:59','ENJBTC','4h','0.000006400000000','0.000006340000000','0.031448192456828','0.031153365652545','4913.7800713794095','4913.780071379409492','test','test','0.9'),('2018-09-20 11:59:59','2018-09-20 23:59:59','ENJBTC','4h','0.000006490000000','0.000006480000000','0.031382675389210','0.031334319957177','4835.543203268071','4835.543203268071011','test','test','0.9'),('2018-09-21 03:59:59','2018-09-21 15:59:59','ENJBTC','4h','0.000006410000000','0.000006240000000','0.031371929737647','0.030539912880330','4894.216807745224','4894.216807745224287','test','test','2.7'),('2018-09-21 19:59:59','2018-09-21 23:59:59','ENJBTC','4h','0.000006520000000','0.000006450000000','0.031187037102688','0.030852206949745','4783.287899185208','4783.287899185207607','test','test','1.1'),('2018-09-22 03:59:59','2018-09-22 07:59:59','ENJBTC','4h','0.000006460000000','0.000006310000000','0.031112630402034','0.030390200903535','4816.19665666154','4816.196656661540146','test','test','2.3'),('2018-09-22 19:59:59','2018-09-24 07:59:59','ENJBTC','4h','0.000006630000000','0.000006430000000','0.030952090513478','0.030018392458773','4668.490273526126','4668.490273526125748','test','test','3.0'),('2018-09-27 07:59:59','2018-09-27 11:59:59','ENJBTC','4h','0.000006460000000','0.000006530000000','0.030744602056877','0.031077747899599','4759.226324593979','4759.226324593979371','test','test','0.0'),('2018-09-27 15:59:59','2018-10-07 07:59:59','ENJBTC','4h','0.000006520000000','0.000008180000000','0.030818634466371','0.038665096615784','4726.784427357497','4726.784427357497407','test','test','0.0'),('2018-10-08 19:59:59','2018-10-08 23:59:59','ENJBTC','4h','0.000008160000000','0.000008120000000','0.032562292721796','0.032402673639826','3990.4770492397056','3990.477049239705593','test','test','0.5'),('2018-10-10 15:59:59','2018-10-11 03:59:59','ENJBTC','4h','0.000008310000000','0.000008080000000','0.032526821814692','0.031626560801770','3914.1783170507288','3914.178317050728765','test','test','2.8'),('2018-10-14 15:59:59','2018-10-14 19:59:59','ENJBTC','4h','0.000008030000000','0.000007970000000','0.032326763811820','0.032085218876738','4025.74891803487','4025.748918034869803','test','test','0.7'),('2018-10-20 15:59:59','2018-10-21 23:59:59','ENJBTC','4h','0.000008040000000','0.000007718400000','0.032273087159580','0.030982163673197','4014.0655671118857','4014.065567111885684','test','test','4.0'),('2018-10-24 11:59:59','2018-10-24 15:59:59','ENJBTC','4h','0.000007810000000','0.000007860000000','0.031986215273717','0.032190992580207','4095.5461297972683','4095.546129797268350','test','test','0.0'),('2018-10-24 23:59:59','2018-10-25 23:59:59','ENJBTC','4h','0.000008200000000','0.000007872000000','0.032031721341826','0.030750452488153','3906.3074807104344','3906.307480710434447','test','test','4.0'),('2018-10-31 19:59:59','2018-11-02 23:59:59','ENJBTC','4h','0.000007730000000','0.000007810000000','0.031746994929898','0.032075553739004','4106.985113829006','4106.985113829005968','test','test','0.0'),('2018-11-03 03:59:59','2018-11-03 11:59:59','ENJBTC','4h','0.000007920000000','0.000007770000000','0.031820007998588','0.031217356331948','4017.67777759955','4017.677777599550154','test','test','1.9'),('2018-11-08 19:59:59','2018-11-09 11:59:59','ENJBTC','4h','0.000007710000000','0.000007800000000','0.031686085406002','0.032055961889341','4109.738703761579','4109.738703761579018','test','test','0.0'),('2018-11-09 15:59:59','2018-11-11 15:59:59','ENJBTC','4h','0.000007930000000','0.000007770000000','0.031768280180077','0.031127306052862','4006.0882950916907','4006.088295091690725','test','test','2.0'),('2018-11-12 07:59:59','2018-11-12 19:59:59','ENJBTC','4h','0.000008040000000','0.000007810000000','0.031625841485140','0.030721122139172','3933.5623737736883','3933.562373773688250','test','test','2.9'),('2018-11-13 15:59:59','2018-11-13 19:59:59','ENJBTC','4h','0.000007870000000','0.000007800000000','0.031424792741592','0.031145283784551','3992.9851005834826','3992.985100583482563','test','test','0.9'),('2018-11-28 11:59:59','2018-11-28 15:59:59','ENJBTC','4h','0.000006960000000','0.000006681600000','0.031362679640027','0.030108172454426','4506.132132187835','4506.132132187834941','test','test','4.0'),('2018-11-28 19:59:59','2018-11-28 23:59:59','ENJBTC','4h','0.000006380000000','0.000006350000000','0.031083900265449','0.030937737725016','4872.0846811049105','4872.084681104910487','test','test','0.5'),('2018-11-29 11:59:59','2018-11-29 15:59:59','ENJBTC','4h','0.000006480000000','0.000006220800000','0.031051419700909','0.029809362912873','4791.885756313066','4791.885756313065940','test','test','4.0'),('2018-12-01 23:59:59','2018-12-02 11:59:59','ENJBTC','4h','0.000007160000000','0.000006873600000','0.030775407081345','0.029544390798091','4298.241212478368','4298.241212478367743','test','test','4.0'),('2018-12-04 07:59:59','2018-12-05 07:59:59','ENJBTC','4h','0.000007220000000','0.000007220000000','0.030501847907289','0.030501847907289','4224.632674139704','4224.632674139704250','test','test','3.0'),('2018-12-06 03:59:59','2018-12-06 15:59:59','ENJBTC','4h','0.000006860000000','0.000006820000000','0.030501847907289','0.030323994566722','4446.333514182021','4446.333514182020735','test','test','0.6'),('2018-12-07 03:59:59','2018-12-30 23:59:59','ENJBTC','4h','0.000006810000000','0.000010470000000','0.030462324942718','0.046834147158628','4473.1754688279325','4473.175468827932491','test','test','0.0'),('2018-12-31 03:59:59','2018-12-31 07:59:59','ENJBTC','4h','0.000010710000000','0.000010650000000','0.034100507657365','0.033909468398780','3183.9876430779536','3183.987643077953635','test','test','0.6'),('2019-01-02 03:59:59','2019-01-02 07:59:59','ENJBTC','4h','0.000010600000000','0.000010490000000','0.034058054488790','0.033704621847869','3213.024008376456','3213.024008376456095','test','test','1.0'),('2019-01-12 07:59:59','2019-01-12 19:59:59','ENJBTC','4h','0.000010340000000','0.000009926400000','0.033979513901919','0.032620333345842','3286.219913144982','3286.219913144982002','test','test','4.0'),('2019-01-22 15:59:59','2019-01-24 03:59:59','ENJBTC','4h','0.000009650000000','0.000009520000000','0.033677473778346','0.033223787603094','3489.8936557871957','3489.893655787195712','test','test','1.3'),('2019-01-29 23:59:59','2019-01-30 03:59:59','ENJBTC','4h','0.000009350000000','0.000009050000000','0.033576654628290','0.032499328811340','3591.086056501651','3591.086056501651001','test','test','3.2'),('2019-02-10 23:59:59','2019-02-11 03:59:59','ENJBTC','4h','0.000008240000000','0.000008090000000','0.033337248891190','0.032730381496326','4045.782632426025','4045.782632426024975','test','test','1.8'),('2019-02-11 07:59:59','2019-02-17 03:59:59','ENJBTC','4h','0.000008340000000','0.000008460000000','0.033202389470110','0.033680121692702','3981.1018549292035','3981.101854929203455','test','test','0.0'),('2019-02-17 11:59:59','2019-03-16 07:59:59','ENJBTC','4h','0.000008580000000','0.000041040000000','0.033308552186241','0.159322025841880','3882.115639422041','3882.115639422041113','test','test','0.0'),('2019-03-18 11:59:59','2019-03-19 07:59:59','ENJBTC','4h','0.000050800000000','0.000048768000000','0.061311546331939','0.058859084478661','1206.9202033846193','1206.920203384619299','test','test','4.0'),('2019-03-19 19:59:59','2019-03-20 03:59:59','ENJBTC','4h','0.000048000000000','0.000046080000000','0.060766554808988','0.058335892616628','1265.9698918539166','1265.969891853916579','test','test','4.0'),('2019-03-21 19:59:59','2019-03-23 19:59:59','ENJBTC','4h','0.000047960000000','0.000046041600000','0.060226407655130','0.057817351348925','1255.763295561514','1255.763295561514042','test','test','4.0'),('2019-03-24 03:59:59','2019-03-24 11:59:59','ENJBTC','4h','0.000045060000000','0.000045130000000','0.059691061809307','0.059783790933290','1324.7017711785816','1324.701771178581566','test','test','0.0'),('2019-03-25 03:59:59','2019-03-25 07:59:59','ENJBTC','4h','0.000044750000000','0.000043700000000','0.059711668281303','0.058310612377496','1334.3389560067735','1334.338956006773515','test','test','2.3'),('2019-04-13 19:59:59','2019-04-14 23:59:59','ENJBTC','4h','0.000033070000000','0.000031747200000','0.059400322524902','0.057024309623906','1796.199653005792','1796.199653005792015','test','test','4.0'),('2019-04-17 11:59:59','2019-04-20 11:59:59','ENJBTC','4h','0.000031460000000','0.000037730000000','0.058872319658014','0.070605614135310','1871.33883210469','1871.338832104690027','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 15:59:38
