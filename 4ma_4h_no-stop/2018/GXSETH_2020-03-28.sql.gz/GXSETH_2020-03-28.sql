-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-28 19:59:59','2018-06-02 07:59:59','GXSETH','4h','0.005303000000000','0.005830000000000','0.072144500000000','0.079314055251744','13.604469168395246','13.604469168395246','test'),('2018-06-04 03:59:59','2018-06-10 03:59:59','GXSETH','4h','0.005906000000000','0.006498000000000','0.073936888812936','0.081348104217145','12.51894493954216','12.518944939542161','test'),('2018-06-10 11:59:59','2018-06-10 19:59:59','GXSETH','4h','0.006620000000000','0.006472000000000','0.075789692663988','0.074095300743403','11.448594058004266','11.448594058004266','test'),('2018-06-11 07:59:59','2018-06-13 23:59:59','GXSETH','4h','0.006735000000000','0.006787000000000','0.075789692663988','0.076374854359389','11.253109526946993','11.253109526946993','test'),('2018-07-12 11:59:59','2018-07-13 03:59:59','GXSETH','4h','0.005704000000000','0.005722000000000','0.075789692663988','0.076028860698341','13.287113019633239','13.287113019633239','test'),('2018-07-13 07:59:59','2018-07-24 11:59:59','GXSETH','4h','0.005777000000000','0.006489000000000','0.075789692663988','0.085130572216828','13.119212855113034','13.119212855113034','test'),('2018-08-28 11:59:59','2018-08-28 15:59:59','GXSETH','4h','0.005087000000000','0.005188000000000','0.077907397004491','0.079454211845744','15.314998428246609','15.314998428246609','test'),('2018-08-28 19:59:59','2018-08-29 19:59:59','GXSETH','4h','0.005200000000000','0.005082000000000','0.078294100714804','0.076517426890891','15.056557829769952','15.056557829769952','test'),('2018-08-30 03:59:59','2018-08-30 07:59:59','GXSETH','4h','0.005109000000000','0.005043000000000','0.078294100714804','0.077282667822422','15.324740793659034','15.324740793659034','test'),('2018-08-31 15:59:59','2018-09-01 15:59:59','GXSETH','4h','0.005146000000000','0.005081000000000','0.078294100714804','0.077305154631154','15.214555133075008','15.214555133075008','test'),('2018-09-01 19:59:59','2018-09-01 23:59:59','GXSETH','4h','0.005101000000000','0.005140000000000','0.078294100714804','0.078892702935521','15.34877489017918','15.348774890179181','test'),('2018-09-02 07:59:59','2018-09-02 11:59:59','GXSETH','4h','0.005102000000000','0.005066000000000','0.078294100714804','0.077741653120580','15.345766506233634','15.345766506233634','test'),('2018-09-03 15:59:59','2018-09-03 19:59:59','GXSETH','4h','0.005190000000000','0.005119000000000','0.078294100714804','0.077223025348571','15.08556853849788','15.085568538497879','test'),('2018-09-04 03:59:59','2018-09-05 11:59:59','GXSETH','4h','0.005100000000000','0.005129000000000','0.078294100714804','0.078739302463967','15.351784453883136','15.351784453883136','test'),('2018-09-05 15:59:59','2018-09-06 03:59:59','GXSETH','4h','0.005151000000000','0.005070000000000','0.078294100714804','0.077062918001176','15.199786588003105','15.199786588003105','test'),('2018-09-07 03:59:59','2018-09-12 23:59:59','GXSETH','4h','0.005273000000000','0.005497000000000','0.078294100714804','0.081620078063584','14.848113164195714','14.848113164195714','test'),('2018-09-23 07:59:59','2018-09-23 11:59:59','GXSETH','4h','0.005267000000000','0.005187000000000','0.078294100714804','0.077104898501555','14.865027665616859','14.865027665616859','test'),('2018-09-23 15:59:59','2018-09-29 11:59:59','GXSETH','4h','0.005219000000000','0.005916000000000','0.078294100714804','0.088750316119713','15.00174376600958','15.001743766009580','test'),('2018-10-04 11:59:59','2018-10-06 15:59:59','GXSETH','4h','0.006230000000000','0.005972000000000','0.080045359723876','0.076730479658264','12.848372347331663','12.848372347331663','test'),('2018-10-08 11:59:59','2018-10-16 03:59:59','GXSETH','4h','0.006164000000000','0.007325000000000','0.080045359723876','0.095122040878876','12.985944147286826','12.985944147286826','test'),('2018-11-04 03:59:59','2018-11-04 11:59:59','GXSETH','4h','0.006896000000000','0.006720000000000','0.082985809996223','0.080867842687735','12.033905161865322','12.033905161865322','test'),('2018-11-17 11:59:59','2018-11-17 19:59:59','GXSETH','4h','0.006270000000000','0.006221000000000','0.082985809996223','0.082337276552871','13.235376394931897','13.235376394931897','test'),('2018-11-18 03:59:59','2018-11-18 07:59:59','GXSETH','4h','0.006172000000000','0.006207000000000','0.082985809996223','0.083456403539623','13.445529811442482','13.445529811442482','test'),('2018-11-18 11:59:59','2018-11-18 15:59:59','GXSETH','4h','0.006230000000000','0.006201000000000','0.082985809996223','0.082599519708921','13.320354734546227','13.320354734546227','test'),('2018-11-19 07:59:59','2018-11-19 15:59:59','GXSETH','4h','0.006362000000000','0.006206000000000','0.082985809996223','0.080950948889745','13.043981451779787','13.043981451779787','test'),('2018-11-20 03:59:59','2018-11-20 07:59:59','GXSETH','4h','0.006286000000000','0.006252000000000','0.082985809996223','0.082536952608397','13.201687877222877','13.201687877222877','test'),('2018-11-20 11:59:59','2018-11-20 15:59:59','GXSETH','4h','0.006303000000000','0.006219000000000','0.082985809996223','0.081879859172856','13.166081230560527','13.166081230560527','test'),('2018-11-20 23:59:59','2018-11-24 23:59:59','GXSETH','4h','0.006270000000000','0.006313000000000','0.082985809996223','0.083554931181205','13.235376394931897','13.235376394931897','test'),('2018-12-01 23:59:59','2018-12-04 07:59:59','GXSETH','4h','0.006340000000000','0.006197000000000','0.082985809996223','0.081114048035740','13.089244478899527','13.089244478899527','test'),('2019-01-11 11:59:59','2019-01-15 03:59:59','GXSETH','4h','0.004139000000000','0.004097000000000','0.082985809996223','0.082143721564273','20.049724570239913','20.049724570239913','test'),('2019-01-16 03:59:59','2019-01-23 23:59:59','GXSETH','4h','0.004331000000000','0.004781000000000','0.082985809996223','0.091608210018920','19.160888939326483','19.160888939326483','test'),('2019-01-25 07:59:59','2019-01-25 15:59:59','GXSETH','4h','0.004926000000000','0.004781000000000','0.083037260996682','0.080593005445623','16.856934834892716','16.856934834892716','test'),('2019-01-27 11:59:59','2019-01-31 11:59:59','GXSETH','4h','0.004869000000000','0.005001000000000','0.083037260996682','0.085288425188829','17.054274182929145','17.054274182929145','test'),('2019-02-02 07:59:59','2019-02-02 11:59:59','GXSETH','4h','0.005137000000000','0.005054000000000','0.083037260996682','0.081695603869424','16.164543701904226','16.164543701904226','test'),('2019-02-04 11:59:59','2019-02-04 19:59:59','GXSETH','4h','0.005135000000000','0.005045000000000','0.083037260996682','0.081581885438804','16.170839531973126','16.170839531973126','test'),('2019-02-04 23:59:59','2019-02-05 11:59:59','GXSETH','4h','0.005090000000000','0.005044000000000','0.083037260996682','0.082286826025003','16.313803732157563','16.313803732157563','test'),('2019-02-05 15:59:59','2019-02-05 19:59:59','GXSETH','4h','0.005092000000000','0.005039000000000','0.083037260996682','0.082172969002805','16.307396110895915','16.307396110895915','test'),('2019-02-06 03:59:59','2019-02-06 23:59:59','GXSETH','4h','0.005146000000000','0.005050000000000','0.083037260996682','0.081488178786095','16.136273026949475','16.136273026949475','test'),('2019-02-07 03:59:59','2019-02-08 11:59:59','GXSETH','4h','0.005075000000000','0.005146000000000','0.083037260996682','0.084198964549542','16.36202187126739','16.362021871267391','test'),('2019-02-26 11:59:59','2019-03-05 15:59:59','GXSETH','4h','0.004677000000000','0.004911000000000','0.083037260996682','0.087191787204342','17.754385502818476','17.754385502818476','test'),('2019-03-08 03:59:59','2019-03-15 03:59:59','GXSETH','4h','0.004996000000000','0.006686000000000','0.083037260996682','0.111126326465936','16.620748798375104','16.620748798375104','test'),('2019-03-17 23:59:59','2019-03-23 15:59:59','GXSETH','4h','0.006793000000000','0.007965000000000','0.089850101499077','0.105351988582386','13.226866112038458','13.226866112038458','test'),('2019-03-28 15:59:59','2019-03-30 03:59:59','GXSETH','4h','0.008095000000000','0.007915000000000','0.093725573269904','0.091641496285521','11.578205468796108','11.578205468796108','test'),('2019-03-30 07:59:59','2019-03-31 07:59:59','GXSETH','4h','0.007983000000000','0.007850000000000','0.093725573269904','0.092164067414349','11.74064553049029','11.740645530490291','test'),('2019-03-31 11:59:59','2019-04-02 07:59:59','GXSETH','4h','0.008001000000000','0.008155000000000','0.093725573269904','0.095529565056376','11.71423237969054','11.714232379690539','test'),('2019-04-02 15:59:59','2019-04-02 19:59:59','GXSETH','4h','0.008025000000000','0.007904000000000','0.093725573269904','0.092312390171380','11.679199161358754','11.679199161358754','test'),('2019-04-13 11:59:59','2019-04-17 19:59:59','GXSETH','4h','0.007938000000000','0.007997000000000','0.093725573269904','0.094422198216103','11.807202477942049','11.807202477942049','test'),('2019-04-22 23:59:59','2019-04-23 15:59:59','GXSETH','4h','0.007823000000000','0.007612000000000','0.093725573269904','0.091197630542057','11.980771222025309','11.980771222025309','test'),('2019-04-23 19:59:59','2019-04-23 23:59:59','GXSETH','4h','0.007629000000000','0.007550000000000','0.093725573269904','0.092755024012030','12.285433643977454','12.285433643977454','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 19:28:37
