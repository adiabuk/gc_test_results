-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-21 11:59:59','2018-03-23 03:59:59','KNCBTC','4h','0.000159800000000','0.000142480000000','0.001467500000000','0.001308444305382','9.183354192740927','9.183354192740927','test'),('2018-03-23 15:59:59','2018-03-26 15:59:59','KNCBTC','4h','0.000151560000000','0.000163260000000','0.001467500000000','0.001580786817102','9.682633940353655','9.682633940353655','test'),('2018-04-09 07:59:59','2018-04-21 11:59:59','KNCBTC','4h','0.000147180000000','0.000176500000000','0.001467500000000','0.001759843389047','9.970784073923086','9.970784073923086','test'),('2018-04-22 15:59:59','2018-05-01 03:59:59','KNCBTC','4h','0.000191000000000','0.000280220000000','0.001529143627883','0.002243437839819','8.005987580537958','8.005987580537958','test'),('2018-05-02 07:59:59','2018-05-03 03:59:59','KNCBTC','4h','0.000294000000000','0.000284890000000','0.001707717180867','0.001654801182507','5.808561839682824','5.808561839682824','test'),('2018-05-15 03:59:59','2018-05-15 15:59:59','KNCBTC','4h','0.000263260000000','0.000252580000000','0.001707717180867','0.001638438067095','6.486808405633214','6.486808405633214','test'),('2018-06-02 07:59:59','2018-06-04 07:59:59','KNCBTC','4h','0.000212770000000','0.000191330000000','0.001707717180867','0.001535637205505','8.026118253828077','8.026118253828077','test'),('2018-07-02 15:59:59','2018-07-03 23:59:59','KNCBTC','4h','0.000146960000000','0.000136900000000','0.001707717180867','0.001590817107109','11.620285661860372','11.620285661860372','test'),('2018-07-04 11:59:59','2018-07-06 15:59:59','KNCBTC','4h','0.000144770000000','0.000144290000000','0.001707717180867','0.001702055066846','11.796070877025626','11.796070877025626','test'),('2018-07-06 19:59:59','2018-07-07 23:59:59','KNCBTC','4h','0.000151590000000','0.000147940000000','0.001707717180867','0.001666598586565','11.26536830178112','11.265368301781120','test'),('2018-07-08 03:59:59','2018-07-09 07:59:59','KNCBTC','4h','0.000151300000000','0.000148500000000','0.001707717180867','0.001676113690408','11.286960878169202','11.286960878169202','test'),('2018-07-19 07:59:59','2018-07-19 11:59:59','KNCBTC','4h','0.000144030000000','0.000143420000000','0.001707717180867','0.001700484607929','11.856676948323267','11.856676948323267','test'),('2018-07-19 15:59:59','2018-07-19 19:59:59','KNCBTC','4h','0.000144000000000','0.000139010000000','0.001707717180867','0.001648540036891','11.859147089354167','11.859147089354167','test'),('2018-07-19 23:59:59','2018-07-20 03:59:59','KNCBTC','4h','0.000141150000000','0.000137000000000','0.001707717180867','0.001657507997016','12.098598518363445','12.098598518363445','test'),('2018-08-24 15:59:59','2018-08-29 19:59:59','KNCBTC','4h','0.000078400000000','0.000079250000000','0.001707717180867','0.001726231971731','21.78210689881378','21.782106898813780','test'),('2018-09-23 07:59:59','2018-09-23 15:59:59','KNCBTC','4h','0.000059850000000','0.000060080000000','0.001707717180867','0.001714279836700','28.533286230025066','28.533286230025066','test'),('2018-09-23 23:59:59','2018-09-24 07:59:59','KNCBTC','4h','0.000060370000000','0.000057750000000','0.001707717180867','0.001633603895893','28.287513348799074','28.287513348799074','test'),('2018-10-01 07:59:59','2018-10-01 15:59:59','KNCBTC','4h','0.000059080000000','0.000058170000000','0.001707717180867','0.001681413480214','28.905165552928235','28.905165552928235','test'),('2018-10-01 19:59:59','2018-10-03 11:59:59','KNCBTC','4h','0.000058590000000','0.000058750000000','0.001707717180867','0.001712380685713','29.14690528873528','29.146905288735280','test'),('2018-10-06 23:59:59','2018-10-07 15:59:59','KNCBTC','4h','0.000059100000000','0.000059210000000','0.001707717180867','0.001710895673082','28.89538377101523','28.895383771015229','test'),('2018-10-07 23:59:59','2018-10-11 03:59:59','KNCBTC','4h','0.000059970000000','0.000060960000000','0.001707717180867','0.001735908610066','28.476191110005004','28.476191110005004','test'),('2018-10-15 19:59:59','2018-10-22 03:59:59','KNCBTC','4h','0.000064280000000','0.000063340000000','0.001707717180867','0.001682744340948','26.566850978018046','26.566850978018046','test'),('2018-10-23 03:59:59','2018-10-27 23:59:59','KNCBTC','4h','0.000065850000000','0.000070700000000','0.001707717180867','0.001833494376421','25.93344238218679','25.933442382186790','test'),('2018-12-01 03:59:59','2018-12-02 23:59:59','KNCBTC','4h','0.000053580000000','0.000046600000000','0.001707717180867','0.001485248611952','31.87228781013438','31.872287810134381','test'),('2018-12-20 07:59:59','2018-12-25 03:59:59','KNCBTC','4h','0.000043040000000','0.000039930000000','0.001707717180867','0.001584320330670','39.67744379337825','39.677443793378252','test'),('2018-12-26 19:59:59','2018-12-27 07:59:59','KNCBTC','4h','0.000041280000000','0.000040730000000','0.001707717180867','0.001684964166103','41.36911775356105','41.369117753561049','test'),('2018-12-27 11:59:59','2018-12-27 19:59:59','KNCBTC','4h','0.000041340000000','0.000040700000000','0.001707717180867','0.001681279372552','41.30907549267054','41.309075492670537','test'),('2018-12-28 19:59:59','2018-12-29 11:59:59','KNCBTC','4h','0.000042200000000','0.000041100000000','0.001707717180867','0.001663203225915','40.467231774099524','40.467231774099524','test'),('2018-12-29 15:59:59','2018-12-30 03:59:59','KNCBTC','4h','0.000041470000000','0.000041230000000','0.001707717180867','0.001697834081677','41.17957995821075','41.179579958210752','test'),('2018-12-30 15:59:59','2018-12-31 03:59:59','KNCBTC','4h','0.000042230000000','0.000041500000000','0.001707717180867','0.001678197087520','40.43848403663273','40.438484036632730','test'),('2019-01-01 15:59:59','2019-01-03 11:59:59','KNCBTC','4h','0.000041800000000','0.000041430000000','0.001707717180867','0.001692601024003','40.85447801117225','40.854478011172247','test'),('2019-01-06 07:59:59','2019-01-07 07:59:59','KNCBTC','4h','0.000042170000000','0.000041680000000','0.001707717180867','0.001687874130864','40.496020414204416','40.496020414204416','test'),('2019-01-25 03:59:59','2019-01-25 15:59:59','KNCBTC','4h','0.000040050000000','0.000038470000000','0.001707717180867','0.001640346565492','42.63962998419476','42.639629984194762','test'),('2019-01-25 19:59:59','2019-01-25 23:59:59','KNCBTC','4h','0.000038610000000','0.000038580000000','0.001707717180867','0.001706390283291','44.22991921437452','44.229919214374519','test'),('2019-01-26 11:59:59','2019-01-26 19:59:59','KNCBTC','4h','0.000038670000000','0.000038750000000','0.001707717180867','0.001711250084267','44.161292497207135','44.161292497207135','test'),('2019-02-08 07:59:59','2019-02-08 19:59:59','KNCBTC','4h','0.000036650000000','0.000035020000000','0.001707717180867','0.001631766866957','46.59528460755798','46.595284607557979','test'),('2019-02-08 23:59:59','2019-02-09 03:59:59','KNCBTC','4h','0.000035160000000','0.000034990000000','0.001707717180867','0.001699460300300','48.56988569018771','48.569885690187711','test'),('2019-02-09 07:59:59','2019-02-09 19:59:59','KNCBTC','4h','0.000035240000000','0.000035170000000','0.001707717180867','0.001704325007125','48.4596248827185','48.459624882718501','test'),('2019-02-09 23:59:59','2019-02-10 07:59:59','KNCBTC','4h','0.000035240000000','0.000034490000000','0.001707717180867','0.001671372462205','48.4596248827185','48.459624882718501','test'),('2019-02-10 11:59:59','2019-02-12 11:59:59','KNCBTC','4h','0.000041000000000','0.000036380000000','0.001707717180867','0.001515286610730','41.65163855773171','41.651638557731708','test'),('2019-02-16 03:59:59','2019-02-19 03:59:59','KNCBTC','4h','0.000037850000000','0.000038020000000','0.001707717180867','0.001715387244823','45.11802327257596','45.118023272575961','test'),('2019-02-22 19:59:59','2019-02-23 19:59:59','KNCBTC','4h','0.000040180000000','0.000038410000000','0.001707717180867','0.001632489221431','42.50167199768542','42.501671997685420','test'),('2019-02-23 23:59:59','2019-02-24 03:59:59','KNCBTC','4h','0.000038480000000','0.000038410000000','0.001707717180867','0.001704610626744','44.37934461712578','44.379344617125781','test'),('2019-02-24 07:59:59','2019-02-24 15:59:59','KNCBTC','4h','0.000039790000000','0.000037990000000','0.001707717180867','0.001630464330262','42.91825033593868','42.918250335938680','test'),('2019-02-26 07:59:59','2019-03-03 23:59:59','KNCBTC','4h','0.000039590000000','0.000045390000000','0.001707717180867','0.001957900551643','43.135063926925994','43.135063926925994','test'),('2019-03-07 11:59:59','2019-03-11 15:59:59','KNCBTC','4h','0.000046700000000','0.000067500000000','0.001707717180867','0.002468327831018','36.56781971877945','36.567819718779447','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 12:41:48
