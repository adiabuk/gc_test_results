-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-16 11:59:59','2018-08-27 23:59:59','NANOBNB','4h','0.126100000000000','0.269900000000000','0.711908500000000','1.523743886994449','5.645586835844568','5.645586835844568','test'),('2018-08-28 03:59:59','2018-08-28 19:59:59','NANOBNB','4h','0.297800000000000','0.281100000000000','0.914867346748612','0.863563502924899','3.0720864565097794','3.072086456509779','test'),('2018-08-31 15:59:59','2018-09-02 03:59:59','NANOBNB','4h','0.283200000000000','0.267300000000000','0.914867346748612','0.863502972407853','3.2304637950162856','3.230463795016286','test'),('2018-09-14 19:59:59','2018-09-17 11:59:59','NANOBNB','4h','0.270300000000000','0.246700000000000','0.914867346748612','0.834989916547845','3.3846368729138443','3.384636872913844','test'),('2018-09-20 11:59:59','2018-09-20 23:59:59','NANOBNB','4h','0.253500000000000','0.255400000000000','0.914867346748612','0.921724340669016','3.608944168633578','3.608944168633578','test'),('2018-09-21 03:59:59','2018-09-22 03:59:59','NANOBNB','4h','0.257700000000000','0.240100000000000','0.914867346748612','0.852385137579906','3.5501255209492126','3.550125520949213','test'),('2018-10-18 03:59:59','2018-10-18 19:59:59','NANOBNB','4h','0.215100000000000','0.196600000000000','0.914867346748612','0.836182800422023','4.253218720356169','4.253218720356169','test'),('2018-10-18 23:59:59','2018-10-22 03:59:59','NANOBNB','4h','0.203500000000000','0.205700000000000','0.914867346748612','0.924757804551300','4.495662637585317','4.495662637585317','test'),('2018-10-26 19:59:59','2018-10-27 19:59:59','NANOBNB','4h','0.211700000000000','0.206200000000000','0.914867346748612','0.891098946148152','4.321527381901805','4.321527381901805','test'),('2018-10-27 23:59:59','2018-10-28 03:59:59','NANOBNB','4h','0.207800000000000','0.208400000000000','0.914867346748612','0.917508927153083','4.4026340074524155','4.402634007452416','test'),('2018-10-31 23:59:59','2018-11-01 11:59:59','NANOBNB','4h','0.212000000000000','0.209100000000000','0.914867346748612','0.902352651911013','4.315412012965151','4.315412012965151','test'),('2018-11-01 23:59:59','2018-11-02 03:59:59','NANOBNB','4h','0.206300000000000','0.204400000000000','0.914867346748612','0.906441520481902','4.434645403531808','4.434645403531808','test'),('2018-11-21 11:59:59','2018-11-22 15:59:59','NANOBNB','4h','0.204900000000000','0.189200000000000','0.914867346748612','0.844767701341325','4.464945567343153','4.464945567343153','test'),('2018-11-23 15:59:59','2018-11-24 23:59:59','NANOBNB','4h','0.192800000000000','0.186900000000000','0.914867346748612','0.886870887486077','4.745162586870395','4.745162586870395','test'),('2018-11-25 03:59:59','2018-11-26 03:59:59','NANOBNB','4h','0.191800000000000','0.194700000000000','0.914867346748612','0.928700064713007','4.769902746343129','4.769902746343129','test'),('2018-11-26 07:59:59','2018-11-26 19:59:59','NANOBNB','4h','0.197700000000000','0.195000000000000','0.914867346748612','0.902372952028221','4.627553600144725','4.627553600144725','test'),('2018-11-27 15:59:59','2018-11-30 11:59:59','NANOBNB','4h','0.198000000000000','0.194100000000000','0.914867346748612','0.896847232342957','4.62054215529602','4.620542155296020','test'),('2018-12-01 19:59:59','2018-12-01 23:59:59','NANOBNB','4h','0.205400000000000','0.204300000000000','0.914867346748612','0.909967862418410','4.454076663819922','4.454076663819922','test'),('2018-12-02 07:59:59','2018-12-02 11:59:59','NANOBNB','4h','0.202300000000000','0.199000000000000','0.914867346748612','0.899943657948462','4.522329939439506','4.522329939439506','test'),('2018-12-20 11:59:59','2018-12-22 15:59:59','NANOBNB','4h','0.177800000000000','0.173600000000000','0.914867346748612','0.893256307061637','5.1454856397559725','5.145485639755973','test'),('2018-12-23 03:59:59','2018-12-23 11:59:59','NANOBNB','4h','0.182100000000000','0.176100000000000','0.914867346748612','0.884723447349976','5.023983233106051','5.023983233106051','test'),('2018-12-24 11:59:59','2018-12-24 19:59:59','NANOBNB','4h','0.180000000000000','0.174500000000000','0.914867346748612','0.886913066709071','5.082596370825622','5.082596370825622','test'),('2019-01-24 03:59:59','2019-01-25 15:59:59','NANOBNB','4h','0.151600000000000','0.145900000000000','0.914867346748612','0.880469300070069','6.034745031323298','6.034745031323298','test'),('2019-01-25 19:59:59','2019-01-26 19:59:59','NANOBNB','4h','0.148900000000000','0.142800000000000','0.914867346748612','0.877387891979193','6.144172913019557','6.144172913019557','test'),('2019-01-31 07:59:59','2019-01-31 15:59:59','NANOBNB','4h','0.145700000000000','0.139000000000000','0.914867346748612','0.872797262855574','6.279116998960961','6.279116998960961','test'),('2019-02-27 03:59:59','2019-02-27 07:59:59','NANOBNB','4h','0.093000000000000','0.089700000000000','0.914867346748612','0.882404311863984','9.837283298372173','9.837283298372173','test'),('2019-02-27 11:59:59','2019-02-27 15:59:59','NANOBNB','4h','0.090800000000000','0.088200000000000','0.914867346748612','0.888670704661097','10.075631572121278','10.075631572121278','test'),('2019-03-21 11:59:59','2019-03-21 23:59:59','NANOBNB','4h','0.067600000000000','0.067600000000000','0.914867346748612','0.914867346748612','13.533540632375919','13.533540632375919','test'),('2019-03-22 07:59:59','2019-03-22 11:59:59','NANOBNB','4h','0.066200000000000','0.065300000000000','0.914867346748612','0.902429573152332','13.819748440311361','13.819748440311361','test'),('2019-03-24 03:59:59','2019-03-24 07:59:59','NANOBNB','4h','0.067000000000000','0.065700000000000','0.914867346748612','0.897116189274385','13.654736518636','13.654736518636000','test'),('2019-04-01 07:59:59','2019-04-01 11:59:59','NANOBNB','4h','0.064400000000000','0.061800000000000','0.914867346748612','0.877931708525842','14.206014701065405','14.206014701065405','test'),('2019-04-01 15:59:59','2019-04-04 23:59:59','NANOBNB','4h','0.062200000000000','0.069300000000000','0.914867346748612','1.019297542277795','14.708478243546818','14.708478243546818','test'),('2019-04-05 07:59:59','2019-04-11 11:59:59','NANOBNB','4h','0.072300000000000','0.085500000000000','0.914867346748612','1.081897069806450','12.65376689832105','12.653766898321051','test'),('2019-04-12 23:59:59','2019-04-13 11:59:59','NANOBNB','4h','0.089000000000000','0.084700000000000','0.914867346748612','0.870665890669747','10.279408390433844','10.279408390433844','test'),('2019-04-24 15:59:59','2019-04-24 23:59:59','NANOBNB','4h','0.079200000000000','0.077200000000000','0.914867346748612','0.891764635972132','11.55135538824005','11.551355388240051','test'),('2019-04-25 07:59:59','2019-04-25 19:59:59','NANOBNB','4h','0.076700000000000','0.078300000000000','0.914867346748612','0.933951932860708','11.92786632006013','11.927866320060129','test'),('2019-05-07 19:59:59','2019-05-11 19:59:59','NANOBNB','4h','0.072800000000000','0.077400000000000','0.914867346748612','0.972674898878332','12.56685915863478','12.566859158634781','test'),('2019-05-12 03:59:59','2019-05-13 07:59:59','NANOBNB','4h','0.080100000000000','0.072700000000000','0.914867346748612','0.830347766649489','11.421564878259826','11.421564878259826','test'),('2019-07-08 03:59:59','2019-07-08 11:59:59','NANOBNB','4h','0.042100000000000','0.038900000000000','0.914867346748612','0.845328736069383','21.730815837259193','21.730815837259193','test'),('2019-07-08 19:59:59','2019-07-10 15:59:59','NANOBNB','4h','0.039600000000000','0.040000000000000','0.914867346748612','0.924108431059204','23.1027107764801','23.102710776480102','test'),('2019-07-18 15:59:59','2019-07-18 19:59:59','NANOBNB','4h','0.039400000000000','0.038160000000000','0.914867346748612','0.886074567307793','23.219983420015534','23.219983420015534','test'),('2019-07-21 11:59:59','2019-07-21 11:59:59','NANOBNB','4h','0.039910000000000','0.039910000000000','0.914867346748612','0.914867346748612','22.923261005978752','22.923261005978752','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  3:58:49
