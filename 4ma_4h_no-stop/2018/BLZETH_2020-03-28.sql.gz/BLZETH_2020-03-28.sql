-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-26 03:59:59','2018-07-26 11:59:59','BLZETH','4h','0.000703930000000','0.000667770000000','0.072144500000000','0.068438527644794','102.48817353998267','102.488173539982668','test'),('2018-07-26 19:59:59','2018-07-26 23:59:59','BLZETH','4h','0.000667430000000','0.000652000000000','0.072144500000000','0.070476625264073','108.09298353385374','108.092983533853740','test'),('2018-08-26 07:59:59','2018-08-29 23:59:59','BLZETH','4h','0.000435970000000','0.000472150000000','0.072144500000000','0.078131581702869','165.4804229648829','165.480422964882905','test'),('2018-08-31 07:59:59','2018-09-05 15:59:59','BLZETH','4h','0.000489830000000','0.000526650000000','0.072297808652934','0.077732358016185','147.5977556559092','147.597755655909197','test'),('2018-09-07 15:59:59','2018-09-11 11:59:59','BLZETH','4h','0.000552970000000','0.000561000000000','0.073656445993747','0.074726054220829','133.2015226752749','133.201522675274902','test'),('2018-09-11 19:59:59','2018-09-12 19:59:59','BLZETH','4h','0.000566520000000','0.000552560000000','0.073923848050517','0.072102240836676','130.48762276798215','130.487622767982145','test'),('2018-09-19 19:59:59','2018-09-20 19:59:59','BLZETH','4h','0.000537840000000','0.000532220000000','0.073923848050517','0.073151402665191','137.44579810076786','137.445798100767860','test'),('2018-09-21 07:59:59','2018-09-21 19:59:59','BLZETH','4h','0.000537040000000','0.000529050000000','0.073923848050517','0.072824020205434','137.6505438152037','137.650543815203690','test'),('2018-09-21 23:59:59','2018-09-22 03:59:59','BLZETH','4h','0.000536900000000','0.000525480000000','0.073923848050517','0.072351468939441','137.68643704696777','137.686437046967768','test'),('2018-09-22 07:59:59','2018-09-22 11:59:59','BLZETH','4h','0.000553400000000','0.000524190000000','0.073923848050517','0.070021940566680','133.58122163085832','133.581221630858323','test'),('2018-09-22 15:59:59','2018-09-23 03:59:59','BLZETH','4h','0.000548320000000','0.000537780000000','0.073923848050517','0.072502857828653','134.81880662845964','134.818806628459640','test'),('2018-09-23 07:59:59','2018-09-23 15:59:59','BLZETH','4h','0.000541870000000','0.000528900000000','0.073923848050517','0.072154434151952','136.4235850859376','136.423585085937589','test'),('2018-09-25 23:59:59','2018-09-27 19:59:59','BLZETH','4h','0.000537830000000','0.000537680000000','0.073923848050517','0.073903230797468','137.44835366289905','137.448353662899052','test'),('2018-09-30 23:59:59','2018-10-10 07:59:59','BLZETH','4h','0.000551010000000','0.000588770000000','0.073923848050517','0.078989753392321','134.16062875540734','134.160628755407345','test'),('2018-10-10 11:59:59','2018-10-11 07:59:59','BLZETH','4h','0.000604310000000','0.000573190000000','0.073923848050517','0.070117010249832','122.32769282407537','122.327692824075370','test'),('2018-10-14 07:59:59','2018-10-14 15:59:59','BLZETH','4h','0.000600650000000','0.000591070000000','0.073923848050517','0.072744807903470','123.07308424293181','123.073084242931813','test'),('2018-10-14 19:59:59','2018-10-15 07:59:59','BLZETH','4h','0.000602370000000','0.000566400000000','0.073923848050517','0.069509549837829','122.7216628492737','122.721662849273699','test'),('2018-10-15 15:59:59','2018-10-19 11:59:59','BLZETH','4h','0.000601800000000','0.000631030000000','0.073923848050517','0.077514399859285','122.83789971837321','122.837899718373208','test'),('2018-10-20 23:59:59','2018-10-22 03:59:59','BLZETH','4h','0.000664430000000','0.000628580000000','0.073923848050517','0.069935211245118','111.25904617569495','111.259046175694948','test'),('2018-10-27 03:59:59','2018-10-27 11:59:59','BLZETH','4h','0.000647950000000','0.000631390000000','0.073923848050517','0.072034537264628','114.0888155729871','114.088815572987102','test'),('2018-10-28 19:59:59','2018-10-29 07:59:59','BLZETH','4h','0.000654940000000','0.000646260000000','0.073923848050517','0.072944126242293','112.8711760627187','112.871176062718703','test'),('2018-10-29 11:59:59','2018-10-31 15:59:59','BLZETH','4h','0.000686190000000','0.000677260000000','0.073923848050517','0.072961811350636','107.7308734468835','107.730873446883507','test'),('2018-11-01 11:59:59','2018-11-04 11:59:59','BLZETH','4h','0.000722160000000','0.000688880000000','0.073923848050517','0.070517143631661','102.36491643197766','102.364916431977662','test'),('2018-11-29 03:59:59','2018-11-30 11:59:59','BLZETH','4h','0.000512970000000','0.000504740000000','0.073923848050517','0.072737826900244','144.10949578048815','144.109495780488146','test'),('2018-11-30 15:59:59','2018-12-03 07:59:59','BLZETH','4h','0.000516350000000','0.000520880000000','0.073923848050517','0.074572390767025','143.16616258452018','143.166162584520180','test'),('2018-12-10 11:59:59','2018-12-11 15:59:59','BLZETH','4h','0.000542790000000','0.000522620000000','0.073923848050517','0.071176848262056','136.19235441057683','136.192354410576826','test'),('2019-01-13 03:59:59','2019-01-14 15:59:59','BLZETH','4h','0.000317360000000','0.000301880000000','0.073923848050517','0.070318033934617','232.9337284173084','232.933728417308402','test'),('2019-01-15 15:59:59','2019-01-20 23:59:59','BLZETH','4h','0.000328390000000','0.000348420000000','0.073923848050517','0.078432799834834','225.1099243293553','225.109924329355295','test'),('2019-01-21 07:59:59','2019-01-24 03:59:59','BLZETH','4h','0.000361040000000','0.000359020000000','0.073923848050517','0.073510247970022','204.75251509671224','204.752515096712244','test'),('2019-02-07 03:59:59','2019-02-08 15:59:59','BLZETH','4h','0.000353210000000','0.000347770000000','0.073923848050517','0.072785302331554','209.2914924563772','209.291492456377199','test'),('2019-02-27 15:59:59','2019-02-28 11:59:59','BLZETH','4h','0.000321980000000','0.000311900000000','0.073923848050517','0.071609566454302','229.59142819590346','229.591428195903461','test'),('2019-03-01 07:59:59','2019-03-05 19:59:59','BLZETH','4h','0.000319630000000','0.000355470000000','0.073923848050517','0.082212903252252','231.27944201269278','231.279442012692783','test'),('2019-03-06 07:59:59','2019-03-07 07:59:59','BLZETH','4h','0.000387140000000','0.000359170000000','0.073923848050517','0.068583015199422','190.94861820146974','190.948618201469742','test'),('2019-03-09 07:59:59','2019-03-17 03:59:59','BLZETH','4h','0.000391190000000','0.000416530000000','0.073923848050517','0.078712391493857','188.97172231017407','188.971722310174073','test'),('2019-03-23 19:59:59','2019-03-24 11:59:59','BLZETH','4h','0.000414000000000','0.000400020000000','0.073923848050517','0.071427578978666','178.56001944569323','178.560019445693229','test'),('2019-03-27 03:59:59','2019-04-02 07:59:59','BLZETH','4h','0.000423640000000','0.000464780000000','0.073923848050517','0.081102648703898','174.49685594022517','174.496855940225174','test'),('2019-04-04 23:59:59','2019-04-08 07:59:59','BLZETH','4h','0.000473170000000','0.000481650000000','0.073923848050517','0.075248687392547','156.231054484682','156.231054484682005','test'),('2019-05-23 07:59:59','2019-05-24 19:59:59','BLZETH','4h','0.000261330000000','0.000255140000000','0.073923848050517','0.072172848856269','282.8754756458003','282.875475645800293','test'),('2019-05-24 23:59:59','2019-05-25 03:59:59','BLZETH','4h','0.000259980000000','0.000265320000000','0.073923848050517','0.075442246960394','284.34436514546115','284.344365145461154','test'),('2019-06-07 07:59:59','2019-06-09 19:59:59','BLZETH','4h','0.000256380000000','0.000259070000000','0.073923848050517','0.074699474664355','288.3370311666939','288.337031166693919','test'),('2019-06-10 03:59:59','2019-06-11 15:59:59','BLZETH','4h','0.000257640000000','0.000256430000000','0.073923848050517','0.073576666494310','286.92690595605103','286.926905956051030','test'),('2019-06-14 07:59:59','2019-06-14 11:59:59','BLZETH','4h','0.000263590000000','0.000238940000000','0.073923848050517','0.067010752506508','280.4501234891953','280.450123489195278','test'),('2019-07-23 23:59:59','2019-07-24 19:59:59','BLZETH','4h','0.000169580000000','0.000169640000000','0.073923848050517','0.073950003439614','435.92315161290827','435.923151612908271','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 20:48:11
